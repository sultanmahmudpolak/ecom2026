import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

declare global {
  interface Window {
    __STOCKMASTER_BOOTED__?: boolean;
  }
}

if (typeof window !== 'undefined') {
  window.__STOCKMASTER_BOOTED__ = true;

  // Protect React DOM reconciliation from crashing if a mobile browser translator or extension mutates text nodes
  if (typeof Node === 'function' && Node.prototype) {
    const originalRemoveChild = Node.prototype.removeChild;
    Node.prototype.removeChild = function <T extends Node>(child: T): T {
      if (child.parentNode !== this) {
        return child;
      }
      return originalRemoveChild.apply(this, arguments as unknown as [Node]) as T;
    };

    const originalInsertBefore = Node.prototype.insertBefore;
    Node.prototype.insertBefore = function <T extends Node>(newNode: T, referenceNode: Node | null): T {
      if (referenceNode && referenceNode.parentNode !== this) {
        return this.appendChild(newNode);
      }
      return originalInsertBefore.apply(this, arguments as unknown as [Node, Node | null]) as T;
    };
  }
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class RootErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || 'Unexpected rendering error'
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('[StockMaster BD RootErrorBoundary]', error, errorInfo);
    const msg = String(error?.message || '').toLowerCase();

    // If the error was a transient DOM node mismatch (e.g. browser translator), recover in-place without showing error screen
    if (msg.includes('removechild') || msg.includes('insertbefore')) {
      this.setState({ hasError: false, errorMessage: '' });
      return;
    }

    // Auto-reload once silently if cPanel files were just updated (chunk/cache mismatch)
    try {
      const autoRecoverKey = 'sm_auto_recovered_once_v1';
      if (!window.sessionStorage.getItem(autoRecoverKey)) {
        window.sessionStorage.setItem(autoRecoverKey, '1');
        window.location.reload();
      }
    } catch {
      // Ignore storage errors
    }
  }

  handleSafeReload = () => {
    try {
      window.sessionStorage.clear();
      window.localStorage.removeItem('stockmaster_active_route_mode_v1');
      window.localStorage.removeItem('stockmaster_active_erp_view_v1');
      window.localStorage.removeItem('stockmaster_last_erp_view_v1');
      window.localStorage.removeItem('stockmaster_admin_theme_v1');
    } catch {
      // Ignore storage errors
    }
    window.location.href = '/';
  };

  handleHardResetCache = () => {
    try {
      window.sessionStorage.clear();
      window.localStorage.removeItem('stockmaster_bd_persistent_erp_v2');
      window.localStorage.removeItem('stockmaster_bd_auth_session_v2');
      window.localStorage.removeItem('stockmaster_active_route_mode_v1');
      window.localStorage.removeItem('stockmaster_active_erp_view_v1');
      window.localStorage.removeItem('stockmaster_last_erp_view_v1');
    } catch {
      // Ignore storage errors
    }
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            background: '#F8FAFC',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px',
            fontFamily: "'Noto Sans Bengali', 'Hind Siliguri', sans-serif"
          }}
        >
          <div
            style={{
              background: '#FFFFFF',
              border: '1px solid #E2E8F0',
              borderRadius: '20px',
              padding: '28px',
              maxWidth: '480px',
              width: '100%',
              boxShadow: '0 10px 30px -10px rgba(15, 23, 42, 0.08)',
              textAlign: 'center'
            }}
          >
            <div
              style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: '#ECFDF5',
                color: '#047857',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px',
                fontSize: '24px',
                fontWeight: 'bold'
              }}
            >
              ✓
            </div>
            <h2 style={{ margin: '0 0 8px', fontSize: '18px', fontWeight: 700, color: '#0F172A' }}>
              পেজটি রিলোড হচ্ছে (Auto Recovery)
            </h2>
            <p style={{ margin: '0 0 20px', fontSize: '13px', color: '#475569', lineHeight: 1.6 }}>
              আপনার ব্রাউজারে পূর্বের পুরনো ক্যাশ ডাটার কারণে পেজ লোড হতে সমস্যা হচ্ছিল। নিচের বাটনে ক্লিক করলেই পেজটি সাথে সাথে সচল হয়ে যাবে।
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <button
                type="button"
                onClick={this.handleSafeReload}
                style={{
                  padding: '12px 20px',
                  borderRadius: '12px',
                  border: 'none',
                  background: '#047857',
                  color: '#FFFFFF',
                  fontSize: '14px',
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                🔄 পেজ রিলোড করুন (Reload Now)
              </button>
              <button
                type="button"
                onClick={this.handleHardResetCache}
                style={{
                  padding: '10px 16px',
                  borderRadius: '12px',
                  border: '1px solid #CBD5E1',
                  background: '#F8FAFC',
                  color: '#334155',
                  fontSize: '12px',
                  fontWeight: 600,
                  cursor: 'pointer'
                }}
              >
                🧹 ব্রাউজার ক্যাশ ক্লিয়ার করে রিলোড করুন
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <RootErrorBoundary>
      <App />
    </RootErrorBoundary>
  );
}
