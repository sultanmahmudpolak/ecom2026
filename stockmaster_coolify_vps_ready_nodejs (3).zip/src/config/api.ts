/**
 * StockMaster BD - Single Centralized PHP REST API Configuration
 *
 * In cPanel production, VITE_API_BASE_URL points to `/api` (or `https://yourdomain.com/api`),
 * which is routed by `.htaccess` to `backend/api/index.php`.
 */

const resolvedApiBaseUrl = (() => {
  try {
    const metaEnv = (import.meta as unknown as { env?: Record<string, string | undefined> })?.env;
    if (metaEnv && typeof metaEnv.VITE_API_BASE_URL === 'string' && metaEnv.VITE_API_BASE_URL.trim() !== '') {
      return metaEnv.VITE_API_BASE_URL.trim();
    }
  } catch {
    // Fallback to '/api' in classic IIFE bundles
  }
  return '/api';
})();

export const API_CONFIG = {
  BASE_URL: resolvedApiBaseUrl,
  TIMEZONE: 'Asia/Dhaka',
  CURRENCY_SYMBOL: '৳',
  CURRENCY_CODE: 'BDT',
};

/**
 * Generates a unique cryptographic idempotency key to prevent duplicate
 * POS sales, wholesale challans, or purchase receipts on double-click / slow networks.
 */
export function generateIdempotencyKey(prefix = 'TX'): string {
  const randomPart = Math.random().toString(36).substring(2, 10).toUpperCase();
  return `${prefix}-${Date.now()}-${randomPart}`;
}

/**
 * Exports any tabular array to a UTF-8 CSV file (with Byte Order Mark \uFEFF
 * so Bangla script renders properly in Microsoft Excel & LibreOffice).
 */
export function exportToCsv(filename: string, headers: string[], rows: (string | number)[][]): void {
  const escapeCsvCell = (cell: string | number): string => {
    const str = String(cell ?? '').replace(/"/g, '""');
    return `"${str}"`;
  };

  const csvLines = [
    headers.map(escapeCsvCell).join(','),
    ...rows.map(row => row.map(escapeCsvCell).join(','))
  ];

  // Add UTF-8 BOM (\uFEFF) for Bangla Excel compatibility
  const blob = new Blob(['\uFEFF' + csvLines.join('\r\n')], {
    type: 'text/csv;charset=utf-8;'
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Exports any tabular array to a styled Microsoft Excel (.xls) / Google Sheets compatible spreadsheet
 * with UTF-8 Bangla encoding and explicit text formatting for Bangladeshi mobile numbers (01XXXXXXXXX)
 * so leading zeros are never stripped by Excel.
 */
export function exportToExcel(
  filename: string,
  sheetTitle: string,
  headers: string[],
  rows: (string | number)[][]
): void {
  const escapeHtml = (val: string | number): string =>
    String(val ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

  const isPhoneLike = (val: string | number): boolean => {
    const s = String(val ?? '').trim();
    return /^(\+?88)?01[3-9]\d{8}$/.test(s) || /^0\d{7,14}$/.test(s);
  };

  const thHtml = headers
    .map(
      h =>
        `<th style="background-color:#065f46;color:#ffffff;font-weight:bold;padding:8px 12px;border:1px solid #cbd5e1;text-align:left;white-space:nowrap;">${escapeHtml(
          h
        )}</th>`
    )
    .join('');

  const trHtml = rows
    .map((row, idx) => {
      const bg = idx % 2 === 0 ? '#ffffff' : '#f8fafc';
      const cells = row
        .map(cell => {
          const textFmt = isPhoneLike(cell) ? 'mso-number-format:"\\@";font-weight:bold;color:#0f172a;' : '';
          return `<td style="background-color:${bg};padding:7px 10px;border:1px solid #e2e8f0;vertical-align:top;${textFmt}">${escapeHtml(
            cell
          )}</td>`;
        })
        .join('');
      return `<tr>${cells}</tr>`;
    })
    .join('');

  const excelHtml = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="UTF-8" />
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>${escapeHtml(
    sheetTitle.slice(0, 30) || 'Marketing_Data'
  )}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
</head>
<body style="font-family:'Hind Siliguri','Noto Sans Bengali',Arial,sans-serif;font-size:12px;">
  <table border="1" cellspacing="0" cellpadding="5" style="border-collapse:collapse;">
    <thead><tr>${thHtml}</tr></thead>
    <tbody>${trHtml}</tbody>
  </table>
</body>
</html>`;

  const blob = new Blob(['\uFEFF' + excelHtml], {
    type: 'application/vnd.ms-excel;charset=utf-8;'
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.xls`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

