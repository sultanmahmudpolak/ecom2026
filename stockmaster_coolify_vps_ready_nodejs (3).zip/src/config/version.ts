export const APP_VERSION = 'v5.6.0';
export const APP_BUILD_CODE = '2026.11.02-CPANEL-V560';
export const APP_VERSION_LABEL_BN = 'ভার্সন ৫.৬.০ (অটো ক্যাশ-বাস্টিং ও ক্লিন অ্যাডমিন প্যানেল বিল্ড)';
export const APP_VERSION_LABEL_EN = 'Version 5.6.0 (Auto Cache-Busting & Clean Admin Panel Build)';

