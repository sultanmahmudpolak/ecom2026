import type { 
  Business, 
  Outlet, 
  Category, 
  Brand, 
  Product, 
  Customer, 
  Supplier, 
  Sale, 
  Purchase, 
  Expense, 
  AccountLedger, 
  SalesRep, 
  User,
  OnlineOrder
} from '../types/index.ts';

export const initialBusinesses: Business[] = [
  {
    id: 'biz_01',
    name: 'কিডস অ্যান্ড ফ্যাশন মার্ট',
    nameEn: 'Kids & Fashion Mart',
    businessType: 'supershop_and_distribution',
    taxId: 'BIN: 002349182-0102',
    phone: '+8801711234567',
    whatsappOrderPhone: '01711234567',
    callOrderPhone: '01711234567',
    address: 'প্লট ৪২, রোড ৭, ধানমন্ডি / বসুন্ধরা সিটি লেভেল-৩, ঢাকা-১২০৫',
    currency: '৳',
    vatRate: 5.0,
    invoicePrefix: 'KFM',
    planName: 'Enterprise SaaS Multi-Store',
    planStatus: 'active',
    planExpiresAt: '2027-12-31',
    maxOutlets: 5,
    maxWarehouses: 3,
    ecommerceDeliveryCharge: 60,
    insideDhakaDeliveryCharge: 60,
    outsideDhakaDeliveryCharge: 120,
    freeDeliveryEnabled: false,
    signupOtpRequired: false,
    wpSyncEnabled: true,
    developerCreditEnabled: true,
    developerCreditName: 'Web Studio BD',
    developerCreditLink: 'https://example.com',
    productImageZoomEnabled: true,
    topAnnouncementEnabled: true,
    topAnnouncementText: '❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।',
    topAnnouncementSpeed: 'normal',
    topUtilityBarEnabled: true,
    dailyOrderLimitEnabled: true,
    dailySameProductMaxCount: 2,
    dailyOrderMaxCount: 5,
    checkoutSummaryZoneToggleEnabled: true,
    checkoutSummaryZoneHideOnDesktop: true,
    checkoutEstimatedDeliveryEnabled: true,
    checkoutEstimatedDeliveryInsideText: '🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে',
    checkoutEstimatedDeliveryOutsideText: '🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)',
    orderEditEnabled: true
  },
  {
    id: 'biz_02',
    name: 'ঢাকা ফ্যাশন অ্যান্ড অ্যাপারেল হাব',
    nameEn: 'Dhaka Fashion & Apparel Hub',
    businessType: 'supershop_and_distribution',
    taxId: 'BIN: 009871234-0301',
    phone: '+8801819876543',
    address: 'উত্তরা সেক্টর ৭ ফ্যাশন জোন, ঢাকা-১২৩০',
    currency: '৳',
    vatRate: 5.0,
    invoicePrefix: 'DFH',
    planName: 'Pro Distribution Tier',
    planStatus: 'active',
    planExpiresAt: '2027-06-30',
    maxOutlets: 3,
    maxWarehouses: 2
  }
];

export const initialOutlets: Outlet[] = [
  {
    id: 'outlet_01',
    businessId: 'biz_01',
    name: 'ধানমন্ডি ফ্ল্যাগশিপ ফ্যাশন শোরুম (মেইন স্টোর)',
    type: 'retail_shop',
    address: 'বাড়ি ১২, রোড ৪/এ, ধানমন্ডি, ঢাকা',
    phone: '+8801711234567'
  },
  {
    id: 'outlet_02',
    businessId: 'biz_01',
    name: 'তেজগাঁও সেন্ট্রাল অ্যাপারেল ওয়্যারহাউজ (সেন্ট্রাল গুদাম)',
    type: 'central_warehouse',
    address: 'শিল্প এলাকা, তেজগাঁও, ঢাকা-১২০৮',
    phone: '+8801711998877'
  },
  {
    id: 'outlet_03',
    businessId: 'biz_01',
    name: 'মিরপুর ফ্যাশন ডিস্ট্রিবিউশন হাব',
    type: 'distribution_hub',
    address: 'সেকশন ১০, গোলচত্বর সংলগ্ন, মিরপুর, ঢাকা',
    phone: '+8801711445566'
  }
];

export const initialCategories: Category[] = [
  { id: 'cat_01', nameBn: 'বেবি ফ্রক ও পার্টি ড্রেস', nameEn: 'Baby Frock & Party Dress', slug: 'baby-party-dress' },
  { id: 'cat_02', nameBn: 'বেবি বয়েজ পাঞ্জাবি ও সেট', nameEn: 'Kids Panjabi & Boys Set', slug: 'kids-boys-wear' },
  { id: 'cat_03', nameBn: 'মেনজ পাঞ্জাবি ও শার্ট', nameEn: "Men's Panjabi & Shirt", slug: 'mens-fashion' },
  { id: 'cat_04', nameBn: 'লেডিস কুর্তি ও থ্রি-পিস', nameEn: 'Ladies Kurti & Three-Piece', slug: 'womens-fashion' }
];

export const initialBrands: Brand[] = [
  { id: 'brand_01', name: 'লিটল অ্যাঞ্জেল বেবি ওয়্যার (Little Angel)', origin: 'Bangladesh' },
  { id: 'brand_02', name: 'কিডস ক্লাব ফ্যাশন (Kids Club)', origin: 'Bangladesh' },
  { id: 'brand_03', name: 'আড়ং ক্রাফট স্টাইল (Aarong Style)', origin: 'Bangladesh' },
  { id: 'brand_04', name: 'সেইলর ফ্যাশন (Sailor)', origin: 'Bangladesh' }
];

const buildBabyYearVariants = (
  prefix: string,
  basePurchase: number,
  baseRetail: number
) => [
  { id: `${prefix}_1_2y`, label: '1-2 Years', type: 'size' as const, purchasePrice: basePurchase, retailPrice: baseRetail },
  { id: `${prefix}_3_4y`, label: '3-4 Years', type: 'size' as const, purchasePrice: basePurchase, retailPrice: baseRetail },
  { id: `${prefix}_5_6y`, label: '5-6 Years', type: 'size' as const, purchasePrice: basePurchase, retailPrice: baseRetail },
  { id: `${prefix}_7_8y`, label: '7-8 Years', type: 'size' as const, purchasePrice: basePurchase + 30, retailPrice: baseRetail + 50 },
  { id: `${prefix}_9_10y`, label: '9-10 Years', type: 'size' as const, purchasePrice: basePurchase + 50, retailPrice: baseRetail + 80 },
  { id: `${prefix}_11_12y`, label: '11-12 Years', type: 'size' as const, purchasePrice: basePurchase + 70, retailPrice: baseRetail + 100 }
];

const buildAdultSizeVariants = (
  prefix: string,
  basePurchase: number,
  baseRetail: number
) => [
  { id: `${prefix}_m`, label: 'M', type: 'size' as const, purchasePrice: basePurchase, retailPrice: baseRetail },
  { id: `${prefix}_l`, label: 'L', type: 'size' as const, purchasePrice: basePurchase, retailPrice: baseRetail },
  { id: `${prefix}_xl`, label: 'XL', type: 'size' as const, purchasePrice: basePurchase, retailPrice: baseRetail },
  { id: `${prefix}_xxl`, label: 'XXL', type: 'size' as const, purchasePrice: basePurchase + 40, retailPrice: baseRetail + 60 }
];

export const initialProducts: Product[] = [
  {
    id: 'prod_01',
    businessId: 'biz_01',
    sku: 'BABY-DRESS-01',
    barcode: '89411001001',
    nameBn: 'প্রিমিয়াম বেবি গার্লস পার্টি ফ্রক ও গাউন ড্রেস - পিঙ্ক প্রিন্সেস',
    nameEn: 'Premium Baby Girls Party Frock & Gown Dress - Pink Princess',
    categoryId: 'cat_01',
    brandId: 'brand_01',
    unit: 'পিস (Pcs)',
    packSize: 6,
    purchasePrice: 620,
    retailPrice: 950,
    wholesalePrice: 760,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 35,
      outlet_02: 140,
      outlet_03: 50
    },
    lowStockAlert: 10,
    batchNumber: 'BD-2601',
    expiryDate: '2029-12-31',
    vatPercent: 5,
    variants: buildBabyYearVariants('v_p01', 620, 950)
  },
  {
    id: 'prod_02',
    businessId: 'biz_01',
    sku: 'BABY-DRESS-02',
    barcode: '89411001002',
    nameBn: 'বেবি গার্লস সফট কটন ফ্লোরাল ফ্রক ও স্কার্ট সেট',
    nameEn: 'Baby Girls Soft Cotton Floral Frock & Skirt Set',
    categoryId: 'cat_01',
    brandId: 'brand_01',
    unit: 'সেট (Set)',
    packSize: 6,
    purchasePrice: 480,
    retailPrice: 750,
    wholesalePrice: 590,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 42,
      outlet_02: 160,
      outlet_03: 60
    },
    lowStockAlert: 10,
    batchNumber: 'BD-2602',
    expiryDate: '2029-12-31',
    vatPercent: 5,
    variants: buildBabyYearVariants('v_p02', 480, 750)
  },
  {
    id: 'prod_03',
    businessId: 'biz_01',
    sku: 'BABY-BOYS-03',
    barcode: '89411002001',
    nameBn: 'বেবি বয়েজ এক্সপোর্ট কোয়ালিটি টি-শার্ট ও ডেনিম শর্টস কম্বো সেট',
    nameEn: 'Baby Boys Export T-Shirt & Denim Shorts Combo Set',
    categoryId: 'cat_02',
    brandId: 'brand_02',
    unit: 'সেট (Set)',
    packSize: 6,
    purchasePrice: 520,
    retailPrice: 820,
    wholesalePrice: 640,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 38,
      outlet_02: 150,
      outlet_03: 55
    },
    lowStockAlert: 10,
    batchNumber: 'BB-2603',
    expiryDate: '2029-12-01',
    vatPercent: 5,
    variants: buildBabyYearVariants('v_p03', 520, 820)
  },
  {
    id: 'prod_04',
    businessId: 'biz_01',
    sku: 'BABY-PANJABI-04',
    barcode: '89411002002',
    nameBn: 'কিডস এমব্রয়ডারি কটন ফেস্টিভ পাঞ্জাবি ও পায়জামা সেট',
    nameEn: 'Kids Embroidered Cotton Festive Panjabi & Pajama Set',
    categoryId: 'cat_02',
    brandId: 'brand_02',
    unit: 'সেট (Set)',
    packSize: 6,
    purchasePrice: 680,
    retailPrice: 1050,
    wholesalePrice: 840,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 30,
      outlet_02: 120,
      outlet_03: 40
    },
    lowStockAlert: 10,
    batchNumber: 'BP-2604',
    expiryDate: '2029-11-20',
    vatPercent: 5,
    variants: buildBabyYearVariants('v_p04', 680, 1050)
  },
  {
    id: 'prod_05',
    businessId: 'biz_01',
    sku: 'BABY-DRESS-05',
    barcode: '89411004001',
    nameBn: 'বেবি গার্লস লেস ওয়ার্ক ফেস্টিভ কুর্তি ও প্লাজো সেট',
    nameEn: 'Baby Girls Lace Work Festive Kurti & Palazzo Set',
    categoryId: 'cat_01',
    brandId: 'brand_01',
    unit: 'সেট (Set)',
    packSize: 6,
    purchasePrice: 720,
    retailPrice: 1120,
    wholesalePrice: 890,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 28,
      outlet_02: 110,
      outlet_03: 45
    },
    lowStockAlert: 10,
    batchNumber: 'BK-2605',
    expiryDate: '2029-01-01',
    vatPercent: 5,
    variants: buildBabyYearVariants('v_p05', 720, 1120)
  },
  {
    id: 'prod_06',
    businessId: 'biz_01',
    sku: 'BABY-ROMPER-06',
    barcode: '89411003001',
    nameBn: 'কিডস প্রিমিয়াম কটন হুডি ও জগার্স উইন্টার/ক্যাজুয়াল সুট',
    nameEn: 'Kids Premium Cotton Hoodie & Joggers Casual Suit',
    categoryId: 'cat_02',
    brandId: 'brand_02',
    unit: 'সেট (Set)',
    packSize: 6,
    purchasePrice: 650,
    retailPrice: 990,
    wholesalePrice: 790,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 32,
      outlet_02: 95,
      outlet_03: 30
    },
    lowStockAlert: 10,
    batchNumber: 'BH-2606',
    expiryDate: '2029-10-10',
    vatPercent: 5,
    variants: buildBabyYearVariants('v_p06', 650, 990)
  },
  {
    id: 'prod_07',
    businessId: 'biz_01',
    sku: 'FASH-PANJABI-07',
    barcode: '89411003002',
    nameBn: 'প্রিমিয়াম এমব্রয়ডারি কটন পাঞ্জাবি - রয়েল মেরুন',
    nameEn: 'Premium Embroidered Cotton Panjabi - Royal Maroon',
    categoryId: 'cat_03',
    brandId: 'brand_03',
    unit: 'পিস (Pcs)',
    packSize: 6,
    purchasePrice: 1080,
    retailPrice: 1590,
    wholesalePrice: 1280,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 38,
      outlet_02: 140,
      outlet_03: 50
    },
    lowStockAlert: 10,
    batchNumber: 'PJ-2607',
    expiryDate: '2029-02-14',
    vatPercent: 5,
    variants: buildAdultSizeVariants('v_p07', 1080, 1590)
  },
  {
    id: 'prod_08',
    businessId: 'biz_01',
    sku: 'FASH-POLO-08',
    barcode: '89411004002',
    nameBn: 'এক্সপোর্ট কোয়ালিটি পিকে পোলো টি-শার্ট - ক্লাসিক ব্ল্যাক',
    nameEn: 'Export Quality Pique Polo T-Shirt - Classic Black',
    categoryId: 'cat_03',
    brandId: 'brand_04',
    unit: 'পিস (Pcs)',
    packSize: 12,
    purchasePrice: 420,
    retailPrice: 690,
    wholesalePrice: 520,
    minWholesaleQty: 12,
    stockByOutlet: {
      outlet_01: 45,
      outlet_02: 180,
      outlet_03: 60
    },
    lowStockAlert: 15,
    batchNumber: 'PL-2608',
    expiryDate: '2029-12-15',
    vatPercent: 5,
    variants: buildAdultSizeVariants('v_p08', 420, 690)
  },
  {
    id: 'prod_09',
    businessId: 'biz_01',
    sku: 'FASH-KURTI-09',
    barcode: '89411005001',
    nameBn: 'লেডিস এমব্রয়ডারি ফ্যাশন কুর্তি ও টিউনিক টপস',
    nameEn: 'Ladies Embroidered Fashion Kurti & Tunic Top',
    categoryId: 'cat_04',
    brandId: 'brand_03',
    unit: 'পিস (Pcs)',
    packSize: 6,
    purchasePrice: 780,
    retailPrice: 1250,
    wholesalePrice: 950,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 34,
      outlet_02: 120,
      outlet_03: 40
    },
    lowStockAlert: 10,
    batchNumber: 'KR-2609',
    expiryDate: '2029-06-30',
    vatPercent: 5,
    variants: buildAdultSizeVariants('v_p09', 780, 1250)
  },
  {
    id: 'prod_10',
    businessId: 'biz_01',
    sku: 'FASH-SHIRT-10',
    barcode: '89411005002',
    nameBn: 'মেনজ প্রিমিয়াম অক্সফোর্ড কটন ক্যাজুয়াল চেক শার্ট',
    nameEn: 'Mens Premium Oxford Cotton Casual Check Shirt',
    categoryId: 'cat_03',
    brandId: 'brand_04',
    unit: 'পিস (Pcs)',
    packSize: 10,
    purchasePrice: 750,
    retailPrice: 1150,
    wholesalePrice: 910,
    minWholesaleQty: 10,
    stockByOutlet: {
      outlet_01: 30,
      outlet_02: 110,
      outlet_03: 45
    },
    lowStockAlert: 10,
    batchNumber: 'SH-2610',
    expiryDate: '2029-01-01',
    vatPercent: 5,
    variants: buildAdultSizeVariants('v_p10', 750, 1150)
  },
  {
    id: 'prod_lp_makhana',
    businessId: 'biz_01',
    sku: 'LP-MAKHANA-01',
    barcode: '89411009001',
    nameBn: 'প্রিমিয়াম রোস্টেড মাখানা (হেলদি ফক্স নাটস - ওজন নিয়ন্ত্রণ ও পুষ্টিকর স্ন্যাকস)',
    nameEn: 'Premium Roasted Makhana (Healthy Fox Nuts Superfood)',
    categoryId: 'cat_01',
    brandId: 'brand_01',
    unit: 'প্যাক (Pack)',
    packSize: 1,
    purchasePrice: 320,
    regularPrice: 550,
    discountPrice: 450,
    retailPrice: 450,
    wholesalePrice: 390,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 85,
      outlet_02: 200,
      outlet_03: 60
    },
    lowStockAlert: 10,
    batchNumber: 'MK-2601',
    expiryDate: '2027-12-31',
    vatPercent: 0,
    isLandingPageProduct: true,
    landingSlug: 'makhana',
    freeDeliveryOnLanding: false,
    image: '',
    galleryImages: [],
    description:
      '১০০% প্রাকৃতিক ও অর্গানিক রোস্টেড মাখানা (Fox Nuts)\nপ্রোটিন, ক্যালসিয়াম ও অ্যান্টি-অক্সিডেন্ট সমৃদ্ধ সুপারফুড\nওজন নিয়ন্ত্রণ, ডায়াবেটিস ও হার্টের জন্য অত্যন্ত উপকারী হেলদি স্ন্যাকস\nবাচ্চা থেকে বয়স্ক সবার জন্য মুচমুচে ও সুস্বাদু নাস্তা\nসারাদেশে দ্রুত হোম ডেলিভারি ও পণ্য হাতে পেয়ে মূল্য পরিশোধের সুবিধা',
    variants: [
      {
        id: 'var_makhana_250g',
        label: '২৫০ গ্রাম ট্রায়াল প্যাক (250g Pack)',
        sku: 'LP-MAKHANA-250G',
        type: 'weight',
        purchasePrice: 320,
        regularPrice: 550,
        discountPrice: 450,
        retailPrice: 450
      },
      {
        id: 'var_makhana_500g',
        label: '৫০০ গ্রাম ফ্যামিলি প্যাক (500g Family Pack)',
        sku: 'LP-MAKHANA-500G',
        type: 'weight',
        purchasePrice: 600,
        regularPrice: 1050,
        discountPrice: 850,
        retailPrice: 850
      },
      {
        id: 'var_makhana_1kg',
        label: '১ কেজি সুপার সেভার প্যাক (1kg Value Pack)',
        sku: 'LP-MAKHANA-1KG',
        type: 'weight',
        purchasePrice: 1150,
        regularPrice: 2000,
        discountPrice: 1590,
        retailPrice: 1590
      }
    ]
  },
  {
    id: 'prod_lp_dress_collection',
    businessId: 'biz_01',
    sku: 'LP-DRESS-COLLECTION-02',
    barcode: '89411009002',
    nameBn: 'এক্সক্লুসিভ ৫-ডিজাইন প্রিমিয়াম ফেস্টিভ ড্রেস কালেকশন (Landing Page 2)',
    nameEn: 'Exclusive 5-Design Premium Festive Dress Collection',
    categoryId: 'cat_01',
    brandId: 'brand_01',
    unit: 'পিস (Pcs)',
    packSize: 1,
    purchasePrice: 620,
    regularPrice: 1350,
    discountPrice: 950,
    retailPrice: 950,
    wholesalePrice: 760,
    minWholesaleQty: 6,
    stockByOutlet: {
      outlet_01: 120,
      outlet_02: 300,
      outlet_03: 100
    },
    lowStockAlert: 10,
    batchNumber: 'DC-2602',
    expiryDate: '2029-12-31',
    vatPercent: 0,
    isLandingPageProduct: true,
    landingTemplate: 'template_2',
    landingSlug: 'dress-collection',
    landingShowcaseSectionTitle: 'পছন্দের ড্রেস ডিজাইনটি বেছে নিন',
    landingShowcaseSectionSubtitle:
      'আমাদের ওয়েবসাইটের সেরা ৫টি এক্সক্লুসিভ ড্রেস কালেকশন — যেকোনো ড্রেসে ক্লিক করে সরাসরি সাইজ ও অর্ডার কনফার্ম করুন',
    landingShowcaseItems: [
      {
        productId: 'prod_01',
        badgeText: 'টপ সেলিং 🔥',
        fabricSubtitle: 'প্রিমিয়াম চায়না মাইক্রো ভেলভেট',
        colorTag: 'রয়্যাল মেরুন'
      },
      {
        productId: 'prod_02',
        badgeText: 'বেস্ট চয়েস ⭐',
        fabricSubtitle: 'অরিজিনাল সুতি ও এমব্রয়ডারি',
        colorTag: 'রোজ পিঙ্ক'
      },
      {
        productId: 'prod_05',
        badgeText: 'লিমিটেড অফার ⏳',
        fabricSubtitle: 'সফট জর্জেট ও কারচুপি ওয়ার্ক',
        colorTag: 'এমেরাল্ড গ্রিন'
      },
      {
        productId: 'prod_07',
        badgeText: 'নতুন কালেকশন ✨',
        fabricSubtitle: 'প্রিমিয়াম লাক্সারি কটন',
        colorTag: 'রয়্যাল মেরুন'
      },
      {
        productId: 'prod_09',
        badgeText: 'ট্রেন্ডিং 🌸',
        fabricSubtitle: 'ইম্পোর্টেড সফট সিল্ক',
        colorTag: 'ডিপ ব্ল্যাক'
      }
    ],
    freeDeliveryOnLanding: false,
    image: '',
    galleryImages: [],
    description:
      '১০০% অরিজিনাল ও এক্সপোর্ট কোয়ালিটি প্রিমিয়াম ফেব্রিক\nআরামদায়ক ফিটিং এবং নিখুঁত এমব্রয়ডারি ও লেস ওয়ার্ক\nরঙ ও কাপড়ের ১০০% গ্যারান্টি — ধোয়ার পরও নতুনের মতো থাকবে\nপছন্দের ডিজাইন ও সঠিক সাইজ বেছে নেওয়ার সুবিধা\nসারাদেশে ক্যাশ অন ডেলিভারি — পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধ করুন',
    variants: buildAdultSizeVariants('v_lp_dc', 620, 950)
  }
];

export const initialCustomers: Customer[] = [
  {
    id: 'cust_01',
    businessId: 'biz_01',
    name: 'করিম ব্রাদার্স জেনারেল স্টোর',
    phone: '+8801712001122',
    address: 'দোকান নং ১৪, কাওরান বাজার কাঁচামাল মার্কেট, ঢাকা',
    route: 'কাওরান বাজার পাইকারি রুট',
    customerType: 'wholesale',
    creditLimit: 150000,
    currentDue: 38500,
    salesRepId: 'sr_01',
    createdAt: '2026-01-15'
  },
  {
    id: 'cust_02',
    businessId: 'biz_01',
    name: 'ভাই ভাই ডিপার্টমেন্টাল স্টোর',
    phone: '+8801815334455',
    address: 'প্লট ৮, রোড ৩, মিরপুর সেকশন ১০, ঢাকা',
    route: 'মিরপুর ডিস্ট্রিবিউশন রুট - ০১',
    customerType: 'wholesale',
    creditLimit: 100000,
    currentDue: 47200,
    salesRepId: 'sr_02',
    createdAt: '2026-02-01'
  },
  {
    id: 'cust_03',
    businessId: 'biz_01',
    name: 'মায়ের দোয়া কনফেকশনারি ও মুদি',
    phone: '+8801911778899',
    address: 'কলাবাগান বাসস্ট্যান্ড সংলগ্ন, ঢাকা',
    route: 'ধানমন্ডি-কলাবাগান রুট',
    customerType: 'wholesale',
    creditLimit: 60000,
    currentDue: 18400,
    salesRepId: 'sr_01',
    createdAt: '2026-03-10'
  },
  {
    id: 'cust_04',
    businessId: 'biz_01',
    name: 'ইঞ্জিনিয়ার মো: রফিকুল ইসলাম',
    phone: '+8801719223344',
    address: 'বাড়ি ৪৫, রোড ৮, ধানমন্ডি, ঢাকা',
    customerType: 'retail',
    creditLimit: 20000,
    currentDue: 3200,
    createdAt: '2026-05-12'
  },
  {
    id: 'cust_05',
    businessId: 'biz_01',
    name: 'ডা: তাহমিনা আক্তার',
    phone: '+8801611009988',
    address: 'ফ্ল্যাট ৪-বি, গ্রিন রোড, ধানমন্ডি',
    customerType: 'retail',
    creditLimit: 15000,
    currentDue: 0,
    createdAt: '2026-06-20'
  },
  {
    id: 'cust_online_01',
    businessId: 'biz_01',
    name: 'সাবরিনা সুলতানা নিপা',
    phone: '01715889900',
    address: 'বাসা ২৪, রোড ৯/এ, ফ্ল্যাট ৫-বি, ধানমন্ডি (ইবনে সিনা হাসপাতালের পাশে)',
    route: 'হোম ডেলিভারি (অনলাইন)',
    customerType: 'online',
    isOnlineCustomer: true,
    password: '1234',
    creditLimit: 0,
    currentDue: 0,
    createdAt: '2026-10-23'
  },
  {
    id: 'cust_online_02',
    businessId: 'biz_01',
    name: 'মাহমুদুল হাসান রনি',
    phone: '01819445566',
    address: 'বাড়ি ১৪, তাজমহল রোড, ব্লক-সি, মোহাম্মদপুর, ঢাকা',
    route: 'হোম ডেলিভারি (অনলাইন)',
    customerType: 'online',
    isOnlineCustomer: true,
    password: '1234',
    creditLimit: 0,
    currentDue: 0,
    createdAt: '2026-10-23'
  }
];

export const initialSuppliers: Supplier[] = [
  {
    id: 'supp_01',
    businessId: 'biz_01',
    name: 'জনাব সাজ্জাদ হোসেন (এরিয়া ম্যানেজার)',
    companyName: 'সিটি গ্রুপ / তীর এডিবল অয়েলস লি:',
    phone: '+8801713009911',
    email: 'sales@citygroupbd.com',
    address: 'সিটি ভবন, মতিঝিল বা/এ, ঢাকা-১০০০',
    currentPayable: 142000,
    bankDetails: 'BRAC Bank A/C: 1501203498001'
  },
  {
    id: 'supp_02',
    businessId: 'biz_01',
    name: 'জনাব আরিফুল হক (ডিস্ট্রিবিউশন প্রধান)',
    companyName: 'স্কয়ার কনজিউমার প্রডাক্টস লি:',
    phone: '+8801819223388',
    email: 'supply@squaregroup.com',
    address: 'স্কয়ার সেন্টার, মহাখালী বা/এ, ঢাকা-১২১২',
    currentPayable: 88500,
    bankDetails: 'Dutch-Bangla Bank A/C: 115120004921'
  },
  {
    id: 'supp_03',
    businessId: 'biz_01',
    name: 'জনাব মাহমুদুর রহমান',
    companyName: 'বসুন্ধরা ফুড অ্যান্ড বেভারেজ ইন্ডাস্ট্রিজ',
    phone: '+8801711884422',
    email: 'order@bashundharagroup.com',
    address: 'বসুন্ধরা আবাসিক এলাকা, বারিধারা, ঢাকা',
    currentPayable: 215000,
    bankDetails: 'Islami Bank BD Ltd A/C: 20501890044'
  },
  {
    id: 'supp_04',
    businessId: 'biz_01',
    name: 'জনাব তারেক মাহমুদ',
    companyName: 'এসিআই লিমিটেড (কনজিউমার গুডস)',
    phone: '+8801912445500',
    email: 'acipure@aci-bd.com',
    address: 'এসিআই সেন্টার, ২৪৫ তেজগাঁও শি/এ, ঢাকা',
    currentPayable: 65400,
    bankDetails: 'Standard Chartered A/C: 0118492001'
  }
];

export const initialSalesReps: SalesRep[] = [
  {
    id: 'sr_01',
    businessId: 'biz_01',
    name: 'মোঃ তারেকুল ইসলাম (তারেক)',
    phone: '+8801719882233',
    email: 'tarek.sr@stockflowbd.com',
    routeTerritory: 'কাওরান বাজার ও কলাবাগান রুট',
    monthlyTarget: 800000,
    commissionRate: 1.5,
    status: 'active'
  },
  {
    id: 'sr_02',
    businessId: 'biz_01',
    name: 'আশরাফুল ইসলাম জীবন',
    phone: '+8801817556644',
    email: 'ashraf.sr@stockflowbd.com',
    routeTerritory: 'মিরপুর সেকশন ১, ২, ১০ ও কাজীপাড়া',
    monthlyTarget: 950000,
    commissionRate: 1.5,
    status: 'active'
  },
  {
    id: 'sr_03',
    businessId: 'biz_01',
    name: 'তানভীর আহমেদ',
    phone: '+8801918334411',
    email: 'tanvir.sr@stockflowbd.com',
    routeTerritory: 'মোহাম্মদপুর ও শ্যামলী পাইকারি এলাকা',
    monthlyTarget: 750000,
    commissionRate: 1.5,
    status: 'active'
  }
];

export const initialAccounts: AccountLedger[] = [
  {
    id: 'acc_01',
    businessId: 'biz_01',
    accountName: 'ধানমন্ডি স্টোর ক্যাশ ড্রয়ার (Physical Cash Float)',
    type: 'cash_drawer',
    currentBalance: 48500
  },
  {
    id: 'acc_02',
    businessId: 'biz_01',
    accountName: 'বিকাশ মার্চেন্ট অ্যাকাউন্ট (bKash Merchant 01711234567)',
    type: 'bkash_merchant',
    accountNumber: '01711234567',
    currentBalance: 84320
  },
  {
    id: 'acc_03',
    businessId: 'biz_01',
    accountName: 'নগদ মার্চেন্ট ওয়ালেট (Nagad Merchant)',
    type: 'nagad_merchant',
    accountNumber: '01819876543',
    currentBalance: 32150
  },
  {
    id: 'acc_04',
    businessId: 'biz_01',
    accountName: 'ডাচ্-বাংলা ব্যাংক চলতি হিসাব (DBBL Current A/C)',
    type: 'bank_account',
    accountNumber: '115.110.49821',
    currentBalance: 425600
  }
];

export const initialSales: Sale[] = [
  {
    id: 'sale_01',
    invoiceNo: 'AMB-POS-20261022-001',
    businessId: 'biz_01',
    outletId: 'outlet_01',
    channel: 'retail_pos',
    customerName: 'সাধারণ খুচরা ক্রেতা',
    items: [
      {
        productId: 'prod_01',
        productName: 'তীর ফর্টিফাইড সয়াবিন তেল ৫ লিটার',
        unit: 'বোতল (Bottle)',
        quantity: 1,
        unitPrice: 940,
        costPrice: 860,
        discount: 0,
        total: 940
      },
      {
        productId: 'prod_05',
        productName: 'এসিআই পিওর আয়োডিনযুক্ত লবণ ১ কেজি',
        unit: 'প্যাকেট (Pack)',
        quantity: 2,
        unitPrice: 42,
        costPrice: 36,
        discount: 0,
        total: 84
      },
      {
        productId: 'prod_07',
        productName: 'ইস্পাহানি মির্জাপুর চা পাতা ৪০০ গ্রাম',
        unit: 'প্যাক (Pack)',
        quantity: 1,
        unitPrice: 245,
        costPrice: 215,
        discount: 0,
        total: 245
      }
    ],
    subtotal: 1269,
    taxAmount: 63.45,
    discountAmount: 19,
    grandTotal: 1313,
    paidAmount: 1500,
    changeAmount: 187,
    dueAmount: 0,
    paymentSplits: [{ method: 'cash', amount: 1500 }],
    status: 'completed',
    createdAt: '2026-10-22T10:15:00+06:00',
    cashierName: 'মো: আব্দুল্লাহ (ক্যাশিয়ার-১)',
    notes: 'কাউন্টার বিক্রয়'
  },
  {
    id: 'sale_02',
    invoiceNo: 'AMB-DIST-20261022-002',
    businessId: 'biz_01',
    outletId: 'outlet_03',
    channel: 'wholesale_distribution',
    customerId: 'cust_01',
    customerName: 'করিম ব্রাদার্স জেনারেল স্টোর',
    customerPhone: '+8801712001122',
    salesRepId: 'sr_01',
    items: [
      {
        productId: 'prod_01',
        productName: 'তীর ফর্টিফাইড সয়াবিন তেল ৫ লিটার',
        unit: 'বোতল (Bottle)',
        quantity: 16, // 4 cartons
        unitPrice: 890,
        costPrice: 860,
        discount: 0,
        total: 14240
      },
      {
        productId: 'prod_03',
        productName: 'মিনিকেট চাল প্রিমিয়াম ৫০ কেজি বস্তা',
        unit: 'বস্তা (Sack)',
        quantity: 10,
        unitPrice: 3680,
        costPrice: 3550,
        discount: 300,
        total: 36500
      },
      {
        productId: 'prod_09',
        productName: 'চাকা সুপার হোয়াইট কাপড় ধোয়ার সাবান ১৩০ গ্রাম',
        unit: 'পিস (Pcs)',
        quantity: 144, // 2 cartons
        unitPrice: 34,
        costPrice: 32,
        discount: 0,
        total: 4896
      }
    ],
    subtotal: 55636,
    taxAmount: 0,
    discountAmount: 636,
    grandTotal: 55000,
    paidAmount: 30000,
    changeAmount: 0,
    dueAmount: 25000,
    paymentSplits: [
      { method: 'bank', amount: 30000, reference: 'Chq # 482091' },
      { method: 'due', amount: 25000 }
    ],
    status: 'delivered',
    createdAt: '2026-10-22T11:45:00+06:00',
    cashierName: 'ডিস্ট্রিবিউশন ডেস্ক',
    notes: 'চালান নং: CH-8891, পরিবহন: নিজস্ব পিকআপ'
  },
  {
    id: 'sale_03',
    invoiceNo: 'AMB-POS-20261022-003',
    businessId: 'biz_01',
    outletId: 'outlet_01',
    channel: 'retail_pos',
    customerId: 'cust_04',
    customerName: 'ইঞ্জিনিয়ার মো: রফিকুল ইসলাম',
    customerPhone: '+8801719223344',
    items: [
      {
        productId: 'prod_06',
        productName: 'ডানো ফুল ক্রিম গুঁড়ো দুধ ১ কেজি জার',
        unit: 'জার (Jar)',
        quantity: 2,
        unitPrice: 975,
        costPrice: 870,
        discount: 0,
        total: 1950
      },
      {
        productId: 'prod_10',
        productName: 'বসুন্ধরা প্রিমিয়াম ফেসিয়াল টিস্যু (১০০x২ প্লাই)',
        unit: 'বক্স (Box)',
        quantity: 4,
        unitPrice: 85,
        costPrice: 72,
        discount: 0,
        total: 340
      }
    ],
    subtotal: 2290,
    taxAmount: 114.5,
    discountAmount: 50,
    grandTotal: 2354.5,
    paidAmount: 2354.5,
    changeAmount: 0,
    dueAmount: 0,
    paymentSplits: [{ method: 'bkash', amount: 2354.5, reference: 'TrxID: 9JK83B1' }],
    status: 'completed',
    createdAt: '2026-10-22T14:20:00+06:00',
    cashierName: 'মো: আব্দুল্লাহ (ক্যাশিয়ার-১)',
    notes: 'বিকাশ পেমেন্ট'
  }
];

export const initialPurchases: Purchase[] = [
  {
    id: 'pur_01',
    poNumber: 'PO-202610-091',
    businessId: 'biz_01',
    outletId: 'outlet_02',
    supplierId: 'supp_01',
    supplierName: 'সিটি গ্রুপ / তীর এডিবল অয়েলস লি:',
    items: [
      {
        productId: 'prod_01',
        productName: 'তীর ফর্টিফাইড সয়াবিন তেল ৫ লিটার',
        quantity: 100,
        unitCost: 860,
        total: 86000,
        batchNumber: 'TR-2603-A',
        expiryDate: '2027-09-15'
      }
    ],
    totalAmount: 86000,
    paidAmount: 50000,
    dueAmount: 36000,
    paymentMethod: 'bank',
    paymentRef: 'Online Transfer BRAC Bank',
    receivedDate: '2026-10-20',
    status: 'received',
    notes: 'তেজগাঁও সেন্ট্রাল ওয়্যারহাউজে খালাসকৃত'
  },
  {
    id: 'pur_02',
    poNumber: 'PO-202610-092',
    businessId: 'biz_01',
    outletId: 'outlet_02',
    supplierId: 'supp_03',
    supplierName: 'বসুন্ধরা ফুড অ্যান্ড বেভারেজ ইন্ডাস্ট্রিজ',
    items: [
      {
        productId: 'prod_03',
        productName: 'মিনিকেট চাল প্রিমিয়াম ৫০ কেজি বস্তা',
        quantity: 80,
        unitCost: 3550,
        total: 284000,
        batchNumber: 'MK-50-2026',
        expiryDate: '2027-12-01'
      }
    ],
    totalAmount: 284000,
    paidAmount: 200000,
    dueAmount: 84000,
    paymentMethod: 'bank',
    paymentRef: 'DBBL Cheque # 904812',
    receivedDate: '2026-10-21',
    status: 'received',
    notes: 'ট্রাক নং: ঢাকা মেট্রো-ট ১৮-৯৮১১'
  }
];

export const initialExpenses: Expense[] = [
  {
    id: 'exp_01',
    businessId: 'biz_01',
    outletId: 'outlet_01',
    category: 'electricity',
    amount: 14500,
    paymentMethod: 'bkash',
    paidTo: 'ডেসকো (DESCO Prepaid Meter Recharge)',
    date: '2026-10-18',
    note: 'ধানমন্ডি সুপার শপ বিদ্যুৎ বিল',
    createdBy: 'স্টোর ম্যানেজার'
  },
  {
    id: 'exp_02',
    businessId: 'biz_01',
    outletId: 'outlet_02',
    category: 'transport',
    amount: 4200,
    paymentMethod: 'cash',
    paidTo: 'কুলি ও লেবার লোডিং খরচ (তেজগাঁও)',
    date: '2026-10-21',
    note: 'চাল ও তেলের ট্রাক আনলোড মজুরি',
    createdBy: 'ওয়্যারহাউজ ইনচার্জ'
  },
  {
    id: 'exp_03',
    businessId: 'biz_01',
    outletId: 'outlet_01',
    category: 'packaging',
    amount: 3800,
    paymentMethod: 'cash',
    paidTo: 'রাজু প্রিন্টিং অ্যান্ড ব্যাগ হাউস',
    date: '2026-10-22',
    note: 'বায়োডিগ্রেডেবল শপিং ব্যাগ ও রোল পেপার',
    createdBy: 'ক্যাশিয়ার'
  }
];

export const initialUsers: User[] = [
  {
    id: 'user_01',
    name: 'আলহাজ্ব মো: কামরুল হাসান',
    username: 'admin',
    phone: '+8801711234567',
    email: 'owner@stockflowbd.com',
    role: 'super_admin',
    businessId: 'biz_01'
  },
  {
    id: 'user_02',
    name: 'কাজী শাহেদ আলম (ম্যানেজার)',
    username: 'manager',
    phone: '+8801711334455',
    email: 'manager.dhanmondi@stockflowbd.com',
    role: 'store_manager',
    businessId: 'biz_01',
    outletId: 'outlet_01'
  },
  {
    id: 'user_03',
    name: 'মো: আব্দুল্লাহ (ক্যাশিয়ার-১)',
    username: 'cashier1',
    phone: '+8801819665544',
    email: 'cashier1@stockflowbd.com',
    role: 'cashier',
    businessId: 'biz_01',
    outletId: 'outlet_01'
  },
  {
    id: 'user_04',
    name: 'মোঃ তারেকুল ইসলাম (এসআর)',
    username: 'sr_tarek',
    phone: '+8801719882233',
    email: 'tarek.sr@stockflowbd.com',
    role: 'sales_rep',
    businessId: 'biz_01'
  },
  {
    id: 'user_05',
    name: 'রফিকুল ইসলাম (ডিস্ট্রিবিউশন ইনচার্জ)',
    username: 'dist_mgr',
    phone: '+8801911554433',
    email: 'depot.mirpur@stockflowbd.com',
    role: 'distribution_mgr',
    businessId: 'biz_01',
    outletId: 'outlet_03'
  },
  {
    id: 'user_06',
    name: 'সিস্টেম ডেভেলপার (Developer)',
    username: 'developer',
    phone: '+8801700000000',
    email: 'developer@stockflowbd.com',
    role: 'developer',
    businessId: 'biz_01',
    outletId: 'outlet_01'
  }
];

export const initialOnlineOrders: OnlineOrder[] = [
  {
    id: 'eord_01',
    orderNo: 'ORD-48291',
    invoiceNo: 'SMB-48291',
    businessId: 'biz_01',
    outletId: 'outlet_01',
    customerName: 'সাবরিনা সুলতানা নিপা',
    customerPhone: '01715889900',
    deliveryArea: 'ধানমন্ডি ও কলাবাগান',
    deliveryAddress: 'বাসা ২৪, রোড ৯/এ, ফ্ল্যাট ৫-বি, ধানমন্ডি (ইবনে সিনা হাসপাতালের পাশে)',
    deliverySlot: 'এক্সপ্রেস ৬০ মিনিট ডেলিভারি',
    items: [
      {
        productId: 'prod_01',
        productName: 'তীর ফর্টিফাইড সয়াবিন তেল ৫ লিটার',
        unit: 'বোতল (Bottle)',
        quantity: 1,
        unitPrice: 940,
        costPrice: 860,
        discount: 0,
        total: 940
      },
      {
        productId: 'prod_13',
        productName: 'দেশি মসুর ডাল (চিকন দানা) ১ কেজি প্যাক',
        unit: 'প্যাকেট (Pack)',
        quantity: 2,
        unitPrice: 138,
        costPrice: 122,
        discount: 0,
        total: 276
      },
      {
        productId: 'prod_07',
        productName: 'ইস্পাহানি মির্জাপুর চা পাতা ৪০০ গ্রাম',
        unit: 'প্যাক (Pack)',
        quantity: 1,
        unitPrice: 245,
        costPrice: 215,
        discount: 0,
        total: 245
      }
    ],
    subtotal: 1461,
    deliveryCharge: 0,
    discountAmount: 0,
    grandTotal: 1461,
    paymentMethod: 'cod',
    paymentStatus: 'unpaid',
    orderStatus: 'pending',
    notes: 'বাসার নিচে এসে কল দিলে দারোয়ান রিসিভ করবে।',
    createdAt: '2026-10-23T11:30:00+06:00'
  },
  {
    id: 'eord_02',
    orderNo: 'ORD-59304',
    invoiceNo: 'SMB-59304',
    businessId: 'biz_01',
    outletId: 'outlet_01',
    customerName: 'মাহমুদুল হাসান রনি',
    customerPhone: '01819445566',
    deliveryArea: 'মিরপুর ও মোহাম্মদপুর',
    deliveryAddress: 'বাড়ি ১৪, তাজমহল রোড, ব্লক-সি, মোহাম্মদপুর, ঢাকা',
    deliverySlot: 'সকাল ৯টা - দুপুর ১টা',
    items: [
      {
        productId: 'prod_06',
        productName: 'ডানো ফুল ক্রিম গুঁড়ো দুধ ১ কেজি জার',
        unit: 'জার (Jar)',
        quantity: 1,
        unitPrice: 975,
        costPrice: 870,
        discount: 0,
        total: 975
      },
      {
        productId: 'prod_14',
        productName: 'বসুন্ধরা সাদা আটা ২ কেজি ফ্যামিলি প্যাক',
        unit: 'প্যাকেট (Pack)',
        quantity: 1,
        unitPrice: 115,
        costPrice: 98,
        discount: 0,
        total: 115
      }
    ],
    subtotal: 1090,
    deliveryCharge: 0,
    discountAmount: 0,
    grandTotal: 1090,
    paymentMethod: 'bkash',
    paymentStatus: 'paid',
    transactionId: 'BK982M71QA',
    orderStatus: 'dispatched',
    notes: 'বিকাশ পেমেন্ট সম্পন্ন',
    createdAt: '2026-10-23T09:45:00+06:00'
  }
];
