import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const requireModule = createRequire(import.meta.url);

export interface VpsDbMetrics {
  engine: 'SQLite3 (WAL Mode) + Node.js RAM Cache';
  sqliteAvailable: boolean;
  walMode: boolean;
  dbFilePath: string;
  dbFileSizeKb: number;
  postgresConfigured: boolean;
  lastSavedAt: string;
}

let sqliteDb: any = null;
let sqliteDbPath = '';
let isWalEnabled = false;
let lastSavedIso = new Date().toISOString();

/**
 * Initializes the embedded High-Speed SQLite (WAL Mode) database inside /data/stockmaster_vps.sqlite.
 * Automatically migrates any existing state from erp_persistent_state.json on first boot.
 */
export function initVpsSqliteEngine(dataDir: string): boolean {
  try {
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    sqliteDbPath = path.join(dataDir, 'stockmaster_vps.sqlite');

    // Use Node 22 built-in native C++ SQLite engine (zero node-gyp build issues on Coolify/VPS)
    const { DatabaseSync } = requireModule('node:sqlite');
    sqliteDb = new DatabaseSync(sqliteDbPath);

    // High-concurrency, ultra-low-latency WAL configuration for eCommerce & ERP workloads
    sqliteDb.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = NORMAL;
      PRAGMA temp_store = MEMORY;
      PRAGMA cache_size = -64000;
      PRAGMA foreign_keys = ON;
      PRAGMA busy_timeout = 5000;
    `);

    isWalEnabled = true;

    // Core state & entity tables
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS erp_kv_store (
        collection_key TEXT PRIMARY KEY,
        json_payload TEXT NOT NULL,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS erp_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        snapshot_tag TEXT NOT NULL,
        full_state_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `);

    return true;
  } catch (err) {
    console.warn('[StockMaster VPS DB] SQLite initialization fallback to disk JSON:', err);
    sqliteDb = null;
    isWalEnabled = false;
    return false;
  }
}

/**
 * Loads the full ERP state from SQLite WAL store if populated; returns null if empty so JSON seed/migration can run.
 */
export function loadStateFromSqlite(): Record<string, any> | null {
  if (!sqliteDb) return null;
  try {
    const stmt = sqliteDb.prepare('SELECT collection_key, json_payload FROM erp_kv_store');
    const rows = stmt.all() as Array<{ collection_key: string; json_payload: string }>;
    if (!rows || rows.length === 0) {
      return null;
    }

    const state: Record<string, any> = {};
    for (const row of rows) {
      if (!row || !row.collection_key) continue;
      try {
        state[row.collection_key] = JSON.parse(row.json_payload);
      } catch {
        // Ignore malformed collection entry
      }
    }

    return Object.keys(state).length > 0 ? state : null;
  } catch (err) {
    console.error('[StockMaster VPS DB] Failed to load state from SQLite:', err);
    return null;
  }
}

/**
 * Atomically persists all ERP collections into SQLite (WAL Mode) inside a single fast transaction.
 */
export function saveStateToSqlite(stateObj: Record<string, any>): boolean {
  if (!sqliteDb || !stateObj || typeof stateObj !== 'object') return false;
  try {
    const nowTs = Date.now();
    const upsertStmt = sqliteDb.prepare(`
      INSERT INTO erp_kv_store (collection_key, json_payload, updated_at)
      VALUES (?, ?, ?)
      ON CONFLICT(collection_key) DO UPDATE SET
        json_payload = excluded.json_payload,
        updated_at = excluded.updated_at
    `);

    sqliteDb.exec('BEGIN IMMEDIATE TRANSACTION');
    try {
      for (const [key, value] of Object.entries(stateObj)) {
        if (value === undefined) continue;
        upsertStmt.run(key, JSON.stringify(value), nowTs);
      }
      sqliteDb.exec('COMMIT');
      lastSavedIso = new Date(nowTs).toISOString();
      return true;
    } catch (txErr) {
      try {
        sqliteDb.exec('ROLLBACK');
      } catch {
        // ignore rollback error
      }
      throw txErr;
    }
  } catch (err) {
    console.error('[StockMaster VPS DB] Failed to save state to SQLite:', err);
    return false;
  }
}

/**
 * Creates a clean, consistent binary backup of the SQLite database file (checkpointing WAL first).
 */
export function getSqliteDatabaseBuffer(): Buffer | null {
  if (!sqliteDb || !sqliteDbPath || !fs.existsSync(sqliteDbPath)) return null;
  try {
    sqliteDb.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    return fs.readFileSync(sqliteDbPath);
  } catch {
    try {
      return fs.readFileSync(sqliteDbPath);
    } catch {
      return null;
    }
  }
}

export function getVpsDatabaseMetrics(): VpsDbMetrics {
  let sizeKb = 0;
  try {
    if (sqliteDbPath && fs.existsSync(sqliteDbPath)) {
      const stat = fs.statSync(sqliteDbPath);
      sizeKb = Math.max(1, Math.round(stat.size / 1024));
    }
  } catch {
    sizeKb = 0;
  }

  return {
    engine: 'SQLite3 (WAL Mode) + Node.js RAM Cache',
    sqliteAvailable: Boolean(sqliteDb),
    walMode: isWalEnabled,
    dbFilePath: sqliteDbPath || 'data/stockmaster_vps.sqlite',
    dbFileSizeKb: sizeKb,
    postgresConfigured: Boolean(process.env.DATABASE_URL && process.env.DATABASE_URL.trim() !== ''),
    lastSavedAt: lastSavedIso
  };
}
