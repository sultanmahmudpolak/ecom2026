import React, { useState, useEffect, useMemo } from 'react';
import {
  Business,
  DeliverySlipLayoutStyle,
  InvoiceAccentTheme,
  InvoiceCustomizationConfig,
  InvoiceLayoutStyle,
  InvoicePaperSize,
  OnlineOrder,
  Product,
  SaleItem,
  SlipPaperSize,
  UserRole
} from '../types';
import {
  Printer,
  Download,
  FileText,
  Truck,
  Settings2,
  X,
  CheckCircle2,
  RotateCcw,
  Save,
  Image as ImageIcon,
  Eye,
  Sparkles,
  Phone,
  MapPin,
  LayoutTemplate,
  Palette,
  Tag,
  Globe,
  Maximize2,
  Layers,
  Lock
} from 'lucide-react';

interface SmartInvoiceSlipModalProps {
  order: OnlineOrder | null;
  bulkOrders?: OnlineOrder[];
  initialMode?: 'invoice' | 'slip' | 'customize';
  userRole?: UserRole;
  business: Business;
  products?: Product[];
  onUpdateBusiness: (updates: Partial<Business>) => void;
  onUpdateOrder?: (orderId: string, updates: Partial<OnlineOrder>) => void;
  onClose: () => void;
  formatCurrency: (amount: number) => string;
  formatDate: (dateStr: string) => string;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

interface AccentPalette {
  id: InvoiceAccentTheme;
  nameBn: string;
  shortBn: string;
  primary: string;
  primaryDark: string;
  primarySoft: string;
  primaryBorder: string;
  badgeBg: string;
  badgeText: string;
}

export const INVOICE_ACCENT_PALETTES: Record<InvoiceAccentTheme, AccentPalette> = {
  cool_blue: {
    id: 'cool_blue',
    nameBn: 'কুল ব্লু (Cool Blue - স্ট্যান্ডার্ড)',
    shortBn: 'কুল ব্লু',
    primary: '#1d4ed8',
    primaryDark: '#0f172a',
    primarySoft: '#eff6ff',
    primaryBorder: '#bfdbfe',
    badgeBg: '#dbeafe',
    badgeText: '#1e40af'
  },
  classic_bw: {
    id: 'classic_bw',
    nameBn: 'ক্লাসিক সাদাকালো (B&W প্রিন্টার ফ্রেন্ডলি)',
    shortBn: 'সাদাকালো',
    primary: '#0f172a',
    primaryDark: '#000000',
    primarySoft: '#f8fafc',
    primaryBorder: '#94a3b8',
    badgeBg: '#f1f5f9',
    badgeText: '#0f172a'
  },
  emerald: {
    id: 'emerald',
    nameBn: 'এমেরাল্ড কর্পোরেট (Emerald Green)',
    shortBn: 'এমেরাল্ড',
    primary: '#047857',
    primaryDark: '#064e3b',
    primarySoft: '#ecfdf5',
    primaryBorder: '#a7f3d0',
    badgeBg: '#d1fae5',
    badgeText: '#065f46'
  },
  slate: {
    id: 'slate',
    nameBn: 'রয়্যাল স্লেট (Executive Slate)',
    shortBn: 'স্লেট',
    primary: '#334155',
    primaryDark: '#0f172a',
    primarySoft: '#f8fafc',
    primaryBorder: '#cbd5e1',
    badgeBg: '#e2e8f0',
    badgeText: '#1e293b'
  },
  royal_crimson: {
    id: 'royal_crimson',
    nameBn: 'রয়্যাল ক্রিমসন (Royal Crimson)',
    shortBn: 'ক্রিমসন',
    primary: '#be123c',
    primaryDark: '#4c0519',
    primarySoft: '#fff1f2',
    primaryBorder: '#fecdd3',
    badgeBg: '#ffe4e6',
    badgeText: '#9f1239'
  },
  midnight_gold: {
    id: 'midnight_gold',
    nameBn: 'মিডনাইট নেভি (Midnight Navy)',
    shortBn: 'মিডনাইট',
    primary: '#1e3a8a',
    primaryDark: '#0f172a',
    primarySoft: '#f0f9ff',
    primaryBorder: '#bae6fd',
    badgeBg: '#e0f2fe',
    badgeText: '#1e3a8a'
  }
};

export const INVOICE_LAYOUT_STYLES: {
  id: InvoiceLayoutStyle;
  nameBn: string;
  shortBn: string;
  descBn: string;
}[] = [
  {
    id: 'executive_standard',
    nameBn: 'স্টাইল ১: এক্সিকিউটিভ স্ট্যান্ডার্ড (Executive A4)',
    shortBn: '১. এক্সিকিউটিভ স্ট্যান্ডার্ড',
    descBn: 'বাম পাশে ওয়েবসাইট লোগো, ২-কলাম বক্স ও স্ট্যান্ডার্ড কর্পোরেট টেবিল'
  },
  {
    id: 'modern_banner_header',
    nameBn: 'স্টাইল ২: মডার্ন ব্যানার হেডার (Modern Brand Banner)',
    shortBn: '২. মডার্ন ব্যানার',
    descBn: 'উপরে ফুল-উইডথ ব্র্যান্ড হেডার ব্যানার ও হাইলাইটেড সামারি কার্ড'
  },
  {
    id: 'minimal_classic_grid',
    nameBn: 'স্টাইল ৩: মিনিমাল ক্লাসিক বক্স গ্রিড (Aarong / Daraz Boxed)',
    shortBn: '৩. ক্লাসিক বক্স গ্রিড',
    descBn: 'চারপাশে স্পষ্ট বর্ডার ও ফুল-গ্রিড ছক — যেকোনো প্রিন্টারে ১০০% শার্প'
  },
  {
    id: 'compact_pos_memo',
    nameBn: 'স্টাইল ৪: স্মার্ট ক্যাশ মেমো (Centered Cash Memo / A5)',
    shortBn: '৪. স্মার্ট ক্যাশ মেমো',
    descBn: 'মাঝখানে বড় লোগো ও কম্প্যাক্ট ক্যাশ মেমো ডিজাইন (কম কাগজে প্রিন্ট)'
  },
  {
    id: 'luxury_boutique',
    nameBn: 'স্টাইল ৫: প্রিমিয়াম ফ্যাশন বুটিক (Luxury Fashion Frame)',
    shortBn: '৫. ফ্যাশন বুটিক ফ্রেম',
    descBn: 'ডাবল-বর্ডার রয়েল ফ্রেম ও প্রিমিয়াম ফ্যাশন ব্র্যান্ড স্টাইল'
  },
  {
    id: 'thermal_pos_receipt',
    nameBn: 'স্টাইল ৬: থার্মাল প্রিন্ট রিসিট ইনভয়েস (Thermal POS Print)',
    shortBn: '৬. থার্মাল প্রিন্ট',
    descBn: 'থার্মাল প্রিন্টার ও কালি-সাশ্রয়ী সাদাকালো ড্যাশড রিসিট ইনভয়েস ডিজাইন'
  }
];

export const DELIVERY_SLIP_STYLES: {
  id: DeliverySlipLayoutStyle;
  nameBn: string;
  shortBn: string;
  descBn: string;
}[] = [
  {
    id: 'courier_standard_box',
    nameBn: 'স্লিপ ১: স্ট্যান্ডার্ড কুরিয়ার বক্স (Steadfast / Pathao)',
    shortBn: '১. স্ট্যান্ডার্ড কুরিয়ার',
    descBn: 'ওপরে লোগো, বারকোড, প্রাপকের বক্স ও ডার্ক COD কালেকশন ব্যানার'
  },
  {
    id: 'bold_cod_split',
    nameBn: 'স্লিপ ২: বোল্ড স্প্লিট লেবেল (Rider 2-Column Focus)',
    shortBn: '২. বোল্ড স্প্লিট COD',
    descBn: 'বাম পাশে প্রাপকের ঠিকানা এবং ডান পাশে বড় অক্ষরে COD বিল ও বারকোড'
  },
  {
    id: 'thermal_pos_80mm',
    nameBn: 'স্লিপ ৩: থার্মাল ইনক-সেভার লেবেল (Thermal / B&W)',
    shortBn: '৩. থার্মাল পস স্লিপ',
    descBn: 'কালি সাশ্রয়ী সাদাকালো ড্যাশড বর্ডার — থার্মাল ও লেজার প্রিন্টারের জন্য সেরা'
  },
  {
    id: 'modern_fashion_tag',
    nameBn: 'স্লিপ ৪: স্মার্ট ফ্যাশন পার্সেল ট্যাগ (Brand Header Tag)',
    shortBn: '৪. ফ্যাশন পার্সেল কার্ড',
    descBn: 'রঙিন ব্র্যান্ড হেডার ব্যান্ড ও ভ্যারিয়েশন ব্যাজসহ প্রিমিয়াম পার্সেল কার্ড'
  }
];

export const INVOICE_PAPER_SIZES: {
  id: InvoicePaperSize;
  labelBn: string;
  shortBn: string;
  widthPt: number;
  maxWidthCss: string;
  pageCssSize: string;
}[] = [
  {
    id: 'a4_standard',
    labelBn: 'A4 স্ট্যান্ডার্ড পেপার (210 × 297 mm)',
    shortBn: 'A4 Standard',
    widthPt: 595.28,
    maxWidthCss: '196mm',
    pageCssSize: 'A4 portrait'
  },
  {
    id: 'a5_half',
    labelBn: 'A5 হাফ-পেজ মেমো (148 × 210 mm)',
    shortBn: 'A5 Half-Page',
    widthPt: 419.53,
    maxWidthCss: '138mm',
    pageCssSize: 'A5 portrait'
  },
  {
    id: 'pos_80mm',
    labelBn: 'POS থার্মাল ৮০ মিমি রোল (80mm Roll)',
    shortBn: '80mm POS Roll',
    widthPt: 226.77,
    maxWidthCss: '76mm',
    pageCssSize: '80mm auto'
  }
];

export const SLIP_PAPER_SIZES: {
  id: SlipPaperSize;
  labelBn: string;
  shortBn: string;
  widthPt: number;
  maxWidthCss: string;
  pageCssSize: string;
}[] = [
  {
    id: 'sticker_4x6',
    labelBn: '4×6 ইঞ্চি বারকোড স্টিকার (100 × 150 mm — কুরিয়ার স্ট্যান্ডার্ড)',
    shortBn: '4×6" Sticker (100×150mm)',
    widthPt: 288,
    maxWidthCss: '98mm',
    pageCssSize: '100mm 150mm'
  },
  {
    id: 'sticker_3x4',
    labelBn: '3×4 ইঞ্চি মিডিয়াম স্টিকার (75 × 100 mm — স্টিকার প্রিন্টার)',
    shortBn: '3×4" Sticker (75×100mm)',
    widthPt: 216,
    maxWidthCss: '73mm',
    pageCssSize: '75mm 100mm'
  },
  {
    id: 'thermal_80mm',
    labelBn: '80mm (3 ইঞ্চি) থার্মাল পস রোল স্টিকার',
    shortBn: '80mm Thermal Roll',
    widthPt: 226.77,
    maxWidthCss: '76mm',
    pageCssSize: '80mm auto'
  },
  {
    id: 'a5_sheet',
    labelBn: 'A5 / হাফ-A4 রেগুলার পেপার (148 × 210 mm)',
    shortBn: 'A5 Regular Paper',
    widthPt: 419.53,
    maxWidthCss: '136mm',
    pageCssSize: 'A5 portrait'
  }
];

const getCleanDefaultDomain = (): string => {
  if (typeof window === 'undefined') return 'www.smartlook.com.bd';
  const host = (window.location.hostname || '').toLowerCase();
  if (
    !host ||
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host.endsWith('.run.app') ||
    host.includes('aistudio')
  ) {
    return 'www.smartlook.com.bd';
  }
  return window.location.host;
};

export const getDefaultInvoiceConfig = (business: Business): Required<InvoiceCustomizationConfig> => ({
  invoiceStyle: 'executive_standard',
  deliverySlipStyle: 'courier_standard_box',
  invoicePaperSize: 'a4_standard',
  slipPaperSize: 'sticker_4x6',
  accentTheme: 'cool_blue',
  showLogo: true,
  logoHeightPx: 50,
  brandNameOverride: business.name || 'Smart Look',
  brandTagline: 'SMART FASHION STORE',
  storePhoneOverride: business.callOrderPhone || business.whatsappOrderPhone || business.phone || '',
  storeAddressOverride: business.address || '',
  storeWebsiteText: getCleanDefaultDomain(),
  showDomainOnInvoice: true,
  invoiceTitleText: 'INVOICE / ক্যাশ মেমো',
  deliverySlipTitleText: 'ডেলিভারি স্লিপ / DELIVERY SLIP',
  billToLabelText: 'গ্রাহকের তথ্য ও ডেলিভারি ঠিকানা (Bill & Ship To)',
  orderInfoLabelText: 'অর্ডার ও ইনভয়েস তথ্য (Order Details)',
  itemColumnLabel: 'পণ্যের বিবরণ (Item Description)',
  qtyColumnLabel: 'পরিমাণ (Qty)',
  priceColumnLabel: 'একক দর (Rate)',
  totalColumnLabel: 'মোট মূল্য (Total)',
  subtotalLabelText: 'উপ-মোট (Subtotal)',
  deliveryLabelText: 'ডেলিভারি চার্জ (Delivery Fee)',
  discountLabelText: 'স্পেশাল ডিসকাউন্ট / ছাড় (Discount)',
  grandTotalLabelText: 'সর্বমোট পরিশোধযোগ্য বিল (Total Payable)',
  codNoticeBannerText: 'ক্যাশ অন ডেলিভারি (Cash on Delivery) — পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধ করুন।',
  thankYouText: 'আমাদের স্টোর থেকে কেনাকাটার জন্য আপনাকে অসংখ্য ধন্যবাদ!',
  termsAndPolicyText:
    'ডেলিভারি ম্যান থাকা অবস্থায় অনুগ্রহ করে পণ্য চেক করে বুঝে নিন। কোনো সমস্যা থাকলে সাথে সাথে আমাদের হটলাইন নাম্বারে যোগাযোগ করুন।',
  showTermsSection: true,
  showSignatureSection: true,
  customerSignatureLabel: 'গ্রাহকের স্বাক্ষর (Customer Signature)',
  authorizedSignatureLabel: 'কর্তৃপক্ষের স্বাক্ষর (Authorized Signature)',
  showCourierBarcode: true,
  showCourierCnBox: true,
  showProductSku: true,
  showProductImage: true,
  showOrderNoteOnInvoice: true,
  showOrderNoteOnSlip: true,
  slipInstructionText: 'পার্সেলটি সাবধানে হ্যান্ডেল করুন · ডেলিভারির পূর্বে কাস্টমারকে কল করুন'
});

export const resolveInvoiceConfig = (business: Business): Required<InvoiceCustomizationConfig> => {
  const defaults = getDefaultInvoiceConfig(business);
  const saved = business.invoiceConfig || {};
  // Clean out accidental .run.app preview URLs unless admin explicitly saved something else
  let domainText =
    saved.storeWebsiteText !== undefined ? saved.storeWebsiteText : defaults.storeWebsiteText;
  if (domainText && domainText.includes('.run.app')) {
    domainText = 'www.smartlook.com.bd';
  }

  return {
    invoiceStyle: saved.invoiceStyle || defaults.invoiceStyle,
    deliverySlipStyle: saved.deliverySlipStyle || defaults.deliverySlipStyle,
    invoicePaperSize: saved.invoicePaperSize || defaults.invoicePaperSize,
    slipPaperSize: saved.slipPaperSize || defaults.slipPaperSize,
    accentTheme: saved.accentTheme || defaults.accentTheme,
    showLogo: saved.showLogo !== false,
    logoHeightPx: saved.logoHeightPx || defaults.logoHeightPx,
    brandNameOverride:
      saved.brandNameOverride !== undefined && saved.brandNameOverride.trim() !== ''
        ? saved.brandNameOverride
        : defaults.brandNameOverride,
    brandTagline:
      saved.brandTagline !== undefined ? saved.brandTagline : defaults.brandTagline,
    storePhoneOverride:
      saved.storePhoneOverride !== undefined && saved.storePhoneOverride.trim() !== ''
        ? saved.storePhoneOverride
        : defaults.storePhoneOverride,
    storeAddressOverride:
      saved.storeAddressOverride !== undefined && saved.storeAddressOverride.trim() !== ''
        ? saved.storeAddressOverride
        : defaults.storeAddressOverride,
    storeWebsiteText: domainText,
    showDomainOnInvoice: saved.showDomainOnInvoice !== false,
    invoiceTitleText: saved.invoiceTitleText || defaults.invoiceTitleText,
    deliverySlipTitleText: saved.deliverySlipTitleText || defaults.deliverySlipTitleText,
    billToLabelText: saved.billToLabelText || defaults.billToLabelText,
    orderInfoLabelText: saved.orderInfoLabelText || defaults.orderInfoLabelText,
    itemColumnLabel: saved.itemColumnLabel || defaults.itemColumnLabel,
    qtyColumnLabel: saved.qtyColumnLabel || defaults.qtyColumnLabel,
    priceColumnLabel: saved.priceColumnLabel || defaults.priceColumnLabel,
    totalColumnLabel: saved.totalColumnLabel || defaults.totalColumnLabel,
    subtotalLabelText: saved.subtotalLabelText || defaults.subtotalLabelText,
    deliveryLabelText: saved.deliveryLabelText || defaults.deliveryLabelText,
    discountLabelText: saved.discountLabelText || defaults.discountLabelText,
    grandTotalLabelText: saved.grandTotalLabelText || defaults.grandTotalLabelText,
    codNoticeBannerText: saved.codNoticeBannerText || defaults.codNoticeBannerText,
    thankYouText: saved.thankYouText || defaults.thankYouText,
    termsAndPolicyText: saved.termsAndPolicyText || defaults.termsAndPolicyText,
    showTermsSection: saved.showTermsSection !== false,
    showSignatureSection: saved.showSignatureSection !== false,
    customerSignatureLabel: saved.customerSignatureLabel || defaults.customerSignatureLabel,
    authorizedSignatureLabel: saved.authorizedSignatureLabel || defaults.authorizedSignatureLabel,
    showCourierBarcode: saved.showCourierBarcode !== false,
    showCourierCnBox: saved.showCourierCnBox !== false,
    showProductSku: saved.showProductSku !== false,
    showProductImage: saved.showProductImage !== false,
    showOrderNoteOnInvoice: saved.showOrderNoteOnInvoice !== false,
    showOrderNoteOnSlip: saved.showOrderNoteOnSlip !== false,
    slipInstructionText: saved.slipInstructionText || defaults.slipInstructionText
  };
};

const getCleanCustomerNote = (rawNotes?: string): string => {
  if (!rawNotes) return '';
  return rawNotes
    .replace(
      /\[(?:ডাইরেক্ট বাই অর্ডার|Landing Page:|ফ্রি ডেলিভারি অফার:|স্পিন দ্য হুইল পুরস্কার:|স্পিন হুইল অফার:)[^\]]*\]/gi,
      ''
    )
    .split('|')
    .map(part => part.trim())
    .filter(Boolean)
    .join(' | ')
    .trim();
};

// Resolve product image URL for an order item from item.image or products catalog
const resolveOrderItemImageUrl = (item: SaleItem, products?: Product[]): string => {
  if (item.image && item.image.trim()) return item.image.trim();
  if (!products || products.length === 0) return '';
  const cleanName = (item.productNameClean || item.productName || '').trim().toLowerCase();
  const matched = products.find(
    (p) =>
      p.id === item.productId ||
      (item.sku && p.sku && p.sku === item.sku) ||
      (item.parentSku && p.sku && p.sku === item.parentSku) ||
      (cleanName &&
        (p.nameBn.trim().toLowerCase() === cleanName ||
          cleanName.startsWith(p.nameBn.trim().toLowerCase()) ||
          p.nameBn.trim().toLowerCase().includes(cleanName)))
  );
  if (matched) {
    return matched.image || matched.galleryImages?.[0] || '';
  }
  return '';
};

// Generate deterministic 1D barcode bar widths from an order/tracking code string
const generateBarcodePattern = (code: string): number[] => {
  const clean = (code || 'ORD-1001').replace(/[^A-Za-z0-9-]/g, '') || 'ORD1001';
  const bars: number[] = [2, 1, 1, 2, 1, 1];
  for (let i = 0; i < clean.length; i++) {
    const c = clean.charCodeAt(i);
    bars.push(((c >> 0) & 1) + 1);
    bars.push(((c >> 1) & 1) + 1);
    bars.push(((c >> 2) & 2) + 1);
    bars.push(((c >> 3) & 1) + 1);
    bars.push(((c >> 4) & 1) + 1);
    bars.push(1);
  }
  bars.push(2, 1, 2, 1, 1, 2);
  return bars;
};

// Load website logo (SVG / PNG / WebP / DataURL) into an HTMLImageElement safely for Canvas rendering
const loadLogoImageForCanvas = async (logoUrl?: string): Promise<HTMLImageElement | null> => {
  if (!logoUrl || !logoUrl.trim()) return null;
  const trimmed = logoUrl.trim();

  const loadFromSrc = (src: string): Promise<HTMLImageElement | null> =>
    new Promise(resolve => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = src;
    });

  try {
    if (trimmed.startsWith('data:')) {
      return await loadFromSrc(trimmed);
    }
    const resp = await fetch(trimmed, { cache: 'force-cache' });
    if (resp.ok) {
      const contentType = resp.headers.get('content-type') || '';
      if (contentType.includes('svg') || trimmed.toLowerCase().includes('.svg')) {
        const svgText = await resp.text();
        const encoded = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgText)}`;
        return await loadFromSrc(encoded);
      }
      const blob = await resp.blob();
      const dataUrl = await new Promise<string | null>(resolve => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(typeof reader.result === 'string' ? reader.result : null);
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
      });
      if (dataUrl) {
        return await loadFromSrc(dataUrl);
      }
    }
  } catch {
    // Fallback to direct image load
  }

  return await loadFromSrc(trimmed);
};

const wrapCanvasText = (
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] => {
  if (!text) return ['—'];
  const paragraphs = String(text).split(/\r?\n/);
  const lines: string[] = [];

  for (const para of paragraphs) {
    const words = para.trim().split(/\s+/);
    if (words.length === 0) continue;
    let currentLine = words[0];

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const testLine = `${currentLine} ${word}`;
      if (ctx.measureText(testLine).width <= maxWidth) {
        currentLine = testLine;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);
  }

  return lines.length > 0 ? lines : ['—'];
};

const drawRoundedRect = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) => {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
};

const drawBarcodeOnCanvas = (
  ctx: CanvasRenderingContext2D,
  code: string,
  x: number,
  y: number,
  width: number,
  height: number
) => {
  const pattern = generateBarcodePattern(code);
  const totalUnits = pattern.reduce((acc, v) => acc + v, 0);
  const unitPx = width / totalUnits;
  let curX = x;
  for (let i = 0; i < pattern.length; i++) {
    const barW = pattern[i] * unitPx;
    if (i % 2 === 0) {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(curX, y, Math.max(1, barW), height);
    }
    curX += barW;
  }
};

interface CompressedPdfPageImage {
  width: number;
  height: number;
  jpegBytes: Uint8Array;
}

/**
 * Compresses a single rendered HTMLCanvasElement into JPEG bytes and immediately
 * zeroes out the canvas dimensions (canvas.width = 0; canvas.height = 0) to release
 * ~19.7 MB of raw RGBA pixel memory per page from browser RAM/GPU backing store.
 */
const compressAndReleaseCanvasForPdf = (
  canvas: HTMLCanvasElement,
  quality = 0.94
): CompressedPdfPageImage => {
  const width = Math.max(1, canvas.width);
  const height = Math.max(1, canvas.height);
  const jpegDataUrl = canvas.toDataURL('image/jpeg', quality);

  // Immediately release raw RGBA backing store from browser RAM before decoding base64
  try {
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, width, height);
    }
    canvas.width = 0;
    canvas.height = 0;
  } catch {
    // Ignore canvas cleanup errors
  }

  const base64 = jpegDataUrl.split(',')[1] || '';
  const binaryStr = window.atob(base64);
  const jpegBytes = new Uint8Array(binaryStr.length);
  for (let j = 0; j < binaryStr.length; j++) {
    jpegBytes[j] = binaryStr.charCodeAt(j);
  }

  return { width, height, jpegBytes };
};

// Pure TypeScript Multi-Page PDF-1.4 Binary Builder with Zero-RAM-Bloat Canvas Recycling (Supports 100+ Bulk Pages)
const buildMultiPagePdfBlobFromCanvases = (
  pagesInput: Array<HTMLCanvasElement | CompressedPdfPageImage>,
  pageWidthPt: number
): Blob => {
  const encoder = new TextEncoder();
  const chunks: Uint8Array[] = [];
  const offsets: number[] = [0];
  let byteLength = 0;

  const pushStr = (str: string) => {
    const arr = encoder.encode(str);
    chunks.push(arr);
    byteLength += arr.byteLength;
  };

  const pushBytes = (arr: Uint8Array) => {
    chunks.push(arr);
    byteLength += arr.byteLength;
  };

  const startObj = (id: number) => {
    offsets[id] = byteLength;
    pushStr(`${id} 0 obj\n`);
  };

  const endObj = () => {
    pushStr(`\nendobj\n`);
  };

  pushStr(`%PDF-1.4\n%\xFF\xFF\xFF\xFF\n`);

  // Object 1: Catalog
  startObj(1);
  pushStr(`<< /Type /Catalog /Pages 2 0 R >>`);
  endObj();

  const pageCount = pagesInput.length;
  // Each page i (0..pageCount-1) uses 3 objects:
  // pageObjId = 3 + i * 3
  // imgObjId  = 4 + i * 3
  // contentId = 5 + i * 3
  const kidsRefs = pagesInput.map((_, i) => `${3 + i * 3} 0 R`).join(' ');

  // Object 2: Pages
  startObj(2);
  pushStr(`<< /Type /Pages /Kids [${kidsRefs}] /Count ${pageCount} >>`);
  endObj();

  pagesInput.forEach((pageItem, i) => {
    const pageObjId = 3 + i * 3;
    const imgObjId = 4 + i * 3;
    const contentObjId = 5 + i * 3;

    const compressed: CompressedPdfPageImage =
      'jpegBytes' in pageItem ? pageItem : compressAndReleaseCanvasForPdf(pageItem, 0.94);

    const pageHeightPt = (compressed.height / Math.max(1, compressed.width)) * pageWidthPt;
    const imgBytes = compressed.jpegBytes;

    // Page Object
    startObj(pageObjId);
    pushStr(
      `<< /Type /Page /Parent 2 0 R /Resources << /XObject << /Im${i} ${imgObjId} 0 R >> >> /MediaBox [0 0 ${pageWidthPt.toFixed(
        2
      )} ${pageHeightPt.toFixed(2)}] /Contents ${contentObjId} 0 R >>`
    );
    endObj();

    // Image XObject
    startObj(imgObjId);
    pushStr(
      `<< /Type /XObject /Subtype /Image /Width ${compressed.width} /Height ${compressed.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${imgBytes.byteLength} >>\nstream\n`
    );
    pushBytes(imgBytes);
    pushStr(`\nendstream`);
    endObj();

    // Content Stream
    const contentStream = `q\n${pageWidthPt.toFixed(2)} 0 0 ${pageHeightPt.toFixed(
      2
    )} 0 0 cm\n/Im${i} Do\nQ\n`;
    const contentBytes = encoder.encode(contentStream);
    startObj(contentObjId);
    pushStr(`<< /Length ${contentBytes.byteLength} >>\nstream\n`);
    pushBytes(contentBytes);
    pushStr(`endstream`);
    endObj();
  });

  const totalObjects = 2 + pageCount * 3;
  const xrefOffset = byteLength;
  pushStr(`xref\n0 ${totalObjects + 1}\n0000000000 65535 f \n`);
  for (let id = 1; id <= totalObjects; id++) {
    const off = String(offsets[id] || 0).padStart(10, '0');
    pushStr(`${off} 00000 n \n`);
  }
  pushStr(
    `trailer\n<< /Size ${totalObjects + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`
  );

  return new Blob(chunks as BlobPart[], { type: 'application/pdf' });
};

const drawProductThumbnailOnCanvas = (
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | null | undefined,
  x: number,
  y: number,
  size: number,
  isThermal = false
) => {
  ctx.save();
  ctx.fillStyle = '#f8fafc';
  ctx.strokeStyle = isThermal ? '#0f172a' : '#cbd5e1';
  ctx.lineWidth = isThermal ? 1.2 : 1;
  drawRoundedRect(ctx, x, y, size, size, 6);
  ctx.fill();
  ctx.stroke();

  if (img && img.naturalWidth > 0 && img.naturalHeight > 0) {
    ctx.save();
    drawRoundedRect(ctx, x + 1, y + 1, size - 2, size - 2, 5);
    ctx.clip();
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;
    const fitScale = Math.max((size - 2) / iw, (size - 2) / ih);
    const dw = iw * fitScale;
    const dh = ih * fitScale;
    const dx = x + 1 + (size - 2 - dw) / 2;
    const dy = y + 1 + (size - 2 - dh) / 2;
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.restore();
  } else {
    ctx.fillStyle = '#94a3b8';
    ctx.font = `700 ${Math.round(size * 0.42)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText('🛍️', x + size / 2, y + size * 0.66);
  }
  ctx.restore();
};

// High-DPI 300-DPI Canvas Renderer supporting all 6 Invoice Styles & 4 Delivery Slip Styles
const renderOrderDocumentToCanvas = async (
  order: OnlineOrder,
  business: Business,
  cfg: Required<InvoiceCustomizationConfig>,
  mode: 'invoice' | 'slip',
  formatCurrency: (n: number) => string,
  formatDate: (d: string) => string,
  preloadedLogo?: HTMLImageElement | null,
  products?: Product[]
): Promise<HTMLCanvasElement> => {
  if (typeof document !== 'undefined' && (document as any).fonts?.ready) {
    try {
      await (document as any).fonts.ready;
    } catch {
      // ignore font wait errors
    }
  }

  const palette = INVOICE_ACCENT_PALETTES[cfg.accentTheme] || INVOICE_ACCENT_PALETTES.cool_blue;
  const logoImg =
    preloadedLogo !== undefined
      ? preloadedLogo
      : cfg.showLogo
        ? await loadLogoImageForCanvas(business.logoUrl)
        : null;

  // Preload item product images if showProductImage is enabled
  const itemImages: (HTMLImageElement | null)[] = cfg.showProductImage
    ? await Promise.all(
        order.items.map((it) => {
          const url = resolveOrderItemImageUrl(it, products);
          return url ? loadLogoImageForCanvas(url) : Promise.resolve(null);
        })
      )
    : [];

  const fontSans = `'Noto Sans Bengali', 'Plus Jakarta Sans', 'Hind Siliguri', sans-serif`;
  const fontMono = `'JetBrains Mono', 'Plus Jakarta Sans', monospace`;
  const scale = 2.35;

  const hasCourierNo = Boolean(
    (order.courierConsignmentId && order.courierConsignmentId.trim()) ||
      (order.courierTrackingCode && order.courierTrackingCode.trim())
  );
  const courierNoStr = (order.courierConsignmentId || order.courierTrackingCode || '').trim();
  const courierProviderName =
    order.courierProvider === 'pathao'
      ? 'Pathao'
      : order.courierProvider === 'steadfast'
        ? 'Steadfast'
        : 'Courier';

  const domainToShow =
    cfg.showDomainOnInvoice && cfg.storeWebsiteText && cfg.storeWebsiteText.trim()
      ? cfg.storeWebsiteText.trim()
      : '';

  const cleanCustomerNote = getCleanCustomerNote(order.notes);

  // =========================================================================
  // DELIVERY SLIP RENDERER (4 STYLES + PRODUCT IMAGE + BLANK COURIER BOX)
  // =========================================================================
  if (mode === 'slip') {
    const slipStyle = cfg.deliverySlipStyle || 'courier_standard_box';
    const showNoteOnSlip = Boolean(cfg.showOrderNoteOnSlip !== false && cleanCustomerNote);
    const baseW = 640;
    const itemRowExtra = cfg.showProductImage ? 48 : 42;
    const baseH = Math.max(860, 660 + order.items.length * itemRowExtra + (showNoteOnSlip ? 70 : 0));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(baseW * scale);
    canvas.height = Math.round(baseH * scale);
    const ctx = canvas.getContext('2d')!;
    ctx.scale(scale, scale);

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, baseW, baseH);

    if (slipStyle === 'thermal_pos_80mm') {
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 5]);
      drawRoundedRect(ctx, 18, 18, baseW - 36, baseH - 36, 8);
      ctx.stroke();
      ctx.setLineDash([]);
    } else if (slipStyle === 'modern_fashion_tag') {
      ctx.strokeStyle = palette.primary;
      ctx.lineWidth = 2.5;
      drawRoundedRect(ctx, 18, 18, baseW - 36, baseH - 36, 16);
      ctx.stroke();
      ctx.fillStyle = palette.primarySoft;
      drawRoundedRect(ctx, 20, 20, baseW - 40, 82, 14);
      ctx.fill();
    } else {
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.5;
      drawRoundedRect(ctx, 18, 18, baseW - 36, baseH - 36, 14);
      ctx.stroke();
    }

    let y = 34;

    if (slipStyle === 'thermal_pos_80mm') {
      if (logoImg && logoImg.naturalWidth > 0) {
        const targetH = Math.min(48, Math.max(34, cfg.logoHeightPx));
        const aspect = logoImg.naturalWidth / Math.max(1, logoImg.naturalHeight);
        const targetW = Math.min(200, targetH * aspect);
        ctx.drawImage(logoImg, (baseW - targetW) / 2, y, targetW, targetH);
        y += targetH + 8;
      }
      ctx.textAlign = 'center';
      ctx.fillStyle = '#0f172a';
      ctx.font = `800 18px ${fontSans}`;
      ctx.fillText(cfg.brandNameOverride, baseW / 2, y + 14);
      ctx.font = `700 12px ${fontMono}`;
      ctx.fillText(
        `হটলাইন: ${cfg.storePhoneOverride}${domainToShow ? ` · ${domainToShow}` : ''} · ${formatDate(
          order.createdAt
        )}`,
        baseW / 2,
        y + 32
      );
      y += 44;
    } else {
      let brandLeftX = 36;
      if (logoImg && logoImg.naturalWidth > 0) {
        const targetH = Math.min(54, Math.max(36, cfg.logoHeightPx));
        const aspect = logoImg.naturalWidth / Math.max(1, logoImg.naturalHeight);
        const targetW = Math.min(210, targetH * aspect);
        ctx.drawImage(logoImg, 36, y, targetW, targetH);
        brandLeftX = 36 + targetW + 14;
      }

      ctx.fillStyle = '#0f172a';
      ctx.textAlign = 'left';
      if (!logoImg) {
        ctx.font = `800 20px ${fontSans}`;
        ctx.fillText(cfg.brandNameOverride, 36, y + 24);
        if (cfg.brandTagline) {
          ctx.fillStyle = palette.primary;
          ctx.font = `700 10px ${fontSans}`;
          ctx.fillText(cfg.brandTagline, 36, y + 40);
        }
      } else {
        ctx.font = `800 16px ${fontSans}`;
        ctx.fillText(cfg.brandNameOverride, brandLeftX, y + 20);
        ctx.fillStyle = '#475569';
        ctx.font = `600 12px ${fontSans}`;
        ctx.fillText(`হটলাইন: ${cfg.storePhoneOverride}`, brandLeftX, y + 37);
        if (domainToShow) {
          ctx.fillStyle = palette.primary;
          ctx.font = `600 11px ${fontMono}`;
          ctx.fillText(domainToShow, brandLeftX, y + 52);
        }
      }

      ctx.fillStyle = palette.primary;
      drawRoundedRect(ctx, baseW - 236, y, 200, 34, 8);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `800 12px ${fontSans}`;
      ctx.textAlign = 'center';
      ctx.fillText(cfg.deliverySlipTitleText, baseW - 136, y + 21);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#475569';
      ctx.font = `600 11px ${fontSans}`;
      ctx.fillText(`তারিখ: ${formatDate(order.createdAt)}`, baseW - 36, y + 52);

      y += 68;
    }

    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.5;
    if (slipStyle === 'thermal_pos_80mm') ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(32, y);
    ctx.lineTo(baseW - 32, y);
    ctx.stroke();
    ctx.setLineDash([]);

    y += 14;

    // Order ID + Courier Number Box (Auto Number if sent to Courier, or Blank Handwriting Box if not!)
    const showCnBoxOnSlip = cfg.showCourierCnBox !== false;
    const orderBoxH = showCnBoxOnSlip ? 98 : cfg.showCourierBarcode ? 82 : 62;
    ctx.fillStyle = '#f8fafc';
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.2;
    drawRoundedRect(ctx, 34, y, baseW - 68, orderBoxH, 10);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = '#64748b';
    ctx.font = `700 11px ${fontSans}`;
    ctx.fillText('অর্ডার নং (ORDER NO):', 48, y + (showCnBoxOnSlip ? 22 : 24));
    ctx.fillStyle = '#0f172a';
    ctx.font = `800 20px ${fontMono}`;
    ctx.fillText(`#${order.orderNo}`, 48, y + (showCnBoxOnSlip ? 44 : 48));

    if (showCnBoxOnSlip) {
      if (hasCourierNo) {
        // Sent to Courier -> Show bold Courier Provider & Consignment No
        ctx.fillStyle = '#ecfdf5';
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 1.5;
        drawRoundedRect(ctx, 48, y + 54, 305, 32, 6);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#065f46';
        ctx.font = `800 13.5px ${fontMono}`;
        ctx.fillText(`${courierProviderName} CN: ${courierNoStr}`, 58, y + 75);
      } else {
        // Not sent to Courier yet -> Show clean Blank Box for Handwriting Courier Number!
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#475569';
        ctx.lineWidth = 1.5;
        drawRoundedRect(ctx, 48, y + 54, 305, 32, 6);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#334155';
        ctx.font = `700 12px ${fontSans}`;
        ctx.fillText('কুরিয়ার নং (CN):', 56, y + 74);
      }
    }

    if (cfg.showCourierBarcode) {
      const barcodeCode = courierNoStr || order.orderNo;
      const barTopOffset = showCnBoxOnSlip ? 16 : 12;
      const barH = showCnBoxOnSlip ? 44 : 38;
      drawBarcodeOnCanvas(ctx, barcodeCode, baseW - 235, y + barTopOffset, 180, barH);
      ctx.textAlign = 'center';
      ctx.fillStyle = '#334155';
      ctx.font = `700 11px ${fontMono}`;
      ctx.fillText(barcodeCode, baseW - 145, y + (showCnBoxOnSlip ? 78 : 66));
    }

    y += orderBoxH + 14;

    if (slipStyle === 'bold_cod_split') {
      const leftW = 330;
      const rightW = baseW - 68 - leftW - 14;
      const rightX = 34 + leftW + 14;
      const splitH = 175;

      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.8;
      drawRoundedRect(ctx, 34, y, leftW, splitH, 10);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = palette.primarySoft;
      drawRoundedRect(ctx, 35, y + 1, leftW - 2, 32, 9);
      ctx.fill();
      ctx.textAlign = 'left';
      ctx.fillStyle = palette.badgeText;
      ctx.font = `800 12px ${fontSans}`;
      ctx.fillText('প্রাপক (DELIVER TO)', 48, y + 21);

      ctx.fillStyle = '#0f172a';
      ctx.font = `800 18px ${fontSans}`;
      ctx.fillText(order.customerName || 'সম্মানিত গ্রাহক', 48, y + 55);

      ctx.fillStyle = palette.primary;
      ctx.font = `800 16px ${fontMono}`;
      ctx.fillText(
        order.alternativePhone
          ? `📞 ${order.customerPhone} / ${order.alternativePhone}`
          : `📞 ${order.customerPhone}`,
        48,
        y + 80
      );

      ctx.fillStyle = '#334155';
      ctx.font = `700 12px ${fontSans}`;
      ctx.fillText(`এরিয়া: ${order.deliveryArea}`, 48, y + 102);

      ctx.fillStyle = '#1e293b';
      ctx.font = `600 12.5px ${fontSans}`;
      const addrLines = wrapCanvasText(ctx, `ঠিকানা: ${order.deliveryAddress}`, leftW - 28);
      addrLines.slice(0, 3).forEach((ln, idx) => {
        ctx.fillText(ln, 48, y + 124 + idx * 18);
      });

      const isPaid = order.paymentStatus === 'paid';
      ctx.fillStyle = isPaid ? '#ecfdf5' : palette.primary;
      drawRoundedRect(ctx, rightX, y, rightW, splitH, 10);
      ctx.fill();

      ctx.textAlign = 'center';
      ctx.fillStyle = isPaid ? '#065f46' : '#ffffff';
      ctx.font = `800 12px ${fontSans}`;
      ctx.fillText(
        isPaid ? 'পেমেন্ট স্ট্যাটাস' : 'ডেলিভারি ম্যান সংগ্রহ করবেন',
        rightX + rightW / 2,
        y + 42
      );
      ctx.font = `800 28px ${fontMono}`;
      ctx.fillText(
        isPaid ? 'PAID (৳0)' : formatCurrency(order.grandTotal),
        rightX + rightW / 2,
        y + 92
      );
      if ((order.discountAmount || 0) > 0) {
        ctx.font = `700 11.5px ${fontSans}`;
        ctx.fillText(
          `স্পেশাল ছাড়: -${formatCurrency(order.discountAmount)}`,
          rightX + rightW / 2,
          y + 122
        );
      }
      ctx.font = `700 11px ${fontSans}`;
      ctx.fillText(
        isPaid ? 'সম্পূর্ণ পরিশোধিত' : 'CASH ON DELIVERY',
        rightX + rightW / 2,
        y + 150
      );

      y += splitH + 16;
    } else {
      // Receiver Box
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = slipStyle === 'modern_fashion_tag' ? palette.primary : '#0f172a';
      ctx.lineWidth = 1.8;
      drawRoundedRect(ctx, 34, y, baseW - 68, 158, 10);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = slipStyle === 'thermal_pos_80mm' ? '#f1f5f9' : palette.primarySoft;
      drawRoundedRect(ctx, 35, y + 1, baseW - 70, 32, 9);
      ctx.fill();
      ctx.textAlign = 'left';
      ctx.fillStyle = slipStyle === 'thermal_pos_80mm' ? '#0f172a' : palette.badgeText;
      ctx.font = `800 12px ${fontSans}`;
      ctx.fillText(`প্রাপক / ডেলিভারি ঠিকানা (DELIVER TO)`, 48, y + 21);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#0f172a';
      ctx.font = `700 12px ${fontSans}`;
      ctx.fillText(`এরিয়া: ${order.deliveryArea}`, baseW - 48, y + 21);

      ctx.textAlign = 'left';
      ctx.fillStyle = '#0f172a';
      ctx.font = `800 20px ${fontSans}`;
      ctx.fillText(order.customerName || 'সম্মানিত গ্রাহক', 48, y + 58);

      ctx.fillStyle = palette.primary;
      ctx.font = `800 18px ${fontMono}`;
      ctx.fillText(
        order.alternativePhone
          ? `📞 ${order.customerPhone} (বিকল্প: ${order.alternativePhone})`
          : `📞 ${order.customerPhone}`,
        48,
        y + 86
      );

      ctx.fillStyle = '#1e293b';
      ctx.font = `600 14px ${fontSans}`;
      const addrLines = wrapCanvasText(
        ctx,
        `ঠিকানা: ${order.deliveryAddress}, ${order.deliveryArea}`,
        baseW - 100
      );
      addrLines.slice(0, 2).forEach((line, idx) => {
        ctx.fillText(line, 48, y + 112 + idx * 20);
      });

      y += 172;

      // COD Box
      const isPaid = order.paymentStatus === 'paid';
      const codAmount = isPaid ? 0 : order.grandTotal;
      if (slipStyle === 'thermal_pos_80mm') {
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2.5;
        drawRoundedRect(ctx, 34, y, baseW - 68, 66, 8);
        ctx.fill();
        ctx.stroke();

        ctx.textAlign = 'left';
        ctx.fillStyle = '#0f172a';
        ctx.font = `800 13px ${fontSans}`;
        ctx.fillText('ডেলিভারি ম্যান সংগ্রহ করবেন (COD):', 48, y + 27);
        ctx.font = `600 12px ${fontSans}`;
        ctx.fillText(
          (order.discountAmount || 0) > 0
            ? `ক্যাশ অন ডেলিভারি (ছাড়: -${formatCurrency(order.discountAmount)})`
            : isPaid
              ? 'পরিশোধিত (PAID)'
              : 'ক্যাশ অন ডেলিভারি',
          48,
          y + 48
        );

        ctx.textAlign = 'right';
        ctx.font = `800 26px ${fontMono}`;
        ctx.fillText(isPaid ? 'PAID (৳0)' : formatCurrency(codAmount), baseW - 48, y + 43);
      } else {
        ctx.fillStyle = isPaid
          ? '#ecfdf5'
          : slipStyle === 'modern_fashion_tag'
            ? palette.primary
            : '#0f172a';
        drawRoundedRect(ctx, 34, y, baseW - 68, 66, 10);
        ctx.fill();

        ctx.textAlign = 'left';
        ctx.fillStyle = isPaid ? '#065f46' : '#f8fafc';
        ctx.font = `700 13px ${fontSans}`;
        ctx.fillText(
          isPaid
            ? 'পেমেন্ট স্ট্যাটাস (PAYMENT STATUS):'
            : 'ডেলিভারি ম্যান সংগ্রহ করবেন (COD AMOUNT TO COLLECT):',
          48,
          y + 26
        );
        ctx.font = `600 12px ${fontSans}`;
        ctx.fillStyle = isPaid ? '#047857' : '#e2e8f0';
        ctx.fillText(
          (order.discountAmount || 0) > 0
            ? `ক্যাশ অন ডেলিভারি (স্পেশাল ছাড়: -${formatCurrency(order.discountAmount)})`
            : isPaid
              ? 'সম্পূর্ণ পরিশোধিত (PAID)'
              : 'ক্যাশ অন ডেলিভারি (Cash on Delivery)',
          48,
          y + 48
        );

        ctx.textAlign = 'right';
        ctx.fillStyle = isPaid ? '#047857' : '#ffffff';
        ctx.font = `800 26px ${fontMono}`;
        ctx.fillText(isPaid ? 'PAID (৳0)' : formatCurrency(codAmount), baseW - 48, y + 43);
      }

      y += 80;
    }

    // Items Checklist Table
    ctx.fillStyle = '#f1f5f9';
    drawRoundedRect(ctx, 34, y, baseW - 68, 32, 7);
    ctx.fill();

    ctx.fillStyle = '#334155';
    ctx.font = `800 12px ${fontSans}`;
    ctx.textAlign = 'left';
    ctx.fillText(cfg.itemColumnLabel, 46, y + 20);
    ctx.textAlign = 'center';
    ctx.fillText(cfg.qtyColumnLabel, baseW - 145, y + 20);
    ctx.textAlign = 'right';
    ctx.fillText(cfg.totalColumnLabel, baseW - 46, y + 20);

    y += 38;

    let totalQty = 0;
    order.items.forEach((item, idx) => {
      totalQty += Number(item.quantity) || 0;
      const itemLabel = `${idx + 1}. ${item.productName}${
        item.variantLabel ? ` (${item.variantLabel})` : ''
      }`;
      const textStartX = cfg.showProductImage ? 86 : 46;
      const textMaxW = cfg.showProductImage ? baseW - 270 : baseW - 230;

      if (cfg.showProductImage) {
        drawProductThumbnailOnCanvas(
          ctx,
          itemImages[idx],
          44,
          y + 3,
          34,
          slipStyle === 'thermal_pos_80mm'
        );
      }

      ctx.textAlign = 'left';
      ctx.fillStyle = '#0f172a';
      ctx.font = `700 13px ${fontSans}`;
      const wrappedItem = wrapCanvasText(ctx, itemLabel, textMaxW);
      ctx.fillText(wrappedItem[0], textStartX, y + 18);
      if (wrappedItem.length > 1) {
        ctx.font = `600 11px ${fontSans}`;
        ctx.fillStyle = '#475569';
        ctx.fillText(wrappedItem[1], textStartX + 10, y + 33);
      }

      ctx.textAlign = 'center';
      ctx.fillStyle = '#0f172a';
      ctx.font = `800 14px ${fontMono}`;
      ctx.fillText(`${item.quantity}`, baseW - 145, y + 22);

      ctx.textAlign = 'right';
      ctx.font = `700 13px ${fontMono}`;
      ctx.fillText(formatCurrency(item.total), baseW - 46, y + 22);

      y += Math.max(cfg.showProductImage ? 42 : 32, wrappedItem.length > 1 ? 42 : 32);

      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(38, y);
      ctx.lineTo(baseW - 38, y);
      ctx.stroke();
    });

    y += 16;

    ctx.textAlign = 'left';
    ctx.fillStyle = '#334155';
    ctx.font = `700 12px ${fontSans}`;
    ctx.fillText(`মোট পণ্য: ${totalQty} টি · ইনভয়েস: ${order.invoiceNo}`, 42, y + 16);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#475569';
    ctx.font = `600 11.5px ${fontSans}`;
    const delivText =
      order.deliveryCharge === 0 ? 'ফ্রি' : formatCurrency(order.deliveryCharge);
    const discPart =
      (order.discountAmount || 0) > 0 ? ` | ছাড়: -${formatCurrency(order.discountAmount)}` : '';
    ctx.fillText(
      `সাবটোটাল: ${formatCurrency(order.subtotal)} | ডেলিভারি: ${delivText}${discPart} | মোট: ${formatCurrency(
        order.grandTotal
      )}`,
      baseW - 42,
      y + 16
    );

    if (showNoteOnSlip) {
      y += 28;
      ctx.fillStyle = slipStyle === 'thermal_pos_80mm' ? '#ffffff' : '#fffbeb';
      ctx.strokeStyle = slipStyle === 'thermal_pos_80mm' ? '#0f172a' : '#f59e0b';
      ctx.lineWidth = 1.5;
      drawRoundedRect(ctx, 34, y, baseW - 68, 52, 8);
      ctx.fill();
      ctx.stroke();

      ctx.textAlign = 'left';
      ctx.fillStyle = slipStyle === 'thermal_pos_80mm' ? '#0f172a' : '#92400e';
      ctx.font = `800 11.5px ${fontSans}`;
      ctx.fillText('📝 কাস্টমারের অর্ডার নোট (Customer Note):', 46, y + 18);

      ctx.fillStyle = '#0f172a';
      ctx.font = `700 12px ${fontSans}`;
      const noteLines = wrapCanvasText(ctx, cleanCustomerNote, baseW - 96);
      noteLines.slice(0, 2).forEach((ln, idx) => {
        ctx.fillText(ln, 46, y + 36 + idx * 14);
      });
    }

    const footerY = baseH - 76;
    ctx.fillStyle = '#f8fafc';
    ctx.strokeStyle = '#e2e8f0';
    drawRoundedRect(ctx, 34, footerY, baseW - 68, 48, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 11.5px ${fontSans}`;
    ctx.fillText(cfg.slipInstructionText, baseW / 2, footerY + 20);

    ctx.fillStyle = '#64748b';
    ctx.font = `600 11px ${fontSans}`;
    ctx.fillText(
      `প্রেরক: ${cfg.brandNameOverride} · হটলাইন: ${cfg.storePhoneOverride}${
        domainToShow ? ` · ${domainToShow}` : ''
      }`,
      baseW / 2,
      footerY + 38
    );

    return canvas;
  }

  // =========================================================================
  // MODE: SMART INVOICE RENDERER (6 DISTINCT STYLES INCLUDING THERMAL POS)
  // =========================================================================
  const invStyle = cfg.invoiceStyle || 'executive_standard';
  const showNoteOnInv = Boolean(cfg.showOrderNoteOnInvoice !== false && cleanCustomerNote);

  // Dedicated Thermal POS Receipt Invoice Canvas Renderer (Style 6)
  if (invStyle === 'thermal_pos_receipt') {
    const baseW = 520;
    const itemRowH = cfg.showProductImage ? 48 : 38;
    const baseH = Math.max(760, 580 + order.items.length * itemRowH + (showNoteOnInv ? 64 : 0));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(baseW * scale);
    canvas.height = Math.round(baseH * scale);
    const ctx = canvas.getContext('2d')!;
    ctx.scale(scale, scale);

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, baseW, baseH);

    // Outer dashed thermal receipt frame
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;
    ctx.setLineDash([7, 4]);
    drawRoundedRect(ctx, 16, 16, baseW - 32, baseH - 32, 8);
    ctx.stroke();
    ctx.setLineDash([]);

    let y = 32;

    if (logoImg && logoImg.naturalWidth > 0) {
      const targetH = Math.min(48, Math.max(32, cfg.logoHeightPx));
      const aspect = logoImg.naturalWidth / Math.max(1, logoImg.naturalHeight);
      const targetW = Math.min(200, targetH * aspect);
      ctx.drawImage(logoImg, (baseW - targetW) / 2, y, targetW, targetH);
      y += targetH + 8;
    }

    ctx.textAlign = 'center';
    ctx.fillStyle = '#000000';
    ctx.font = `800 20px ${fontSans}`;
    ctx.fillText(cfg.brandNameOverride, baseW / 2, y + 16);
    y += 24;

    if (cfg.storeAddressOverride) {
      ctx.fillStyle = '#334155';
      ctx.font = `600 11.5px ${fontSans}`;
      ctx.fillText(cfg.storeAddressOverride, baseW / 2, y + 10);
      y += 16;
    }

    ctx.fillStyle = '#0f172a';
    ctx.font = `700 12px ${fontMono}`;
    ctx.fillText(
      `হটলাইন: ${cfg.storePhoneOverride}${domainToShow ? ` · ${domainToShow}` : ''}`,
      baseW / 2,
      y + 12
    );
    y += 22;

    // Thermal Title Pill
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.6;
    drawRoundedRect(ctx, baseW / 2 - 95, y, 190, 26, 5);
    ctx.stroke();
    ctx.fillStyle = '#000000';
    ctx.font = `800 11.5px ${fontSans}`;
    ctx.fillText(cfg.invoiceTitleText, baseW / 2, y + 17);
    y += 36;

    // Dashed Divider
    const drawThermalDash = (curY: number) => {
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.moveTo(28, curY);
      ctx.lineTo(baseW - 28, curY);
      ctx.stroke();
      ctx.setLineDash([]);
    };

    drawThermalDash(y);
    y += 16;

    // Order & Invoice Meta
    ctx.textAlign = 'left';
    ctx.fillStyle = '#000000';
    ctx.font = `700 12px ${fontMono}`;
    ctx.fillText(`ইনভয়েস: ${order.invoiceNo}`, 32, y);
    ctx.textAlign = 'right';
    ctx.fillText(`অর্ডার নং: #${order.orderNo}`, baseW - 32, y);
    y += 18;

    ctx.textAlign = 'left';
    ctx.fillStyle = '#334155';
    ctx.font = `600 11.5px ${fontSans}`;
    ctx.fillText(`তারিখ: ${formatDate(order.createdAt)}`, 32, y);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#000000';
    ctx.font = `800 11.5px ${fontSans}`;
    ctx.fillText(
      order.paymentStatus === 'paid' ? 'পেমেন্ট: PAID' : 'পেমেন্ট: COD (ক্যাশ অন ডেলিভারি)',
      baseW - 32,
      y
    );
    y += 12;

    drawThermalDash(y);
    y += 18;

    // Customer & Courier Block
    ctx.textAlign = 'left';
    ctx.fillStyle = '#000000';
    ctx.font = `800 14px ${fontSans}`;
    ctx.fillText(`গ্রাহক: ${order.customerName}`, 32, y);
    y += 20;

    ctx.font = `800 13.5px ${fontMono}`;
    ctx.fillText(
      order.alternativePhone
        ? `মোবাইল: ${order.customerPhone}, ${order.alternativePhone}`
        : `মোবাইল: ${order.customerPhone}`,
      32,
      y
    );
    y += 19;

    ctx.fillStyle = '#1e293b';
    ctx.font = `600 12px ${fontSans}`;
    const addrWrapped = wrapCanvasText(
      ctx,
      `ঠিকানা: ${order.deliveryAddress}, ${order.deliveryArea}`,
      baseW - 64
    );
    addrWrapped.slice(0, 2).forEach((ln) => {
      ctx.fillText(ln, 32, y);
      y += 17;
    });

    if (cfg.showCourierCnBox !== false) {
      y += 4;
      if (hasCourierNo) {
        ctx.fillStyle = '#000000';
        ctx.font = `800 12.5px ${fontMono}`;
        ctx.fillText(`কুরিয়ার (${courierProviderName}) CN: ${courierNoStr}`, 32, y + 10);
        y += 22;
      } else {
        ctx.fillStyle = '#000000';
        ctx.font = `700 12px ${fontSans}`;
        ctx.fillText('কুরিয়ার নং (CN):', 32, y + 14);
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1.2;
        drawRoundedRect(ctx, 134, y - 2, baseW - 166, 22, 4);
        ctx.stroke();
        y += 28;
      }
    }

    drawThermalDash(y);
    y += 16;

    // Items Table Header
    ctx.fillStyle = '#000000';
    ctx.font = `800 11.5px ${fontSans}`;
    ctx.textAlign = 'left';
    ctx.fillText(cfg.itemColumnLabel, 32, y);
    ctx.textAlign = 'center';
    ctx.fillText(cfg.qtyColumnLabel, baseW - 140, y);
    ctx.textAlign = 'right';
    ctx.fillText(cfg.totalColumnLabel, baseW - 32, y);
    y += 10;

    drawThermalDash(y);
    y += 10;

    order.items.forEach((item, idx) => {
      const itemLabel = `${idx + 1}. ${item.productName}${
        item.variantLabel ? ` [${item.variantLabel}]` : ''
      }`;
      const textX = cfg.showProductImage ? 72 : 32;
      const maxTextW = cfg.showProductImage ? baseW - 235 : baseW - 195;

      if (cfg.showProductImage) {
        drawProductThumbnailOnCanvas(ctx, itemImages[idx], 32, y, 32, true);
      }

      ctx.textAlign = 'left';
      ctx.fillStyle = '#000000';
      ctx.font = `700 12.5px ${fontSans}`;
      const lines = wrapCanvasText(ctx, itemLabel, maxTextW);
      ctx.fillText(lines[0], textX, y + 14);
      if (lines.length > 1) {
        ctx.font = `600 11px ${fontSans}`;
        ctx.fillText(lines[1], textX + 8, y + 28);
      }

      ctx.textAlign = 'center';
      ctx.font = `700 12.5px ${fontMono}`;
      ctx.fillText(`${item.quantity}×${item.unitPrice}`, baseW - 140, y + 16);

      ctx.textAlign = 'right';
      ctx.font = `800 13px ${fontMono}`;
      ctx.fillText(formatCurrency(item.total), baseW - 32, y + 16);

      y += Math.max(cfg.showProductImage ? 40 : 30, lines.length > 1 ? 38 : 30);
    });

    drawThermalDash(y);
    y += 18;

    // Totals
    ctx.textAlign = 'left';
    ctx.fillStyle = '#1e293b';
    ctx.font = `600 12px ${fontSans}`;
    ctx.fillText(cfg.subtotalLabelText, 32, y);
    ctx.textAlign = 'right';
    ctx.font = `700 12.5px ${fontMono}`;
    ctx.fillText(formatCurrency(order.subtotal), baseW - 32, y);
    y += 20;

    ctx.textAlign = 'left';
    ctx.font = `600 12px ${fontSans}`;
    ctx.fillText(cfg.deliveryLabelText, 32, y);
    ctx.textAlign = 'right';
    ctx.font = `700 12.5px ${fontMono}`;
    ctx.fillText(
      order.deliveryCharge === 0 ? 'ফ্রি (৳0)' : formatCurrency(order.deliveryCharge),
      baseW - 32,
      y
    );
    y += 20;

    if ((order.discountAmount || 0) > 0) {
      ctx.textAlign = 'left';
      ctx.fillStyle = '#000000';
      ctx.font = `800 12px ${fontSans}`;
      ctx.fillText(cfg.discountLabelText, 32, y);
      ctx.textAlign = 'right';
      ctx.font = `800 12.5px ${fontMono}`;
      ctx.fillText(`- ${formatCurrency(order.discountAmount)}`, baseW - 32, y);
      y += 20;
    }

    // Grand Total Box (Thermal High-Contrast Double Box)
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    drawRoundedRect(ctx, 32, y, baseW - 64, 42, 6);
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = '#000000';
    ctx.font = `800 13px ${fontSans}`;
    ctx.fillText(cfg.grandTotalLabelText, 44, y + 26);

    ctx.textAlign = 'right';
    ctx.font = `800 18px ${fontMono}`;
    ctx.fillText(formatCurrency(order.grandTotal), baseW - 44, y + 27);
    y += 56;

    if (showNoteOnInv) {
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.4;
      drawRoundedRect(ctx, 32, y, baseW - 64, 48, 6);
      ctx.stroke();

      ctx.textAlign = 'left';
      ctx.fillStyle = '#000000';
      ctx.font = `800 11.5px ${fontSans}`;
      ctx.fillText('📝 অর্ডার নোট:', 42, y + 18);

      ctx.font = `600 11.5px ${fontSans}`;
      const noteWrapped = wrapCanvasText(ctx, cleanCustomerNote, baseW - 88);
      ctx.fillText(noteWrapped[0] || '', 42, y + 36);
      y += 58;
    }

    if (cfg.showCourierBarcode) {
      const codeStr = courierNoStr || order.orderNo;
      drawBarcodeOnCanvas(ctx, codeStr, (baseW - 200) / 2, y, 200, 34);
      ctx.textAlign = 'center';
      ctx.fillStyle = '#0f172a';
      ctx.font = `700 11px ${fontMono}`;
      ctx.fillText(`#${codeStr}`, baseW / 2, y + 48);
      y += 60;
    }

    ctx.textAlign = 'center';
    ctx.fillStyle = '#000000';
    ctx.font = `700 12px ${fontSans}`;
    ctx.fillText(cfg.thankYouText, baseW / 2, baseH - 36);

    return canvas;
  }

  const baseW = 794;
  const minH = invStyle === 'compact_pos_memo' ? 920 : 1123;
  const itemRowExtra = cfg.showProductImage ? 54 : 46;
  const dynamicH = Math.max(
    minH,
    760 + order.items.length * itemRowExtra + (showNoteOnInv ? 76 : 0)
  );

  const canvas = document.createElement('canvas');
  canvas.width = Math.round(baseW * scale);
  canvas.height = Math.round(dynamicH * scale);
  const ctx = canvas.getContext('2d')!;
  ctx.scale(scale, scale);

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, baseW, dynamicH);

  const padX = 48;
  let y = 42;

  if (invStyle === 'minimal_classic_grid') {
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;
    ctx.strokeRect(24, 24, baseW - 48, dynamicH - 48);
  } else if (invStyle === 'luxury_boutique') {
    ctx.strokeStyle = palette.primary;
    ctx.lineWidth = 2.5;
    drawRoundedRect(ctx, 20, 20, baseW - 40, dynamicH - 40, 14);
    ctx.stroke();
    ctx.strokeStyle = palette.primaryBorder;
    ctx.lineWidth = 1;
    drawRoundedRect(ctx, 26, 26, baseW - 52, dynamicH - 52, 10);
    ctx.stroke();
  } else if (invStyle === 'modern_banner_header') {
    ctx.fillStyle = palette.primarySoft;
    ctx.fillRect(0, 0, baseW, 168);
    ctx.fillStyle = palette.primary;
    ctx.fillRect(0, 0, baseW, 6);
    ctx.strokeStyle = palette.primaryBorder;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, 168);
    ctx.lineTo(baseW, 168);
    ctx.stroke();
  } else {
    ctx.fillStyle = palette.primary;
    ctx.fillRect(0, 0, baseW, 8);
  }

  // 1. HEADER SECTION
  if (invStyle === 'compact_pos_memo') {
    if (logoImg && logoImg.naturalWidth > 0) {
      const targetH = Math.min(64, Math.max(40, cfg.logoHeightPx));
      const aspect = logoImg.naturalWidth / Math.max(1, logoImg.naturalHeight);
      const targetW = Math.min(260, targetH * aspect);
      ctx.drawImage(logoImg, (baseW - targetW) / 2, y, targetW, targetH);
      y += targetH + 12;
    }
    ctx.textAlign = 'center';
    ctx.fillStyle = '#0f172a';
    ctx.font = `800 22px ${fontSans}`;
    ctx.fillText(cfg.brandNameOverride, baseW / 2, y + 14);
    y += 32;

    ctx.fillStyle = '#475569';
    ctx.font = `600 12px ${fontSans}`;
    ctx.fillText(
      `${cfg.storeAddressOverride ? `${cfg.storeAddressOverride} · ` : ''}হটলাইন: ${
        cfg.storePhoneOverride
      }${domainToShow ? ` · ${domainToShow}` : ''}`,
      baseW / 2,
      y
    );
    y += 22;

    ctx.fillStyle = palette.primary;
    drawRoundedRect(ctx, baseW / 2 - 110, y, 220, 30, 15);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = `800 12px ${fontSans}`;
    ctx.fillText(cfg.invoiceTitleText, baseW / 2, y + 19);
    y += 44;

    ctx.fillStyle = '#0f172a';
    ctx.font = `700 12.5px ${fontMono}`;
    ctx.fillText(
      `ইনভয়েস: ${order.invoiceNo}   |   অর্ডার নং: #${order.orderNo}   |   তারিখ: ${formatDate(
        order.createdAt
      )}`,
      baseW / 2,
      y
    );
    y += 18;
  } else {
    let logoBottomY = y;
    if (logoImg && logoImg.naturalWidth > 0) {
      const targetH = Math.min(68, Math.max(36, cfg.logoHeightPx));
      const aspect = logoImg.naturalWidth / Math.max(1, logoImg.naturalHeight);
      const targetW = Math.min(260, targetH * aspect);
      ctx.drawImage(logoImg, padX, y, targetW, targetH);
      logoBottomY = y + targetH + 10;
    } else {
      ctx.textAlign = 'left';
      ctx.fillStyle = '#0f172a';
      ctx.font = `800 28px ${fontSans}`;
      ctx.fillText(cfg.brandNameOverride, padX, y + 28);
      logoBottomY = y + 38;
      if (cfg.brandTagline) {
        ctx.fillStyle = palette.primary;
        ctx.font = `700 11px ${fontSans}`;
        ctx.fillText(cfg.brandTagline, padX, logoBottomY + 6);
        logoBottomY += 16;
      }
    }

    ctx.textAlign = 'left';
    ctx.fillStyle = '#0f172a';
    ctx.font = `800 15px ${fontSans}`;
    ctx.fillText(cfg.brandNameOverride, padX, logoBottomY + 12);

    let leftInfoY = logoBottomY + 30;
    ctx.fillStyle = '#475569';
    ctx.font = `500 12px ${fontSans}`;
    if (cfg.storeAddressOverride) {
      ctx.fillText(cfg.storeAddressOverride, padX, leftInfoY);
      leftInfoY += 18;
    }
    if (cfg.storePhoneOverride) {
      ctx.fillStyle = '#1e293b';
      ctx.font = `700 12.5px ${fontSans}`;
      ctx.fillText(`হটলাইন: ${cfg.storePhoneOverride}`, padX, leftInfoY);
      leftInfoY += 18;
    }
    if (domainToShow) {
      ctx.fillStyle = palette.primary;
      ctx.font = `700 12px ${fontMono}`;
      ctx.fillText(domainToShow, padX, leftInfoY);
      leftInfoY += 16;
    }

    ctx.textAlign = 'right';
    ctx.fillStyle = palette.primary;
    ctx.font = `800 22px ${fontSans}`;
    ctx.fillText(cfg.invoiceTitleText, baseW - padX, y + 24);

    ctx.fillStyle = '#0f172a';
    ctx.font = `700 13px ${fontMono}`;
    ctx.fillText(`ইনভয়েস নং: ${order.invoiceNo}`, baseW - padX, y + 48);
    ctx.fillStyle = '#334155';
    ctx.font = `700 13px ${fontMono}`;
    ctx.fillText(`অর্ডার নং: #${order.orderNo}`, baseW - padX, y + 68);
    ctx.fillStyle = '#64748b';
    ctx.font = `600 12px ${fontSans}`;
    ctx.fillText(`তারিখ: ${formatDate(order.createdAt)}`, baseW - padX, y + 88);

    const isPaid = order.paymentStatus === 'paid';
    const stampText = isPaid ? 'পরিশোধিত · PAID' : 'ক্যাশ অন ডেলিভারি · COD';
    ctx.font = `800 11px ${fontSans}`;
    const stampW = Math.max(148, ctx.measureText(stampText).width + 26);
    ctx.fillStyle = isPaid ? '#d1fae5' : palette.badgeBg;
    drawRoundedRect(ctx, baseW - padX - stampW, y + 98, stampW, 26, 6);
    ctx.fill();
    ctx.fillStyle = isPaid ? '#065f46' : palette.badgeText;
    ctx.textAlign = 'center';
    ctx.fillText(stampText, baseW - padX - stampW / 2, y + 115);

    y = Math.max(leftInfoY + 12, y + 140);
  }

  ctx.strokeStyle = invStyle === 'minimal_classic_grid' ? '#0f172a' : '#e2e8f0';
  ctx.lineWidth = invStyle === 'minimal_classic_grid' ? 2 : 1.5;
  ctx.beginPath();
  ctx.moveTo(padX, y);
  ctx.lineTo(baseW - padX, y);
  ctx.stroke();

  y += 22;

  // 2. TWO-COLUMN CUSTOMER & ORDER DETAILS CARDS
  const colGap = invStyle === 'minimal_classic_grid' ? 0 : 20;
  const colW = (baseW - padX * 2 - colGap) / 2;
  const boxH = 152;

  if (invStyle === 'minimal_classic_grid') {
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(padX, y, baseW - padX * 2, boxH);
    ctx.beginPath();
    ctx.moveTo(padX + colW, y);
    ctx.lineTo(padX + colW, y + boxH);
    ctx.stroke();

    ctx.fillStyle = '#f1f5f9';
    ctx.fillRect(padX + 1, y + 1, baseW - padX * 2 - 2, 30);
    ctx.beginPath();
    ctx.moveTo(padX, y + 31);
    ctx.lineTo(baseW - padX, y + 31);
    ctx.stroke();
  } else {
    ctx.fillStyle = '#f8fafc';
    ctx.strokeStyle = invStyle === 'luxury_boutique' ? palette.primaryBorder : '#e2e8f0';
    ctx.lineWidth = 1.2;
    drawRoundedRect(ctx, padX, y, colW, boxH, 10);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = palette.primarySoft;
    drawRoundedRect(ctx, padX + 1, y + 1, colW - 2, 32, 9);
    ctx.fill();
  }

  ctx.textAlign = 'left';
  ctx.fillStyle = palette.badgeText;
  ctx.font = `800 12px ${fontSans}`;
  ctx.fillText(cfg.billToLabelText, padX + 16, y + 21);

  ctx.fillStyle = '#0f172a';
  ctx.font = `800 16px ${fontSans}`;
  ctx.fillText(order.customerName || 'সম্মানিত গ্রাহক', padX + 16, y + 56);

  ctx.fillStyle = palette.primary;
  ctx.font = `700 14px ${fontMono}`;
  ctx.fillText(
    order.alternativePhone
      ? `মোবাইল: ${order.customerPhone} (বিকল্প: ${order.alternativePhone})`
      : `মোবাইল: ${order.customerPhone}`,
    padX + 16,
    y + 78
  );

  ctx.fillStyle = '#334155';
  ctx.font = `600 12.5px ${fontSans}`;
  const fullAddr = `${order.deliveryAddress}, ${order.deliveryArea}`;
  const addrLines = wrapCanvasText(ctx, `ঠিকানা: ${fullAddr}`, colW - 32);
  addrLines.slice(0, 3).forEach((ln, idx) => {
    ctx.fillText(ln, padX + 16, y + 100 + idx * 18);
  });

  // Right Box: Order & Courier Info (Auto Courier Number or Blank Handwriting Box)
  const rightColX = padX + colW + colGap;
  if (invStyle !== 'minimal_classic_grid') {
    ctx.fillStyle = '#f8fafc';
    ctx.strokeStyle = invStyle === 'luxury_boutique' ? palette.primaryBorder : '#e2e8f0';
    drawRoundedRect(ctx, rightColX, y, colW, boxH, 10);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = palette.primarySoft;
    drawRoundedRect(ctx, rightColX + 1, y + 1, colW - 2, 32, 9);
    ctx.fill();
  }

  ctx.fillStyle = palette.badgeText;
  ctx.font = `800 12px ${fontSans}`;
  ctx.fillText(cfg.orderInfoLabelText, rightColX + 16, y + 21);

  ctx.fillStyle = '#334155';
  ctx.font = `600 12.5px ${fontSans}`;
  ctx.fillText(`ডেলিভারি জোন: ${order.deliveryArea}`, rightColX + 16, y + 52);
  ctx.fillText(
    `পেমেন্ট মাধ্যম: ${
      order.paymentMethod === 'cod'
        ? 'Cash on Delivery (ক্যাশ অন ডেলিভারি)'
        : order.paymentMethod.toUpperCase()
    }`,
    rightColX + 16,
    y + 72
  );

  if (cfg.showCourierCnBox !== false) {
    if (hasCourierNo) {
      ctx.fillStyle = '#047857';
      ctx.font = `800 13px ${fontMono}`;
      ctx.fillText(`কুরিয়ার (${courierProviderName}) CN: ${courierNoStr}`, rightColX + 16, y + 94);
    } else {
      // Blank Handwriting Box for Courier Number
      ctx.fillStyle = '#334155';
      ctx.font = `700 12px ${fontSans}`;
      ctx.fillText('কুরিয়ার নং (CN):', rightColX + 16, y + 95);
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 1.2;
      drawRoundedRect(ctx, rightColX + 115, y + 79, colW - 131, 22, 4);
      ctx.fill();
      ctx.stroke();
    }
  }

  if (cfg.showCourierBarcode) {
    const codeStr = courierNoStr || order.orderNo;
    drawBarcodeOnCanvas(ctx, codeStr, rightColX + 16, y + 109, 175, 26);
    ctx.fillStyle = '#475569';
    ctx.font = `700 10.5px ${fontMono}`;
    ctx.fillText(`#${codeStr}`, rightColX + 200, y + 127);
  }

  y += boxH + 24;

  // 3. ITEMS TABLE
  const tableW = baseW - padX * 2;
  if (invStyle === 'minimal_classic_grid') {
    ctx.fillStyle = '#f1f5f9';
    ctx.fillRect(padX, y, tableW, 38);
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(padX, y, tableW, 38);
    ctx.fillStyle = '#0f172a';
  } else {
    ctx.fillStyle =
      invStyle === 'modern_banner_header' || invStyle === 'luxury_boutique'
        ? palette.primary
        : palette.primaryDark;
    drawRoundedRect(ctx, padX, y, tableW, 38, 8);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
  }

  ctx.font = `700 12px ${fontSans}`;
  ctx.textAlign = 'left';
  ctx.fillText('#', padX + 16, y + 24);
  ctx.fillText(cfg.itemColumnLabel, padX + 48, y + 24);
  ctx.textAlign = 'center';
  ctx.fillText(cfg.qtyColumnLabel, padX + tableW - 220, y + 24);
  ctx.textAlign = 'right';
  ctx.fillText(cfg.priceColumnLabel, padX + tableW - 115, y + 24);
  ctx.fillText(cfg.totalColumnLabel, padX + tableW - 16, y + 24);

  y += 40;

  order.items.forEach((item, idx) => {
    const rowTitle = `${item.productName}${item.variantLabel ? ` — [${item.variantLabel}]` : ''}`;
    ctx.font = `700 13px ${fontSans}`;
    const textStartX = cfg.showProductImage ? padX + 94 : padX + 48;
    const textMaxW = cfg.showProductImage ? tableW - 346 : tableW - 300;
    const wrappedName = wrapCanvasText(ctx, rowTitle, textMaxW);
    const hasSubSku = cfg.showProductSku && (item.variantSku || item.sku);
    const rowH = Math.max(
      cfg.showProductImage ? 48 : 42,
      wrappedName.length * 19 + (hasSubSku ? 18 : 14)
    );

    if (idx % 2 === 1 && invStyle !== 'minimal_classic_grid') {
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(padX, y, tableW, rowH);
    }

    ctx.textAlign = 'left';
    ctx.fillStyle = '#64748b';
    ctx.font = `700 12.5px ${fontMono}`;
    ctx.fillText(String(idx + 1).padStart(2, '0'), padX + 16, y + 26);

    if (cfg.showProductImage) {
      drawProductThumbnailOnCanvas(
        ctx,
        itemImages[idx],
        padX + 46,
        y + 6,
        36,
        invStyle === 'minimal_classic_grid'
      );
    }

    ctx.fillStyle = '#0f172a';
    ctx.font = `700 13px ${fontSans}`;
    wrappedName.forEach((ln, lIdx) => {
      ctx.fillText(ln, textStartX, y + 23 + lIdx * 18);
    });

    if (hasSubSku) {
      ctx.fillStyle = '#64748b';
      ctx.font = `500 11px ${fontMono}`;
      ctx.fillText(
        `SKU: ${item.variantSku || item.sku}`,
        textStartX,
        y + 23 + wrappedName.length * 18
      );
    }

    ctx.textAlign = 'center';
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 13.5px ${fontMono}`;
    ctx.fillText(`${item.quantity}`, padX + tableW - 220, y + 26);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#334155';
    ctx.font = `600 13px ${fontMono}`;
    ctx.fillText(formatCurrency(item.unitPrice), padX + tableW - 115, y + 26);

    ctx.fillStyle = '#0f172a';
    ctx.font = `800 13.5px ${fontMono}`;
    ctx.fillText(formatCurrency(item.total), padX + tableW - 16, y + 26);

    y += rowH;

    ctx.strokeStyle = invStyle === 'minimal_classic_grid' ? '#0f172a' : '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padX, y);
    ctx.lineTo(padX + tableW, y);
    ctx.stroke();
  });

  y += 22;

  // 4. BOTTOM SUMMARY: Left (COD Notice & Terms/Notes) | Right (Totals Box)
  const leftBoxW = tableW - 290;
  const rightBoxX = padX + leftBoxW + 24;
  const rightBoxW = 266;

  ctx.fillStyle = palette.primarySoft;
  ctx.strokeStyle = palette.primaryBorder;
  ctx.lineWidth = 1.2;
  drawRoundedRect(ctx, padX, y, leftBoxW, 54, 8);
  ctx.fill();
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.fillStyle = palette.badgeText;
  ctx.font = `700 12px ${fontSans}`;
  const codLines = wrapCanvasText(ctx, cfg.codNoticeBannerText, leftBoxW - 28);
  codLines.slice(0, 2).forEach((ln, idx) => {
    ctx.fillText(ln, padX + 14, y + 22 + idx * 18);
  });

  let leftColCurY = y + 64;

  if (showNoteOnInv) {
    ctx.fillStyle = '#fffbeb';
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.4;
    drawRoundedRect(ctx, padX, leftColCurY, leftBoxW, 62, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#92400e';
    ctx.font = `800 11.5px ${fontSans}`;
    ctx.fillText('📝 কাস্টমারের অর্ডার নোট (Customer Order Note):', padX + 14, leftColCurY + 20);

    ctx.fillStyle = '#0f172a';
    ctx.font = `700 12px ${fontSans}`;
    const noteLines = wrapCanvasText(ctx, cleanCustomerNote, leftBoxW - 28);
    noteLines.slice(0, 2).forEach((ln, idx) => {
      ctx.fillText(ln, padX + 14, leftColCurY + 39 + idx * 16);
    });

    leftColCurY += 72;
  }

  if (cfg.showTermsSection && cfg.termsAndPolicyText) {
    const termsY = leftColCurY;
    ctx.fillStyle = '#f8fafc';
    ctx.strokeStyle = '#e2e8f0';
    drawRoundedRect(ctx, padX, termsY, leftBoxW, 74, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#0f172a';
    ctx.font = `800 11.5px ${fontSans}`;
    ctx.fillText('বিশেষ দ্রষ্টব্য / রিটার্ন পলিসি:', padX + 14, termsY + 20);

    ctx.fillStyle = '#475569';
    ctx.font = `500 11.5px ${fontSans}`;
    const termLines = wrapCanvasText(ctx, cfg.termsAndPolicyText, leftBoxW - 28);
    termLines.slice(0, 2).forEach((ln, idx) => {
      ctx.fillText(ln, padX + 14, termsY + 40 + idx * 17);
    });
    leftColCurY += 84;
  }

  let sumY = y + 18;
  ctx.textAlign = 'left';
  ctx.fillStyle = '#475569';
  ctx.font = `600 13px ${fontSans}`;
  ctx.fillText(cfg.subtotalLabelText, rightBoxX, sumY);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#0f172a';
  ctx.font = `700 13.5px ${fontMono}`;
  ctx.fillText(formatCurrency(order.subtotal), rightBoxX + rightBoxW, sumY);

  sumY += 26;
  ctx.textAlign = 'left';
  ctx.fillStyle = '#475569';
  ctx.font = `600 13px ${fontSans}`;
  ctx.fillText(cfg.deliveryLabelText, rightBoxX, sumY);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#0f172a';
  ctx.font = `700 13.5px ${fontMono}`;
  ctx.fillText(
    order.deliveryCharge === 0 ? 'ফ্রি (৳0)' : formatCurrency(order.deliveryCharge),
    rightBoxX + rightBoxW,
    sumY
  );

  if ((order.discountAmount || 0) > 0) {
    sumY += 26;
    ctx.textAlign = 'left';
    ctx.fillStyle = '#e11d48';
    ctx.font = `700 13px ${fontSans}`;
    ctx.fillText(cfg.discountLabelText, rightBoxX, sumY);
    ctx.textAlign = 'right';
    ctx.font = `800 13.5px ${fontMono}`;
    ctx.fillText(`- ${formatCurrency(order.discountAmount)}`, rightBoxX + rightBoxW, sumY);
  }

  sumY += 18;
  ctx.fillStyle = palette.primary;
  drawRoundedRect(ctx, rightBoxX, sumY, rightBoxW, 48, 9);
  ctx.fill();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffffff';
  ctx.font = `700 12px ${fontSans}`;
  ctx.fillText(cfg.grandTotalLabelText, rightBoxX + 14, sumY + 29);

  ctx.textAlign = 'right';
  ctx.font = `800 18px ${fontMono}`;
  ctx.fillText(formatCurrency(order.grandTotal), rightBoxX + rightBoxW - 14, sumY + 30);

  // 5. SIGNATURES & FOOTER
  const footerBaseY = Math.max(sumY + 115, leftColCurY + 45, dynamicH - 125);

  if (cfg.showSignatureSection) {
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.2;

    ctx.beginPath();
    ctx.moveTo(padX, footerBaseY);
    ctx.lineTo(padX + 200, footerBaseY);
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.fillStyle = '#475569';
    ctx.font = `700 12px ${fontSans}`;
    ctx.fillText(cfg.customerSignatureLabel, padX + 100, footerBaseY + 20);

    ctx.beginPath();
    ctx.moveTo(baseW - padX - 200, footerBaseY);
    ctx.lineTo(baseW - padX, footerBaseY);
    ctx.stroke();

    ctx.fillText(cfg.authorizedSignatureLabel, baseW - padX - 100, footerBaseY + 20);
  }

  const thankY = dynamicH - 58;
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(28, thankY, baseW - 56, 48);
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(28, thankY);
  ctx.lineTo(baseW - 28, thankY);
  ctx.stroke();

  ctx.textAlign = 'center';
  ctx.fillStyle = '#0f172a';
  ctx.font = `700 13px ${fontSans}`;
  ctx.fillText(cfg.thankYouText, baseW / 2, thankY + 20);

  ctx.fillStyle = '#64748b';
  ctx.font = `500 11px ${fontSans}`;
  ctx.fillText(
    `${cfg.brandNameOverride} · হটলাইন: ${cfg.storePhoneOverride}${
      domainToShow ? ` · ${domainToShow}` : ''
    }`,
    baseW / 2,
    thankY + 38
  );

  return canvas;
};

export const SmartInvoiceSlipModal: React.FC<SmartInvoiceSlipModalProps> = ({
  order,
  bulkOrders,
  initialMode = 'invoice',
  userRole = 'super_admin',
  business,
  products,
  onUpdateBusiness,
  onUpdateOrder,
  onClose,
  formatCurrency,
  formatDate,
  showToast
}) => {
  // Strictly allow only Developer and Super Admin to customize invoice templates/texts
  const canCustomizeInvoice = userRole === 'developer' || userRole === 'super_admin';

  const isBulkMode = Boolean(bulkOrders && bulkOrders.length > 1);
  const [activeBulkIndex, setActiveBulkIndex] = useState<number>(0);

  const [activeTab, setActiveTab] = useState<'invoice' | 'slip' | 'customize'>(() => {
    if (initialMode === 'customize' && !canCustomizeInvoice) return 'invoice';
    return order || (bulkOrders && bulkOrders.length > 0) ? initialMode : 'customize';
  });

  const [draftConfig, setDraftConfig] = useState<Required<InvoiceCustomizationConfig>>(() =>
    resolveInvoiceConfig(business)
  );
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  useEffect(() => {
    setDraftConfig(resolveInvoiceConfig(business));
  }, [business.invoiceConfig, business.name, business.phone, business.address, business.logoUrl]);

  const effectiveOrder: OnlineOrder = useMemo(() => {
    if (bulkOrders && bulkOrders.length > 0) {
      return bulkOrders[Math.min(activeBulkIndex, bulkOrders.length - 1)] || bulkOrders[0];
    }
    if (order) return order;
    const sampleImg =
      products?.find((p) => p.image && p.image.trim())?.image || '';
    return {
      id: 'demo_preview',
      orderNo: '1024',
      invoiceNo: `${business.invoicePrefix || 'INV'}-1024`,
      businessId: business.id,
      outletId: 'outlet_01',
      customerName: 'মোঃ তানভীর আহমেদ',
      customerPhone: '01711000000',
      deliveryArea: 'ঢাকার ভেতরে (Inside Dhaka)',
      deliveryAddress: 'বাসা ১২, রোড ৫, ধানমন্ডি, ঢাকা-১২০৫',
      deliverySlot: 'হোম ডেলিভারি (২৪-৪৮ ঘণ্টা)',
      items: [
        {
          productId: 'p1',
          productName: 'প্রিমিয়াম কুল ব্লু এক্সিকিউটিভ পাঞ্জাবি',
          image: sampleImg,
          variantLabel: 'XL (44)',
          sku: 'SL-PNJ-44',
          unit: 'পিস',
          quantity: 1,
          unitPrice: 1250,
          costPrice: 800,
          discount: 0,
          total: 1250
        }
      ],
      subtotal: 1250,
      deliveryCharge: 60,
      discountAmount: 0,
      grandTotal: 1310,
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      orderStatus: 'confirmed',
      notes: 'ডেলিভারির আগে অনুগ্রহ করে কল দিয়ে আসবেন।',
      createdAt: new Date().toISOString()
    };
  }, [order, bulkOrders, activeBulkIndex, business, products]);

  const cleanOrderNote = useMemo(
    () => getCleanCustomerNote(effectiveOrder.notes),
    [effectiveOrder.notes]
  );

  // Special Discount Input State for the active order
  const [specialDiscountInput, setSpecialDiscountInput] = useState<string>(
    String(effectiveOrder.discountAmount || 0)
  );

  useEffect(() => {
    setSpecialDiscountInput(String(effectiveOrder.discountAmount || 0));
  }, [effectiveOrder.id, effectiveOrder.discountAmount]);

  const handleApplySpecialDiscount = (customAmount?: number) => {
    if (!onUpdateOrder || effectiveOrder.id === 'demo_preview') return;
    const rawDiscount =
      customAmount !== undefined ? customAmount : Math.max(0, Number(specialDiscountInput) || 0);
    const maxAllowed = effectiveOrder.subtotal + effectiveOrder.deliveryCharge;
    const finalDiscount = Math.min(maxAllowed, Math.round(rawDiscount));
    const newGrandTotal = Math.max(
      0,
      effectiveOrder.subtotal + effectiveOrder.deliveryCharge - finalDiscount
    );

    onUpdateOrder(effectiveOrder.id, {
      discountAmount: finalDiscount,
      grandTotal: newGrandTotal
    });
    setSpecialDiscountInput(String(finalDiscount));
    showToast(
      finalDiscount > 0
        ? `অর্ডার #${effectiveOrder.orderNo}-এ ৳${finalDiscount} স্পেশাল ডিসকাউন্ট যুক্ত হয়েছে! নতুন বিল: ৳${newGrandTotal}`
        : `অর্ডার #${effectiveOrder.orderNo}-এর ডিসকাউন্ট রিমুভ করা হয়েছে!`,
      'success'
    );
  };

  const palette =
    INVOICE_ACCENT_PALETTES[draftConfig.accentTheme] || INVOICE_ACCENT_PALETTES.cool_blue;

  const hasCourierNo = Boolean(
    (effectiveOrder.courierConsignmentId && effectiveOrder.courierConsignmentId.trim()) ||
      (effectiveOrder.courierTrackingCode && effectiveOrder.courierTrackingCode.trim())
  );
  const courierNoStr = (
    effectiveOrder.courierConsignmentId ||
    effectiveOrder.courierTrackingCode ||
    ''
  ).trim();

  const barcodeBars = useMemo(
    () => generateBarcodePattern(courierNoStr || effectiveOrder.orderNo || '1001'),
    [courierNoStr, effectiveOrder.orderNo]
  );

  const domainToShow =
    draftConfig.showDomainOnInvoice &&
    draftConfig.storeWebsiteText &&
    draftConfig.storeWebsiteText.trim()
      ? draftConfig.storeWebsiteText.trim()
      : '';

  const handleQuickStyleUpdate = (patch: Partial<InvoiceCustomizationConfig>) => {
    if (!canCustomizeInvoice) return;
    const next = { ...draftConfig, ...patch };
    setDraftConfig(next);
    onUpdateBusiness({
      invoiceConfig: next
    });
  };

  const handleSaveCustomConfig = () => {
    if (!canCustomizeInvoice) {
      showToast('শুধুমাত্র অ্যাডমিন ও ডেভেলপার ইনভয়েস কাস্টমাইজ করতে পারবেন', 'error');
      return;
    }
    onUpdateBusiness({
      invoiceConfig: draftConfig
    });
    showToast('ইনভয়েস ও ডেলিভারি স্লিপের স্টাইল ও কাস্টমাইজেশন সেভ হয়েছে!', 'success');
    if ((order || (bulkOrders && bulkOrders.length > 0)) && activeTab === 'customize') {
      setActiveTab('invoice');
    }
  };

  const handleResetDefaultConfig = () => {
    if (!canCustomizeInvoice) return;
    const defaults = getDefaultInvoiceConfig(business);
    setDraftConfig(defaults);
    onUpdateBusiness({
      invoiceConfig: defaults
    });
    showToast('ইনভয়েস ডিজাইন ও টেক্সট ডিফল্ট অবস্থায় রিসেট করা হয়েছে!', 'info');
  };

  // Single or Bulk Multi-Page PDF Download
  const handleDownloadPdf = async (targetMode: 'invoice' | 'slip', downloadAllBulk = false) => {
    setIsGenerating(true);
    try {
      const targetOrders =
        downloadAllBulk && bulkOrders && bulkOrders.length > 0 ? bulkOrders : [effectiveOrder];
      const preloadedLogo = draftConfig.showLogo
        ? await loadLogoImageForCanvas(business.logoUrl)
        : null;

      const compressedPages: CompressedPdfPageImage[] = [];
      for (let idx = 0; idx < targetOrders.length; idx++) {
        const ord = targetOrders[idx];
        const c = await renderOrderDocumentToCanvas(
          ord,
          business,
          draftConfig,
          targetMode,
          formatCurrency,
          formatDate,
          preloadedLogo,
          products
        );
        // Immediately convert canvas to compressed JPEG bytes and zero out canvas.width = 0; canvas.height = 0
        // so browser RAM is freed after every single invoice (supports 100+ bulk invoices without memory crash)
        compressedPages.push(compressAndReleaseCanvasForPdf(c, 0.94));
        if (idx > 0 && idx % 8 === 0) {
          await new Promise(resolve => window.setTimeout(resolve, 0));
        }
      }

      const isSlip = targetMode === 'slip';
      const slipSizeSpec =
        SLIP_PAPER_SIZES.find(s => s.id === draftConfig.slipPaperSize) || SLIP_PAPER_SIZES[0];
      const invSizeSpec =
        INVOICE_PAPER_SIZES.find(s => s.id === draftConfig.invoicePaperSize) ||
        INVOICE_PAPER_SIZES[0];
      const pageW = isSlip ? slipSizeSpec.widthPt : invSizeSpec.widthPt;

      const pdfBlob = buildMultiPagePdfBlobFromCanvases(compressedPages, pageW);
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      if (targetOrders.length > 1) {
        link.download =
          targetMode === 'slip'
            ? `Bulk-Delivery-Slips-${targetOrders.length}-Orders.pdf`
            : `Bulk-Smart-Invoices-${targetOrders.length}-Orders.pdf`;
      } else {
        link.download =
          targetMode === 'slip'
            ? `Delivery-Slip-ORD-${effectiveOrder.orderNo}.pdf`
            : `Smart-Invoice-ORD-${effectiveOrder.orderNo}.pdf`;
      }
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 4000);

      showToast(
        targetOrders.length > 1
          ? `মোট ${targetOrders.length} টি অর্ডারের বাল্ক PDF এক ফাইলে ডাউনলোড সম্পন্ন হয়েছে!`
          : targetMode === 'slip'
            ? `ডেলিভারি স্লিপ (#${effectiveOrder.orderNo}) PDF ডাউনলোড সম্পন্ন হয়েছে!`
            : `স্মার্ট ইনভয়েস (#${effectiveOrder.orderNo}) PDF ডাউনলোড সম্পন্ন হয়েছে!`,
        'success'
      );
    } catch {
      showToast('PDF তৈরিতে সমস্যা হয়েছে, অনুগ্রহ করে আবার চেষ্টা করুন', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadPng = async (targetMode: 'invoice' | 'slip') => {
    setIsGenerating(true);
    try {
      const canvas = await renderOrderDocumentToCanvas(
        effectiveOrder,
        business,
        draftConfig,
        targetMode,
        formatCurrency,
        formatDate,
        undefined,
        products
      );
      const pngUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = pngUrl;
      link.download =
        targetMode === 'slip'
          ? `Delivery-Slip-ORD-${effectiveOrder.orderNo}.png`
          : `Smart-Invoice-ORD-${effectiveOrder.orderNo}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast(
        targetMode === 'slip'
          ? 'ডেলিভারি স্লিপের HD ছবি (.png) ডাউনলোড হয়েছে!'
          : 'স্মার্ট ইনভয়েসের HD ছবি (.png) ডাউনলোড হয়েছে!',
        'success'
      );
    } catch {
      showToast('ইমেজ ডাউনলোডে সমস্যা হয়েছে', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  // Single or Bulk Print Engine (Supports Sticker Printers 4x6, 3x4, 80mm Roll & A4/A5)
  const handlePrintDocument = async (targetMode: 'invoice' | 'slip', printAllBulk = false) => {
    setIsGenerating(true);
    try {
      const targetOrders =
        printAllBulk && bulkOrders && bulkOrders.length > 0 ? bulkOrders : [effectiveOrder];
      const preloadedLogo = draftConfig.showLogo
        ? await loadLogoImageForCanvas(business.logoUrl)
        : null;

      const dataUrls: string[] = [];
      for (const ord of targetOrders) {
        const canvas = await renderOrderDocumentToCanvas(
          ord,
          business,
          draftConfig,
          targetMode,
          formatCurrency,
          formatDate,
          preloadedLogo,
          products
        );
        dataUrls.push(canvas.toDataURL('image/png'));
      }

      const existingFrame = document.getElementById('sm-dedicated-print-iframe');
      if (existingFrame && existingFrame.parentNode) {
        existingFrame.parentNode.removeChild(existingFrame);
      }

      const iframe = document.createElement('iframe');
      iframe.id = 'sm-dedicated-print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '1px';
      iframe.style.height = '1px';
      iframe.style.border = '0';
      iframe.style.opacity = '0';
      iframe.style.pointerEvents = 'none';
      document.body.appendChild(iframe);

      const slipSizeSpec =
        SLIP_PAPER_SIZES.find(s => s.id === draftConfig.slipPaperSize) || SLIP_PAPER_SIZES[0];
      const invSizeSpec =
        INVOICE_PAPER_SIZES.find(s => s.id === draftConfig.invoicePaperSize) ||
        INVOICE_PAPER_SIZES[0];

      const maxWidthCss = targetMode === 'slip' ? slipSizeSpec.maxWidthCss : invSizeSpec.maxWidthCss;
      const pageSizeRule =
        targetMode === 'slip' ? slipSizeSpec.pageCssSize : invSizeSpec.pageCssSize;

      const docTitle =
        targetOrders.length > 1
          ? `Bulk-${targetMode}-${targetOrders.length}-Orders`
          : `${targetMode}-ORD-${effectiveOrder.orderNo}`;

      const pagesHtml = dataUrls
        .map(
          (url, idx) => `
  <div class="print-page${idx < dataUrls.length - 1 ? ' page-break' : ''}">
    <img class="print-img" src="${url}" alt="Page ${idx + 1}" />
  </div>`
        )
        .join('\n');

      const printHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${docTitle}</title>
  <style>
    @page {
      size: ${pageSizeRule};
      margin: 4mm;
    }
    html, body {
      margin: 0;
      padding: 0;
      background: #ffffff;
      text-align: center;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .print-page {
      display: block;
      width: 100%;
      max-width: ${maxWidthCss};
      margin: 0 auto;
    }
    .page-break {
      page-break-after: always;
      break-after: page;
      margin-bottom: 6mm;
    }
    .print-img {
      width: 100%;
      height: auto;
      display: block;
    }
  </style>
</head>
<body>
  ${pagesHtml}
  <script>
    window.onload = function() {
      var imgs = document.querySelectorAll('.print-img');
      var loaded = 0;
      function checkDone() {
        loaded++;
        if (loaded >= imgs.length) {
          setTimeout(function() {
            window.focus();
            window.print();
          }, 150);
        }
      }
      if (imgs.length === 0) {
        checkDone();
      } else {
        for (var i = 0; i < imgs.length; i++) {
          if (imgs[i].complete) {
            checkDone();
          } else {
            imgs[i].onload = checkDone;
            imgs[i].onerror = checkDone;
          }
        }
      }
    };
  </script>
</body>
</html>`;

      const frameDoc = iframe.contentWindow?.document;
      if (frameDoc) {
        frameDoc.open();
        frameDoc.write(printHtml);
        frameDoc.close();
      } else {
        document.body.classList.add('sm-printing-invoice');
        window.print();
        setTimeout(() => document.body.classList.remove('sm-printing-invoice'), 1000);
      }
    } catch {
      document.body.classList.add('sm-printing-invoice');
      window.print();
      setTimeout(() => document.body.classList.remove('sm-printing-invoice'), 1000);
    } finally {
      setIsGenerating(false);
    }
  };

  const activeDocMode: 'invoice' | 'slip' = activeTab === 'slip' ? 'slip' : 'invoice';
  const currentInvStyle = draftConfig.invoiceStyle || 'executive_standard';
  const currentSlipStyle = draftConfig.deliverySlipStyle || 'courier_standard_box';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-100 rounded-2xl border border-slate-200 max-w-5xl w-full max-h-[96vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Top Action & Mode Switcher Bar */}
        <div className="bg-white border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-2.5 shrink-0 no-print">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setActiveTab('invoice')}
              className={`px-3.5 py-2 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'invoice'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>স্মার্ট ইনভয়েস (6 Styles)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('slip')}
              className={`px-3.5 py-2 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'slip'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Truck className="w-4 h-4" />
              <span>ডেলিভারি স্লিপ (4 Styles)</span>
            </button>

            {canCustomizeInvoice ? (
              <button
                type="button"
                onClick={() => setActiveTab('customize')}
                className={`px-3.5 py-2 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'customize'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                <Settings2 className="w-4 h-4" />
                <span>⚙️ ইনভয়েস কাস্টমাইজ</span>
              </button>
            ) : (
              <span
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 text-slate-500 text-[11px] font-bold inline-flex items-center gap-1"
                title="শুধুমাত্র অ্যাডমিন ও ডেভেলপার ইনভয়েস কাস্টমাইজ করতে পারবেন"
              >
                <Lock className="w-3 h-3" />
                <span>কাস্টমাইজ লকড (Admin Only)</span>
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {isBulkMode && bulkOrders && (
              <>
                <button
                  type="button"
                  disabled={isGenerating}
                  onClick={() => handlePrintDocument(activeDocMode, true)}
                  className="px-3.5 py-2 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>
                    সবগুলো একসাথে প্রিন্ট ({bulkOrders.length} টি)
                  </span>
                </button>

                <button
                  type="button"
                  disabled={isGenerating}
                  onClick={() => handleDownloadPdf(activeDocMode, true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>
                    বাল্ক PDF ডাউনলোড ({bulkOrders.length} টি)
                  </span>
                </button>
              </>
            )}

            <button
              type="button"
              disabled={isGenerating}
              onClick={() => handleDownloadPdf(activeDocMode, false)}
              className="px-3.5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              title="সার্ভারে কোনো স্পেস খরচ না করে সরাসরি আপনার পিসি/ফোনে PDF ডাউনলোড করুন"
            >
              <Download className="w-3.5 h-3.5" />
              <span>
                {isGenerating
                  ? 'তৈরি হচ্ছে...'
                  : activeDocMode === 'slip'
                    ? 'স্লিপ PDF ডাউনলোড'
                    : 'ইনভয়েস PDF ডাউনলোড'}
              </span>
            </button>

            <button
              type="button"
              disabled={isGenerating}
              onClick={() => handleDownloadPng(activeDocMode)}
              className="px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="হোয়াটসঅ্যাপ বা মেসেঞ্জারে পাঠানোর জন্য HD ছবি (.png) ডাউনলোড করুন"
            >
              <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>HD ছবি (PNG)</span>
            </button>

            <button
              type="button"
              disabled={isGenerating}
              onClick={() => handlePrintDocument(activeDocMode, false)}
              className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>
                {activeDocMode === 'slip' ? 'স্লিপ প্রিন্ট করুন' : 'ইনভয়েস প্রিন্ট করুন'}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Special Discount Bar + Bulk Order Navigator + Print Size Selector (Visible in Preview Modes) */}
        {activeTab !== 'customize' && (
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 space-y-2 shrink-0 no-print">
            {/* Row 1: Special Discount Editor + Paper/Sticker Size Template + Bulk Order Switcher */}
            <div className="flex flex-wrap items-center justify-between gap-2.5">
              {/* Special Discount Quick Editor for Current Order */}
              {onUpdateOrder && effectiveOrder.id !== 'demo_preview' && (
                <div className="flex flex-wrap items-center gap-1.5 bg-rose-50/90 border border-rose-200 px-3 py-1.5 rounded-xl">
                  <Tag className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span className="text-xs font-extrabold text-rose-950">
                    স্পেশাল ডিসকাউন্ট (৳):
                  </span>
                  <input
                    type="number"
                    min={0}
                    value={specialDiscountInput}
                    onChange={e => setSpecialDiscountInput(e.target.value)}
                    placeholder="0"
                    className="w-20 px-2 py-1 text-xs font-mono font-bold bg-white border border-rose-300 rounded-lg outline-hidden focus:border-rose-600 text-slate-900"
                  />
                  <button
                    type="button"
                    onClick={() => handleApplySpecialDiscount()}
                    className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-extrabold cursor-pointer"
                  >
                    অ্যাপ্লাই
                  </button>
                  {[50, 100, 150, 200].map(preset => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => handleApplySpecialDiscount(preset)}
                      className="px-2 py-0.5 rounded bg-white hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-mono font-bold cursor-pointer"
                    >
                      ৳{preset}
                    </button>
                  ))}
                  {(effectiveOrder.discountAmount || 0) > 0 && (
                    <button
                      type="button"
                      onClick={() => handleApplySpecialDiscount(0)}
                      className="px-2 py-0.5 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] font-bold cursor-pointer"
                    >
                      রিমুভ (৳0)
                    </button>
                  )}
                </div>
              )}

              {/* Print / Sticker Size Template Selector */}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-extrabold text-slate-600 inline-flex items-center gap-1">
                  <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>{activeTab === 'slip' ? 'স্টিকার / প্রিন্ট সাইজ:' : 'পেপার সাইজ:'}</span>
                </span>
                {activeTab === 'slip' ? (
                  <select
                    value={draftConfig.slipPaperSize}
                    onChange={e => {
                      const val = e.target.value as SlipPaperSize;
                      setDraftConfig(prev => ({ ...prev, slipPaperSize: val }));
                      if (canCustomizeInvoice) {
                        onUpdateBusiness({
                          invoiceConfig: { ...draftConfig, slipPaperSize: val }
                        });
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-800 outline-hidden cursor-pointer"
                  >
                    {SLIP_PAPER_SIZES.map(sz => (
                      <option key={sz.id} value={sz.id}>
                        {sz.labelBn}
                      </option>
                    ))}
                  </select>
                ) : (
                  <select
                    value={draftConfig.invoicePaperSize}
                    onChange={e => {
                      const val = e.target.value as InvoicePaperSize;
                      setDraftConfig(prev => ({ ...prev, invoicePaperSize: val }));
                      if (canCustomizeInvoice) {
                        onUpdateBusiness({
                          invoiceConfig: { ...draftConfig, invoicePaperSize: val }
                        });
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-800 outline-hidden cursor-pointer"
                  >
                    {INVOICE_PAPER_SIZES.map(sz => (
                      <option key={sz.id} value={sz.id}>
                        {sz.labelBn}
                      </option>
                    ))}
                  </select>
                )}

                {/* 1-Click Product Image ON/OFF Toggle in Preview Bar */}
                <button
                  type="button"
                  onClick={() => {
                    const nextVal = !draftConfig.showProductImage;
                    setDraftConfig(prev => ({ ...prev, showProductImage: nextVal }));
                    if (canCustomizeInvoice) {
                      onUpdateBusiness({
                        invoiceConfig: { ...draftConfig, showProductImage: nextVal }
                      });
                    }
                  }}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer transition-all ${
                    draftConfig.showProductImage
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : 'bg-white border-slate-300 text-slate-600'
                  }`}
                  title="ইনভয়েস ও ডেলিভারি স্লিপে পণ্যের ছবি (Product Image) চালু বা বন্ধ করুন"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>পণ্যের ছবি:</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                      draftConfig.showProductImage
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {draftConfig.showProductImage ? 'ON' : 'OFF'}
                  </span>
                </button>

                {/* 1-Click Courier CN Box ON/OFF Toggle in Preview Bar */}
                <button
                  type="button"
                  onClick={() => {
                    const nextVal = !draftConfig.showCourierCnBox;
                    setDraftConfig(prev => ({ ...prev, showCourierCnBox: nextVal }));
                    if (canCustomizeInvoice) {
                      onUpdateBusiness({
                        invoiceConfig: { ...draftConfig, showCourierCnBox: nextVal }
                      });
                    }
                  }}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer transition-all ${
                    draftConfig.showCourierCnBox
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : 'bg-white border-slate-300 text-slate-600'
                  }`}
                  title="ইনভয়েস ও ডেলিভারি স্লিপে 'কুরিয়ার নং (CN):' বক্স চালু বা বন্ধ করুন"
                >
                  <Truck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>কুরিয়ার নং (CN):</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                      draftConfig.showCourierCnBox
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {draftConfig.showCourierCnBox ? 'ON' : 'OFF'}
                  </span>
                </button>

                {/* 1-Click Order Note ON/OFF Toggle for Current View (Invoice vs Delivery Slip) */}
                {activeTab === 'slip' ? (
                  <button
                    type="button"
                    onClick={() => {
                      const nextVal = !draftConfig.showOrderNoteOnSlip;
                      setDraftConfig(prev => ({ ...prev, showOrderNoteOnSlip: nextVal }));
                      if (canCustomizeInvoice) {
                        onUpdateBusiness({
                          invoiceConfig: { ...draftConfig, showOrderNoteOnSlip: nextVal }
                        });
                      }
                    }}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer transition-all ${
                      draftConfig.showOrderNoteOnSlip
                        ? 'bg-amber-50 border-amber-300 text-amber-950'
                        : 'bg-white border-slate-300 text-slate-600'
                    }`}
                    title="ডেলিভারি স্লিপে কাস্টমারের অর্ডার নোট দেখানো চালু বা বন্ধ (ON/OFF) করুন"
                  >
                    <FileText className="w-3.5 h-3.5 text-amber-600" />
                    <span>স্লিপে অর্ডার নোট:</span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                        draftConfig.showOrderNoteOnSlip
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {draftConfig.showOrderNoteOnSlip ? 'ON' : 'OFF'}
                    </span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      const nextVal = !draftConfig.showOrderNoteOnInvoice;
                      setDraftConfig(prev => ({ ...prev, showOrderNoteOnInvoice: nextVal }));
                      if (canCustomizeInvoice) {
                        onUpdateBusiness({
                          invoiceConfig: { ...draftConfig, showOrderNoteOnInvoice: nextVal }
                        });
                      }
                    }}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer transition-all ${
                      draftConfig.showOrderNoteOnInvoice
                        ? 'bg-amber-50 border-amber-300 text-amber-950'
                        : 'bg-white border-slate-300 text-slate-600'
                    }`}
                    title="ইনভয়েসে কাস্টমারের অর্ডার নোট দেখানো চালু বা বন্ধ (ON/OFF) করুন"
                  >
                    <FileText className="w-3.5 h-3.5 text-amber-600" />
                    <span>ইনভয়েসে অর্ডার নোট:</span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                        draftConfig.showOrderNoteOnInvoice
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {draftConfig.showOrderNoteOnInvoice ? 'ON' : 'OFF'}
                    </span>
                  </button>
                )}
              </div>

              {/* Bulk Order Preview Switcher */}
              {isBulkMode && bulkOrders && (
                <div className="flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-xl text-xs font-bold text-indigo-950">
                  <span>
                    বাল্ক প্রিভিউ: অর্ডার {activeBulkIndex + 1} / {bulkOrders.length} (#
                    {effectiveOrder.orderNo})
                  </span>
                  <button
                    type="button"
                    disabled={activeBulkIndex <= 0}
                    onClick={() => setActiveBulkIndex(i => Math.max(0, i - 1))}
                    className="px-2 py-0.5 rounded bg-white border border-indigo-200 disabled:opacity-40 cursor-pointer"
                  >
                    ← আগেরটি
                  </button>
                  <button
                    type="button"
                    disabled={activeBulkIndex >= bulkOrders.length - 1}
                    onClick={() =>
                      setActiveBulkIndex(i => Math.min(bulkOrders.length - 1, i + 1))
                    }
                    className="px-2 py-0.5 rounded bg-white border border-indigo-200 disabled:opacity-40 cursor-pointer"
                  >
                    পরেরটি →
                  </button>
                </div>
              )}
            </div>

            {/* Row 2: 1-Click Quick Style & Color Theme Switcher (Only for Admin & Developer) */}
            {canCustomizeInvoice && (
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-200/70">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-extrabold text-slate-600 inline-flex items-center gap-1 mr-1">
                    <LayoutTemplate className="w-3.5 h-3.5 text-blue-600" />
                    <span>{activeTab === 'slip' ? 'স্লিপ স্টাইল:' : 'ইনভয়েস স্টাইল:'}</span>
                  </span>

                  {activeTab === 'invoice'
                    ? INVOICE_LAYOUT_STYLES.map(st => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => handleQuickStyleUpdate({ invoiceStyle: st.id })}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition-all cursor-pointer ${
                            currentInvStyle === st.id
                              ? 'bg-blue-700 text-white shadow-2xs'
                              : 'bg-white text-slate-700 border border-slate-200 hover:border-blue-300'
                          }`}
                          title={st.descBn}
                        >
                          {st.shortBn}
                        </button>
                      ))
                    : DELIVERY_SLIP_STYLES.map(st => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => handleQuickStyleUpdate({ deliverySlipStyle: st.id })}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition-all cursor-pointer ${
                            currentSlipStyle === st.id
                              ? 'bg-slate-900 text-white shadow-2xs'
                              : 'bg-white text-slate-700 border border-slate-200 hover:border-slate-400'
                          }`}
                          title={st.descBn}
                        >
                          {st.shortBn}
                        </button>
                      ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-slate-500 inline-flex items-center gap-1">
                    <Palette className="w-3.5 h-3.5" />
                    <span>রঙ:</span>
                  </span>
                  {(Object.values(INVOICE_ACCENT_PALETTES) as AccentPalette[]).map(th => (
                    <button
                      key={th.id}
                      type="button"
                      onClick={() => handleQuickStyleUpdate({ accentTheme: th.id })}
                      className={`px-2 py-1 rounded-lg border text-[10px] font-extrabold inline-flex items-center gap-1 cursor-pointer transition-all ${
                        draftConfig.accentTheme === th.id
                          ? 'border-blue-600 bg-blue-50 text-blue-950 ring-1 ring-blue-500/30'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                      title={th.nameBn}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: th.primary }}
                      />
                      <span className="hidden sm:inline">{th.shortBn}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Main Modal Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6">
          {activeTab === 'customize' && canCustomizeInvoice ? (
            /* ================================================================
               INVOICE & DELIVERY SLIP CUSTOMIZATION STUDIO (ADMIN & DEVELOPER ONLY)
               ================================================================ */
            <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-6 space-y-6 max-w-4xl mx-auto">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
                <div>
                  <h3 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-blue-600" />
                    <span>স্মার্ট ইনভয়েস ও ডেলিভারি স্লিপ কাস্টমাইজেশন (Admin & Developer)</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    ডোমেইন নাম, পেপার/স্টিকার প্রিন্টার সাইজ, ইনভয়েস স্টাইল এবং যেকোনো টেক্সট পরিবর্তন করে সেভ করুন।
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleResetDefaultConfig}
                    className="px-3 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>ডিফল্ট রিসেট</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveCustomConfig}
                    className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>কাস্টমাইজেশন সেভ করুন</span>
                  </button>
                </div>
              </div>

              {/* Highlighted Custom Domain Name & Print Paper/Sticker Size Template Box */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-blue-50/60 p-4 rounded-xl border border-blue-200">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-extrabold text-blue-950 flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-blue-700" />
                      <span>ইনভয়েসে প্রদর্শিত ডোমেইন / ওয়েবসাইট নাম</span>
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setDraftConfig(prev => ({
                          ...prev,
                          showDomainOnInvoice: !prev.showDomainOnInvoice
                        }))
                      }
                      className={`px-2.5 py-0.5 rounded text-[11px] font-extrabold cursor-pointer ${
                        draftConfig.showDomainOnInvoice
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {draftConfig.showDomainOnInvoice ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                    </button>
                  </div>
                  <input
                    type="text"
                    value={draftConfig.storeWebsiteText}
                    onChange={e =>
                      setDraftConfig(prev => ({ ...prev, storeWebsiteText: e.target.value }))
                    }
                    placeholder="যেমন: www.smartlook.com.bd"
                    className="w-full px-3 py-2 text-xs font-mono font-bold bg-white rounded-xl border border-blue-300 focus:border-blue-700 outline-hidden"
                  />
                  <p className="text-[11px] text-slate-600">
                    এখানে আপনি যে ডোমেইন নাম লিখে দেবেন, ইনভয়েস ও স্লিপে ঠিক সেই ডোমেইন নামটিই শো করবে।
                  </p>
                </div>

                <div className="space-y-2.5">
                  <label className="block text-xs font-extrabold text-blue-950 flex items-center gap-1.5">
                    <Maximize2 className="w-4 h-4 text-blue-700" />
                    <span>প্রিন্টার ও স্টিকার সাইজ টেমপ্লেট (Future Sticker Printer Ready)</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <span className="block text-[10px] font-bold text-slate-600 mb-1">
                        ইনভয়েস পেপার সাইজ:
                      </span>
                      <select
                        value={draftConfig.invoicePaperSize}
                        onChange={e =>
                          setDraftConfig(prev => ({
                            ...prev,
                            invoicePaperSize: e.target.value as InvoicePaperSize
                          }))
                        }
                        className="w-full px-2.5 py-2 rounded-xl border border-blue-300 bg-white text-xs font-bold text-slate-800 outline-hidden"
                      >
                        {INVOICE_PAPER_SIZES.map(sz => (
                          <option key={sz.id} value={sz.id}>
                            {sz.shortBn}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <span className="block text-[10px] font-bold text-slate-600 mb-1">
                        ডেলিভারি স্লিপ / স্টিকার সাইজ:
                      </span>
                      <select
                        value={draftConfig.slipPaperSize}
                        onChange={e =>
                          setDraftConfig(prev => ({
                            ...prev,
                            slipPaperSize: e.target.value as SlipPaperSize
                          }))
                        }
                        className="w-full px-2.5 py-2 rounded-xl border border-blue-300 bg-white text-xs font-bold text-slate-800 outline-hidden"
                      >
                        {SLIP_PAPER_SIZES.map(sz => (
                          <option key={sz.id} value={sz.id}>
                            {sz.shortBn}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* 1. 5 Invoice Layout Styles & 4 Delivery Slip Styles Selector */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2.5">
                  <label className="block text-xs font-extrabold text-slate-900">
                    ১. স্মার্ট ইনভয়েসের ডিজাইন স্টাইল (5 Clean Styles)
                  </label>
                  <div className="space-y-2">
                    {INVOICE_LAYOUT_STYLES.map(st => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() =>
                          setDraftConfig(prev => ({ ...prev, invoiceStyle: st.id }))
                        }
                        className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-2 ${
                          currentInvStyle === st.id
                            ? 'border-blue-600 bg-blue-50/90 text-blue-950 ring-2 ring-blue-500/20'
                            : 'border-slate-200 bg-white text-slate-800 hover:border-blue-300'
                        }`}
                      >
                        <div>
                          <p className="text-xs font-extrabold">{st.nameBn}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">{st.descBn}</p>
                        </div>
                        {currentInvStyle === st.id && (
                          <span className="px-2 py-0.5 rounded bg-blue-700 text-white text-[10px] font-extrabold shrink-0">
                            Selected
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2.5">
                  <label className="block text-xs font-extrabold text-slate-900">
                    ২. ডেলিভারি স্লিপের ডিজাইন স্টাইল (4 Parcel Styles)
                  </label>
                  <div className="space-y-2">
                    {DELIVERY_SLIP_STYLES.map(st => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() =>
                          setDraftConfig(prev => ({ ...prev, deliverySlipStyle: st.id }))
                        }
                        className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-2 ${
                          currentSlipStyle === st.id
                            ? 'border-slate-900 bg-slate-900/5 text-slate-950 ring-2 ring-slate-900/15'
                            : 'border-slate-200 bg-white text-slate-800 hover:border-slate-400'
                        }`}
                      >
                        <div>
                          <p className="text-xs font-extrabold">{st.nameBn}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">{st.descBn}</p>
                        </div>
                        {currentSlipStyle === st.id && (
                          <span className="px-2 py-0.5 rounded bg-slate-900 text-white text-[10px] font-extrabold shrink-0">
                            Selected
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* 2. Theme & Website Logo Settings */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                <div className="space-y-2.5">
                  <label className="block text-xs font-extrabold text-slate-800">
                    ৩. ইনভয়েস ও স্লিপ কালার থিম (6 Clean Accents)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {(Object.values(INVOICE_ACCENT_PALETTES) as AccentPalette[]).map(th => (
                      <button
                        key={th.id}
                        type="button"
                        onClick={() =>
                          setDraftConfig(prev => ({ ...prev, accentTheme: th.id }))
                        }
                        className={`p-2.5 rounded-xl border text-left text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                          draftConfig.accentTheme === th.id
                            ? 'border-blue-600 bg-blue-50/80 text-blue-950 ring-2 ring-blue-500/20'
                            : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        <span
                          className="w-4 h-4 rounded-full shrink-0 border border-white shadow-2xs"
                          style={{ backgroundColor: th.primary }}
                        />
                        <span className="truncate">{th.shortBn}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-extrabold text-slate-800">
                      ৪. ওয়েবসাইটের লোগো ইনভয়েসে দেখান
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setDraftConfig(prev => ({ ...prev, showLogo: !prev.showLogo }))
                      }
                      className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer ${
                        draftConfig.showLogo
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {draftConfig.showLogo ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                    </button>
                  </div>

                  <div className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                    {business.logoUrl ? (
                      <img
                        src={business.logoUrl}
                        alt={business.name}
                        className="h-10 w-auto object-contain shrink-0"
                      />
                    ) : (
                      <span className="text-xs text-slate-400">লোগো নেই</span>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-bold text-slate-700">
                        লোগোর সাইজ (উচ্চতা: {draftConfig.logoHeightPx}px)
                      </p>
                      <input
                        type="range"
                        min={32}
                        max={72}
                        value={draftConfig.logoHeightPx}
                        onChange={e =>
                          setDraftConfig(prev => ({
                            ...prev,
                            logoHeightPx: Number(e.target.value) || 48
                          }))
                        }
                        className="w-full accent-blue-600 cursor-pointer mt-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Store Brand & Contact Texts */}
              <div className="space-y-3">
                <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                  স্টোরের নাম, ঠিকানা ও হটলাইন টেক্সট
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      স্টোর / ব্র্যান্ডের নাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.brandNameOverride}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, brandNameOverride: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      সাবটাইটেল / ট্যাগলাইন
                    </label>
                    <input
                      type="text"
                      value={draftConfig.brandTagline}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, brandTagline: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ইনভয়েস হটলাইন / মোবাইল নাম্বার
                    </label>
                    <input
                      type="text"
                      value={draftConfig.storePhoneOverride}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, storePhoneOverride: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      স্টোরের ঠিকানা (Address)
                    </label>
                    <input
                      type="text"
                      value={draftConfig.storeAddressOverride}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, storeAddressOverride: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* 4. Headings & Table Column Labels */}
              <div className="space-y-3">
                <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                  ইনভয়েস ও স্লিপের শিরোনাম এবং টেবিলের টেক্সট
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ইনভয়েস শিরোনাম (Invoice Title)
                    </label>
                    <input
                      type="text"
                      value={draftConfig.invoiceTitleText}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, invoiceTitleText: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ডেলিভারি স্লিপ শিরোনাম (Slip Title)
                    </label>
                    <input
                      type="text"
                      value={draftConfig.deliverySlipTitleText}
                      onChange={e =>
                        setDraftConfig(prev => ({
                          ...prev,
                          deliverySlipTitleText: e.target.value
                        }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      গ্রাহকের বক্সের শিরোনাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.billToLabelText}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, billToLabelText: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      অর্ডার তথ্যের বক্সের শিরোনাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.orderInfoLabelText}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, orderInfoLabelText: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      পণ্যের কলামের নাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.itemColumnLabel}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, itemColumnLabel: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      পরিমাণ কলামের নাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.qtyColumnLabel}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, qtyColumnLabel: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      দর (Rate) কলামের নাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.priceColumnLabel}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, priceColumnLabel: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      মোট (Total) কলামের নাম
                    </label>
                    <input
                      type="text"
                      value={draftConfig.totalColumnLabel}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, totalColumnLabel: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* 5. Footer Notes, COD Notice, Signatures & Toggles */}
              <div className="space-y-3">
                <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                  ফুটার নোট, রিটার্ন পলিসি ও স্বাক্ষর কাস্টমাইজেশন
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ক্যাশ অন ডেলিভারি (COD) নির্দেশনা বার্তা
                    </label>
                    <input
                      type="text"
                      value={draftConfig.codNoticeBannerText}
                      onChange={e =>
                        setDraftConfig(prev => ({
                          ...prev,
                          codNoticeBannerText: e.target.value
                        }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ফুটার ধন্যবাদ বার্তা (Thank You Message)
                    </label>
                    <input
                      type="text"
                      value={draftConfig.thankYouText}
                      onChange={e =>
                        setDraftConfig(prev => ({ ...prev, thankYouText: e.target.value }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      বিশেষ নোট / রিটার্ন পলিসি (Terms & Return Policy)
                    </label>
                    <textarea
                      rows={2}
                      value={draftConfig.termsAndPolicyText}
                      onChange={e =>
                        setDraftConfig(prev => ({
                          ...prev,
                          termsAndPolicyText: e.target.value
                        }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ডেলিভারি স্লিপের রাইডার নির্দেশনা (Delivery Slip Rider Note)
                    </label>
                    <input
                      type="text"
                      value={draftConfig.slipInstructionText}
                      onChange={e =>
                        setDraftConfig(prev => ({
                          ...prev,
                          slipInstructionText: e.target.value
                        }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      বাম পাশের স্বাক্ষর টেক্সট
                    </label>
                    <input
                      type="text"
                      value={draftConfig.customerSignatureLabel}
                      onChange={e =>
                        setDraftConfig(prev => ({
                          ...prev,
                          customerSignatureLabel: e.target.value
                        }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      ডান পাশের স্বাক্ষর টেক্সট
                    </label>
                    <input
                      type="text"
                      value={draftConfig.authorizedSignatureLabel}
                      onChange={e =>
                        setDraftConfig(prev => ({
                          ...prev,
                          authorizedSignatureLabel: e.target.value
                        }))
                      }
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 outline-hidden"
                    />
                  </div>
                </div>

                {/* Quick ON/OFF Feature Toggles */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                  {[
                    {
                      key: 'showProductImage' as const,
                      label: 'প্রোডাক্টের ছবি (Image)'
                    },
                    {
                      key: 'showCourierCnBox' as const,
                      label: 'কুরিয়ার নং (CN) বক্স'
                    },
                    {
                      key: 'showOrderNoteOnInvoice' as const,
                      label: 'ইনভয়েসে অর্ডার নোট'
                    },
                    {
                      key: 'showOrderNoteOnSlip' as const,
                      label: 'ডেলিভারি স্লিপে অর্ডার নোট'
                    },
                    {
                      key: 'showTermsSection' as const,
                      label: 'রিটার্ন পলিসি বক্স'
                    },
                    {
                      key: 'showSignatureSection' as const,
                      label: 'স্বাক্ষর সেকশন'
                    },
                    {
                      key: 'showCourierBarcode' as const,
                      label: 'বারকোড ও ট্র্যাকিং'
                    },
                    {
                      key: 'showProductSku' as const,
                      label: 'প্রোডাক্ট SKU কোড'
                    }
                  ].map(tog => (
                    <button
                      key={tog.key}
                      type="button"
                      onClick={() =>
                        setDraftConfig(prev => ({ ...prev, [tog.key]: !prev[tog.key] }))
                      }
                      className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-between cursor-pointer ${
                        draftConfig[tog.key]
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                          : 'bg-slate-50 border-slate-200 text-slate-500'
                      }`}
                    >
                      <span>{tog.label}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                          draftConfig[tog.key]
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {draftConfig[tog.key] ? 'ON' : 'OFF'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveTab('invoice')}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>ইনভয়েস প্রিভিউ দেখুন</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('slip')}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>ডেলিভারি স্লিপ প্রিভিউ দেখুন</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleSaveCustomConfig}
                  className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>কাস্টমাইজেশন সেভ করুন</span>
                </button>
              </div>
            </div>
          ) : activeTab === 'slip' ? (
            /* ================================================================
               LIVE PREVIEW: 4 DELIVERY SLIP STYLES (PARCEL STICKER)
               ================================================================ */
            <div
              id="sm-printable-document-area"
              className={`bg-white max-w-xl mx-auto p-5 sm:p-6 shadow-md space-y-4 text-slate-900 ${
                currentSlipStyle === 'thermal_pos_80mm'
                  ? 'rounded-xl border-2 border-dashed border-slate-900'
                  : currentSlipStyle === 'modern_fashion_tag'
                    ? 'rounded-2xl border-2'
                    : 'rounded-2xl border-2 border-slate-900'
              }`}
              style={
                currentSlipStyle === 'modern_fashion_tag'
                  ? { borderColor: palette.primary }
                  : undefined
              }
            >
              {/* Top Header */}
              {currentSlipStyle === 'thermal_pos_80mm' ? (
                <div className="text-center border-b-2 border-dashed border-slate-300 pb-3.5 space-y-1">
                  {draftConfig.showLogo && business.logoUrl ? (
                    <img
                      src={business.logoUrl}
                      alt={draftConfig.brandNameOverride}
                      style={{ height: `${Math.min(48, draftConfig.logoHeightPx)}px` }}
                      className="w-auto object-contain mx-auto"
                    />
                  ) : null}
                  <h3 className="text-lg font-black text-slate-900">
                    {draftConfig.brandNameOverride}
                  </h3>
                  <p className="text-xs font-mono font-bold text-slate-700">
                    হটলাইন: {draftConfig.storePhoneOverride}
                    {domainToShow ? ` · ${domainToShow}` : ''} · তারিখ:{' '}
                    {formatDate(effectiveOrder.createdAt)}
                  </p>
                  <span className="inline-block px-3 py-0.5 rounded border border-slate-900 text-[11px] font-extrabold uppercase">
                    {draftConfig.deliverySlipTitleText}
                  </span>
                </div>
              ) : (
                <div
                  className={`flex items-start justify-between gap-3 pb-3.5 ${
                    currentSlipStyle === 'modern_fashion_tag'
                      ? 'p-3.5 -mx-2 -mt-2 rounded-xl border'
                      : 'border-b-2 border-slate-200'
                  }`}
                  style={
                    currentSlipStyle === 'modern_fashion_tag'
                      ? {
                          backgroundColor: palette.primarySoft,
                          borderColor: palette.primaryBorder
                        }
                      : undefined
                  }
                >
                  <div className="flex items-center gap-3">
                    {draftConfig.showLogo && business.logoUrl ? (
                      <img
                        src={business.logoUrl}
                        alt={draftConfig.brandNameOverride}
                        style={{ height: `${Math.min(52, draftConfig.logoHeightPx)}px` }}
                        className="w-auto object-contain shrink-0"
                      />
                    ) : null}
                    <div>
                      <h3 className="text-base sm:text-lg font-extrabold text-slate-900 leading-tight">
                        {draftConfig.brandNameOverride}
                      </h3>
                      <p className="text-xs font-bold text-slate-600 mt-0.5">
                        হটলাইন: <span className="font-mono">{draftConfig.storePhoneOverride}</span>
                      </p>
                      {domainToShow && (
                        <p
                          className="text-[11px] font-mono font-bold mt-0.5"
                          style={{ color: palette.primary }}
                        >
                          {domainToShow}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className="inline-block px-3 py-1 rounded-lg text-white text-[11px] font-extrabold tracking-wide uppercase"
                      style={{ backgroundColor: palette.primary }}
                    >
                      {draftConfig.deliverySlipTitleText}
                    </span>
                    <p className="text-[11px] font-semibold text-slate-500 mt-1">
                      তারিখ: {formatDate(effectiveOrder.createdAt)}
                    </p>
                  </div>
                </div>
              )}

              {/* Order No + Courier Number Box (Auto Courier Number OR Blank Handwriting Box) */}
              <div className="bg-slate-50 rounded-xl border border-slate-300 p-3.5 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-1.5 flex-1 min-w-[220px]">
                  <div>
                    <p className="text-[10px] font-extrabold uppercase text-slate-500">
                      অর্ডার নং (ORDER NO)
                    </p>
                    <p className="text-xl font-black font-mono text-slate-900">
                      #{effectiveOrder.orderNo}
                    </p>
                  </div>

                  {draftConfig.showCourierCnBox !== false && (
                    hasCourierNo ? (
                      <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 border-2 border-emerald-500 text-emerald-950 font-mono text-xs font-black">
                        <Truck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>
                          {effectiveOrder.courierProvider === 'pathao' ? 'Pathao' : 'Steadfast'} CN:{' '}
                          {courierNoStr}
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border-2 border-slate-500 max-w-xs">
                        <span className="text-xs font-extrabold text-slate-700 whitespace-nowrap">
                          কুরিয়ার নং (CN):
                        </span>
                        <span className="flex-1 h-5 border-b border-dashed border-slate-400" />
                      </div>
                    )
                  )}
                </div>

                {draftConfig.showCourierBarcode && (
                  <div className="flex flex-col items-center bg-white px-3 py-2 rounded-lg border border-slate-200">
                    <div className="flex items-stretch h-9 gap-[1px]">
                      {barcodeBars.map((w, idx) => (
                        <span
                          key={idx}
                          style={{
                            width: `${w * 1.45}px`,
                            backgroundColor: idx % 2 === 0 ? '#0f172a' : 'transparent'
                          }}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-mono font-bold text-slate-700 mt-1 tracking-widest">
                      {courierNoStr || effectiveOrder.orderNo}
                    </span>
                  </div>
                )}
              </div>

              {currentSlipStyle === 'bold_cod_split' ? (
                /* Slip Style 2: Side-by-Side Split Layout */
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5 items-stretch">
                  <div className="sm:col-span-7 rounded-xl border-2 border-slate-900 overflow-hidden flex flex-col">
                    <div
                      className="px-3.5 py-2 text-xs font-extrabold"
                      style={{
                        backgroundColor: palette.primarySoft,
                        color: palette.badgeText
                      }}
                    >
                      প্রাপক / ডেলিভারি ঠিকানা (DELIVER TO)
                    </div>
                    <div className="p-3.5 space-y-1.5 flex-1 bg-white">
                      <p className="text-lg font-black text-slate-950">
                        {effectiveOrder.customerName}
                      </p>
                      <p
                        className="text-base font-mono font-extrabold flex flex-wrap items-center gap-1.5"
                        style={{ color: palette.primary }}
                      >
                        <Phone className="w-4 h-4 shrink-0" />
                        <span>
                          {effectiveOrder.customerPhone}
                          {effectiveOrder.alternativePhone
                            ? ` / বিকল্প: ${effectiveOrder.alternativePhone}`
                            : ''}
                        </span>
                      </p>
                      <p className="text-xs font-bold text-slate-700">
                        এরিয়া: {effectiveOrder.deliveryArea}
                      </p>
                      <p className="text-xs sm:text-sm font-semibold text-slate-800 pt-0.5">
                        ঠিকানা: {effectiveOrder.deliveryAddress}
                      </p>
                    </div>
                  </div>

                  <div
                    className="sm:col-span-5 rounded-xl p-4 text-center flex flex-col items-center justify-center text-white"
                    style={{
                      backgroundColor:
                        effectiveOrder.paymentStatus === 'paid' ? '#047857' : palette.primary
                    }}
                  >
                    <p className="text-[11px] font-extrabold uppercase opacity-90">
                      {effectiveOrder.paymentStatus === 'paid'
                        ? 'পেমেন্ট স্ট্যাটাস'
                        : 'ডেলিভারি ম্যান সংগ্রহ করবেন'}
                    </p>
                    <p className="text-2xl sm:text-3xl font-black font-mono my-1.5">
                      {effectiveOrder.paymentStatus === 'paid'
                        ? 'PAID (৳0)'
                        : formatCurrency(effectiveOrder.grandTotal)}
                    </p>
                    {(effectiveOrder.discountAmount || 0) > 0 && (
                      <p className="text-[11px] font-bold bg-white/20 px-2 py-0.5 rounded mb-1">
                        স্পেশাল ছাড়: -{formatCurrency(effectiveOrder.discountAmount)}
                      </p>
                    )}
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-black/20 px-2.5 py-0.5 rounded">
                      {effectiveOrder.paymentStatus === 'paid'
                        ? 'সম্পূর্ণ পরিশোধিত'
                        : 'CASH ON DELIVERY'}
                    </span>
                  </div>
                </div>
              ) : (
                /* Slip Style 1, 3, 4: Receiver + COD */
                <>
                  <div
                    className="rounded-xl border-2 overflow-hidden"
                    style={{
                      borderColor:
                        currentSlipStyle === 'modern_fashion_tag' ? palette.primary : '#0f172a'
                    }}
                  >
                    <div
                      className="px-3.5 py-2 flex items-center justify-between text-xs font-extrabold"
                      style={{
                        backgroundColor:
                          currentSlipStyle === 'thermal_pos_80mm'
                            ? '#f1f5f9'
                            : palette.primarySoft,
                        color:
                          currentSlipStyle === 'thermal_pos_80mm'
                            ? '#0f172a'
                            : palette.badgeText
                      }}
                    >
                      <span>প্রাপক / ডেলিভারি ঠিকানা (DELIVER TO)</span>
                      <span className="text-slate-900">এরিয়া: {effectiveOrder.deliveryArea}</span>
                    </div>
                    <div className="p-3.5 space-y-1.5 bg-white">
                      <p className="text-lg font-extrabold text-slate-950">
                        {effectiveOrder.customerName}
                      </p>
                      <p
                        className="text-base font-mono font-extrabold flex flex-wrap items-center gap-1.5"
                        style={{ color: palette.primary }}
                      >
                        <Phone className="w-4 h-4 shrink-0" />
                        <span>
                          {effectiveOrder.customerPhone}
                          {effectiveOrder.alternativePhone
                            ? ` (বিকল্প: ${effectiveOrder.alternativePhone})`
                            : ''}
                        </span>
                      </p>
                      <p className="text-xs sm:text-sm font-semibold text-slate-800 flex items-start gap-1.5 pt-0.5">
                        <MapPin className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                        <span>
                          {effectiveOrder.deliveryAddress}, {effectiveOrder.deliveryArea}
                        </span>
                      </p>
                    </div>
                  </div>

                  <div
                    className={`rounded-xl p-3.5 flex items-center justify-between gap-3 ${
                      currentSlipStyle === 'thermal_pos_80mm'
                        ? 'bg-white border-2 border-slate-900 text-slate-950'
                        : effectiveOrder.paymentStatus === 'paid'
                          ? 'bg-emerald-50 border-2 border-emerald-600 text-emerald-950'
                          : 'text-white'
                    }`}
                    style={
                      currentSlipStyle !== 'thermal_pos_80mm' &&
                      effectiveOrder.paymentStatus !== 'paid'
                        ? {
                            backgroundColor:
                              currentSlipStyle === 'modern_fashion_tag'
                                ? palette.primary
                                : '#0f172a'
                          }
                        : undefined
                    }
                  >
                    <div>
                      <p className="text-xs font-extrabold uppercase tracking-wide opacity-90">
                        {effectiveOrder.paymentStatus === 'paid'
                          ? 'পেমেন্ট স্ট্যাটাস (PAYMENT STATUS)'
                          : 'ডেলিভারি ম্যান সংগ্রহ করবেন (COD AMOUNT)'}
                      </p>
                      <p className="text-[11px] opacity-85 mt-0.5">
                        {(effectiveOrder.discountAmount || 0) > 0
                          ? `ক্যাশ অন ডেলিভারি (স্পেশাল ছাড়: -${formatCurrency(
                              effectiveOrder.discountAmount
                            )})`
                          : effectiveOrder.paymentStatus === 'paid'
                            ? 'সম্পূর্ণ পরিশোধিত (PAID)'
                            : 'ক্যাশ অন ডেলিভারি (Cash on Delivery)'}
                      </p>
                    </div>
                    <p className="text-2xl font-black font-mono tabular-nums">
                      {effectiveOrder.paymentStatus === 'paid'
                        ? 'PAID (৳0)'
                        : formatCurrency(effectiveOrder.grandTotal)}
                    </p>
                  </div>
                </>
              )}

              {/* Items Checklist */}
              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <div className="bg-slate-100 px-3.5 py-2 flex items-center justify-between font-extrabold text-slate-700">
                  <span>{draftConfig.itemColumnLabel}</span>
                  <span>
                    {draftConfig.qtyColumnLabel} × {draftConfig.totalColumnLabel}
                  </span>
                </div>
                <div className="divide-y divide-slate-100">
                  {effectiveOrder.items.map((it, idx) => {
                    const itemImgUrl = draftConfig.showProductImage
                      ? resolveOrderItemImageUrl(it, products)
                      : '';
                    return (
                      <div
                        key={idx}
                        className="px-3.5 py-2 flex items-center justify-between gap-2.5"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {draftConfig.showProductImage && (
                            <div className="w-9 h-9 rounded-lg border border-slate-200 bg-slate-50 overflow-hidden shrink-0 flex items-center justify-center">
                              {itemImgUrl ? (
                                <img
                                  src={itemImgUrl}
                                  alt={it.productName}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <span className="text-xs">🛍️</span>
                              )}
                            </div>
                          )}
                          <div className="font-bold text-slate-900 min-w-0">
                            <span>
                              {idx + 1}. {it.productName}
                            </span>
                            {it.variantLabel && (
                              <span className="ml-1.5 px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200 text-[11px] font-extrabold">
                                {it.variantLabel}
                              </span>
                            )}
                          </div>
                        </div>
                        <span className="font-mono font-extrabold text-slate-900 shrink-0">
                          {it.quantity} পিস — {formatCurrency(it.total)}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <div className="bg-slate-50 px-3.5 py-2 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px] font-bold text-slate-600">
                  <span>
                    মোট পণ্য:{' '}
                    {effectiveOrder.items.reduce((s, i) => s + (Number(i.quantity) || 0), 0)} টি ·
                    ইনভয়েস: {effectiveOrder.invoiceNo}
                  </span>
                  <span className="font-mono">
                    সাবটোটাল: {formatCurrency(effectiveOrder.subtotal)} | ডেলিভারি:{' '}
                    {effectiveOrder.deliveryCharge === 0
                      ? 'ফ্রি'
                      : formatCurrency(effectiveOrder.deliveryCharge)}
                    {(effectiveOrder.discountAmount || 0) > 0 && (
                      <span className="text-rose-600 font-extrabold">
                        {' '}
                        | ছাড়: -{formatCurrency(effectiveOrder.discountAmount)}
                      </span>
                    )}
                  </span>
                </div>
              </div>

              {/* Customer Order Note on Delivery Slip (Shown only if enabled & order has a note) */}
              {draftConfig.showOrderNoteOnSlip !== false && cleanOrderNote && (
                <div
                  className={`rounded-xl p-3 text-xs space-y-1 ${
                    currentSlipStyle === 'thermal_pos_80mm'
                      ? 'bg-white border-2 border-slate-900 text-slate-950'
                      : 'bg-amber-50/90 border-2 border-amber-400 text-amber-950'
                  }`}
                >
                  <p className="font-extrabold flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                    <span>কাস্টমারের অর্ডার নোট (Customer Note):</span>
                  </p>
                  <p className="font-bold text-slate-900 leading-snug whitespace-pre-wrap">
                    {cleanOrderNote}
                  </p>
                </div>
              )}

              {/* Bottom Rider Note */}
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-2.5 text-center space-y-0.5">
                <p className="text-xs font-extrabold text-slate-800">
                  {draftConfig.slipInstructionText}
                </p>
                <p className="text-[11px] text-slate-500">
                  প্রেরক: {draftConfig.brandNameOverride} · হটলাইন: {draftConfig.storePhoneOverride}
                  {domainToShow ? ` · ${domainToShow}` : ''}
                </p>
              </div>
            </div>
          ) : currentInvStyle === 'thermal_pos_receipt' ? (
            /* ================================================================
               LIVE PREVIEW: STYLE 6 — THERMAL POS RECEIPT INVOICE (80mm / B&W)
               ================================================================ */
            <div
              id="sm-printable-document-area"
              className="bg-white max-w-md mx-auto p-5 shadow-md rounded-xl border-2 border-dashed border-slate-900 text-slate-950 space-y-3.5"
            >
              {/* Centered Thermal Store Header */}
              <div className="text-center border-b-2 border-dashed border-slate-400 pb-3 space-y-1">
                {draftConfig.showLogo && business.logoUrl ? (
                  <img
                    src={business.logoUrl}
                    alt={draftConfig.brandNameOverride}
                    style={{ height: `${Math.min(46, draftConfig.logoHeightPx)}px` }}
                    className="w-auto object-contain mx-auto mb-1"
                  />
                ) : null}
                <h2 className="text-xl font-black tracking-tight text-black">
                  {draftConfig.brandNameOverride}
                </h2>
                {draftConfig.storeAddressOverride && (
                  <p className="text-[11px] font-semibold text-slate-700">
                    {draftConfig.storeAddressOverride}
                  </p>
                )}
                <p className="text-xs font-mono font-bold text-black">
                  হটলাইন: {draftConfig.storePhoneOverride}
                  {domainToShow ? ` · ${domainToShow}` : ''}
                </p>
                <div className="pt-1">
                  <span className="inline-block px-3.5 py-0.5 rounded border-2 border-black text-black text-[11px] font-black uppercase tracking-wide">
                    {draftConfig.invoiceTitleText}
                  </span>
                </div>
              </div>

              {/* Order & Date Meta */}
              <div className="border-b-2 border-dashed border-slate-400 pb-2.5 text-xs space-y-1">
                <div className="flex items-center justify-between font-mono font-bold text-black">
                  <span>ইনভয়েস: {effectiveOrder.invoiceNo}</span>
                  <span>অর্ডার নং: #{effectiveOrder.orderNo}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-700">
                  <span>তারিখ: {formatDate(effectiveOrder.createdAt)}</span>
                  <span className="font-extrabold text-black">
                    {effectiveOrder.paymentStatus === 'paid'
                      ? 'পেমেন্ট: PAID'
                      : 'পেমেন্ট: COD (ক্যাশ অন ডেলিভারি)'}
                  </span>
                </div>
              </div>

              {/* Customer & Courier Details */}
              <div className="border-b-2 border-dashed border-slate-400 pb-3 text-xs space-y-1">
                <p className="font-black text-sm text-black">
                  গ্রাহক: {effectiveOrder.customerName}
                </p>
                <p className="font-mono font-black text-sm text-black">
                  মোবাইল: {effectiveOrder.customerPhone}
                  {effectiveOrder.alternativePhone
                    ? `, বিকল্প: ${effectiveOrder.alternativePhone}`
                    : ''}
                </p>
                <p className="font-semibold text-slate-800 leading-snug">
                  ঠিকানা: {effectiveOrder.deliveryAddress}, {effectiveOrder.deliveryArea}
                </p>
                {draftConfig.showCourierCnBox !== false && (
                  <div className="pt-1">
                    {hasCourierNo ? (
                      <p className="font-mono font-black text-xs text-black bg-slate-100 px-2.5 py-1 rounded border border-black inline-block">
                        কুরিয়ার (
                        {effectiveOrder.courierProvider === 'pathao' ? 'Pathao' : 'Steadfast'}) CN:{' '}
                        {courierNoStr}
                      </p>
                    ) : (
                      <div className="flex items-center gap-2 pt-0.5">
                        <span className="font-extrabold text-black whitespace-nowrap">
                          কুরিয়ার নং (CN):
                        </span>
                        <span className="flex-1 h-6 bg-white rounded border-2 border-black px-2" />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Thermal Items List with Optional Product Image */}
              <div className="border-b-2 border-dashed border-slate-400 pb-2.5 text-xs">
                <div className="flex items-center justify-between font-black text-black border-b border-dashed border-slate-400 pb-1.5 mb-2">
                  <span>{draftConfig.itemColumnLabel}</span>
                  <span>
                    {draftConfig.qtyColumnLabel} × {draftConfig.totalColumnLabel}
                  </span>
                </div>
                <div className="space-y-2">
                  {effectiveOrder.items.map((item, idx) => {
                    const itemImgUrl = draftConfig.showProductImage
                      ? resolveOrderItemImageUrl(item, products)
                      : '';
                    return (
                      <div
                        key={idx}
                        className="flex items-center justify-between gap-2 py-1 border-b border-dotted border-slate-200 last:border-b-0"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          {draftConfig.showProductImage && (
                            <div className="w-8 h-8 rounded border border-slate-900 bg-slate-50 overflow-hidden shrink-0 flex items-center justify-center">
                              {itemImgUrl ? (
                                <img
                                  src={itemImgUrl}
                                  alt={item.productName}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <span className="text-[11px]">🛍️</span>
                              )}
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="font-extrabold text-black leading-snug">
                              {idx + 1}. {item.productName}
                              {item.variantLabel ? ` [${item.variantLabel}]` : ''}
                            </p>
                            <p className="text-[11px] font-mono text-slate-600">
                              {item.quantity} × {formatCurrency(item.unitPrice)}
                              {draftConfig.showProductSku && (item.variantSku || item.sku)
                                ? ` · SKU: ${item.variantSku || item.sku}`
                                : ''}
                            </p>
                          </div>
                        </div>
                        <span className="font-mono font-black text-black shrink-0">
                          {formatCurrency(item.total)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Thermal Totals */}
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-800">
                  <span className="font-semibold">{draftConfig.subtotalLabelText}</span>
                  <span className="font-mono font-bold text-black">
                    {formatCurrency(effectiveOrder.subtotal)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-800">
                  <span className="font-semibold">{draftConfig.deliveryLabelText}</span>
                  <span className="font-mono font-bold text-black">
                    {effectiveOrder.deliveryCharge === 0
                      ? 'ফ্রি (৳0)'
                      : formatCurrency(effectiveOrder.deliveryCharge)}
                  </span>
                </div>
                {(effectiveOrder.discountAmount || 0) > 0 && (
                  <div className="flex items-center justify-between font-extrabold text-black">
                    <span>{draftConfig.discountLabelText}</span>
                    <span className="font-mono">
                      - {formatCurrency(effectiveOrder.discountAmount)}
                    </span>
                  </div>
                )}
                <div className="border-2 border-black rounded-lg p-2.5 flex items-center justify-between bg-slate-50 mt-1">
                  <span className="font-black text-xs text-black">
                    {draftConfig.grandTotalLabelText}
                  </span>
                  <span className="text-lg font-black font-mono text-black">
                    {formatCurrency(effectiveOrder.grandTotal)}
                  </span>
                </div>
              </div>

              {/* Customer Order Note on Thermal Invoice (Shown only if enabled & order has a note) */}
              {draftConfig.showOrderNoteOnInvoice !== false && cleanOrderNote && (
                <div className="border-2 border-black rounded-lg p-2.5 text-xs space-y-0.5 bg-white">
                  <p className="font-black text-black">📝 অর্ডার নোট:</p>
                  <p className="font-bold text-slate-900 leading-snug whitespace-pre-wrap">
                    {cleanOrderNote}
                  </p>
                </div>
              )}

              {/* Barcode & Footer */}
              {draftConfig.showCourierBarcode && (
                <div className="pt-2 flex flex-col items-center">
                  <div className="inline-flex items-stretch h-8 bg-white px-2 py-1 border border-slate-300 gap-[1px]">
                    {barcodeBars.map((w, idx) => (
                      <span
                        key={idx}
                        style={{
                          width: `${w * 1.3}px`,
                          backgroundColor: idx % 2 === 0 ? '#000000' : 'transparent'
                        }}
                      />
                    ))}
                  </div>
                  <span className="font-mono text-[10px] font-bold text-black mt-1 tracking-widest">
                    #{courierNoStr || effectiveOrder.orderNo}
                  </span>
                </div>
              )}

              <div className="border-t-2 border-dashed border-slate-400 pt-2.5 text-center space-y-0.5">
                <p className="text-xs font-extrabold text-black">{draftConfig.thankYouText}</p>
                <p className="text-[10px] font-mono text-slate-600">
                  {draftConfig.brandNameOverride} · {draftConfig.storePhoneOverride}
                </p>
              </div>
            </div>
          ) : (
            /* ================================================================
               LIVE PREVIEW: 5 STANDARD SMART INVOICE STYLES (CLEAN A4 / MEMO)
               ================================================================ */
            <div
              id="sm-printable-document-area"
              className={`bg-white max-w-3xl mx-auto shadow-md overflow-hidden text-slate-900 ${
                currentInvStyle === 'minimal_classic_grid'
                  ? 'border-2 border-slate-900 rounded-none'
                  : currentInvStyle === 'luxury_boutique'
                    ? 'rounded-2xl border-2 p-1.5'
                    : 'rounded-2xl border border-slate-200/90'
              }`}
              style={
                currentInvStyle === 'luxury_boutique'
                  ? { borderColor: palette.primary }
                  : undefined
              }
            >
              <div
                className={
                  currentInvStyle === 'luxury_boutique'
                    ? 'rounded-xl border h-full overflow-hidden'
                    : ''
                }
                style={
                  currentInvStyle === 'luxury_boutique'
                    ? { borderColor: palette.primaryBorder }
                    : undefined
                }
              >
                {(currentInvStyle === 'executive_standard' ||
                  currentInvStyle === 'compact_pos_memo') && (
                  <div className="h-2 w-full" style={{ backgroundColor: palette.primary }} />
                )}

                {currentInvStyle === 'modern_banner_header' && (
                  <div
                    className="p-6 sm:px-9 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    style={{
                      backgroundColor: palette.primarySoft,
                      borderColor: palette.primaryBorder
                    }}
                  >
                    <div className="space-y-1">
                      {draftConfig.showLogo && business.logoUrl ? (
                        <img
                          src={business.logoUrl}
                          alt={draftConfig.brandNameOverride}
                          style={{ height: `${draftConfig.logoHeightPx}px` }}
                          className="w-auto object-contain mb-1.5"
                        />
                      ) : null}
                      <p className="text-base font-black text-slate-900">
                        {draftConfig.brandNameOverride}
                      </p>
                      <p className="text-xs text-slate-600">
                        {draftConfig.storeAddressOverride} · হটলাইন:{' '}
                        <span className="font-mono font-bold text-slate-900">
                          {draftConfig.storePhoneOverride}
                        </span>
                      </p>
                      {domainToShow && (
                        <p
                          className="text-xs font-mono font-bold"
                          style={{ color: palette.primary }}
                        >
                          {domainToShow}
                        </p>
                      )}
                    </div>

                    <div className="sm:text-right space-y-1">
                      <span
                        className="inline-block px-3.5 py-1 rounded-lg text-white text-xs font-extrabold uppercase"
                        style={{ backgroundColor: palette.primary }}
                      >
                        {draftConfig.invoiceTitleText}
                      </span>
                      <p className="text-xs font-mono font-bold text-slate-900 pt-1">
                        ইনভয়েস: {effectiveOrder.invoiceNo} · অর্ডার: #{effectiveOrder.orderNo}
                      </p>
                      <p className="text-xs text-slate-600">
                        তারিখ: {formatDate(effectiveOrder.createdAt)}
                      </p>
                    </div>
                  </div>
                )}

                <div className="p-6 sm:p-9 space-y-6">
                  {currentInvStyle === 'compact_pos_memo' ? (
                    <div className="text-center border-b-2 border-dashed border-slate-200 pb-5 space-y-1.5">
                      {draftConfig.showLogo && business.logoUrl ? (
                        <img
                          src={business.logoUrl}
                          alt={draftConfig.brandNameOverride}
                          style={{ height: `${draftConfig.logoHeightPx}px` }}
                          className="w-auto object-contain mx-auto mb-1"
                        />
                      ) : null}
                      <h2 className="text-xl font-black text-slate-900">
                        {draftConfig.brandNameOverride}
                      </h2>
                      <p className="text-xs text-slate-600">
                        {draftConfig.storeAddressOverride} · হটলাইন:{' '}
                        <span className="font-mono font-bold text-slate-900">
                          {draftConfig.storePhoneOverride}
                        </span>
                        {domainToShow ? ` · ${domainToShow}` : ''}
                      </p>
                      <div className="pt-1">
                        <span
                          className="inline-block px-4 py-1 rounded-full text-white text-xs font-extrabold"
                          style={{ backgroundColor: palette.primary }}
                        >
                          {draftConfig.invoiceTitleText}
                        </span>
                      </div>
                      <p className="text-xs font-mono font-bold text-slate-700 pt-1">
                        ইনভয়েস: {effectiveOrder.invoiceNo} &nbsp;|&nbsp; অর্ডার: #
                        {effectiveOrder.orderNo} &nbsp;|&nbsp; তারিখ:{' '}
                        {formatDate(effectiveOrder.createdAt)}
                      </p>
                    </div>
                  ) : currentInvStyle !== 'modern_banner_header' ? (
                    <div
                      className={`flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 ${
                        currentInvStyle === 'minimal_classic_grid'
                          ? 'border-b-2 border-slate-900'
                          : 'border-b border-slate-200'
                      }`}
                    >
                      <div className="space-y-1.5">
                        {draftConfig.showLogo && business.logoUrl ? (
                          <img
                            src={business.logoUrl}
                            alt={draftConfig.brandNameOverride}
                            style={{ height: `${draftConfig.logoHeightPx}px` }}
                            className="w-auto object-contain mb-2"
                          />
                        ) : (
                          <div>
                            <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                              {draftConfig.brandNameOverride}
                            </h2>
                            {draftConfig.brandTagline && (
                              <p
                                className="text-[11px] font-extrabold tracking-widest uppercase"
                                style={{ color: palette.primary }}
                              >
                                {draftConfig.brandTagline}
                              </p>
                            )}
                          </div>
                        )}

                        <p className="text-sm font-extrabold text-slate-900">
                          {draftConfig.brandNameOverride}
                        </p>
                        {draftConfig.storeAddressOverride && (
                          <p className="text-xs text-slate-600">
                            {draftConfig.storeAddressOverride}
                          </p>
                        )}
                        {draftConfig.storePhoneOverride && (
                          <p className="text-xs font-bold text-slate-800">
                            হটলাইন:{' '}
                            <span className="font-mono">{draftConfig.storePhoneOverride}</span>
                          </p>
                        )}
                        {domainToShow && (
                          <p
                            className="text-xs font-mono font-bold"
                            style={{ color: palette.primary }}
                          >
                            {domainToShow}
                          </p>
                        )}
                      </div>

                      <div className="sm:text-right space-y-1">
                        <h1
                          className="text-lg sm:text-xl font-black tracking-tight"
                          style={{ color: palette.primary }}
                        >
                          {draftConfig.invoiceTitleText}
                        </h1>
                        <p className="text-xs font-mono font-bold text-slate-900">
                          ইনভয়েস নং: {effectiveOrder.invoiceNo}
                        </p>
                        <p className="text-xs font-mono font-bold text-slate-700">
                          অর্ডার নং: #{effectiveOrder.orderNo}
                        </p>
                        <p className="text-xs text-slate-500">
                          তারিখ: {formatDate(effectiveOrder.createdAt)}
                        </p>
                        <div className="pt-1.5">
                          <span
                            className="inline-flex items-center px-3 py-1 rounded-md text-[11px] font-extrabold"
                            style={{
                              backgroundColor:
                                effectiveOrder.paymentStatus === 'paid'
                                  ? '#d1fae5'
                                  : palette.badgeBg,
                              color:
                                effectiveOrder.paymentStatus === 'paid'
                                  ? '#065f46'
                                  : palette.badgeText
                            }}
                          >
                            {effectiveOrder.paymentStatus === 'paid'
                              ? 'পরিশোধিত · PAID'
                              : 'ক্যাশ অন ডেলিভারি · COD'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {/* 2. Two-Column Customer & Order Details Cards */}
                  <div
                    className={
                      currentInvStyle === 'minimal_classic_grid'
                        ? 'grid grid-cols-1 sm:grid-cols-2 border-2 border-slate-900 divide-y sm:divide-y-0 sm:divide-x-2 divide-slate-900'
                        : 'grid grid-cols-1 sm:grid-cols-2 gap-4'
                    }
                  >
                    {/* Left: Bill & Ship To */}
                    <div
                      className={
                        currentInvStyle === 'minimal_classic_grid'
                          ? 'bg-white'
                          : 'rounded-xl border border-slate-200 bg-slate-50/70 overflow-hidden'
                      }
                    >
                      <div
                        className={`px-4 py-2 text-xs font-extrabold ${
                          currentInvStyle === 'minimal_classic_grid'
                            ? 'bg-slate-100 border-b-2 border-slate-900 text-slate-900'
                            : 'border-b border-slate-200/80'
                        }`}
                        style={
                          currentInvStyle !== 'minimal_classic_grid'
                            ? {
                                backgroundColor: palette.primarySoft,
                                color: palette.badgeText
                              }
                            : undefined
                        }
                      >
                        {draftConfig.billToLabelText}
                      </div>
                      <div className="p-4 space-y-1 text-xs">
                        <p className="text-base font-extrabold text-slate-900">
                          {effectiveOrder.customerName}
                        </p>
                        <p
                          className="font-mono font-bold text-sm"
                          style={{ color: palette.primary }}
                        >
                          মোবাইল: {effectiveOrder.customerPhone}
                          {effectiveOrder.alternativePhone
                            ? ` (বিকল্প: ${effectiveOrder.alternativePhone})`
                            : ''}
                        </p>
                        <p className="text-slate-700 font-medium pt-0.5 leading-relaxed">
                          ঠিকানা: {effectiveOrder.deliveryAddress}, {effectiveOrder.deliveryArea}
                        </p>
                      </div>
                    </div>

                    {/* Right: Order & Courier Details (Auto Courier No OR Blank Handwriting Box) */}
                    <div
                      className={
                        currentInvStyle === 'minimal_classic_grid'
                          ? 'bg-white'
                          : 'rounded-xl border border-slate-200 bg-slate-50/70 overflow-hidden'
                      }
                    >
                      <div
                        className={`px-4 py-2 text-xs font-extrabold ${
                          currentInvStyle === 'minimal_classic_grid'
                            ? 'bg-slate-100 border-b-2 border-slate-900 text-slate-900'
                            : 'border-b border-slate-200/80'
                        }`}
                        style={
                          currentInvStyle !== 'minimal_classic_grid'
                            ? {
                                backgroundColor: palette.primarySoft,
                                color: palette.badgeText
                              }
                            : undefined
                        }
                      >
                        {draftConfig.orderInfoLabelText}
                      </div>
                      <div className="p-4 space-y-1.5 text-xs">
                        <p className="text-slate-700 font-semibold">
                          ডেলিভারি জোন:{' '}
                          <span className="font-bold text-slate-900">
                            {effectiveOrder.deliveryArea}
                          </span>
                        </p>
                        <p className="text-slate-700 font-semibold">
                          পেমেন্ট মাধ্যম:{' '}
                          <span className="font-bold text-slate-900">
                            {effectiveOrder.paymentMethod === 'cod'
                              ? 'Cash on Delivery (ক্যাশ অন ডেলিভারি)'
                              : effectiveOrder.paymentMethod.toUpperCase()}
                          </span>
                        </p>

                        {draftConfig.showCourierCnBox !== false && (
                          hasCourierNo ? (
                            <p className="font-mono font-extrabold text-emerald-700">
                              কুরিয়ার (
                              {effectiveOrder.courierProvider === 'pathao' ? 'Pathao' : 'Steadfast'})
                              CN: {courierNoStr}
                            </p>
                          ) : (
                            <div className="flex items-center gap-2 pt-0.5">
                              <span className="font-extrabold text-slate-700 whitespace-nowrap">
                                কুরিয়ার নং (CN):
                              </span>
                              <span className="flex-1 h-6 bg-white rounded border border-slate-400 px-2" />
                            </div>
                          )
                        )}

                        {draftConfig.showCourierBarcode && (
                          <div className="pt-1.5 flex items-center gap-2.5">
                            <div className="inline-flex items-stretch h-7 bg-white px-2 py-1 rounded border border-slate-200 gap-[1px]">
                              {barcodeBars.map((w, idx) => (
                                <span
                                  key={idx}
                                  style={{
                                    width: `${w * 1.2}px`,
                                    backgroundColor: idx % 2 === 0 ? '#0f172a' : 'transparent'
                                  }}
                                />
                              ))}
                            </div>
                            <span className="font-mono text-[11px] font-bold text-slate-600">
                              #{courierNoStr || effectiveOrder.orderNo}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* 3. Standard Clean Item Table */}
                  <div
                    className={
                      currentInvStyle === 'minimal_classic_grid'
                        ? 'border-2 border-slate-900 overflow-hidden'
                        : 'rounded-xl border border-slate-200 overflow-hidden'
                    }
                  >
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr
                          className={
                            currentInvStyle === 'minimal_classic_grid'
                              ? 'bg-slate-100 text-slate-900 font-extrabold border-b-2 border-slate-900'
                              : 'text-white font-bold'
                          }
                          style={
                            currentInvStyle !== 'minimal_classic_grid'
                              ? {
                                  backgroundColor:
                                    currentInvStyle === 'modern_banner_header' ||
                                    currentInvStyle === 'luxury_boutique'
                                      ? palette.primary
                                      : palette.primaryDark
                                }
                              : undefined
                          }
                        >
                          <th className="py-3 px-3.5 w-10">#</th>
                          <th className="py-3 px-3.5">{draftConfig.itemColumnLabel}</th>
                          <th className="py-3 px-3.5 text-center">{draftConfig.qtyColumnLabel}</th>
                          <th className="py-3 px-3.5 text-right">{draftConfig.priceColumnLabel}</th>
                          <th className="py-3 px-3.5 text-right">{draftConfig.totalColumnLabel}</th>
                        </tr>
                      </thead>
                      <tbody
                        className={
                          currentInvStyle === 'minimal_classic_grid'
                            ? 'divide-y divide-slate-900'
                            : 'divide-y divide-slate-200'
                        }
                      >
                        {effectiveOrder.items.map((item, idx) => {
                          const itemImgUrl = draftConfig.showProductImage
                            ? resolveOrderItemImageUrl(item, products)
                            : '';
                          return (
                            <tr
                              key={idx}
                              className={
                                idx % 2 === 1 && currentInvStyle !== 'minimal_classic_grid'
                                  ? 'bg-slate-50/70'
                                  : 'bg-white'
                              }
                            >
                              <td className="py-3 px-3.5 font-mono font-bold text-slate-400">
                                {String(idx + 1).padStart(2, '0')}
                              </td>
                              <td className="py-3 px-3.5">
                                <div className="flex items-center gap-3">
                                  {draftConfig.showProductImage && (
                                    <div className="w-10 h-10 rounded-lg border border-slate-200 bg-slate-50 overflow-hidden shrink-0 flex items-center justify-center">
                                      {itemImgUrl ? (
                                        <img
                                          src={itemImgUrl}
                                          alt={item.productName}
                                          className="w-full h-full object-cover"
                                        />
                                      ) : (
                                        <span className="text-sm">🛍️</span>
                                      )}
                                    </div>
                                  )}
                                  <div>
                                    <div className="font-bold text-slate-900">
                                      <span>{item.productName}</span>
                                      {item.variantLabel && (
                                        <span
                                          className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[11px] font-extrabold"
                                          style={{
                                            backgroundColor: palette.primarySoft,
                                            color: palette.badgeText
                                          }}
                                        >
                                          {item.variantLabel}
                                        </span>
                                      )}
                                    </div>
                                    {draftConfig.showProductSku && (item.variantSku || item.sku) && (
                                      <p className="text-[11px] font-mono text-slate-500 mt-0.5">
                                        SKU: {item.variantSku || item.sku}
                                      </p>
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td className="py-3 px-3.5 text-center font-mono font-bold text-slate-900">
                                {item.quantity}
                              </td>
                              <td className="py-3 px-3.5 text-right font-mono text-slate-700">
                                {formatCurrency(item.unitPrice)}
                              </td>
                              <td className="py-3 px-3.5 text-right font-mono font-extrabold text-slate-900">
                                {formatCurrency(item.total)}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* 4. Summary & Notes Section */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    <div className="md:col-span-7 space-y-3">
                      <div
                        className="p-3.5 rounded-xl border text-xs font-bold"
                        style={{
                          backgroundColor: palette.primarySoft,
                          borderColor: palette.primaryBorder,
                          color: palette.badgeText
                        }}
                      >
                        {draftConfig.codNoticeBannerText}
                      </div>

                      {draftConfig.showOrderNoteOnInvoice !== false && cleanOrderNote && (
                        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-xs space-y-1">
                          <p className="font-extrabold text-amber-950 flex items-center gap-1.5">
                            <FileText className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                            <span>কাস্টমারের অর্ডার নোট (Customer Order Note):</span>
                          </p>
                          <p className="font-bold text-slate-900 leading-relaxed whitespace-pre-wrap">
                            {cleanOrderNote}
                          </p>
                        </div>
                      )}

                      {draftConfig.showTermsSection && draftConfig.termsAndPolicyText && (
                        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                          <p className="font-extrabold text-slate-800">
                            বিশেষ দ্রষ্টব্য / রিটার্ন পলিসি:
                          </p>
                          <p className="text-slate-600 leading-relaxed">
                            {draftConfig.termsAndPolicyText}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="md:col-span-5 space-y-2 text-xs">
                      <div className="flex items-center justify-between py-1 text-slate-600">
                        <span className="font-semibold">{draftConfig.subtotalLabelText}</span>
                        <span className="font-mono font-bold text-slate-900">
                          {formatCurrency(effectiveOrder.subtotal)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between py-1 text-slate-600">
                        <span className="font-semibold">{draftConfig.deliveryLabelText}</span>
                        <span className="font-mono font-bold text-slate-900">
                          {effectiveOrder.deliveryCharge === 0
                            ? 'ফ্রি (৳0)'
                            : formatCurrency(effectiveOrder.deliveryCharge)}
                        </span>
                      </div>

                      {(effectiveOrder.discountAmount || 0) > 0 && (
                        <div className="flex items-center justify-between py-1.5 px-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700">
                          <span className="font-extrabold">{draftConfig.discountLabelText}</span>
                          <span className="font-mono font-black">
                            - {formatCurrency(effectiveOrder.discountAmount)}
                          </span>
                        </div>
                      )}

                      <div
                        className="p-3.5 rounded-xl text-white flex items-center justify-between gap-2 mt-2"
                        style={{ backgroundColor: palette.primary }}
                      >
                        <span className="font-extrabold text-xs">
                          {draftConfig.grandTotalLabelText}
                        </span>
                        <span className="text-base sm:text-lg font-black font-mono tabular-nums">
                          {formatCurrency(effectiveOrder.grandTotal)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 5. Signatures Section */}
                  {draftConfig.showSignatureSection && (
                    <div className="grid grid-cols-2 gap-8 pt-10 pb-2 text-xs text-slate-600">
                      <div className="text-center">
                        <div className="border-t border-slate-400 max-w-[200px] mx-auto pt-2 font-bold">
                          {draftConfig.customerSignatureLabel}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="border-t border-slate-400 max-w-[200px] mx-auto pt-2 font-bold">
                          {draftConfig.authorizedSignatureLabel}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Thank You Footer Strip */}
                <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 text-center space-y-0.5">
                  <p className="text-xs font-extrabold text-slate-900">
                    {draftConfig.thankYouText}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {draftConfig.brandNameOverride} · হটলাইন: {draftConfig.storePhoneOverride}
                    {domainToShow ? ` · ${domainToShow}` : ''}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
