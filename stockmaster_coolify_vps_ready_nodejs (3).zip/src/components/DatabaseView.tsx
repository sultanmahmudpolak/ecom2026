import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Server, ShieldCheck, Copy, Download, FileCode2, BookOpen, Database, Sparkles, CheckCircle2, Wrench, KeyRound, Save, RefreshCw, PhoneCall, MessageSquare, Globe, Upload, ImagePlus, Trash2 } from 'lucide-react';
import { downloadVerifiedZip, downloadSqlFile, getAdminDownloadAuthHeaders } from '../utils/zipDownloader';
import { checkAlphaSmsBalance } from '../utils/smsService';
import { testWordPressConnection, normalizeWpSiteUrl } from '../utils/wordpressOrderSync';
import { processUploadedLogoImage } from '../utils/imageUploader';

const PROJECT_FILES = [
  { path: 'Dockerfile', label: '🚀 Coolify & VPS Production Dockerfile (Dockerfile)' },
  { path: 'docker-compose.yml', label: '🚀 Coolify Docker Compose + Persistent Volumes (docker-compose.yml)' },
  { path: 'deployment/coolify_vps_guide.md', label: '🚀 Coolify ও VPS ডিপ্লয়মেন্ট গাইড (coolify_vps_guide.md)' },
  { path: 'src/db/vpsDatabase.ts', label: '⚡ High-Speed SQLite3 (WAL Mode) + RAM Cache Engine (vpsDatabase.ts)' },
  { path: 'database/cpanel_complete_install.sql', label: '⭐ 1-Click Complete MySQL (database/cpanel_complete_install.sql)' },
  { path: 'backend/api/install.php', label: '⭐ 1-Click Browser Auto-Installer (install.php / api/install.php)' },
  { path: 'public/.htaccess', label: '⭐ cPanel public_html .htaccess (public/.htaccess)' },
  { path: 'database/schema.sql', label: 'MySQL Schema Only (database/schema.sql)' },
  { path: 'database/demo_seed.sql', label: 'MySQL Demo Data Only (database/demo_seed.sql)' },
  { path: 'backend/api/index.php', label: 'PHP Entry Point (backend/api/index.php)' },
  { path: 'backend/api/.htaccess', label: 'PHP API .htaccess (backend/api/.htaccess)' },
  { path: 'backend/config/Database.php', label: 'PDO MySQL Config (backend/config/Database.php)' },
  { path: 'backend/middleware/SecurityMiddleware.php', label: 'Session/CSRF/RBAC (SecurityMiddleware.php)' },
  { path: 'backend/services/TransactionService.php', label: 'ACID, WAC & Customer Ledger Service (TransactionService.php)' },
  { path: 'backend/controllers/ApiController.php', label: 'REST Controller (ApiController.php)' },
  { path: 'deployment/cpanel_deployment_guide.md', label: 'cPanel Beginner Guide (cpanel_deployment_guide.md)' },
  { path: 'deployment/backup_restore_guide.md', label: 'MySQL Backup Guide (backup_restore_guide.md)' },
  { path: 'deployment/environment_configuration_example.txt', label: 'Out-of-Root Env Config (env.php)' },
];

export const DatabaseView: React.FC = () => {
  const { t, language, currentBusiness, updateBusiness, currentUser, showToast, clearWebsiteCache } = useApp();
  const [selectedFile, setSelectedFile] = useState<string>('Dockerfile');
  const [fileContent, setFileContent] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'easy_publish' | 'env_generator' | 'files'>('easy_publish');
  const [isDownloadingZip, setIsDownloadingZip] = useState<boolean>(false);
  const [isDownloadingCoolifyZip, setIsDownloadingCoolifyZip] = useState<boolean>(false);
  const [isRestoringBackup, setIsRestoringBackup] = useState<boolean>(false);
  const restoreInputRef = useRef<HTMLInputElement | null>(null);
  const [vpsDbInfo, setVpsDbInfo] = useState<{
    engine: string;
    walMode: boolean;
    dbFileSizeKb: number;
    nodeVersion: string;
    ramUsedMb: number;
    totalProducts: number;
    totalOrders: number;
    totalCustomers: number;
  } | null>(null);

  // Alpha SMS (api.sms.net.bd) & Product Page WhatsApp/Call Order Quick Setup State for Developer
  const [devSmsKey, setDevSmsKey] = useState(currentBusiness.smsApiKey || '');
  const [devSenderId, setDevSenderId] = useState(currentBusiness.smsSenderId || '');
  const [devSignupOtpRequired, setDevSignupOtpRequired] = useState<boolean>(
    currentBusiness.signupOtpRequired ?? true
  );
  const [devWhatsappPhone, setDevWhatsappPhone] = useState(
    currentBusiness.whatsappOrderPhone || currentBusiness.phone || '01711234567'
  );
  const [devCallOrderPhone, setDevCallOrderPhone] = useState(
    currentBusiness.callOrderPhone || currentBusiness.phone || '01711234567'
  );
  const [devWpSyncEnabled, setDevWpSyncEnabled] = useState<boolean>(
    currentBusiness.wpSyncEnabled ?? true
  );
  const [devWpSiteUrl, setDevWpSiteUrl] = useState<string>(currentBusiness.wpSiteUrl || '');
  const [devWpConsumerKey, setDevWpConsumerKey] = useState<string>(
    currentBusiness.wpConsumerKey || ''
  );
  const [devWpConsumerSecret, setDevWpConsumerSecret] = useState<string>(
    currentBusiness.wpConsumerSecret || ''
  );
  const [devWpOrderStatus, setDevWpOrderStatus] = useState<
    'processing' | 'pending' | 'on-hold' | 'completed'
  >(currentBusiness.wpDefaultOrderStatus || 'processing');
  const [isTestingDevWp, setIsTestingDevWp] = useState<boolean>(false);
  const [devLogoUrl, setDevLogoUrl] = useState<string>(currentBusiness.logoUrl || '');
  const [isUploadingDevLogo, setIsUploadingDevLogo] = useState<boolean>(false);
  const devLogoInputRef = useRef<HTMLInputElement | null>(null);
  const [devFaviconUrl, setDevFaviconUrl] = useState<string>(currentBusiness.faviconUrl || '');
  const [isUploadingDevFavicon, setIsUploadingDevFavicon] = useState<boolean>(false);
  const devFaviconInputRef = useRef<HTMLInputElement | null>(null);
  const [devCreditEnabled, setDevCreditEnabled] = useState<boolean>(
    currentBusiness.developerCreditEnabled !== false
  );
  const [devCreditName, setDevCreditName] = useState<string>(
    currentBusiness.developerCreditName ?? 'Web Studio BD'
  );
  const [devCreditLink, setDevCreditLink] = useState<string>(
    currentBusiness.developerCreditLink ?? 'https://example.com'
  );
  const [devSmsBalance, setDevSmsBalance] = useState<string | null>(null);
  const [isCheckingDevBalance, setIsCheckingDevBalance] = useState(false);

  // Website Cache Clear State (Developer Account)
  const [isClearingCache, setIsClearingCache] = useState<boolean>(false);
  const [cacheSizeKb, setCacheSizeKb] = useState<string>('0 KB');
  const [lastCacheClearedAt, setLastCacheClearedAt] = useState<string>(() => {
    try {
      return window.localStorage.getItem('stockmaster_last_cache_cleared_at') || '';
    } catch {
      return '';
    }
  });

  const calculateBrowserCacheSize = () => {
    try {
      let totalBytes = 0;
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        if (key) {
          const val = window.localStorage.getItem(key) || '';
          totalBytes += (key.length + val.length) * 2;
        }
      }
      for (let i = 0; i < window.sessionStorage.length; i++) {
        const key = window.sessionStorage.key(i);
        if (key) {
          const val = window.sessionStorage.getItem(key) || '';
          totalBytes += (key.length + val.length) * 2;
        }
      }
      setCacheSizeKb(`${Math.max(1, Math.round(totalBytes / 1024))} KB`);
    } catch {
      setCacheSizeKb('N/A');
    }
  };

  useEffect(() => {
    calculateBrowserCacheSize();
  }, []);

  const [activeCacheVersion, setActiveCacheVersion] = useState<string>(() => {
    try {
      return window.localStorage.getItem('sm_client_cache_version_v1') || '';
    } catch {
      return '';
    }
  });

  const handleClearWebsiteCache = async (mode: 'soft_clear' | 'hard_reload' | 'reset_storefront_cache') => {
    setIsClearingCache(true);
    try {
      const result = await clearWebsiteCache(mode);
      if (result?.cacheVersion) {
        setActiveCacheVersion(result.cacheVersion);
      }

      const nowStr = new Date().toLocaleString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
      try {
        window.localStorage.setItem('stockmaster_last_cache_cleared_at', nowStr);
      } catch {
        // Ignore
      }
      setLastCacheClearedAt(nowStr);
      calculateBrowserCacheSize();

      if (mode === 'hard_reload' || mode === 'reset_storefront_cache') {
        showToast(
          mode === 'reset_storefront_cache'
            ? 'সার্ভার ও সকল ভিজিটরের স্টোরফ্রন্ট প্রোডাক্ট ক্যাশ রিসেট ও সিঙ্ক হয়েছে! পেজটি রিলোড হচ্ছে...'
            : 'সার্ভার (OPcache/LiteSpeed) ও সকল ভিজিটরের ব্রাউজার ক্যাশ ক্লিয়ার হয়েছে! পেজটি নতুনভাবে লোড হচ্ছে...',
          'success'
        );
        setTimeout(() => {
          try {
            const url = new URL(window.location.href);
            url.searchParams.set('view', 'database');
            url.searchParams.set('_cb', String(Date.now()));
            window.location.replace(url.toString());
          } catch {
            window.location.reload();
          }
        }, 450);
      } else {
        showToast(
          'সার্ভার (OPcache/LiteSpeed), বুট থিম ও ভিজিটর ব্রাউজার ক্যাশ সফলভাবে ক্লিয়ার ও সিঙ্ক করা হয়েছে!',
          'success'
        );
      }
    } catch {
      showToast('ক্যাশ ক্লিয়ার সম্পন্ন হয়েছে!', 'info');
    } finally {
      setIsClearingCache(false);
    }
  };

  // Live cPanel Readiness Check State
  const [cpanelChecks, setCpanelChecks] = useState<Array<{ id: string; label: string; ready: boolean }>>([]);
  const [isCpanelAllReady, setIsCpanelAllReady] = useState<boolean>(true);

  useEffect(() => {
    setDevSmsKey(currentBusiness.smsApiKey || '');
    setDevSenderId(currentBusiness.smsSenderId || '');
    setDevSignupOtpRequired(currentBusiness.signupOtpRequired ?? true);
    setDevWhatsappPhone(
      currentBusiness.whatsappOrderPhone || currentBusiness.phone || '01711234567'
    );
    setDevCallOrderPhone(
      currentBusiness.callOrderPhone || currentBusiness.phone || '01711234567'
    );
    setDevWpSyncEnabled(currentBusiness.wpSyncEnabled ?? true);
    setDevWpSiteUrl(currentBusiness.wpSiteUrl || '');
    setDevWpConsumerKey(currentBusiness.wpConsumerKey || '');
    setDevWpConsumerSecret(currentBusiness.wpConsumerSecret || '');
    setDevWpOrderStatus(currentBusiness.wpDefaultOrderStatus || 'processing');
    setDevLogoUrl(currentBusiness.logoUrl || '');
    setDevFaviconUrl(currentBusiness.faviconUrl || '');
    setDevCreditEnabled(currentBusiness.developerCreditEnabled !== false);
    setDevCreditName(currentBusiness.developerCreditName ?? 'Web Studio BD');
    setDevCreditLink(currentBusiness.developerCreditLink ?? 'https://example.com');
  }, [currentBusiness]);

  useEffect(() => {
    fetch('/api/db-status', {
      credentials: 'same-origin'
    })
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          setVpsDbInfo({
            engine: data.engine || 'SQLite3 (WAL Mode) + Node.js RAM Cache',
            walMode: data.walMode !== false,
            dbFileSizeKb: Number(data.dbFileSizeKb || 88),
            nodeVersion: data.nodeVersion || 'v22 LTS',
            ramUsedMb: Number(data.ramUsedMb || 0),
            totalProducts: Number(data.totalProducts || 0),
            totalOrders: Number(data.totalOrders || 0),
            totalCustomers: Number(data.totalCustomers || 0)
          });
        }
      })
      .catch(() => {});

    fetch('/api/cpanel-readiness', {
      headers: getAdminDownloadAuthHeaders(),
      credentials: 'same-origin'
    })
      .then(res => res.json())
      .then(data => {
        if (data && Array.isArray(data.checks)) {
          setCpanelChecks(data.checks);
          setIsCpanelAllReady(Boolean(data.allReady));
        }
      })
      .catch(() => {
        // Fallback when running on static hosting
      });
  }, []);

  const handleDownloadJsonBackup = async () => {
    try {
      const res = await fetch('/api/vps-backup-json', {
        headers: getAdminDownloadAuthHeaders(),
        credentials: 'same-origin'
      });
      if (!res.ok) throw new Error('Backup download failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `stockmaster_full_backup_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('✅ সম্পূর্ণ ডাটাবেস ব্যাকআপ (.json) সফলভাবে ডাউনলোড হয়েছে!', 'success');
    } catch {
      showToast('ব্যাকআপ ডাউনলোড করতে সমস্যা হয়েছে', 'error');
    }
  };

  const handleDownloadSqliteBackup = async () => {
    try {
      const res = await fetch('/api/vps-backup-sqlite', {
        headers: getAdminDownloadAuthHeaders(),
        credentials: 'same-origin'
      });
      if (!res.ok) throw new Error('SQLite download failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `stockmaster_vps_${dateStr}.sqlite`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('⚡ High-Speed SQLite (WAL) ডাটাবেস ফাইল (.sqlite) ডাউনলোড হয়েছে!', 'success');
    } catch {
      showToast('SQLite ডাটাবেস ডাউনলোড করতে সমস্যা হয়েছে', 'error');
    }
  };

  const handleRestoreBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsRestoringBackup(true);
    try {
      const rawText = await file.text();
      const parsed = JSON.parse(rawText);
      const res = await fetch('/api/vps-restore-json', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminDownloadAuthHeaders()
        },
        credentials: 'same-origin',
        body: JSON.stringify({ backupData: parsed })
      });
      const result = await res.json();
      if (!res.ok || !result?.success) {
        throw new Error(result?.error || 'Restore failed');
      }
      showToast(
        `✅ ডাটাবেস সফলভাবে রিস্টোর হয়েছে (${result.totalProducts} প্রোডাক্ট, ${result.totalOrders} অর্ডার)! পেজ রিলোড হচ্ছে...`,
        'success'
      );
      setTimeout(() => {
        window.location.reload();
      }, 900);
    } catch (err: any) {
      showToast(err?.message || 'সঠিক .json ব্যাকআপ ফাইল সিলেক্ট করুন', 'error');
    } finally {
      setIsRestoringBackup(false);
      e.target.value = '';
    }
  };

  // Interactive env.php generator state for non-programmers
  const [dbHost, setDbHost] = useState('localhost');
  const [dbName, setDbName] = useState('cpaneluser_stockmaster');
  const [dbUser, setDbUser] = useState('cpaneluser_admin');
  const [dbPass, setDbPass] = useState('');

  useEffect(() => {
    fetch(`/api/project-file?path=${encodeURIComponent(selectedFile)}`, {
      headers: getAdminDownloadAuthHeaders(),
      credentials: 'same-origin'
    })
      .then(res => {
        if (!res.ok) throw new Error('Unauthorized or not found');
        return res.text();
      })
      .then(text => setFileContent(text))
      .catch(() => setFileContent('-- শুধুমাত্র লগইন করা অ্যাডমিন/ডেভেলপার এই ফাইল প্রিভিউ দেখতে পারবেন --'));
  }, [selectedFile]);

  const copyContent = () => {
    if (fileContent) {
      navigator.clipboard.writeText(fileContent);
      showToast(
        language === 'bn' ? `${selectedFile} ক্লিপবোর্ডে কপি করা হয়েছে!` : `Copied ${selectedFile} to clipboard!`,
        'info'
      );
    }
  };

  const generatedEnvPhp = `<?php
/**
 * StockMaster BD - MySQL Connection Config for cPanel
 * Upload to: /home/YOUR_CPANEL_USER/stockmaster_config/env.php
 * OR inside: public_html/backend/config/env.php
 */
return [
    'DB_HOST'  => '${dbHost.replace(/'/g, "\\'")}',
    'DB_PORT'  => '3306',
    'DB_NAME'  => '${dbName.replace(/'/g, "\\'")}',
    'DB_USER'  => '${dbUser.replace(/'/g, "\\'")}',
    'DB_PASS'  => '${dbPass.replace(/'/g, "\\'")}',
    'APP_ENV'  => 'production',
    'TIMEZONE' => 'Asia/Dhaka',
];
`;

  const downloadGeneratedEnv = () => {
    const blob = new Blob([generatedEnvPhp], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'env.php';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(
      language === 'bn'
        ? 'আপনার রেডিমেড env.php ফাইল ডাউনলোড হয়েছে!'
        : 'Your custom env.php file has been downloaded!',
      'success'
    );
  };

  if (currentUser.role !== 'developer') {
    return (
      <div className="bg-white rounded-2xl border border-rose-200 p-8 max-w-lg mx-auto my-12 text-center space-y-3 shadow-xs">
        <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-extrabold text-slate-900">
          শুধুমাত্র ডেভেলপার অ্যাকাউন্টের জন্য সংরক্ষিত (Developer Access Only)
        </h2>
        <p className="text-xs text-slate-600 leading-relaxed">
          cPanel ও MySQL কনফিগারেশন মডিউলটি শুধুমাত্র সিস্টেম ডেভেলপার অ্যাকাউন্ট থেকে প্রদর্শনযোগ্য।
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & 1-Click Quick Downloads (Coolify / VPS Ready + cPanel Compatible) */}
      <div className="bg-gradient-to-r from-[#041f1e] via-[#063834] to-[#0f172a] text-white p-6 rounded-2xl shadow-md border border-teal-700/60 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-[11px] font-extrabold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                🚀 Coolify ও VPS Ready (Pure Node.js 22 + React + High-Speed SQLite WAL + RAM Cache)
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
              Coolify / VPS ডিপ্লয়মেন্ট ও ফাস্ট ডাটাবেস কন্ট্রোল সেন্টার
            </h1>
            <p className="text-xs sm:text-sm text-teal-100/85 max-w-2xl leading-relaxed">
              আপনার সাইট এখন সম্পূর্ণ <strong>Pure Node.js + SQLite3 (WAL Mode) + 0.1ms RAM Cache</strong> ইঞ্জিনে চলছে—কোনো ডাটাবেস কানেকশন ঝামেলা ছাড়াই সরাসরি Coolify বা যেকোনো VPS-এ ১-ক্লিকে হোস্ট করতে পারবেন এবং ভবিষ্যতে যেকোনো সময় PostgreSQL বা cPanel-এও ডাটা ট্রান্সফার করতে পারবেন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              disabled={isDownloadingCoolifyZip}
              onClick={async () => {
                setIsDownloadingCoolifyZip(true);
                await downloadVerifiedZip(
                  '/api/download-coolify-zip',
                  'stockmaster_coolify_vps_ready_nodejs.zip',
                  showToast
                );
                setIsDownloadingCoolifyZip(false);
              }}
              className="px-4 py-2.5 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-60 text-slate-950 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <Server className="w-4 h-4" />
              <span>
                {isDownloadingCoolifyZip
                  ? 'Coolify প্যাকেজ তৈরি হচ্ছে...'
                  : '🚀 ১-ক্লিক Coolify / VPS রেডি জিপ (.zip)'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleDownloadJsonBackup}
              className="px-4 py-2.5 bg-teal-500/25 hover:bg-teal-500/35 text-teal-100 border border-teal-400/40 rounded-xl text-xs font-extrabold flex items-center gap-2 transition-colors cursor-pointer"
              title="এই ব্যাকআপ ফাইল দিয়ে যেকোনো নতুন VPS, PostgreSQL বা cPanel-এ ১-ক্লিকে সব ডাটা রিস্টোর করতে পারবেন"
            >
              <Download className="w-4 h-4 text-teal-300" />
              <span>১-ক্লিক ফুল ডাটাবেস ব্যাকআপ (.json)</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadSqliteBackup}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Database className="w-4 h-4 text-emerald-300" />
              <span>SQLite WAL (.sqlite)</span>
            </button>

            <input
              ref={restoreInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleRestoreBackupFile}
              className="hidden"
            />
            <button
              type="button"
              disabled={isRestoringBackup}
              onClick={() => restoreInputRef.current?.click()}
              className="px-3.5 py-2.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{isRestoringBackup ? 'রিস্টোর হচ্ছে...' : 'ডাটাবেস রিস্টোর (.json)'}</span>
            </button>
          </div>
        </div>

        {/* Secondary cPanel / Legacy Export Row (Future Portability) */}
        <div className="pt-3 border-t border-teal-700/50 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="text-teal-200/90 font-semibold">
            🔄 ভবিষ্যতে আবার cPanel বা MySQL-এ সাইট নিতে চাইলে নিচের বাটনগুলো সবসময় রেডি থাকবে:
          </span>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={isDownloadingZip}
              onClick={async () => {
                setIsDownloadingZip(true);
                await downloadVerifiedZip(
                  '/api/download-cpanel-zip',
                  'stockmaster_cpanel_ready_public_html.zip',
                  showToast
                );
                setIsDownloadingZip(false);
              }}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg text-[11px] font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-teal-300" />
              <span>{isDownloadingZip ? 'তৈরি হচ্ছে...' : 'cPanel রেডি জিপ (.zip)'}</span>
            </button>

            <button
              type="button"
              disabled={isDownloadingZip}
              onClick={async () => {
                setIsDownloadingZip(true);
                await downloadVerifiedZip(
                  '/api/download-source-zip',
                  'stockmaster_full_source_code.zip',
                  showToast
                );
                setIsDownloadingZip(false);
              }}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg text-[11px] font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-teal-300" />
              <span>সম্পূর্ণ মেইন সোর্স কোড (.zip)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                downloadSqlFile(
                  'database/cpanel_complete_install.sql',
                  'cpanel_complete_install.sql',
                  showToast
                )
              }
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg text-[11px] font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Database className="w-3.5 h-3.5 text-teal-300" />
              <span>MySQL ফাইল (.sql)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Coolify 3-Step Quick Deployment & Live SQLite WAL Status Card */}
      <div className="bg-emerald-50/80 rounded-2xl border-2 border-emerald-300/90 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-emerald-700" />
            <h2 className="text-xs sm:text-sm font-extrabold text-emerald-950">
              ⚡ Live VPS Database ইঞ্জিন ও Coolify ৩-ধাপ সেটআপ গাইড (Zero Database Config)
            </h2>
          </div>
          <span className="px-3 py-1 rounded-full text-[11px] font-extrabold bg-emerald-600 text-white">
            ✓ {vpsDbInfo?.engine || 'SQLite3 (WAL Mode) + Node.js RAM Cache'} সচল
          </span>
        </div>

        {/* Live Engine Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          <div className="p-3 rounded-xl bg-white border border-emerald-200">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">ডাটাবেস ইঞ্জিন</span>
            <span className="font-extrabold text-emerald-800 text-xs">SQLite3 WAL + RAM (0.1ms)</span>
          </div>
          <div className="p-3 rounded-xl bg-white border border-emerald-200">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">ডাটাবেস সাইজ ও রেকর্ড</span>
            <span className="font-extrabold text-slate-900 font-mono text-xs">
              {vpsDbInfo ? `${vpsDbInfo.dbFileSizeKb} KB (${vpsDbInfo.totalProducts} পণ্য, ${vpsDbInfo.totalOrders} অর্ডার)` : 'Auto-Synced'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-white border border-emerald-200">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">Coolify Build Pack</span>
            <span className="font-extrabold text-blue-800 font-mono text-xs">Dockerfile / Docker Compose</span>
          </div>
          <div className="p-3 rounded-xl bg-white border border-emerald-200">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">এক্সপোজড পোর্ট (Port)</span>
            <span className="font-extrabold text-slate-900 font-mono text-xs">3000 (Auto Healthcheck)</span>
          </div>
        </div>

        {/* 3 Easy Steps for Coolify */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200/90 space-y-1">
            <p className="font-extrabold text-emerald-950">ধাপ ১: গিটহাব বা জিপ আপলোড</p>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              উপরের <strong>&quot;১-ক্লিক Coolify / VPS রেডি জিপ&quot;</strong> ডাউনলোড করে আপনার GitHub রিপোজিটরিতে দিন এবং Coolify-তে <strong>Dockerfile</strong> বা <strong>Docker Compose</strong> হিসেবে কানেক্ট করুন।
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200/90 space-y-1.5">
            <p className="font-extrabold text-emerald-950">ধাপ ২: Persistent Volume পাথ (জরুরি)</p>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Coolify-এর <strong>Storages</strong> অপশনে নিচের ২টি Destination Path যোগ করুন যাতে রিবিল্ড করলেও ডাটা ও ছবি না মুছে যায়:
            </p>
            <div className="flex flex-wrap gap-1.5 pt-0.5">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText('/app/data');
                  showToast('/app/data ক্লিপবোর্ডে কপি হয়েছে!', 'info');
                }}
                className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-900 font-mono font-bold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <span>/app/data</span>
                <Copy className="w-3 h-3 text-slate-500" />
              </button>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText('/app/uploads');
                  showToast('/app/uploads ক্লিপবোর্ডে কপি হয়েছে!', 'info');
                }}
                className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-900 font-mono font-bold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <span>/app/uploads</span>
                <Copy className="w-3 h-3 text-slate-500" />
              </button>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-emerald-200/90 space-y-1">
            <p className="font-extrabold text-emerald-950">ধাপ ৩: ডোমেইন ও ১-ক্লিক Deploy</p>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Coolify-তে আপনার ডোমেইন (`https://yourdomain.com`) এবং Port `3000` বসিয়ে <strong>Deploy</strong> চাপুন। কোনো আলাদা ডাটাবেস কানেক্ট করতে হবে না—সব অটোমেটিক চলবে!
            </p>
          </div>
        </div>
      </div>

      {/* Developer Storefront Header Logo Upload & Change Card */}
      <div className="bg-white rounded-2xl border-2 border-amber-500/40 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0">
              <ImagePlus className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                ওয়েবসাইট লোগো (Header Banner Logo) আপলোড ও পরিবর্তন (Developer Control)
              </h2>
              <p className="text-[11px] text-slate-500">
                ফ্রন্ট ওয়েবসাইটের উপরে বাম পাশে শপের নামের জায়গায় থাকা ডেমো লোগো পরিবর্তন করে আপনার নিজস্ব লোগো (PNG / JPG / WebP / SVG) এখানে আপলোড করুন
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px] font-extrabold">
            সাজেশন সাইজ: 340 × 68 px (Horizontal Logo)
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center text-xs">
          {/* Live Horizontal Logo Preview Box (Exact Header Proportion) */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-300">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              হেডার লোগো লাইভ প্রিভিউ
            </span>
            <div className="h-12 sm:h-14 px-4 py-1.5 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-center min-w-[120px]">
              {devLogoUrl && devLogoUrl.trim() !== '' ? (
                <img
                  src={devLogoUrl}
                  alt="Storefront Logo Preview"
                  className="h-9 sm:h-11 w-auto max-w-[240px] sm:max-w-[280px] object-contain"
                />
              ) : (
                <span className="text-slate-400 text-xs italic">কোনো লোগো নেই (ফাঁকা)</span>
              )}
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 mt-2">
              {devLogoUrl && devLogoUrl.trim() !== '' ? '✓ আপনার কাস্টম লোগো সেট করা আছে' : 'বর্তমানে কোনো লোগো নেই (ফাঁকা থাকবে)'}
            </span>
          </div>

          {/* Upload & URL Controls */}
          <div className="lg:col-span-7 space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <input
                ref={devLogoInputRef}
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setIsUploadingDevLogo(true);
                  try {
                    const dataUrl = await processUploadedLogoImage(file, 720, 220);
                    setDevLogoUrl(dataUrl);
                    updateBusiness({ logoUrl: dataUrl });
                    showToast('আপনার নতুন ওয়েবসাইট লোগো সফলভাবে আপলোড ও সেভ হয়েছে!', 'success');
                  } catch (err: any) {
                    showToast(err?.message || 'লোগো আপলোড করতে সমস্যা হয়েছে', 'error');
                  } finally {
                    setIsUploadingDevLogo(false);
                    e.target.value = '';
                  }
                }}
                className="hidden"
              />

              <button
                type="button"
                disabled={isUploadingDevLogo}
                onClick={() => devLogoInputRef.current?.click()}
                className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-extrabold rounded-xl flex items-center gap-2 shadow-2xs cursor-pointer transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>
                  {isUploadingDevLogo
                    ? 'লোগো আপলোড হচ্ছে...'
                    : 'কম্পিউটার / মোবাইল থেকে লোগো আপলোড করুন'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const animatedUrl = '/uploads/logos/smart_look_animated_logo.svg?v=cb3';
                  setDevLogoUrl(animatedUrl);
                  updateBusiness({ logoUrl: animatedUrl });
                  showToast('✨ Cool Blue "Smart Look" অ্যানিমেটেড লোগো সেট করা হয়েছে!', 'success');
                }}
                className="px-3.5 py-2.5 bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-300 font-extrabold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
              >
                <Sparkles className="w-4 h-4 text-sky-600" />
                <span>✨ Smart Look (Cool Blue Eyes) লোগো</span>
              </button>

              {devLogoUrl && (
                <>
                  <a
                    href={devLogoUrl}
                    download={devLogoUrl.split('/').pop() || 'smart_look_animated_logo.svg'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2.5 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 font-extrabold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>লোগো ডাউনলোড করুন</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      setDevLogoUrl('');
                      updateBusiness({ logoUrl: '' });
                      showToast('কাস্টম লোগো রিমুভ করা হয়েছে (এখন লোগোর জায়গা ফাঁকা থাকবে)', 'info');
                    }}
                    className="px-3.5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-extrabold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>লোগো রিমুভ করুন (ফাঁকা রাখুন)</span>
                  </button>
                </>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                updateBusiness({ logoUrl: devLogoUrl.trim() });
                showToast('ওয়েবসাইটের লোগো সফলভাবে সংরক্ষিত হয়েছে!', 'success');
              }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2"
            >
              <input
                type="text"
                value={devLogoUrl.startsWith('data:') ? '' : devLogoUrl}
                onChange={(e) => setDevLogoUrl(e.target.value)}
                placeholder="অথবা সরাসরি লোগো ছবির লিংক (https://.../logo.png) এখানে পেস্ট করুন..."
                className="flex-1 min-h-[40px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
              />
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>লোগো সেভ করুন</span>
              </button>
            </form>

            {/* Master Preloader / Splash Screen ON/OFF + Shimmer Product Card Skeleton Grid ON/OFF Controls */}
            <div className="pt-2 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-teal-50/80 border border-teal-200">
                <div className="space-y-0.5">
                  <p className="text-xs font-extrabold text-teal-950">
                    🚀 সম্পূর্ণ প্রিলোডার / স্প্ল্যাশ স্ক্রিন (Master Preloader ON / OFF)
                  </p>
                  <p className="text-[11px] text-teal-800/90">
                    {currentBusiness.preloaderEnabled !== false
                      ? 'চালু আছে (ON): ওয়েবসাইটে ঢুকলে প্রিলোডার / স্প্ল্যাশ স্ক্রিন দেখাবে।'
                      : 'বন্ধ আছে (OFF): কোনো প্রিলোডার স্ক্রিন আসবে না — সরাসরি হোম স্ক্রিন ওপেন হবে এবং প্রোডাক্টের ছবিগুলো Lazy Load হবে!'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = currentBusiness.preloaderEnabled === false ? true : false;
                    updateBusiness({ preloaderEnabled: nextState });
                    showToast(
                      nextState
                        ? 'প্রিলোডার / স্প্ল্যাশ স্ক্রিন চালু (ON) করা হয়েছে!'
                        : 'প্রিলোডার বন্ধ (OFF) করা হয়েছে! এখন সরাসরি হোম স্ক্রিন লোড হবে।',
                      'success'
                    );
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer shrink-0 shadow-2xs ${
                    currentBusiness.preloaderEnabled !== false
                      ? 'bg-teal-700 hover:bg-teal-800 text-white'
                      : 'bg-rose-600 hover:bg-rose-700 text-white'
                  }`}
                >
                  {currentBusiness.preloaderEnabled !== false
                    ? '✓ প্রিলোডার স্ক্রিন: চালু (ON)'
                    : '✕ প্রিলোডার স্ক্রিন: বন্ধ (OFF — সরাসরি হোম)'}
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
                <div className="space-y-0.5">
                  <p className="text-xs font-extrabold text-emerald-950">
                    ✨ শিমার প্রোডাক্ট স্কেলিটন গ্রিড (Shimmer Skeleton Grid — আলাদা ON / OFF)
                  </p>
                  <p className="text-[11px] text-emerald-800/90">
                    {currentBusiness.preloaderShimmerEnabled !== false
                      ? currentBusiness.preloaderEnabled === false
                        ? 'চালু আছে (ON): প্রিলোডার OFF থাকায় সরাসরি ওয়েবসাইটে ঢুকবে এবং প্রোডাক্ট লোড হওয়া পর্যন্ত Shimmer Skeleton Grid দেখাবে।'
                        : 'চালু আছে (ON): লোডিং স্ক্রিনে ও প্রোডাক্ট লোড হওয়ার সময় প্রোডাক্ট কার্ডের Shimmer Skeleton Grid ইফেক্ট দেখাবে।'
                      : 'বন্ধ আছে (OFF): কোনো Shimmer Skeleton Grid দেখাবে না।'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = currentBusiness.preloaderShimmerEnabled === false ? true : false;
                    updateBusiness({ preloaderShimmerEnabled: nextState });
                    showToast(
                      nextState
                        ? 'শিমার প্রোডাক্ট স্কেলিটন গ্রিড (Shimmer Skeleton Grid) চালু (ON) করা হয়েছে!'
                        : 'শিমার প্রোডাক্ট স্কেলিটন গ্রিড বন্ধ (OFF) করা হয়েছে!',
                      'success'
                    );
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer shrink-0 shadow-2xs ${
                    currentBusiness.preloaderShimmerEnabled !== false
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                  }`}
                >
                  {currentBusiness.preloaderShimmerEnabled !== false
                    ? '✓ শিমার স্কেলিটন গ্রিড: চালু (ON)'
                    : '✕ শিমার স্কেলিটন গ্রিড: বন্ধ (OFF)'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Favicon Upload & Preview right inside the Logo Card */}
        <div className="pt-4 border-t border-slate-200 grid grid-cols-1 lg:grid-cols-12 gap-4 items-center text-xs">
          <div className="lg:col-span-5 flex items-center gap-3 p-3.5 rounded-2xl bg-indigo-50/50 border border-indigo-200">
            <div className="w-12 h-12 rounded-xl bg-white border border-indigo-200 flex items-center justify-center p-1.5 shrink-0 shadow-2xs">
              {devFaviconUrl && devFaviconUrl.trim() !== '' ? (
                <img
                  src={devFaviconUrl}
                  alt="Favicon Preview"
                  className="w-8 h-8 object-contain rounded"
                />
              ) : devLogoUrl && devLogoUrl.trim() !== '' ? (
                <img
                  src={devLogoUrl}
                  alt="Favicon Preview"
                  className="w-8 h-8 object-contain rounded"
                />
              ) : (
                <span className="text-[10px] text-slate-400 italic">None</span>
              )}
            </div>
            <div>
              <span className="text-xs font-extrabold text-indigo-950 block">
                ওয়েবসাইট ফেভিকন (Favicon / ব্রাউজার ট্যাব আইকন)
              </span>
              <span className="text-[11px] text-indigo-800/80 block mt-0.5">
                {devFaviconUrl && devFaviconUrl.trim() !== ''
                  ? '✓ কাস্টম ফেভিকন সেট করা আছে'
                  : 'ডিফল্টভাবে স্টোর লোগো ফেভিকন হিসেবে ব্যবহৃত হচ্ছে'}
              </span>
            </div>
          </div>

          <div className="lg:col-span-7 flex flex-wrap items-center gap-2">
            <input
              ref={devFaviconInputRef}
              type="file"
              accept="image/*,.ico"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                setIsUploadingDevFavicon(true);
                try {
                  const dataUrl = await processUploadedLogoImage(file, 128, 128);
                  setDevFaviconUrl(dataUrl);
                  updateBusiness({ faviconUrl: dataUrl });
                  showToast('ওয়েবসাইট ফেভিকন (Favicon) সফলভাবে আপলোড ও সেভ হয়েছে!', 'success');
                } catch (err: any) {
                  showToast(err?.message || 'ফেভিকন আপলোড করতে সমস্যা হয়েছে', 'error');
                } finally {
                  setIsUploadingDevFavicon(false);
                  e.target.value = '';
                }
              }}
              className="hidden"
            />

            <button
              type="button"
              disabled={isUploadingDevFavicon}
              onClick={() => devFaviconInputRef.current?.click()}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-extrabold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>
                {isUploadingDevFavicon ? 'আপলোড হচ্ছে...' : 'ফেভিকন আইকন আপলোড করুন'}
              </span>
            </button>

            <input
              type="text"
              value={devFaviconUrl.startsWith('data:') ? '' : devFaviconUrl}
              onChange={(e) => setDevFaviconUrl(e.target.value)}
              placeholder="অথবা ফেভিকন লিংক (URL) দিন..."
              className="flex-1 min-w-[180px] min-h-[38px] px-3 py-1.5 bg-slate-50 border border-slate-300 focus:border-indigo-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
            />

            <button
              type="button"
              onClick={() => {
                updateBusiness({ faviconUrl: devFaviconUrl.trim() || undefined });
                showToast('ফেভিকন সংরক্ষিত হয়েছে!', 'success');
              }}
              className="min-h-[38px] px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>সেভ</span>
            </button>

            {devFaviconUrl && (
              <button
                type="button"
                onClick={() => {
                  setDevFaviconUrl('');
                  updateBusiness({ faviconUrl: undefined });
                  showToast('কাস্টম ফেভিকন মুছে ফেলা হয়েছে', 'info');
                }}
                className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl cursor-pointer"
                title="ফেভিকন মুছুন"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Developer Footer Credit Control Card (E-Commerce Website & Landing Page Footer — ON/OFF, Name & Link) */}
      <div className="bg-white rounded-2xl border-2 border-emerald-500/40 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center shrink-0">
              <Globe className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                ওয়েবসাইট ও ল্যান্ডিং পেজ ফুটার ডেভেলপার ক্রেডিট (Footer Developer Credit — ON/OFF, Name & Link)
              </h2>
              <p className="text-[11px] text-slate-500">
                ই-কমার্স ওয়েবসাইট এবং ল্যান্ডিং পেজের ফুটারে ডেভেলপার ক্রেডিট দেখানো চালু (ON) বা বন্ধ (OFF) করুন এবং নাম ও লিংক পরিবর্তন করুন
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              const nextVal = !devCreditEnabled;
              setDevCreditEnabled(nextVal);
              updateBusiness({
                developerCreditEnabled: nextVal,
                developerCreditName: devCreditName.trim(),
                developerCreditLink: devCreditLink.trim()
              });
              showToast(
                nextVal
                  ? 'ফুটার ডেভেলপার ক্রেডিট চালু (ON) করা হয়েছে!'
                  : 'ফুটার ডেভেলপার ক্রেডিট বন্ধ (OFF) করা হয়েছে!',
                nextVal ? 'success' : 'info'
              );
            }}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-colors ${
              devCreditEnabled
                ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{devCreditEnabled ? 'ডেভেলপার ক্রেডিট চালু আছে (ON)' : 'ডেভেলপার ক্রেডিট বন্ধ আছে (OFF)'}</span>
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            updateBusiness({
              developerCreditEnabled: devCreditEnabled,
              developerCreditName: devCreditName.trim(),
              developerCreditLink: devCreditLink.trim()
            });
            showToast(
              'ডেভেলপার ক্রেডিট নাম ও লিংক ওয়েবসাইট এবং ল্যান্ডিং পেজ ফুটারে সংরক্ষিত হয়েছে!',
              'success'
            );
          }}
          className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end text-xs"
        >
          <div className="md:col-span-5">
            <label className="block font-bold text-slate-700 mb-1">
              ডেভেলপারের নাম (Developer Name):
            </label>
            <input
              type="text"
              value={devCreditName}
              onChange={(e) => setDevCreditName(e.target.value)}
              placeholder="যেমন: Web Studio BD"
              className="w-full min-h-[40px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-bold text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-5">
            <label className="block font-bold text-slate-700 mb-1">
              ডেভেলপার লিংক (Website / Profile Link):
            </label>
            <input
              type="text"
              value={devCreditLink}
              onChange={(e) => setDevCreditLink(e.target.value)}
              placeholder="https://yourwebsite.com"
              className="w-full min-h-[40px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full min-h-[40px] px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>সেভ করুন</span>
            </button>
          </div>
        </form>
      </div>

      {/* Developer Website Cache Clear & Force Refresh Card */}
      <div className="bg-white rounded-2xl border-2 border-rose-500/35 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center shrink-0">
              <RefreshCw className={`w-4.5 h-4.5 ${isClearingCache ? 'animate-spin' : ''}`} />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                ওয়েবসাইট ক্যাশ ক্লিয়ার ও হার্ড রিফ্রেশ (Website Cache Clear - Developer Control)
              </h2>
              <p className="text-[11px] text-slate-500">
                ওয়েবসাইটের ডিজাইন, লোগো, বাটন বা পণ্যের ভেরিয়েশন পরিবর্তন করার পর ব্রাউজারে পুরাতন ক্যাশ আটকে থাকলে ১-ক্লিকে ক্যাশ ক্লিয়ার করুন
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[11px]">
            <span className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-700 font-mono font-bold">
              ব্রাউজার স্টোরেজ: {cacheSizeKb}
            </span>
            {activeCacheVersion && (
              <span className="px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-800 font-mono font-bold">
                ভার্সন: {activeCacheVersion}
              </span>
            )}
            {lastCacheClearedAt && (
              <span className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold">
                সর্বশেষ ক্লিয়ার: {lastCacheClearedAt}
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {/* Option 1: Instant Cache Clear (No Reload) */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/90 flex flex-col justify-between space-y-3">
            <div className="space-y-1">
              <span className="font-extrabold text-slate-900 block">
                ১. কুইক ক্যাশ ক্লিয়ার (ডাটা অক্ষুণ্ণ রেখে)
              </span>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                আপনার সকল পণ্য, অর্ডার, লোগো ও API সেটিংস ১০০% ঠিক রেখে ব্রাউজারের টেম্পোরারি ক্যাশ ও সেশন পরিষ্কার করবে।
              </p>
            </div>
            <button
              type="button"
              disabled={isClearingCache}
              onClick={() => handleClearWebsiteCache('soft_clear')}
              className="w-full min-h-[40px] py-2 px-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isClearingCache ? 'animate-spin' : ''}`} />
              <span>১-ক্লিক ক্যাশ ক্লিয়ার করুন</span>
            </button>
          </div>

          {/* Option 2: Cache Clear + Hard Reload */}
          <div className="p-3.5 rounded-xl bg-rose-50/50 border border-rose-200/80 flex flex-col justify-between space-y-3">
            <div className="space-y-1">
              <span className="font-extrabold text-rose-950 block">
                ২. ক্যাশ ক্লিয়ার + ওয়েবসাইট হার্ড রিলোড
              </span>
              <p className="text-[11px] text-rose-800/90 leading-relaxed">
                সকল ব্রাউজার ক্যাশ ক্লিয়ার করে ওয়েবসাইটটি নতুনভাবে রিলোড করবে যাতে নতুন পরিবর্তন সাথে সাথে লাইভ দেখায়।
              </p>
            </div>
            <button
              type="button"
              disabled={isClearingCache}
              onClick={() => handleClearWebsiteCache('hard_reload')}
              className="w-full min-h-[40px] py-2 px-3 bg-[#c30000] hover:bg-[#9e0000] disabled:opacity-60 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isClearingCache ? 'animate-spin' : ''}`} />
              <span>ক্যাশ ক্লিয়ার ও পেজ রিলোড</span>
            </button>
          </div>

          {/* Option 3: Storefront Product/Category Cache Reset (Preserving Developer Config) */}
          <div className="p-3.5 rounded-xl bg-amber-50/50 border border-amber-200/90 flex flex-col justify-between space-y-3">
            <div className="space-y-1">
              <span className="font-extrabold text-amber-950 block">
                ৩. স্টোরফ্রন্ট প্রোডাক্ট ক্যাশ সিঙ্ক (সেটিংস রেখে)
              </span>
              <p className="text-[11px] text-amber-900/80 leading-relaxed">
                লোগো, নম্বর ও API অক্ষুণ্ণ রেখে পুরাতন ক্যাশ হওয়া ডেমো প্রোডাক্ট মুছে নতুন ফ্যাশন ও বেবি ড্রেস ভেরিয়েশন লোড করবে।
              </p>
            </div>
            <button
              type="button"
              disabled={isClearingCache}
              onClick={() => handleClearWebsiteCache('reset_storefront_cache')}
              className="w-full min-h-[40px] py-2 px-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5 text-amber-400" />
              <span>পুরাতন প্রোডাক্ট ক্যাশ রিসেট</span>
            </button>
          </div>
        </div>
      </div>

      {/* Developer Quick SMS API Setup Card (api.sms.net.bd) */}
      <div className="bg-white rounded-2xl border border-teal-200 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 border border-teal-200 flex items-center justify-center shrink-0">
              <KeyRound className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                Alpha SMS Gateway (https://api.sms.net.bd) API সেটআপ ও সাইনআপ OTP কন্ট্রোল
              </h2>
              <p className="text-[11px] text-slate-500">
                শুধু আপনার <code className="font-mono font-bold text-teal-700">api_key</code> এখানে বসিয়ে সেভ করলেই সাইনআপ ভেরিফিকেশন OTP, অর্ডার কনফার্মেশন, স্ট্যাটাস আপডেট ও পাসওয়ার্ড ফরগেট OTP মেসেজ অটোমেটিক যাবে
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {devSmsBalance !== null && (
              <span className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono font-extrabold text-xs">
                ব্যালেন্স: ৳{devSmsBalance}
              </span>
            )}
            <button
              type="button"
              disabled={isCheckingDevBalance}
              onClick={async () => {
                if (!devSmsKey.trim()) {
                  showToast('প্রথমে API Key লিখুন', 'error');
                  return;
                }
                setIsCheckingDevBalance(true);
                try {
                  const res = await checkAlphaSmsBalance(devSmsKey.trim());
                  if (res.error === 0 && res.data?.balance !== undefined) {
                    setDevSmsBalance(res.data.balance);
                    showToast(`SMS ব্যালেন্স: ৳${res.data.balance}`, 'success');
                  } else {
                    showToast(res.msg || 'ব্যালেন্স পাওয়া যায়নি', 'error');
                  }
                } finally {
                  setIsCheckingDevBalance(false);
                }
              }}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isCheckingDevBalance ? 'animate-spin' : ''}`} />
              <span>ব্যালেন্স চেক</span>
            </button>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            updateBusiness({
              smsApiKey: devSmsKey.trim(),
              smsSenderId: devSenderId.trim() || undefined,
              signupOtpRequired: devSignupOtpRequired,
              smsEnabled: true
            });
            showToast('Alpha SMS API Key ও সাইনআপ OTP সেটিং সফলভাবে সংরক্ষিত হয়েছে!', 'success');
          }}
          className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end text-xs"
        >
          <div className="md:col-span-4">
            <label className="block font-bold text-slate-700 mb-1">
              API Key (<span className="font-mono text-teal-700">api_key</span>) *
            </label>
            <input
              type="text"
              value={devSmsKey}
              onChange={(e) => setDevSmsKey(e.target.value)}
              placeholder="আপনার api.sms.net.bd এর API KEY এখানে বসান..."
              className="w-full min-h-[40px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-teal-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block font-bold text-slate-700 mb-1">
              Sender ID (<span className="font-mono text-slate-500">sender_id</span>)
            </label>
            <input
              type="text"
              value={devSenderId}
              onChange={(e) => setDevSenderId(e.target.value)}
              placeholder="ঐচ্ছিক"
              className="w-full min-h-[40px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-teal-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
          </div>
          <div className="md:col-span-3">
            <label className="block font-bold text-slate-700 mb-1">
              কাস্টমার সাইনআপে OTP ভেরিফিকেশন
            </label>
            <button
              type="button"
              onClick={() => {
                const nextVal = !devSignupOtpRequired;
                setDevSignupOtpRequired(nextVal);
                updateBusiness({ signupOtpRequired: nextVal });
                showToast(
                  nextVal
                    ? 'সাইনআপে OTP ভেরিফিকেশন চালু (ON) করা হয়েছে'
                    : 'সাইনআপে OTP ভেরিফিকেশন বন্ধ (OFF) করা হয়েছে',
                  'info'
                );
              }}
              className={`w-full min-h-[40px] px-3 py-2 rounded-xl font-extrabold flex items-center justify-between border cursor-pointer transition-colors ${
                devSignupOtpRequired
                  ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                  : 'bg-slate-100 border-slate-300 text-slate-700'
              }`}
            >
              <span>{devSignupOtpRequired ? 'চালু আছে (ON)' : 'বন্ধ আছে (OFF)'}</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                  devSignupOtpRequired ? 'bg-emerald-600 text-white' : 'bg-slate-400 text-white'
                }`}
              >
                {devSignupOtpRequired ? 'ACTIVE' : 'DISABLED'}
              </span>
            </button>
          </div>
          <div className="md:col-span-3">
            <button
              type="submit"
              className="w-full min-h-[40px] py-2 px-4 bg-[#0d9488] hover:bg-[#0f766e] text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>সেটিং ও API Key সেভ করুন</span>
            </button>
          </div>
        </form>
      </div>

      {/* Developer Product Page WhatsApp Order & Call For Order Number Configuration Card */}
      <div className="bg-white rounded-2xl border-2 border-emerald-500/30 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center shrink-0">
              <PhoneCall className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                প্রোডাক্ট পেজ WhatsApp Order এবং Call For Order নম্বর পরিবর্তন (Developer Control)
              </h2>
              <p className="text-[11px] text-slate-500">
                ওয়েবসাইটের প্রতিটি পণ্যের পেজে থাকা <strong className="text-emerald-700">WhatsApp Order</strong> ও <strong className="text-slate-800">Call For Order</strong> বাটনের নম্বর এখান থেকে পরিবর্তন ও সেভ করুন
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-extrabold">
            সকল পণ্যে অটো-আপডেট হবে
          </span>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            updateBusiness({
              whatsappOrderPhone: devWhatsappPhone.trim() || currentBusiness.phone,
              callOrderPhone: devCallOrderPhone.trim() || currentBusiness.phone
            });
            showToast(
              'প্রোডাক্ট পেজের WhatsApp Order এবং Call For Order নম্বর সফলভাবে পরিবর্তন ও সেভ হয়েছে!',
              'success'
            );
          }}
          className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end text-xs"
        >
          <div className="md:col-span-5">
            <label className="block font-extrabold text-emerald-800 mb-1.5 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
              <span>WhatsApp Order নম্বর (হোয়াটসঅ্যাপ নম্বর) *</span>
            </label>
            <input
              type="text"
              value={devWhatsappPhone}
              onChange={(e) => setDevWhatsappPhone(e.target.value)}
              placeholder="যেমন: 01711234567 বা +8801711234567"
              className="w-full min-h-[42px] px-3.5 py-2 bg-emerald-50/40 border-2 border-emerald-400 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-bold text-sm text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block font-extrabold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <PhoneCall className="w-3.5 h-3.5 text-amber-600" />
              <span>Call For Order নম্বর (ডিরেক্ট কল নম্বর) *</span>
            </label>
            <input
              type="text"
              value={devCallOrderPhone}
              onChange={(e) => setDevCallOrderPhone(e.target.value)}
              placeholder="যেমন: 01711234567"
              className="w-full min-h-[42px] px-3.5 py-2 bg-slate-50 border-2 border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-bold text-sm text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-3">
            <button
              type="submit"
              className="w-full min-h-[42px] py-2.5 px-4 bg-[#16A34A] hover:bg-[#15803D] text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>নম্বর দুটি সেভ করুন</span>
            </button>
          </div>
        </form>
      </div>

      {/* Developer WordPress (WooCommerce) Automatic Order Creation Setup Card */}
      <div className="bg-white rounded-2xl border-2 border-sky-500/35 p-5 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-700 border border-sky-200 flex items-center justify-center shrink-0">
              <Globe className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                আলাদা WordPress (WooCommerce) ওয়েবসাইটে অটোমেটিক অর্ডার তৈরি (Developer Setup)
              </h2>
              <p className="text-[11px] text-slate-500">
                ফ্রন্ট ওয়েবসাইটে অর্ডার আসলেই আপনার আলাদা ওয়ার্ডপ্রেস সাইটে অটোমেটিক অর্ডার তৈরি করতে নিচের ৩টি তথ্য (<strong className="text-sky-800">WordPress Site URL</strong>, <strong className="text-sky-800">Consumer Key</strong> ও <strong className="text-sky-800">Consumer Secret</strong>) দিন
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 cursor-pointer">
              <input
                type="checkbox"
                checked={devWpSyncEnabled}
                onChange={(e) => setDevWpSyncEnabled(e.target.checked)}
                className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
              />
              <span className="text-[11px] font-extrabold text-emerald-950">
                অটো অর্ডার সিঙ্ক চালু
              </span>
            </label>
            <button
              type="button"
              disabled={isTestingDevWp}
              onClick={async () => {
                const cleaned = normalizeWpSiteUrl(devWpSiteUrl);
                if (!cleaned || !devWpConsumerKey.trim() || !devWpConsumerSecret.trim()) {
                  showToast('প্রথমে WordPress URL, Consumer Key ও Consumer Secret লিখুন', 'error');
                  return;
                }
                setIsTestingDevWp(true);
                try {
                  const res = await testWordPressConnection({
                    siteUrl: cleaned,
                    consumerKey: devWpConsumerKey.trim(),
                    consumerSecret: devWpConsumerSecret.trim()
                  });
                  showToast(res.message, res.ok ? 'success' : 'error');
                } finally {
                  setIsTestingDevWp(false);
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-200 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingDevWp ? 'animate-spin' : ''}`} />
              <span>কানেকশন চেক</span>
            </button>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-sky-50/70 border border-sky-200/80 text-[11px] text-sky-950 leading-relaxed">
          <strong>ওয়ার্ডপ্রেস থেকে যা লাগবে:</strong> আপনার WordPress সাইটের অ্যাডমিনে যান:{' '}
          <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-sky-200">
            WooCommerce → Settings → Advanced → REST API → Add key
          </code>{' '}
          (Permissions: <strong>Read/Write</strong> দিন)। সেখান থেকে পাওয়া <strong>Consumer key (ck_...)</strong> এবং{' '}
          <strong>Consumer secret (cs_...)</strong> নিচে বসিয়ে সেভ করুন। (বাম পাশের মেনুর <strong>WordPress</strong> অপশন থেকে টেস্ট অর্ডার ও লগ দেখতে পারবেন)।
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const cleanedUrl = normalizeWpSiteUrl(devWpSiteUrl);
            setDevWpSiteUrl(cleanedUrl);
            updateBusiness({
              wpSyncEnabled: devWpSyncEnabled,
              wpSiteUrl: cleanedUrl,
              wpConsumerKey: devWpConsumerKey.trim(),
              wpConsumerSecret: devWpConsumerSecret.trim(),
              wpDefaultOrderStatus: devWpOrderStatus
            });
            showToast(
              'WordPress (WooCommerce) অটোমেটিক অর্ডার সিঙ্ক সেটিংস সফলভাবে সেভ হয়েছে!',
              'success'
            );
          }}
          className="grid grid-cols-1 md:grid-cols-12 gap-3.5 items-end text-xs"
        >
          <div className="md:col-span-3">
            <label className="block font-extrabold text-slate-800 mb-1">
              ১. WordPress Site URL *
            </label>
            <input
              type="text"
              value={devWpSiteUrl}
              onChange={(e) => setDevWpSiteUrl(e.target.value)}
              placeholder="https://yourfashionsite.com"
              className="w-full min-h-[42px] px-3 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block font-extrabold text-slate-800 mb-1">
              ২. Consumer Key (ck_...) *
            </label>
            <input
              type="text"
              value={devWpConsumerKey}
              onChange={(e) => setDevWpConsumerKey(e.target.value)}
              placeholder="ck_xxxxxxxxxxxxxxxxxxxx"
              className="w-full min-h-[42px] px-3 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block font-extrabold text-slate-800 mb-1">
              ৩. Consumer Secret (cs_...) *
            </label>
            <input
              type="password"
              value={devWpConsumerSecret}
              onChange={(e) => setDevWpConsumerSecret(e.target.value)}
              placeholder="cs_xxxxxxxxxxxxxxxxxxxx"
              className="w-full min-h-[42px] px-3 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
          </div>

          <div className="md:col-span-3">
            <button
              type="submit"
              className="w-full min-h-[42px] py-2.5 px-4 bg-sky-600 hover:bg-sky-700 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>WordPress সেটিং সেভ করুন</span>
            </button>
          </div>
        </form>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-200/80 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('easy_publish')}
          className={`px-4 py-2 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
            activeTab === 'easy_publish' ? 'bg-[#0d9488] text-white shadow-xs' : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>সহজ ৩-ধাপে cPanel ও MySQL পাবলিশ গাইড</span>
        </button>

        <button
          onClick={() => setActiveTab('env_generator')}
          className={`px-4 py-2 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
            activeTab === 'env_generator' ? 'bg-[#0d9488] text-white shadow-xs' : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          <span>১-ক্লিক MySQL কানেকশন জেনারেটর (env.php)</span>
        </button>

        <button
          onClick={() => setActiveTab('files')}
          className={`px-4 py-2 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
            activeTab === 'files' ? 'bg-[#0d9488] text-white shadow-xs' : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          <FileCode2 className="w-3.5 h-3.5" />
          <span>সকল PHP ও MySQL ফাইল ({PROJECT_FILES.length})</span>
        </button>
      </div>

      {/* TAB 1: Super Easy 3-Step Guide for Non-Programmers */}
      {activeTab === 'easy_publish' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Step 1 */}
            <div className="bg-white p-5 rounded-2xl border-2 border-teal-500/30 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-md bg-teal-50 text-teal-800 font-extrabold text-xs">
                    ধাপ ১ (Step 1)
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">সময়: ১ মিনিট</span>
                </div>
                <h3 className="font-bold text-slate-900 text-base">
                  ১-ক্লিক জিপ (.zip) ফাইলটি public_html-এ রাখুন
                </h3>
                <ol className="text-xs text-slate-600 space-y-2 list-decimal list-inside leading-relaxed">
                  <li>উপরের <strong>১-ক্লিক cPanel রেডি জিপ (.zip) ডাউনলোড</strong> বাটনে ক্লিক করে জিপ ফাইলটি ডাউনলোড করুন।</li>
                  <li>আপনার cPanel-এর <strong>File Manager → public_html</strong> ফোল্ডারে ঢুকে জিপ ফাইলটি <strong>Upload</strong> করুন।</li>
                  <li>জিপ ফাইলটির ওপর রাইট-ক্লিক করে <strong>Extract</strong> করুন।</li>
                </ol>
              </div>
              <button
                type="button"
                disabled={isDownloadingZip}
                onClick={async () => {
                  setIsDownloadingZip(true);
                  await downloadVerifiedZip(
                    '/api/download-cpanel-zip',
                    'stockmaster_cpanel_ready_public_html.zip',
                    showToast
                  );
                  setIsDownloadingZip(false);
                }}
                className="w-full py-2.5 px-4 bg-[#0d9488] hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>১-ক্লিক cPanel রেডি জিপ (.zip) ডাউনলোড</span>
              </button>
            </div>

            {/* Step 2 */}
            <div className="bg-white p-5 rounded-2xl border-2 border-teal-500/30 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-md bg-teal-50 text-teal-800 font-extrabold text-xs">
                    ধাপ ২ (Step 2)
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">সময়: ১ মিনিট</span>
                </div>
                <h3 className="font-bold text-slate-900 text-base">
                  cPanel-এ একটি ডাটাবেজ ও ইউজার তৈরি করুন
                </h3>
                <ol className="text-xs text-slate-600 space-y-2 list-decimal list-inside leading-relaxed">
                  <li>cPanel হোমপেজ থেকে <strong>MySQL Database Wizard</strong>-এ ক্লিক করুন।</li>
                  <li>একটি ডাটাবেজ নাম দিন (যেমন: <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-slate-900">stockmaster</code>)।</li>
                  <li>একটি ইউজারনেম ও পাসওয়ার্ড দিয়ে <strong>ALL PRIVILEGES</strong> টিক দিয়ে সেভ করুন।</li>
                </ol>
              </div>
              <div className="p-3 bg-teal-50/70 rounded-xl border border-teal-200/70 text-[11px] text-teal-900 font-medium">
                💡 ডাটাবেজের পুরো নাম (যেমন: <code className="font-mono">cpaneluser_stockmaster</code>), ইউজারনেম ও পাসওয়ার্ডটি কপি করে রাখুন।
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-white p-5 rounded-2xl border-2 border-teal-500/30 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-md bg-teal-50 text-teal-800 font-extrabold text-xs">
                    ধাপ ৩ (Step 3)
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">সময়: ৩০ সেকেন্ড</span>
                </div>
                <h3 className="font-bold text-slate-900 text-base">
                  ইন্সটল লিংকে ঢুকে ১-ক্লিকে সেটআপ করুন!
                </h3>
                <ol className="text-xs text-slate-600 space-y-2 list-decimal list-inside leading-relaxed">
                  <li>আপনার ব্রাউজারে এই লিংকটি ওপেন করুন:<br />
                    <code className="bg-teal-50 border border-teal-200 px-2 py-1 rounded font-mono font-bold text-teal-900 inline-block mt-1">
                      https://আপনার-ডোমেইন.com/install.php
                    </code>
                  </li>
                  <li>সেখানে আপনার ডাটাবেজের নাম, ইউজারনেম ও পাসওয়ার্ড বসিয়ে <strong>1-Click Install</strong> বাটনে চাপ দিন!</li>
                  <li>ব্যস! অটোমেটিক ১৬টি টেবিল তৈরি ও কানেক্ট হয়ে সফটওয়্যার চালু হয়ে যাবে!</li>
                </ol>
              </div>
              <button
                onClick={() => setActiveTab('env_generator')}
                className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Wrench className="w-4 h-4 text-teal-400" />
                <span>অথবা ম্যানুয়ালি env.php ডাউনলোড করুন</span>
              </button>
            </div>
          </div>

          {/* Folder Structure Summary Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="space-y-2.5 text-xs">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span>আপনার অটো-ইন্সটলার লিংক ও লগইন তথ্য:</span>
              </h3>
              <p className="text-slate-600 leading-relaxed">
                জিপ ফাইলটির ভেতরে <code className="font-mono font-bold text-teal-800">install.php</code> এবং <code className="font-mono font-bold text-teal-800">api/install.php</code> দুই জায়গাতেই অ্যাক্টিভ ইনস্টলার দেওয়া আছে। তাই আপনি <code className="font-mono font-bold">yourdomain.com/install.php</code> অথবা <code className="font-mono font-bold">yourdomain.com/api/install.php</code>—যেকোনো একটিতে ঢুকলেই ইনস্টলার পেজ পাবেন।
              </p>
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-950 space-y-1">
                <div className="font-bold">ডিফল্ট অ্যাডমিন লগইন (ইনস্টলের পর):</div>
                <div>অ্যাডমিন লিংক: <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded">yourdomain.com/smart</code></div>
                <div>ইমেইল/ইউজারনেম: <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded">owner@stockflowbd.com</code> (অথবা <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded">admin</code>) | পাসওয়ার্ড: <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded">Admin@1234</code></div>
              </div>
            </div>

            <div className="bg-slate-950 text-teal-300 p-4 rounded-xl font-mono text-xs leading-relaxed overflow-x-auto">
              <pre>{`public_html/ (জিপ Extract করার পর)
├── index.php             <-- মেইন সফটওয়্যার (Universal Entry)
├── install.php           <-- ১-ক্লিক অটো ইনস্টলার (yourdomain.com/install.php)
├── .htaccess             <-- রাউটিং, কাস্টম 404 ও সিকিউরিটি
├── assets/               <-- কম্পাইলড JS ও CSS বান্ডেল
├── database/
│   └── cpanel_complete_install.sql
└── api/
    ├── index.php         <-- মূল PHP 8.2 API
    └── install.php       <-- বিকল্প ইনস্টলার লিংক`}</pre>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Interactive env.php Config Generator for Non-Programmers */}
      {activeTab === 'env_generator' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                কোডিং ছাড়াই আপনার MySQL <code className="font-mono text-teal-700">env.php</code> ফাইল তৈরি করুন
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                cPanel MySQL Database Wizard থেকে পাওয়া নাম ও পাসওয়ার্ড নিচের বক্সে লিখুন এবং ডাউনলোড বাটনে ক্লিক করুন।
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">MySQL Host (হোস্ট)</label>
                <input
                  type="text"
                  value={dbHost}
                  onChange={e => setDbHost(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Database Name (ডাটাবেজের নাম)</label>
                <input
                  type="text"
                  value={dbName}
                  onChange={e => setDbName(e.target.value)}
                  placeholder="যেমন: cpaneluser_stockmaster"
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Database Username (ডাটাবেজ ইউজারনেম)</label>
                <input
                  type="text"
                  value={dbUser}
                  onChange={e => setDbUser(e.target.value)}
                  placeholder="যেমন: cpaneluser_admin"
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Database Password (ডাটাবেজ পাসওয়ার্ড)</label>
                <input
                  type="text"
                  value={dbPass}
                  onChange={e => setDbPass(e.target.value)}
                  placeholder="আপনার ডাটাবেজ পাসওয়ার্ড লিখুন"
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>
            </div>

            <button
              onClick={downloadGeneratedEnv}
              className="w-full py-3 px-4 bg-[#0d9488] hover:bg-teal-700 text-white rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>আমার রেডিমেড env.php ফাইল ডাউনলোড করুন</span>
            </button>
          </div>

          <div className="space-y-2 flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">অটো-জেনারেটেড <code className="font-mono">env.php</code> প্রিভিউ:</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(generatedEnvPhp);
                  showToast('env.php কোড কপি করা হয়েছে!', 'info');
                }}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>কপি করুন</span>
              </button>
            </div>
            <div className="flex-1 bg-slate-950 p-4 rounded-xl text-teal-300 font-mono text-xs overflow-x-auto">
              <pre>{generatedEnvPhp}</pre>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Source Code Explorer & Individual Downloader */}
      {activeTab === 'files' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <select
              value={selectedFile}
              onChange={e => setSelectedFile(e.target.value)}
              className="text-xs p-2.5 bg-white border border-slate-300 rounded-xl font-mono text-slate-900 min-w-[320px]"
            >
              {PROJECT_FILES.map(f => (
                <option key={f.path} value={f.path}>{f.label}</option>
              ))}
            </select>

            <div className="flex items-center gap-2">
              <button
                onClick={copyContent}
                className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>কোড কপি করুন</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  downloadSqlFile(
                    selectedFile,
                    selectedFile.split('/').pop() || 'project-file.txt',
                    showToast
                  )
                }
                className="px-3.5 py-2 bg-[#0d9488] hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>ফাইল ডাউনলোড</span>
              </button>
            </div>
          </div>

          <div className="bg-slate-950 p-4 text-teal-300 font-mono text-xs overflow-x-auto max-h-[520px]">
            <pre>{fileContent}</pre>
          </div>
        </div>
      )}
    </div>
  );
};
