import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  LayoutDashboard, 
  ShoppingBag,
  Boxes, 
  Users, 
  Database, 
  Settings, 
  X,
  Server,
  LogOut,
  Layers,
  ExternalLink,
  AlertTriangle,
  Rocket,
  Gift,
  Truck,
  PanelLeftClose
} from 'lucide-react';
import { UserRole } from '../types';
import { APP_VERSION } from '../config/version';

interface SidebarProps {
  currentView: string;
  onSelectView: (view: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  isDesktopSidebarOpen?: boolean;
  onToggleDesktopSidebar?: () => void;
  onOpenStorefront?: () => void;
  adminTheme?: 'light' | 'dark';
  onSetAdminTheme?: (theme: 'light' | 'dark') => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  isOpenMobile,
  onCloseMobile,
  isDesktopSidebarOpen = true,
  onToggleDesktopSidebar,
  onOpenStorefront,
  adminTheme = 'light',
  onSetAdminTheme
}) => {
  const { currentUser, currentBusiness, onlineOrders, incompleteOrders, products, customers, logout } = useApp();

  const regularProductsCount = products.filter(p => !p.isLandingPageProduct).length;
  const landingProductsCount = products.filter(p => Boolean(p.isLandingPageProduct)).length;

  const totalSpinLeadsCount = React.useMemo(() => {
    const deletedSet = new Set(currentBusiness.deletedSpinLeadIds || []);
    const ids = new Set<string>();
    (currentBusiness.spinWheelLeads || []).forEach(l => {
      if (l?.id && !deletedSet.has(l.id)) ids.add(l.id);
    });
    (currentBusiness.landingSpinWheelLeads || []).forEach(l => {
      if (l?.id && !deletedSet.has(l.id)) ids.add(l.id);
    });
    return ids.size;
  }, [
    currentBusiness.spinWheelLeads,
    currentBusiness.landingSpinWheelLeads,
    currentBusiness.deletedSpinLeadIds
  ]);

  const pendingOnlineCount = onlineOrders.filter(
    o => o.orderStatus === 'pending'
  ).length;

  const abandonedCount = incompleteOrders.filter(
    inc => inc.status === 'abandoned' || inc.status === 'contacted'
  ).length;

  const onlineCustomersCount = customers.filter(
    c => c.customerType === 'online' || c.isOnlineCustomer
  ).length;

  const roleLabels: Record<UserRole, string> = {
    developer: 'System Developer',
    super_admin: 'Super Admin (Owner)',
    store_manager: 'Store Manager',
    cashier: 'Order Executive',
    distribution_mgr: 'Fulfilment Manager',
    sales_rep: 'Sales Executive'
  };

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      roles: ['developer', 'super_admin', 'store_manager', 'cashier', 'distribution_mgr', 'sales_rep'],
      badge: 'Home',
      iconBg: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
      activeBg: 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
    },
    {
      id: 'online_orders',
      label: 'Online Orders',
      icon: ShoppingBag,
      roles: ['developer', 'super_admin', 'store_manager', 'cashier', 'distribution_mgr'],
      badge: `${pendingOnlineCount}`,
      iconBg: 'bg-sky-100 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300',
      activeBg: 'bg-gradient-to-r from-sky-600 to-blue-600 text-white shadow-sm'
    },
    {
      id: 'courier_integration',
      label: 'Courier Integration',
      icon: Truck,
      roles: ['developer', 'super_admin', 'store_manager'],
      badge: '1-Click',
      iconBg: 'bg-teal-100 text-teal-800 dark:bg-teal-950/70 dark:text-teal-300',
      activeBg: 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-sm'
    },
    {
      id: 'inventory',
      label: 'Products & Stock',
      icon: Boxes,
      roles: ['developer', 'super_admin', 'store_manager', 'distribution_mgr'],
      badge: `${regularProductsCount}`,
      iconBg: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300',
      activeBg: 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-sm'
    },
    {
      id: 'landing_pages',
      label: 'Landing Pages',
      icon: Rocket,
      roles: ['developer', 'super_admin', 'store_manager', 'distribution_mgr'],
      badge: `${landingProductsCount}`,
      iconBg: 'bg-violet-100 text-violet-700 dark:bg-violet-950/70 dark:text-violet-300',
      activeBg: 'bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow-sm'
    },
    {
      id: 'spin_wheel',
      label: 'Spin Wheel & Leads',
      icon: Gift,
      roles: ['developer', 'super_admin', 'store_manager', 'cashier', 'distribution_mgr'],
      badge: `${totalSpinLeadsCount}`,
      iconBg: 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300',
      activeBg: 'bg-gradient-to-r from-rose-600 to-orange-500 text-white shadow-sm'
    },
    {
      id: 'online_customers',
      label: 'Customers',
      icon: Users,
      roles: ['developer', 'super_admin', 'store_manager', 'cashier', 'distribution_mgr'],
      badge: `${onlineCustomersCount}`,
      iconBg: 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300',
      activeBg: 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-sm'
    },
    {
      id: 'facebook',
      label: 'Facebook Pixel & CAPI',
      icon: Server,
      roles: ['developer'],
      badge: 'Pixel',
      iconBg: 'bg-blue-100 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300',
      activeBg: 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
    },
    {
      id: 'gtm',
      label: 'Google Tag Manager',
      icon: Layers,
      roles: ['developer'],
      badge: 'GTM',
      iconBg: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-300',
      activeBg: 'bg-gradient-to-r from-cyan-600 to-sky-600 text-white shadow-sm'
    },
    {
      id: 'wordpress',
      label: 'WordPress Sync',
      icon: ExternalLink,
      roles: ['developer'],
      badge: 'Woo',
      iconBg: 'bg-purple-100 text-purple-700 dark:bg-purple-950/70 dark:text-purple-300',
      activeBg: 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-sm'
    },
    {
      id: 'settings',
      label: 'Store Settings',
      icon: Settings,
      roles: ['developer', 'super_admin'],
      iconBg: 'bg-teal-100 text-teal-800 dark:bg-teal-950/70 dark:text-teal-300',
      activeBg: 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-sm'
    },
    {
      id: 'database',
      label: 'cPanel & Database',
      icon: Database,
      roles: ['developer'],
      badge: 'cPanel',
      iconBg: 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
      activeBg: 'bg-gradient-to-r from-slate-700 to-slate-900 text-white shadow-sm'
    }
  ];

  const visibleItems = navigationItems.filter(item => 
    item.roles.includes(currentUser.role)
  );

  const handleItemClick = (id: string) => {
    onSelectView(id);
    onCloseMobile();
  };

  const handleOpenIncompleteOrders = () => {
    try {
      sessionStorage.setItem('sm_orders_initial_tab', 'incomplete');
    } catch {
      // ignore storage errors
    }
    onSelectView('online_orders');
    onCloseMobile();
  };

  return (
    <>
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      <aside 
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 flex flex-col transition-transform duration-200 ease-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        } ${
          isDesktopSidebarOpen ? 'lg:translate-x-0' : 'lg:-translate-x-full'
        } border-r border-indigo-100 dark:border-slate-800 shadow-xs`}
      >
        {/* Mobile Drawer Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 lg:hidden">
          <div className="flex items-center gap-2.5 min-w-0">
            {currentBusiness.logoUrl ? (
              <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-0.5 flex items-center justify-center shrink-0 overflow-hidden">
                <img src={currentBusiness.logoUrl} alt={currentBusiness.nameEn || currentBusiness.name} className="w-full h-full object-contain" />
              </div>
            ) : (
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0">
                <ShoppingBag className="w-4 h-4" />
              </div>
            )}
            <span className="font-bold text-slate-900 dark:text-white text-sm tracking-tight truncate">
              {currentBusiness.nameEn || currentBusiness.name}
            </span>
          </div>
          <button 
            onClick={onCloseMobile}
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Colorful Store Summary Header */}
        <div className="px-4 py-3.5 border-b border-indigo-100/80 dark:border-slate-800 bg-gradient-to-br from-emerald-50/80 via-sky-50/50 to-indigo-50/70 dark:from-slate-800/80 dark:via-slate-900 dark:to-slate-900">
          <div className="flex items-center justify-between text-[10px] font-bold text-indigo-700 dark:text-indigo-300">
            <span>E-COMMERCE ADMIN PANEL</span>
            <div className="flex items-center gap-1.5">
              <span className="font-mono text-emerald-700 dark:text-emerald-400">
                {APP_VERSION}
              </span>
              {onToggleDesktopSidebar && (
                <button
                  type="button"
                  onClick={onToggleDesktopSidebar}
                  title="Hide sidebar menu"
                  className="hidden lg:inline-flex items-center justify-center w-6 h-6 rounded-lg bg-white/80 hover:bg-indigo-100 text-slate-600 hover:text-indigo-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 border border-indigo-200/70 dark:border-slate-700 transition-colors cursor-pointer"
                  aria-label="Hide sidebar"
                >
                  <PanelLeftClose className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2.5 mt-2">
            {currentBusiness.logoUrl ? (
              <div className="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 p-0.5 flex items-center justify-center shrink-0 overflow-hidden border border-emerald-200 dark:border-slate-700 shadow-2xs">
                <img src={currentBusiness.logoUrl} alt={currentBusiness.nameEn || currentBusiness.name} className="w-full h-full object-contain" />
              </div>
            ) : (
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shrink-0 font-bold text-xs shadow-2xs">
                <ShoppingBag className="w-4 h-4" />
              </div>
            )}
            <div className="min-w-0 flex-1">
              <p className="text-xs font-extrabold text-slate-900 dark:text-slate-100 truncate">
                {currentBusiness.nameEn || currentBusiness.name}
              </p>
              <div className="flex items-center gap-1.5 text-[10px] text-slate-600 dark:text-slate-400 mt-0.5 font-semibold">
                {currentBusiness.freeDeliveryEnabled ? (
                  <span className="text-emerald-700 dark:text-emerald-400 font-bold">Free Delivery Active</span>
                ) : (
                  <span className="font-mono tabular-nums">
                    Dhaka: ৳{currentBusiness.insideDhakaDeliveryCharge ?? currentBusiness.ecommerceDeliveryCharge ?? 60} · Outside: ৳{currentBusiness.outsideDhakaDeliveryCharge ?? 120}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Links with Colorful Icon Badges */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1.5 scrollbar-thin">
          <p className="px-2.5 pb-1 text-[10px] font-extrabold text-slate-400 dark:text-slate-500">
            MODULES & NAVIGATION
          </p>
          {visibleItems.map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`w-full min-h-[42px] flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-all text-left cursor-pointer ${
                  isActive
                    ? item.activeBg
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100/90 dark:hover:bg-slate-800/80 font-semibold'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                      isActive ? 'bg-white/20 text-white' : item.iconBg
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono font-bold shrink-0 tabular-nums ${
                      isActive
                        ? 'bg-black/20 text-white'
                        : item.id === 'online_orders' && pendingOnlineCount > 0
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Quick Incomplete Orders Shortcut Box */}
          {abandonedCount > 0 && (
            <div className="pt-2">
              <button
                type="button"
                onClick={handleOpenIncompleteOrders}
                className="w-full p-3 rounded-xl bg-gradient-to-r from-amber-50 to-rose-50 dark:from-amber-950/50 dark:to-rose-950/40 hover:from-amber-100 hover:to-rose-100 border border-amber-200 dark:border-amber-800/70 text-left transition-colors cursor-pointer group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold text-amber-950 dark:text-amber-200 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600 dark:text-amber-400 shrink-0" />
                    <span>Incomplete Orders (Leads)</span>
                  </span>
                  <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-rose-600 text-white rounded tabular-nums">
                    {abandonedCount} Active
                  </span>
                </div>
                <p className="text-[10px] text-amber-800 dark:text-amber-300/90 mt-1 font-medium">
                  Click here to call & convert abandoned orders
                </p>
              </button>
            </div>
          )}
        </div>

        {/* User Session Footer + Logout */}
        <div className="p-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/90 space-y-2.5">
          <div className="flex items-center gap-2.5 text-xs">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
              {currentUser.name.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-slate-900 dark:text-slate-100 font-bold truncate">{currentUser.name}</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                {roleLabels[currentUser.role]}
              </p>
            </div>
          </div>

          <button
            onClick={logout}
            className="w-full min-h-[36px] py-2 px-3 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/70 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/70 text-[11px] rounded-lg flex items-center justify-center gap-1.5 transition-colors font-bold cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
