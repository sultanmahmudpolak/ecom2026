import React, { useState, useEffect } from 'react';
import {
  useApp,
  DEFAULT_DAILY_ORDER_LIMIT_TITLE,
  DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
} from '../context/AppContext';
import { UserRole, Outlet, User, BanglaFontStyle, StorefrontThemeStyle } from '../types';
import { processUploadedProductImage } from './ProductThumbnail';
import { processUploadedLogoImage } from '../utils/imageUploader';
import { 
  Building2, 
  Store, 
  Users, 
  CheckCircle2, 
  Save, 
  Plus, 
  X, 
  Shield, 
  Lock,
  Upload,
  Trash2,
  Truck,
  Type,
  Image as ImageIcon,
  MessageSquare,
  Send,
  RefreshCw,
  FileText,
  KeyRound,
  Edit2,
  PhoneCall,
  Globe,
  Search,
  Sparkles,
  Bell,
  Clock
} from 'lucide-react';
import {
  DEFAULT_SMS_TEMPLATES,
  formatSmsMessage,
  sendAlphaSms,
  checkAlphaSmsBalance,
  checkAlphaSmsReport,
  getSmsLogs,
  clearSmsLogs,
  SmsLogEntry
} from '../utils/smsService';

export const SettingsView: React.FC = () => {
  const { 
    language, 
    currentBusiness, 
    updateBusiness,
    products,
    updateProduct,
    outlets, 
    addOutlet,
    updateOutlet,
    deleteOutlet,
    users, 
    currentUser,
    quickLogin,
    addUser,
    updateUser,
    deleteUser,
    showToast,
    confirmDelete
  } = useApp();

  const [bizName, setBizName] = useState(currentBusiness.name);
  const [bizNameEn, setBizNameEn] = useState(currentBusiness.nameEn);
  const [taxId, setTaxId] = useState(currentBusiness.taxId);
  const [phone, setPhone] = useState(currentBusiness.phone);
  const [address, setAddress] = useState(currentBusiness.address);
  const [vatRate, setVatRate] = useState(String(currentBusiness.vatRate));
  const [invoicePrefix, setInvoicePrefix] = useState(currentBusiness.invoicePrefix);
  const [logoUrl, setLogoUrl] = useState(currentBusiness.logoUrl || '');
  const [faviconUrl, setFaviconUrl] = useState(currentBusiness.faviconUrl || '');
  const [seoTitle, setSeoTitle] = useState(currentBusiness.seoTitle || '');
  const [seoDescription, setSeoDescription] = useState(currentBusiness.seoDescription || '');
  const [seoKeywords, setSeoKeywords] = useState(currentBusiness.seoKeywords || '');
  const [seoOgImageUrl, setSeoOgImageUrl] = useState(currentBusiness.seoOgImageUrl || '');
  const [deliveryCharge, setDeliveryCharge] = useState(
    String(currentBusiness.insideDhakaDeliveryCharge ?? currentBusiness.ecommerceDeliveryCharge ?? 60)
  );
  const [outsideDhakaCharge, setOutsideDhakaCharge] = useState(
    String(currentBusiness.outsideDhakaDeliveryCharge ?? 120)
  );
  const [freeDeliveryEnabled, setFreeDeliveryEnabled] = useState<boolean>(
    Boolean(currentBusiness.freeDeliveryEnabled)
  );
  const [freeDeliveryMin, setFreeDeliveryMin] = useState(String(currentBusiness.freeDeliveryMinOrder ?? 1000));
  const [banglaFont, setBanglaFont] = useState<BanglaFontStyle>(
    currentBusiness.banglaFont || 'noto_sans'
  );
  const [storefrontTheme, setStorefrontTheme] = useState<StorefrontThemeStyle>(
    currentBusiness.storefrontTheme || 'emerald_default'
  );
  const [numberFontStyle, setNumberFontStyle] = useState<'jetbrains_mono' | 'outfit' | 'plus_jakarta_sans'>(
    currentBusiness.numberFontStyle || 'jetbrains_mono'
  );
  const [developerCreditEnabled, setDeveloperCreditEnabled] = useState<boolean>(
    currentBusiness.developerCreditEnabled !== false
  );
  const [developerCreditName, setDeveloperCreditName] = useState<string>(
    currentBusiness.developerCreditName ?? 'Web Studio BD'
  );
  const [developerCreditLink, setDeveloperCreditLink] = useState<string>(
    currentBusiness.developerCreditLink ?? 'https://example.com'
  );
  const DEFAULT_ANNOUNCEMENT_TEXT =
    '❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।';
  const [topAnnouncementEnabled, setTopAnnouncementEnabled] = useState<boolean>(
    currentBusiness.topAnnouncementEnabled !== false
  );
  const [topUtilityBarEnabled, setTopUtilityBarEnabled] = useState<boolean>(
    currentBusiness.topUtilityBarEnabled !== false
  );
  const [topAnnouncementText, setTopAnnouncementText] = useState<string>(
    currentBusiness.topAnnouncementText ?? DEFAULT_ANNOUNCEMENT_TEXT
  );
  const [topAnnouncementSpeed, setTopAnnouncementSpeed] = useState<'slow' | 'normal' | 'fast' | 'static'>(
    currentBusiness.topAnnouncementSpeed || 'normal'
  );
  const [snowfallIntensity, setSnowfallIntensity] = useState<number>(
    Math.max(10, Math.min(100, Number(currentBusiness.winterSnowfallIntensity ?? 50)))
  );
  const [snowfallSpeed, setSnowfallSpeed] = useState<number>(
    Math.max(30, Math.min(200, Number(currentBusiness.winterSnowfallSpeed ?? 100)))
  );
  const [snowfallAutoOffSec, setSnowfallAutoOffSec] = useState<number>(
    Math.max(0, Number(currentBusiness.winterSnowfallAutoOffSec ?? 0))
  );
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [isUploadingFavicon, setIsUploadingFavicon] = useState(false);
  const [isUploadingSeoOgImage, setIsUploadingSeoOgImage] = useState(false);

  // Dual SMS Gateway (GreenWeb bdbulksms.net & Alpha SMS api.sms.net.bd) & Smart Admin Notification Controls
  const [smsProvider, setSmsProvider] = useState<'alpha' | 'greenweb'>(
    currentBusiness.smsProvider === 'greenweb' ? 'greenweb' : 'alpha'
  );
  const [smsApiKey, setSmsApiKey] = useState(currentBusiness.smsApiKey || '');
  const [greenwebToken, setGreenwebToken] = useState(currentBusiness.greenwebToken || '');
  const [smsSenderId, setSmsSenderId] = useState(currentBusiness.smsSenderId || '');
  const [smsContentId, setSmsContentId] = useState(currentBusiness.smsContentId || '');
  const [smsEnabled, setSmsEnabled] = useState<boolean>(currentBusiness.smsEnabled ?? true);
  const [smsOrderConfirmationEnabled, setSmsOrderConfirmationEnabled] = useState<boolean>(
    currentBusiness.smsOrderConfirmationEnabled !== false
  );
  const [smsAdminOrderAlertEnabled, setSmsAdminOrderAlertEnabled] = useState<boolean>(
    Boolean(currentBusiness.smsAdminOrderAlertEnabled)
  );
  const [smsAdminOrderAlertPhone, setSmsAdminOrderAlertPhone] = useState<string>(
    currentBusiness.smsAdminOrderAlertPhone || currentBusiness.phone || ''
  );
  const [smsOrderStatusUpdateEnabled, setSmsOrderStatusUpdateEnabled] = useState<boolean>(
    currentBusiness.smsOrderStatusUpdateEnabled !== false
  );
  const [smsForgotPasswordOtpEnabled, setSmsForgotPasswordOtpEnabled] = useState<boolean>(
    currentBusiness.smsForgotPasswordOtpEnabled !== false
  );
  const [showSmsSecret, setShowSmsSecret] = useState<boolean>(false);
  const [whatsappOrderPhone, setWhatsappOrderPhone] = useState(
    currentBusiness.whatsappOrderPhone || currentBusiness.phone || '01711234567'
  );
  const [callOrderPhone, setCallOrderPhone] = useState(
    currentBusiness.callOrderPhone || currentBusiness.phone || '01711234567'
  );
  const [signupOtpRequired, setSignupOtpRequired] = useState<boolean>(
    Boolean(currentBusiness.signupOtpRequired)
  );
  const [smsOrderPlacedTemplate, setSmsOrderPlacedTemplate] = useState(
    currentBusiness.smsOrderPlacedTemplate || DEFAULT_SMS_TEMPLATES.orderPlaced
  );
  const [smsAdminOrderAlertTemplate, setSmsAdminOrderAlertTemplate] = useState(
    currentBusiness.smsAdminOrderAlertTemplate || DEFAULT_SMS_TEMPLATES.adminOrderAlert
  );
  const [smsOrderStatusTemplate, setSmsOrderStatusTemplate] = useState(
    currentBusiness.smsOrderStatusTemplate || DEFAULT_SMS_TEMPLATES.orderStatus
  );
  const [smsOtpTemplate, setSmsOtpTemplate] = useState(
    currentBusiness.smsOtpTemplate || DEFAULT_SMS_TEMPLATES.otpReset
  );
  const [smsSignupOtpTemplate, setSmsSignupOtpTemplate] = useState(
    currentBusiness.smsSignupOtpTemplate || DEFAULT_SMS_TEMPLATES.signupOtp
  );

  // Daily Order Limit (Mobile Number & IP/Device) + Editable Error Popup State
  const [dailyOrderLimitEnabled, setDailyOrderLimitEnabled] = useState<boolean>(
    currentBusiness.dailyOrderLimitEnabled !== false
  );
  const [dailySameProductMaxCount, setDailySameProductMaxCount] = useState<number>(
    Math.max(1, Number(currentBusiness.dailySameProductMaxCount ?? 2))
  );
  const [dailyOrderMaxCount, setDailyOrderMaxCount] = useState<number>(() => {
    const rawTotal = currentBusiness.dailyOrderMaxCount;
    return Math.max(
      1,
      Number(
        currentBusiness.dailySameProductMaxCount === undefined &&
          (rawTotal === undefined || rawTotal === 2)
          ? 5
          : (rawTotal ?? 5)
      )
    );
  });
  const [dailyOrderLimitTitle, setDailyOrderLimitTitle] = useState<string>(
    currentBusiness.dailyOrderLimitTitle || DEFAULT_DAILY_ORDER_LIMIT_TITLE
  );
  const [dailyOrderLimitMessage, setDailyOrderLimitMessage] = useState<string>(
    currentBusiness.dailyOrderLimitMessage || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
  );
  const [showLimitPopupPreview, setShowLimitPopupPreview] = useState<boolean>(false);

  // SMS Gateway Tools (Balance, Test SMS, Delivery Report & Logs)
  const [smsBalance, setSmsBalance] = useState<string | null>(null);
  const [smsExpiry, setSmsExpiry] = useState<string | null>(null);
  const [isCheckingBalance, setIsCheckingBalance] = useState(false);
  const [testSmsTo, setTestSmsTo] = useState('');
  const [testSmsMsg, setTestSmsMsg] = useState('টেস্ট মেসেজ: আপনার স্টোরের SMS গেটওয়ে সফলভাবে সংযুক্ত হয়েছে!');
  const [testSmsSchedule, setTestSmsSchedule] = useState('');
  const [isSendingTestSms, setIsSendingTestSms] = useState(false);
  const [reportRequestId, setReportRequestId] = useState('');
  const [reportResult, setReportResult] = useState<any>(null);
  const [isCheckingReport, setIsCheckingReport] = useState(false);
  const [smsLogs, setSmsLogs] = useState<SmsLogEntry[]>(() => getSmsLogs());

  // Sync local form state if currentBusiness updates from server
  useEffect(() => {
    setBizName(currentBusiness.name);
    setBizNameEn(currentBusiness.nameEn);
    setTaxId(currentBusiness.taxId);
    setPhone(currentBusiness.phone);
    setAddress(currentBusiness.address);
    setVatRate(String(currentBusiness.vatRate));
    setInvoicePrefix(currentBusiness.invoicePrefix);
    setLogoUrl(currentBusiness.logoUrl || '');
    setFaviconUrl(currentBusiness.faviconUrl || '');
    setSeoTitle(currentBusiness.seoTitle || '');
    setSeoDescription(currentBusiness.seoDescription || '');
    setSeoKeywords(currentBusiness.seoKeywords || '');
    setSeoOgImageUrl(currentBusiness.seoOgImageUrl || '');
    setDeliveryCharge(
      String(currentBusiness.insideDhakaDeliveryCharge ?? currentBusiness.ecommerceDeliveryCharge ?? 60)
    );
    setOutsideDhakaCharge(String(currentBusiness.outsideDhakaDeliveryCharge ?? 120));
    setFreeDeliveryEnabled(Boolean(currentBusiness.freeDeliveryEnabled));
    setFreeDeliveryMin(String(currentBusiness.freeDeliveryMinOrder ?? 1000));
    setBanglaFont(currentBusiness.banglaFont || 'noto_sans');
    setNumberFontStyle(currentBusiness.numberFontStyle || 'jetbrains_mono');
    setDeveloperCreditEnabled(currentBusiness.developerCreditEnabled !== false);
    setDeveloperCreditName(currentBusiness.developerCreditName ?? 'Web Studio BD');
    setDeveloperCreditLink(currentBusiness.developerCreditLink ?? 'https://example.com');
    setTopAnnouncementEnabled(currentBusiness.topAnnouncementEnabled !== false);
    setTopUtilityBarEnabled(currentBusiness.topUtilityBarEnabled !== false);
    setTopAnnouncementText(currentBusiness.topAnnouncementText ?? DEFAULT_ANNOUNCEMENT_TEXT);
    setTopAnnouncementSpeed(currentBusiness.topAnnouncementSpeed || 'normal');
    setSnowfallIntensity(
      Math.max(10, Math.min(100, Number(currentBusiness.winterSnowfallIntensity ?? 50)))
    );
    setSnowfallSpeed(
      Math.max(30, Math.min(200, Number(currentBusiness.winterSnowfallSpeed ?? 100)))
    );
    setSnowfallAutoOffSec(Math.max(0, Number(currentBusiness.winterSnowfallAutoOffSec ?? 0)));
    setSmsProvider(currentBusiness.smsProvider === 'greenweb' ? 'greenweb' : 'alpha');
    setSmsApiKey(currentBusiness.smsApiKey || '');
    setGreenwebToken(currentBusiness.greenwebToken || '');
    setSmsSenderId(currentBusiness.smsSenderId || '');
    setSmsContentId(currentBusiness.smsContentId || '');
    setSmsEnabled(currentBusiness.smsEnabled ?? true);
    setSmsOrderConfirmationEnabled(currentBusiness.smsOrderConfirmationEnabled !== false);
    setSmsAdminOrderAlertEnabled(Boolean(currentBusiness.smsAdminOrderAlertEnabled));
    setSmsAdminOrderAlertPhone(currentBusiness.smsAdminOrderAlertPhone || currentBusiness.phone || '');
    setSmsOrderStatusUpdateEnabled(currentBusiness.smsOrderStatusUpdateEnabled !== false);
    setSmsForgotPasswordOtpEnabled(currentBusiness.smsForgotPasswordOtpEnabled !== false);
    setSignupOtpRequired(Boolean(currentBusiness.signupOtpRequired));
    setSmsOrderPlacedTemplate(
      currentBusiness.smsOrderPlacedTemplate || DEFAULT_SMS_TEMPLATES.orderPlaced
    );
    setSmsAdminOrderAlertTemplate(
      currentBusiness.smsAdminOrderAlertTemplate || DEFAULT_SMS_TEMPLATES.adminOrderAlert
    );
    setSmsOrderStatusTemplate(
      currentBusiness.smsOrderStatusTemplate || DEFAULT_SMS_TEMPLATES.orderStatus
    );
    setSmsOtpTemplate(currentBusiness.smsOtpTemplate || DEFAULT_SMS_TEMPLATES.otpReset);
    setSmsSignupOtpTemplate(
      currentBusiness.smsSignupOtpTemplate || DEFAULT_SMS_TEMPLATES.signupOtp
    );
    setWhatsappOrderPhone(
      currentBusiness.whatsappOrderPhone || currentBusiness.phone || '01711234567'
    );
    setCallOrderPhone(
      currentBusiness.callOrderPhone || currentBusiness.phone || '01711234567'
    );
    setDailyOrderLimitEnabled(currentBusiness.dailyOrderLimitEnabled !== false);
    setDailySameProductMaxCount(Math.max(1, Number(currentBusiness.dailySameProductMaxCount ?? 2)));
    const rawTotal = currentBusiness.dailyOrderMaxCount;
    setDailyOrderMaxCount(
      Math.max(
        1,
        Number(
          currentBusiness.dailySameProductMaxCount === undefined &&
            (rawTotal === undefined || rawTotal === 2)
            ? 5
            : (rawTotal ?? 5)
        )
      )
    );
    setDailyOrderLimitTitle(
      currentBusiness.dailyOrderLimitTitle || DEFAULT_DAILY_ORDER_LIMIT_TITLE
    );
    setDailyOrderLimitMessage(
      currentBusiness.dailyOrderLimitMessage || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
    );
  }, [currentBusiness]);

  // Add / Edit User Modal State
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [newUserName, setNewUserName] = useState('');
  const [newUserUsername, setNewUserUsername] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>('cashier');
  const [newUserOutletId, setNewUserOutletId] = useState<string>(outlets[0]?.id || 'outlet_01');

  // Add / Edit Outlet (Branch & Warehouse) Modal State
  const [showOutletModal, setShowOutletModal] = useState(false);
  const [editingOutlet, setEditingOutlet] = useState<Outlet | null>(null);
  const [outletName, setOutletName] = useState('');
  const [outletType, setOutletType] = useState<Outlet['type']>('retail_shop');
  const [outletAddress, setOutletAddress] = useState('');
  const [outletPhone, setOutletPhone] = useState('');

  const openAddOutletModal = () => {
    setEditingOutlet(null);
    setOutletName('');
    setOutletType('retail_shop');
    setOutletAddress('');
    setOutletPhone('');
    setShowOutletModal(true);
  };

  const openEditOutletModal = (target: Outlet) => {
    setEditingOutlet(target);
    setOutletName(target.name);
    setOutletType(target.type);
    setOutletAddress(target.address);
    setOutletPhone(target.phone);
    setShowOutletModal(true);
  };

  const handleSaveOutlet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!outletName.trim()) {
      showToast(language === 'bn' ? 'শাখা বা গুদামের নাম লিখুন' : 'Please enter branch/warehouse name', 'error');
      return;
    }
    if (editingOutlet) {
      updateOutlet(editingOutlet.id, {
        name: outletName.trim(),
        type: outletType,
        address: outletAddress.trim() || 'ঢাকা, বাংলাদেশ',
        phone: outletPhone.trim() || currentBusiness.phone
      });
    } else {
      addOutlet({
        name: outletName.trim(),
        type: outletType,
        address: outletAddress.trim() || 'ঢাকা, বাংলাদেশ',
        phone: outletPhone.trim() || currentBusiness.phone
      });
    }
    setShowOutletModal(false);
    setEditingOutlet(null);
  };

  const outletTypeLabels: Record<Outlet['type'], { bn: string; en: string; badge: string }> = {
    retail_shop: {
      bn: 'সুপার শপ / বিক্রয় শাখা',
      en: 'Retail Shop Branch',
      badge: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    },
    central_warehouse: {
      bn: 'সেন্ট্রাল ওয়্যারহাউজ (গুদাম)',
      en: 'Central Warehouse',
      badge: 'bg-blue-50 text-blue-700 border-blue-200'
    },
    distribution_hub: {
      bn: 'ডিস্ট্রিবিউশন হাব',
      en: 'Distribution Hub',
      badge: 'bg-amber-50 text-amber-700 border-amber-200'
    }
  };

  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingLogo(true);
    try {
      const dataUrl = await processUploadedLogoImage(file);
      setLogoUrl(dataUrl);
      updateBusiness({ logoUrl: dataUrl });
      showToast(
        language === 'bn'
          ? 'স্টোরের লোগো সফলভাবে আপলোড ও ওয়েবসাইটে যুক্ত করা হয়েছে!'
          : 'Store logo uploaded and saved to website!'
      );
    } catch {
      showToast(
        language === 'bn' ? 'লোগো ইমেজ আপলোড করতে সমস্যা হয়েছে' : 'Failed to upload logo image',
        'error'
      );
    } finally {
      setIsUploadingLogo(false);
      e.target.value = '';
    }
  };

  const handleFaviconFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingFavicon(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 128);
      setFaviconUrl(dataUrl);
      updateBusiness({ faviconUrl: dataUrl });
      showToast(
        language === 'bn'
          ? 'ফেভিকন (Favicon) সফলভাবে আপলোড ও ব্রাউজার ট্যাবে যুক্ত করা হয়েছে!'
          : 'Favicon uploaded and applied to browser tab!'
      );
    } catch {
      showToast(
        language === 'bn' ? 'ফেভিকন ইমেজ আপলোড করতে সমস্যা হয়েছে' : 'Failed to upload favicon image',
        'error'
      );
    } finally {
      setIsUploadingFavicon(false);
      e.target.value = '';
    }
  };

  const handleSeoOgImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingSeoOgImage(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 1200);
      setSeoOgImageUrl(dataUrl);
      updateBusiness({ seoOgImageUrl: dataUrl });
      showToast(
        language === 'bn'
          ? 'ওয়েবসাইট লিংক শেয়ার ব্যানার (OG Image) সফলভাবে আপলোড ও যুক্ত করা হয়েছে!'
          : 'Website link share banner (OG Image) uploaded and applied!'
      );
    } catch {
      showToast(
        language === 'bn'
          ? 'শেয়ার ব্যানার ইমেজ আপলোড করতে সমস্যা হয়েছে'
          : 'Failed to upload social share image',
        'error'
      );
    } finally {
      setIsUploadingSeoOgImage(false);
      e.target.value = '';
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      name: bizName.trim() || currentBusiness.name,
      nameEn: bizNameEn.trim() || currentBusiness.nameEn,
      taxId: taxId.trim(),
      phone: phone.trim(),
      address: address.trim(),
      vatRate: Number(vatRate) || 0,
      invoicePrefix: invoicePrefix.trim().toUpperCase() || 'SMB',
      logoUrl: logoUrl.trim() || undefined,
      faviconUrl: faviconUrl.trim() || undefined,
      seoTitle: seoTitle.trim() || undefined,
      seoDescription: seoDescription.trim() || undefined,
      seoKeywords: seoKeywords.trim() || undefined,
      seoOgImageUrl: seoOgImageUrl.trim() || undefined,
      ecommerceDeliveryCharge: Math.max(0, Number(deliveryCharge) || 0),
      insideDhakaDeliveryCharge: Math.max(0, Number(deliveryCharge) || 0),
      outsideDhakaDeliveryCharge: Math.max(0, Number(outsideDhakaCharge) || 0),
      freeDeliveryEnabled,
      freeDeliveryMinOrder: Math.max(0, Number(freeDeliveryMin) || 0),
      banglaFont,
      storefrontTheme,
      numberFontStyle,
      developerCreditEnabled,
      developerCreditName: developerCreditName.trim(),
      developerCreditLink: developerCreditLink.trim(),
      topAnnouncementEnabled,
      topUtilityBarEnabled,
      topAnnouncementText: topAnnouncementText.trim() || DEFAULT_ANNOUNCEMENT_TEXT,
      topAnnouncementSpeed,
      winterSnowfallIntensity: snowfallIntensity,
      winterSnowfallSpeed: snowfallSpeed,
      winterSnowfallAutoOffSec: snowfallAutoOffSec,
      smsProvider,
      smsApiKey: smsApiKey.trim(),
      greenwebToken: greenwebToken.trim(),
      smsSenderId: smsSenderId.trim() || undefined,
      smsContentId: smsContentId.trim() || undefined,
      smsEnabled,
      smsOrderConfirmationEnabled,
      smsAdminOrderAlertEnabled,
      smsAdminOrderAlertPhone: smsAdminOrderAlertPhone.trim() || phone.trim(),
      smsOrderStatusUpdateEnabled,
      smsForgotPasswordOtpEnabled,
      signupOtpRequired,
      smsOrderPlacedTemplate: smsOrderPlacedTemplate.trim() || DEFAULT_SMS_TEMPLATES.orderPlaced,
      smsAdminOrderAlertTemplate: smsAdminOrderAlertTemplate.trim() || DEFAULT_SMS_TEMPLATES.adminOrderAlert,
      smsOrderStatusTemplate: smsOrderStatusTemplate.trim() || DEFAULT_SMS_TEMPLATES.orderStatus,
      smsOtpTemplate: smsOtpTemplate.trim() || DEFAULT_SMS_TEMPLATES.otpReset,
      smsSignupOtpTemplate: smsSignupOtpTemplate.trim() || DEFAULT_SMS_TEMPLATES.signupOtp,
      dailyOrderLimitEnabled,
      dailySameProductMaxCount: Math.max(1, Number(dailySameProductMaxCount) || 2),
      dailyOrderMaxCount: Math.max(1, Number(dailyOrderMaxCount) || 5),
      dailyOrderLimitTitle:
        dailyOrderLimitTitle.trim() || DEFAULT_DAILY_ORDER_LIMIT_TITLE,
      dailyOrderLimitMessage:
        dailyOrderLimitMessage.trim() || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
    });

    showToast(
      language === 'bn'
        ? 'লোগো, ফেভিকন, গ্লোবাল SEO, ডেলিভারি চার্জ ও সেটিংস সফলভাবে সংরক্ষিত হয়েছে!'
        : 'Store logo, favicon, global SEO, delivery charge, and settings saved!'
    );
  };

  const handleSaveSmsTemplates = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      smsProvider,
      smsApiKey: smsApiKey.trim(),
      greenwebToken: greenwebToken.trim(),
      smsSenderId: smsSenderId.trim() || undefined,
      smsContentId: smsContentId.trim() || undefined,
      smsEnabled,
      smsOrderConfirmationEnabled,
      smsAdminOrderAlertEnabled,
      smsAdminOrderAlertPhone: smsAdminOrderAlertPhone.trim() || phone.trim(),
      smsOrderStatusUpdateEnabled,
      smsForgotPasswordOtpEnabled,
      signupOtpRequired,
      smsOrderPlacedTemplate: smsOrderPlacedTemplate.trim() || DEFAULT_SMS_TEMPLATES.orderPlaced,
      smsAdminOrderAlertTemplate: smsAdminOrderAlertTemplate.trim() || DEFAULT_SMS_TEMPLATES.adminOrderAlert,
      smsOrderStatusTemplate: smsOrderStatusTemplate.trim() || DEFAULT_SMS_TEMPLATES.orderStatus,
      smsOtpTemplate: smsOtpTemplate.trim() || DEFAULT_SMS_TEMPLATES.otpReset,
      smsSignupOtpTemplate: smsSignupOtpTemplate.trim() || DEFAULT_SMS_TEMPLATES.signupOtp
    });
    showToast(
      `স্মার্ট SMS গেটওয়ে (${smsProvider === 'greenweb' ? 'GreenWeb SMS' : 'Alpha SMS'}), নোটিফিকেশন কন্ট্রোল ও মেসেজ ফরম্যাট সংরক্ষিত হয়েছে!`,
      'success'
    );
  };

  const handleSaveDeveloperSmsApi = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      smsProvider,
      smsApiKey: smsApiKey.trim(),
      greenwebToken: greenwebToken.trim(),
      smsSenderId: smsSenderId.trim() || undefined,
      smsContentId: smsContentId.trim() || undefined,
      smsEnabled,
      smsOrderConfirmationEnabled,
      smsAdminOrderAlertEnabled,
      smsAdminOrderAlertPhone: smsAdminOrderAlertPhone.trim() || phone.trim(),
      smsOrderStatusUpdateEnabled,
      smsForgotPasswordOtpEnabled
    });
    showToast(
      `${smsProvider === 'greenweb' ? 'GreenWeb (bdbulksms.net)' : 'Alpha SMS (api.sms.net.bd)'} গেটওয়ে কনফিগারেশন সংরক্ষিত হয়েছে!`,
      'success'
    );
  };

  const handleCheckSmsBalance = async () => {
    const activeCredential = smsProvider === 'greenweb' ? greenwebToken.trim() : smsApiKey.trim();
    if (!activeCredential) {
      showToast(
        smsProvider === 'greenweb'
          ? 'প্রথমে GreenWeb API Token বসান'
          : 'প্রথমে Alpha SMS API Key বসান',
        'error'
      );
      return;
    }
    setIsCheckingBalance(true);
    try {
      const res = await checkAlphaSmsBalance(activeCredential, smsProvider);
      if (res.error === 0 && res.data?.balance !== undefined) {
        setSmsBalance(res.data.balance);
        setSmsExpiry(res.data.expiry || null);
        showToast(
          `বর্তমান ${smsProvider === 'greenweb' ? 'GreenWeb' : 'Alpha'} SMS ব্যালেন্স: ${res.data.balance}`,
          'success'
        );
      } else {
        showToast(
          res.msg ||
            (smsProvider === 'greenweb'
              ? 'ব্যালেন্স পাওয়া যায়নি (GreenWeb Token চেক করুন)'
              : 'ব্যালেন্স পাওয়া যায়নি (Alpha API Key চেক করুন)'),
          'error'
        );
      }
    } finally {
      setIsCheckingBalance(false);
    }
  };

  const handleSendTestSms = async (e: React.FormEvent) => {
    e.preventDefault();
    const activeCredential = smsProvider === 'greenweb' ? greenwebToken.trim() : smsApiKey.trim();
    if (!activeCredential) {
      showToast(
        smsProvider === 'greenweb'
          ? 'প্রথমে GreenWeb API Token বসিয়ে নিন'
          : 'প্রথমে Alpha SMS API Key বসিয়ে নিন',
        'error'
      );
      return;
    }
    if (!testSmsTo.trim() || !testSmsMsg.trim()) {
      showToast('প্রাপকের মোবাইল নম্বর ও মেসেজ লিখুন', 'error');
      return;
    }
    setIsSendingTestSms(true);
    try {
      const res = await sendAlphaSms({
        provider: smsProvider,
        apiKey: smsApiKey.trim(),
        greenwebToken: greenwebToken.trim(),
        to: testSmsTo.trim(),
        msg: testSmsMsg.trim(),
        senderId: smsSenderId.trim() || undefined,
        schedule: testSmsSchedule.trim() || undefined,
        contentId: smsContentId.trim() || undefined
      });
      setSmsLogs(getSmsLogs());
      if (res.error === 0) {
        const reqId = res.data?.request_id ?? '';
        if (reqId) setReportRequestId(String(reqId));
        showToast(
          `SMS সফলভাবে সাবমিট হয়েছে (${smsProvider === 'greenweb' ? 'GreenWeb' : 'Alpha SMS'})! ${reqId ? `ID: ${reqId}` : ''}`,
          'success'
        );
      } else {
        showToast(`SMS ত্রুটি (${res.error}): ${res.msg}`, 'error');
      }
    } finally {
      setIsSendingTestSms(false);
    }
  };

  const handleCheckSmsReport = async (customReqId?: string | number) => {
    const targetId = String(customReqId ?? reportRequestId).trim();
    if (!smsApiKey.trim() || !targetId) {
      showToast('Alpha SMS API Key এবং Request ID প্রয়োজন', 'error');
      return;
    }
    setReportRequestId(targetId);
    setIsCheckingReport(true);
    try {
      const res = await checkAlphaSmsReport(smsApiKey.trim(), targetId);
      setReportResult(res);
      if (res.error === 0) {
        showToast(
          `রিপোর্ট স্ট্যাটাস: ${res.data?.request_status || 'Success'}`,
          'info'
        );
      } else {
        showToast(res.msg || 'রিপোর্ট পাওয়া যায়নি', 'error');
      }
    } finally {
      setIsCheckingReport(false);
    }
  };

  const openCreateUserModal = () => {
    setEditingUser(null);
    setNewUserName('');
    setNewUserUsername('');
    setNewUserEmail('');
    setNewUserPassword('');
    setNewUserPhone('');
    setNewUserRole('cashier');
    setNewUserOutletId(outlets[0]?.id || 'outlet_01');
    setShowAddUserModal(true);
  };

  const openEditUserModal = (u: User) => {
    setEditingUser(u);
    setNewUserName(u.name);
    setNewUserUsername(u.username || u.email.split('@')[0] || '');
    setNewUserEmail(u.email);
    setNewUserPassword('');
    setNewUserPhone(u.phone || '');
    setNewUserRole(u.role);
    setNewUserOutletId(u.outletId || outlets[0]?.id || 'outlet_01');
    setShowAddUserModal(true);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserEmail.trim() || !newUserUsername.trim()) {
      showToast(
        language === 'bn'
          ? 'নাম, ইউজারনেম এবং ইমেইল অবশ্যই পূরণ করুন'
          : 'Please fill name, username and email',
        'error'
      );
      return;
    }

    if (editingUser) {
      updateUser(editingUser.id, {
        name: newUserName.trim(),
        username: newUserUsername.trim().toLowerCase(),
        email: newUserEmail.trim().toLowerCase(),
        ...(newUserPassword.trim() ? { password: newUserPassword.trim() } : {}),
        phone: newUserPhone.trim() || editingUser.phone,
        role: newUserRole,
        outletId: newUserOutletId
      });
    } else {
      if (!newUserPassword.trim()) {
        showToast(
          language === 'bn' ? 'লগইন পাসওয়ার্ড নির্ধারণ করুন' : 'Please enter a password',
          'error'
        );
        return;
      }
      addUser({
        name: newUserName.trim(),
        username: newUserUsername.trim().toLowerCase(),
        email: newUserEmail.trim().toLowerCase(),
        password: newUserPassword.trim(),
        phone: newUserPhone.trim() || '01700-000000',
        role: newUserRole,
        outletId: newUserOutletId
      });
    }

    setEditingUser(null);
    setNewUserName('');
    setNewUserUsername('');
    setNewUserEmail('');
    setNewUserPassword('');
    setNewUserPhone('');
    setNewUserRole('cashier');
    setShowAddUserModal(false);
  };

  const roleLabels: Record<UserRole, { bn: string; en: string; descBn: string; descEn: string }> = {
    developer: {
      bn: 'সিস্টেম ডেভেলপার (Developer)',
      en: 'System Developer',
      descBn: 'cPanel + MySQL ও সিস্টেম কনফিগারেশন অ্যাক্সেস',
      descEn: 'cPanel + MySQL & System Setup access'
    },
    super_admin: {
      bn: 'সুপার অ্যাডমিন (মালিক)',
      en: 'Super Admin (Owner)',
      descBn: 'সকল মডিউল, হিসাব, রিপোর্ট ও সেটিংস নিয়ন্ত্রণ',
      descEn: 'Full access to all modules, accounting & settings'
    },
    store_manager: {
      bn: 'স্টোর ম্যানেজার',
      en: 'Store Manager',
      descBn: 'ইনভেন্টরি, ক্রয়, পিওএস ও স্টক ট্রান্সফার নিয়ন্ত্রণ',
      descEn: 'Inventory, purchases, POS & stock transfers'
    },
    cashier: {
      bn: 'পিওএস ক্যাশিয়ার',
      en: 'POS Cashier',
      descBn: 'শুধুমাত্র খুচরা পিওএস বিলিং, রিটার্ন ও ডে-এন্ড ক্লোজিং',
      descEn: 'Retail POS billing, returns & day-end close only'
    },
    distribution_mgr: {
      bn: 'ডিস্ট্রিবিউশন ইনচার্জ',
      en: 'Distribution Manager',
      descBn: 'পাইকারি চালান, গুদাম, রুট ও এসআর ব্যবস্থাপনা',
      descEn: 'Wholesale challans, warehouses, routes & SRs'
    },
    sales_rep: {
      bn: 'ফিল্ড এসআর (Sales Rep)',
      en: 'Field Sales Representative',
      descBn: 'রুট অর্ডার গ্রহণ ও ডিলার বকেয়া কালেকশন',
      descEn: 'Route order taking & dealer due collection'
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {language === 'bn'
              ? 'স্টোর লোগো, ডেলিভারি চার্জ ও সিস্টেম সেটিংস'
              : 'Store Logo, Delivery Charge & System Settings'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {language === 'bn'
              ? 'ওয়েবসাইটের লোগো, ই-কমার্স ডেলিভারি চার্জ, বাংলা ফন্ট, আউটলেট ও স্টাফ রোল ম্যানেজমেন্ট'
              : 'Manage website logo, e-commerce delivery fee, Bangla font, outlets & staff roles'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{currentBusiness.planName}</span>
          </span>
        </div>
      </div>

      {/* NEW: Featured Card — Website Store Logo, Delivery Charge & Bangla Typography */}
      <form
        onSubmit={handleSaveSettings}
        className="bg-white rounded-2xl border-2 border-emerald-600/30 shadow-xs overflow-hidden"
      >
        <div className="px-5 py-4 bg-gradient-to-r from-[#004D38] to-[#006A4E] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">
                {language === 'bn'
                  ? 'ওয়েবসাইট লোগো, ই-কমার্স ডেলিভারি চার্জ ও বাংলা ফন্ট সেটিংস'
                  : 'Website Store Logo, Delivery Charge & Bangla Font Settings'}
              </h3>
              <p className="text-[11px] text-emerald-100">
                {language === 'bn'
                  ? 'এখান থেকে পরিবর্তন করলে আপনার মেইন ওয়েবসাইট (domain.com) এবং ইনভয়েসে সাথে সাথে আপডেট হয়ে যাবে'
                  : 'Changes here immediately update your live e-commerce website and invoices'}
              </p>
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
          >
            <Save className="w-4 h-4" />
            <span>{language === 'bn' ? 'সকল সেটিংস সেভ করুন' : 'Save All Settings'}</span>
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6">
          {/* Top Section: Store Branding & Identity (Logo & Favicon) - Balanced 2-Column Responsive Card */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                  <ImageIcon className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    {language === 'bn' ? 'স্টোর ব্র্যান্ডিং ও লোগো সেটিংস (Store Branding & Identity)' : 'Store Branding & Identity'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {language === 'bn'
                      ? 'ওয়েবসাইট হেডার, ইনভয়েস ক্যাশ মেমো এবং ব্রাউজার ট্যাবের জন্য লোগো ও ফেভিকন সেট করুন'
                      : 'Set logo & favicon for storefront header, invoice slips, and browser tab'}
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-bold px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg self-start sm:self-auto">
                {language === 'bn' ? '🎨 ব্র্যান্ড আইডেন্টিটি' : 'Brand Identity'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Store Logo Box */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/90 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4 text-emerald-700" />
                      <span>{language === 'bn' ? 'স্টোরের লোগো (Website & Invoice Logo)' : 'Store Logo'}</span>
                    </label>
                    {logoUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          confirmDelete({
                            title: 'স্টোরের লোগো মুছে ফেলতে চান?',
                            itemName: currentBusiness.name,
                            message: 'ওয়েবসাইট, ইনভয়েস এবং অ্যাডমিন লগইন পেজ থেকে বর্তমান লোগোটি সরে যাবে।',
                            confirmLabel: 'হ্যাঁ, লোগো মুছুন',
                            onConfirm: () => {
                              setLogoUrl('');
                              updateBusiness({ logoUrl: undefined });
                              showToast(language === 'bn' ? 'লোগো মুছে ফেলা হয়েছে' : 'Logo removed', 'info');
                            }
                          });
                        }}
                        className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{language === 'bn' ? 'লোগো মুছুন' : 'Remove'}</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Live Logo Preview Box */}
                    <div className="w-20 h-20 rounded-xl bg-white border-2 border-dashed border-slate-300 flex items-center justify-center p-1.5 shrink-0 overflow-hidden shadow-2xs">
                      {logoUrl ? (
                        <img
                          src={logoUrl}
                          alt="Store Logo Preview"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <div className="text-center text-[10px] text-slate-400 font-semibold leading-tight">
                          <ImageIcon className="w-6 h-6 mx-auto mb-1 text-slate-300" />
                          <span>No Logo</span>
                        </div>
                      )}
                    </div>

                    <div className="flex-1 space-y-2">
                      <label className="w-full min-h-[38px] px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs">
                        <Upload className="w-4 h-4" />
                        <span>
                          {isUploadingLogo
                            ? language === 'bn'
                              ? 'আপলোড হচ্ছে...'
                              : 'Uploading...'
                            : language === 'bn'
                            ? 'লোগো ছবি আপলোড করুন'
                            : 'Upload Logo Image'}
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoFileChange}
                          className="hidden"
                        />
                      </label>

                      <input
                        type="text"
                        value={logoUrl.startsWith('data:') ? '' : logoUrl}
                        onChange={(e) => setLogoUrl(e.target.value)}
                        placeholder={language === 'bn' ? 'অথবা লোগো ইমেজ লিংক (URL) দিন...' : 'Or paste logo URL...'}
                        className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-800 outline-hidden"
                      />
                    </div>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed pt-2 border-t border-slate-200/60">
                  {language === 'bn'
                    ? 'টিপস: স্বচ্ছ ব্যাকগ্রাউন্ডের (PNG / JPG) লোগো আপলোড করলে ওয়েবসাইটের হেডার এবং প্রিন্টেড রশিদে সবচেয়ে সুন্দর দেখাবে।'
                    : 'Tip: Upload a square or horizontal PNG/JPG logo for best appearance on storefront header and receipts.'}
                </p>
              </div>

              {/* Favicon Upload & Preview Box */}
              <div className="bg-indigo-50/50 rounded-xl p-4 border border-indigo-200/80 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <label className="text-xs font-extrabold text-indigo-950 flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-indigo-600" />
                      <span>
                        {language === 'bn'
                          ? 'ওয়েবসাইট ফেভিকন (Favicon / ব্রাউজার ট্যাব আইকন)'
                          : 'Website Favicon (Browser Tab Icon)'}
                      </span>
                    </label>
                    <div className="flex items-center gap-2">
                      {logoUrl && faviconUrl !== logoUrl && (
                        <button
                          type="button"
                          onClick={() => {
                            setFaviconUrl(logoUrl);
                            updateBusiness({ faviconUrl: logoUrl });
                            showToast(
                              language === 'bn'
                                ? 'স্টোরের লোগো ফেভিকন হিসেবে সেট করা হয়েছে!'
                                : 'Store logo set as favicon!',
                              'success'
                            );
                          }}
                          className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 hover:bg-indigo-200 text-indigo-800 cursor-pointer transition-colors"
                        >
                          {language === 'bn' ? 'লোগো ব্যবহার করুন' : 'Use Logo'}
                        </button>
                      )}
                      {faviconUrl && (
                        <button
                          type="button"
                          onClick={() => {
                            confirmDelete({
                              title: 'ওয়েবসাইটের ফেভিকন (Favicon) মুছে ফেলতে চান?',
                              itemName: 'Browser Tab Icon (Favicon)',
                              message: 'ব্রাউজার ট্যাব থেকে কাস্টম ফেভিকনটি মুছে যাবে।',
                              confirmLabel: 'হ্যাঁ, ফেভিকন মুছুন',
                              onConfirm: () => {
                                setFaviconUrl('');
                                updateBusiness({ faviconUrl: undefined });
                                showToast(
                                  language === 'bn' ? 'ফেভিকন মুছে ফেলা হয়েছে' : 'Favicon removed',
                                  'info'
                                );
                              }
                            });
                          }}
                          className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'মুছুন' : 'Remove'}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Live Favicon Preview Box */}
                    <div className="w-16 h-16 rounded-xl bg-white border-2 border-dashed border-indigo-300 flex flex-col items-center justify-center p-1.5 shrink-0 overflow-hidden shadow-2xs">
                      {faviconUrl || logoUrl ? (
                        <img
                          src={faviconUrl || logoUrl}
                          alt="Favicon Preview"
                          className="w-10 h-10 object-contain rounded"
                        />
                      ) : (
                        <div className="text-center text-[9px] text-slate-400 font-semibold leading-tight">
                          <Globe className="w-5 h-5 mx-auto mb-0.5 text-slate-300" />
                          <span>32×32</span>
                        </div>
                      )}
                    </div>

                    <div className="flex-1 space-y-2">
                      <label className="w-full min-h-[36px] px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs">
                        <Upload className="w-3.5 h-3.5" />
                        <span>
                          {isUploadingFavicon
                            ? language === 'bn'
                              ? 'ফেভিকন আপলোড হচ্ছে...'
                              : 'Uploading Favicon...'
                            : language === 'bn'
                            ? 'ফেভিকন আইকন আপলোড করুন'
                            : 'Upload Favicon Icon'}
                        </span>
                        <input
                          type="file"
                          accept="image/*,.ico"
                          onChange={handleFaviconFileChange}
                          className="hidden"
                        />
                      </label>

                      <input
                        type="text"
                        value={faviconUrl.startsWith('data:') ? '' : faviconUrl}
                        onChange={(e) => setFaviconUrl(e.target.value)}
                        placeholder={
                          language === 'bn'
                            ? 'অথবা ফেভিকন আইকন লিংক (URL) দিন...'
                            : 'Or paste favicon URL...'
                        }
                        className="w-full px-3 py-1.5 text-xs bg-white border border-indigo-200 rounded-lg text-slate-800 outline-hidden"
                      />
                    </div>
                  </div>
                </div>
                <p className="text-[11px] text-indigo-900/80 leading-relaxed pt-2 border-t border-indigo-200/60">
                  {language === 'bn'
                    ? 'ব্রাউজারের ট্যাবে ও বুকমার্কে সাইটের নামের পাশে এই ছোট আইকনটি (স্কয়ার PNG/ICO) দেখা যাবে। আলাদা না দিলে স্টোর লোগো অটোমেটিক ব্যবহৃত হবে।'
                    : 'Displayed in browser tabs and bookmarks next to your page title. Falls back to store logo if left empty.'}
                </p>
              </div>
            </div>
          </div>

          {/* Main Storefront Settings Grid (Full Width & Clean 2-Column Responsive Flow) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Top Announcement Scrolling Bar (ON/OFF + Editable Text + Speed Control) */}
            <div className="sm:col-span-2 bg-gradient-to-r from-emerald-50/90 via-teal-50/75 to-amber-50/80 rounded-xl p-4 border-2 border-emerald-500/60 shadow-2xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-emerald-200/70">
                <div className="space-y-0.5">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>
                      টপ অ্যানাউন্সমেন্ট বার (Top Scrolling Announcement Bar — টেক্সট পরিবর্তন ও ON / OFF)
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    ওয়েবসাইটের একদম ওপরে যে স্ক্রলিং লেখাটি চলে সেটি ১-ক্লিকে চালু (ON) বা বন্ধ (OFF) করুন এবং নিজের মতো যেকোনো টেক্সট লিখে পরিবর্তন করুন।
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const nextVal = !topAnnouncementEnabled;
                      setTopAnnouncementEnabled(nextVal);
                      updateBusiness({
                        topAnnouncementEnabled: nextVal,
                        topAnnouncementText: topAnnouncementText.trim() || DEFAULT_ANNOUNCEMENT_TEXT,
                        topAnnouncementSpeed
                      });
                      showToast(
                        nextVal
                          ? 'ওয়েবসাইটের টপ অ্যানাউন্সমেন্ট বার চালু (ON) করা হয়েছে!'
                          : 'ওয়েবসাইটের টপ অ্যানাউন্সমেন্ট বার বন্ধ (OFF) করা হয়েছে!',
                        nextVal ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      topAnnouncementEnabled
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {topAnnouncementEnabled
                        ? '📢 অ্যানাউন্সমেন্ট বার: চালু (ON)'
                        : 'অ্যানাউন্সমেন্ট বার: বন্ধ (OFF)'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const nextVal = !topUtilityBarEnabled;
                      setTopUtilityBarEnabled(nextVal);
                      updateBusiness({
                        topUtilityBarEnabled: nextVal
                      });
                      showToast(
                        nextVal
                          ? 'স্টোরফ্রন্ট হটলাইন ও লগইন টপ বার চালু (ON) করা হয়েছে!'
                          : 'স্টোরফ্রন্ট হটলাইন ও লগইন টপ বার হাইড (OFF) করা হয়েছে!',
                        nextVal ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      topUtilityBarEnabled
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                    title="হটলাইন ও লগইন / সাইনআপ বাটন থাকা টপ বারটি চালু (ON) বা বন্ধ (OFF) করুন"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {topUtilityBarEnabled
                        ? '🔝 হটলাইন ও লগইন বার: চালু (ON)'
                        : 'হটলাইন ও লগইন বার: বন্ধ (OFF)'}
                    </span>
                  </button>
                </div>
              </div>

              <div className="space-y-2.5">
                <label className="block text-xs font-extrabold text-slate-800">
                  স্ক্রলিং অ্যানাউন্সমেন্ট টেক্সট লিখুন (পরিবর্তন করে "টেক্সট সেভ করুন" ক্লিক করুন):
                </label>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <input
                    type="text"
                    value={topAnnouncementText}
                    onChange={(e) => setTopAnnouncementText(e.target.value)}
                    placeholder="❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি..."
                    className="flex-1 min-h-[42px] px-3.5 py-2 bg-white border-2 border-emerald-500/70 focus:border-emerald-700 rounded-xl text-xs sm:text-sm font-bold text-slate-900 outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const cleanText = topAnnouncementText.trim() || DEFAULT_ANNOUNCEMENT_TEXT;
                      setTopAnnouncementText(cleanText);
                      updateBusiness({
                        topAnnouncementEnabled,
                        topAnnouncementText: cleanText,
                        topAnnouncementSpeed
                      });
                      showToast('টপ অ্যানাউন্সমেন্ট বারের টেক্সট সফলভাবে আপডেট হয়েছে!', 'success');
                    }}
                    className="min-h-[42px] px-4 py-2 bg-[#047857] hover:bg-[#065F46] text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shrink-0 shadow-2xs"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>টেক্সট সেভ করুন</span>
                  </button>
                </div>

                {/* Quick Presets & Scroll Speed Selector */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold text-slate-600">রেডিমেড টেক্সট:</span>
                    {[
                      {
                        label: '❄️ উইন্টার কালেকশন (ডিফল্ট)',
                        text: '❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।'
                      },
                      {
                        label: '🔥 ফ্ল্যাশ সেল অফার',
                        text: '🔥 উইন্টার ফ্ল্যাশ সেল চলছে! সকল শীতের পোশাকে বিশেষ ছাড় — আজই অর্ডার করুন, সারাদেশে হোম ডেলিভারি।'
                      },
                      {
                        label: '🚚 ফ্রি ডেলিভারি অফার',
                        text: '🚚 ২টি প্রোডাক্ট একসাথে অর্ডার করলেই সারা বাংলাদেশে ডেলিভারি চার্জ সম্পূর্ণ ফ্রি! পণ্য হাতে পেয়ে পেমেন্ট।'
                      }
                    ].map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => {
                          setTopAnnouncementText(preset.text);
                          setTopAnnouncementEnabled(true);
                          updateBusiness({
                            topAnnouncementEnabled: true,
                            topAnnouncementText: preset.text,
                            topAnnouncementSpeed
                          });
                          showToast(`"${preset.label}" টেক্সট সেট করা হয়েছে!`, 'success');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 text-[11px] font-bold transition-colors cursor-pointer"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-bold text-slate-600">স্ক্রলিং ধরন:</span>
                    {(
                      [
                        { id: 'normal', label: 'সাধারণ স্ক্রল' },
                        { id: 'slow', label: 'ধীর স্ক্রল' },
                        { id: 'fast', label: 'দ্রুত স্ক্রল' },
                        { id: 'static', label: 'স্থির (Static)' }
                      ] as const
                    ).map((sp) => (
                      <button
                        key={sp.id}
                        type="button"
                        onClick={() => {
                          setTopAnnouncementSpeed(sp.id);
                          updateBusiness({ topAnnouncementSpeed: sp.id });
                          showToast(`স্ক্রলিং ধরন "${sp.label}" সেট করা হয়েছে!`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                          topAnnouncementSpeed === sp.id
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {sp.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* ❄️ 1-Click Winter Theme & Falling Snow Animation Toggle + Intensity, Speed & Auto-Off Timer */}
            <div className="sm:col-span-2 bg-gradient-to-r from-sky-50 via-white to-blue-50/90 rounded-xl p-4 border-2 border-sky-400/70 shadow-2xs space-y-4">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <span className="text-base leading-none">❄️☀️🌙🕌</span>
                    <span>
                      Seasonal Themes (Winter, Summer, Ramadan &amp; Eid) &amp; Particle Animation Control
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    ১-ক্লিকে পুরো ওয়েবসাইটে <span className="font-bold text-sky-800">❄️ Winter Theme</span>, <span className="font-bold text-amber-700">☀️ Summer Mango Theme</span>, <span className="font-bold text-teal-800">🌙 Ramadan Noor Theme</span> অথবা <span className="font-bold text-purple-800">🕌 Eid Vacation Theme</span> চালু করুন এবং স্ক্রিনের ওপর মৌসুমি অ্যানিমেশন কণা (❄️/☀️/🌙/🕌), গতি (Speed) ও অটো-অফ টাইমার নিয়ন্ত্রণ করুন।
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const isCurrentlyWinter =
                        Boolean(currentBusiness.winterThemeEnabled) ||
                        currentBusiness.storefrontTheme === 'winter_frost' ||
                        storefrontTheme === 'winter_frost';
                      const nextWinter = !isCurrentlyWinter;
                      const nextTheme: StorefrontThemeStyle = nextWinter
                        ? 'winter_frost'
                        : 'emerald_default';
                      setStorefrontTheme(nextTheme);
                      updateBusiness({
                        winterThemeEnabled: nextWinter,
                        storefrontTheme: nextTheme,
                        ...(nextWinter ? { winterSnowfallEnabled: true } : {})
                      });
                      showToast(
                        nextWinter
                          ? '❄️ Winter Theme (Cool Blues & Snowy Whites) চালু (ON) করা হয়েছে!'
                          : 'Winter Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextWinter ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      Boolean(currentBusiness.winterThemeEnabled) ||
                      currentBusiness.storefrontTheme === 'winter_frost'
                        ? 'bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white ring-2 ring-sky-400/40'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      {Boolean(currentBusiness.winterThemeEnabled) ||
                      currentBusiness.storefrontTheme === 'winter_frost'
                        ? '❄️ Winter: ON'
                        : '❄️ Winter: OFF'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isSummer =
                        currentBusiness.storefrontTheme === 'summer_mango' ||
                        storefrontTheme === 'summer_mango';
                      const nextSummer = !isSummer;
                      const nextTheme: StorefrontThemeStyle = nextSummer
                        ? 'summer_mango'
                        : 'emerald_default';
                      setStorefrontTheme(nextTheme);
                      updateBusiness({
                        winterThemeEnabled: false,
                        storefrontTheme: nextTheme,
                        ...(nextSummer ? { winterSnowfallEnabled: true } : {})
                      });
                      showToast(
                        nextSummer
                          ? '☀️ Summer Sunshine & Mango Theme চালু (ON) করা হয়েছে!'
                          : 'Summer Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextSummer ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      currentBusiness.storefrontTheme === 'summer_mango'
                        ? 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white ring-2 ring-amber-400/40'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      {currentBusiness.storefrontTheme === 'summer_mango'
                        ? '☀️ Summer: ON'
                        : '☀️ Summer: OFF'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isRamadan =
                        currentBusiness.storefrontTheme === 'ramadan_noor' ||
                        storefrontTheme === 'ramadan_noor';
                      const nextRamadan = !isRamadan;
                      const nextTheme: StorefrontThemeStyle = nextRamadan
                        ? 'ramadan_noor'
                        : 'emerald_default';
                      setStorefrontTheme(nextTheme);
                      updateBusiness({
                        winterThemeEnabled: false,
                        storefrontTheme: nextTheme,
                        ...(nextRamadan ? { winterSnowfallEnabled: true } : {})
                      });
                      showToast(
                        nextRamadan
                          ? '🌙 Ramadan Noor & Royal Gold Theme চালু (ON) করা হয়েছে!'
                          : 'Ramadan Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextRamadan ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      currentBusiness.storefrontTheme === 'ramadan_noor'
                        ? 'bg-gradient-to-r from-teal-700 to-amber-600 hover:from-teal-800 hover:to-amber-700 text-white ring-2 ring-amber-400/40'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      {currentBusiness.storefrontTheme === 'ramadan_noor'
                        ? '🌙 Ramadan: ON'
                        : '🌙 Ramadan: OFF'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isEid =
                        currentBusiness.storefrontTheme === 'eid_festive' ||
                        storefrontTheme === 'eid_festive';
                      const nextEid = !isEid;
                      const nextTheme: StorefrontThemeStyle = nextEid
                        ? 'eid_festive'
                        : 'emerald_default';
                      setStorefrontTheme(nextTheme);
                      updateBusiness({
                        winterThemeEnabled: false,
                        storefrontTheme: nextTheme,
                        ...(nextEid ? { winterSnowfallEnabled: true } : {})
                      });
                      showToast(
                        nextEid
                          ? '🕌 Eid Mubarak & Festive Vacation Theme চালু (ON) করা হয়েছে!'
                          : 'Eid Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextEid ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      currentBusiness.storefrontTheme === 'eid_festive'
                        ? 'bg-gradient-to-r from-purple-700 to-pink-600 hover:from-purple-800 hover:to-pink-700 text-white ring-2 ring-purple-400/40'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      {currentBusiness.storefrontTheme === 'eid_festive'
                        ? '🕌 Eid Theme: ON'
                        : '🕌 Eid Theme: OFF'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isSnowOn = currentBusiness.winterSnowfallEnabled !== false;
                      const nextSnow = !isSnowOn;
                      updateBusiness({
                        winterSnowfallEnabled: nextSnow
                      });
                      showToast(
                        nextSnow
                          ? '✨ মৌসুমি অ্যানিমেশন কণা (Seasonal Particles Overlay) চালু (ON) করা হয়েছে!'
                          : 'মৌসুমি অ্যানিমেশন কণা (Seasonal Particles Overlay) বন্ধ (OFF) করা হয়েছে।',
                        nextSnow ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                      currentBusiness.winterSnowfallEnabled !== false
                        ? 'bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-700 hover:to-sky-700 text-white ring-2 ring-cyan-400/40'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      {currentBusiness.winterSnowfallEnabled !== false
                        ? '✨ Animation: ON'
                        : '✨ Animation: OFF'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Detailed Snowfall Intensity, Falling Speed & Auto-Off Timer Controls */}
              <div className="pt-3 border-t border-sky-200/80 grid grid-cols-1 lg:grid-cols-3 gap-3.5">
                {/* 1. Snowfall Intensity Slider (Particle Count + CSS Speed) */}
                <div className="bg-white/90 rounded-xl p-3.5 border border-sky-200/90 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <span>🌨️ Snowfall Intensity (তুষারপাতের ঘনত্ব)</span>
                    </label>
                    <span className="px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-900 border border-sky-300 font-mono text-[11px] font-extrabold">
                      {snowfallIntensity}% ({Math.max(6, Math.min(80, Math.round((snowfallIntensity / 100) * 68)))} কণা)
                    </span>
                  </div>

                  <input
                    type="range"
                    min={10}
                    max={100}
                    step={5}
                    value={snowfallIntensity}
                    onChange={(e) => {
                      const nextVal = Number(e.target.value) || 50;
                      setSnowfallIntensity(nextVal);
                      updateBusiness({
                        winterSnowfallEnabled: true,
                        winterSnowfallIntensity: nextVal
                      });
                    }}
                    className="w-full h-2 bg-sky-100 rounded-lg appearance-none cursor-pointer accent-sky-600"
                  />

                  <div className="flex flex-wrap items-center justify-between gap-1.5">
                    {[
                      { val: 25, label: 'হালকা (25%)' },
                      { val: 50, label: 'মাঝারি (50%)' },
                      { val: 85, label: 'ঘন তুষারপাত (85%)' }
                    ].map((preset) => (
                      <button
                        key={preset.val}
                        type="button"
                        onClick={() => {
                          setSnowfallIntensity(preset.val);
                          updateBusiness({
                            winterSnowfallEnabled: true,
                            winterSnowfallIntensity: preset.val
                          });
                          showToast(`তুষারপাতের ঘনত্ব "${preset.label}" সেট করা হয়েছে!`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                          snowfallIntensity === preset.val
                            ? 'bg-sky-600 text-white border-sky-600'
                            : 'bg-sky-50/70 text-sky-900 border-sky-200 hover:bg-sky-100'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-slate-500">
                    স্লাইডার বাড়ালে তুষারকণার সংখ্যা (Particle Count) এবং অ্যানিমেশন স্পিড বাড়বে।
                  </p>
                </div>

                {/* 2. Snow Falling Speed Slider (তুষার পড়ার গতি — Slow to Fast) */}
                <div className="bg-white/90 rounded-xl p-3.5 border border-sky-200/90 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <span>💨 তুষার পড়ার গতি (Falling Speed)</span>
                    </label>
                    <span className="px-2.5 py-0.5 rounded-full bg-cyan-100 text-cyan-900 border border-cyan-300 font-mono text-[11px] font-extrabold">
                      {snowfallSpeed}% {snowfallSpeed < 75 ? '(ধীর)' : snowfallSpeed > 130 ? '(দ্রুত)' : '(স্বাভাবিক)'}
                    </span>
                  </div>

                  <input
                    type="range"
                    min={30}
                    max={200}
                    step={10}
                    value={snowfallSpeed}
                    onChange={(e) => {
                      const nextSpd = Number(e.target.value) || 100;
                      setSnowfallSpeed(nextSpd);
                      updateBusiness({
                        winterSnowfallEnabled: true,
                        winterSnowfallSpeed: nextSpd
                      });
                    }}
                    className="w-full h-2 bg-cyan-100 rounded-lg appearance-none cursor-pointer accent-cyan-600"
                  />

                  <div className="flex flex-wrap items-center justify-between gap-1.5">
                    {[
                      { val: 50, label: 'ধীর (Slow)' },
                      { val: 100, label: 'স্বাভাবিক (Normal)' },
                      { val: 160, label: 'দ্রুত (Fast)' }
                    ].map((spPreset) => (
                      <button
                        key={spPreset.val}
                        type="button"
                        onClick={() => {
                          setSnowfallSpeed(spPreset.val);
                          updateBusiness({
                            winterSnowfallEnabled: true,
                            winterSnowfallSpeed: spPreset.val
                          });
                          showToast(`তুষার পড়ার গতি "${spPreset.label}" সেট করা হয়েছে!`, 'info');
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                          snowfallSpeed === spPreset.val
                            ? 'bg-cyan-600 text-white border-cyan-600'
                            : 'bg-cyan-50/70 text-cyan-900 border-cyan-200 hover:bg-cyan-100'
                        }`}
                      >
                        {spPreset.label}
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-slate-500">
                    তুষারকণা কত দ্রুত বা ধীরে স্ক্রিনের ওপর থেকে নিচে পড়বে তা নির্ধারণ করুন।
                  </p>
                </div>

                {/* 3. Auto-Off Timer (কত সেকেন্ড পরে অটো বন্ধ হয়ে যাবে) */}
                <div className="bg-white/90 rounded-xl p-3.5 border border-sky-200/90 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-sky-700 shrink-0" />
                      <span>অটো-অফ টাইমার (কত সেকেন্ড পরে বন্ধ হবে)</span>
                    </label>
                    <span
                      className={`px-2.5 py-0.5 rounded-full font-mono text-[11px] font-extrabold border ${
                        snowfallAutoOffSec > 0
                          ? 'bg-amber-100 text-amber-900 border-amber-300'
                          : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      }`}
                    >
                      {snowfallAutoOffSec > 0
                        ? `${snowfallAutoOffSec} সেকেন্ড পর বন্ধ`
                        : 'সবসময় চলবে (Always On)'}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {[
                      { sec: 0, label: '♾️ সবসময় চলবে' },
                      { sec: 5, label: '৫ সেকেন্ড' },
                      { sec: 10, label: '১০ সেকেন্ড' },
                      { sec: 15, label: '১৫ সেকেন্ড' },
                      { sec: 30, label: '৩০ সেকেন্ড' },
                      { sec: 60, label: '৬০ সেকেন্ড' }
                    ].map((timerOpt) => (
                      <button
                        key={timerOpt.sec}
                        type="button"
                        onClick={() => {
                          setSnowfallAutoOffSec(timerOpt.sec);
                          updateBusiness({
                            winterSnowfallEnabled: true,
                            winterSnowfallAutoOffSec: timerOpt.sec
                          });
                          showToast(
                            timerOpt.sec === 0
                              ? 'তুষারপাত অ্যানিমেশন সবসময় চালু (Always On) রাখা হয়েছে!'
                              : `তুষারপাত অ্যানিমেশন ${timerOpt.sec} সেকেন্ড পর অটো বন্ধ হয়ে যাবে!`,
                            'success'
                          );
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                          snowfallAutoOffSec === timerOpt.sec
                            ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                            : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {timerOpt.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pt-0.5">
                    <span className="text-[11px] font-bold text-slate-600 shrink-0">
                      কাস্টম সেকেন্ড:
                    </span>
                    <input
                      type="number"
                      min={0}
                      max={600}
                      step={1}
                      value={snowfallAutoOffSec}
                      onChange={(e) => {
                        const nextSec = Math.max(0, Number(e.target.value) || 0);
                        setSnowfallAutoOffSec(nextSec);
                        updateBusiness({
                          winterSnowfallEnabled: true,
                          winterSnowfallAutoOffSec: nextSec
                        });
                      }}
                      className="w-20 min-h-[32px] px-2.5 py-1 bg-white border border-sky-300 focus:border-sky-600 rounded-lg font-mono text-xs font-extrabold text-slate-900 outline-hidden"
                    />
                    <span className="text-[10px] text-slate-500">
                      (0 = অটো বন্ধ হবে না)
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* ⚡ Home Page Smart Hybrid Infinite Scroll + Load More Control */}
            <div className="sm:col-span-2 bg-gradient-to-r from-emerald-50/90 via-white to-teal-50/80 rounded-xl p-4 border-2 border-emerald-300/80 shadow-2xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                      ⚡ হোমপেজ স্মার্ট অটো স্ক্রল ও লোড মোর সিস্টেম (Auto Scroll + Load More)
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                        currentBusiness.homeInfiniteScrollEnabled !== false
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-200 text-slate-700 border-slate-300'
                      }`}
                    >
                      {currentBusiness.homeInfiniteScrollEnabled !== false ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600">
                    শুরুতে নির্দিষ্ট সংখ্যক প্রোডাক্ট দেখাবে এবং কাস্টমার নিচে স্ক্রল করলে অটোমেটিক পরের প্রোডাক্টগুলো লোড হবে (সার্চ করলে সাথে সাথে সব প্রোডাক্ট থেকে দেখাবে)।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const cur = currentBusiness.homeInfiniteScrollEnabled !== false;
                    const next = !cur;
                    updateBusiness({ homeInfiniteScrollEnabled: next });
                    showToast(
                      next
                        ? 'হোমপেজ অটো স্ক্রল লোড চালু (ON) করা হয়েছে!'
                        : 'হোমপেজ অটো স্ক্রল লোড বন্ধ (OFF) করা হয়েছে!',
                      next ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[38px] px-4 py-2 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                    currentBusiness.homeInfiniteScrollEnabled !== false
                      ? 'bg-emerald-700 hover:bg-emerald-800 text-white border-emerald-700 shadow-xs'
                      : 'bg-white hover:bg-emerald-50 text-slate-800 border-slate-300'
                  }`}
                >
                  {currentBusiness.homeInfiniteScrollEnabled !== false
                    ? '✓ অটো স্ক্রল: ON (বন্ধ করুন)'
                    : 'অটো স্ক্রল: OFF (চালু করুন)'}
                </button>
              </div>

              {currentBusiness.homeInfiniteScrollEnabled !== false && (
                <div className="pt-2 border-t border-emerald-200/70 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-800">
                    শুরুতে এবং প্রতিবার স্ক্রল করলে কয়টি করে প্রোডাক্ট লোড হবে:
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {[
                      { count: 12, label: '১২টি করে' },
                      { count: 20, label: '২০টি করে (সেরা)' },
                      { count: 30, label: '৩০টি করে' },
                      { count: 40, label: '৪০টি করে' }
                    ].map(opt => {
                      const activeBatch = Number(currentBusiness.homeProductsPerBatch) || 20;
                      const isSel = activeBatch === opt.count;
                      return (
                        <button
                          key={opt.count}
                          type="button"
                          onClick={() => {
                            updateBusiness({
                              homeInfiniteScrollEnabled: true,
                              homeProductsPerBatch: opt.count
                            });
                            showToast(
                              `হোমপেজে প্রতি ধাপে ${opt.count}টি করে প্রোডাক্ট লোড সেট করা হয়েছে!`,
                              'success'
                            );
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                            isSel
                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                              : 'bg-white hover:bg-emerald-50 text-slate-800 border-emerald-200'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* 🛡️ Daily Order Limit by Mobile Number & IP/Device + Editable Clean Error Popup */}
            <div className="sm:col-span-2 bg-gradient-to-r from-rose-50/90 via-white to-indigo-50/80 rounded-xl p-4 border-2 border-rose-300/80 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                        🛡️ ফেক অর্ডার প্রতিরোধ: দৈনিক অর্ডার লিমিট ও পপআপ মেসেজ কন্ট্রোল (Same Product & Total Daily Limit)
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                          dailyOrderLimitEnabled
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                            : 'bg-slate-200 text-slate-600 border-slate-300'
                        }`}
                      >
                        {dailyOrderLimitEnabled
                          ? `চালু আছে (একই পণ্য ${dailySameProductMaxCount} বার • মোট ${dailyOrderMaxCount}টি অর্ডার/দিন)`
                          : 'বন্ধ আছে ( আনলিমিটেড অর্ডার )'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      একই মোবাইল নাম্বার বা IP/ডিভাইস থেকে দিনে একই প্রোডাক্ট {dailySameProductMaxCount} বারের বেশি অথবা অন্য প্রোডাক্ট মিলিয়ে মোট {dailyOrderMaxCount}টির বেশি অর্ডার করলে অটোমেটিক ব্লক হবে এবং কাস্টমারকে পপআপে কল ও হোয়াটসঅ্যাপ বাটন দেখাবে।
                    </p>
                  </div>
                </div>

                {/* Master ON / OFF Switch */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowLimitPopupPreview(true)}
                    className="px-3 py-2 rounded-xl text-xs font-extrabold border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 transition-all cursor-pointer"
                  >
                    👁️ পপআপ প্রিভিউ
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const nextState = !dailyOrderLimitEnabled;
                      setDailyOrderLimitEnabled(nextState);
                      updateBusiness({
                        dailyOrderLimitEnabled: nextState,
                        dailySameProductMaxCount: Math.max(1, Number(dailySameProductMaxCount) || 2),
                        dailyOrderMaxCount: Math.max(1, Number(dailyOrderMaxCount) || 5),
                        dailyOrderLimitTitle:
                          dailyOrderLimitTitle.trim() || DEFAULT_DAILY_ORDER_LIMIT_TITLE,
                        dailyOrderLimitMessage:
                          dailyOrderLimitMessage.trim() || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
                      });
                      showToast(
                        nextState
                          ? `দৈনিক অর্ডার লিমিট চালু (ON) করা হয়েছে! (একই প্রোডাক্ট ${dailySameProductMaxCount} বার, মোট ${dailyOrderMaxCount}টি)`
                          : 'দৈনিক অর্ডার লিমিট বন্ধ (OFF) করা হয়েছে!',
                        nextState ? 'success' : 'info'
                      );
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                      dailyOrderLimitEnabled
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-700 border-slate-300'
                    }`}
                  >
                    {dailyOrderLimitEnabled ? '✅ লিমিট চালু আছে (ON)' : '❌ লিমিট বন্ধ (OFF)'}
                  </button>
                </div>
              </div>

              {/* Controls Grid: Dual Order Limits + Editable Popup Message */}
              <div
                className={`grid grid-cols-1 lg:grid-cols-12 gap-3.5 pt-2 border-t border-rose-200/70 transition-opacity ${
                  dailyOrderLimitEnabled ? 'opacity-100' : 'opacity-65'
                }`}
              >
                {/* 1. Dual Order Limit Controls: Same Product (default 2) + Total Daily Across Products (default 5) */}
                <div className="lg:col-span-5 bg-white/95 rounded-xl p-3.5 border border-rose-200/90 space-y-3">
                  {/* Rule A: Same Product Limit (default 2 times) */}
                  <div className="space-y-2 pb-2.5 border-b border-rose-100">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-extrabold text-slate-900">
                        ১(ক). একই প্রোডাক্ট কয়বার অর্ডার করলে ব্লক হবে?
                      </label>
                      <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300 font-mono text-[11px] font-extrabold shrink-0">
                        {dailySameProductMaxCount} বার (Same Product)
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <div className="grid grid-cols-4 gap-1.5 flex-1">
                        {[1, 2, 3, 5].map(cnt => {
                          const isSelected = Number(dailySameProductMaxCount) === cnt;
                          return (
                            <button
                              key={cnt}
                              type="button"
                              onClick={() => {
                                setDailySameProductMaxCount(cnt);
                                setDailyOrderLimitEnabled(true);
                                updateBusiness({
                                  dailyOrderLimitEnabled: true,
                                  dailySameProductMaxCount: cnt,
                                  dailyOrderMaxCount: Math.max(1, Number(dailyOrderMaxCount) || 5)
                                });
                                showToast(
                                  `একই প্রোডাক্ট দিনে সর্বোচ্চ ${cnt} বার অর্ডারের লিমিট সেট করা হয়েছে!`,
                                  'success'
                                );
                              }}
                              className={`py-1.5 px-2 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                                isSelected
                                  ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                  : 'bg-rose-50/70 text-slate-800 border-rose-200 hover:bg-rose-100'
                              }`}
                            >
                              {cnt} বার
                            </button>
                          );
                        })}
                      </div>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        step={1}
                        value={dailySameProductMaxCount}
                        onChange={e => {
                          const nextVal = Math.max(1, Math.min(50, Number(e.target.value) || 1));
                          setDailySameProductMaxCount(nextVal);
                          updateBusiness({
                            dailyOrderLimitEnabled: true,
                            dailySameProductMaxCount: nextVal,
                            dailyOrderMaxCount: Math.max(1, Number(dailyOrderMaxCount) || 5)
                          });
                        }}
                        className="w-16 min-h-[32px] px-2 py-1 bg-white border-2 border-rose-300 focus:border-rose-600 rounded-lg font-mono text-xs font-extrabold text-slate-900 text-center outline-hidden"
                        title="একই প্রোডাক্ট সর্বোচ্চ কয়বার অর্ডার করা যাবে"
                      />
                    </div>
                  </div>

                  {/* Rule B: Total Products Limit (default 5 orders across all/other products) */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-extrabold text-slate-900">
                        ১(খ). অন্য সব প্রোডাক্ট মিলিয়ে মোট কয়টি অর্ডার করা যাবে?
                      </label>
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-300 font-mono text-[11px] font-extrabold shrink-0">
                        মোট {dailyOrderMaxCount} টি / দিন
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <div className="grid grid-cols-5 gap-1.5 flex-1">
                        {[2, 3, 5, 8, 10].map(cnt => {
                          const isSelected = Number(dailyOrderMaxCount) === cnt;
                          return (
                            <button
                              key={cnt}
                              type="button"
                              onClick={() => {
                                setDailyOrderMaxCount(cnt);
                                setDailyOrderLimitEnabled(true);
                                updateBusiness({
                                  dailyOrderLimitEnabled: true,
                                  dailySameProductMaxCount: Math.max(
                                    1,
                                    Number(dailySameProductMaxCount) || 2
                                  ),
                                  dailyOrderMaxCount: cnt
                                });
                                showToast(
                                  `অন্য প্রোডাক্ট মিলিয়ে দিনে মোট ${cnt}টি অর্ডারের লিমিট সেট করা হয়েছে!`,
                                  'success'
                                );
                              }}
                              className={`py-1.5 px-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                                isSelected
                                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                                  : 'bg-indigo-50/70 text-slate-800 border-indigo-200 hover:bg-indigo-100'
                              }`}
                            >
                              {cnt} টি
                            </button>
                          );
                        })}
                      </div>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        step={1}
                        value={dailyOrderMaxCount}
                        onChange={e => {
                          const nextVal = Math.max(1, Math.min(100, Number(e.target.value) || 1));
                          setDailyOrderMaxCount(nextVal);
                          updateBusiness({
                            dailyOrderLimitEnabled: true,
                            dailySameProductMaxCount: Math.max(
                              1,
                              Number(dailySameProductMaxCount) || 2
                            ),
                            dailyOrderMaxCount: nextVal
                          });
                        }}
                        className="w-16 min-h-[32px] px-2 py-1 bg-white border-2 border-indigo-300 focus:border-indigo-600 rounded-lg font-mono text-xs font-extrabold text-slate-900 text-center outline-hidden"
                        title="সব প্রোডাক্ট মিলিয়ে দিনে মোট কয়টি অর্ডার করা যাবে"
                      />
                    </div>
                  </div>

                  {/* Reset Today's Counter Button */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-[10px] text-slate-500 leading-snug">
                      কোনো অর্ডার Cancelled করলে বা নিচের বাটনে চাপলে আজকের ব্লক সাথে সাথে খুলে যাবে।
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const nowTs = Date.now();
                        try {
                          window.localStorage.removeItem('sm_daily_device_orders_v1');
                        } catch {
                          // ignore
                        }
                        updateBusiness({
                          dailyOrderLimitResetAt: nowTs
                        });
                        showToast(
                          'আজকের সকল নাম্বার ও IP-এর অর্ডার লিমিট কাউন্টার রিসেট করা হয়েছে!',
                          'success'
                        );
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[11px] font-extrabold shrink-0 cursor-pointer transition-colors"
                    >
                      🔄 আজকের ব্লক রিসেট
                    </button>
                  </div>
                </div>

                {/* 2. Editable Error Popup Title & Message */}
                <div className="lg:col-span-7 bg-white/95 rounded-xl p-3.5 border border-indigo-200/90 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      <span>২. অর্ডার ব্লক হলে পপআপে যে মেসেজ দেখাবে (ইচ্ছেমতো এডিট করুন)</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setDailyOrderLimitTitle(DEFAULT_DAILY_ORDER_LIMIT_TITLE);
                        setDailyOrderLimitMessage(DEFAULT_DAILY_ORDER_LIMIT_MESSAGE);
                        updateBusiness({
                          dailyOrderLimitTitle: DEFAULT_DAILY_ORDER_LIMIT_TITLE,
                          dailyOrderLimitMessage: DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
                        });
                        showToast('ডিফল্ট পপআপ মেসেজ রিস্টোর করা হয়েছে!', 'info');
                      }}
                      className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 underline cursor-pointer"
                    >
                      ডিফল্ট মেসেজ সেট করুন
                    </button>
                  </div>

                  {/* Popup Title Input */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      পপআপ হেডিং / টাইটেল (Popup Title)
                    </label>
                    <input
                      type="text"
                      value={dailyOrderLimitTitle}
                      onChange={e => {
                        const val = e.target.value;
                        setDailyOrderLimitTitle(val);
                      }}
                      onBlur={() => {
                        updateBusiness({
                          dailyOrderLimitTitle:
                            dailyOrderLimitTitle.trim() || DEFAULT_DAILY_ORDER_LIMIT_TITLE
                        });
                      }}
                      placeholder={DEFAULT_DAILY_ORDER_LIMIT_TITLE}
                      className="w-full min-h-[36px] px-3 py-1.5 bg-slate-50 border border-slate-300 focus:border-indigo-600 focus:bg-white rounded-lg text-xs font-bold text-slate-900 outline-hidden"
                    />
                  </div>

                  {/* Popup Message Textarea */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      পপআপ মেসেজ (Popup Error Message)
                    </label>
                    <textarea
                      rows={2}
                      value={dailyOrderLimitMessage}
                      onChange={e => {
                        const val = e.target.value;
                        setDailyOrderLimitMessage(val);
                      }}
                      onBlur={() => {
                        updateBusiness({
                          dailyOrderLimitMessage:
                            dailyOrderLimitMessage.trim() || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
                        });
                      }}
                      placeholder={DEFAULT_DAILY_ORDER_LIMIT_MESSAGE}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-indigo-600 focus:bg-white rounded-lg text-xs font-medium text-slate-800 outline-hidden leading-relaxed"
                    />
                  </div>

                  {/* Quick Preset Messages + Save Button */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] font-bold text-slate-500">রেডি মেসেজ:</span>
                      {[
                        {
                          label: 'স্ট্যান্ডার্ড মেসেজ',
                          title: 'অর্ডার লিমিট অতিক্রম করেছে!',
                          msg: 'দুঃখিত! আপনার মোবাইল নাম্বার বা ডিভাইস থেকে আজকের সর্বোচ্চ অর্ডারের সীমা পূর্ণ হয়েছে। জরুরি প্রয়োজনে আমাদের হেল্পলাইনে কল করুন অথবা হোয়াটসঅ্যাপে মেসেজ দিন।'
                        },
                        {
                          label: 'অর্ডার প্রসেসিং মেসেজ',
                          title: 'আপনার অর্ডারটি প্রসেসিংয়ে আছে!',
                          msg: 'প্রিয় গ্রাহক, আপনার আগের অর্ডারটি ইতিমধ্যে আমাদের সিস্টেমে গৃহীত হয়েছে। নতুন আরেকটি অর্ডার করতে বা অর্ডারে পণ্য যোগ করতে হেল্পলাইনে কল করুন বা হোয়াটসঅ্যাপে যোগাযোগ করুন।'
                        },
                        {
                          label: 'নিরাপত্তা মেসেজ',
                          title: 'আজকের অর্ডার সীমা পূর্ণ হয়েছে!',
                          msg: 'ফেক অর্ডার প্রতিরোধের কারণে একই পণ্য দিনে ২ বার এবং মোট ৫টির বেশি অর্ডার করা যায় না। জরুরি প্রয়োজনে নিচে হেল্পলাইন বা হোয়াটসঅ্যাপে যোগাযোগ করুন।'
                        }
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setDailyOrderLimitTitle(preset.title);
                            setDailyOrderLimitMessage(preset.msg);
                            updateBusiness({
                              dailyOrderLimitTitle: preset.title,
                              dailyOrderLimitMessage: preset.msg
                            });
                            showToast(`"${preset.label}" সেট ও সেভ করা হয়েছে!`, 'success');
                          }}
                          className="px-2 py-1 rounded-md bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[10px] font-extrabold cursor-pointer transition-colors"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({
                          dailyOrderLimitEnabled,
                          dailySameProductMaxCount: Math.max(
                            1,
                            Number(dailySameProductMaxCount) || 2
                          ),
                          dailyOrderMaxCount: Math.max(1, Number(dailyOrderMaxCount) || 5),
                          dailyOrderLimitTitle:
                            dailyOrderLimitTitle.trim() || DEFAULT_DAILY_ORDER_LIMIT_TITLE,
                          dailyOrderLimitMessage:
                            dailyOrderLimitMessage.trim() || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE
                        });
                        showToast('দৈনিক অর্ডার লিমিট ও পপআপ মেসেজ সংরক্ষিত হয়েছে!', 'success');
                      }}
                      className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold shadow-2xs cursor-pointer transition-colors"
                    >
                      💾 মেসেজ সেভ করুন
                    </button>
                  </div>
                </div>
              </div>

              {/* Live Preview Modal inside SettingsView */}
              {showLimitPopupPreview && (
                <div
                  className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-page-rise"
                  onClick={() => setShowLimitPopupPreview(false)}
                >
                  <div
                    className="bg-white rounded-3xl max-w-md w-full p-6 border border-rose-200 shadow-2xl text-center relative overflow-hidden"
                    onClick={e => e.stopPropagation()}
                  >
                    {/* Top-Right Cross (X) Button */}
                    <button
                      type="button"
                      onClick={() => setShowLimitPopupPreview(false)}
                      className="absolute top-3.5 right-3.5 w-9 h-9 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 flex items-center justify-center transition-all cursor-pointer shadow-2xs"
                      aria-label="Close"
                      title="পপআপ বন্ধ করুন"
                    >
                      <X className="w-4.5 h-4.5 stroke-[2.5]" />
                    </button>

                    <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-3.5 shadow-2xs">
                      <Shield className="w-7 h-7" />
                    </div>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-[11px] font-extrabold mb-2">
                      একই পণ্য {dailySameProductMaxCount} বার • মোট সর্বোচ্চ {dailyOrderMaxCount}টি অর্ডার/দিন
                    </span>
                    <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
                      {dailyOrderLimitTitle.trim() || DEFAULT_DAILY_ORDER_LIMIT_TITLE}
                    </h3>
                    <p className="mt-2.5 text-xs sm:text-sm font-medium text-slate-600 leading-relaxed whitespace-pre-line">
                      {dailyOrderLimitMessage.trim() || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE}
                    </p>
                    <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
                      <a
                        href={`tel:${callOrderPhone || currentBusiness.phone || '01711234567'}`}
                        className="min-h-[44px] px-4 py-2.5 rounded-[12px] bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-sm transition-colors whitespace-nowrap"
                      >
                        <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>হেল্পলাইনে কল করুন</span>
                      </a>

                      <div className="wa-confirm-beam-wrapper">
                        <a
                          href={`https://wa.me/${(() => {
                            const rawWa = (
                              whatsappOrderPhone ||
                              callOrderPhone ||
                              currentBusiness.phone ||
                              '01711234567'
                            ).replace(/\D/g, '');
                            return rawWa.startsWith('880')
                              ? rawWa
                              : rawWa.startsWith('0')
                              ? `88${rawWa}`
                              : `880${rawWa}`;
                          })()}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="relative z-10 w-full min-h-[44px] py-2.5 px-3.5 bg-gradient-to-r from-[#1fa855] via-[#25D366] to-[#128C7E] hover:from-[#1b944a] hover:to-[#0f7a6e] text-white font-extrabold text-xs sm:text-sm rounded-[12px] flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer btn-premium-shine"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-white shrink-0 animate-bounce"
                            fill="currentColor"
                          >
                            <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824zm-3.423-14.416c-6.627 0-12 5.373-12 12 0 2.625.846 5.059 2.284 7.033l-1.494 4.462 4.614-1.469c1.906 1.249 4.184 1.974 6.596 1.974 6.627 0 12-5.373 12-12s-5.373-12-12-12z" />
                          </svg>
                          <span>হোয়াটসঅ্যাপে মেসেজ দিন</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 🎉 1-Click Order Success Celebration Control (ON/OFF + 4 Luxury Styles + Center Badge Toggle) */}
            <div className="sm:col-span-2 bg-gradient-to-r from-amber-50/90 via-white to-emerald-50/80 rounded-xl p-4 border-2 border-amber-300/80 shadow-2xs space-y-3.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <span className="text-base leading-none">🎉</span>
                    <span>
                      অর্ডার কনফার্ম হলে প্রিমিয়াম সেলিব্রেশন (Order Celebration — ৪টি লাক্সারি স্টাইল ও ON/OFF)
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    কাস্টমার ফ্রন্ট ওয়েবসাইটে অর্ডার কনফার্ম করার সাথে সাথে ৬০-FPS ক্যানভাস ফিজিক্সে <span className="font-bold text-amber-900">ডাবল পার্টি ক্যানন, রয়্যাল আতশবাজি, ২৪-ক্যারেট গোল্ড ফাউন্টেন অথবা উৎসবমুখর বেলুন</span> অ্যানিমেশন এবং মাঝখানে গোল্ডেন চেকমার্ক ব্যাজ দেখাবে।
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const isCurrentlyOn = currentBusiness.storefrontOrderConfettiEnabled !== false;
                      const nextState = !isCurrentlyOn;
                      updateBusiness({
                        storefrontOrderConfettiEnabled: nextState
                      });
                      showToast(
                        nextState
                          ? '🎉 অর্ডার কনফার্ম সেলিব্রেশন অ্যানিমেশন চালু (ON) করা হয়েছে!'
                          : 'অর্ডার কনফার্ম সেলিব্রেশন অ্যানিমেশন বন্ধ (OFF) করা হয়েছে।',
                        nextState ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer border shadow-2xs ${
                      currentBusiness.storefrontOrderConfettiEnabled !== false
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white border-emerald-800'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                    }`}
                  >
                    <span>🎉</span>
                    <span>
                      {currentBusiness.storefrontOrderConfettiEnabled !== false
                        ? 'সেলিব্রেশন: চালু (ON)'
                        : 'সেলিব্রেশন: বন্ধ (OFF)'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const nextBadge =
                        currentBusiness.storefrontOrderCelebrationBadgeEnabled === false;
                      updateBusiness({
                        storefrontOrderCelebrationBadgeEnabled: nextBadge
                      });
                      showToast(
                        nextBadge
                          ? '🏅 মাঝখানের গোল্ডেন চেকমার্ক পপ-আপ ব্যাজ চালু (ON) করা হয়েছে!'
                          : 'মাঝখানের পপ-আপ ব্যাজ বন্ধ (OFF) করা হয়েছে।',
                        'info'
                      );
                    }}
                    className={`min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      currentBusiness.storefrontOrderCelebrationBadgeEnabled !== false
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-2xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <span>🏅 সেন্টার গোল্ডেন ব্যাজ: {currentBusiness.storefrontOrderCelebrationBadgeEnabled !== false ? 'ON' : 'OFF'}</span>
                  </button>
                </div>
              </div>

              {/* 6 Luxury Celebration Style Buttons */}
              <div className="pt-2 border-t border-amber-200/70 flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-extrabold text-slate-700">
                  🎨 সেলিব্রেশন ডিজাইন স্টাইল:
                </span>
                {(
                  [
                    {
                      id: 'dual_cannon_badge',
                      label: '🎊 ১. ডাবল পার্টি ক্যানন (দুই পাশ থেকে)'
                    },
                    {
                      id: 'royal_fireworks',
                      label: '🎆 ২. রয়্যাল আতশবাজি ও স্টারবার্স্ট'
                    },
                    {
                      id: 'luxury_gold_fountain',
                      label: '✨ ৩. ২৪-ক্যারেট গোল্ড ও এমেরাল্ড ফাউন্টেন'
                    },
                    {
                      id: 'festive_balloons',
                      label: '🎈 ৪. উৎসবমুখর বেলুন ও লাভ হার্টস'
                    },
                    {
                      id: 'ramadan_noor_lanterns',
                      label: '🌙 ৫. রমজান নূর, ফানুস ও চাঁদ-তারা (Ramadan Special)'
                    },
                    {
                      id: 'eid_mubarak_royal',
                      label: '🕌 ৬. ঈদ মোবারক রয়্যাল আতশবাজি ও উৎসব (Eid Special)'
                    }
                  ] as const
                ).map((st) => {
                  const activeStyle =
                    currentBusiness.storefrontOrderConfettiStyle || 'dual_cannon_badge';
                  const isSel = activeStyle === st.id;
                  return (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => {
                        updateBusiness({
                          storefrontOrderConfettiEnabled: true,
                          storefrontOrderConfettiStyle: st.id
                        });
                        showToast(`"${st.label}" ডিজাইন সেট করা হয়েছে!`, 'success');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer ${
                        isSel
                          ? 'bg-slate-900 text-amber-300 border-slate-900 shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-amber-50'
                      }`}
                    >
                      {st.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Inside Dhaka (ঢাকার ভিতরে) Delivery Charge */}
            <div className="bg-emerald-50/60 rounded-xl p-4 border border-emerald-200/80 space-y-2">
              <label className="text-xs font-extrabold text-emerald-950 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-700" />
                <span>
                  {language === 'bn'
                    ? 'ঢাকার ভিতরে ডেলিভারি চার্জ (Inside Dhaka) *'
                    : 'Inside Dhaka Delivery Charge (BDT) *'}
                </span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-bold text-sm text-emerald-800">
                  ৳
                </span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={deliveryCharge}
                  onChange={(e) => setDeliveryCharge(e.target.value)}
                  className="w-full min-h-[42px] pl-8 pr-3 py-2 bg-white border-2 border-emerald-500/70 focus:border-emerald-600 rounded-xl font-mono font-extrabold text-base text-slate-900 outline-hidden"
                />
              </div>
              <p className="text-[11px] text-emerald-800">
                {language === 'bn'
                  ? 'কাস্টমার চেকআউট পেজে "ঢাকার ভিতরে" সিলেক্ট করলে এই চার্জ যোগ হবে (ডিফল্ট: ৳৬০)।'
                  : 'Delivery charge applied when customer selects Inside Dhaka (default: 60 BDT).'}
              </p>
            </div>

            {/* Outside Dhaka (ঢাকার বাইরে) Delivery Charge */}
            <div className="bg-amber-50/60 rounded-xl p-4 border border-amber-200/80 space-y-2">
              <label className="text-xs font-extrabold text-amber-950 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-amber-700" />
                <span>
                  {language === 'bn'
                    ? 'ঢাকার বাইরে ডেলিভারি চার্জ (Outside Dhaka) *'
                    : 'Outside Dhaka Delivery Charge (BDT) *'}
                </span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-bold text-sm text-amber-800">
                  ৳
                </span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={outsideDhakaCharge}
                  onChange={(e) => setOutsideDhakaCharge(e.target.value)}
                  className="w-full min-h-[42px] pl-8 pr-3 py-2 bg-white border-2 border-amber-400 focus:border-amber-600 rounded-xl font-mono font-extrabold text-base text-slate-900 outline-hidden"
                />
              </div>
              <p className="text-[11px] text-amber-900">
                {language === 'bn'
                  ? 'কাস্টমার চেকআউট পেজে "ঢাকার বাইরে" সিলেক্ট করলে এই চার্জ যোগ হবে (ডিফল্ট: ৳১২০)।'
                  : 'Delivery charge applied when customer selects Outside Dhaka (default: 120 BDT).'}
              </p>
            </div>

            {/* Enable Free Delivery (ফ্রি ডেলিভারি) Toggle / Checkbox */}
            <div className="sm:col-span-2 bg-teal-50/70 rounded-xl p-4 border border-teal-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <label className="flex items-start sm:items-center gap-3 cursor-pointer flex-1">
                <input
                  type="checkbox"
                  checked={freeDeliveryEnabled}
                  onChange={(e) => {
                    const nextVal = e.target.checked;
                    setFreeDeliveryEnabled(nextVal);
                    updateBusiness({
                      freeDeliveryEnabled: nextVal,
                      insideDhakaDeliveryCharge: Math.max(0, Number(deliveryCharge) || 0),
                      outsideDhakaDeliveryCharge: Math.max(0, Number(outsideDhakaCharge) || 0),
                      ecommerceDeliveryCharge: Math.max(0, Number(deliveryCharge) || 0)
                    });
                    showToast(
                      nextVal
                        ? 'সকল অর্ডারে "ফ্রি ডেলিভারি (Free Delivery)" চালু করা হয়েছে!'
                        : '"ফ্রি ডেলিভারি" বন্ধ করা হয়েছে — এখন ঢাকার ভিতরে/বাইরে চার্জ প্রযোজ্য হবে।',
                      nextVal ? 'success' : 'info'
                    );
                  }}
                  className="w-5 h-5 mt-0.5 sm:mt-0 accent-emerald-700 rounded cursor-pointer shrink-0"
                />
                <div className="space-y-0.5">
                  <span className="text-xs sm:text-sm font-extrabold text-slate-900 block">
                    {language === 'bn'
                      ? 'ফ্রি ডেলিভারি চালু করুন (Enable Free Delivery)'
                      : 'Enable Free Delivery'}
                  </span>
                  <span className="text-[11px] text-slate-600 block">
                    {language === 'bn'
                      ? 'এটি চালু থাকলে চেকআউট পেজে "ঢাকার ভিতরে / ঢাকার বাইরে" অপশনটি স্বয়ংক্রিয়ভাবে লুকিয়ে যাবে এবং ডেলিভারি চার্জ ৳০ (ফ্রি ডেলিভারি) হিসেবে হিসাব হবে।'
                      : 'When enabled, hides Inside/Outside Dhaka options on Checkout and sets delivery charge to 0 (Free Delivery).'}
                  </span>
                </div>
              </label>

              <button
                type="button"
                onClick={() => {
                  const nextVal = !freeDeliveryEnabled;
                  setFreeDeliveryEnabled(nextVal);
                  updateBusiness({
                    freeDeliveryEnabled: nextVal,
                    insideDhakaDeliveryCharge: Math.max(0, Number(deliveryCharge) || 0),
                    outsideDhakaDeliveryCharge: Math.max(0, Number(outsideDhakaCharge) || 0),
                    ecommerceDeliveryCharge: Math.max(0, Number(deliveryCharge) || 0)
                  });
                  showToast(
                    nextVal
                      ? 'সকল অর্ডারে "ফ্রি ডেলিভারি (Free Delivery)" চালু করা হয়েছে!'
                      : '"ফ্রি ডেলিভারি" বন্ধ করা হয়েছে — এখন ঢাকার ভিতরে/বাইরে চার্জ প্রযোজ্য হবে।',
                    nextVal ? 'success' : 'info'
                  );
                }}
                className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  freeDeliveryEnabled
                    ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {freeDeliveryEnabled
                    ? 'ফ্রি ডেলিভারি চালু (ON)'
                    : 'ফ্রি ডেলিভারি বন্ধ (OFF)'}
                </span>
              </button>
            </div>

            {/* Smart Quantity-Based Free Delivery ("২ পিস বা ৩ পিস কিনলে ডেলিভারি ফ্রি") for Website & Landing Page */}
            <div className="sm:col-span-2 bg-gradient-to-r from-amber-50/90 via-emerald-50/70 to-amber-50/90 rounded-xl p-4 border border-amber-300/90 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>২ পিস বা ৩ পিস কিনলে ডেলিভারি ফ্রি (Quantity-Based Free Delivery — মেইন ওয়েবসাইট ও ল্যান্ডিং পেজ)</span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    কাস্টমার মেইন ওয়েবসাইট অথবা ল্যান্ডিং পেজে কমপক্ষে নির্ধারিত সংখ্যক পিস (যেমন ২ পিস বা ৩ পিস) সিলেক্ট করলেই অটোমেটিক ডেলিভারি চার্জ ফ্রি (৳০) হয়ে যাবে।
                  </p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-[11px] font-extrabold shrink-0 self-start sm:self-center ${
                    currentBusiness.freeDeliveryByQtyEnabled
                      ? 'bg-emerald-700 text-white'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {currentBusiness.freeDeliveryByQtyEnabled
                    ? `চালু: কমপক্ষে ${currentBusiness.freeDeliveryMinQty || 2} পিসে ডেলিভারি ফ্রি`
                    : 'বর্তমানে বন্ধ (OFF)'}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({
                      freeDeliveryByQtyEnabled: false,
                      landingFreeDeliveryByQtyEnabled: false
                    });
                    showToast('পিস হিসেবে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে।', 'info');
                  }}
                  className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                    !currentBusiness.freeDeliveryByQtyEnabled
                      ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  OFF (বন্ধ রাখুন)
                </button>
                {[2, 3, 4, 5].map(minQty => {
                  const isSelected =
                    Boolean(currentBusiness.freeDeliveryByQtyEnabled) &&
                    Number(currentBusiness.freeDeliveryMinQty || 2) === minQty;
                  return (
                    <button
                      key={minQty}
                      type="button"
                      onClick={() => {
                        updateBusiness({
                          freeDeliveryByQtyEnabled: true,
                          freeDeliveryMinQty: minQty,
                          landingFreeDeliveryByQtyEnabled: true,
                          landingFreeDeliveryMinQty: minQty
                        });
                        showToast(
                          `ওয়েবসাইট ও ল্যান্ডিং পেজে "${minQty} পিস কিনলে ডেলিভারি ফ্রি" চালু করা হয়েছে!`,
                          'success'
                        );
                      }}
                      className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                          : 'bg-white text-emerald-900 border-emerald-300 hover:bg-emerald-50'
                      }`}
                    >
                      🚚 {minQty} পিস কিনলে ডেলিভারি ফ্রি
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 1. Minimum Order Amount Free Delivery + Animated Live Progress Bar */}
            <div className="sm:col-span-2 bg-gradient-to-r from-teal-50/90 via-emerald-50/75 to-cyan-50/60 rounded-xl p-4 border border-teal-200/90 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <p className="text-xs sm:text-sm font-extrabold text-teal-950 flex items-center gap-1.5">
                    <span>📊 ১. নির্দিষ্ট টাকার অর্ডারে ফ্রি ডেলিভারি + লাইভ প্রোগ্রেস বার (Minimum Order Amount Free Delivery)</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                        currentBusiness.freeDeliveryByMinAmountEnabled
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {currentBusiness.freeDeliveryByMinAmountEnabled
                        ? `ON (৳${currentBusiness.freeDeliveryMinOrder || 1500}+ অর্ডারে ফ্রি)`
                        : 'OFF'}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    কাস্টমার কার্টে বা চেকআউটে একটি অ্যানিমেটেড প্রোগ্রেস বার দেখবে—&ldquo;আর মাত্র ৳৩৫০ টাকার পণ্য যোগ করলেই আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!&rdquo; (ওয়েবসাইট ও ল্যান্ডিং পেজ উভয় জায়গায় কাজ করবে)।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextOn = !Boolean(currentBusiness.freeDeliveryByMinAmountEnabled);
                    const targetAmt = Math.max(100, Number(currentBusiness.freeDeliveryMinOrder || 1500));
                    setFreeDeliveryMin(String(targetAmt));
                    updateBusiness({
                      freeDeliveryByMinAmountEnabled: nextOn,
                      freeDeliveryMinOrder: targetAmt
                    });
                    showToast(
                      nextOn
                        ? `নির্দিষ্ট টাকার অর্ডারে (৳${targetAmt}+) ফ্রি ডেলিভারি ও লাইভ প্রোগ্রেস বার চালু (ON) করা হয়েছে!`
                        : 'নির্দিষ্ট টাকার অর্ডারে ফ্রি ডেলিভারি প্রোগ্রেস বার বন্ধ (OFF) করা হয়েছে।',
                      nextOn ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                    currentBusiness.freeDeliveryByMinAmountEnabled
                      ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {currentBusiness.freeDeliveryByMinAmountEnabled ? '✓ চালু আছে (ON)' : 'চালু করুন (ON)'}
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({ freeDeliveryByMinAmountEnabled: false });
                    showToast('নির্দিষ্ট টাকার অর্ডারে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে।', 'info');
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                    !currentBusiness.freeDeliveryByMinAmountEnabled
                      ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  OFF (বন্ধ)
                </button>
                {[1000, 1200, 1500, 2000, 2500, 3000].map(presetAmt => {
                  const currentAmt = Number(currentBusiness.freeDeliveryMinOrder || 1500);
                  const isSel =
                    Boolean(currentBusiness.freeDeliveryByMinAmountEnabled) &&
                    currentAmt === presetAmt;
                  return (
                    <button
                      key={presetAmt}
                      type="button"
                      onClick={() => {
                        setFreeDeliveryMin(String(presetAmt));
                        updateBusiness({
                          freeDeliveryByMinAmountEnabled: true,
                          freeDeliveryMinOrder: presetAmt
                        });
                        showToast(
                          `৳${presetAmt.toLocaleString('en-IN')}+ টাকার কেনাকাটায় ফ্রি ডেলিভারি ও লাইভ প্রোগ্রেস বার চালু করা হয়েছে!`,
                          'success'
                        );
                      }}
                      className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                        isSel
                          ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                          : 'bg-white text-teal-900 border-teal-300 hover:bg-teal-50'
                      }`}
                    >
                      🚚 ৳{presetAmt.toLocaleString('en-IN')}+ অর্ডারে ফ্রি
                    </button>
                  );
                })}

                <div className="flex items-center gap-1.5 ml-auto">
                  <span className="text-[11px] font-bold text-slate-700">কাস্টম টার্গেট (৳):</span>
                  <input
                    type="number"
                    min="100"
                    value={freeDeliveryMin}
                    onChange={e => {
                      const val = e.target.value;
                      setFreeDeliveryMin(val);
                      const num = parseInt(val, 10);
                      if (!Number.isNaN(num) && num >= 100) {
                        updateBusiness({
                          freeDeliveryByMinAmountEnabled: true,
                          freeDeliveryMinOrder: num
                        });
                      }
                    }}
                    placeholder="1500"
                    className="w-24 min-h-[36px] px-2.5 py-1 bg-white border border-teal-300 rounded-xl font-mono font-extrabold text-xs text-teal-950"
                  />
                </div>
              </div>
            </div>

            {/* 4. Half Delivery Charge Offer (৫০% ডেলিভারি ডিসকাউন্ট ক্যাম্পেইন) */}
            <div className="sm:col-span-2 bg-gradient-to-r from-rose-50/90 via-orange-50/70 to-amber-50/60 rounded-xl p-4 border border-rose-200/90 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <p className="text-xs sm:text-sm font-extrabold text-rose-950 flex items-center gap-1.5">
                    <span>🔥 ৪. হাফ ডেলিভারি চার্জ অফার (৫০% ডেলিভারি ডিসকাউন্ট ক্যাম্পেইন)</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                        currentBusiness.halfDeliveryOfferEnabled
                          ? 'bg-[#c30000] text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {currentBusiness.halfDeliveryOfferEnabled
                        ? `ON (${currentBusiness.deliveryDiscountPercent || 50}% ছাড়)`
                        : 'OFF'}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    ১-ক্লিকে চালু করলে রেগুলার ডেলিভারি চার্জ কাটা দাগ (<s>৳{Number(deliveryCharge) || 60}</s> / <s>৳{Number(outsideDhakaCharge) || 120}</s>) হয়ে অর্ধেক চার্জ লাল/সবুজ রঙে হাইলাইট হয়ে দেখাবে।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextOn = !Boolean(currentBusiness.halfDeliveryOfferEnabled);
                    const pct = Number(currentBusiness.deliveryDiscountPercent || 50);
                    updateBusiness({
                      halfDeliveryOfferEnabled: nextOn,
                      deliveryDiscountPercent: pct
                    });
                    showToast(
                      nextOn
                        ? `🔥 হাফ ডেলিভারি চার্জ অফার (${pct}% ডেলিভারি ছাড়) চালু (ON) করা হয়েছে!`
                        : 'হাফ ডেলিভারি চার্জ অফার বন্ধ (OFF) করা হয়েছে।',
                      nextOn ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                    currentBusiness.halfDeliveryOfferEnabled
                      ? 'bg-[#c30000] text-white border-[#c30000] shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {currentBusiness.halfDeliveryOfferEnabled
                    ? '✓ হাফ ডেলিভারি অফার: ON'
                    : '১-ক্লিকে চালু করুন (ON)'}
                </button>
              </div>

              {(() => {
                const regInside = Math.max(0, Number(deliveryCharge) || 60);
                const regOutside = Math.max(0, Number(outsideDhakaCharge) || 120);
                const discPct = Math.min(90, Math.max(10, Number(currentBusiness.deliveryDiscountPercent || 50)));
                const halfInside = Math.round(regInside * (1 - discPct / 100));
                const halfOutside = Math.round(regOutside * (1 - discPct / 100));
                return (
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="px-3 py-1.5 rounded-xl bg-white border border-rose-200 font-bold text-slate-700">
                        ঢাকার ভিতরে:{' '}
                        <span className="line-through text-slate-400 font-mono mr-1">৳{regInside}</span>
                        <strong className="text-[#c30000] font-mono text-sm">৳{halfInside}</strong>
                      </span>
                      <span className="px-3 py-1.5 rounded-xl bg-white border border-rose-200 font-bold text-slate-700">
                        ঢাকার বাইরে:{' '}
                        <span className="line-through text-slate-400 font-mono mr-1">৳{regOutside}</span>
                        <strong className="text-[#c30000] font-mono text-sm">৳{halfOutside}</strong>
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5">
                      {[30, 50, 70].map(pctOpt => {
                        const isSel =
                          Boolean(currentBusiness.halfDeliveryOfferEnabled) && discPct === pctOpt;
                        return (
                          <button
                            key={pctOpt}
                            type="button"
                            onClick={() => {
                              updateBusiness({
                                halfDeliveryOfferEnabled: true,
                                deliveryDiscountPercent: pctOpt
                              });
                              showToast(
                                `ডেলিভারি চার্জে ${pctOpt}% ডিসকাউন্ট অফার চালু করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer transition-all ${
                              isSel
                                ? 'bg-[#c30000] text-white border-[#c30000]'
                                : 'bg-white text-rose-900 border-rose-300 hover:bg-rose-50'
                            }`}
                          >
                            {pctOpt === 50 ? '৫০% ছাড় (হাফ চার্জ)' : `${pctOpt}% ছাড়`}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* 6. Product-Specific Free Delivery Badge & Rule (প্রোডাক্ট ভেদে আলাদা ফ্রি ডেলিভারি) */}
            <div className="sm:col-span-2 bg-gradient-to-r from-indigo-50/80 via-sky-50/70 to-emerald-50/60 rounded-xl p-4 border border-indigo-200/90 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <p className="text-xs sm:text-sm font-extrabold text-indigo-950 flex items-center gap-1.5">
                    <span>🏷️ ৬. প্রোডাক্ট ভেদে আলাদা ফ্রি ডেলিভারি (Product-Specific Free Delivery)</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                        currentBusiness.productSpecificFreeDeliveryEnabled !== false
                          ? 'bg-indigo-700 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {currentBusiness.productSpecificFreeDeliveryEnabled !== false
                        ? `ON (${products.filter(p => p.freeDelivery || p.freeDeliveryOnLanding).length} টি প্রোডাক্টে চালু)`
                        : 'OFF'}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    যেকোনো প্রোডাক্টে &ldquo;🚚 ফ্রি ডেলিভারি&rdquo; চালু করলে ওই প্রোডাক্টের কার্ডে ব্যাজ দেখাবে এবং কাস্টমার সেটি একা বা অন্য পণ্যের সাথে কার্টে যোগ করলেই পুরো অর্ডারের ডেলিভারি চার্জ ফ্রি (৳০) হয়ে যাবে!
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextOn = currentBusiness.productSpecificFreeDeliveryEnabled === false;
                    updateBusiness({ productSpecificFreeDeliveryEnabled: nextOn });
                    showToast(
                      nextOn
                        ? 'প্রোডাক্ট ভেদে আলাদা ফ্রি ডেলিভারি সিস্টেম চালু (ON) করা হয়েছে!'
                        : 'প্রোডাক্ট ভেদে আলাদা ফ্রি ডেলিভারি সিস্টেম সাময়িকভাবে বন্ধ (OFF) করা হয়েছে।',
                      nextOn ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                    currentBusiness.productSpecificFreeDeliveryEnabled !== false
                      ? 'bg-indigo-700 text-white border-indigo-700'
                      : 'bg-white text-slate-700 border-slate-300'
                  }`}
                >
                  {currentBusiness.productSpecificFreeDeliveryEnabled !== false
                    ? '✓ সিস্টেম: ON'
                    : 'সিস্টেম: OFF'}
                </button>
              </div>

              {currentBusiness.productSpecificFreeDeliveryEnabled !== false && products.length > 0 && (
                <div className="space-y-1.5 pt-1">
                  <p className="text-[11px] font-bold text-indigo-900">
                    ১-ক্লিকে যেকোনো প্রোডাক্টে &ldquo;🚚 ফ্রি ডেলিভারি&rdquo; চালু / বন্ধ করুন:
                  </p>
                  <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-2 rounded-xl bg-white/90 border border-indigo-100">
                    {products.map(prod => {
                      const isProdFree = Boolean(prod.freeDelivery || prod.freeDeliveryOnLanding);
                      return (
                        <button
                          key={prod.id}
                          type="button"
                          onClick={async () => {
                            const nextVal = !isProdFree;
                            await updateProduct(prod.id, {
                              freeDelivery: nextVal,
                              freeDeliveryOnLanding: nextVal
                            });
                            showToast(
                              nextVal
                                ? `🚚 "${prod.nameBn}" প্রোডাক্টে ফ্রি ডেলিভারি ব্যাজ ও অফার চালু করা হয়েছে!`
                                : `"${prod.nameBn}" প্রোডাক্ট থেকে ফ্রি ডেলিভারি অফার সরানো হয়েছে।`,
                              nextVal ? 'success' : 'info'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer inline-flex items-center gap-1 ${
                            isProdFree
                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-indigo-400'
                          }`}
                        >
                          <span>{isProdFree ? '🚚 ✓' : '+'}</span>
                          <span className="truncate max-w-[180px]">{prod.nameBn}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* 7. Happy Hour / Flash Free Delivery Timer Window (হ্যাপি আওয়ার / ফ্ল্যাশ ফ্রি ডেলিভারি টাইমার) */}
            <div className="sm:col-span-2 bg-gradient-to-r from-amber-50/90 via-yellow-50/70 to-orange-50/70 rounded-xl p-4 border border-amber-300/90 space-y-3">
              {(() => {
                const isFlashTimerActive =
                  Boolean(currentBusiness.flashFreeDeliveryEnabled) &&
                  Number(currentBusiness.flashFreeDeliveryEndTime || 0) > Date.now();
                const isScheduleActive = Boolean(currentBusiness.flashFreeDeliveryScheduleEnabled);
                const remainingMin = isFlashTimerActive
                  ? Math.max(
                      1,
                      Math.ceil(
                        (Number(currentBusiness.flashFreeDeliveryEndTime || 0) - Date.now()) / 60000
                      )
                    )
                  : 0;
                return (
                  <>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="space-y-0.5">
                        <p className="text-xs sm:text-sm font-extrabold text-amber-950 flex items-center gap-1.5">
                          <span>⚡ ৭. হ্যাপি আওয়ার / ফ্ল্যাশ ফ্রি ডেলিভারি টাইমার (Flash Free Delivery Window)</span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                              isFlashTimerActive || isScheduleActive
                                ? 'bg-amber-600 text-white'
                                : 'bg-slate-200 text-slate-600'
                            }`}
                          >
                            {isFlashTimerActive
                              ? `LIVE (${remainingMin} মিনিট বাকি)`
                              : isScheduleActive
                              ? `Daily (${currentBusiness.flashFreeDeliveryStartHour || '21:00'} - ${currentBusiness.flashFreeDeliveryEndHour || '23:59'})`
                              : 'OFF'}
                          </span>
                        </p>
                        <p className="text-[11px] text-slate-600">
                          নির্দিষ্ট সময়ের জন্য ফ্ল্যাশ ফ্রি ডেলিভারি চালু করুন। কাস্টমার কাউন্টডাউন ব্যানার দেখবে এবং সময় শেষ হলে অফারটি অটোমেটিক বন্ধ হয়ে যাবে!
                        </p>
                      </div>

                      {(isFlashTimerActive || isScheduleActive) && (
                        <button
                          type="button"
                          onClick={() => {
                            updateBusiness({
                              flashFreeDeliveryEnabled: false,
                              flashFreeDeliveryEndTime: 0,
                              flashFreeDeliveryScheduleEnabled: false
                            });
                            showToast('ফ্ল্যাশ ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে।', 'info');
                          }}
                          className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold cursor-pointer shrink-0"
                        >
                          ✕ অফার বন্ধ করুন (OFF)
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] font-extrabold text-amber-950">
                        ⚡ তাৎক্ষণিক ফ্ল্যাশ টাইমার চালু করুন:
                      </span>
                      {[
                        { mins: 60, label: '১ ঘণ্টা' },
                        { mins: 120, label: '২ ঘণ্টা' },
                        { mins: 180, label: '৩ ঘণ্টা' },
                        { mins: 360, label: '৬ ঘণ্টা' },
                        { mins: 720, label: '১২ ঘণ্টা' }
                      ].map(opt => {
                        const isSel =
                          isFlashTimerActive &&
                          Number(currentBusiness.flashFreeDeliveryDurationMinutes || 120) === opt.mins;
                        return (
                          <button
                            key={opt.mins}
                            type="button"
                            onClick={() => {
                              const endTime = Date.now() + opt.mins * 60 * 1000;
                              updateBusiness({
                                flashFreeDeliveryEnabled: true,
                                flashFreeDeliveryDurationMinutes: opt.mins,
                                flashFreeDeliveryEndTime: endTime
                              });
                              showToast(
                                `⚡ আগামী ${opt.label}র জন্য ফ্ল্যাশ ফ্রি ডেলিভারি কাউন্টডাউন চালু করা হয়েছে! সময় শেষ হলে অটো বন্ধ হবে।`,
                                'success'
                              );
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                              isSel
                                ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                                : 'bg-white text-amber-950 border-amber-300 hover:bg-amber-100'
                            }`}
                          >
                            ⚡ আগামী {opt.label} ফ্রি ডেলিভারি
                          </button>
                        );
                      })}
                    </div>

                    <div className="pt-2 border-t border-amber-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-extrabold text-slate-800">
                          🌙 প্রতিদিন হ্যাপি আওয়ার (যেমন রাত ৯টা - ১২টা):
                        </span>
                        <input
                          type="time"
                          value={currentBusiness.flashFreeDeliveryStartHour || '21:00'}
                          onChange={e =>
                            updateBusiness({
                              flashFreeDeliveryStartHour: e.target.value || '21:00'
                            })
                          }
                          className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 font-mono font-bold text-slate-900"
                        />
                        <span className="font-bold text-slate-600">থেকে</span>
                        <input
                          type="time"
                          value={currentBusiness.flashFreeDeliveryEndHour || '23:59'}
                          onChange={e =>
                            updateBusiness({
                              flashFreeDeliveryEndHour: e.target.value || '23:59'
                            })
                          }
                          className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 font-mono font-bold text-slate-900"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          const nextSched = !Boolean(currentBusiness.flashFreeDeliveryScheduleEnabled);
                          updateBusiness({
                            flashFreeDeliveryScheduleEnabled: nextSched,
                            flashFreeDeliveryStartHour:
                              currentBusiness.flashFreeDeliveryStartHour || '21:00',
                            flashFreeDeliveryEndHour:
                              currentBusiness.flashFreeDeliveryEndHour || '23:59'
                          });
                          showToast(
                            nextSched
                              ? `🌙 ডেইলি হ্যাপি আওয়ার (${
                                  currentBusiness.flashFreeDeliveryStartHour || '21:00'
                                } - ${
                                  currentBusiness.flashFreeDeliveryEndHour || '23:59'
                                }) ফ্রি ডেলিভারি চালু হয়েছে!`
                              : 'ডেইলি হ্যাপি আওয়ার শিডিউল বন্ধ করা হয়েছে।',
                            nextSched ? 'success' : 'info'
                          );
                        }}
                        className={`px-3 py-1.5 rounded-xl font-extrabold border cursor-pointer ${
                          isScheduleActive
                            ? 'bg-emerald-700 text-white border-emerald-700'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {isScheduleActive ? '✓ ডেইলি হ্যাপি আওয়ার: ON' : 'ডেইলি হ্যাপি আওয়ার চালু করুন'}
                      </button>
                    </div>
                  </>
                );
              })()}
            </div>

            {/* Preloader / Splash Screen OFF + Independent Shimmer Skeleton Grid Control */}
            <div className="sm:col-span-2 bg-slate-50 rounded-xl p-4 border border-slate-200/90 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                    ⚡ প্রিলোডার (Splash Screen) ও Shimmer Skeleton Grid কন্ট্রোল (আলাদা ON / OFF)
                  </p>
                  <p className="text-[11px] text-slate-600">
                    প্রিলোডার OFF করলে কাস্টমার লোগো স্প্ল্যাশ ছাড়াই সরাসরি ওয়েবসাইটে ঢুকবে এবং প্রোডাক্ট লোড হওয়ার সময় Shimmer Skeleton Grid দেখাবে (চাইলে সেটিও ON/OFF করতে পারবেন)।
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const nextPreloader = currentBusiness.preloaderEnabled === false;
                      updateBusiness({ preloaderEnabled: nextPreloader });
                      showToast(
                        nextPreloader
                          ? 'প্রিলোডার / স্প্ল্যাশ স্ক্রিন চালু (ON) করা হয়েছে!'
                          : 'প্রিলোডার বন্ধ (OFF) করা হয়েছে — এখন সরাসরি ওয়েবসাইট ভিজিট হবে!',
                        'success'
                      );
                    }}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                      currentBusiness.preloaderEnabled !== false
                        ? 'bg-teal-700 text-white border-teal-700'
                        : 'bg-rose-600 text-white border-rose-600'
                    }`}
                  >
                    {currentBusiness.preloaderEnabled !== false
                      ? 'প্রিলোডার স্ক্রিন: ON'
                      : 'প্রিলোডার স্ক্রিন: OFF (সরাসরি ভিজিট)'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const nextShimmer = currentBusiness.preloaderShimmerEnabled === false;
                      updateBusiness({ preloaderShimmerEnabled: nextShimmer });
                      showToast(
                        nextShimmer
                          ? 'Shimmer Skeleton Grid চালু (ON) করা হয়েছে!'
                          : 'Shimmer Skeleton Grid বন্ধ (OFF) করা হয়েছে!',
                        'success'
                      );
                    }}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                      currentBusiness.preloaderShimmerEnabled !== false
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-slate-200 text-slate-700 border-slate-300'
                    }`}
                  >
                    {currentBusiness.preloaderShimmerEnabled !== false
                      ? '✨ Shimmer Skeleton Grid: ON ✓'
                      : 'Shimmer Skeleton Grid: OFF'}
                  </button>
                </div>
              </div>
            </div>

            {/* Mobile Checkout Delivery Area UX Controls (উপায় ১ ও উপায় ২) */}
            <div className="sm:col-span-2 bg-gradient-to-r from-indigo-50/90 via-white to-emerald-50/80 rounded-xl p-4 border border-indigo-200/90 space-y-3.5">
              <div className="space-y-0.5">
                <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                  📱 মোবাইল চেকআউট ও ডেলিভারি এরিয়া স্মার্ট কন্ট্রোল (উপায় ১ ও উপায় ২)
                </p>
                <p className="text-[11px] text-slate-600">
                  মোবাইলে কাস্টমার যাতে শুরুতেই তার নিজের এলাকার (ঢাকার ভিতরে/বাইরে) সঠিক ডেলিভারি চার্জ ও মোট বিল সহজে বুঝতে পারে তার জন্য নিচের দুটি সিস্টেম ON/OFF ও ডিজাইন কাস্টমাইজ করুন:
                </p>
              </div>

              {/* উপায় ১: অর্ডার বক্স ও কার্টে ১-ট্যাপ বাটন + ৪টি বাটন ডিজাইন */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-extrabold text-emerald-950">
                      ✅ উপায় ১: অর্ডার বক্স ও কার্টে ১-ট্যাপ এরিয়া বাটন [✓ ঢাকার ভিতরে] [ঢাকার বাইরে]
                    </p>
                    <p className="text-[11px] text-slate-500">
                      কাস্টমার পেজে ঢুকেই সবার উপরে ১ ট্যাপে তার আসল ডেলিভারি চার্জ ও মোট বিল এক পলকে দেখে ফেলতে পারবে।
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const nextOn = currentBusiness.checkoutSummaryZoneToggleEnabled === false;
                        updateBusiness({ checkoutSummaryZoneToggleEnabled: nextOn });
                        showToast(
                          nextOn
                            ? 'উপায় ১: অর্ডার বক্সে ১-ট্যাপ ডেলিভারি এরিয়া বাটন চালু (ON) করা হয়েছে!'
                            : 'উপায় ১: অর্ডার বক্সে ১-ট্যাপ ডেলিভারি এরিয়া বাটন বন্ধ (OFF) করা হয়েছে!',
                          nextOn ? 'success' : 'info'
                        );
                      }}
                      className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                        currentBusiness.checkoutSummaryZoneToggleEnabled !== false
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'bg-slate-200 text-slate-700 border-slate-300'
                      }`}
                    >
                      {currentBusiness.checkoutSummaryZoneToggleEnabled !== false
                        ? 'উপায় ১: চালু আছে (ON) ✓'
                        : 'উপায় ১: বন্ধ আছে (OFF)'}
                    </button>

                    {currentBusiness.checkoutSummaryZoneToggleEnabled !== false && (
                      <button
                        type="button"
                        onClick={() => {
                          const isHiddenDesktop =
                            currentBusiness.checkoutSummaryZoneHideOnDesktop !== false;
                          const nextHideDesktop = !isHiddenDesktop;
                          updateBusiness({ checkoutSummaryZoneHideOnDesktop: nextHideDesktop });
                          showToast(
                            nextHideDesktop
                              ? '🖥️ ডেক্সটপে হাইড চালু (ON): ঢাকার ভিতরে/বাইরে বাটনটি এখন শুধু মোবাইলে দেখাবে, ডেক্সটপে হাইড থাকবে!'
                              : '💻 ডেক্সটপে হাইড বন্ধ (OFF): ঢাকার ভিতরে/বাইরে বাটনটি এখন মোবাইল ও ডেক্সটপ উভয় ভিউতে দেখাবে!',
                            nextHideDesktop ? 'success' : 'info'
                          );
                        }}
                        className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                          currentBusiness.checkoutSummaryZoneHideOnDesktop !== false
                            ? 'bg-sky-700 text-white border-sky-700 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {currentBusiness.checkoutSummaryZoneHideOnDesktop !== false
                          ? '🖥️ ডেক্সটপে হাইড: ON (শুধু মোবাইলে দেখাবে) ✓'
                          : '💻 ডেক্সটপে হাইড: OFF (ডেক্সটপ + মোবাইলে দেখাবে)'}
                      </button>
                    )}
                  </div>
                </div>

                {currentBusiness.checkoutSummaryZoneToggleEnabled !== false && (
                  <div className="pt-2 border-t border-slate-100 space-y-1.5">
                    <p className="text-[11px] font-extrabold text-slate-700">
                      🎨 ১-ট্যাপ বাটনের ডিজাইন স্টাইল নির্বাচন করুন (৪টি ডিজাইন):
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                      {(
                        [
                          { id: 'emerald_pill', label: '১. প্রিমিয়াম গ্রিন বাটন (ডিফল্ট)' },
                          { id: 'segmented_tab', label: '২. মডার্ন স্লাইড ট্যাব বার' },
                          { id: 'crimson_bold', label: '৩. বোল্ড রেড হাইলাইট বাটন' },
                          { id: 'radio_compact', label: '৪. রেডিও ডট মিনি কার্ড' }
                        ] as const
                      ).map(styleOpt => {
                        const isSelected =
                          (currentBusiness.checkoutSummaryZoneButtonStyle || 'emerald_pill') ===
                          styleOpt.id;
                        return (
                          <button
                            key={styleOpt.id}
                            type="button"
                            onClick={() => {
                              updateBusiness({ checkoutSummaryZoneButtonStyle: styleOpt.id });
                              showToast(
                                `ডেলিভারি এরিয়া বাটন ডিজাইন "${styleOpt.label}" সেট করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className={`px-3 py-2 rounded-xl text-xs font-extrabold border text-left transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-emerald-50'
                            }`}
                          >
                            {styleOpt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* উপায় ২: মোবাইলে আগে ফর্ম, পরে নিচে বিল */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-xs font-extrabold text-indigo-950">
                    🔄 উপায় ২: মোবাইলে আগে ফর্ম (নাম, ফোন ও এরিয়া), তারপর নিচে অর্ডার বিল
                  </p>
                  <p className="text-[11px] text-slate-500">
                    ON করলে মোবাইলে আগে নাম, ফোন ও ডেলিভারি এরিয়া নির্বাচনের ফর্ম আসবে, তারপর নিচে অর্ডার বক্স ও বিল দেখাবে। OFF থাকলে আগে অর্ডার বক্স ও বিল দেখাবে।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const nextFormFirst = !Boolean(currentBusiness.checkoutMobileFormFirst);
                    updateBusiness({ checkoutMobileFormFirst: nextFormFirst });
                    showToast(
                      nextFormFirst
                        ? 'উপায় ২ (ON): মোবাইলে আগে ফর্ম, পরে নিচে বিল দেখানো চালু করা হয়েছে!'
                        : 'উপায় ২ (OFF): মোবাইলে আগে উপরে অর্ডার বক্স ও বিল, নিচে ফর্ম দেখানো সেট করা হয়েছে!',
                      'success'
                    );
                  }}
                  className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                    currentBusiness.checkoutMobileFormFirst
                      ? 'bg-indigo-700 text-white border-indigo-700'
                      : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {currentBusiness.checkoutMobileFormFirst
                    ? 'উপায় ২ (আগে ফর্ম পরে বিল): ON ✓'
                    : 'উপায় ২ (আগে ফর্ম পরে বিল): OFF (আগে বিল)'}
                </button>
              </div>

              {/* 📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন (Estimated Delivery Date Badge — ON / OFF & Editable Text) */}
              <div className="p-3.5 rounded-xl bg-white border border-teal-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-extrabold text-teal-950">
                      📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন (Estimated Delivery Date Badge — ON / OFF)
                    </p>
                    <p className="text-[11px] text-slate-500">
                      কাস্টমার যখন "ঢাকার ভিতরে" বা "ঢাকার বাইরে" সিলেক্ট করবেন তখন নিচে আনুমানিক ডেলিভারির সময় দেখাবে—এতে কাস্টমারের আস্থা বাড়ে এবং দ্রুত অর্ডার কনফার্ম করে।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const nextEstOn = currentBusiness.checkoutEstimatedDeliveryEnabled === false;
                      updateBusiness({ checkoutEstimatedDeliveryEnabled: nextEstOn });
                      showToast(
                        nextEstOn
                          ? '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন চালু (ON) করা হয়েছে!'
                          : '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন বন্ধ (OFF) করা হয়েছে!',
                        nextEstOn ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer shrink-0 ${
                      currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                        ? 'bg-teal-700 text-white border-teal-700 shadow-2xs'
                        : 'bg-slate-200 text-slate-700 border-slate-300'
                    }`}
                  >
                    {currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                      ? '📦 ডেলিভারি সময় ব্যাজ: চালু আছে (ON) ✓'
                      : '📦 ডেলিভারি সময় ব্যাজ: বন্ধ আছে (OFF)'}
                  </button>
                </div>

                {currentBusiness.checkoutEstimatedDeliveryEnabled !== false && (
                  <div className="pt-2.5 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between gap-1">
                        <label className="text-[11px] font-extrabold text-slate-700">
                          ১. "ঢাকার ভিতরে" সিলেক্ট করলে যা দেখাবে:
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            const defInside = '🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে';
                            updateBusiness({ checkoutEstimatedDeliveryInsideText: defInside });
                            showToast('ঢাকার ভিতরের ডিফল্ট ডেলিভারি টেক্সট সেট করা হয়েছে!', 'info');
                          }}
                          className="text-[10px] font-bold text-teal-700 hover:underline cursor-pointer"
                        >
                          ডিফল্ট টেক্সট
                        </button>
                      </div>
                      <input
                        type="text"
                        value={
                          currentBusiness.checkoutEstimatedDeliveryInsideText ??
                          '🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে'
                        }
                        onChange={e =>
                          updateBusiness({ checkoutEstimatedDeliveryInsideText: e.target.value })
                        }
                        placeholder="🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে"
                        className="w-full min-h-[36px] px-3 py-1.5 rounded-lg bg-emerald-50/50 border border-emerald-300 focus:border-emerald-600 focus:bg-white text-xs font-bold text-slate-900 outline-hidden"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between gap-1">
                        <label className="text-[11px] font-extrabold text-slate-700">
                          ২. "ঢাকার বাইরে" সিলেক্ট করলে যা দেখাবে:
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            const defOutside =
                              '🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)';
                            updateBusiness({ checkoutEstimatedDeliveryOutsideText: defOutside });
                            showToast('ঢাকার বাইরের ডিফল্ট ডেলিভারি টেক্সট সেট করা হয়েছে!', 'info');
                          }}
                          className="text-[10px] font-bold text-teal-700 hover:underline cursor-pointer"
                        >
                          ডিফল্ট টেক্সট
                        </button>
                      </div>
                      <input
                        type="text"
                        value={
                          currentBusiness.checkoutEstimatedDeliveryOutsideText ??
                          '🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)'
                        }
                        onChange={e =>
                          updateBusiness({ checkoutEstimatedDeliveryOutsideText: e.target.value })
                        }
                        placeholder="🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)"
                        className="w-full min-h-[36px] px-3 py-1.5 rounded-lg bg-teal-50/50 border border-teal-300 focus:border-teal-600 focus:bg-white text-xs font-bold text-slate-900 outline-hidden"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Smart Image-Overlaid "স্টক শেষ (Stock Out)" Badge Style Switcher */}
            <div className="sm:col-span-2 bg-slate-50 rounded-xl p-4 border border-slate-200/90 space-y-2.5">
              <div className="space-y-0.5">
                <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                  🖼️ প্রোডাক্ট ছবির ওপর "স্টক শেষ / Stock Out" দেখানোর স্মার্ট ভিউ স্টাইল
                </p>
                <p className="text-[11px] text-slate-600">
                  যেকোনো প্রোডাক্ট স্টক আউট করলে ছবির ওপর কীভাবে কাস্টমারকে দেখাবে তা ১-ক্লিকে সিলেক্ট করুন (আগের ডিজাইনও ৪ নম্বর অপশনে রাখা হয়েছে)।
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {(
                  [
                    { id: 'center_glass', label: '১. ছবির মাঝে স্মার্ট ব্যাজ (ডিফল্ট)' },
                    { id: 'diagonal_ribbon', label: '২. ছবির ওপর কোণাকুণি রিবন' },
                    { id: 'bottom_banner', label: '৩. ছবির নিচে ফুল-উইডথ বার' },
                    { id: 'classic_corner', label: '৪. আগের ক্লাসিক কর্নার ব্যাজ' }
                  ] as const
                ).map(styleOpt => {
                  const activeStyle = currentBusiness.stockOutBadgeStyle || 'center_glass';
                  const isSel = activeStyle === styleOpt.id;
                  return (
                    <button
                      key={styleOpt.id}
                      type="button"
                      onClick={() => {
                        updateBusiness({ stockOutBadgeStyle: styleOpt.id });
                        showToast(`স্টক শেষ ভিউ "${styleOpt.label}" সেট করা হয়েছে!`, 'success');
                      }}
                      className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                        isSel
                          ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-slate-500'
                      }`}
                    >
                      {styleOpt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 1-Click Marketing Scarcity Stock ("অফার মূল্যে আর মাত্র X টি বাকি আছে!") ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-rose-50/60 rounded-xl p-4 border border-rose-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-extrabold text-slate-900">
                  প্রোডাক্ট পেজে "অফার মূল্যে আর মাত্র X টি বাকি আছে! / সীমিত স্টক" অ্যালার্ট
                </p>
                <p className="text-[11px] text-slate-600">
                  ১-ক্লিকে ওয়েবসাইটের প্রোডাক্ট পেজ ও কার্ডে মার্কেটিং ফেক স্টক / সীমিত স্টক কাউন্টার চালু (ON) অথবা বন্ধ (OFF) করুন।
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextState = currentBusiness.scarcityStockEnabled === false;
                  updateBusiness({ scarcityStockEnabled: nextState });
                  showToast(
                    nextState
                      ? 'প্রোডাক্ট পেজে "সীমিত স্টক / আর মাত্র X টি বাকি" দেখানো চালু (ON) করা হয়েছে!'
                      : 'প্রোডাক্ট পেজে "সীমিত স্টক / আর মাত্র X টি বাকি" দেখানো বন্ধ (OFF) করা হয়েছে!',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  currentBusiness.scarcityStockEnabled !== false
                    ? 'bg-[#c30000] hover:bg-[#9e0000] text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <span>
                  {currentBusiness.scarcityStockEnabled !== false
                    ? '🔥 বর্তমানে চালু (ON) — বন্ধ করতে ক্লিক করুন'
                    : 'বর্তমানে বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                </span>
              </button>
            </div>

            {/* 1-Click Home Page Product Card Variations (হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন প্রদর্শন) ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-emerald-50/60 rounded-xl p-4 border border-emerald-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-extrabold text-slate-900">
                  হোমপেজে প্রোডাক্টের নিচে সাইজ/ভ্যারিয়েশন প্রদর্শন (Home Page Product Card Variations — ON / OFF)
                </p>
                <p className="text-[11px] text-slate-600">
                  চালু (ON) থাকলে হোমপেজে প্রোডাক্টের নিচে সাইজ বাটনগুলো দেখাবে। বন্ধ (OFF) করলে <span className="font-bold text-slate-800">প্রোডাক্ট পেজ (এবং অর্ডার নাউ ক্লিক করলে আসা সাইজ পপআপ) ছাড়া</span> হোমপেজে বা অন্য কোথাও প্রোডাক্টের নিচে ভ্যারিয়েশন দেখাবে না। যেকোনো সময় আবার চালু (ON) করতে পারবেন।
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextState = currentBusiness.showVariantsOnHomePage === false;
                  updateBusiness({ showVariantsOnHomePage: nextState });
                  showToast(
                    nextState
                      ? 'হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন দেখানো চালু (ON) করা হয়েছে!'
                      : 'হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন বন্ধ (OFF) করা হয়েছে! (এখন শুধু প্রোডাক্ট পেজে ও সাইজ পপআপে দেখাবে)',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  currentBusiness.showVariantsOnHomePage !== false
                    ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {currentBusiness.showVariantsOnHomePage !== false
                    ? '📏 হোমপেজ ভ্যারিয়েশন চালু (ON) — বন্ধ করতে ক্লিক করুন'
                    : 'হোমপেজ ভ্যারিয়েশন বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                </span>
              </button>
            </div>

            {/* 1-Click Home Page & Related Products Full Product Name vs 2-Line Clamp ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-amber-50/75 rounded-xl p-4 border border-amber-300/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                  📝 হোমপেজ ও রিলেটেড প্রোডাক্টে সম্পূর্ণ নাম প্রদর্শন (Full Product Name ON / OFF)
                </p>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  চালু (ON) করলে হোমপেজ এবং প্রোডাক্ট পেজের নিচের &ldquo;আমাদের আরও পণ্য (Related Products)&rdquo;-এ প্রোডাক্টের সম্পূর্ণ নাম দেখাবে। আর বন্ধ (OFF) রাখলে সুন্দরভাবে ২ লাইন দেখিয়ে বাকি অংশ হাইড থাকবে।
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({ showFullProductNameOnCards: true });
                    showToast(
                      'হোমপেজ ও রিলেটেড প্রোডাক্টে সম্পূর্ণ নাম প্রদর্শন চালু (ON) করা হয়েছে!',
                      'success'
                    );
                  }}
                  className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer border shadow-2xs ${
                    Boolean(currentBusiness.showFullProductNameOnCards)
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-emerald-50'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>সম্পূর্ণ নাম দেখান (ON)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({ showFullProductNameOnCards: false });
                    showToast(
                      'হোমপেজ ও রিলেটেড প্রোডাক্টে ২-লাইনে সংক্ষিপ্ত নাম (OFF) চালু করা হয়েছে!',
                      'info'
                    );
                  }}
                  className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer border shadow-2xs ${
                    !currentBusiness.showFullProductNameOnCards
                      ? 'bg-slate-800 text-white border-slate-800'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <span>২-লাইনে সংক্ষিপ্ত নাম (OFF)</span>
                </button>
              </div>
            </div>

            {/* 1-Click Checkout Page Full Product Name vs 1-Line Truncate ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-emerald-50/75 rounded-xl p-4 border border-emerald-300/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                  🛒 চেকআউট পেজে প্রোডাক্টের সম্পূর্ণ নাম প্রদর্শন (Checkout Full Product Name ON / OFF)
                </p>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  চালু (ON) করলে চেকআউট পেজের অর্ডার বক্সে প্রোডাক্টের সম্পূর্ণ নাম দেখাবে। আর বন্ধ (OFF) রাখলে আগের মতো ১ লাইনে সংক্ষিপ্ত নাম দেখাবে।
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({ showFullProductNameOnCheckout: true });
                    showToast(
                      'চেকআউট পেজে প্রোডাক্টের সম্পূর্ণ নাম প্রদর্শন চালু (ON) করা হয়েছে!',
                      'success'
                    );
                  }}
                  className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer border shadow-2xs ${
                    currentBusiness.showFullProductNameOnCheckout !== false
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-emerald-50'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>সম্পূর্ণ নাম দেখান (ON)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({ showFullProductNameOnCheckout: false });
                    showToast(
                      'চেকআউট পেজে ১-লাইনে সংক্ষিপ্ত নাম (OFF) চালু করা হয়েছে!',
                      'info'
                    );
                  }}
                  className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer border shadow-2xs ${
                    currentBusiness.showFullProductNameOnCheckout === false
                      ? 'bg-slate-800 text-white border-slate-800'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <span>১-লাইনে সংক্ষিপ্ত নাম (OFF)</span>
                </button>
              </div>
            </div>

            {/* 1-Click Home Page "+ ব্যাগে যোগ করুন" & Product Page "শপিং ব্যাগে যোগ করুন" Buttons ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-teal-50/60 rounded-xl p-4 border border-teal-200/90 space-y-3">
              <div>
                <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                  "ব্যাগে যোগ করুন" (হোমপেজ) ও "শপিং ব্যাগে যোগ করুন" (প্রোডাক্ট পেজ) বাটন ON / OFF কন্ট্রোল
                </p>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  আপনি চাইলে হোমপেজের প্রোডাক্ট কার্ড থেকে <span className="font-bold text-slate-800">"+ ব্যাগে যোগ করুন"</span> বাটন এবং প্রোডাক্ট পেজ থেকে <span className="font-bold text-slate-800">"শপিং ব্যাগে যোগ করুন"</span> বাটন আলাদাভাবে ১-ক্লিকে চালু (ON) অথবা বন্ধ (OFF) করে রাখতে পারবেন।
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Home Page "+ ব্যাগে যোগ করুন" Toggle */}
                <div className="bg-white rounded-xl p-3.5 border border-teal-200 flex flex-col justify-between gap-2.5 shadow-2xs">
                  <div>
                    <p className="text-xs font-extrabold text-slate-900">
                      ১. হোমপেজে "+ ব্যাগে যোগ করুন" বাটন
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      বন্ধ (OFF) করলে হোমপেজে প্রোডাক্টের নিচে শুধু লাল রঙের "অর্ডার করুন" বাটনটি থাকবে।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const nextState = currentBusiness.showAddToBagOnHomePage === false;
                      updateBusiness({ showAddToBagOnHomePage: nextState });
                      showToast(
                        nextState
                          ? 'হোমপেজে "+ ব্যাগে যোগ করুন" বাটন চালু (ON) করা হয়েছে!'
                          : 'হোমপেজে "+ ব্যাগে যোগ করুন" বাটন বন্ধ (OFF) করা হয়েছে!',
                        nextState ? 'success' : 'info'
                      );
                    }}
                    className={`w-full min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs ${
                      currentBusiness.showAddToBagOnHomePage !== false
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {currentBusiness.showAddToBagOnHomePage !== false
                        ? '🛍️ হোমপেজে "ব্যাগে যোগ করুন": চালু (ON)'
                        : 'হোমপেজে "ব্যাগে যোগ করুন": বন্ধ (OFF)'}
                    </span>
                  </button>
                </div>

                {/* Product Page "শপিং ব্যাগে যোগ করুন" Toggle */}
                <div className="bg-white rounded-xl p-3.5 border border-teal-200 flex flex-col justify-between gap-2.5 shadow-2xs">
                  <div>
                    <p className="text-xs font-extrabold text-slate-900">
                      ২. প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      বন্ধ (OFF) করলে প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" লুকিয়ে যাবে এবং "এখনই অর্ডার করুন" বাটনটি ফুল-উইডথ দেখাবে।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const nextState = currentBusiness.showAddToBagOnProductPage === false;
                      updateBusiness({ showAddToBagOnProductPage: nextState });
                      showToast(
                        nextState
                          ? 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন চালু (ON) করা হয়েছে!'
                          : 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন বন্ধ (OFF) করা হয়েছে!',
                        nextState ? 'success' : 'info'
                      );
                    }}
                    className={`w-full min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs ${
                      currentBusiness.showAddToBagOnProductPage !== false
                        ? 'bg-[#006A4E] hover:bg-[#005840] text-white'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {currentBusiness.showAddToBagOnProductPage !== false
                        ? '🛒 প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন": চালু (ON)'
                        : 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন": বন্ধ (OFF)'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Bottom Floating Bars ON/OFF (Home Page Floating Bar + Product/Checkout Sticky Bar) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                {/* 1. Home Page Bottom Floating Bar ON/OFF */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between gap-2.5">
                  <div className="space-y-1">
                    <p className="text-xs font-extrabold text-slate-900">
                      ১. হোমপেজের নিচের ফ্লোটিং বার (Home Page Bottom Floating Bar)
                    </p>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      হোমপেজের নিচে থাকা ফ্লোটিং কার্ট বার ও কুইক ফ্লোটিং বার চালু বা বন্ধ করুন। আপনি চাইলে ফ্লোটিং বার বা রিসেন্ট অর্ডার নোটিফিকেশনের যেকোনো একটি ON রেখে অন্যটি OFF রাখতে পারেন।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const nextState = !(currentBusiness.homeFloatingBarEnabled !== false);
                      updateBusiness({ homeFloatingBarEnabled: nextState });
                      showToast(
                        nextState
                          ? 'হোমপেজের নিচের ফ্লোটিং বার চালু (ON) করা হয়েছে!'
                          : 'হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করা হয়েছে!',
                        nextState ? 'success' : 'info'
                      );
                    }}
                    className={`w-full min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs ${
                      currentBusiness.homeFloatingBarEnabled !== false
                        ? 'bg-[#006A4E] hover:bg-[#005840] text-white'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {currentBusiness.homeFloatingBarEnabled !== false
                        ? '📌 হোমপেজ ফ্লোটিং বার: চালু (ON)'
                        : 'হোমপেজ ফ্লোটিং বার: বন্ধ (OFF)'}
                    </span>
                  </button>
                </div>

                {/* 2. Product Page & Checkout Sticky Bottom Floating Bar (Mobile Only / Desktop+Mobile / Completely OFF) */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between gap-2.5">
                  <div className="space-y-1">
                    <p className="text-xs font-extrabold text-slate-900">
                      ২. প্রোডাক্ট পেজের নিচের ফ্লোটিং "এখনই অর্ডার করুন" বাটন
                    </p>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      প্রোডাক্ট পেজের নিচের ফ্লোটিং অর্ডার বাটনটি ডেক্সটপ থেকে হাইড (শুধু মোবাইলে চালু), সব ভিউতে চালু, অথবা একদম বন্ধ (OFF) রাখুন:
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({
                          storefrontFloatingBtnEnabled: true,
                          storefrontFloatingBtnHideOnDesktop: true
                        });
                        showToast(
                          'প্রোডাক্ট পেজের ফ্লোটিং বাটন ডেক্সটপ থেকে হাইড করা হয়েছে (শুধু মোবাইলে দেখাবে)!',
                          'success'
                        );
                      }}
                      className={`min-h-[38px] px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer border ${
                        currentBusiness.storefrontFloatingBtnEnabled !== false &&
                        currentBusiness.storefrontFloatingBtnHideOnDesktop !== false
                          ? 'bg-[#006A4E] text-white border-[#006A4E] shadow-2xs'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      <span>📱 শুধু মোবাইলে (ডেক্সটপে হাইড)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({
                          storefrontFloatingBtnEnabled: true,
                          storefrontFloatingBtnHideOnDesktop: false
                        });
                        showToast(
                          'প্রোডাক্ট পেজের ফ্লোটিং বাটন মোবাইল ও ডেক্সটপ উভয় ভিউতে চালু করা হয়েছে!',
                          'success'
                        );
                      }}
                      className={`min-h-[38px] px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer border ${
                        currentBusiness.storefrontFloatingBtnEnabled !== false &&
                        currentBusiness.storefrontFloatingBtnHideOnDesktop === false
                          ? 'bg-indigo-700 text-white border-indigo-700 shadow-2xs'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      <span>💻 মোবাইল + ডেক্সটপ (ON)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({ storefrontFloatingBtnEnabled: false });
                        showToast(
                          'প্রোডাক্ট পেজের ফ্লোটিং অর্ডার বাটন একদম বন্ধ (OFF) করা হয়েছে!',
                          'info'
                        );
                      }}
                      className={`min-h-[38px] px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer border ${
                        currentBusiness.storefrontFloatingBtnEnabled === false
                          ? 'bg-rose-700 text-white border-rose-700 shadow-2xs'
                          : 'bg-white hover:bg-rose-50 text-slate-700 border-slate-300'
                      }`}
                    >
                      <span>🚫 একদম বন্ধ (OFF)</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Product Page Variation Price (ON/OFF) & 4 Selectable Variation Button Designs */}
            <div className="sm:col-span-2 bg-white rounded-xl p-4 border border-emerald-200/90 shadow-2xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2.5 border-b border-slate-100">
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                    প্রোডাক্ট পেজে ভ্যারিয়েশনের প্রাইস প্রদর্শন (ON / OFF) ও ৪টি ডিজাইন স্টাইল
                  </p>
                  <p className="text-[11px] text-slate-600">
                    প্রোডাক্ট পেজে সাইজ/ভ্যারিয়েশন বাটনের ভেতরে দাম (যেমন: <span className="font-bold text-slate-800">1-2 Years · ৳990</span>) দেখানো ১-ক্লিকে চালু (ON) বা বন্ধ (OFF) করুন। এছাড়া নিচে দেওয়া <span className="font-bold text-emerald-700">৪টি ডিজাইন স্টাইল (বর্তমান স্টাইলসহ)</span> থেকে আপনার পছন্দের ডিজাইনটি বেছে নিন।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextState = currentBusiness.productPageVariantShowPrice === false;
                    updateBusiness({ productPageVariantShowPrice: nextState });
                    showToast(
                      nextState
                        ? 'প্রোডাক্ট পেজে ভ্যারিয়েশনের সাথে দাম (Price) দেখানো চালু (ON) করা হয়েছে!'
                        : 'প্রোডাক্ট পেজে ভ্যারিয়েশনের দাম বন্ধ (OFF) করা হয়েছে (এখন শুধু সাইজ দেখাবে)!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                    currentBusiness.productPageVariantShowPrice !== false
                      ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {currentBusiness.productPageVariantShowPrice !== false
                      ? '💰 ভ্যারিয়েশন প্রাইস চালু (ON) — বন্ধ করতে ক্লিক করুন'
                      : 'ভ্যারিয়েশন প্রাইস বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                  </span>
                </button>
              </div>

              {/* 4 Selectable Variation Button Designs with Live Preview */}
              <div className="space-y-2 pt-1">
                <label className="block text-xs font-extrabold text-slate-800">
                  ভ্যারিয়েশন বাটনের ডিজাইন বেছে নিন (যেকোনো সময় ১-ক্লিকে পরিবর্তন বা আগের ডিফল্ট ডিজাইনে ফিরতে পারবেন):
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                  {[
                    {
                      id: 'classic_inline' as const,
                      title: 'ডিজাইন ১: বর্তমান ক্লাসিক স্টাইল (ডিফল্ট)',
                      desc: 'এক লাইনে সাইজ ও দাম (1-2 Years · ৳990)'
                    },
                    {
                      id: 'stacked_card' as const,
                      title: 'ডিজাইন ২: ২-লাইন বক্স কার্ড স্টাইল',
                      desc: 'উপরে সাইজ, নিচে দাম ও কর্নার টিক-মার্ক'
                    },
                    {
                      id: 'price_badge' as const,
                      title: 'ডিজাইন ৩: মডার্ন প্রাইস ট্যাগ ব্যাজ',
                      desc: 'সাইজের পাশে আলাদা হাইলাইটেড প্রাইস বক্স'
                    },
                    {
                      id: 'minimal_check' as const,
                      title: 'ডিজাইন ৪: ফ্যাশন আউটলাইন ও টিক-মার্ক',
                      desc: 'বামে গোল টিক-মার্ক ও ব্র্যাকেটে দাম'
                    }
                  ].map(styleOpt => {
                    const activeStyle =
                      currentBusiness.productPageVariantStyle || 'classic_inline';
                    const isSelected = activeStyle === styleOpt.id;
                    const showPrice = currentBusiness.productPageVariantShowPrice !== false;
                    return (
                      <div
                        key={styleOpt.id}
                        onClick={() => {
                          updateBusiness({ productPageVariantStyle: styleOpt.id });
                          showToast(
                            `প্রোডাক্ট পেজ ভ্যারিয়েশন ডিজাইন: "${styleOpt.title}" সেট করা হয়েছে!`,
                            'success'
                          );
                        }}
                        className={`p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-2.5 ${
                          isSelected
                            ? 'bg-emerald-50/70 border-emerald-700 shadow-2xs'
                            : 'bg-slate-50/60 border-slate-200 hover:border-emerald-400'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-xs font-extrabold text-slate-900">
                              {styleOpt.title}
                            </span>
                            {isSelected && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-700 text-white text-[9px] font-extrabold shrink-0">
                                Active
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-500 mt-0.5">{styleOpt.desc}</p>
                        </div>

                        {/* Mini Visual Preview of the Button Style */}
                        <div className="pt-1 flex items-center justify-start">
                          {styleOpt.id === 'classic_inline' && (
                            <span className="px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-700 text-white border-2 border-emerald-700 inline-flex items-center">
                              <span>1-2 Years</span>
                              {showPrice && <span className="ml-1.5 font-mono">· ৳990</span>}
                            </span>
                          )}
                          {styleOpt.id === 'stacked_card' && (
                            <span className="relative min-w-[92px] px-3 py-1.5 rounded-xl text-center bg-emerald-50 text-emerald-950 border-2 border-emerald-700 inline-block">
                              <span className="block text-xs font-extrabold leading-tight">
                                1-2 Years
                              </span>
                              {showPrice && (
                                <span className="block font-mono text-[11px] font-extrabold text-emerald-700 mt-0.5">
                                  ৳990
                                </span>
                              )}
                            </span>
                          )}
                          {styleOpt.id === 'price_badge' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-800 text-white border-2 border-emerald-800">
                              <span>1-2 Years</span>
                              {showPrice && (
                                <span className="px-1.5 py-0.5 rounded-md bg-amber-300 text-slate-950 font-mono text-[10px] font-extrabold">
                                  ৳990
                                </span>
                              )}
                            </span>
                          )}
                          {styleOpt.id === 'minimal_check' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-50 text-emerald-950 border-2 border-emerald-700">
                              <span className="w-3 h-3 rounded-full bg-emerald-700 flex items-center justify-center">
                                <span className="w-1.5 h-1.5 rounded-full bg-white" />
                              </span>
                              <span>1-2 Years</span>
                              {showPrice && (
                                <span className="font-mono font-extrabold text-rose-700">
                                  (৳990)
                                </span>
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Global Storefront Offer Countdown Timer (সব প্রোডাক্টে একই গ্লোবাল টাইম + ১-ক্লিকে সব প্রোডাক্টে ON/OFF + রিয়েলিস্টিক র‍্যান্ডম টাইম) */}
            <div className="sm:col-span-2 bg-white rounded-xl p-4 border border-rose-200/90 shadow-2xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2.5 border-b border-slate-100">
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>
                      গ্লোবাল অফার কাউন্টডাউন টাইমার ("স্পেশাল অফার শেষ হতে বাকি" — সব প্রোডাক্টে একই সময় ও ১-ক্লিকে ON / OFF)
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    ফ্রন্ট ওয়েবসাইটের <span className="font-bold text-slate-800">সব প্রোডাক্টে একই গ্লোবাল টাইম একসাথে চলবে</span> (এক প্রোডাক্ট থেকে অন্য প্রোডাক্টে গেলে টাইম পরিবর্তন বা রিসেট হবে না)। ৮ ঘণ্টা ৫৯ মিনিট ৫৯ সেকেন্ডের মতো কৃত্রিম না দেখিয়ে <span className="font-bold text-rose-700">৮ ঘণ্টা ৩০ মিনিট ৩৪ সেকেন্ড</span> এর মতো ন্যাচারাল/রিয়েলিস্টিক সময় থেকে কমতে থাকবে এবং ০ হলে আবার নতুন রিয়েলিস্টিক সময় থেকে অটো শুরু হবে।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextState = currentBusiness.storefrontCountdownEnabled === false;
                    updateBusiness({ storefrontCountdownEnabled: nextState });
                    showToast(
                      nextState
                        ? '১-ক্লিকে সব প্রোডাক্টে গ্লোবাল অফার কাউন্টডাউন চালু (ON) করা হয়েছে!'
                        : '১-ক্লিকে সব প্রোডাক্টে গ্লোবাল অফার কাউন্টডাউন বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                    currentBusiness.storefrontCountdownEnabled !== false
                      ? 'bg-rose-600 hover:bg-rose-700 text-white'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  <span>
                    {currentBusiness.storefrontCountdownEnabled !== false
                      ? '⏳ সব প্রোডাক্টে চালু (ON) — বন্ধ করতে ক্লিক করুন'
                      : 'সব প্রোডাক্টে বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                  </span>
                </button>
              </div>

              {currentBusiness.storefrontCountdownEnabled !== false && (
                <div className="space-y-3 pt-1">
                  {/* Centralized Realistic Time Presets & Custom Hours:Minutes:Seconds */}
                  <div className="p-3 rounded-xl bg-rose-50/50 border border-rose-200/80 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-rose-600" />
                        <span>
                          গ্লোবাল কাউন্টডাউন শুরুর সময় সেট করুন (ঘণ্টা : মিনিট : সেকেন্ড — এক জায়গা থেকে সব প্রোডাক্টে প্রযোজ্য):
                        </span>
                      </label>

                      <button
                        type="button"
                        onClick={() => {
                          const randH = [3, 5, 7, 8, 10][Math.floor(Math.random() * 5)];
                          const randM = Math.floor(18 + Math.random() * 31);
                          const randS = Math.floor(12 + Math.random() * 43);
                          updateBusiness({
                            storefrontCountdownHours: randH,
                            storefrontCountdownMinutes: randM,
                            storefrontCountdownSeconds: randS,
                            storefrontCountdownResetSeed: Date.now()
                          });
                          showToast(
                            `নতুন রিয়েলিস্টিক গ্লোবাল টাইম (${randH} ঘণ্টা ${randM} মিনিট ${randS} সেকেন্ড) সব প্রোডাক্টে সেট ও রিস্টার্ট করা হয়েছে!`,
                            'success'
                          );
                        }}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-extrabold transition-all cursor-pointer shadow-2xs"
                      >
                        🎲 ১-ক্লিকে র‍্যান্ডম রিয়েলিস্টিক টাইম সেট করুন
                      </button>
                    </div>

                    {/* Quick Realistic Presets */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      {[
                        { h: 8, m: 30, s: 34, label: '৮ ঘণ্টা ৩০ মি. ৩৪ সে. (৯ ঘণ্টার রিয়েলিস্টিক)' },
                        { h: 5, m: 42, s: 18, label: '৫ ঘণ্টা ৪২ মি. ১৮ সে. (৬ ঘণ্টার রিয়েলিস্টিক)' },
                        { h: 2, m: 35, s: 47, label: '২ ঘণ্টা ৩৫ মি. ৪৭ সে. (৩ ঘণ্টার রিয়েলিস্টিক)' },
                        { h: 11, m: 28, s: 19, label: '১১ ঘণ্টা ২৮ মি. ১৯ সে. (১২ ঘণ্টার রিয়েলিস্টিক)' },
                        { h: 18, m: 37, s: 26, label: '১৮ ঘণ্টা ৩৭ মি. ২৬ সে. (২৪ ঘণ্টার রিয়েলিস্টিক)' }
                      ].map(opt => {
                        const curH = currentBusiness.storefrontCountdownHours ?? 8;
                        const curM = currentBusiness.storefrontCountdownMinutes ?? 30;
                        const curS = currentBusiness.storefrontCountdownSeconds ?? 34;
                        const isSelected = curH === opt.h && curM === opt.m && curS === opt.s;
                        return (
                          <button
                            key={opt.label}
                            type="button"
                            onClick={() => {
                              updateBusiness({
                                storefrontCountdownHours: opt.h,
                                storefrontCountdownMinutes: opt.m,
                                storefrontCountdownSeconds: opt.s,
                                storefrontCountdownResetSeed: Date.now()
                              });
                              showToast(
                                `সব প্রোডাক্টের গ্লোবাল কাউন্টডাউন টাইম: ${opt.label} থেকে শুরু করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                : 'bg-white hover:bg-rose-50 text-slate-700 border-slate-200'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Exact Custom Hours, Minutes, Seconds & Title */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-1">
                      <div className="sm:col-span-6 flex flex-wrap items-center gap-2">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                            ঘণ্টা (Hours)
                          </label>
                          <input
                            type="number"
                            min={0}
                            max={72}
                            value={currentBusiness.storefrontCountdownHours ?? 8}
                            onChange={e => {
                              const val = Math.max(0, Math.min(72, parseInt(e.target.value, 10) || 0));
                              updateBusiness({
                                storefrontCountdownHours: val,
                                storefrontCountdownResetSeed: Date.now()
                              });
                            }}
                            className="w-20 min-h-[36px] px-2.5 py-1 rounded-lg border border-rose-300 bg-white font-mono font-extrabold text-xs text-slate-900 text-center"
                          />
                        </div>
                        <span className="font-extrabold text-rose-600 mt-4">:</span>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                            মিনিট (Minutes)
                          </label>
                          <input
                            type="number"
                            min={0}
                            max={59}
                            value={currentBusiness.storefrontCountdownMinutes ?? 30}
                            onChange={e => {
                              const val = Math.max(0, Math.min(59, parseInt(e.target.value, 10) || 0));
                              updateBusiness({
                                storefrontCountdownMinutes: val,
                                storefrontCountdownResetSeed: Date.now()
                              });
                            }}
                            className="w-20 min-h-[36px] px-2.5 py-1 rounded-lg border border-rose-300 bg-white font-mono font-extrabold text-xs text-slate-900 text-center"
                          />
                        </div>
                        <span className="font-extrabold text-rose-600 mt-4">:</span>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                            সেকেন্ড (Seconds)
                          </label>
                          <input
                            type="number"
                            min={1}
                            max={58}
                            value={currentBusiness.storefrontCountdownSeconds ?? 34}
                            onChange={e => {
                              const val = Math.max(1, Math.min(58, parseInt(e.target.value, 10) || 34));
                              updateBusiness({
                                storefrontCountdownSeconds: val,
                                storefrontCountdownResetSeed: Date.now()
                              });
                            }}
                            className="w-20 min-h-[36px] px-2.5 py-1 rounded-lg border border-rose-300 bg-white font-mono font-extrabold text-xs text-slate-900 text-center"
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-6">
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                          কাউন্টডাউন টাইটেল টেক্সট (গ্লোবাল)
                        </label>
                        <input
                          type="text"
                          value={currentBusiness.storefrontCountdownTitle ?? 'স্পেশাল অফার শেষ হতে বাকি:'}
                          onChange={e => {
                            updateBusiness({ storefrontCountdownTitle: e.target.value });
                          }}
                          placeholder="স্পেশাল অফার শেষ হতে বাকি:"
                          className="w-full min-h-[36px] px-3 py-1 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900 outline-hidden focus:border-rose-500"
                        />
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500">
                      নোট: প্রোডাক্ট পেজে শুধুমাত্র ওই নির্দিষ্ট প্রোডাক্টে কাউন্টডাউন দেখাবে কি না (Show/Hide) তা প্রোডাক্ট পেজ বা প্রোডাক্ট এডিট থেকে কন্ট্রোল করা যাবে, কিন্তু টাইম সবসময় এই গ্লোবাল টাইমের সাথে মিল রেখে চলবে।
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Storefront Live Recent Sales Popup Notification (Social Proof Toast — ON/OFF + Speed/Time Gap + Custom Buyers) */}
            <div className="sm:col-span-2 bg-white rounded-xl p-4 border border-emerald-200/90 shadow-2xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2.5 border-b border-slate-100">
                <div className="space-y-1">
                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Bell className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      স্টোরফ্রন্ট রিসেন্ট সেলস পপআপ নোটিফিকেশন (Live Order Social Proof Toast — ON / OFF)
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-600">
                    স্ক্রিনের নিচে কোণায় কয়েক সেকেন্ড পর পর নোটিফিকেশন দেখাবে (যেমন: <span className="font-bold text-slate-800">"উত্তরা, ঢাকা থেকে তানিয়া আক্তার এইমাত্র অর্ডার করেছেন ✓"</span>)। বাংলাদেশের ৫৬+ জেলা ও এলাকার ভেরিফাইড ক্রেতার ডেটা থেকে স্মার্ট রোটেশনে দেখাবে।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextState = currentBusiness.storefrontSocialProofEnabled === false;
                    updateBusiness({ storefrontSocialProofEnabled: nextState });
                    showToast(
                      nextState
                        ? 'স্টোরফ্রন্টে রিসেন্ট সেলস পপআপ নোটিফিকেশন চালু (ON) করা হয়েছে!'
                        : 'স্টোরফ্রন্টে রিসেন্ট সেলস পপআপ নোটিফিকেশন বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                    currentBusiness.storefrontSocialProofEnabled !== false
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                  }`}
                >
                  <Bell className="w-4 h-4" />
                  <span>
                    {currentBusiness.storefrontSocialProofEnabled !== false
                      ? '🔔 অর্ডার পপ-আপ চালু (ON) — বন্ধ করতে ক্লিক করুন'
                      : 'অর্ডার পপ-আপ বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                  </span>
                </button>
              </div>

              {currentBusiness.storefrontSocialProofEnabled !== false && (
                <div className="space-y-3 pt-1">
                  {/* Speed / Time Gap Control */}
                  <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200/80 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-emerald-600" />
                        <span>
                          অর্ডার নোটিফিকেশন আসার সময়ের গ্যাপ (Speed / Time Gap — কত সেকেন্ড পর পর দেখাবে):
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min={2}
                          max={300}
                          value={currentBusiness.storefrontSocialProofIntervalSec ?? 16}
                          onChange={e => {
                            const val = Math.max(2, Math.min(300, Number(e.target.value) || 16));
                            updateBusiness({ storefrontSocialProofIntervalSec: val });
                          }}
                          className="w-20 min-h-[32px] px-2.5 py-1 rounded-lg border border-emerald-300 bg-white font-mono font-extrabold text-xs text-slate-900 text-center"
                        />
                        <span className="text-[11px] font-bold text-slate-600">সেকেন্ড গ্যাপ</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5">
                      {[
                        { sec: 5, label: 'ফাস্ট (৫ সে. গ্যাপ)' },
                        { sec: 10, label: 'মিডিয়াম (১০ সে. গ্যাপ)' },
                        { sec: 16, label: 'স্ট্যান্ডার্ড (১৬ সে. গ্যাপ)' },
                        { sec: 25, label: 'গ্যাপ দিয়ে (২৫ সে. গ্যাপ)' },
                        { sec: 40, label: 'স্লো (৪০ সে. গ্যাপ)' },
                        { sec: 60, label: '১ মিনিট পর পর (৬০ সে.)' }
                      ].map(opt => {
                        const activeGap = currentBusiness.storefrontSocialProofIntervalSec ?? 16;
                        return (
                          <button
                            key={opt.sec}
                            type="button"
                            onClick={() => {
                              updateBusiness({ storefrontSocialProofIntervalSec: opt.sec });
                              showToast(
                                `স্টোরফ্রন্ট অর্ডার পপ-আপ গ্যাপ: ${opt.label} সেট করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition-all cursor-pointer ${
                              activeGap === opt.sec
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                : 'bg-white hover:bg-emerald-50 text-slate-700 border-slate-200'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      টিপস: প্রতিটি নোটিফিকেশন ৪.৫ সেকেন্ড স্ক্রিনে থাকবে এবং এরপর আপনার সিলেক্ট করা সেকেন্ড গ্যাপ দিয়ে পরবর্তী নোটিফিকেশন আসবে।
                    </p>
                  </div>

                  {/* Optional Custom Buyers Textarea */}
                  <div>
                    <label className="block font-bold text-slate-800 text-xs mb-1">
                      কাস্টম ক্রেতার নাম ও ঠিকানা (ঐচ্ছিক — ফাঁকা রাখলে অটোমেটিক সারা বাংলাদেশের ৫৬+ এলাকার ভেরিফাইড ক্রেতার নাম র‍্যান্ডমলি দেখাবে):
                    </label>
                    <textarea
                      rows={3}
                      value={(currentBusiness.storefrontSocialProofCustomEntries || []).join('\n')}
                      onChange={e => {
                        const rawLines = e.target.value
                          .split('\n')
                          .map(s => s.trim())
                          .filter(Boolean);
                        updateBusiness({
                          storefrontSocialProofCustomEntries: rawLines.length > 0 ? rawLines : undefined
                        });
                      }}
                      placeholder={`তানিয়া আক্তার | উত্তরা, ঢাকা | ৩ মিনিট আগে\nফারহানা ইসলাম | ধানমন্ডি, ঢাকা | ৭ মিনিট আগে\nরাকিবুল হাসান | চট্টগ্রাম | ১২ মিনিট আগে`}
                      className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-xs text-slate-900 outline-hidden focus:border-emerald-600"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* 1-Click Global Product Image HD Zoom (ওয়েবসাইট ও ল্যান্ডিং পেজে প্রোডাক্ট ছবি জুম) ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-indigo-50/70 rounded-xl p-4 border border-indigo-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-extrabold text-slate-900">
                  স্মার্ট প্রোডাক্ট ছবি এইচডি জুম (Product Image HD Zoom — ফ্রন্ট ওয়েবসাইট ও ল্যান্ডিং পেজ)
                </p>
                <p className="text-[11px] text-slate-600">
                  চালু (ON) থাকলে কাস্টমাররা ওয়েবসাইট এবং ল্যান্ডিং পেজে পণ্যের ছবির ওপর মাউস নিলে বা জুম বাটনে ক্লিক করলে এইচডি (HD) জুম করে কাপড়ের কোয়ালিটি ও ডিজাইন স্পষ্টভাবে দেখতে পারবে।
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextState = currentBusiness.productImageZoomEnabled === false;
                  updateBusiness({ productImageZoomEnabled: nextState });
                  showToast(
                    nextState
                      ? 'প্রোডাক্ট ছবি এইচডি জুম (HD Image Zoom) গ্লোবালি চালু (ON) করা হয়েছে!'
                      : 'প্রোডাক্ট ছবি জুম সিস্টেম গ্লোবালি বন্ধ (OFF) করা হয়েছে!',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  currentBusiness.productImageZoomEnabled !== false
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {currentBusiness.productImageZoomEnabled !== false
                    ? '🔍 ছবি জুম চালু (ON) — বন্ধ করতে ক্লিক করুন'
                    : 'ছবি জুম বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                </span>
              </button>
            </div>

            {/* 1-Click Global Product SKU Code Visibility (প্রোডাক্ট ছবির নিচে SKU কোড প্রদর্শন) ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-slate-50 rounded-xl p-4 border border-slate-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-extrabold text-slate-900">
                  প্রোডাক্ট ছবির নিচে SKU কোড প্রদর্শন (Product Page SKU Code Show / Hide)
                </p>
                <p className="text-[11px] text-slate-600">
                  ডিফল্টভাবে কাস্টমারদের সুবিধার্থে প্রোডাক্ট পেজে ছবির নিচে থাকা <span className="font-bold text-slate-800">SKU কোড</span> হাইড (OFF) রাখা হয়েছে যাতে পেজটি একদম ক্লিন দেখায়। প্রয়োজনে ১-ক্লিকে চালু বা বন্ধ করতে পারবেন।
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextState = !Boolean(currentBusiness.showProductSkuOnStorefront);
                  updateBusiness({ showProductSkuOnStorefront: nextState });
                  showToast(
                    nextState
                      ? 'প্রোডাক্ট পেজে ছবির নিচে SKU কোড প্রদর্শন চালু (ON) করা হয়েছে!'
                      : 'প্রোডাক্ট পেজে ছবির নিচে SKU কোড হাইড (OFF) করা হয়েছে!',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  Boolean(currentBusiness.showProductSkuOnStorefront)
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {Boolean(currentBusiness.showProductSkuOnStorefront)
                    ? 'SKU কোড চালু (ON) — হাইড করতে ক্লিক করুন'
                    : 'SKU কোড হাইড (OFF) — চালু করতে ক্লিক করুন'}
                </span>
              </button>
            </div>

            {/* 1-Click Header Cart Button Border Beam Animation (লোগোর পাশের কার্ট বাটনে Border Beam অ্যানিমেশন) ON/OFF Switcher */}
            <div className="sm:col-span-2 bg-emerald-50/70 rounded-xl p-4 border border-emerald-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-extrabold text-slate-900">
                  লোগোর পাশের শপিং ব্যাগ (Cart) বাটনে Border Beam অ্যানিমেশন (ON / OFF)
                </p>
                <p className="text-[11px] text-slate-600">
                  চালু (ON) থাকলে ওয়েবসাইটের হেডারে লোগোর পাশে থাকা সবুজ শপিং ব্যাগ (Cart) বাটনের চারপাশ ঘিরে সাদা আলোর রেখা (Border Beam) রাউন্ড হয়ে ঘুরবে। যেকোনো সময় ১-ক্লিকে চালু বা বন্ধ করতে পারবেন।
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextState = currentBusiness.cartBorderBeamEnabled === false;
                  updateBusiness({ cartBorderBeamEnabled: nextState });
                  showToast(
                    nextState
                      ? 'শপিং ব্যাগ (Cart) বাটনে Border Beam অ্যানিমেশন চালু (ON) করা হয়েছে!'
                      : 'শপিং ব্যাগ (Cart) বাটনের অ্যানিমেশন বন্ধ (OFF) করা হয়েছে!',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  currentBusiness.cartBorderBeamEnabled !== false
                    ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {currentBusiness.cartBorderBeamEnabled !== false
                    ? '✨ কার্ট অ্যানিমেশন চালু (ON) — বন্ধ করতে ক্লিক করুন'
                    : 'কার্ট অ্যানিমেশন বন্ধ (OFF) — চালু করতে ক্লিক করুন'}
                </span>
              </button>
            </div>

            {/* Website Color Theme Switcher (10 Color Themes including Cool Blue & Classic Emerald Default) */}
            <div className="sm:col-span-2 bg-gradient-to-br from-emerald-50/70 via-white to-indigo-50/60 rounded-xl p-4 border-2 border-emerald-300/90 space-y-3 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <label className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>
                      Website Color Theme Switcher (Cool Blue এবং Classic Emerald সহ ১০টি কালার প্রিসেট)
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Click any theme below to change the live website colors (header bar, buttons, badges, price highlights). Choose <strong>Cool Blue (উইন্টার ছাড়া কুল ব্লু)</strong> to use the exact Winter Cool Blue color palette all year round without snow or winter icons.
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-700 text-white text-[11px] font-extrabold self-start sm:self-center shrink-0">
                  Active: {(currentBusiness.storefrontTheme || storefrontTheme || 'emerald_default').replace('_', ' ').toUpperCase()}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {[
                  {
                    id: 'emerald_default' as StorefrontThemeStyle,
                    title: '1. Classic Emerald (Current Default)',
                    desc: 'Original deep emerald green & warm gold theme',
                    primaryHex: '#059669',
                    topbarHex: '#064e3b',
                    badgeHex: '#d97706'
                  },
                  {
                    id: 'cool_blue' as StorefrontThemeStyle,
                    title: '💎 2. Cool Blue (উইন্টার ছাড়া কুল ব্লু)',
                    desc: 'উইন্টার থিমের হুবহু একই Cool Blue কালার প্রিসেট (তুষারপাত বা উইন্টার আইকন ছাড়া)',
                    primaryHex: '#0284c7',
                    topbarHex: '#082f49',
                    badgeHex: '#38bdf8'
                  },
                  {
                    id: 'winter_frost' as StorefrontThemeStyle,
                    title: '❄️ Winter Frost (Cool Blue & Snow)',
                    desc: 'Cool icy blues, snowy whites & winter frost accents',
                    primaryHex: '#0284c7',
                    topbarHex: '#082f49',
                    badgeHex: '#38bdf8'
                  },
                  {
                    id: 'summer_mango' as StorefrontThemeStyle,
                    title: '☀️ Summer Sunshine & Mango (সামার থিম)',
                    desc: 'গ্রীষ্মকালীন উজ্জ্বল ম্যাঙ্গো গোল্ড, সানশাইন অরেঞ্জ ও সামার ভাইব (☀️🌴✨)',
                    primaryHex: '#ea580c',
                    topbarHex: '#9a3412',
                    badgeHex: '#f59e0b'
                  },
                  {
                    id: 'ramadan_noor' as StorefrontThemeStyle,
                    title: '🌙 Ramadan Noor & Royal Gold (রমজান থিম)',
                    desc: 'পবিত্র মাহে রমজানের রয়্যাল অ্যারাবিয়ান টিল ও নূরানী গোল্ড থিম (🌙🏮✨)',
                    primaryHex: '#0d9488',
                    topbarHex: '#042f2e',
                    badgeHex: '#d97706'
                  },
                  {
                    id: 'eid_festive' as StorefrontThemeStyle,
                    title: '🕌 Eid Mubarak & Festive Vacation (ঈদ ভ্যাকেশন থিম)',
                    desc: 'ঈদ উৎসবের রয়্যাল ফেস্টিভ ম্যাজেন্টা, ভেলভেট পার্পল ও গোল্ডেন আনন্দ (🌙🕌🎉)',
                    primaryHex: '#9333ea',
                    topbarHex: '#4a044e',
                    badgeHex: '#f59e0b'
                  },
                  {
                    id: 'royal_crimson' as StorefrontThemeStyle,
                    title: '3. Royal Crimson Red',
                    desc: 'High-converting vibrant crimson red fashion theme',
                    primaryHex: '#e11d48',
                    topbarHex: '#881337',
                    badgeHex: '#be123c'
                  },
                  {
                    id: 'ocean_indigo' as StorefrontThemeStyle,
                    title: '4. Ocean Sapphire Blue',
                    desc: 'Clean modern sapphire blue & deep navy accents',
                    primaryHex: '#2563eb',
                    topbarHex: '#1e3a8a',
                    badgeHex: '#1d4ed8'
                  },
                  {
                    id: 'royal_purple' as StorefrontThemeStyle,
                    title: '5. Royal Velvet Purple',
                    desc: 'Elegant boutique violet & deep plum palette',
                    primaryHex: '#7c3aed',
                    topbarHex: '#4c1d95',
                    badgeHex: '#6d28d9'
                  },
                  {
                    id: 'sunset_coral' as StorefrontThemeStyle,
                    title: '6. Sunset Coral Orange',
                    desc: 'Energetic warm coral orange & festive retail look',
                    primaryHex: '#ea580c',
                    topbarHex: '#7c2d12',
                    badgeHex: '#c2410c'
                  },
                  {
                    id: 'rose_magenta' as StorefrontThemeStyle,
                    title: '7. Rose Pink & Baby Boutique',
                    desc: 'Soft rose magenta ideal for kids & fashion stores',
                    primaryHex: '#db2777',
                    topbarHex: '#831843',
                    badgeHex: '#be185d'
                  },
                  {
                    id: 'coffee_bronze' as StorefrontThemeStyle,
                    title: '8. Warm Coffee & Bronze Gold',
                    desc: 'Earth-toned luxury bronze & rich espresso brown',
                    primaryHex: '#b45309',
                    topbarHex: '#451a03',
                    badgeHex: '#92400e'
                  },
                  {
                    id: 'luxury_midnight' as StorefrontThemeStyle,
                    title: '9. Luxury Midnight & Gold',
                    desc: 'Executive dark slate charcoal with royal gold accents',
                    primaryHex: '#0f172a',
                    topbarHex: '#020617',
                    badgeHex: '#d97706'
                  }
                ].map(t => {
                  const active =
                    (Boolean(currentBusiness.winterThemeEnabled)
                      ? 'winter_frost'
                      : currentBusiness.storefrontTheme || storefrontTheme || 'emerald_default') === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        const isSeasonalAnimated =
                          t.id === 'winter_frost' ||
                          t.id === 'summer_mango' ||
                          t.id === 'ramadan_noor' ||
                          t.id === 'eid_festive';
                        setStorefrontTheme(t.id);
                        updateBusiness({
                          storefrontTheme: t.id,
                          winterThemeEnabled: t.id === 'winter_frost',
                          winterSnowfallEnabled: isSeasonalAnimated
                        });
                        showToast(`Storefront color theme set to "${t.title}"!`, 'success');
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                        active
                          ? 'bg-emerald-50/90 border-2 border-emerald-700 shadow-2xs ring-2 ring-emerald-500/20'
                          : 'bg-white border-slate-200 hover:border-slate-400'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1.5">
                          <span className="font-extrabold text-xs text-slate-900">{t.title}</span>
                          {active && (
                            <span className="px-1.5 py-0.5 rounded bg-emerald-700 text-white text-[9px] font-extrabold shrink-0">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">{t.desc}</p>
                      </div>

                      {/* Color Swatch Preview Bar */}
                      <div className="flex items-center gap-1.5 pt-1">
                        <span
                          className="h-5 flex-1 rounded-md border border-black/10"
                          style={{ backgroundColor: t.topbarHex }}
                          title="Topbar Color"
                        />
                        <span
                          className="h-5 flex-1 rounded-md border border-black/10"
                          style={{ backgroundColor: t.primaryHex }}
                          title="Primary Button Color"
                        />
                        <span
                          className="h-5 w-8 rounded-md border border-black/10"
                          style={{ backgroundColor: t.badgeHex }}
                          title="Accent Color"
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>


            {/* NEW: Separate Mobile & Computer Font Size Controller for Front Website, Landing Pages & Home Page Product Name */}
            <div className="sm:col-span-2 bg-gradient-to-br from-blue-50/70 via-white to-emerald-50/60 rounded-xl p-4 sm:p-5 border-2 border-blue-300/90 space-y-4 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-blue-200/70">
                <div>
                  <label className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Type className="w-4 h-4 text-blue-700" />
                    <span>
                      Font Size Controller — Separate Mobile & Computer Settings (Front Website & Landing Pages)
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Adjust text sizes smaller or larger independently for <strong>Mobile View</strong> and <strong>Computer (Desktop) View</strong> across your Front Website and Landing Pages without breaking page layout.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({
                      storefrontMobileFontSizeScale: 100,
                      storefrontDesktopFontSizeScale: 100,
                      landingMobileFontSizeScale: 100,
                      landingDesktopFontSizeScale: 100,
                      homeProductTitleMobilePx: 13,
                      homeProductTitleDesktopPx: 14,
                      homeProductTitleExtraBold: true
                    });
                    showToast('All Mobile & Computer font sizes reset to 100% default!', 'info');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-[11px] font-extrabold cursor-pointer shrink-0 self-start sm:self-center shadow-2xs"
                >
                  ↺ Reset All to Default (100%)
                </button>
              </div>

              {/* 1. Front Website (Storefront): Mobile vs Computer Font Size */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* Storefront MOBILE Font Size */}
                <div className="bg-white rounded-xl p-3.5 border border-blue-200/90 shadow-2xs space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-extrabold text-slate-900 block">
                        📱 1A. Front Website — Mobile Font Size
                      </span>
                      <span className="text-[10px] text-slate-500">
                        Applies only on Mobile screens (&lt; 768px) on main website
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-blue-600 text-white font-mono text-xs font-extrabold shrink-0">
                      {currentBusiness.storefrontMobileFontSizeScale || 100}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.storefrontMobileFontSizeScale) || 100;
                        const next = Math.max(80, cur - 5);
                        updateBusiness({ storefrontMobileFontSizeScale: next });
                        showToast(`Front Website Mobile Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-900 font-extrabold text-xs border border-slate-300 cursor-pointer"
                    >
                      A- (ছোট -5%)
                    </button>
                    <input
                      type="range"
                      min={80}
                      max={135}
                      step={5}
                      value={currentBusiness.storefrontMobileFontSizeScale || 100}
                      onChange={e => {
                        updateBusiness({ storefrontMobileFontSizeScale: Number(e.target.value) });
                      }}
                      className="flex-1 accent-blue-600 cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.storefrontMobileFontSizeScale) || 100;
                        const next = Math.min(135, cur + 5);
                        updateBusiness({ storefrontMobileFontSizeScale: next });
                        showToast(`Front Website Mobile Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs cursor-pointer"
                    >
                      A+ (বড় +5%)
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {[85, 90, 95, 100, 105, 110, 115, 120, 125].map(pct => {
                      const isSel = (currentBusiness.storefrontMobileFontSizeScale || 100) === pct;
                      return (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => {
                            updateBusiness({ storefrontMobileFontSizeScale: pct });
                            showToast(`Front Website Mobile Font Size set to ${pct}%`, 'success');
                          }}
                          className={`px-2 py-1 rounded-lg text-[10px] font-mono font-extrabold border cursor-pointer transition-all ${
                            isSel
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-blue-50'
                          }`}
                        >
                          {pct === 100 ? '100% (Default)' : `${pct}%`}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Storefront COMPUTER / DESKTOP Font Size */}
                <div className="bg-white rounded-xl p-3.5 border border-indigo-200/90 shadow-2xs space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-extrabold text-slate-900 block">
                        💻 1B. Front Website — Computer Font Size
                      </span>
                      <span className="text-[10px] text-slate-500">
                        Applies only on Computer / Desktop screens (&ge; 768px) on main website
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-mono text-xs font-extrabold shrink-0">
                      {currentBusiness.storefrontDesktopFontSizeScale || 100}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.storefrontDesktopFontSizeScale) || 100;
                        const next = Math.max(80, cur - 5);
                        updateBusiness({ storefrontDesktopFontSizeScale: next });
                        showToast(`Front Website Computer Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-900 font-extrabold text-xs border border-slate-300 cursor-pointer"
                    >
                      A- (ছোট -5%)
                    </button>
                    <input
                      type="range"
                      min={80}
                      max={135}
                      step={5}
                      value={currentBusiness.storefrontDesktopFontSizeScale || 100}
                      onChange={e => {
                        updateBusiness({ storefrontDesktopFontSizeScale: Number(e.target.value) });
                      }}
                      className="flex-1 accent-indigo-600 cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.storefrontDesktopFontSizeScale) || 100;
                        const next = Math.min(135, cur + 5);
                        updateBusiness({ storefrontDesktopFontSizeScale: next });
                        showToast(`Front Website Computer Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs cursor-pointer"
                    >
                      A+ (বড় +5%)
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {[85, 90, 95, 100, 105, 110, 115, 120, 125].map(pct => {
                      const isSel = (currentBusiness.storefrontDesktopFontSizeScale || 100) === pct;
                      return (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => {
                            updateBusiness({ storefrontDesktopFontSizeScale: pct });
                            showToast(`Front Website Computer Font Size set to ${pct}%`, 'success');
                          }}
                          className={`px-2 py-1 rounded-lg text-[10px] font-mono font-extrabold border cursor-pointer transition-all ${
                            isSel
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-indigo-50'
                          }`}
                        >
                          {pct === 100 ? '100% (Default)' : `${pct}%`}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 2. Landing Pages: Mobile vs Computer Font Size */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* Landing Page MOBILE Font Size */}
                <div className="bg-white rounded-xl p-3.5 border border-emerald-200/90 shadow-2xs space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-extrabold text-slate-900 block">
                        📱 2A. Landing Page — Mobile Font Size
                      </span>
                      <span className="text-[10px] text-slate-500">
                        Applies only on Mobile screens (&lt; 768px) on all Landing Pages
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-700 text-white font-mono text-xs font-extrabold shrink-0">
                      {currentBusiness.landingMobileFontSizeScale || 100}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.landingMobileFontSizeScale) || 100;
                        const next = Math.max(80, cur - 5);
                        updateBusiness({ landingMobileFontSizeScale: next });
                        showToast(`Landing Page Mobile Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-900 font-extrabold text-xs border border-slate-300 cursor-pointer"
                    >
                      A- (ছোট -5%)
                    </button>
                    <input
                      type="range"
                      min={80}
                      max={135}
                      step={5}
                      value={currentBusiness.landingMobileFontSizeScale || 100}
                      onChange={e => {
                        updateBusiness({ landingMobileFontSizeScale: Number(e.target.value) });
                      }}
                      className="flex-1 accent-emerald-700 cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.landingMobileFontSizeScale) || 100;
                        const next = Math.min(135, cur + 5);
                        updateBusiness({ landingMobileFontSizeScale: next });
                        showToast(`Landing Page Mobile Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs cursor-pointer"
                    >
                      A+ (বড় +5%)
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {[85, 90, 95, 100, 105, 110, 115, 120, 125].map(pct => {
                      const isSel = (currentBusiness.landingMobileFontSizeScale || 100) === pct;
                      return (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => {
                            updateBusiness({ landingMobileFontSizeScale: pct });
                            showToast(`Landing Page Mobile Font Size set to ${pct}%`, 'success');
                          }}
                          className={`px-2 py-1 rounded-lg text-[10px] font-mono font-extrabold border cursor-pointer transition-all ${
                            isSel
                              ? 'bg-emerald-700 text-white border-emerald-700'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50'
                          }`}
                        >
                          {pct === 100 ? '100% (Default)' : `${pct}%`}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Landing Page COMPUTER / DESKTOP Font Size */}
                <div className="bg-white rounded-xl p-3.5 border border-teal-200/90 shadow-2xs space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-extrabold text-slate-900 block">
                        💻 2B. Landing Page — Computer Font Size
                      </span>
                      <span className="text-[10px] text-slate-500">
                        Applies only on Computer / Desktop screens (&ge; 768px) on all Landing Pages
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-teal-700 text-white font-mono text-xs font-extrabold shrink-0">
                      {currentBusiness.landingDesktopFontSizeScale || 100}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.landingDesktopFontSizeScale) || 100;
                        const next = Math.max(80, cur - 5);
                        updateBusiness({ landingDesktopFontSizeScale: next });
                        showToast(`Landing Page Computer Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-900 font-extrabold text-xs border border-slate-300 cursor-pointer"
                    >
                      A- (ছোট -5%)
                    </button>
                    <input
                      type="range"
                      min={80}
                      max={135}
                      step={5}
                      value={currentBusiness.landingDesktopFontSizeScale || 100}
                      onChange={e => {
                        updateBusiness({ landingDesktopFontSizeScale: Number(e.target.value) });
                      }}
                      className="flex-1 accent-teal-700 cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const cur = Number(currentBusiness.landingDesktopFontSizeScale) || 100;
                        const next = Math.min(135, cur + 5);
                        updateBusiness({ landingDesktopFontSizeScale: next });
                        showToast(`Landing Page Computer Font Size: ${next}%`, 'success');
                      }}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs cursor-pointer"
                    >
                      A+ (বড় +5%)
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {[85, 90, 95, 100, 105, 110, 115, 120, 125].map(pct => {
                      const isSel = (currentBusiness.landingDesktopFontSizeScale || 100) === pct;
                      return (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => {
                            updateBusiness({ landingDesktopFontSizeScale: pct });
                            showToast(`Landing Page Computer Font Size set to ${pct}%`, 'success');
                          }}
                          className={`px-2 py-1 rounded-lg text-[10px] font-mono font-extrabold border cursor-pointer transition-all ${
                            isSel
                              ? 'bg-teal-700 text-white border-teal-700'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-teal-50'
                          }`}
                        >
                          {pct === 100 ? '100% (Default)' : `${pct}%`}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 3. Home Page Product Card Name Exact Size & Boldness ("হটলাইন" ফন্ট সাইজ স্টাইল) */}
              <div className="bg-amber-50/70 rounded-xl p-3.5 border border-amber-300/90 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      🏷️ 3. Home Page Product Name Font Size & Style (হোমপেজ প্রোডাক্টের নামের সাইজ — মোবাইল ও কম্পিউটার আলাদা)
                    </span>
                    <span className="text-[11px] text-slate-600 block mt-0.5">
                      Mobile Footer-এর <strong>&ldquo;হটলাইন&rdquo;</strong> লেখাটি হলো <strong>13px Extra-Bold (800 Weight, Noto Sans Bengali)</strong>। নিচে ১-ক্লিকে হোমপেজের প্রোডাক্টের নাম সেই সাইজে বা আপনার পছন্দের সাইজে ছোট-বড় করুন:
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const nextExtraBold = currentBusiness.homeProductTitleExtraBold === false;
                      updateBusiness({ homeProductTitleExtraBold: nextExtraBold });
                      showToast(
                        nextExtraBold
                          ? 'Home Page Product Name set to Extra-Bold (800 - হটলাইন স্টাইল)!'
                          : 'Home Page Product Name set to Standard Bold (700)!',
                        'success'
                      );
                    }}
                    className={`min-h-[34px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold border cursor-pointer shrink-0 transition-all ${
                      currentBusiness.homeProductTitleExtraBold !== false
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-2xs'
                        : 'bg-white text-slate-700 border-slate-300'
                    }`}
                  >
                    {currentBusiness.homeProductTitleExtraBold !== false
                      ? '✓ Extra-Bold 800 ("হটলাইন" মোটা স্টাইল ON)'
                      : 'Standard Bold 700 (সাধারণ বোল্ড)'}
                  </button>
                </div>

                {/* Full Name vs 2-Line Clamp Mode Switcher inside Font Section too */}
                <div className="bg-white rounded-xl p-3 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      📝 হোমপেজ ও রিলেটেড প্রোডাক্টে সম্পূর্ণ নাম নাকি ২-লাইন দেখাবেন? (ON / OFF)
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">
                      ১-ক্লিকে প্রোডাক্টের পুরো নাম (Full Name: ON) অথবা ২-লাইনের সংক্ষিপ্ত স্টাইল (2-Line: OFF) বেছে নিন:
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({ showFullProductNameOnCards: true });
                        showToast('প্রোডাক্টের সম্পূর্ণ নাম দেখানো চালু (ON) করা হয়েছে!', 'success');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-all ${
                        Boolean(currentBusiness.showFullProductNameOnCards)
                          ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50'
                      }`}
                    >
                      ✓ সম্পূর্ণ নাম (Full Name: ON)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({ showFullProductNameOnCards: false });
                        showToast('২-লাইনে সংক্ষিপ্ত নাম (2-Line Mode: OFF) চালু করা হয়েছে!', 'info');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-all ${
                        !currentBusiness.showFullProductNameOnCards
                          ? 'bg-slate-800 text-white border-slate-800 shadow-2xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      ✓ ২-লাইন সংক্ষিপ্ত (2-Line: OFF)
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Mobile Product Name Size */}
                  <div className="bg-white rounded-xl p-3 border border-amber-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold text-slate-800">
                        📱 Mobile Product Name Size:
                      </span>
                      <span className="font-mono text-xs font-extrabold text-amber-800">
                        {currentBusiness.homeProductTitleMobilePx || 13}px
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { px: 12, label: '12px (আগের সাইজ)' },
                        { px: 13, label: '13px (হটলাইন সাইজ ★)' },
                        { px: 14, label: '14px (মিডিয়াম বড়)' },
                        { px: 15, label: '15px (বড়)' },
                        { px: 16, label: '16px (অনেক বড়)' }
                      ].map(opt => {
                        const isSel = (currentBusiness.homeProductTitleMobilePx || 13) === opt.px;
                        return (
                          <button
                            key={opt.px}
                            type="button"
                            onClick={() => {
                              updateBusiness({ homeProductTitleMobilePx: opt.px });
                              showToast(`Mobile Home Product Name size set to ${opt.px}px!`, 'success');
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                              isSel
                                ? 'bg-emerald-700 text-white border-emerald-700'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Computer Product Name Size */}
                  <div className="bg-white rounded-xl p-3 border border-amber-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold text-slate-800">
                        💻 Computer Product Name Size:
                      </span>
                      <span className="font-mono text-xs font-extrabold text-amber-800">
                        {currentBusiness.homeProductTitleDesktopPx || 14}px
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { px: 13, label: '13px (হটলাইন সাইজ)' },
                        { px: 14, label: '14px (ডিফল্ট ★)' },
                        { px: 15, label: '15px (মাঝারি বড়)' },
                        { px: 16, label: '16px (বড়)' },
                        { px: 18, label: '18px (অনেক বড়)' }
                      ].map(opt => {
                        const isSel = (currentBusiness.homeProductTitleDesktopPx || 14) === opt.px;
                        return (
                          <button
                            key={opt.px}
                            type="button"
                            onClick={() => {
                              updateBusiness({ homeProductTitleDesktopPx: opt.px });
                              showToast(`Computer Home Product Name size set to ${opt.px}px!`, 'success');
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                              isSel
                                ? 'bg-emerald-700 text-white border-emerald-700'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* English Number & Price Font Style Switcher (JetBrains Mono + 2 Clean Premium Fonts) */}
            <div className="sm:col-span-2 bg-emerald-50/40 rounded-xl p-4 border border-emerald-200/80 space-y-2.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Type className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'bn'
                      ? 'ইংরেজি সংখ্যা ও প্রাইস ফন্ট স্টাইল পরিবর্তন করুন (English Number & Price Font)'
                      : 'Select English Number & Price Font Style'}
                  </span>
                </label>
                <span className="text-[11px] font-semibold text-emerald-700">
                  ১-ক্লিকে সম্পূর্ণ ওয়েবসাইটের ইংরেজি নাম্বার ও টাকার ফন্ট পরিবর্তন হবে
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  {
                    id: 'jetbrains_mono',
                    titleBn: 'JetBrains Mono (ডট যুক্ত 0)',
                    badgeBn: 'ডট 0 ফন্ট',
                    descBn: '০ (Zero)-এর ভেতরে বিন্দু/ফোঁটা যুক্ত মডার্ন টেক ও ইনভয়েস ফন্ট',
                    sampleStyle: "'JetBrains Mono', monospace"
                  },
                  {
                    id: 'outfit',
                    titleBn: 'Outfit Premium (ক্লিন গোল 0)',
                    badgeBn: 'প্রিমিয়াম ১',
                    descBn: 'ফোঁটা ছাড়া একদম ক্লিন, রাউন্ডেড ও লাক্সারি ই-কমার্স প্রাইস ফন্ট',
                    sampleStyle: "'Outfit', sans-serif"
                  },
                  {
                    id: 'plus_jakarta_sans',
                    titleBn: 'Plus Jakarta Sans (স্ট্যান্ডার্ড 0)',
                    badgeBn: 'প্রিমিয়াম ২',
                    descBn: 'ফোঁটা ছাড়া ঝকঝকে, পরিষ্কার ও স্ট্যান্ডার্ড আধুনিক কর্পোরেট নাম্বার ফন্ট',
                    sampleStyle: "'Plus Jakarta Sans', sans-serif"
                  }
                ].map((nf) => {
                  const active = (currentBusiness.numberFontStyle || numberFontStyle || 'jetbrains_mono') === nf.id;
                  return (
                    <button
                      key={nf.id}
                      type="button"
                      onClick={() => {
                        setNumberFontStyle(nf.id as any);
                        updateBusiness({ numberFontStyle: nf.id as any });
                        showToast(
                          language === 'bn'
                            ? `ইংরেজি সংখ্যা ও প্রাইস ফন্ট "${nf.titleBn}" সেট করা হয়েছে!`
                            : `English number font updated`
                        );
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        active
                          ? 'bg-emerald-50/95 border-2 border-emerald-600 shadow-2xs'
                          : 'bg-white border-slate-200 hover:border-emerald-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bold text-xs text-slate-900">{nf.titleBn}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold shrink-0 ${
                            active
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {nf.badgeBn}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1">{nf.descBn}</p>
                      <div
                        style={{ fontFamily: nf.sampleStyle }}
                        className="mt-2 px-2.5 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-extrabold tracking-wide flex items-center justify-between"
                      >
                        <span>01711-203040</span>
                        <span className="text-amber-300">৳ 1,090</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Footer Developer Credit Operation (E-Commerce Website & Landing Page Footer — ON/OFF + Name + Link) */}
            <div className="sm:col-span-2 bg-slate-50 rounded-xl p-4 border border-slate-200/90 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2.5 border-b border-slate-200/80">
                <div className="space-y-0.5">
                  <label className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <span>
                      {language === 'bn'
                        ? 'ই-কমার্স ওয়েবসাইট ও ল্যান্ডিং পেজ ফুটার ডেভেলপার ক্রেডিট (Developer Credit)'
                        : 'E-Commerce & Landing Page Footer Developer Credit'}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        developerCreditEnabled
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {developerCreditEnabled ? 'ON (চালু)' : 'OFF (বন্ধ)'}
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-500">
                    {language === 'bn'
                      ? 'ওয়েবসাইট এবং ল্যান্ডিং পেজের একদম নিচে ফুটারে ডেভেলপার ক্রেডিট দেখাতে চাইলে ON রাখুন, এবং নাম ও ওয়েবসাইট/প্রোফাইল লিংক পরিবর্তন করুন।'
                      : 'Toggle Developer Credit visibility in Website & Landing Page footers, and customize the Developer Name and Link.'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextVal = !developerCreditEnabled;
                    setDeveloperCreditEnabled(nextVal);
                    updateBusiness({
                      developerCreditEnabled: nextVal,
                      developerCreditName: developerCreditName.trim(),
                      developerCreditLink: developerCreditLink.trim()
                    });
                    showToast(
                      nextVal
                        ? 'ফুটার ডেভেলপার ক্রেডিট চালু (ON) করা হয়েছে!'
                        : 'ফুটার ডেভেলপার ক্রেডিট বন্ধ (OFF) করা হয়েছে!',
                      nextVal ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                    developerCreditEnabled
                      ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {developerCreditEnabled
                      ? 'ডেভেলপার ক্রেডিট চালু আছে (ON)'
                      : 'ডেভেলপার ক্রেডিট বন্ধ আছে (OFF)'}
                  </span>
                </button>
              </div>

              {developerCreditEnabled && (
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                  <div className="sm:col-span-5">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      ডেভেলপারের নাম (Developer Name):
                    </label>
                    <input
                      type="text"
                      value={developerCreditName}
                      onChange={(e) => {
                        setDeveloperCreditName(e.target.value);
                      }}
                      placeholder="যেমন: Web Studio BD / আপনার নাম"
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 focus:border-emerald-600 rounded-lg text-xs font-bold text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-5">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      ডেভেলপার লিংক (Website / Facebook URL):
                    </label>
                    <input
                      type="text"
                      value={developerCreditLink}
                      onChange={(e) => {
                        setDeveloperCreditLink(e.target.value);
                      }}
                      placeholder="https://yourwebsite.com বা facebook.com/..."
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 focus:border-emerald-600 rounded-lg text-xs font-mono text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({
                          developerCreditEnabled,
                          developerCreditName: developerCreditName.trim(),
                          developerCreditLink: developerCreditLink.trim()
                        });
                        showToast(
                          'ডেভেলপার ক্রেডিট নাম ও লিংক ওয়েবসাইট এবং ল্যান্ডিং পেজে আপডেট হয়েছে!',
                          'success'
                        );
                      }}
                      className="w-full min-h-[38px] px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>আপডেট করুন</span>
                    </button>
                  </div>

                  {/* Live Preview of Footer Developer Credit */}
                  <div className="sm:col-span-12 px-3.5 py-2.5 rounded-lg bg-white border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="text-[11px] font-semibold text-slate-400">
                      ফুটার প্রিভিউ (Live Preview):
                    </span>
                    <p className="inline-flex items-center gap-1.5 font-medium text-slate-600">
                      <span>Developed by</span>
                      {developerCreditLink.trim() ? (
                        <a
                          href={
                            /^https?:\/\//i.test(developerCreditLink.trim())
                              ? developerCreditLink.trim()
                              : `https://${developerCreditLink.trim()}`
                          }
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-bold text-emerald-700 hover:underline"
                        >
                          {developerCreditName.trim() || 'Developer Name'}
                        </a>
                      ) : (
                        <span className="font-bold text-slate-800">
                          {developerCreditName.trim() || 'Developer Name'}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Global SEO Configuration (Homepage Title, Meta Description & Keywords + Live Google Preview) */}
            <div className="sm:col-span-2 bg-gradient-to-br from-emerald-50/70 via-white to-sky-50/60 rounded-xl p-4 sm:p-5 border-2 border-emerald-200/90 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-emerald-200/70">
                <div className="space-y-0.5">
                  <label className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <Search className="w-4 h-4 text-emerald-700" />
                    <span>
                      {language === 'bn'
                        ? 'গ্লোবাল এসইও সেটিংস (Global SEO — হোমপেজ টাইটেল ও মেটা ডেসক্রিপশন)'
                        : 'Global SEO Settings (Homepage Title & Meta Description)'}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold">
                      Google + Facebook OG
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-600">
                    {language === 'bn'
                      ? 'আপনার মেইন ওয়েবসাইটের (হোম পেজ) ব্রাউজার ট্যাব টাইটেল, গুগল সার্চ স্নিপেট এবং ফেসবুক/হোয়াটসঅ্যাপে লিংক শেয়ার প্রিভিউ এখান থেকে কাস্টমাইজ করুন।'
                      : 'Customize your homepage title, meta description, and keywords for Google Search and Facebook/WhatsApp link shares.'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    updateBusiness({
                      faviconUrl: faviconUrl.trim() || undefined,
                      seoTitle: seoTitle.trim() || undefined,
                      seoDescription: seoDescription.trim() || undefined,
                      seoKeywords: seoKeywords.trim() || undefined,
                      seoOgImageUrl: seoOgImageUrl.trim() || undefined
                    });
                    showToast(
                      language === 'bn'
                        ? 'গ্লোবাল SEO টাইটেল, মেটা ডেসক্রিপশন ও লিংক শেয়ার ব্যানার ইমেজ আপডেট হয়েছে!'
                        : 'Global SEO title, meta description & social share image updated!',
                      'success'
                    );
                  }}
                  className="min-h-[38px] px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'SEO সেভ করুন' : 'Save SEO'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
                <div className="lg:col-span-7 space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-800">
                        {language === 'bn'
                          ? 'হোমপেজ এসইও টাইটেল (Homepage SEO Title)'
                          : 'Homepage SEO Title'}
                      </label>
                      <span className="text-[10px] font-mono text-slate-500">
                        {(seoTitle || `${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} – প্রিমিয়াম ফ্যাশন ও বেবি ড্রেস কালেকশন`).length} / 70 chars
                      </span>
                    </div>
                    <input
                      type="text"
                      value={seoTitle}
                      onChange={(e) => setSeoTitle(e.target.value)}
                      placeholder={`${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} – প্রিমিয়াম ফ্যাশন ও বেবি ড্রেস কালেকশন`}
                      className="w-full min-h-[40px] px-3 py-2 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl text-xs font-bold text-slate-900 outline-hidden"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-800">
                        {language === 'bn'
                          ? 'হোমপেজ মেটা ডেসক্রিপশন (Meta Description)'
                          : 'Homepage Meta Description'}
                      </label>
                      <span className="text-[10px] font-mono text-slate-500">
                        {(seoDescription || '').length} / 160 chars
                      </span>
                    </div>
                    <textarea
                      rows={3}
                      value={seoDescription}
                      onChange={(e) => setSeoDescription(e.target.value)}
                      placeholder={`${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} — প্রিমিয়াম বেবি ফ্রক, পার্টি ড্রেস, পাঞ্জাবি ও ফ্যাশন কালেকশন। সারাদেশে ক্যাশ অন ডেলিভারি সুবিধা।`}
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl text-xs text-slate-800 outline-hidden leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      {language === 'bn'
                        ? 'এসইও কিওয়ার্ডস (SEO Keywords — কমা দিয়ে লিখুন, ঐচ্ছিক)'
                        : 'SEO Keywords (comma-separated, optional)'}
                    </label>
                    <input
                      type="text"
                      value={seoKeywords}
                      onChange={(e) => setSeoKeywords(e.target.value)}
                      placeholder="বেবি ড্রেস, পার্টি ফ্রক, পাঞ্জাবি, অনলাইন শপিং বাংলাদেশ, ক্যাশ অন ডেলিভারি"
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl text-xs text-slate-800 outline-hidden"
                    />
                  </div>

                  {/* Social Share Banner / OG Image Upload Box */}
                  <div className="p-3.5 rounded-xl bg-white border-2 border-emerald-200/90 space-y-2.5 shadow-2xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-emerald-700" />
                          <span>
                            {language === 'bn'
                              ? 'ওয়েবসাইট মেইন লিংক শেয়ার ইমেজ (Social Share / OG Image)'
                              : 'Website Main Link Share Banner (Social OG Image)'}
                          </span>
                        </label>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {language === 'bn'
                            ? 'ফেসবুক, মেসেঞ্জার, হোয়াটসঅ্যাপ বা ইমোতে ওয়েবসাইটের মেইন লিংক শেয়ার করলে সবার কাছে এই ব্যানার ছবিটি বড় হয়ে দেখাবে (রিকমেন্ডেড সাইজ: 1200×630 px)।'
                            : 'This banner image is shown when your main website link is shared on Facebook, Messenger, WhatsApp, or Telegram (Recommended: 1200×630 px).'}
                        </p>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                        1200 × 630 px
                      </span>
                    </div>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                      <div className="w-full sm:w-36 h-20 rounded-lg bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center shrink-0 relative">
                        {seoOgImageUrl || logoUrl ? (
                          <img
                            src={seoOgImageUrl || logoUrl}
                            alt="Social Share Preview"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="flex flex-col items-center justify-center text-slate-400 text-[10px] gap-1">
                            <ImageIcon className="w-5 h-5" />
                            <span>No Banner</span>
                          </div>
                        )}
                        {seoOgImageUrl && (
                          <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-emerald-700/90 text-white text-[9px] font-bold">
                            Custom OG
                          </span>
                        )}
                      </div>

                      <div className="flex-1 space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <label className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer transition-all shadow-2xs">
                            <Upload className="w-3.5 h-3.5" />
                            <span>
                              {isUploadingSeoOgImage
                                ? language === 'bn'
                                  ? 'আপলোড হচ্ছে...'
                                  : 'Uploading...'
                                : language === 'bn'
                                ? 'শেয়ার ব্যানার ইমেজ আপলোড করুন'
                                : 'Upload Share Banner'}
                            </span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleSeoOgImageFileChange}
                              className="hidden"
                              disabled={isUploadingSeoOgImage}
                            />
                          </label>

                          {seoOgImageUrl && (
                            <button
                              type="button"
                              onClick={() => {
                                setSeoOgImageUrl('');
                                updateBusiness({ seoOgImageUrl: '' });
                                showToast(
                                  language === 'bn'
                                    ? 'শেয়ার ব্যানার ইমেজ রিমুভ করা হয়েছে (এখন ডিফল্ট লোগো দেখাবে)'
                                    : 'Share banner removed (falling back to store logo)',
                                  'info'
                                );
                              }}
                              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold inline-flex items-center gap-1 cursor-pointer transition-all"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'রিমুভ' : 'Remove'}</span>
                            </button>
                          )}
                        </div>

                        <input
                          type="text"
                          value={seoOgImageUrl}
                          onChange={(e) => setSeoOgImageUrl(e.target.value)}
                          placeholder={
                            language === 'bn'
                              ? 'অথবা সরাসরি ব্যানার ইমেজের লিংক (Image URL) এখানে পেস্ট করুন...'
                              : 'Or paste direct banner image URL here...'
                          }
                          className="w-full min-h-[34px] px-2.5 py-1 bg-slate-50 border border-slate-200 focus:border-emerald-600 focus:bg-white rounded-lg text-[11px] text-slate-700 outline-hidden font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Live Google Search, Browser Tab & Facebook/WhatsApp Link Share Preview */}
                <div className="lg:col-span-5 bg-white rounded-xl p-4 border border-slate-200/90 shadow-2xs space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold text-slate-700 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>
                        {language === 'bn'
                          ? 'ফেসবুক/হোয়াটসঅ্যাপ ও গুগল লাইভ প্রিভিউ'
                          : 'Social Share & Google Live Preview'}
                      </span>
                    </span>
                    <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold">
                      Live
                    </span>
                  </div>

                  {/* Simulated Facebook / Messenger / WhatsApp Link Share Card */}
                  <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100/80 shadow-2xs">
                    <div className="px-2.5 py-1.5 bg-slate-200/70 flex items-center justify-between text-[10px] font-bold text-slate-600">
                      <span>Facebook / Messenger / WhatsApp Share</span>
                      <span className="text-emerald-700">OG Card</span>
                    </div>
                    <div className="aspect-[1.91/1] w-full bg-slate-200 relative overflow-hidden flex items-center justify-center">
                      {seoOgImageUrl || logoUrl ? (
                        <img
                          src={seoOgImageUrl || logoUrl}
                          alt="Social Link Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-slate-400 text-xs gap-1">
                          <Globe className="w-7 h-7 text-slate-400" />
                          <span>No Share Image Uploaded</span>
                        </div>
                      )}
                    </div>
                    <div className="p-2.5 bg-[#f0f2f5] border-t border-slate-200 space-y-0.5">
                      <div className="text-[10px] font-mono uppercase text-slate-500 truncate">
                        {typeof window !== 'undefined'
                          ? window.location.hostname
                          : 'yourstore.com'}
                      </div>
                      <div className="text-xs font-extrabold text-slate-900 line-clamp-1">
                        {seoTitle.trim() ||
                          `${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} – প্রিমিয়াম ফ্যাশন ও বেবি ড্রেস কালেকশন`}
                      </div>
                      <p className="text-[11px] text-slate-600 line-clamp-2 leading-snug">
                        {seoDescription.trim() ||
                          `${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} — প্রিমিয়াম বেবি ফ্রক, পার্টি ড্রেস, পাঞ্জাবি ও ফ্যাশন কালেকশন। সারাদেশে ক্যাশ অন ডেলিভারি সুবিধা।`}
                      </p>
                    </div>
                  </div>

                  {/* Simulated Browser Tab */}
                  <div className="bg-slate-100 p-2 rounded-lg border border-slate-200">
                    <div className="bg-white rounded-md px-2.5 py-1.5 flex items-center gap-2 shadow-2xs max-w-[260px]">
                      {faviconUrl || logoUrl ? (
                        <img
                          src={faviconUrl || logoUrl}
                          alt="Tab Icon"
                          className="w-4 h-4 object-contain rounded-xs shrink-0"
                        />
                      ) : (
                        <Globe className="w-4 h-4 text-emerald-700 shrink-0" />
                      )}
                      <span className="text-[11px] font-semibold text-slate-800 truncate">
                        {seoTitle.trim() ||
                          `${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} – প্রিমিয়াম ফ্যাশন ও বেবি ড্রেস কালেকশন`}
                      </span>
                    </div>
                  </div>

                  {/* Simulated Google SERP Result */}
                  <div className="p-3 rounded-lg bg-slate-50/70 border border-slate-200/80 space-y-1">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-white border border-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                        {faviconUrl || logoUrl ? (
                          <img
                            src={faviconUrl || logoUrl}
                            alt="Site Icon"
                            className="w-4 h-4 object-contain"
                          />
                        ) : (
                          <Globe className="w-3.5 h-3.5 text-slate-500" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="text-[11px] font-bold text-slate-800 truncate">
                          {bizName.replace('স্টকমাস্টার বিডি - ', '').trim()}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate font-mono">
                          {typeof window !== 'undefined' ? window.location.origin : 'https://yourstore.com'}
                        </div>
                      </div>
                    </div>
                    <div className="text-sm font-bold text-[#1a0dab] hover:underline line-clamp-1 pt-0.5">
                      {seoTitle.trim() ||
                        `${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} – প্রিমিয়াম ফ্যাশন ও বেবি ড্রেস কালেকশন`}
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {seoDescription.trim() ||
                        `${bizName.replace('স্টকমাস্টার বিডি - ', '').trim()} — প্রিমিয়াম বেবি ফ্রক, পার্টি ড্রেস, পাঞ্জাবি ও ফ্যাশন কালেকশন। ১-১২ বছরের বেবি ড্রেস ও সকল সাইজ ভেরিয়েশনে সারাদেশে ক্যাশ অন ডেলিভারি সুবিধা।`}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Organization Form */}
        <form onSubmit={handleSaveSettings} className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Building2 className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">
              {language === 'bn' ? 'প্রতিষ্ঠানের মৌলিক তথ্য (ইনভয়েস ও ওয়েবসাইট হেডার)' : 'Organization Details'}
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'প্রতিষ্ঠানের নাম (বাংলা)' : 'Business Name (Bangla)'}
              </label>
              <input
                type="text"
                value={bizName}
                onChange={e => setBizName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'প্রতিষ্ঠানের নাম (ইংরেজি)' : 'Business Name (English)'}
              </label>
              <input
                type="text"
                value={bizNameEn}
                onChange={e => setBizNameEn(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'ট্যাক্স আইডি (BIN / TIN)' : 'Tax ID (BIN / TIN)'}
              </label>
              <input
                type="text"
                value={taxId}
                onChange={e => setTaxId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'হটলাইন / মোবাইল নম্বর' : 'Phone Number'}
              </label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'প্রধান কার্যালয়ের ঠিকানা' : 'Head Office Address'}
              </label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'ডিফল্ট ভ্যাট হার (%)' : 'Default VAT Rate (%)'}
              </label>
              <input
                type="number"
                step="0.5"
                value={vatRate}
                onChange={e => setVatRate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'bn' ? 'ইনভয়েস প্রিফিক্স' : 'Invoice Prefix'}
              </label>
              <input
                type="text"
                value={invoicePrefix}
                onChange={e => setInvoicePrefix(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{language === 'bn' ? 'তথ্য সংরক্ষণ করুন' : 'Save Changes'}</span>
            </button>
          </div>
        </form>

        {/* Outlets List */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Store className="w-4 h-4 text-emerald-600" />
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {language === 'bn' ? 'শাখা ও গুদাম তালিকা' : 'Branches & Warehouses'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  {language === 'bn'
                    ? 'নতুন শাখা/গুদাম যোগ করুন অথবা নাম ও ঠিকানা পরিবর্তন করুন'
                    : 'Add, rename or edit branches & warehouses'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={openAddOutletModal}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'নতুন যোগ করুন' : 'Add New'}</span>
            </button>
          </div>
          <div className="space-y-3">
            {outlets.map(o => {
              const typeMeta = outletTypeLabels[o.type] || outletTypeLabels.retail_shop;
              return (
                <div
                  key={o.id}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 text-sm truncate">{o.name}</p>
                      <span
                        className={`inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 rounded border ${typeMeta.badge}`}
                      >
                        {language === 'bn' ? typeMeta.bn : typeMeta.en}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => openEditOutletModal(o)}
                        className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-blue-700 border border-slate-200 hover:border-blue-300 font-semibold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                        title={language === 'bn' ? 'নাম ও তথ্য পরিবর্তন করুন' : 'Edit / Rename'}
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>{language === 'bn' ? 'এডিট / নাম পরিবর্তন' : 'Edit'}</span>
                      </button>
                      {outlets.length > 1 && (
                        <button
                          type="button"
                          onClick={() => deleteOutlet(o.id)}
                          className="p-1.5 rounded-lg bg-white hover:bg-rose-50 text-rose-600 border border-slate-200 hover:border-rose-200 transition-colors cursor-pointer"
                          title={language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-slate-600 mt-2">{o.address}</p>
                  <p className="text-slate-500 font-mono mt-0.5">{o.phone}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* SMART SMS SYSTEM: Dual Gateway (GreenWeb & Alpha SMS) + 1-Click Auto-Notification Toggles + Template Editor */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-[#0f172a] to-[#06342e] text-white p-5 sm:p-6 border-b border-slate-800">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 flex items-center justify-center shrink-0">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                    স্মার্ট SMS সিস্টেম ও অটো-নোটিফিকেশন কন্ট্রোল প্যানেল
                  </h3>
                  <span
                    className={`px-2.5 py-0.5 rounded-md text-[11px] font-extrabold ${
                      smsEnabled
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-rose-500/90 text-white'
                    }`}
                  >
                    {smsEnabled ? 'মাস্টার SMS চালু (ACTIVE)' : 'মাস্টার SMS বন্ধ (PAUSED)'}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-md bg-white/10 border border-white/15 text-teal-200 text-[11px] font-bold">
                    গেটওয়ে: {smsProvider === 'greenweb' ? 'GreenWeb SMS (bdbulksms.net)' : 'Alpha SMS (sms.net.bd)'}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  Alpha SMS অথবা GreenWeb SMS — যেকোনো একটি গেটওয়ে বেছে নিন এবং নতুন অর্ডার (কাস্টমার ও অ্যাডমিন), ফরগেট পাসওয়ার্ড ও স্ট্যাটাস মেসেজ ১-ক্লিকে ON / OFF করুন
                </p>
              </div>
            </div>

            {/* Master SMS System ON/OFF Switch + Live Balance */}
            <div className="flex flex-wrap items-center gap-2.5">
              {smsBalance !== null && (
                <div className="px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 font-mono font-extrabold text-xs tabular-nums">
                  ব্যালেন্স: {smsProvider === 'alpha' ? `৳${smsBalance}` : smsBalance}
                  {smsExpiry ? ` (${smsExpiry})` : ''}
                </div>
              )}
              <button
                type="button"
                disabled={isCheckingBalance}
                onClick={handleCheckSmsBalance}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 disabled:opacity-50 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isCheckingBalance ? 'animate-spin' : ''}`} />
                <span>ব্যালেন্স চেক</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const next = !smsEnabled;
                  setSmsEnabled(next);
                  updateBusiness({ smsEnabled: next });
                  showToast(
                    next
                      ? 'সম্পূর্ণ SMS সিস্টেম চালু (ON) করা হয়েছে!'
                      : 'সম্পূর্ণ SMS সিস্টেম সাময়িকভাবে বন্ধ (OFF) করা হয়েছে!',
                    next ? 'success' : 'info'
                  );
                }}
                className={`px-4 py-2 rounded-xl font-extrabold text-xs inline-flex items-center gap-2 cursor-pointer transition-all ${
                  smsEnabled
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-xs'
                    : 'bg-rose-600 hover:bg-rose-500 text-white'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{smsEnabled ? 'মাস্টার SMS: ON' : 'মাস্টার SMS: OFF'}</span>
              </button>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-6">
          {/* STEP 1: Gateway Selector (GreenWeb vs Alpha SMS) & API Credential Setup */}
          <form
            onSubmit={handleSaveDeveloperSmsApi}
            className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-emerald-700" />
                  <span>১. SMS গেটওয়ে নির্বাচন ও API কানেকশন (Alpha SMS অথবা GreenWeb)</span>
                </h4>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  আপনার পছন্দমতো যেকোনো একটি গেটওয়ে সিলেক্ট করে Token বা API Key বসিয়ে সেভ করুন
                </p>
              </div>

              {/* 1-Click Gateway Switcher Tabs */}
              <div className="inline-flex p-1 rounded-xl bg-slate-200/80 border border-slate-300/80 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => {
                    setSmsProvider('greenweb');
                    setSmsBalance(null);
                    setSmsExpiry(null);
                    updateBusiness({ smsProvider: 'greenweb' });
                    showToast('GreenWeb SMS (bdbulksms.net) গেটওয়ে সিলেক্ট করা হয়েছে', 'info');
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                    smsProvider === 'greenweb'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  <span>GreenWeb SMS</span>
                  <span className="text-[10px] opacity-85 font-mono">(bdbulksms)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSmsProvider('alpha');
                    setSmsBalance(null);
                    setSmsExpiry(null);
                    updateBusiness({ smsProvider: 'alpha' });
                    showToast('Alpha SMS (api.sms.net.bd) গেটওয়ে সিলেক্ট করা হয়েছে', 'info');
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                    smsProvider === 'alpha'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  <span>Alpha SMS</span>
                  <span className="text-[10px] opacity-85 font-mono">(sms.net.bd)</span>
                </button>
              </div>
            </div>

            {smsProvider === 'greenweb' ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end text-xs">
                <div className="lg:col-span-9">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-extrabold text-slate-800">
                      GreenWeb SMS API Token (<span className="font-mono text-emerald-700">token</span>) *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowSmsSecret(prev => !prev)}
                      className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                    >
                      {showSmsSecret ? 'টোকেন লুকান (Hide)' : 'টোকেন দেখুন (Show)'}
                    </button>
                  </div>
                  <input
                    type={showSmsSecret ? 'text' : 'password'}
                    value={greenwebToken}
                    onChange={(e) => setGreenwebToken(e.target.value)}
                    placeholder="আপনার GreenWeb (sms.greenweb.com.bd / bdbulksms.net) এর API Token এখানে বসান"
                    className="w-full min-h-[42px] px-3.5 py-2.5 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl font-mono text-slate-900 outline-hidden"
                  />
                  <p className="text-[11px] text-slate-500 mt-1.5 font-mono break-all">
                    Endpoint: https://api.bdbulksms.net/api.php?json (GreenWeb অফিসিয়াল JSON API)
                  </p>
                </div>

                <div className="lg:col-span-3">
                  <button
                    type="submit"
                    className="w-full min-h-[42px] py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-2xs text-xs"
                  >
                    <Save className="w-4 h-4" />
                    <span>GreenWeb টোকেন সেভ করুন</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3.5 text-xs">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-end">
                  <div className="lg:col-span-5">
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="font-extrabold text-slate-800">
                        Alpha SMS API Key (<span className="font-mono text-emerald-700">api_key</span>) *
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowSmsSecret(prev => !prev)}
                        className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                      >
                        {showSmsSecret ? 'কি লুকান (Hide)' : 'কি দেখুন (Show)'}
                      </button>
                    </div>
                    <input
                      type={showSmsSecret ? 'text' : 'password'}
                      value={smsApiKey}
                      onChange={(e) => setSmsApiKey(e.target.value)}
                      placeholder="আপনার api.sms.net.bd এর API KEY এখানে বসান"
                      className="w-full min-h-[42px] px-3.5 py-2.5 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl font-mono text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="lg:col-span-2">
                    <label className="block font-bold text-slate-700 mb-1.5">
                      Sender ID (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      value={smsSenderId}
                      onChange={(e) => setSmsSenderId(e.target.value)}
                      placeholder="Sender ID"
                      className="w-full min-h-[42px] px-3 py-2 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl font-mono text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="lg:col-span-2">
                    <label className="block font-bold text-slate-700 mb-1.5">
                      Content ID (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      value={smsContentId}
                      onChange={(e) => setSmsContentId(e.target.value)}
                      placeholder="Content ID"
                      className="w-full min-h-[42px] px-3 py-2 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl font-mono text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="lg:col-span-3">
                    <button
                      type="submit"
                      className="w-full min-h-[42px] py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                    >
                      <Save className="w-4 h-4" />
                      <span>Alpha API সেভ করুন</span>
                    </button>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 font-mono break-all">
                  Endpoint: https://api.sms.net.bd/sendsms (Alpha SMS অফিসিয়াল API)
                </p>
              </div>
            )}
          </form>

          {/* STEP 2: Granular 1-Click ON/OFF Notification Controls */}
          <div className="space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                  <Bell className="w-4 h-4 text-emerald-700" />
                  <span>২. স্মার্ট অটো-নোটিফিকেশন কন্ট্রোল (যেকোনো ফিচার ১-ক্লিকে ON / OFF করুন)</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  কোন কোন ইভেন্টে অটোমেটিক SMS যাবে তা আপনার প্রয়োজন অনুযায়ী চালু বা বন্ধ রাখুন
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Toggle 1: New Order -> Customer SMS ON/OFF */}
              <div
                className={`p-4 rounded-xl border-2 transition-all flex flex-col justify-between gap-3 ${
                  smsOrderConfirmationEnabled
                    ? 'bg-emerald-50/60 border-emerald-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                        ১. নতুন অর্ডারে কাস্টমারের কাছে SMS
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                          smsOrderConfirmationEnabled
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-300 text-slate-800'
                        }`}
                      >
                        {smsOrderConfirmationEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      নতুন অর্ডার প্লেস হলে কাস্টমারের মোবাইলে অর্ডার নম্বর ও মোট বিলের কনফার্মেশন মেসেজ যাবে।
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !smsOrderConfirmationEnabled;
                      setSmsOrderConfirmationEnabled(next);
                      updateBusiness({ smsOrderConfirmationEnabled: next });
                      showToast(
                        next
                          ? 'নতুন অর্ডারে কাস্টমার কনফার্মেশন SMS চালু (ON) করা হয়েছে!'
                          : 'নতুন অর্ডারে কাস্টমার কনফার্মেশন SMS বন্ধ (OFF) করা হয়েছে!',
                        'success'
                      );
                    }}
                    className={`px-3.5 py-2 rounded-xl font-extrabold text-xs shrink-0 cursor-pointer transition-all ${
                      smsOrderConfirmationEnabled
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-800 hover:bg-slate-900 text-white'
                    }`}
                  >
                    {smsOrderConfirmationEnabled ? 'Turn OFF' : 'Turn ON'}
                  </button>
                </div>
              </div>

              {/* Toggle 2: New Order -> Admin SMS Alert ON/OFF + Admin Phone Input */}
              <div
                className={`p-4 rounded-xl border-2 transition-all flex flex-col justify-between gap-3 ${
                  smsAdminOrderAlertEnabled
                    ? 'bg-emerald-50/60 border-emerald-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                        ২. নতুন অর্ডারে অ্যাডমিন SMS নোটিফিকেশন
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                          smsAdminOrderAlertEnabled
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-300 text-slate-800'
                        }`}
                      >
                        {smsAdminOrderAlertEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      ওয়েবসাইটে নতুন অর্ডার আসলেই সাথে সাথে অ্যাডমিনের মোবাইল নম্বরে কাস্টমারের নাম, ফোন ও অর্ডারের তথ্য সহ এলার্ট যাবে।
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !smsAdminOrderAlertEnabled;
                      const targetPhone = smsAdminOrderAlertPhone.trim() || phone.trim();
                      setSmsAdminOrderAlertEnabled(next);
                      updateBusiness({
                        smsAdminOrderAlertEnabled: next,
                        smsAdminOrderAlertPhone: targetPhone
                      });
                      showToast(
                        next
                          ? `অ্যাডমিন অর্ডার এলার্ট SMS চালু (ON) করা হয়েছে (${targetPhone})!`
                          : 'অ্যাডমিন অর্ডার এলার্ট SMS বন্ধ (OFF) করা হয়েছে!',
                        'success'
                      );
                    }}
                    className={`px-3.5 py-2 rounded-xl font-extrabold text-xs shrink-0 cursor-pointer transition-all ${
                      smsAdminOrderAlertEnabled
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-800 hover:bg-slate-900 text-white'
                    }`}
                  >
                    {smsAdminOrderAlertEnabled ? 'Turn OFF' : 'Turn ON'}
                  </button>
                </div>

                {/* Admin Alert Phone Number Input */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={smsAdminOrderAlertPhone}
                    onChange={(e) => setSmsAdminOrderAlertPhone(e.target.value)}
                    placeholder="অ্যাডমিন মোবাইল নম্বর (যেমন: 017XXXXXXXX)"
                    className="flex-1 px-3 py-1.5 bg-white border border-slate-300 focus:border-emerald-600 rounded-lg font-mono text-xs text-slate-900 tabular-nums outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const clean = smsAdminOrderAlertPhone.trim() || phone.trim();
                      setSmsAdminOrderAlertPhone(clean);
                      updateBusiness({ smsAdminOrderAlertPhone: clean });
                      showToast(`অ্যাডমিন নোটিফিকেশন নম্বর (${clean}) সংরক্ষিত হয়েছে!`, 'success');
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-[11px] font-bold cursor-pointer shrink-0"
                  >
                    নম্বর সেভ
                  </button>
                </div>
              </div>

              {/* Toggle 3: Forgot Password OTP SMS ON/OFF */}
              <div
                className={`p-4 rounded-xl border-2 transition-all flex flex-col justify-between gap-3 ${
                  smsForgotPasswordOtpEnabled
                    ? 'bg-emerald-50/60 border-emerald-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                        ৩. ফরগেট পাসওয়ার্ড (Forget Password OTP) SMS
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                          smsForgotPasswordOtpEnabled
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-300 text-slate-800'
                        }`}
                      >
                        {smsForgotPasswordOtpEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      চালু থাকলে কাস্টমার পাসওয়ার্ড ভুলে গেলে মোবাইলে OTP কোড পাঠিয়ে রিসেট করতে পারবে। বন্ধ করলে ফরগেট SMS অপশন অফ থাকবে।
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !smsForgotPasswordOtpEnabled;
                      setSmsForgotPasswordOtpEnabled(next);
                      updateBusiness({ smsForgotPasswordOtpEnabled: next });
                      showToast(
                        next
                          ? 'পাসওয়ার্ড ফরগেট OTP SMS চালু (ON) করা হয়েছে!'
                          : 'পাসওয়ার্ড ফরগেট OTP SMS বন্ধ (OFF) করা হয়েছে!',
                        'success'
                      );
                    }}
                    className={`px-3.5 py-2 rounded-xl font-extrabold text-xs shrink-0 cursor-pointer transition-all ${
                      smsForgotPasswordOtpEnabled
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-800 hover:bg-slate-900 text-white'
                    }`}
                  >
                    {smsForgotPasswordOtpEnabled ? 'Turn OFF' : 'Turn ON'}
                  </button>
                </div>
              </div>

              {/* Toggle 4: Order Status Update Customer SMS ON/OFF */}
              <div
                className={`p-4 rounded-xl border-2 transition-all flex flex-col justify-between gap-3 ${
                  smsOrderStatusUpdateEnabled
                    ? 'bg-emerald-50/60 border-emerald-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                        ৪. অর্ডার স্ট্যাটাস পরিবর্তন কাস্টমার SMS
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                          smsOrderStatusUpdateEnabled
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-300 text-slate-800'
                        }`}
                      >
                        {smsOrderStatusUpdateEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      অ্যাডমিন অর্ডার কনফার্ম, ডিসপ্যাচ বা ডেলিভারি সম্পন্ন করলে কাস্টমারের কাছে অটোমেটিক স্ট্যাটাস আপডেট SMS যাবে।
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !smsOrderStatusUpdateEnabled;
                      setSmsOrderStatusUpdateEnabled(next);
                      updateBusiness({ smsOrderStatusUpdateEnabled: next });
                      showToast(
                        next
                          ? 'অর্ডার স্ট্যাটাস আপডেট SMS চালু (ON) করা হয়েছে!'
                          : 'অর্ডার স্ট্যাটাস আপডেট SMS বন্ধ (OFF) করা হয়েছে!',
                        'success'
                      );
                    }}
                    className={`px-3.5 py-2 rounded-xl font-extrabold text-xs shrink-0 cursor-pointer transition-all ${
                      smsOrderStatusUpdateEnabled
                        ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                        : 'bg-slate-800 hover:bg-slate-900 text-white'
                    }`}
                  >
                    {smsOrderStatusUpdateEnabled ? 'Turn OFF' : 'Turn ON'}
                  </button>
                </div>
              </div>
            </div>

            {/* Toggle 5: Customer Signup OTP Verification ON/OFF */}
            <div
              className={`p-4 rounded-xl border-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                signupOtpRequired
                  ? 'bg-emerald-50/60 border-emerald-400'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Shield className={`w-4 h-4 ${signupOtpRequired ? 'text-emerald-700' : 'text-slate-500'}`} />
                  <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                    ৫. কাস্টমার সাইনআপে মোবাইল OTP ভেরিফিকেশন (Signup OTP Verification)
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                      signupOtpRequired
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-300 text-slate-800'
                    }`}
                  >
                    {signupOtpRequired ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600">
                  {signupOtpRequired
                    ? 'চালু থাকলে নতুন কাস্টমার একাউন্ট খোলার সময় মোবাইল নম্বরে ৪-ডিজিটের OTP কোড যাবে এবং কোড ভেরিফাই করেই সাইনআপ সম্পন্ন হবে।'
                    : 'বন্ধ থাকলে কাস্টমার কোনো OTP কোড ছাড়াই সরাসরি এক ক্লিকে একাউন্ট খুলতে পারবে।'}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  const nextVal = !signupOtpRequired;
                  setSignupOtpRequired(nextVal);
                  updateBusiness({ signupOtpRequired: nextVal });
                  showToast(
                    nextVal
                      ? 'কাস্টমার সাইনআপে OTP ভেরিফিকেশন চালু (ON) করা হয়েছে!'
                      : 'কাস্টমার সাইনআপে OTP ভেরিফিকেশন বন্ধ (OFF) করা হয়েছে!',
                    'success'
                  );
                }}
                className={`px-3.5 py-2 rounded-xl font-extrabold text-xs shrink-0 cursor-pointer transition-all ${
                  signupOtpRequired
                    ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    : 'bg-slate-800 hover:bg-slate-900 text-white'
                }`}
              >
                {signupOtpRequired ? 'Turn OFF' : 'Turn ON'}
              </button>
            </div>
          </div>

          {/* STEP 3: Editable SMS Message Templates with Live Preview */}
          <form onSubmit={handleSaveSmsTemplates} className="space-y-4 pt-2 border-t border-slate-200">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-emerald-700" />
                  <span>৩. অটোমেটিক SMS মেসেজের ফরম্যাট ও টেমপ্লেট এডিটর</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  কাস্টমার ও অ্যাডমিনের কাছে কোন ভাষায় ও কোন ফরম্যাটে মেসেজ যাবে তা নিজের মতো সাজিয়ে নিন
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setSmsOrderPlacedTemplate(DEFAULT_SMS_TEMPLATES.orderPlaced);
                  setSmsAdminOrderAlertTemplate(DEFAULT_SMS_TEMPLATES.adminOrderAlert);
                  setSmsOrderStatusTemplate(DEFAULT_SMS_TEMPLATES.orderStatus);
                  setSmsOtpTemplate(DEFAULT_SMS_TEMPLATES.otpReset);
                  setSmsSignupOtpTemplate(DEFAULT_SMS_TEMPLATES.signupOtp);
                  showToast('ডিফল্ট মেসেজ ফরম্যাট রিস্টোর করা হয়েছে', 'info');
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                ডিফল্ট ফরম্যাট রিসেট
              </button>
            </div>

            {/* Dynamic Variable Tags Guide */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs space-y-1.5">
              <p className="font-bold text-slate-700">
                মেসেজে ব্যবহারযোগ্য ডাইনামিক শর্টকোড (অটোমেটিক তথ্য বসবে):
              </p>
              <div className="flex flex-wrap gap-1.5 font-mono text-[11px]">
                {[
                  { tag: '{name}', label: 'কাস্টমারের নাম' },
                  { tag: '{phone}', label: 'কাস্টমারের মোবাইল' },
                  { tag: '{order_no}', label: 'অর্ডার নম্বর' },
                  { tag: '{invoice_no}', label: 'ইনভয়েস নম্বর' },
                  { tag: '{total}', label: 'মোট বিল' },
                  { tag: '{address}', label: 'ঠিকানা' },
                  { tag: '{items}', label: 'পণ্যের তালিকা' },
                  { tag: '{status}', label: 'অর্ডার স্ট্যাটাস' },
                  { tag: '{otp}', label: 'OTP কোড' },
                  { tag: '{shop_name}', label: 'দোকানের নাম' }
                ].map(item => (
                  <span
                    key={item.tag}
                    className="px-2 py-0.5 rounded bg-white border border-slate-200 text-emerald-800 font-bold"
                  >
                    {item.tag} <span className="font-sans font-normal text-slate-500">= {item.label}</span>
                  </span>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
              {/* 1. Customer Order Placed SMS Template */}
              <div className="space-y-1.5">
                <label className="block font-bold text-slate-800">
                  ১. নতুন অর্ডার কনফার্মেশন SMS ফরম্যাট (কাস্টমারের জন্য)
                </label>
                <textarea
                  rows={3}
                  value={smsOrderPlacedTemplate}
                  onChange={(e) => setSmsOrderPlacedTemplate(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
                />
                <p className="text-[11px] text-slate-500 bg-emerald-50/60 p-2 rounded-lg border border-emerald-100">
                  <strong>প্রিভিউ:</strong>{' '}
                  {formatSmsMessage(smsOrderPlacedTemplate, {
                    name: 'রহিম উদ্দিন',
                    order_no: 'ORD-20261024-4512',
                    invoice_no: 'SMB-WEB-4512',
                    total: 850,
                    status: 'অর্ডার গৃহীত',
                    shop_name: currentBusiness.name
                  })}
                </p>
              </div>

              {/* 2. Admin New Order Notification SMS Template */}
              <div className="space-y-1.5">
                <label className="block font-bold text-slate-800">
                  ২. নতুন অর্ডার অ্যাডমিন এলার্ট SMS ফরম্যাট (অ্যাডমিনের জন্য)
                </label>
                <textarea
                  rows={3}
                  value={smsAdminOrderAlertTemplate}
                  onChange={(e) => setSmsAdminOrderAlertTemplate(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
                />
                <p className="text-[11px] text-slate-500 bg-emerald-50/60 p-2 rounded-lg border border-emerald-100">
                  <strong>প্রিভিউ:</strong>{' '}
                  {formatSmsMessage(smsAdminOrderAlertTemplate, {
                    name: 'রহিম উদ্দিন',
                    phone: '01712345678',
                    order_no: 'ORD-20261024-4512',
                    total: 850,
                    address: 'মিরপুর ১০, ঢাকা',
                    items: 'হুডি x1',
                    shop_name: currentBusiness.name
                  })}
                </p>
              </div>

              {/* 3. Order Status Update SMS Template */}
              <div className="space-y-1.5">
                <label className="block font-bold text-slate-800">
                  ৩. অর্ডার স্ট্যাটাস পরিবর্তন SMS ফরম্যাট
                </label>
                <textarea
                  rows={3}
                  value={smsOrderStatusTemplate}
                  onChange={(e) => setSmsOrderStatusTemplate(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
                />
                <p className="text-[11px] text-slate-500 bg-emerald-50/60 p-2 rounded-lg border border-emerald-100">
                  <strong>প্রিভিউ:</strong>{' '}
                  {formatSmsMessage(smsOrderStatusTemplate, {
                    name: 'রহিম উদ্দিন',
                    order_no: 'ORD-20261024-4512',
                    total: 850,
                    status: 'ডেলিভারির পথে (Dispatched)',
                    shop_name: currentBusiness.name
                  })}
                </p>
              </div>

              {/* 4. Forgot Password OTP SMS Template */}
              <div className="space-y-1.5">
                <label className="block font-bold text-slate-800">
                  ৪. পাসওয়ার্ড ফরগেট (OTP) SMS ফরম্যাট
                </label>
                <textarea
                  rows={3}
                  value={smsOtpTemplate}
                  onChange={(e) => setSmsOtpTemplate(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
                />
                <p className="text-[11px] text-slate-500 bg-emerald-50/60 p-2 rounded-lg border border-emerald-100">
                  <strong>প্রিভিউ:</strong>{' '}
                  {formatSmsMessage(smsOtpTemplate, {
                    name: 'রহিম উদ্দিন',
                    otp: '4829',
                    shop_name: currentBusiness.name
                  })}
                </p>
              </div>

              {/* 5. Customer Signup OTP SMS Template */}
              <div className="space-y-1.5 lg:col-span-2">
                <label className="block font-bold text-slate-800">
                  ৫. কাস্টমার সাইনআপ ভেরিফিকেশন (OTP) SMS ফরম্যাট
                </label>
                <textarea
                  rows={2}
                  value={smsSignupOtpTemplate}
                  onChange={(e) => setSmsSignupOtpTemplate(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden"
                />
                <p className="text-[11px] text-slate-500 bg-emerald-50/60 p-2 rounded-lg border border-emerald-100">
                  <strong>প্রিভিউ:</strong>{' '}
                  {formatSmsMessage(smsSignupOtpTemplate, {
                    name: 'রহিম উদ্দিন',
                    otp: '7391',
                    shop_name: currentBusiness.name
                  })}
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl text-xs flex items-center gap-2 shadow-2xs cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>সকল SMS সেটিংস ও মেসেজ ফরম্যাট সংরক্ষণ করুন</span>
              </button>
            </div>
          </form>

          {/* STEP 4: Quick Test SMS & Live SMS Activity Log */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 pt-3 border-t border-slate-200 text-xs">
            <form
              onSubmit={handleSendTestSms}
              className="lg:col-span-6 p-4 rounded-xl bg-slate-50 border border-slate-200/90 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Send className="w-3.5 h-3.5 text-emerald-700" />
                  <span>৪. ওয়ান-ক্লিক টেস্ট SMS পাঠান ({smsProvider === 'greenweb' ? 'GreenWeb' : 'Alpha SMS'})</span>
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    প্রাপকের মোবাইল নম্বর *
                  </label>
                  <input
                    type="text"
                    value={testSmsTo}
                    onChange={(e) => setTestSmsTo(e.target.value)}
                    placeholder="017XXXXXXXX"
                    className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl font-mono text-slate-900 tabular-nums outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    শিডিউল (ঐচ্ছিক - শুধুমাত্র Alpha SMS)
                  </label>
                  <input
                    type="text"
                    value={testSmsSchedule}
                    onChange={(e) => setTestSmsSchedule(e.target.value)}
                    placeholder="YYYY-MM-DD HH:MM:SS"
                    disabled={smsProvider === 'greenweb'}
                    className="w-full px-3 py-2 bg-white disabled:bg-slate-100 border border-slate-300 rounded-xl font-mono text-slate-900 outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  টেস্ট মেসেজ বডি *
                </label>
                <input
                  type="text"
                  value={testSmsMsg}
                  onChange={(e) => setTestSmsMsg(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-emerald-600 rounded-xl text-slate-900 outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={isSendingTestSms}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSendingTestSms ? 'SMS পাঠানো হচ্ছে...' : 'টেস্ট SMS পাঠিয়ে চেক করুন'}</span>
              </button>
            </form>

            {/* Right: Recent Sent SMS Logs & Alpha Report Checker */}
            <div className="lg:col-span-6 p-4 rounded-xl bg-slate-50 border border-slate-200/90 space-y-3 flex flex-col justify-between">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-emerald-700" />
                    <span>সাম্প্রতিক পাঠানো SMS লগ ({smsLogs.length})</span>
                  </span>
                  {smsLogs.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        clearSmsLogs();
                        setSmsLogs([]);
                        showToast('SMS লগ পরিষ্কার করা হয়েছে', 'info');
                      }}
                      className="text-[11px] font-bold text-rose-600 hover:underline cursor-pointer"
                    >
                      লগ মুছুন
                    </button>
                  )}
                </div>

                {smsLogs.length === 0 ? (
                  <div className="p-4 rounded-xl bg-white border border-slate-200 text-center text-slate-400 text-xs">
                    এখনো কোনো টেস্ট বা অটোমেটিক SMS লগ নেই
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                    {smsLogs.slice(0, 6).map(log => (
                      <div
                        key={log.id}
                        className="p-2.5 rounded-lg bg-white border border-slate-200 flex items-center justify-between gap-2 text-[11px]"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 font-mono font-bold text-slate-800 tabular-nums">
                            <span>{log.to}</span>
                            <span
                              className={`px-1.5 py-0.2 rounded text-[9px] font-extrabold uppercase ${
                                log.provider === 'greenweb'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-sky-100 text-sky-800'
                              }`}
                            >
                              {log.provider === 'greenweb' ? 'GreenWeb' : 'Alpha'}
                            </span>
                            <span
                              className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                log.status === 'Success'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : 'bg-rose-50 text-rose-700'
                              }`}
                            >
                              {log.status}
                            </span>
                          </div>
                          <p className="text-slate-500 truncate mt-0.5">{log.msg}</p>
                        </div>

                        {log.provider === 'alpha' && log.requestId && log.requestId !== 'N/A' && (
                          <button
                            type="button"
                            onClick={() => handleCheckSmsReport(log.requestId)}
                            className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[10px] shrink-0 cursor-pointer"
                          >
                            রিপোর্ট
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {smsProvider === 'alpha' && (
                <div className="pt-2 border-t border-slate-200 space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={reportRequestId}
                      onChange={(e) => setReportRequestId(e.target.value)}
                      placeholder="Alpha Request ID দিয়ে ডেলিভারি রিপোর্ট চেক"
                      className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs text-slate-900 outline-hidden"
                    />
                    <button
                      type="button"
                      disabled={isCheckingReport}
                      onClick={() => handleCheckSmsReport()}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg inline-flex items-center gap-1 cursor-pointer text-xs"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>রিপোর্ট</span>
                    </button>
                  </div>
                  {reportResult && (
                    <div className="p-2 rounded-lg bg-slate-900 text-emerald-300 font-mono text-[10px] overflow-x-auto">
                      <pre className="whitespace-pre-wrap">{JSON.stringify(reportResult, null, 2)}</pre>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* DEVELOPER ACCOUNT ONLY: Product Page WhatsApp Order & Call For Order Number Configuration */}
      {currentUser.role === 'developer' && (
        <div className="space-y-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              updateBusiness({
                whatsappOrderPhone: whatsappOrderPhone.trim() || currentBusiness.phone,
                callOrderPhone: callOrderPhone.trim() || currentBusiness.phone
              });
              showToast(
                'প্রোডাক্ট পেজের WhatsApp Order এবং Call For Order নম্বর সফলভাবে সংরক্ষিত হয়েছে!',
                'success'
              );
            }}
            className="bg-gradient-to-br from-slate-900 via-[#0f172a] to-[#062c28] text-white p-5 sm:p-6 rounded-2xl border border-emerald-500/40 shadow-lg space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-700/80">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 flex items-center justify-center shrink-0">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm sm:text-base font-extrabold text-white">
                      প্রোডাক্ট পেজ WhatsApp Order এবং Call For Order নম্বর পরিবর্তন
                    </h3>
                    <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 text-[10px] font-extrabold">
                      DEVELOPER ONLY
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-200/80 mt-0.5">
                    ওয়েবসাইটের প্রতিটি প্রোডাক্ট ডিটেইলস পেজে থাকা <strong className="text-amber-300">WhatsApp Order</strong> এবং <strong className="text-amber-300">Call For Order</strong> বাটনের নম্বর এখান থেকে পরিবর্তন করুন
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end text-xs">
              <div className="md:col-span-5">
                <label className="block font-bold text-emerald-300 mb-1.5">
                  ১. WhatsApp Order নম্বর (হোয়াটসঅ্যাপে অর্ডার নম্বর) *
                </label>
                <input
                  type="text"
                  value={whatsappOrderPhone}
                  onChange={(e) => setWhatsappOrderPhone(e.target.value)}
                  placeholder="যেমন: 01711234567 বা +8801711234567"
                  className="w-full min-h-[42px] px-3.5 py-2.5 bg-slate-900 border border-emerald-500/50 focus:border-emerald-400 rounded-xl font-mono font-bold text-sm text-white outline-hidden"
                />
              </div>

              <div className="md:col-span-4">
                <label className="block font-bold text-amber-300 mb-1.5">
                  ২. Call For Order নম্বর (ডিরেক্ট কল করার নম্বর) *
                </label>
                <input
                  type="text"
                  value={callOrderPhone}
                  onChange={(e) => setCallOrderPhone(e.target.value)}
                  placeholder="যেমন: 01711234567"
                  className="w-full min-h-[42px] px-3.5 py-2.5 bg-slate-900 border border-amber-500/50 focus:border-amber-400 rounded-xl font-mono font-bold text-sm text-white outline-hidden"
                />
              </div>

              <div className="md:col-span-3">
                <button
                  type="submit"
                  className="w-full min-h-[42px] py-2.5 px-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold rounded-xl flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>নম্বর দুটি সেভ করুন</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* DEVELOPER / ADMIN ONLY: Order Edit System Master ON/OFF Permission Control */}
      {(currentUser.role === 'developer' || currentUser.role === 'super_admin') && (
        <div className="bg-gradient-to-br from-slate-900 via-[#0f172a] to-[#1e1b4b] text-white p-5 sm:p-6 rounded-2xl border border-indigo-500/40 shadow-lg space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 flex items-center justify-center shrink-0 mt-0.5">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-sm sm:text-base font-extrabold text-white">
                    ✏️ অর্ডার এডিট সিস্টেম লক কন্ট্রোল (ঠিকানা, নতুন প্রোডাক্ট যোগ, সাইজ ও নাম/বিকল্প নাম্বার পরিবর্তন)
                  </h3>
                  <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 text-[10px] font-extrabold">
                    DEVELOPER / ADMIN CONTROL
                  </span>
                </div>
                <p className="text-[11px] text-indigo-200/85 mt-1 leading-relaxed">
                  এখান থেকে অর্ডার এডিট সিস্টেম <strong className="text-rose-300">বন্ধ (OFF)</strong> করে রাখলে কোনো স্টোর ম্যানেজার বা অন্য স্টাফ অর্ডারের ঠিকানা, প্রোডাক্ট, সাইজ বা নাম্বার পরিবর্তন করতে পারবে না (বাধা তৈরি হবে)। আর <strong className="text-emerald-300">চালু (ON)</strong> থাকলে কাস্টমার কল করলে সহজেই অর্ডার এডিট করা যাবে।
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  updateBusiness({ orderEditEnabled: true });
                  showToast(
                    '✅ অর্ডার এডিট সিস্টেম চালু (ON) করা হয়েছে — এখন অর্ডারের ঠিকানা, প্রোডাক্ট ও নাম পরিবর্তন করা যাবে।',
                    'success'
                  );
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentBusiness.orderEditEnabled !== false
                    ? 'bg-emerald-500 text-slate-950 shadow-md ring-2 ring-emerald-300'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>চালু (ON)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  updateBusiness({ orderEditEnabled: false });
                  showToast(
                    '🔒 অর্ডার এডিট সিস্টেম বন্ধ (OFF) করা হয়েছে — স্টোর ম্যানেজার বা অন্য কেউ আর অর্ডার এডিট করতে পারবে না!',
                    'info'
                  );
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentBusiness.orderEditEnabled === false
                    ? 'bg-rose-600 text-white shadow-md ring-2 ring-rose-300'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                }`}
              >
                <Lock className="w-4 h-4" />
                <span>বন্ধ / লকড (OFF)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Staff Users & Role Permissions */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {language === 'bn'
                  ? 'অ্যাডমিন ও স্টাফ লগইন অ্যাকাউন্ট (Username, Email & Password)'
                  : 'Admin & Staff Accounts (Username, Email & Password)'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {language === 'bn'
                  ? 'অ্যাডমিন লগইনের ইউজারনেম, ইমেইল এবং পাসওয়ার্ড পরিবর্তন করুন অথবা নতুন স্টাফ অ্যাকাউন্ট তৈরি করুন'
                  : 'Manage Admin login username, email & password or create new staff accounts'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => openEditUserModal(currentUser)}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>
                {language === 'bn'
                  ? 'আমার ইউজারনেম / পাসওয়ার্ড পরিবর্তন'
                  : 'Change My Username / Password'}
              </span>
            </button>
            <button
              type="button"
              onClick={openCreateUserModal}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{language === 'bn' ? 'নতুন স্টাফ ইউজার যোগ করুন' : 'Add Staff Account'}</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase">
                <th className="py-3 px-4">{language === 'bn' ? 'নাম' : 'Name'}</th>
                <th className="py-3 px-4">{language === 'bn' ? 'ইউজারনেম (Username)' : 'Username'}</th>
                <th className="py-3 px-4">{language === 'bn' ? 'ইমেইল (Email)' : 'Email'}</th>
                <th className="py-3 px-4">{language === 'bn' ? 'পদবী / রোল' : 'Role'}</th>
                <th className="py-3 px-4 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/70 text-xs">
              {users
                .filter(u => currentUser.role === 'developer' || u.role !== 'developer')
                .map(u => {
                  const isCurrent = u.id === currentUser.id;
                  const rInfo = roleLabels[u.role];
                  const uname = u.username || u.email.split('@')[0] || 'user';
                  return (
                    <tr key={u.id} className={`hover:bg-slate-50/80 ${isCurrent ? 'bg-blue-50/40' : ''}`}>
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-2">
                          <span>{u.name}</span>
                          {isCurrent && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                              {language === 'bn' ? 'বর্তমান সেশন' : 'Active'}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 rounded-md bg-slate-100 border border-slate-200 font-mono font-bold text-slate-800">
                          {uname}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">{u.email}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold text-[11px]">
                          {language === 'bn' ? rInfo.bn : rInfo.en}
                        </span>
                        <p className="text-[10px] text-slate-400 mt-0.5">
                          {language === 'bn' ? rInfo.descBn : rInfo.descEn}
                        </p>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => openEditUserModal(u)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 text-[11px] font-semibold rounded-lg inline-flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>{language === 'bn' ? 'এডিট / পাসওয়ার্ড' : 'Edit / Password'}</span>
                          </button>

                          {!isCurrent && currentUser.role === 'developer' && (
                            <button
                              type="button"
                              onClick={() => quickLogin(u.id)}
                              className="px-2.5 py-1.5 bg-slate-900 hover:bg-blue-600 text-white text-[11px] font-semibold rounded-lg transition-colors cursor-pointer"
                            >
                              {language === 'bn' ? 'প্রবেশ করুন' : 'Switch'}
                            </button>
                          )}

                          {!isCurrent && u.id !== 'usr_01' && (
                            <button
                              type="button"
                              onClick={() => deleteUser(u.id)}
                              className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title={language === 'bn' ? 'মুছে ফেলুন' : 'Delete user'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Staff User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {editingUser
                    ? language === 'bn'
                      ? 'ইউজারনেম, ইমেইল ও পাসওয়ার্ড পরিবর্তন'
                      : 'Update Username, Email & Password'
                    : language === 'bn'
                    ? 'নতুন স্টাফ ইউজার অ্যাকাউন্ট তৈরি'
                    : 'Create Staff Account'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAddUserModal(false);
                  setEditingUser(null);
                }}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'পূর্ণ নাম (Full Name) *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUserName}
                  onChange={e => setNewUserName(e.target.value)}
                  placeholder={language === 'bn' ? 'উদা: আলহাজ্ব আবুল কালাম' : 'e.g. Md. Rafiqul Islam'}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {language === 'bn' ? 'লগইন ইউজারনেম (Username) *' : 'Login Username *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newUserUsername}
                    onChange={e => setNewUserUsername(e.target.value)}
                    placeholder="admin"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {language === 'bn' ? 'লগইন ইমেইল (Email) *' : 'Login Email *'}
                  </label>
                  <input
                    type="email"
                    required
                    value={newUserEmail}
                    onChange={e => setNewUserEmail(e.target.value)}
                    placeholder="owner@stockflowbd.com"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {editingUser
                      ? language === 'bn'
                        ? 'নতুন পাসওয়ার্ড (পরিবর্তন করতে চাইলে দিন)'
                        : 'New Password (optional)'
                      : language === 'bn'
                      ? 'লগইন পাসওয়ার্ড (Password) *'
                      : 'Login Password *'}
                  </label>
                  <input
                    type="password"
                    required={!editingUser}
                    autoComplete="new-password"
                    value={newUserPassword}
                    onChange={e => setNewUserPassword(e.target.value)}
                    placeholder={
                      editingUser
                        ? language === 'bn'
                          ? 'অপরিবর্তিত রাখতে ফাঁকা রাখুন'
                          : 'Leave blank to keep current'
                        : language === 'bn'
                        ? 'নতুন পাসওয়ার্ড লিখুন'
                        : 'Enter new password'
                    }
                    className="w-full px-3 py-2 bg-amber-50/70 border border-amber-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {language === 'bn' ? 'মোবাইল নম্বর' : 'Mobile Number'}
                  </label>
                  <input
                    type="text"
                    value={newUserPhone}
                    onChange={e => setNewUserPhone(e.target.value)}
                    placeholder="01711-XXXXXX"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'ইউজার রোল / পদবী *' : 'User Role *'}
                </label>
                <select
                  value={newUserRole}
                  onChange={e => setNewUserRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-medium text-slate-900"
                >
                  <option value="super_admin">{roleLabels.super_admin.bn}</option>
                  <option value="store_manager">{roleLabels.store_manager.bn}</option>
                  <option value="cashier">{roleLabels.cashier.bn}</option>
                  <option value="distribution_mgr">{roleLabels.distribution_mgr.bn}</option>
                  <option value="sales_rep">{roleLabels.sales_rep.bn}</option>
                  {currentUser.role === 'developer' && (
                    <option value="developer">{roleLabels.developer.bn}</option>
                  )}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  {language === 'bn' ? roleLabels[newUserRole].descBn : roleLabels[newUserRole].descEn}
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'নির্ধারিত শাখা / আউটলেট' : 'Assigned Branch / Outlet'}
                </label>
                <select
                  value={newUserOutletId}
                  onChange={e => setNewUserOutletId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-medium text-slate-900"
                >
                  {outlets.map(o => (
                    <option key={o.id} value={o.id}>
                      {o.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddUserModal(false);
                    setEditingUser(null);
                  }}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold cursor-pointer"
                >
                  {editingUser
                    ? language === 'bn'
                      ? 'পরিবর্তন সেভ করুন'
                      : 'Save Changes'
                    : language === 'bn'
                    ? 'ইউজার তৈরি করুন'
                    : 'Create User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Branch & Warehouse Modal */}
      {showOutletModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-md w-full overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-emerald-600" />
                <h2 className="text-sm font-bold text-slate-900">
                  {editingOutlet
                    ? language === 'bn'
                      ? 'শাখা / গুদামের নাম ও তথ্য পরিবর্তন করুন'
                      : 'Edit / Rename Branch or Warehouse'
                    : language === 'bn'
                    ? 'নতুন শাখা বা গুদাম যোগ করুন'
                    : 'Add New Branch or Warehouse'}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowOutletModal(false);
                  setEditingOutlet(null);
                }}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveOutlet} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'শাখা বা গুদামের নাম *' : 'Branch / Warehouse Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={outletName}
                  onChange={e => setOutletName(e.target.value)}
                  placeholder={
                    language === 'bn'
                      ? 'উদা: মিরপুর-১০ মেইন সুপার শপ বা উত্তরা সেন্ট্রাল গুদাম'
                      : 'e.g. Mirpur-10 Main Super Shop'
                  }
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-semibold focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'শাখা / গুদামের ধরন *' : 'Branch / Warehouse Type *'}
                </label>
                <select
                  value={outletType}
                  onChange={e => setOutletType(e.target.value as Outlet['type'])}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg font-medium text-slate-900 focus:outline-none focus:border-emerald-600"
                >
                  <option value="retail_shop">
                    {language === 'bn' ? 'সুপার শপ / বিক্রয় শাখা (Retail Shop)' : 'Retail Shop Branch'}
                  </option>
                  <option value="central_warehouse">
                    {language === 'bn' ? 'সেন্ট্রাল ওয়্যারহাউজ / মূল গুদাম (Central Warehouse)' : 'Central Warehouse'}
                  </option>
                  <option value="distribution_hub">
                    {language === 'bn' ? 'ডিস্ট্রিবিউশন হাব (Distribution Hub)' : 'Distribution Hub'}
                  </option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'ঠিকানা *' : 'Address *'}
                </label>
                <input
                  type="text"
                  required
                  value={outletAddress}
                  onChange={e => setOutletAddress(e.target.value)}
                  placeholder={language === 'bn' ? 'উদা: প্লট ১২, রোড ৪, মিরপুর-১০, ঢাকা' : 'Address'}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'মোবাইল / যোগাযোগের নম্বর *' : 'Contact Phone *'}
                </label>
                <input
                  type="text"
                  required
                  value={outletPhone}
                  onChange={e => setOutletPhone(e.target.value)}
                  placeholder="01711-XXXXXX"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setShowOutletModal(false);
                    setEditingOutlet(null);
                  }}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>
                    {editingOutlet
                      ? language === 'bn'
                        ? 'পরিবর্তন সংরক্ষণ করুন'
                        : 'Save Changes'
                      : language === 'bn'
                      ? 'শাখা/গুদাম যোগ করুন'
                      : 'Add Branch/Warehouse'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
