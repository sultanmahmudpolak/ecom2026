import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp, normalizeBdPhone, isValidBdPhone11 } from '../context/AppContext';
import {
  Product,
  ProductVariant,
  OnlineOrder,
  SaleItem,
  LandingSizeChartRow,
  LandingReviewItem,
  SpinWheelLead,
  SpinWheelConfig,
  SpinWheelSliceConfig,
  LandingFloatingBtnAnimation,
  ProductPageVariantDesign,
  StockOutBadgeDesign,
  StorefrontThemeStyle,
  OrderCelebrationStyle,
  HomeCategoryBarDesign,
  DailyOrderLimitCheckResult
} from '../types';
import { ProductThumbnail, getProductImageUrl } from './ProductThumbnail';
import { OrderCelebrationOverlay } from './OrderCelebrationOverlay';
import {
  DEFAULT_LANDING_SIZE_CHART_HEADERS,
  DEFAULT_LANDING_SIZE_CHART_ROWS,
  DEFAULT_SOCIAL_PROOF_BUYERS
} from '../utils/landingConstants';
import {
  ShoppingBag,
  Search,
  Plus,
  Minus,
  Trash2,
  Truck,
  CheckCircle2,
  Clock,
  PhoneCall,
  MapPin,
  ShieldCheck,
  ArrowRight,
  ArrowLeft,
  X,
  PackageCheck,
  ChevronLeft,
  ChevronRight,
  Lock,
  Menu,
  Eye,
  EyeOff,
  Flame,
  Home,
  LayoutGrid,
  ShoppingCart,
  User as UserIcon,
  LogOut,
  UserPlus,
  LogIn,
  RotateCcw,
  Edit3,
  KeyRound,
  Share2,
  Copy,
  Sparkles,
  MessageCircle,
  Ruler,
  Star,
  Gift,
  Bell,
  Download,
  Upload,
  ChevronDown,
  Play
} from 'lucide-react';
import { exportToCsv, exportToExcel } from '../config/api';
import {
  DEFAULT_SMS_TEMPLATES,
  formatSmsMessage,
  sendAlphaSms,
  sendBusinessSms,
  hasBusinessSmsConfigured
} from '../utils/smsService';
import {
  trackFacebookEvent,
  saveFbCustomerIdentity,
  getFbCustomerIdentity,
  captureAndPersistFbParams,
  ensureMetaFirstPartyIdentifiers,
  normalizeCustomerDataForMeta,
  extractLocationForMeta,
  generateMetaEventId,
  buildMetaProductCustomData,
  buildMetaOrderItemsCustomData,
  flushFbRetryQueue
} from '../utils/facebookTracking';
import { syncOrderToWordPress, buildVariantSkuCode } from '../utils/wordpressOrderSync';
import {
  processUploadedProductImage
} from '../utils/imageUploader';
import { LazyImage } from './LazyImage';
import { ProductSeoHelmet, getEffectiveProductDescription } from './ProductSeoHelmet';

// Official Original WhatsApp Vector SVG Logo Component
export const WhatsAppOriginalIcon: React.FC<{ className?: string }> = ({
  className = 'w-4 h-4'
}) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    aria-hidden="true"
    className={className}
  >
    <path d="M12.031 2C6.508 2 2.023 6.485 2.023 12.007c0 1.766.461 3.49 1.337 5.01L2 22l5.122-1.343a9.975 9.975 0 0 0 4.906 1.292h.004c5.522 0 10.007-4.485 10.007-10.007 0-2.674-1.041-5.188-2.932-7.079A9.946 9.946 0 0 0 12.031 2Zm0 18.258h-.003a8.295 8.295 0 0 1-4.23-1.158l-.303-.18-3.146.825.84-3.066-.198-.314a8.275 8.275 0 0 1-1.278-4.426c0-4.576 3.723-8.299 8.321-8.299 2.222 0 4.311.866 5.882 2.437a8.266 8.266 0 0 1 2.435 5.884c0 4.577-3.724 8.297-8.32 8.297Zm4.552-6.212c-.249-.125-1.474-.728-1.703-.811-.228-.083-.394-.125-.56.125-.166.249-.644.81-.789.976-.145.166-.291.187-.54.062-.249-.125-1.052-.388-2.004-1.237-.741-.661-1.241-1.477-1.386-1.726-.145-.249-.015-.384.11-.508.112-.112.249-.291.374-.436.125-.145.166-.249.249-.415.083-.166.042-.312-.021-.436-.062-.125-.56-1.35-.768-1.848-.202-.485-.407-.419-.56-.427-.145-.007-.311-.009-.477-.009-.166 0-.436.062-.664.312-.228.249-.872.852-.872 2.077 0 1.225.893 2.409 1.017 2.575.125.166 1.757 2.683 4.257 3.762.595.257 1.059.41 1.421.525.597.19 1.14.163 1.569.099.479-.072 1.474-.603 1.682-1.184.208-.581.208-1.08.145-1.184-.062-.104-.228-.166-.477-.291Z" />
  </svg>
);

// Generate SEO-friendly, zero-reload product URL slug
const slugifyProductText = (text: string): string =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

const buildProductSlug = (product: Product): string => {
  const base = slugifyProductText(product.nameEn || product.sku || product.id);
  return base ? `${base}--${product.id}` : product.id;
};

export const buildProductPath = (product: Product): string => `/product/${buildProductSlug(product)}`;

// Match product from URL path (/product/slug--id or /product/id) or query (?product=...)
export const findProductFromLocation = (
  productsList: Product[],
  pathname: string,
  search: string
): Product | null => {
  if (!productsList || productsList.length === 0) return null;

  let rawToken = '';
  const cleanPath = decodeURIComponent(pathname || '').replace(/\/+$/, '');
  if (cleanPath.startsWith('/product/')) {
    rawToken = cleanPath.slice('/product/'.length).trim();
  } else if (search) {
    const params = new URLSearchParams(search);
    rawToken = (params.get('product') || '').trim();
  }

  if (!rawToken) return null;

  // 1. Check if token has `--<id>` suffix
  if (rawToken.includes('--')) {
    const idPart = rawToken.split('--').pop() || '';
    const byId = productsList.find(p => p.id.toLowerCase() === idPart.toLowerCase());
    if (byId) return byId;
  }

  const lowerToken = rawToken.toLowerCase();
  // 2. Match by exact product ID, SKU, or full slug (excluding dedicated landing page products on main storefront)
  return (
    productsList.find(
      p =>
        !p.isLandingPageProduct &&
        (p.id.toLowerCase() === lowerToken ||
          p.sku.toLowerCase() === lowerToken ||
          buildProductSlug(p).toLowerCase() === lowerToken ||
          slugifyProductText(p.nameEn) === lowerToken)
    ) || null
  );
};

interface EcommerceStorefrontViewProps {
  onNavigateToErp: () => void;
}

interface CartEntry {
  cartKey: string;
  product: Product;
  variant?: ProductVariant;
  quantity: number;
}

interface StorefrontCustomerAccount {
  id: string;
  name: string;
  phone: string;
  address: string;
  password: string;
  createdAt: string;
}

const DELIVERY_SLOTS = [
  'এক্সপ্রেস ৬০ মিনিট ডেলিভারি (Express 60 Min)',
  'আজ সকাল ৯:০০ - দুপুর ১:০০',
  'আজ দুপুর ২:০০ - সন্ধ্যা ৬:০০',
  'আজ সন্ধ্যা ৬:০০ - রাত ১০:০০'
];

export const DEFAULT_SPIN_WHEEL_SLICES: SpinWheelSliceConfig[] = [
  {
    id: 'sw_50',
    label: '৳৫০ ডিসকাউন্ট',
    shortLabel: '৳৫০ ছাড়',
    type: 'flat',
    value: 50,
    color: '#e11d48',
    code: 'SPIN50',
    locked: false
  },
  {
    id: 'sw_free_del',
    label: 'ফ্রি ডেলিভারি',
    shortLabel: 'ফ্রি ডেলিভারি',
    type: 'free_delivery',
    value: 0,
    color: '#059669',
    code: 'FREEDEL',
    locked: false
  },
  {
    id: 'sw_30',
    label: '৳৩০ ডিসকাউন্ট',
    shortLabel: '৳৩০ ছাড়',
    type: 'flat',
    value: 30,
    color: '#d97706',
    code: 'SPIN30',
    locked: false
  },
  {
    id: 'sw_5pct',
    label: '৫% স্পেশাল ছাড়',
    shortLabel: '৫% ছাড়',
    type: 'percent',
    value: 5,
    color: '#7c3aed',
    code: 'SPIN5P',
    locked: true
  },
  {
    id: 'sw_100',
    label: '৳১০০ মেগা ছাড়',
    shortLabel: '৳১০০ ছাড়',
    type: 'flat',
    value: 100,
    color: '#ea580c',
    code: 'MEGA100',
    locked: true
  },
  {
    id: 'sw_20',
    label: '৳২০ ক্যাশব্যাক ছাড়',
    shortLabel: '৳২০ ছাড়',
    type: 'flat',
    value: 20,
    color: '#0284c7',
    code: 'SPIN20',
    locked: false
  }
];

export const DEFAULT_SPIN_WHEEL_CONFIG: Required<SpinWheelConfig> = {
  badgeText: 'স্পেশাল লাকি ডিসকাউন্ট হুইল',
  titleText: 'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
  subtitleText: 'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
  claimButtonText: 'অফারটি গ্রহণ করে অর্ডার করুন',
  autoPopupDelaySec: 4,
  cooldownDays: 7,
  slices: DEFAULT_SPIN_WHEEL_SLICES
};

// Calculate regular MRP price: uses admin-configured regularPrice from Dashboard if present,
// or falls back to default demo MRP if regularPrice has not been configured yet.
const getRegularMrpFromRetail = (
  retail: number,
  explicitRegularPrice?: number,
  explicitDiscountPrice?: number
): number => {
  if (explicitRegularPrice !== undefined && explicitRegularPrice > 0) {
    // If admin explicitly set discountPrice === 0 (no discount), return retail so no crossed-out price is shown
    if (explicitDiscountPrice === 0) return retail;
    return Math.max(explicitRegularPrice, retail);
  }
  if (retail >= 1000) return Math.round(retail + 80);
  if (retail >= 500) return Math.round(retail + 40);
  if (retail >= 150) return Math.round(retail + 15);
  return Math.round(retail + 5);
};

// Smart Marketing Scarcity Helper: Shows a realistic low-stock count (5–11 pcs) on the storefront
// to boost Facebook Ad conversion urgency, while actual backend warehouse stock remains high for bulk orders!
const getMarketingUrgencyStock = (product: Product, actualStock: number): number => {
  if (actualStock <= 0) return 0;
  if (actualStock <= 9) return actualStock;
  let hash = 0;
  const seed = `${product.id}_${product.sku}`;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return 5 + (hash % 7); // Deterministically returns 5 to 11 pieces
};

const toBanglaDigitsStatic = (val: number | string, pad = 2): string => {
  const str = String(val).padStart(pad, '0');
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/\d/g, d => bnDigits[Number(d)] || d);
};

interface StorefrontCountdownDigitsProps {
  businessId: string;
  effectiveInitialHours: number;
  effectiveInitialMinutes: number;
  effectiveInitialSeconds: number;
  globalInitialDurationSec: number;
  globalResetSeed: number;
}

const StorefrontCountdownDigits = React.memo<StorefrontCountdownDigitsProps>(
  ({
    businessId,
    effectiveInitialHours,
    effectiveInitialMinutes,
    effectiveInitialSeconds,
    globalInitialDurationSec,
    globalResetSeed
  }) => {
    const [remainingSeconds, setRemainingSeconds] = useState<number>(globalInitialDurationSec);

    useEffect(() => {
      const storageKey = `sf_global_offer_timer_v2_${businessId}_${effectiveInitialHours}_${effectiveInitialMinutes}_${effectiveInitialSeconds}_${globalResetSeed}`;

      const createRealisticLoopDuration = (): number => {
        const randMin = Math.floor(21 + Math.random() * 26);
        const randSec = Math.floor(13 + Math.random() * 41);
        return Math.max(180, effectiveInitialHours * 3600 + randMin * 60 + randSec);
      };

      const getOrInitTimerState = (now: number): { startMs: number; durationSec: number } => {
        try {
          const raw = window.localStorage.getItem(storageKey);
          if (raw) {
            const parsed = JSON.parse(raw);
            const startMs = Number(parsed?.startMs);
            const durationSec = Number(parsed?.durationSec);
            if (
              !Number.isNaN(startMs) &&
              !Number.isNaN(durationSec) &&
              startMs > 0 &&
              startMs <= now &&
              durationSec >= 60
            ) {
              const elapsed = Math.floor((now - startMs) / 1000);
              if (elapsed >= 0 && elapsed < durationSec) {
                return { startMs, durationSec };
              }
              const nextState = {
                startMs: now,
                durationSec: createRealisticLoopDuration()
              };
              window.localStorage.setItem(storageKey, JSON.stringify(nextState));
              return nextState;
            }
          }
          const initialState = {
            startMs: now,
            durationSec: globalInitialDurationSec
          };
          window.localStorage.setItem(storageKey, JSON.stringify(initialState));
          return initialState;
        } catch {
          return { startMs: now, durationSec: globalInitialDurationSec };
        }
      };

      let timerState = getOrInitTimerState(Date.now());

      const tick = () => {
        if (typeof document !== 'undefined' && document.hidden) return;
        const now = Date.now();
        let elapsed = Math.floor((now - timerState.startMs) / 1000);
        if (elapsed >= timerState.durationSec || elapsed < 0) {
          timerState = {
            startMs: now,
            durationSec: createRealisticLoopDuration()
          };
          try {
            window.localStorage.setItem(storageKey, JSON.stringify(timerState));
          } catch {}
          elapsed = 0;
        }
        setRemainingSeconds(Math.max(0, timerState.durationSec - elapsed));
      };

      tick();
      const intervalId = window.setInterval(tick, 1000);
      return () => window.clearInterval(intervalId);
    }, [
      businessId,
      effectiveInitialHours,
      effectiveInitialMinutes,
      effectiveInitialSeconds,
      globalInitialDurationSec,
      globalResetSeed
    ]);

    const qvCdHoursStr = String(Math.floor(remainingSeconds / 3600)).padStart(2, '0');
    const qvCdMinutesStr = String(Math.floor((remainingSeconds % 3600) / 60)).padStart(2, '0');
    const qvCdSecondsStr = String(remainingSeconds % 60).padStart(2, '0');

    const renderTwoDigitCell = (str: string, textColorClass = 'text-white') => (
      <span
        translate="no"
        className={`notranslate inline-grid grid-cols-2 w-[28px] sm:w-[32px] h-[20px] sm:h-[22px] items-center justify-items-center font-mono text-base sm:text-lg font-extrabold leading-none tabular-nums select-none ${textColorClass}`}
      >
        <span className="w-[14px] sm:w-[16px] text-center">{str[0] || '0'}</span>
        <span className="w-[14px] sm:w-[16px] text-center">{str[1] || '0'}</span>
      </span>
    );

    return (
      <div
        translate="no"
        className="notranslate flex items-center gap-1.5 mx-auto sm:mx-0 shrink-0 select-none"
      >
        <div className="w-[54px] sm:w-[58px] h-[50px] sm:h-[54px] shrink-0 rounded-xl bg-gradient-to-b from-[#b91c1c] to-[#7f1d1d] text-white flex flex-col items-center justify-center shadow-xs border border-rose-700/40 overflow-hidden">
          {renderTwoDigitCell(qvCdHoursStr)}
          <span className="block text-[10px] font-bold text-rose-100 leading-none mt-1">ঘণ্টা</span>
        </div>

        <span className="w-2 text-center text-rose-700 font-extrabold text-base sm:text-lg shrink-0">
          :
        </span>

        <div className="w-[54px] sm:w-[58px] h-[50px] sm:h-[54px] shrink-0 rounded-xl bg-gradient-to-b from-[#b91c1c] to-[#7f1d1d] text-white flex flex-col items-center justify-center shadow-xs border border-rose-700/40 overflow-hidden">
          {renderTwoDigitCell(qvCdMinutesStr)}
          <span className="block text-[10px] font-bold text-rose-100 leading-none mt-1">মিনিট</span>
        </div>

        <span className="w-2 text-center text-rose-700 font-extrabold text-base sm:text-lg shrink-0">
          :
        </span>

        <div className="w-[54px] sm:w-[58px] h-[50px] sm:h-[54px] shrink-0 rounded-xl bg-gradient-to-b from-[#dc2626] to-[#991b1b] text-white flex flex-col items-center justify-center shadow-xs border border-amber-300/60 overflow-hidden">
          {renderTwoDigitCell(qvCdSecondsStr, 'text-amber-200')}
          <span className="block text-[10px] font-bold text-amber-100 leading-none mt-1">সেকেন্ড</span>
        </div>
      </div>
    );
  }
);

const StorefrontLiveViewerBadge = React.memo<{ productId: string }>(({ productId }) => {
  const [viewerCount, setViewerCount] = useState<number>(() => Math.floor(12 + Math.random() * 37));

  useEffect(() => {
    setViewerCount(Math.floor(12 + Math.random() * 37));
    const interval = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setViewerCount(prev => {
        const delta = Math.floor(Math.random() * 5) - 2;
        const next = prev + (delta === 0 ? 1 : delta);
        return Math.max(12, Math.min(48, next));
      });
    }, 4500);
    return () => window.clearInterval(interval);
  }, [productId]);

  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-50/90 border border-amber-200/80 text-slate-800 text-xs sm:text-[13px] font-semibold shadow-2xs">
      <span className="relative flex h-2 w-2 shrink-0">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600" />
      </span>
      <Eye className="w-3.5 h-3.5 text-amber-700 shrink-0" />
      <span>
        <strong className="font-mono font-extrabold text-rose-700 tabular-nums">
          {viewerCount}
        </strong>{' '}
        people currently viewing this product
      </span>
    </div>
  );
});

export const EcommerceStorefrontView: React.FC<EcommerceStorefrontViewProps> = ({
  onNavigateToErp
}) => {
  const {
    language,
    setLanguage,
    currentBusiness,
    updateBusiness,
    categories,
    brands,
    products,
    updateProduct,
    onlineOrders,
    placeOnlineOrder,
    checkDailyOrderLimit,
    verifyDailyOrderLimitServer,
    upsertIncompleteOrder,
    customers,
    registerOrUpdateOnlineCustomer,
    isAuthenticated,
    isServerHydrated,
    formatCurrency,
    formatDate,
    showToast
  } = useApp();

  const [orderLimitPopupData, setOrderLimitPopupData] = useState<DailyOrderLimitCheckResult | null>(
    null
  );
  const [isEditingLimitPopupInline, setIsEditingLimitPopupInline] = useState(false);
  const [inlineLimitTitle, setInlineLimitTitle] = useState('');
  const [inlineLimitMessage, setInlineLimitMessage] = useState('');
  const [inlineLimitSameProdMaxCount, setInlineLimitSameProdMaxCount] = useState(2);
  const [inlineLimitMaxCount, setInlineLimitMaxCount] = useState(5);

  // Storefront Navigation & Filters
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [selectedBrandId, setSelectedBrandId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'popular' | 'price_asc' | 'price_desc'>('popular');
  const [showMobileCategoryDrawer, setShowMobileCategoryDrawer] = useState<boolean>(false);
  const homeCategoryScrollRef = useRef<HTMLDivElement | null>(null);
  const isCategorySliderPausedRef = useRef<boolean>(false);
  const categoryPauseTimeoutRef = useRef<number | null>(null);

  const isHomeCategoryBarEnabled = currentBusiness.homeCategoryBarEnabled !== false;
  const isHomeCategoryAutoSlide = currentBusiness.homeCategoryAutoSlide !== false;
  const homeCategoryBarDesign: HomeCategoryBarDesign =
    currentBusiness.homeCategoryBarDesign || 'large_poster_2col';

  const homeCategoryDesignOptions: Array<{
    id: HomeCategoryBarDesign;
    label: string;
    shortLabel: string;
  }> = [
    {
      id: 'large_poster_2col',
      label: '১. বড় ইমেজ পোস্টার (মোবাইলে ২টা করে বড় ছবি)',
      shortLabel: '১. বড় পোস্টার (২টা করে)'
    },
    {
      id: 'pure_image_card',
      label: '২. শুধু বড় ছবি (Pure Image — লেখা ছাড়া ২টা করে)',
      shortLabel: '২. শুধু বড় ছবি'
    },
    {
      id: 'modern_grid_card',
      label: '৩. মডার্ন ফ্যাশন বক্স (২ কলাম ছবি ও নিচে নাম)',
      shortLabel: '৩. মডার্ন বক্স'
    },
    {
      id: 'circle_story',
      label: '৪. প্রিমিয়াম গোল স্টোরি রিং (Circle Story)',
      shortLabel: '৪. গোল স্টোরি'
    },
    {
      id: 'compact_pill',
      label: '৫. কম্প্যাক্ট সিম্পল পিল (ছোট ছবি ও নাম)',
      shortLabel: '৫. সিম্পল পিল'
    }
  ];

  const homeSliderCategories = useMemo(
    () => categories.filter(c => c.showOnHome !== false),
    [categories]
  );

  const catDragStateRef = useRef<{
    isDown: boolean;
    startX: number;
    scrollLeft: number;
    moved: boolean;
  }>({
    isDown: false,
    startX: 0,
    scrollLeft: 0,
    moved: false
  });

  const pauseCategoryAutoSlideTemporarily = (ms = 3800) => {
    isCategorySliderPausedRef.current = true;
    if (categoryPauseTimeoutRef.current) {
      window.clearTimeout(categoryPauseTimeoutRef.current);
    }
    categoryPauseTimeoutRef.current = window.setTimeout(() => {
      isCategorySliderPausedRef.current = false;
    }, ms);
  };

  const handleCatTrackMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = homeCategoryScrollRef.current;
    if (!el) return;
    isCategorySliderPausedRef.current = true;
    catDragStateRef.current = {
      isDown: true,
      startX: e.pageX - el.offsetLeft,
      scrollLeft: el.scrollLeft,
      moved: false
    };
  };

  const handleCatTrackMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!catDragStateRef.current.isDown) return;
    const el = homeCategoryScrollRef.current;
    if (!el) return;
    const x = e.pageX - el.offsetLeft;
    const walk = x - catDragStateRef.current.startX;
    if (Math.abs(walk) > 6) {
      catDragStateRef.current.moved = true;
      e.preventDefault();
      el.scrollLeft = catDragStateRef.current.scrollLeft - walk * 1.15;
    }
  };

  const handleCatTrackMouseUpOrLeave = () => {
    if (!catDragStateRef.current.isDown) return;
    catDragStateRef.current.isDown = false;
    pauseCategoryAutoSlideTemporarily(3200);
    setTimeout(() => {
      catDragStateRef.current.moved = false;
    }, 40);
  };

  // Auto Smooth Slider for Home Page Categories
  useEffect(() => {
    if (!isHomeCategoryBarEnabled || !isHomeCategoryAutoSlide || homeSliderCategories.length <= 1) {
      return;
    }
    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      if (isCategorySliderPausedRef.current) return;
      const el = homeCategoryScrollRef.current;
      if (!el) return;
      if (el.scrollWidth <= el.clientWidth + 6) return;

      const firstChild = el.firstElementChild as HTMLElement | null;
      const step = firstChild
        ? Math.max(130, firstChild.offsetWidth + 10)
        : Math.max(180, Math.round(el.clientWidth * 0.5));

      if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 14) {
        el.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        el.scrollBy({ left: step, behavior: 'smooth' });
      }
    }, 2800);

    return () => {
      window.clearInterval(timer);
    };
  }, [isHomeCategoryBarEnabled, isHomeCategoryAutoSlide, homeSliderCategories.length, homeCategoryBarDesign]);

  // Selected variation per product ID on storefront cards & quick view (Size / primary variation + optional Color variation when product has both)
  const [selectedVariantByProduct, setSelectedVariantByProduct] = useState<Record<string, string>>({});
  const [selectedColorByProduct, setSelectedColorByProduct] = useState<Record<string, string>>({});

  // Whether customer must explicitly select a size/variation before ordering (Defaults to true = ON; Admin can toggle ON/OFF)
  const isVariantSelectionRequired = currentBusiness.requireVariantSelectionBeforeOrder !== false;

  // Whether product variation buttons (size/age pills) are shown on Home Page & Related Product cards (Defaults to true = ON; when OFF, variations only show on Product Page & Size Popup)
  const showVariantsOnHomePage = currentBusiness.showVariantsOnHomePage !== false;

  // Whether "+ ব্যাগে যোগ করুন" button is shown on Home Page & Related Product cards (Defaults to true = ON)
  const showAddToBagOnHomePage = currentBusiness.showAddToBagOnHomePage !== false;

  // Whether "শপিং ব্যাগে যোগ করুন" button is shown on the Product Page (Defaults to true = ON)
  const showAddToBagOnProductPage = currentBusiness.showAddToBagOnProductPage !== false;

  // Product Page Variation Price Show/Hide (Defaults to true = ON) & Button Design Style (Defaults to 'classic_inline' = current style)
  const showProductPageVariantPrice = currentBusiness.productPageVariantShowPrice !== false;
  const productPageVariantStyle: ProductPageVariantDesign =
    currentBusiness.productPageVariantStyle || 'classic_inline';
  const productPageVariantStyleOptions: Array<{
    id: ProductPageVariantDesign;
    label: string;
    shortLabel: string;
  }> = [
    {
      id: 'classic_inline',
      label: 'ডিজাইন ১: বর্তমান ক্লাসিক স্টাইল (1-2 Years · ৳990)',
      shortLabel: 'ডিজাইন ১ (বর্তমান)'
    },
    {
      id: 'stacked_card',
      label: 'ডিজাইন ২: ২-লাইন বক্স কার্ড (উপরে সাইজ, নিচে দাম)',
      shortLabel: 'ডিজাইন ২ (২-লাইন বক্স)'
    },
    {
      id: 'price_badge',
      label: 'ডিজাইন ৩: প্রাইস ট্যাগ ব্যাজ (পাশে আলাদা প্রাইস বক্স)',
      shortLabel: 'ডিজাইন ৩ (প্রাইস ট্যাগ)'
    },
    {
      id: 'minimal_check',
      label: 'ডিজাইন ৪: ফ্যাশন আউটলাইন ও টিক-মার্ক স্টাইল',
      shortLabel: 'ডিজাইন ৪ (টিক-মার্ক)'
    }
  ];

  // Popup modal state when customer clicks "অর্ডার করুন" or "ব্যাগে যোগ করুন" without selecting a variation first
  const [variantSelectionModal, setVariantSelectionModal] = useState<{
    product: Product;
    qty: number;
    mode: 'order_now' | 'add_to_cart';
    chosenVariantId: string;
    chosenColorId?: string;
  } | null>(null);
  const [variantModalError, setVariantModalError] = useState<boolean>(false);
  const [showVariantModalSizeChart, setShowVariantModalSizeChart] = useState<boolean>(false);
  const [showVariantPopupCustomizer, setShowVariantPopupCustomizer] = useState<boolean>(false);

  // Helpers for Dual Variations (Color + Size) vs Single Variation (only Size or only Color) vs No Variation
  const getProductColorVariants = (product: Product): ProductVariant[] =>
    (product.variants || []).filter(v => v.type === 'color');

  const getProductSizeVariants = (product: Product): ProductVariant[] =>
    (product.variants || []).filter(v => v.type !== 'color');

  const hasDualColorAndSizeVariants = (product: Product): boolean =>
    getProductColorVariants(product).length > 0 && getProductSizeVariants(product).length > 0;

  const combineColorAndSizeVariant = (
    product: Product,
    colorVar: ProductVariant,
    sizeVar: ProductVariant
  ): ProductVariant => ({
    ...sizeVar,
    id: `${colorVar.id}__${sizeVar.id}`,
    label: `কালার: ${colorVar.label} | সাইজ: ${sizeVar.label}`,
    sku: sizeVar.sku
      ? `${sizeVar.sku}-${colorVar.label}`
      : colorVar.sku || product.sku,
    retailPrice: sizeVar.retailPrice || colorVar.retailPrice || product.retailPrice,
    regularPrice: sizeVar.regularPrice ?? colorVar.regularPrice ?? product.regularPrice,
    discountPrice: sizeVar.discountPrice ?? colorVar.discountPrice ?? product.discountPrice,
    purchasePrice: sizeVar.purchasePrice || colorVar.purchasePrice || product.purchasePrice,
    outOfStock: Boolean(colorVar.outOfStock || sizeVar.outOfStock),
    imageUrl: colorVar.imageUrl || sizeVar.imageUrl
  });

  // Helper to get ONLY the explicitly clicked variant for a product (returns undefined if user hasn't clicked required variation(s) yet or if out of stock)
  const getExplicitSelectedVariant = (product: Product): ProductVariant | undefined => {
    if (!product.variants || product.variants.length === 0) return undefined;
    if (hasDualColorAndSizeVariants(product)) {
      const colorId = selectedColorByProduct[product.id];
      const sizeId = selectedVariantByProduct[product.id];
      if (!colorId || !sizeId) return undefined;
      const colorVar = getProductColorVariants(product).find(v => v.id === colorId && !v.outOfStock);
      const sizeVar = getProductSizeVariants(product).find(v => v.id === sizeId && !v.outOfStock);
      if (!colorVar || !sizeVar) return undefined;
      return combineColorAndSizeVariant(product, colorVar, sizeVar);
    }
    const chosenId = selectedVariantByProduct[product.id];
    if (!chosenId) return undefined;
    return product.variants.find(v => v.id === chosenId && !v.outOfStock);
  };

  // Helper to get the currently active variant for price display (falls back to first in-stock variant if not yet clicked)
  const getActiveVariant = (product: Product): ProductVariant | undefined => {
    if (!product.variants || product.variants.length === 0) return undefined;
    if (hasDualColorAndSizeVariants(product)) {
      const colorVars = getProductColorVariants(product);
      const sizeVars = getProductSizeVariants(product);
      const chosenColor =
        colorVars.find(v => v.id === selectedColorByProduct[product.id] && !v.outOfStock) ||
        colorVars.find(v => !v.outOfStock) ||
        colorVars[0];
      const chosenSize =
        sizeVars.find(v => v.id === selectedVariantByProduct[product.id] && !v.outOfStock) ||
        sizeVars.find(v => !v.outOfStock) ||
        sizeVars[0];
      if (chosenColor && chosenSize) {
        return combineColorAndSizeVariant(product, chosenColor, chosenSize);
      }
    }
    const chosenId = selectedVariantByProduct[product.id];
    if (chosenId) {
      const found = product.variants.find(v => v.id === chosenId && !v.outOfStock);
      if (found) return found;
    }
    return product.variants.find(v => !v.outOfStock) || product.variants[0];
  };

  // Shopping Cart State (Persisted in localStorage)
  const [cart, setCart] = useState<Record<string, CartEntry>>(() => {
    if (typeof window === 'undefined') return {};
    try {
      const saved = window.localStorage.getItem('stockmaster_dokanghor_cart_v3');
      if (!saved) return {};
      return JSON.parse(saved) || {};
    } catch {
      return {};
    }
  });

  // Modals & Drawers
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState<boolean>(false);
  // Strict Single-Product Direct Buy Item (isolates 1-Click "এখনই অর্ডার করুন" from global cart state)
  const [directBuyItem, setDirectBuyItem] = useState<CartEntry | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [quickViewQty, setQuickViewQty] = useState<number>(1);
  const [activeGalleryIndex, setActiveGalleryIndex] = useState<number>(0);
  const [isEditingQvDescription, setIsEditingQvDescription] = useState<boolean>(false);
  const [qvDescriptionDraft, setQvDescriptionDraft] = useState<string>('');
  const [qvHoverZoom, setQvHoverZoom] = useState<{ active: boolean; x: number; y: number }>({
    active: false,
    x: 50,
    y: 50
  });
  const [qvLightboxOpen, setQvLightboxOpen] = useState<boolean>(false);
  const [qvLightboxScale, setQvLightboxScale] = useState<number>(1);
  const [qvLightboxPan, setQvLightboxPan] = useState<{ x: number; y: number }>({ x: 50, y: 50 });

  const isGlobalImageZoomEnabled = currentBusiness.productImageZoomEnabled !== false;
  const imageZoomStyle = currentBusiness.productImageZoomStyle || 'woocommerce_lightbox';
  const isHoverZoomAllowed =
    isGlobalImageZoomEnabled &&
    (imageZoomStyle === 'hover_and_lightbox' || imageZoomStyle === 'hover_only');
  const isLightboxAllowed =
    isGlobalImageZoomEnabled &&
    (imageZoomStyle === 'woocommerce_lightbox' || imageZoomStyle === 'hover_and_lightbox');

  // Main Storefront Sticky Floating Button Controls (Product Page & Checkout Page) & Home Page Bottom Floating Bar ON/OFF
  const isStorefrontFloatingBtnOn = currentBusiness.storefrontFloatingBtnEnabled !== false;
  const isStorefrontFloatingHideOnDesktop =
    currentBusiness.storefrontFloatingBtnHideOnDesktop !== false;
  const isHomeFloatingBarEnabled = currentBusiness.homeFloatingBarEnabled !== false;
  const isStorefrontFloatingPriceOn = currentBusiness.storefrontFloatingBtnPriceEnabled !== false;
  const storefrontFloatingAnim: LandingFloatingBtnAnimation =
    currentBusiness.storefrontFloatingBtnAnimation || 'login_shine';

  const storefrontFloatingAnimOptions: Array<{
    id: LandingFloatingBtnAnimation;
    label: string;
    shortLabel: string;
  }> = [
    { id: 'login_shine', label: 'লগইন বাটন শাইন (Login Shine & Glow)', shortLabel: 'লগইন শাইন' },
    { id: 'cart_beam', label: 'কার্ট বর্ডার বিম (Cart Golden Beam)', shortLabel: 'বর্ডার বিম' },
    { id: 'combo_beam', label: 'প্রিমিয়াম কম্বো (Beam + Shine + Pulse)', shortLabel: 'প্রিমিয়াম কম্বো' },
    { id: 'glow_pulse', label: 'রিং পালস গ্লো (Ring Pulse Glow)', shortLabel: 'পালস গ্লো' },
    { id: 'jump', label: 'জাম্প বাউন্স (Jump Bounce)', shortLabel: 'জাম্প বাউন্স' },
    { id: 'none', label: 'অ্যানিমেশন বন্ধ (Static / No Animation)', shortLabel: 'বন্ধ (OFF)' }
  ];

  const currentSfFloatingAnimObj =
    storefrontFloatingAnimOptions.find(o => o.id === storefrontFloatingAnim) ||
    storefrontFloatingAnimOptions[0];

  const sfIsBeamAnim =
    storefrontFloatingAnim === 'cart_beam' || storefrontFloatingAnim === 'combo_beam';
  const sfWrapperAnimClass =
    storefrontFloatingAnim === 'cart_beam'
      ? 'lp-floating-cart-beam-wrapper'
      : storefrontFloatingAnim === 'combo_beam'
      ? 'lp-floating-cart-beam-wrapper lp-floating-combo-pulse'
      : '';
  const sfInnerAnimClass =
    storefrontFloatingAnim === 'login_shine'
      ? 'lp-btn-red-shine lp-floating-login-glow border border-white/35'
      : storefrontFloatingAnim === 'cart_beam'
      ? 'border border-white/15 shadow-xl'
      : storefrontFloatingAnim === 'combo_beam'
      ? 'lp-btn-red-shine border border-white/20'
      : storefrontFloatingAnim === 'glow_pulse'
      ? ' border border-white/30 animate-order-cta-attention'
      : storefrontFloatingAnim === 'jump'
      ? 'border border-white/30 animate-cta-jump'
      : 'border border-white/25';

  // Keep quickViewProduct synced whenever products state updates (e.g. after editing in Inventory or inline)
  useEffect(() => {
    if (!quickViewProduct) return;
    const latest = products.find(p => p.id === quickViewProduct.id);
    if (latest && latest !== quickViewProduct) {
      setQuickViewProduct(latest);
    }
  }, [products, quickViewProduct]);

  useEffect(() => {
    setIsEditingQvDescription(false);
    setQvHoverZoom({ active: false, x: 50, y: 50 });
    setQvLightboxOpen(false);
    setQvLightboxScale(1);
    setQvLightboxPan({ x: 50, y: 50 });
  }, [quickViewProduct?.id]);

  // Global Synchronized Offer Countdown Timer for Storefront Product Pages
  // - 100% Global Time: All products share the exact same timer (visiting different products shows the exact same continuing countdown)
  // - 1-Click Global ON/OFF: Controlled via currentBusiness.storefrontCountdownEnabled
  // - Per-Product Show/Hide: Controlled on each product page via quickViewProduct.landingCountdownEnabled
  // - Realistic Non-Round Starting Time: Starts from e.g. 8 ঘণ্টা 30 মিনিট 34 সেকেন্ড (never fake-looking 8:59:59) and auto-loops when hitting 0
  const isGlobalCountdownEnabled = currentBusiness.storefrontCountdownEnabled !== false;
  const isProductCountdownEnabled = quickViewProduct
    ? quickViewProduct.landingCountdownEnabled !== false
    : false;
  const qvShowCountdown = isGlobalCountdownEnabled && isProductCountdownEnabled;

  const rawGlobalHours =
    typeof currentBusiness.storefrontCountdownHours === 'number' &&
    currentBusiness.storefrontCountdownHours >= 0
      ? Math.floor(currentBusiness.storefrontCountdownHours)
      : 8;
  const rawGlobalMinutes =
    typeof currentBusiness.storefrontCountdownMinutes === 'number' &&
    currentBusiness.storefrontCountdownMinutes >= 0 &&
    currentBusiness.storefrontCountdownMinutes <= 59
      ? Math.floor(currentBusiness.storefrontCountdownMinutes)
      : 30;
  const rawGlobalSeconds =
    typeof currentBusiness.storefrontCountdownSeconds === 'number' &&
    currentBusiness.storefrontCountdownSeconds >= 0 &&
    currentBusiness.storefrontCountdownSeconds <= 59
      ? Math.floor(currentBusiness.storefrontCountdownSeconds)
      : 34;

  // If Admin enters a round hour like 9h 0m 0s, automatically convert to realistic (hours-1)h 30m 34s so it never starts at 8:59:59
  const effectiveInitialHours =
    rawGlobalHours >= 1 && rawGlobalMinutes === 0 && rawGlobalSeconds === 0
      ? rawGlobalHours - 1
      : rawGlobalHours;
  const effectiveInitialMinutes =
    rawGlobalHours >= 1 && rawGlobalMinutes === 0 && rawGlobalSeconds === 0
      ? 30
      : rawGlobalMinutes;
  const effectiveInitialSeconds =
    rawGlobalHours >= 1 && rawGlobalMinutes === 0 && rawGlobalSeconds === 0
      ? 34
      : rawGlobalSeconds === 59 || rawGlobalSeconds === 0
      ? 34
      : rawGlobalSeconds;

  const globalInitialDurationSec = Math.max(
    180,
    effectiveInitialHours * 3600 + effectiveInitialMinutes * 60 + effectiveInitialSeconds
  );
  const globalResetSeed = currentBusiness.storefrontCountdownResetSeed || 0;

  const qvCountdownTitle =
    currentBusiness.storefrontCountdownTitle !== undefined &&
    currentBusiness.storefrontCountdownTitle.trim() !== ''
      ? currentBusiness.storefrontCountdownTitle.trim()
      : quickViewProduct?.landingCountdownTitle !== undefined &&
        quickViewProduct.landingCountdownTitle.trim() !== ''
      ? quickViewProduct.landingCountdownTitle.trim()
      : 'স্পেশাল অফার শেষ হতে বাকি:';

  const toBanglaCountdownDigits = toBanglaDigitsStatic;

  // Live "People currently viewing this product" Counter (Randomized 12-48, ON/OFF per product)
  const qvShowLiveViewers = quickViewProduct
    ? quickViewProduct.landingLiveViewersEnabled !== false
    : false;

  // Touch & Mouse Swipe Refs for Storefront Product Image Slider
  const qvTouchStartXRef = useRef<number | null>(null);
  const qvTouchEndXRef = useRef<number | null>(null);
  const qvMouseStartXRef = useRef<number | null>(null);

  // ============================================================================
  // 1. SPIN THE WHEEL (স্পিন দ্য হুইল) AUTO-POPUP, COOLDOWN, ADMIN CONFIG & LEADS
  // ============================================================================
  const spinWheelConfig = useMemo<Required<SpinWheelConfig>>(() => {
    const cfg = currentBusiness.spinWheelConfig || {};
    const rawSlices =
      Array.isArray(cfg.slices) && cfg.slices.length >= 2
        ? cfg.slices
        : DEFAULT_SPIN_WHEEL_SLICES;
    const hasExplicitLockState = rawSlices.some(s => typeof s.locked === 'boolean');
    const validSlices = hasExplicitLockState
      ? rawSlices
      : rawSlices.map((s, idx) => ({
          ...s,
          locked:
            s.id === 'sw_100' ||
            s.id === 'sw_5pct' ||
            (!['sw_50', 'sw_free_del', 'sw_30', 'sw_20'].includes(s.id) &&
              (idx === 3 || idx === 4))
        }));
    return {
      badgeText:
        cfg.badgeText !== undefined && cfg.badgeText.trim() !== ''
          ? cfg.badgeText
          : DEFAULT_SPIN_WHEEL_CONFIG.badgeText,
      titleText:
        cfg.titleText !== undefined && cfg.titleText.trim() !== ''
          ? cfg.titleText
          : DEFAULT_SPIN_WHEEL_CONFIG.titleText,
      subtitleText:
        cfg.subtitleText !== undefined && cfg.subtitleText.trim() !== ''
          ? cfg.subtitleText
          : DEFAULT_SPIN_WHEEL_CONFIG.subtitleText,
      claimButtonText:
        cfg.claimButtonText !== undefined && cfg.claimButtonText.trim() !== ''
          ? cfg.claimButtonText
          : DEFAULT_SPIN_WHEEL_CONFIG.claimButtonText,
      autoPopupDelaySec:
        typeof cfg.autoPopupDelaySec === 'number' && cfg.autoPopupDelaySec >= 1
          ? cfg.autoPopupDelaySec
          : DEFAULT_SPIN_WHEEL_CONFIG.autoPopupDelaySec,
      cooldownDays:
        typeof cfg.cooldownDays === 'number' && cfg.cooldownDays >= 1
          ? cfg.cooldownDays
          : DEFAULT_SPIN_WHEEL_CONFIG.cooldownDays,
      slices: validSlices
    };
  }, [currentBusiness.spinWheelConfig]);

  const SPIN_WHEEL_SLICES = spinWheelConfig.slices;
  const spinCooldownMs = spinWheelConfig.cooldownDays * 24 * 60 * 60 * 1000;

  const getLocalTodayDateKey = (): string => {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  const [isSpinWheelModalOpen, setIsSpinWheelModalOpen] = useState<boolean>(false);
  const [isSpinLeadsModalOpen, setIsSpinLeadsModalOpen] = useState<boolean>(false);
  const [spinAdminModalTab, setSpinAdminModalTab] = useState<'settings' | 'leads'>('settings');
  const [spinLeadsSearch, setSpinLeadsSearch] = useState<string>('');
  const [isWheelSpinning, setIsWheelSpinning] = useState<boolean>(false);
  const [wheelRotationDeg, setWheelRotationDeg] = useState<number>(0);

  // Admin Draft States for customizing Spin Wheel Texts, Timing & Slices
  const [spinDraftBadge, setSpinDraftBadge] = useState<string>(spinWheelConfig.badgeText);
  const [spinDraftTitle, setSpinDraftTitle] = useState<string>(spinWheelConfig.titleText);
  const [spinDraftSubtitle, setSpinDraftSubtitle] = useState<string>(spinWheelConfig.subtitleText);
  const [spinDraftClaimBtnText, setSpinDraftClaimBtnText] = useState<string>(
    spinWheelConfig.claimButtonText
  );
  const [spinDraftDelaySec, setSpinDraftDelaySec] = useState<number>(
    spinWheelConfig.autoPopupDelaySec
  );
  const [spinDraftCooldownDays, setSpinDraftCooldownDays] = useState<number>(
    spinWheelConfig.cooldownDays
  );
  const [spinDraftSlices, setSpinDraftSlices] = useState<SpinWheelSliceConfig[]>(() =>
    spinWheelConfig.slices.map(s => ({ ...s }))
  );

  useEffect(() => {
    setSpinDraftBadge(spinWheelConfig.badgeText);
    setSpinDraftTitle(spinWheelConfig.titleText);
    setSpinDraftSubtitle(spinWheelConfig.subtitleText);
    setSpinDraftClaimBtnText(spinWheelConfig.claimButtonText);
    setSpinDraftDelaySec(spinWheelConfig.autoPopupDelaySec);
    setSpinDraftCooldownDays(spinWheelConfig.cooldownDays);
    setSpinDraftSlices(spinWheelConfig.slices.map(s => ({ ...s })));
  }, [spinWheelConfig]);

  // Spin Lock Record (1 Spin per Cooldown Period per Device / Mobile Number; Offer valid for 1 Order only)
  const [dailySpinRecord, setDailySpinRecord] = useState<{
    dateKey: string;
    name: string;
    phone: string;
    reward: {
      id: string;
      label: string;
      type: 'flat' | 'percent' | 'free_delivery' | 'none';
      value: number;
      code: string;
    };
    spunAt: string;
    used?: boolean;
    usedOrderNo?: string;
  } | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const raw = window.localStorage.getItem('stockmaster_spin_daily_lock_v1');
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (parsed && parsed.spunAt && parsed.reward) {
        const spunTime = new Date(parsed.spunAt).getTime();
        const maxDays =
          currentBusiness.spinWheelConfig?.cooldownDays &&
          currentBusiness.spinWheelConfig.cooldownDays >= 1
            ? currentBusiness.spinWheelConfig.cooldownDays
            : DEFAULT_SPIN_WHEEL_CONFIG.cooldownDays;
        if (!Number.isNaN(spunTime) && Date.now() - spunTime < maxDays * 24 * 60 * 60 * 1000) {
          return parsed;
        }
      }
      return null;
    } catch {
      return null;
    }
  });

  const [claimedSpinReward, setClaimedSpinReward] = useState<{
    id: string;
    label: string;
    type: 'flat' | 'percent' | 'free_delivery' | 'none';
    value: number;
    code: string;
  } | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const rawLock = window.localStorage.getItem('stockmaster_spin_daily_lock_v1');
      if (rawLock) {
        const parsedLock = JSON.parse(rawLock);
        if (parsedLock?.used) {
          return null;
        }
        if (parsedLock && parsedLock.reward && parsedLock.reward.type !== 'none') {
          return parsedLock.reward;
        }
      }
      const saved = window.localStorage.getItem('stockmaster_spin_reward_v1');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Customer Name & Mobile Number required before spinning
  const [spinLeadName, setSpinLeadName] = useState<string>(() => {
    if (dailySpinRecord?.name) return dailySpinRecord.name;
    return getFbCustomerIdentity().name || '';
  });
  const [spinLeadPhone, setSpinLeadPhone] = useState<string>(() => {
    if (dailySpinRecord?.phone) return dailySpinRecord.phone;
    return getFbCustomerIdentity().phone || '';
  });
  const [spinFormError, setSpinFormError] = useState<string | null>(null);
  const spinNameInputRef = useRef<HTMLInputElement | null>(null);
  const spinPhoneInputRef = useRef<HTMLInputElement | null>(null);

  // Local fallback cache of Spin Wheel Leads merged with Business database (`currentBusiness.spinWheelLeads`)
  const [localSpinWheelLeads, setLocalSpinWheelLeads] = useState<SpinWheelLead[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const raw = window.localStorage.getItem('stockmaster_spin_wheel_leads_v1');
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  const allSpinWheelLeads = useMemo<SpinWheelLead[]>(() => {
    const deletedSet = new Set(currentBusiness.deletedSpinLeadIds || []);
    const byId = new Map<string, SpinWheelLead>();
    (currentBusiness.spinWheelLeads || []).forEach(lead => {
      if (lead && lead.id && !deletedSet.has(lead.id)) byId.set(lead.id, lead);
    });
    localSpinWheelLeads.forEach(lead => {
      if (lead && lead.id && !deletedSet.has(lead.id) && !byId.has(lead.id)) {
        byId.set(lead.id, lead);
      }
    });
    return Array.from(byId.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [currentBusiness.spinWheelLeads, currentBusiness.deletedSpinLeadIds, localSpinWheelLeads]);

  const todayDateKey = getLocalTodayDateKey();
  const hasSpunInCooldownOnDevice = useMemo(() => {
    if (!dailySpinRecord || !dailySpinRecord.spunAt) return false;
    const spunTime = new Date(dailySpinRecord.spunAt).getTime();
    if (Number.isNaN(spunTime)) return dailySpinRecord.dateKey === todayDateKey;
    return Date.now() - spunTime < spinCooldownMs;
  }, [dailySpinRecord, spinCooldownMs, todayDateKey]);

  const markSpinPopupShownOrDismissedNow = () => {
    try {
      window.localStorage.setItem(
        'stockmaster_spin_popup_state_v2',
        JSON.stringify({ lastShownAtMs: Date.now() })
      );
    } catch {
      // ignore
    }
  };

  // Auto-Popup after `autoPopupDelaySec` seconds (Hidden initially when user enters website; shows at most once per `cooldownDays`)
  useEffect(() => {
    if (currentBusiness.spinWheelEnabled === false) return;
    if (hasSpunInCooldownOnDevice) return;
    if (isCheckoutModalOpen) return;

    try {
      const rawState = window.localStorage.getItem('stockmaster_spin_popup_state_v2');
      if (rawState) {
        const parsedState = JSON.parse(rawState);
        const lastShown = Number(parsedState?.lastShownAtMs || 0);
        if (lastShown > 0 && Date.now() - lastShown < spinCooldownMs) {
          // Already shown/dismissed within cooldown period (e.g. 7 days or 1 day) — do NOT annoy user again
          return;
        }
      }
    } catch {
      // ignore
    }

    const delayMs = Math.max(1000, spinWheelConfig.autoPopupDelaySec * 1000);
    const timer = window.setTimeout(() => {
      setIsSpinWheelModalOpen(true);
      markSpinPopupShownOrDismissedNow();
    }, delayMs);

    return () => window.clearTimeout(timer);
  }, [
    currentBusiness.spinWheelEnabled,
    hasSpunInCooldownOnDevice,
    spinCooldownMs,
    spinWheelConfig.autoPopupDelaySec,
    isCheckoutModalOpen
  ]);

  const handleCloseSpinWheelModal = () => {
    setIsSpinWheelModalOpen(false);
    setSpinFormError(null);
    markSpinPopupShownOrDismissedNow();
  };

  const handleResetTodaySpinLockForAdmin = () => {
    setDailySpinRecord(null);
    setClaimedSpinReward(null);
    setSpinFormError(null);
    try {
      window.localStorage.removeItem('stockmaster_spin_daily_lock_v1');
      window.localStorage.removeItem('stockmaster_spin_reward_v1');
      window.localStorage.removeItem('stockmaster_spin_popup_state_v2');
    } catch {
      // ignore
    }
    showToast('স্পিন হুইল লক ও পপআপ টাইমার রিসেট হয়েছে! এখন আবার টেস্ট স্পিন করতে পারবেন।', 'info');
  };

  const handleSaveSpinWheelAdminSettings = () => {
    const cleanedSlices = spinDraftSlices
      .map((s, idx) => ({
        id: s.id || `sw_custom_${idx}_${Date.now()}`,
        label: s.label.trim() || `পুরস্কার #${idx + 1}`,
        shortLabel: s.shortLabel.trim() || s.label.trim() || `ছাড় #${idx + 1}`,
        type: s.type,
        value: s.type === 'free_delivery' || s.type === 'none' ? 0 : Math.max(0, Number(s.value) || 0),
        color: s.color || '#e11d48',
        code:
          s.type === 'none'
            ? 'TRYAGAIN'
            : (s.code || `SPIN${idx + 1}`).trim().toUpperCase(),
        locked: Boolean(s.locked)
      }))
      .filter(Boolean);

    if (cleanedSlices.length < 2) {
      showToast('স্পিন হুইলে কমপক্ষে ২টি পুরস্কার স্লাইস থাকতে হবে।', 'error');
      return;
    }

    if (cleanedSlices.every(s => s.locked)) {
      showToast('সবগুলো অফার লক রাখা যাবে না! কমপক্ষে ১টি অফার আনলক রাখুন যাতে কাস্টমার জিততে পারে।', 'error');
      return;
    }

    const updatedConfig: SpinWheelConfig = {
      badgeText: spinDraftBadge.trim() || DEFAULT_SPIN_WHEEL_CONFIG.badgeText,
      titleText: spinDraftTitle.trim() || DEFAULT_SPIN_WHEEL_CONFIG.titleText,
      subtitleText: spinDraftSubtitle.trim() || DEFAULT_SPIN_WHEEL_CONFIG.subtitleText,
      claimButtonText: spinDraftClaimBtnText.trim() || DEFAULT_SPIN_WHEEL_CONFIG.claimButtonText,
      autoPopupDelaySec: Math.max(1, Math.min(60, Number(spinDraftDelaySec) || 4)),
      cooldownDays: Math.max(1, Number(spinDraftCooldownDays) || 7),
      slices: cleanedSlices
    };

    updateBusiness({
      spinWheelEnabled: true,
      spinWheelConfig: updatedConfig
    });
    showToast('স্পিন দ্য হুইল সেটিংস, টেক্সট ও পুরস্কার সফলভাবে সংরক্ষিত হয়েছে!', 'success');
  };

  const handleDeleteSpinWheelLead = (leadId: string) => {
    const targetLead = allSpinWheelLeads.find(l => l.id === leadId);
    const nextLeads = allSpinWheelLeads.filter(l => l.id !== leadId);
    const nextDeletedIds = Array.from(
      new Set([...(currentBusiness.deletedSpinLeadIds || []), leadId])
    );
    setLocalSpinWheelLeads(nextLeads);
    try {
      window.localStorage.setItem('stockmaster_spin_wheel_leads_v1', JSON.stringify(nextLeads));
    } catch {
      // ignore
    }
    updateBusiness({
      spinWheelLeads: nextLeads,
      deletedSpinLeadIds: nextDeletedIds
    });
    if (
      targetLead &&
      dailySpinRecord &&
      normalizeBdPhone(dailySpinRecord.phone || targetLead.customerPhone || '') ===
        normalizeBdPhone(targetLead.phone || targetLead.customerPhone || '')
    ) {
      setDailySpinRecord(null);
      try {
        window.localStorage.removeItem('stockmaster_spin_daily_lock_v1');
        window.localStorage.removeItem('stockmaster_spin_popup_state_v2');
      } catch {
        // ignore
      }
    }
    showToast('স্পিন হুইল কাস্টমার এন্ট্রি ডিলিট করা হয়েছে।', 'info');
  };

  const handleTriggerSpinWheel = () => {
    if (isWheelSpinning) return;
    const todayKey = getLocalTodayDateKey();

    // 1. Check if this device already spun within cooldown period
    if (hasSpunInCooldownOnDevice) {
      setSpinFormError(
        `আপনি ইতিমধ্যে একবার স্পিন করেছেন! প্রতি ${toBanglaCountdownDigits(
          spinWheelConfig.cooldownDays,
          1
        )} দিনে সর্বোচ্চ ১ বার স্পিন করার সুযোগ থাকে।`
      );
      return;
    }

    // 2. Validate Customer Name
    const cleanName = spinLeadName.trim();
    if (cleanName.length < 2) {
      setSpinFormError('স্পিন করার আগে অনুগ্রহ করে আপনার নাম লিখুন।');
      spinNameInputRef.current?.focus();
      return;
    }

    // 3. Validate 11-digit BD Mobile Number
    const normPhone = normalizeBdPhone(spinLeadPhone);
    if (!isValidBdPhone11(normPhone)) {
      setSpinFormError(
        'স্পিন করার আগে সঠিক ১১ ডিজিটের মোবাইল নাম্বার দিন (যেমন: 017XXXXXXXX)।'
      );
      spinPhoneInputRef.current?.focus();
      return;
    }

    // 4. Check if this Mobile Number has already spun within the configured cooldown period
    const existingRecentLead = allSpinWheelLeads.find(lead => {
      if (normalizeBdPhone(lead.phone) !== normPhone) return false;
      const leadTime = new Date(lead.createdAt).getTime();
      if (!Number.isNaN(leadTime)) {
        return Date.now() - leadTime < spinCooldownMs;
      }
      return lead.dateKey === todayKey;
    });

    if (existingRecentLead) {
      const matchedSlice =
        SPIN_WHEEL_SLICES.find(s => s.id === existingRecentLead.prizeId) || SPIN_WHEEL_SLICES[0];
      const restoredReward = {
        id: matchedSlice.id,
        label: matchedSlice.label,
        type: matchedSlice.type,
        value: matchedSlice.value,
        code: matchedSlice.code
      };
      const leadSpunMs = new Date(existingRecentLead.createdAt).getTime();
      const usedOrder = onlineOrders.find(o => {
        if (o.orderStatus === 'cancelled') return false;
        if (normalizeBdPhone(o.customerPhone) !== normPhone) return false;
        const hasSpinNote = Boolean(o.notes && o.notes.includes('স্পিন দ্য হুইল পুরস্কার'));
        if (!hasSpinNote) return false;
        if (!Number.isNaN(leadSpunMs)) {
          const ordMs = new Date(o.createdAt).getTime();
          if (!Number.isNaN(ordMs) && ordMs + 5000 < leadSpunMs) return false;
        }
        return true;
      });
      const isAlreadyUsed = Boolean(usedOrder || dailySpinRecord?.used);
      const restoredLock = {
        dateKey: existingRecentLead.dateKey || todayKey,
        name: existingRecentLead.name || cleanName,
        phone: normPhone,
        reward: restoredReward,
        spunAt: existingRecentLead.createdAt,
        used: isAlreadyUsed,
        usedOrderNo: usedOrder?.orderNo || dailySpinRecord?.usedOrderNo
      };
      setDailySpinRecord(restoredLock);
      if (!isAlreadyUsed && restoredReward.type !== 'none') {
        setClaimedSpinReward(restoredReward);
      } else {
        setClaimedSpinReward(null);
      }
      try {
        window.localStorage.setItem('stockmaster_spin_daily_lock_v1', JSON.stringify(restoredLock));
        if (!isAlreadyUsed && restoredReward.type !== 'none') {
          window.localStorage.setItem('stockmaster_spin_reward_v1', JSON.stringify(restoredReward));
        } else {
          window.localStorage.removeItem('stockmaster_spin_reward_v1');
        }
        markSpinPopupShownOrDismissedNow();
      } catch {
        // ignore
      }
      setSpinFormError(
        isAlreadyUsed
          ? `এই মোবাইল নাম্বার (${normPhone}) দিয়ে জেতা স্পিন অফারটি ইতিমধ্যে ১টি অর্ডারে ব্যবহার করা হয়েছে! (স্পিন অফার শুধুমাত্র ১টি অর্ডারেই প্রযোজ্য)`
          : `এই মোবাইল নাম্বার (${normPhone}) দিয়ে ইতিমধ্যে স্পিন করা হয়েছে! আপনার জেতা পুরস্কার (${restoredReward.label}) নিচে যুক্ত করা হয়েছে।`
      );
      return;
    }

    setSpinFormError(null);
    setIsWheelSpinning(true);
    markSpinPopupShownOrDismissedNow();

    // Pre-fill Checkout Customer Name & Phone and sync with central Customer Database
    if (!customerName.trim()) setCustomerName(cleanName);
    if (!customerPhone.trim()) setCustomerPhone(normPhone);
    saveFbCustomerIdentity({ name: cleanName, phone: normPhone }, currentBusiness);
    registerOrUpdateOnlineCustomer({
      name: cleanName,
      phone: normPhone,
      address: deliveryAddress.trim() || ''
    }).catch(() => {});

    // Pick winning slice ONLY from unlocked slices (4 unlocked winnable offers; 2 locked teaser offers are never landed on)
    const unlockedWinnableIndices = SPIN_WHEEL_SLICES
      .map((s, idx) => (!s.locked && s.type !== 'none' ? idx : -1))
      .filter(idx => idx !== -1);
    const unlockedAnyIndices = SPIN_WHEEL_SLICES
      .map((s, idx) => (!s.locked ? idx : -1))
      .filter(idx => idx !== -1);
    const candidateIndices =
      unlockedWinnableIndices.length > 0
        ? unlockedWinnableIndices
        : unlockedAnyIndices.length > 0
          ? unlockedAnyIndices
          : SPIN_WHEEL_SLICES.map((_, idx) => idx);
    const winningIndex =
      candidateIndices[Math.floor(Math.random() * candidateIndices.length)];

    const sliceAngle = 360 / SPIN_WHEEL_SLICES.length;
    // Align pointer at top (0 deg) with the center of winningIndex slice
    const targetSliceCenter = winningIndex * sliceAngle + sliceAngle / 2;
    const extraSpins = (6 + Math.floor(Math.random() * 3)) * 360;
    const currentBase = wheelRotationDeg - (wheelRotationDeg % 360);
    const finalDeg = currentBase + extraSpins + (360 - targetSliceCenter);
    setWheelRotationDeg(finalDeg);

    window.setTimeout(() => {
      const prize = SPIN_WHEEL_SLICES[winningIndex];
      const nowIso = new Date().toISOString();
      const rewardObj = {
        id: prize.id,
        label: prize.label,
        type: prize.type,
        value: prize.value,
        code: prize.code
      };

      const newLead: SpinWheelLead = {
        id: `swl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        name: cleanName,
        phone: normPhone,
        prizeId: prize.id,
        prizeLabel: prize.label,
        prizeCode: prize.code,
        dateKey: todayKey,
        customerName: cleanName,
        customerPhone: normPhone,
        rewardLabel: prize.label,
        rewardType: prize.type,
        rewardValue: prize.value,
        couponCode: prize.code,
        spinDateKey: todayKey,
        source: 'website',
        createdAt: nowIso
      };

      const lockObj = {
        dateKey: todayKey,
        name: cleanName,
        phone: normPhone,
        reward: rewardObj,
        spunAt: nowIso
      };

      if (rewardObj.type !== 'none') {
        setClaimedSpinReward(rewardObj);
      }
      setDailySpinRecord(lockObj);
      setIsWheelSpinning(false);

      const updatedLeads = [newLead, ...allSpinWheelLeads];
      setLocalSpinWheelLeads(updatedLeads);
      updateBusiness({ spinWheelLeads: updatedLeads });

      try {
        if (rewardObj.type !== 'none') {
          window.localStorage.setItem('stockmaster_spin_reward_v1', JSON.stringify(rewardObj));
        }
        window.localStorage.setItem('stockmaster_spin_daily_lock_v1', JSON.stringify(lockObj));
        window.localStorage.setItem(
          'stockmaster_spin_wheel_leads_v1',
          JSON.stringify(updatedLeads)
        );
      } catch {
        // ignore storage error
      }

      if (rewardObj.type === 'none') {
        showToast(
          `ধন্যবাদ ${cleanName}! এবারের স্পিনে "${prize.label}" উঠেছে। আপনার জন্য শুভকামনা!`,
          'info'
        );
      } else {
        showToast(
          `🎉 অভিনন্দন ${cleanName}! আপনি "${prize.label}" জিতেছেন! চেকআউটে স্বয়ংক্রিয়ভাবে ছাড় যুক্ত হবে।`,
          'success'
        );
      }
    }, 4200);
  };

  // ============================================================================
  // 2. SIZE CHART & CUSTOM / FAKE REVIEW STATES FOR PRODUCT DETAILS PAGE
  // ============================================================================
  const [isQvSizeChartModalOpen, setIsQvSizeChartModalOpen] = useState<boolean>(false);
  const [isEditingQvSizeChart, setIsEditingQvSizeChart] = useState<boolean>(false);
  const [qvSizeChartTitleDraft, setQvSizeChartTitleDraft] = useState<string>(
    'সাইজ চার্ট ও বডির মাপ (Size Chart)'
  );
  const [qvSizeChartSubtitleDraft, setQvSizeChartSubtitleDraft] = useState<string>(
    'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন'
  );
  const [qvSizeChartHeadersDraft, setQvSizeChartHeadersDraft] = useState<[string, string, string]>(
    [...DEFAULT_LANDING_SIZE_CHART_HEADERS]
  );
  const [qvSizeChartRowsDraft, setQvSizeChartRowsDraft] = useState<LandingSizeChartRow[]>(
    DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }))
  );

  const [isWritingQvReview, setIsWritingQvReview] = useState<boolean>(false);
  const [qvNewRevName, setQvNewRevName] = useState<string>('');
  const [qvNewRevLocation, setQvNewRevLocation] = useState<string>('ঢাকা');
  const [qvNewRevRating, setQvNewRevRating] = useState<number>(5);
  const [qvNewRevComment, setQvNewRevComment] = useState<string>('');
  const [qvNewRevAvatar, setQvNewRevAvatar] = useState<string>('');
  const [isUploadingQvReviewAvatar, setIsUploadingQvReviewAvatar] = useState<boolean>(false);

  // Logged-in Customer Order History Review Form State
  const [orderReviewTargetKey, setOrderReviewTargetKey] = useState<string | null>(null);
  const [orderReviewRating, setOrderReviewRating] = useState<number>(5);
  const [orderReviewComment, setOrderReviewComment] = useState<string>('');
  const [orderReviewAvatar, setOrderReviewAvatar] = useState<string>('');
  const [isUploadingOrderReviewAvatar, setIsUploadingOrderReviewAvatar] = useState<boolean>(false);
  const orderHistoryReviewerAvatarInputRef = useRef<HTMLInputElement | null>(null);

  // Storefront Product Page Customer Review Slider & Reviewer Circular Photo Upload State
  const [qvActiveReviewSlide, setQvActiveReviewSlide] = useState<number>(0);
  const [qvActiveScreenshotSlide, setQvActiveScreenshotSlide] = useState<number>(0);
  const [isQvReviewSliderPaused, setIsQvReviewSliderPaused] = useState<boolean>(false);

  const qvReviewerAvatarInputRef = useRef<HTMLInputElement | null>(null);
  const qvNewReviewerAvatarInputRef = useRef<HTMLInputElement | null>(null);
  const qvScreenshotUploadInputRef = useRef<HTMLInputElement | null>(null);
  const targetQvAvatarReviewIdRef = useRef<string | null>(null);
  const qvRevTouchStartXRef = useRef<number | null>(null);
  const qvRevTouchEndXRef = useRef<number | null>(null);
  const qvRevMouseStartXRef = useRef<number | null>(null);
  const qvShotTouchStartXRef = useRef<number | null>(null);
  const qvShotTouchEndXRef = useRef<number | null>(null);
  const qvShotMouseStartXRef = useRef<number | null>(null);

  const [confirmedOrder, setConfirmedOrder] = useState<OnlineOrder | null>(null);

  const qvReviewsEnabled = quickViewProduct
    ? quickViewProduct.landingReviewsEnabled !== false
    : true;
  const qvReviewsSliderEnabled = quickViewProduct
    ? quickViewProduct.landingReviewsSliderEnabled !== false
    : true;

  const qvReviewScreenshots = useMemo(() => {
    return Array.isArray(quickViewProduct?.landingReviewImages)
      ? quickViewProduct.landingReviewImages.filter(Boolean)
      : [];
  }, [quickViewProduct?.landingReviewImages]);

  const qvAllReviews = useMemo<LandingReviewItem[]>(() => {
    if (
      Array.isArray(quickViewProduct?.landingReviewItems) &&
      quickViewProduct.landingReviewItems.length > 0
    ) {
      return quickViewProduct.landingReviewItems;
    }
    if (qvReviewScreenshots.length > 0) return [];
    return [
      {
        id: 'default_rev_1',
        customerName: 'সুমাইয়া আক্তার বর্ষা',
        location: 'মিরপুর-১০, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'আলহামদুলিল্লাহ! ছবির সাথে পণ্যের ১০০% মিল পেয়েছি। কাপড় ও ফিনিশিং খুবই উন্নত মানের। নিশ্চিন্তে অর্ডার করতে পারেন।',
        status: 'approved'
      },
      {
        id: 'default_rev_2',
        customerName: 'ফারজানা হক নদী',
        location: 'আগ্রাবাদ, চট্টগ্রাম · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'ডেলিভারি সার্ভিস খুবই ফাস্ট ছিল। ডেলিভারি ম্যানের সামনে পণ্য চেক করে টাকা দিয়েছি, কোয়ালিটি সত্যিই অসাধারণ!',
        status: 'approved'
      },
      {
        id: 'default_rev_3',
        customerName: 'মাহমুদা খাতুন কেয়া',
        location: 'সোনাডাঙ্গা, খুলনা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'সাইজ চার্ট অনুযায়ী অর্ডার করেছিলাম, একদম পারফেক্ট ফিট হয়েছে। এত কম দামে এত ভালো মানের প্রোডাক্ট দেওয়ার জন্য ধন্যবাদ।',
        status: 'approved'
      },
      {
        id: 'default_rev_4',
        customerName: 'সাদিয়া আফরিন রূপা',
        location: 'সিলেট · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'ফেব্রিকটা অনেক সফট এবং আরামদায়ক। রঙের গ্যারান্টি যেমন বলেছে ঠিক তেমনই পেয়েছি। সবাইকে নেওয়ার পরামর্শ দেবো।',
        status: 'approved'
      },
      {
        id: 'default_rev_5',
        customerName: 'মাহমুদুল হাসান রাকিব',
        location: 'রাজশাহী · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'বাসার সবার জন্য অর্ডার করেছিলাম, প্রত্যেকেই খুব পছন্দ করেছে। কুরিয়ার সার্ভিসও অনেক দ্রুত ডেলিভারি দিয়েছে।',
        status: 'approved'
      },
      {
        id: 'default_rev_6',
        customerName: 'তাসনিম জেরিন ইভা',
        location: 'উত্তরা, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'এই বাজেটে এত সুন্দর ও নিখুঁত সেলাইয়ের প্রোডাক্ট সত্যিই আশা করিনি। ইনশাআল্লাহ সামনে আরও অর্ডার করব।',
        status: 'approved'
      }
    ];
  }, [quickViewProduct?.landingReviewItems, qvReviewScreenshots.length]);

  const qvPendingReviews = useMemo(
    () => qvAllReviews.filter(r => r.status === 'pending'),
    [qvAllReviews]
  );
  const qvApprovedReviews = useMemo(
    () => qvAllReviews.filter(r => r.status !== 'pending'),
    [qvAllReviews]
  );
  const qvDisplayReviews = useMemo(
    () => (isAuthenticated ? [...qvPendingReviews, ...qvApprovedReviews] : qvApprovedReviews),
    [isAuthenticated, qvPendingReviews, qvApprovedReviews]
  );

  const safeQvReviewSlide =
    qvDisplayReviews.length > 0 ? qvActiveReviewSlide % qvDisplayReviews.length : 0;
  const safeQvScreenshotSlide =
    qvReviewScreenshots.length > 0 ? qvActiveScreenshotSlide % qvReviewScreenshots.length : 0;

  // Reset review slide when switching products
  useEffect(() => {
    setQvActiveReviewSlide(0);
    setQvActiveScreenshotSlide(0);
    setIsWritingQvReview(false);
    setQvNewRevAvatar('');
  }, [quickViewProduct?.id]);

  // Auto-advance Storefront Written Reviews Slider every 4.2s when Slider Mode is ON
  useEffect(() => {
    if (
      !quickViewProduct ||
      !qvReviewsEnabled ||
      !qvReviewsSliderEnabled ||
      isQvReviewSliderPaused ||
      isWritingQvReview ||
      qvDisplayReviews.length <= 1 ||
      Boolean(confirmedOrder)
    ) {
      return;
    }
    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setQvActiveReviewSlide(prev => (prev + 1) % qvDisplayReviews.length);
    }, 4200);
    return () => window.clearInterval(timer);
  }, [
    quickViewProduct,
    qvReviewsEnabled,
    qvReviewsSliderEnabled,
    isQvReviewSliderPaused,
    isWritingQvReview,
    qvDisplayReviews.length,
    confirmedOrder
  ]);

  // Auto-advance Storefront Review Screenshots Slider every 4.5s when Slider Mode is ON
  useEffect(() => {
    if (
      !quickViewProduct ||
      !qvReviewsEnabled ||
      !qvReviewsSliderEnabled ||
      isQvReviewSliderPaused ||
      isWritingQvReview ||
      qvReviewScreenshots.length <= 1 ||
      Boolean(confirmedOrder)
    ) {
      return;
    }
    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setQvActiveScreenshotSlide(prev => (prev + 1) % qvReviewScreenshots.length);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [
    quickViewProduct,
    qvReviewsEnabled,
    qvReviewsSliderEnabled,
    isQvReviewSliderPaused,
    isWritingQvReview,
    qvReviewScreenshots.length,
    confirmedOrder
  ]);

  const handleQvPrevReviewSlide = () => {
    if (qvDisplayReviews.length <= 1) return;
    setQvActiveReviewSlide(
      prev => (prev - 1 + qvDisplayReviews.length) % qvDisplayReviews.length
    );
  };

  const handleQvNextReviewSlide = () => {
    if (qvDisplayReviews.length <= 1) return;
    setQvActiveReviewSlide(prev => (prev + 1) % qvDisplayReviews.length);
  };

  const handleQvTriggerReviewerAvatarUpload = (reviewId: string) => {
    targetQvAvatarReviewIdRef.current = reviewId;
    qvReviewerAvatarInputRef.current?.click();
  };

  const handleQvReviewerAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetId = targetQvAvatarReviewIdRef.current;
    if (!file || !targetId || !quickViewProduct) return;
    setIsUploadingQvReviewAvatar(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      const baseList = qvAllReviews.map(item => ({ ...item }));
      const targetIdx = baseList.findIndex(item => item.id === targetId);
      if (targetIdx !== -1) {
        baseList[targetIdx] = {
          ...baseList[targetIdx],
          avatarUrl: dataUrl
        };
        await updateProduct(quickViewProduct.id, {
          landingReviewItems: baseList,
          landingReviewsEnabled: true
        });
        setQuickViewProduct(prev =>
          prev
            ? {
                ...prev,
                landingReviewItems: baseList,
                landingReviewsEnabled: true
              }
            : null
        );
        showToast(
          `"${baseList[targetIdx].customerName}"-এর প্রোফাইল ছবি আপলোড হয়েছে!`,
          'success'
        );
      }
    } catch {
      showToast('প্রোফাইল ছবি প্রসেস করা যায়নি', 'error');
    } finally {
      setIsUploadingQvReviewAvatar(false);
      targetQvAvatarReviewIdRef.current = null;
      e.target.value = '';
    }
  };

  const handleQvRemoveReviewerAvatar = async (reviewId: string) => {
    if (!quickViewProduct) return;
    const baseList = qvAllReviews.map(item => ({ ...item }));
    const targetIdx = baseList.findIndex(item => item.id === reviewId);
    if (targetIdx === -1) return;
    const revName = baseList[targetIdx].customerName;
    baseList[targetIdx] = {
      ...baseList[targetIdx],
      avatarUrl: undefined
    };
    await updateProduct(quickViewProduct.id, {
      landingReviewItems: baseList
    });
    setQuickViewProduct(prev =>
      prev
        ? {
            ...prev,
            landingReviewItems: baseList
          }
        : null
    );
    showToast(`"${revName}"-এর ছবি সরানো হয়েছে (নামের প্রথম অক্ষর দেখাবে)`, 'info');
  };

  const handleQvNewReviewerAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingQvReviewAvatar(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      setQvNewRevAvatar(dataUrl);
      showToast('ক্রেতার ছবি যুক্ত হয়েছে!', 'success');
    } catch {
      showToast('ছবি আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingQvReviewAvatar(false);
      e.target.value = '';
    }
  };

  const handleOrderHistoryReviewAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingOrderReviewAvatar(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      setOrderReviewAvatar(dataUrl);
      showToast('আপনার ছবি যুক্ত হয়েছে!', 'success');
    } catch {
      showToast('ছবি আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingOrderReviewAvatar(false);
      e.target.value = '';
    }
  };

  const handleQvScreenshotUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !quickViewProduct) return;
    setIsUploadingQvReviewAvatar(true);
    try {
      const uploaded: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const dataUrl = await processUploadedProductImage(files[i]);
        uploaded.push(dataUrl);
      }
      const nextShots = [...qvReviewScreenshots, ...uploaded];
      await updateProduct(quickViewProduct.id, {
        landingReviewImages: nextShots,
        landingReviewsEnabled: true
      });
      setQuickViewProduct(prev =>
        prev
          ? {
              ...prev,
              landingReviewImages: nextShots,
              landingReviewsEnabled: true
            }
          : null
      );
      showToast(`${uploaded.length}টি রিভিউ স্ক্রিনশট আপলোড হয়েছে!`, 'success');
    } catch {
      showToast('রিভিউ স্ক্রিনশট আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingQvReviewAvatar(false);
      e.target.value = '';
    }
  };

  // ============================================================================
  // REAL CUSTOMER PHOTO & UNBOXING VIDEO GALLERY STATE ("আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও")
  // ============================================================================
  const qvRealCustomerPhotosInputRef = useRef<HTMLInputElement | null>(null);
  const [qvRealVideoPlaying, setQvRealVideoPlaying] = useState<boolean>(false);
  const [qvSelectedRealPhotoLightbox, setQvSelectedRealPhotoLightbox] = useState<string | null>(
    null
  );

  // Reset Click-to-Play video & lightbox when product changes so zero heavy video loads upfront
  useEffect(() => {
    setQvRealVideoPlaying(false);
    setQvSelectedRealPhotoLightbox(null);
  }, [quickViewProduct?.id]);

  const qvRealGalleryEnabled = quickViewProduct
    ? quickViewProduct.realCustomerGalleryEnabled !== false
    : true;

  const qvRealCustomerPhotos = useMemo(() => {
    return Array.isArray(quickViewProduct?.realCustomerPhotos)
      ? quickViewProduct.realCustomerPhotos.filter(p => Boolean(p && p.trim()))
      : [];
  }, [quickViewProduct?.realCustomerPhotos]);

  const qvRawUnboxingVideoUrl = (
    quickViewProduct?.realUnboxingVideoUrl ||
    quickViewProduct?.landingVideoUrl ||
    ''
  ).trim();

  const qvUnboxingVideoEmbed = useMemo(() => {
    const raw = qvRawUnboxingVideoUrl;
    if (!raw) return { type: 'none' as const, embedUrl: '' };

    const ytMatch = raw.match(
      /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/i
    );
    if (ytMatch && ytMatch[1]) {
      return {
        type: 'iframe' as const,
        embedUrl: `https://www.youtube.com/embed/${ytMatch[1]}?autoplay=1&rel=0`
      };
    }

    if (/facebook\.com|fb\.watch/i.test(raw)) {
      return {
        type: 'iframe' as const,
        embedUrl: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(
          raw
        )}&show_text=false&autoplay=true`
      };
    }

    if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(raw) || raw.startsWith('data:video/')) {
      return {
        type: 'direct_video' as const,
        embedUrl: raw
      };
    }

    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return {
        type: 'iframe' as const,
        embedUrl: raw
      };
    }

    return { type: 'none' as const, embedUrl: '' };
  }, [qvRawUnboxingVideoUrl]);

  const handleQvRealCustomerPhotosUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !quickViewProduct) return;
    setIsUploadingQvReviewAvatar(true);
    try {
      const uploaded: string[] = [];
      for (let i = 0; i < files.length; i++) {
        // Compress to lightweight WebP (max 900px, 0.88 quality) so page stays super fast
        const dataUrl = await processUploadedProductImage(files[i], 900, 0.88);
        uploaded.push(dataUrl);
      }
      const nextPhotos = [...qvRealCustomerPhotos, ...uploaded];
      await updateProduct(quickViewProduct.id, {
        realCustomerPhotos: nextPhotos,
        realCustomerGalleryEnabled: true
      });
      setQuickViewProduct(prev =>
        prev
          ? {
              ...prev,
              realCustomerPhotos: nextPhotos,
              realCustomerGalleryEnabled: true
            }
          : null
      );
      showToast(`${uploaded.length}টি বাস্তব ছবি (WebP) যুক্ত হয়েছে!`, 'success');
    } catch {
      showToast('ছবি আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingQvReviewAvatar(false);
      e.target.value = '';
    }
  };

  // Customer Account & Order History Sub-Page State
  const [isCustomerAccountOpen, setIsCustomerAccountOpen] = useState<boolean>(false);
  const [customerAuthTab, setCustomerAuthTab] = useState<'login' | 'signup' | 'forgot'>('login');
  const [returnToCheckoutAfterAuth, setReturnToCheckoutAfterAuth] = useState<boolean>(false);

  // Forgot Password (Mobile Number + SMS OTP) State
  const [forgotPhone, setForgotPhone] = useState<string>('');
  const [forgotStep, setForgotStep] = useState<'request_otp' | 'verify_reset'>('request_otp');
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [forgotOtpInput, setForgotOtpInput] = useState<string>('');
  const [forgotNewPassword, setForgotNewPassword] = useState<string>('');
  const [isSendingOtp, setIsSendingOtp] = useState<boolean>(false);
  const [otpSentViaSms, setOtpSentViaSms] = useState<boolean>(false);

  // Local fallback cache for customer accounts (Synced with Database `customers` in AppContext)
  const [localCustomerAccounts, setLocalCustomerAccounts] = useState<StorefrontCustomerAccount[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = window.localStorage.getItem('stockmaster_storefront_customers_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  // Unified Database + Local Customer Accounts Directory (Keyed by normalized 11-digit BD phone)
  const customerAccounts = useMemo<StorefrontCustomerAccount[]>(() => {
    const byPhone = new Map<string, StorefrontCustomerAccount>();

    // 1. Load all customers from the central Database (`customers` in AppContext)
    customers.forEach(c => {
      const norm = normalizeBdPhone(c.phone);
      if (norm.length < 10) return;
      byPhone.set(norm, {
        id: c.id,
        name: c.name,
        phone: norm,
        address: c.address || '',
        password: c.password || '',
        createdAt: c.createdAt
      });
    });

    // 2. Merge any local accounts (preserving password if database entry didn't have it yet)
    localCustomerAccounts.forEach(acc => {
      const norm = normalizeBdPhone(acc.phone);
      if (norm.length < 10) return;
      const existing = byPhone.get(norm);
      if (existing) {
        byPhone.set(norm, {
          ...existing,
          name: acc.name || existing.name,
          address: acc.address || existing.address,
          password: existing.password || acc.password || ''
        });
      } else {
        byPhone.set(norm, {
          ...acc,
          phone: norm
        });
      }
    });

    return Array.from(byPhone.values());
  }, [customers, localCustomerAccounts]);

  // Currently Logged-in Customer Phone (Persisted in localStorage)
  const [loggedInCustomerPhone, setLoggedInCustomerPhone] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    try {
      return window.localStorage.getItem('stockmaster_storefront_session_v1') || '';
    } catch {
      return '';
    }
  });

  const currentCustomerAccount = useMemo(() => {
    if (!loggedInCustomerPhone) return null;
    const norm = normalizeBdPhone(loggedInCustomerPhone);
    if (norm.length < 10) return null;
    return customerAccounts.find(acc => normalizeBdPhone(acc.phone) === norm) || null;
  }, [customerAccounts, loggedInCustomerPhone]);

  // Customer Login Form State (Mobile Number + Password only)
  const [loginPhone, setLoginPhone] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [showLoginPass, setShowLoginPass] = useState<boolean>(false);

  // Customer Sign Up Form State (Name + Mobile Number + Address + Password + Optional OTP Step)
  const [signupName, setSignupName] = useState<string>('');
  const [signupPhone, setSignupPhone] = useState<string>('');
  const [signupAddress, setSignupAddress] = useState<string>('');
  const [signupPassword, setSignupPassword] = useState<string>('');
  const [showSignupPass, setShowSignupPass] = useState<boolean>(false);
  const [showForgotPass, setShowForgotPass] = useState<boolean>(false);
  const [copiedProductLinkId, setCopiedProductLinkId] = useState<string | null>(null);
  const [signupStep, setSignupStep] = useState<'form' | 'verify_otp'>('form');
  const [signupGeneratedOtp, setSignupGeneratedOtp] = useState<string>('');
  const [signupOtpInput, setSignupOtpInput] = useState<string>('');
  const [isSendingSignupOtp, setIsSendingSignupOtp] = useState<boolean>(false);
  const [signupOtpSentViaSms, setSignupOtpSentViaSms] = useState<boolean>(false);

  // Profile Edit State inside Customer Account
  const [isEditingCustomerProfile, setIsEditingCustomerProfile] = useState<boolean>(false);
  const [editProfileName, setEditProfileName] = useState<string>('');
  const [editProfileAddress, setEditProfileAddress] = useState<string>('');

  // 1-Step DokanGhor Checkout Form State (Cash on Delivery Only) — Pre-initialized from stored localStorage customer identity for 9.3+ EMQ
  const [customerName, setCustomerName] = useState<string>(() => getFbCustomerIdentity().name || '');
  const [customerPhone, setCustomerPhone] = useState<string>(() => getFbCustomerIdentity().phone || '');
  const [deliveryAddress, setDeliveryAddress] = useState<string>(() => getFbCustomerIdentity().address || '');
  const [deliverySlot, setDeliverySlot] = useState<string>(DELIVERY_SLOTS[0]);
  const [selectedDeliveryZone, setSelectedDeliveryZone] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [orderNotes, setOrderNotes] = useState<string>('');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState<boolean>(false);
  const [checkoutErrorField, setCheckoutErrorField] = useState<'name' | 'phone' | 'address' | null>(null);
  const [isBrowserOnline, setIsBrowserOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Listen for Mobile Data / Wi-Fi connection changes in real time
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handleOnline = () => setIsBrowserOnline(true);
    const handleOffline = () => setIsBrowserOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync logged-in customer info into Checkout fields automatically & enrich Facebook Advanced Matching
  useEffect(() => {
    if (currentCustomerAccount) {
      setCustomerName(currentCustomerAccount.name);
      setCustomerPhone(currentCustomerAccount.phone);
      setDeliveryAddress(currentCustomerAccount.address);
      setEditProfileName(currentCustomerAccount.name);
      setEditProfileAddress(currentCustomerAccount.address);
      saveFbCustomerIdentity(
        {
          name: currentCustomerAccount.name,
          phone: currentCustomerAccount.phone,
          address: currentCustomerAccount.address
        },
        currentBusiness
      );
    }
  }, [currentCustomerAccount, currentBusiness]);

  // Progressive Real-Time Customer Identity Sync when typing in Checkout form (debounced & validated)
  useEffect(() => {
    const cleanName = customerName.trim();
    const cleanPhone = customerPhone.trim();
    const cleanAddr = deliveryAddress.trim();
    if (!cleanName && !cleanPhone && !cleanAddr) return;

    const timer = window.setTimeout(() => {
      const normPhone = normalizeBdPhone(cleanPhone);
      const validPhone = isValidBdPhone11(normPhone) ? normPhone : undefined;
      const resolvedCity =
        selectedDeliveryZone === 'inside_dhaka'
          ? extractLocationForMeta(cleanAddr, 'dhaka').ct
          : extractLocationForMeta(cleanAddr).ct;

      saveFbCustomerIdentity(
        {
          name: cleanName || undefined,
          phone: validPhone,
          address: cleanAddr || undefined,
          city: resolvedCity || undefined
        },
        currentBusiness
      );
    }, 500);

    return () => window.clearTimeout(timer);
  }, [customerName, customerPhone, deliveryAddress, selectedDeliveryZone, currentBusiness]);

  // Fire Facebook PageView + Flush any Offline CAPI Queue on Storefront Load
  const hasFiredPageViewRef = useRef<string>('');
  useEffect(() => {
    captureAndPersistFbParams();
    flushFbRetryQueue().catch(() => {});
    const pid = (currentBusiness.fbPixelId || '').trim();
    if (pid && currentBusiness.fbTrackingEnabled !== false && hasFiredPageViewRef.current !== pid) {
      hasFiredPageViewRef.current = pid;
      const pvEventId = generateMetaEventId('PageView');
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'PageView',
        eventIdOverride: pvEventId
      }).catch(() => {});
    }
  }, [currentBusiness.fbPixelId, currentBusiness.fbTrackingEnabled]);

  // Debounced Facebook Search Event
  useEffect(() => {
    const q = searchQuery.trim();
    if (q.length < 2) return;
    const timer = setTimeout(() => {
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'Search',
        customData: {
          search_string: q
        }
      }).catch(() => {});
    }, 900);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const persistCustomerAccounts = (next: StorefrontCustomerAccount[]) => {
    setLocalCustomerAccounts(next);
    try {
      window.localStorage.setItem('stockmaster_storefront_customers_v1', JSON.stringify(next));
    } catch {
      // Ignore storage errors
    }
  };

  const persistCustomerSession = (phone: string) => {
    setLoggedInCustomerPhone(phone);
    try {
      if (phone) {
        window.localStorage.setItem('stockmaster_storefront_session_v1', phone);
      } else {
        window.localStorage.removeItem('stockmaster_storefront_session_v1');
      }
    } catch {
      // Ignore storage errors
    }
  };

  // All Online Orders belonging to the logged-in customer (Order History)
  const customerOrderHistory = useMemo(() => {
    if (!currentCustomerAccount) return [];
    const targetPhone = normalizeBdPhone(currentCustomerAccount.phone);
    if (targetPhone.length < 10) return [];
    return onlineOrders.filter(o => {
      const orderPhone = normalizeBdPhone(o.customerPhone);
      return (
        orderPhone.length >= 10 &&
        (orderPhone === targetPhone ||
          orderPhone.endsWith(targetPhone) ||
          targetPhone.endsWith(orderPhone))
      );
    });
  }, [onlineOrders, currentCustomerAccount]);

  // Save scroll position before entering a sub-page (Product Details / Checkout / Account)
  const savedScrollYRef = useRef<number>(0);

  // Refs to read current overlay/filter state inside popstate listener
  const stateRef = useRef({
    selectedCategoryId,
    selectedBrandId,
    searchQuery,
    showMobileCategoryDrawer,
    isCartOpen,
    isCheckoutModalOpen,
    quickViewProduct,
    confirmedOrder,
    isCustomerAccountOpen,
    products
  });
  stateRef.current = {
    selectedCategoryId,
    selectedBrandId,
    searchQuery,
    showMobileCategoryDrawer,
    isCartOpen,
    isCheckoutModalOpen,
    quickViewProduct,
    confirmedOrder,
    isCustomerAccountOpen,
    products
  };

  const getStorefrontBaseUrl = (catId = selectedCategoryId) =>
    catId && catId !== 'all' ? `/?category=${encodeURIComponent(catId)}` : '/';

  const pushStorefrontHistory = (meta: Record<string, unknown> = {}, targetUrl?: string) => {
    try {
      const nextUrl = targetUrl || `${window.location.pathname}${window.location.search}`;
      window.history.pushState(
        {
          routeMode: 'storefront',
          sfCategory: selectedCategoryId,
          ...meta
        },
        '',
        nextUrl
      );
    } catch {
      // Ignore in restricted iframe environments
    }
  };

  // Sync dynamic document title so shared links & browser tabs show the current Product Name or Global SEO Title
  useEffect(() => {
    const shopTitle = currentBusiness.name.replace('স্টকমাস্টার বিডি - ', '');
    if (quickViewProduct) {
      document.title = `${quickViewProduct.nameBn} — ৳${quickViewProduct.retailPrice} | ${shopTitle}`;
    } else if (isCheckoutModalOpen) {
      document.title = `চেকআউট | ${shopTitle}`;
    } else if (isCustomerAccountOpen) {
      document.title = `কাস্টমার একাউন্ট | ${shopTitle}`;
    } else if (currentBusiness.seoTitle && currentBusiness.seoTitle.trim() !== '') {
      document.title = currentBusiness.seoTitle.trim();
    } else {
      document.title = `${shopTitle} — অনলাইন সুপার শপ ও হোম ডেলিভারি`;
    }
  }, [
    quickViewProduct,
    isCheckoutModalOpen,
    isCustomerAccountOpen,
    currentBusiness.name,
    currentBusiness.seoTitle
  ]);

  // Deep-Link URL Resolver: When a visitor opens a shared product link (/product/slug--id or ?product=id) directly
  const hasResolvedInitialUrlRef = useRef<boolean>(false);
  useEffect(() => {
    if (hasResolvedInitialUrlRef.current || products.length === 0) return;
    const { pathname, search } = window.location;
    const matchedProd = findProductFromLocation(products, pathname, search);
    if (matchedProd) {
      hasResolvedInitialUrlRef.current = true;
      setQuickViewProduct(matchedProd);
      setQuickViewQty(1);
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });

      const activeVar = getActiveVariant(matchedProd);
      const unitRetail = activeVar ? activeVar.retailPrice : matchedProd.retailPrice;
      const catObj = categories.find(c => c.id === matchedProd.categoryId);
      const viewEventId = generateMetaEventId('ViewContent');
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'ViewContent',
        eventIdOverride: viewEventId,
        customData: buildMetaProductCustomData({
          product: matchedProd,
          activeVariant: activeVar || undefined,
          quantity: 1,
          unitPrice: unitRetail,
          totalValue: unitRetail,
          categoryName: catObj ? catObj.nameBn : 'Grocery'
        })
      }).catch(() => {});
      return;
    }

    const cleanPath = pathname.replace(/\/+$/, '');
    if (cleanPath === '/checkout') {
      hasResolvedInitialUrlRef.current = true;
      setIsCheckoutModalOpen(true);
    } else if (cleanPath === '/account' || cleanPath === '/customer-login') {
      hasResolvedInitialUrlRef.current = true;
      setIsCustomerAccountOpen(true);
    } else if (search) {
      const params = new URLSearchParams(search);
      const catParam = params.get('category');
      if (catParam && categories.some(c => c.id === catParam)) {
        hasResolvedInitialUrlRef.current = true;
        setSelectedCategoryId(catParam);
      }
    }
  }, [products, categories]);

  const handleCopyProductLink = async (product: Product) => {
    const prodPath = buildProductPath(product);
    const fullUrl = `${window.location.origin}${prodPath}`;
    try {
      await navigator.clipboard.writeText(fullUrl);
      setCopiedProductLinkId(product.id);
      setTimeout(() => {
        setCopiedProductLinkId(prev => (prev === product.id ? null : prev));
      }, 2500);
      showToast('পণ্যের ডিরেক্ট লিংক কপি হয়েছে! এখন যেকোনো জায়গায় শেয়ার করতে পারবেন।', 'success');
    } catch {
      showToast(`পণ্যের লিংক: ${fullUrl}`, 'info');
    }
  };

  const closeAllSubPagesAndRestoreScroll = () => {
    setDirectBuyItem(null);
    setQuickViewProduct(null);
    setIsCheckoutModalOpen(false);
    setConfirmedOrder(null);
    setIsCustomerAccountOpen(false);
    setIsCartOpen(false);
    pushStorefrontHistory({ sfOverlay: null }, getStorefrontBaseUrl(selectedCategoryId));
    const targetY = savedScrollYRef.current || 0;
    setTimeout(() => {
      window.scrollTo({ top: targetY, behavior: 'instant' as ScrollBehavior });
    }, 10);
  };

  const handleSelectCategory = (catId: string) => {
    const nextUrl = getStorefrontBaseUrl(catId);
    pushStorefrontHistory({ sfCategory: catId, sfOverlay: null }, nextUrl);
    setQuickViewProduct(null);
    setIsCheckoutModalOpen(false);
    setConfirmedOrder(null);
    setIsCustomerAccountOpen(false);
    setSelectedCategoryId(catId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openQuickView = (product: Product) => {
    if (
      !quickViewProduct &&
      !isCheckoutModalOpen &&
      !confirmedOrder &&
      !isCustomerAccountOpen
    ) {
      savedScrollYRef.current = window.scrollY;
    }
    const productPath = buildProductPath(product);
    pushStorefrontHistory({ sfOverlay: 'quick_view', productId: product.id }, productPath);
    setIsCheckoutModalOpen(false);
    setConfirmedOrder(null);
    setIsCustomerAccountOpen(false);
    setIsCartOpen(false);
    setQuickViewProduct(product);
    setQuickViewQty(1);
    setActiveGalleryIndex(0);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });

    const activeVar = getActiveVariant(product);
    const unitRetail = activeVar ? activeVar.retailPrice : product.retailPrice;
    const catObj = categories.find(c => c.id === product.categoryId);
    const viewEventId = generateMetaEventId('ViewContent');
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'ViewContent',
      eventIdOverride: viewEventId,
      customData: buildMetaProductCustomData({
        product,
        activeVariant: activeVar || undefined,
        quantity: 1,
        unitPrice: unitRetail,
        totalValue: unitRetail,
        categoryName: catObj ? catObj.nameBn : 'Grocery'
      })
    }).catch(() => {});
  };

  const openCartDrawer = () => {
    if (Object.keys(cart).length > 0) {
      setDirectBuyItem(null);
      openCheckoutModal(cart);
      return;
    }
    openCheckoutModal();
  };

  const openCheckoutModal = (explicitCart?: Record<string, CartEntry> | React.MouseEvent) => {
    if (
      !quickViewProduct &&
      !isCheckoutModalOpen &&
      !confirmedOrder &&
      !isCustomerAccountOpen
    ) {
      savedScrollYRef.current = window.scrollY;
    }
    pushStorefrontHistory({ sfOverlay: 'checkout' }, '/checkout');
    setQuickViewProduct(null);
    setConfirmedOrder(null);
    setIsCustomerAccountOpen(false);
    setIsCartOpen(false);
    setCheckoutErrorField(null);

    const storedFbIdentity = getFbCustomerIdentity();
    const resolvedName = currentCustomerAccount?.name || customerName.trim() || storedFbIdentity.name || '';
    const resolvedPhone = currentCustomerAccount?.phone || customerPhone.trim() || storedFbIdentity.phone || '';
    const resolvedAddress = currentCustomerAccount?.address || deliveryAddress.trim() || storedFbIdentity.address || '';

    if (currentCustomerAccount) {
      setCustomerName(currentCustomerAccount.name);
      setCustomerPhone(currentCustomerAccount.phone);
      setDeliveryAddress(currentCustomerAccount.address);
    } else {
      if (!customerName && resolvedName) setCustomerName(resolvedName);
      if (!customerPhone && resolvedPhone) setCustomerPhone(resolvedPhone);
      if (!deliveryAddress && resolvedAddress) setDeliveryAddress(resolvedAddress);
    }

    checkoutSessionKeyRef.current = `chk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    firedLeadPhoneRef.current = '';
    setIsCheckoutModalOpen(true);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });

    const isCartRecord =
      explicitCart &&
      typeof explicitCart === 'object' &&
      !('nativeEvent' in explicitCart) &&
      !('preventDefault' in explicitCart);
    const activeCartMap = isCartRecord
      ? (explicitCart as Record<string, CartEntry>)
      : Object.keys(cart).length > 0
      ? cart
      : directBuyItem
      ? { [directBuyItem.cartKey]: directBuyItem }
      : {};
    const entriesNow = Object.values(activeCartMap);
    if (entriesNow.length > 0) {
      const subNow = entriesNow.reduce((s, it) => {
        const p = it.variant ? it.variant.retailPrice : it.product.retailPrice;
        return s + p * it.quantity;
      }, 0);
      const qtyNow = entriesNow.reduce((s, it) => s + it.quantity, 0);
      const { fbp, fbc } = captureAndPersistFbParams();
      const resolvedCity =
        selectedDeliveryZone === 'inside_dhaka'
          ? extractLocationForMeta(resolvedAddress, 'dhaka').ct
          : extractLocationForMeta(resolvedAddress, storedFbIdentity.city).ct;
      const checkoutCustomerIdentity = {
        name: resolvedName || undefined,
        phone: resolvedPhone || undefined,
        email: storedFbIdentity.email || undefined,
        address: resolvedAddress || undefined,
        city: resolvedCity,
        externalId:
          normalizeCustomerDataForMeta({ phone: resolvedPhone }).ph ||
          currentCustomerAccount?.id ||
          storedFbIdentity.externalId ||
          undefined,
        fbp,
        fbc
      };
      saveFbCustomerIdentity(checkoutCustomerIdentity, currentBusiness);
      const initiateCheckoutEventId = generateMetaEventId('InitiateCheckout');
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'InitiateCheckout',
        eventIdOverride: initiateCheckoutEventId,
        customer: checkoutCustomerIdentity,
        customData: {
          content_ids: entriesNow.map(it => it.product.id),
          content_type: 'product',
          value: subNow,
          num_items: qtyNow,
          contents: entriesNow.map(it => ({
            id: it.product.id,
            quantity: it.quantity,
            item_price: it.variant ? it.variant.retailPrice : it.product.retailPrice,
            title: it.product.nameBn
          }))
        }
      }).catch(() => {});
    }
  };

  const openCustomerAccountPage = (
    initialTab: 'login' | 'signup' | 'forgot' = 'login',
    fromCheckout = false
  ) => {
    if (
      !quickViewProduct &&
      !isCheckoutModalOpen &&
      !confirmedOrder &&
      !isCustomerAccountOpen
    ) {
      savedScrollYRef.current = window.scrollY;
    }
    pushStorefrontHistory({ sfOverlay: 'customer_account' }, '/account');
    setCustomerAuthTab(initialTab);
    setForgotStep('request_otp');
    setSignupStep('form');
    setReturnToCheckoutAfterAuth(fromCheckout);
    setQuickViewProduct(null);
    setIsCheckoutModalOpen(false);
    setConfirmedOrder(null);
    setIsCartOpen(false);
    setShowMobileCategoryDrawer(false);
    setIsCustomerAccountOpen(true);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  };

  const openMobileDrawer = () => {
    pushStorefrontHistory({ sfOverlay: 'mobile_categories' });
    setShowMobileCategoryDrawer(true);
  };

  // Browser / Mobile Hardware Back & Forward Button handler with full Product-to-Product URL support
  useEffect(() => {
    const onPopState = (event: PopStateEvent) => {
      const s = stateRef.current;
      const { pathname, search } = window.location;
      const cleanPath = pathname.replace(/\/+$/, '');

      // 1. Check if the URL we navigated to is a Product URL (/product/... or ?product=...)
      const urlProduct = findProductFromLocation(s.products, pathname, search);
      if (urlProduct) {
        setConfirmedOrder(null);
        setIsCheckoutModalOpen(false);
        setIsCustomerAccountOpen(false);
        setIsCartOpen(false);
        setQuickViewProduct(urlProduct);
        setQuickViewQty(1);
        window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
        return;
      }

      // 2. Check if the URL is a dedicated sub-page (/checkout, /account)
      if (cleanPath === '/checkout') {
        setQuickViewProduct(null);
        setConfirmedOrder(null);
        setIsCustomerAccountOpen(false);
        setIsCheckoutModalOpen(true);
        return;
      }
      if (cleanPath === '/account' || cleanPath === '/customer-login') {
        setQuickViewProduct(null);
        setConfirmedOrder(null);
        setIsCheckoutModalOpen(false);
        setIsCustomerAccountOpen(true);
        return;
      }

      // 3. Otherwise we are returning to the main storefront catalog
      if (s.confirmedOrder) {
        setConfirmedOrder(null);
        window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
        return;
      }
      if (s.isCheckoutModalOpen) {
        setIsCheckoutModalOpen(false);
        const y = savedScrollYRef.current || 0;
        setTimeout(() => window.scrollTo({ top: y, behavior: 'instant' as ScrollBehavior }), 10);
        return;
      }
      if (s.isCustomerAccountOpen) {
        setIsCustomerAccountOpen(false);
        const y = savedScrollYRef.current || 0;
        setTimeout(() => window.scrollTo({ top: y, behavior: 'instant' as ScrollBehavior }), 10);
        return;
      }
      if (s.isCartOpen) {
        setIsCartOpen(false);
        return;
      }
      if (s.quickViewProduct) {
        setQuickViewProduct(null);
        const y = savedScrollYRef.current || 0;
        setTimeout(() => window.scrollTo({ top: y, behavior: 'instant' as ScrollBehavior }), 10);
        return;
      }
      if (s.showMobileCategoryDrawer) {
        setShowMobileCategoryDrawer(false);
        return;
      }
      if (s.selectedCategoryId !== 'all' || s.selectedBrandId !== 'all' || s.searchQuery !== '') {
        const params = new URLSearchParams(search);
        const catFromUrl = params.get('category');
        const targetCat =
          catFromUrl ||
          (event.state && typeof event.state.sfCategory === 'string'
            ? event.state.sfCategory
            : 'all');
        setSelectedCategoryId(targetCat === s.selectedCategoryId ? 'all' : targetCat);
        setSelectedBrandId('all');
        setSearchQuery('');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };

    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const persistCart = (next: Record<string, CartEntry>) => {
    setCart(next);
    try {
      window.localStorage.setItem('stockmaster_dokanghor_cart_v3', JSON.stringify(next));
    } catch {
      // Ignore storage errors
    }
  };

  // Total available stock across all outlets/warehouses (respecting manual product & variation Out of Stock flags)
  const getProductAvailableStock = (product: Product): number => {
    if (product.isOutOfStock) return 0;
    if (
      Array.isArray(product.variants) &&
      product.variants.length > 0 &&
      product.variants.every(v => Boolean(v.outOfStock))
    ) {
      return 0;
    }
    const retailBranchStock = product.stockByOutlet['outlet_01'] ?? 0;
    const totalOrgStock = Object.values(product.stockByOutlet).reduce((s, q) => s + (q || 0), 0);
    return Math.max(retailBranchStock, totalOrgStock);
  };

  const buildCartKey = (productId: string, variant?: ProductVariant) =>
    variant ? `${productId}__${variant.id}` : productId;

  const addToCart = (
    product: Product,
    delta = 1,
    silent = false,
    explicitVariant?: ProductVariant,
    bypassVariantCheck = false
  ) => {
    const available = getProductAvailableStock(product);
    if (available <= 0) {
      showToast(language === 'bn' ? 'দুঃখিত, এই পণ্যটি বর্তমানে স্টকে নেই (স্টক শেষ)' : 'Out of stock', 'error');
      return;
    }

    if (explicitVariant?.outOfStock) {
      showToast(
        language === 'bn'
          ? `দুঃখিত, "${explicitVariant.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`
          : `"${explicitVariant.label}" is out of stock`,
        'error'
      );
      return;
    }

    const hasVariants = Boolean(product.variants && product.variants.length > 0);
    const explicitlyChosen = getExplicitSelectedVariant(product);

    if (
      delta > 0 &&
      (isVariantSelectionRequired || !showVariantsOnHomePage) &&
      hasVariants &&
      (!explicitlyChosen || (!showVariantsOnHomePage && !quickViewProduct)) &&
      !bypassVariantCheck
    ) {
      setVariantModalError(false);
      setShowVariantModalSizeChart(false);
      setVariantSelectionModal({
        product,
        qty: delta,
        mode: 'add_to_cart',
        chosenVariantId: selectedVariantByProduct[product.id] || '',
        chosenColorId: selectedColorByProduct[product.id] || ''
      });
      return;
    }

    const activeVariant =
      explicitVariant !== undefined
        ? explicitVariant
        : explicitlyChosen !== undefined
        ? explicitlyChosen
        : getActiveVariant(product);
    if (activeVariant?.outOfStock) {
      showToast(
        language === 'bn'
          ? `দুঃখিত, "${activeVariant.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`
          : `"${activeVariant.label}" is out of stock`,
        'error'
      );
      return;
    }
    const key = buildCartKey(product.id, activeVariant);
    const existingQty = cart[key]?.quantity || 0;
    const nextQty = existingQty + delta;

    if (nextQty > available) {
      showToast(
        language === 'bn'
          ? `সর্বোচ্চ স্টক সীমা (${available} টি) অতিক্রম করেছে`
          : `Max available stock (${available}) reached`,
        'info'
      );
      return;
    }

    const updated = { ...cart };
    if (nextQty <= 0) {
      delete updated[key];
    } else {
      updated[key] = {
        cartKey: key,
        product,
        variant: activeVariant,
        quantity: nextQty
      };
    }
    setDirectBuyItem(null);
    persistCart(updated);

    if (delta > 0) {
      const unitRetail = activeVariant ? activeVariant.retailPrice : product.retailPrice;
      const catObj = categories.find(c => c.id === product.categoryId);
      const addToCartEventId = generateMetaEventId('AddToCart');
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'AddToCart',
        eventIdOverride: addToCartEventId,
        customData: buildMetaProductCustomData({
          product,
          activeVariant: activeVariant || undefined,
          quantity: delta,
          unitPrice: unitRetail,
          totalValue: unitRetail * delta,
          categoryName: catObj ? catObj.nameBn : 'Grocery'
        })
      }).catch(() => {});
    }

    if (!silent && delta > 0 && existingQty === 0) {
      const varLabel = activeVariant ? ` (${activeVariant.label})` : '';
      showToast(
        language === 'bn'
          ? `"${product.nameBn}${varLabel}" ব্যাগে যোগ করা হয়েছে`
          : `"${product.nameEn}${varLabel}" added to cart`,
        'success'
      );
    }
  };

  // DokanGhor Signature 1-Click "অর্ডার করুন" (Direct Buy Now -> Opens Checkout Form Immediately!)
  const handleDirectOrderNow = (
    product: Product,
    qty = 1,
    explicitVariant?: ProductVariant,
    bypassVariantCheck = false
  ) => {
    const available = getProductAvailableStock(product);
    if (available <= 0) {
      showToast(language === 'bn' ? 'দুঃখিত, এই পণ্যটি বর্তমানে স্টকে নেই (স্টক শেষ)' : 'Out of stock', 'error');
      return;
    }

    if (explicitVariant?.outOfStock) {
      showToast(
        language === 'bn'
          ? `দুঃখিত, "${explicitVariant.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`
          : `"${explicitVariant.label}" is out of stock`,
        'error'
      );
      return;
    }

    const hasVariants = Boolean(product.variants && product.variants.length > 0);
    const explicitlyChosen = getExplicitSelectedVariant(product);

    if (
      (isVariantSelectionRequired || !showVariantsOnHomePage) &&
      hasVariants &&
      (!explicitlyChosen || (!showVariantsOnHomePage && !quickViewProduct)) &&
      !bypassVariantCheck
    ) {
      setVariantModalError(false);
      setShowVariantModalSizeChart(false);
      setVariantSelectionModal({
        product,
        qty,
        mode: 'order_now',
        chosenVariantId: selectedVariantByProduct[product.id] || '',
        chosenColorId: selectedColorByProduct[product.id] || ''
      });
      return;
    }

    const activeVariant =
      explicitVariant !== undefined
        ? explicitVariant
        : explicitlyChosen !== undefined
        ? explicitlyChosen
        : getActiveVariant(product);
    if (activeVariant?.outOfStock) {
      showToast(
        language === 'bn'
          ? `দুঃখিত, "${activeVariant.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`
          : `"${activeVariant.label}" is out of stock`,
        'error'
      );
      return;
    }
    const key = buildCartKey(product.id, activeVariant);
    const singleEntry: CartEntry = {
      cartKey: key,
      product,
      variant: activeVariant,
      quantity: Math.min(qty, available)
    };
    // Strictly isolate this 1-Click Direct Buy order to ONLY the single selected product (ignore/bypass lingering global cart items)
    setDirectBuyItem(singleEntry);
    setQuickViewProduct(null);
    setIsCartOpen(false);
    openCheckoutModal({ [key]: singleEntry });
  };

  const removeFromCart = (cartKey: string) => {
    if (directBuyItem && directBuyItem.cartKey === cartKey) {
      setDirectBuyItem(null);
      closeAllSubPagesAndRestoreScroll();
      return;
    }
    const updated = { ...cart };
    delete updated[cartKey];
    persistCart(updated);
  };

  const clearCart = () => {
    setDirectBuyItem(null);
    setCart({});
    try {
      window.localStorage.removeItem('stockmaster_dokanghor_cart_v3');
    } catch {
      // Ignore storage errors
    }
  };

  const cartEntries: CartEntry[] = useMemo(() => Object.values(cart), [cart]);

  // When in Direct Buy mode ("এখনই অর্ডার করুন"), checkout is strictly scoped to that single selected product!
  const checkoutEntries: CartEntry[] = useMemo(() => {
    if (directBuyItem) return [directBuyItem];
    return cartEntries;
  }, [directBuyItem, cartEntries]);

  const totalCartItems = useMemo(
    () => cartEntries.reduce((sum, item) => sum + item.quantity, 0),
    [cartEntries]
  );
  const cartSubtotal = useMemo(
    () =>
      cartEntries.reduce((sum, item) => {
        const unitRetail = item.variant ? item.variant.retailPrice : item.product.retailPrice;
        return sum + unitRetail * item.quantity;
      }, 0),
    [cartEntries]
  );

  const totalCheckoutItems = useMemo(
    () => checkoutEntries.reduce((sum, item) => sum + item.quantity, 0),
    [checkoutEntries]
  );
  const checkoutSubtotal = useMemo(
    () =>
      checkoutEntries.reduce((sum, item) => {
        const unitRetail = item.variant ? item.variant.retailPrice : item.product.retailPrice;
        return sum + unitRetail * item.quantity;
      }, 0),
    [checkoutEntries]
  );

  // Dynamic Delivery Charge configured from Admin Dashboard (Inside Dhaka / Outside Dhaka / Free Delivery Toggle + Spin the Wheel Reward + 4 Smart Delivery Offers)
  const rawInsideDhakaFee =
    currentBusiness.insideDhakaDeliveryCharge ?? currentBusiness.ecommerceDeliveryCharge ?? 60;
  const rawOutsideDhakaFee = currentBusiness.outsideDhakaDeliveryCharge ?? 120;
  const isHalfDeliveryOfferEnabled = Boolean(currentBusiness.halfDeliveryOfferEnabled);
  const deliveryDiscountPct = Math.min(
    90,
    Math.max(10, Number(currentBusiness.deliveryDiscountPercent || 50))
  );
  const insideDhakaFee = isHalfDeliveryOfferEnabled
    ? Math.round(rawInsideDhakaFee * (1 - deliveryDiscountPct / 100))
    : rawInsideDhakaFee;
  const outsideDhakaFee = isHalfDeliveryOfferEnabled
    ? Math.round(rawOutsideDhakaFee * (1 - deliveryDiscountPct / 100))
    : rawOutsideDhakaFee;
  const isAdminFreeDeliveryEnabled = Boolean(currentBusiness.freeDeliveryEnabled);

  // Offer #7: Happy Hour / Flash Free Delivery Live Timer Window (Auto-expires when countdown hits 0)
  const [flashNowMs, setFlashNowMs] = useState<number>(() => Date.now());
  useEffect(() => {
    const hasFlashConfig =
      Boolean(currentBusiness.flashFreeDeliveryEnabled) ||
      Boolean(currentBusiness.flashFreeDeliveryScheduleEnabled);
    if (!hasFlashConfig) return;
    setFlashNowMs(Date.now());
    const id = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setFlashNowMs(Date.now());
    }, 1000);
    return () => window.clearInterval(id);
  }, [
    currentBusiness.flashFreeDeliveryEnabled,
    currentBusiness.flashFreeDeliveryEndTime,
    currentBusiness.flashFreeDeliveryScheduleEnabled,
    currentBusiness.flashFreeDeliveryStartHour,
    currentBusiness.flashFreeDeliveryEndHour
  ]);

  const flashDeliveryStatus = useMemo(() => {
    // 1. Check explicit countdown end timestamp
    if (
      currentBusiness.flashFreeDeliveryEnabled &&
      Number(currentBusiness.flashFreeDeliveryEndTime || 0) > flashNowMs
    ) {
      const remSec = Math.max(
        0,
        Math.floor((Number(currentBusiness.flashFreeDeliveryEndTime) - flashNowMs) / 1000)
      );
      return { active: remSec > 0, remainingSeconds: remSec };
    }
    // 2. Check daily recurring Happy Hour schedule (e.g. 21:00 to 23:59)
    if (currentBusiness.flashFreeDeliveryScheduleEnabled) {
      const startStr = (currentBusiness.flashFreeDeliveryStartHour || '21:00').trim();
      const endStr = (currentBusiness.flashFreeDeliveryEndHour || '23:59').trim();
      const [sh = 21, sm = 0] = startStr.split(':').map(n => parseInt(n, 10) || 0);
      const [eh = 23, em = 59] = endStr.split(':').map(n => parseInt(n, 10) || 0);
      const nowDate = new Date(flashNowMs);
      const curSecOfDay =
        nowDate.getHours() * 3600 + nowDate.getMinutes() * 60 + nowDate.getSeconds();
      const startSecOfDay = sh * 3600 + sm * 60;
      const endSecOfDay = eh * 3600 + em * 60 + 59;
      if (startSecOfDay <= endSecOfDay) {
        if (curSecOfDay >= startSecOfDay && curSecOfDay <= endSecOfDay) {
          return { active: true, remainingSeconds: Math.max(1, endSecOfDay - curSecOfDay) };
        }
      } else {
        // Cross-midnight window
        if (curSecOfDay >= startSecOfDay) {
          return {
            active: true,
            remainingSeconds: Math.max(1, 86400 - curSecOfDay + endSecOfDay)
          };
        }
        if (curSecOfDay <= endSecOfDay) {
          return { active: true, remainingSeconds: Math.max(1, endSecOfDay - curSecOfDay) };
        }
      }
    }
    return { active: false, remainingSeconds: 0 };
  }, [
    currentBusiness.flashFreeDeliveryEnabled,
    currentBusiness.flashFreeDeliveryEndTime,
    currentBusiness.flashFreeDeliveryScheduleEnabled,
    currentBusiness.flashFreeDeliveryStartHour,
    currentBusiness.flashFreeDeliveryEndHour,
    flashNowMs
  ]);

  const isFlashFreeDeliveryActive = flashDeliveryStatus.active;
  const flashCountdownLabelBn = useMemo(() => {
    const sec = flashDeliveryStatus.remainingSeconds;
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${toBanglaCountdownDigits(h, 2)} ঘণ্টা ${toBanglaCountdownDigits(
      m,
      2
    )} মিনিট ${toBanglaCountdownDigits(s, 2)} সেকেন্ড`;
  }, [flashDeliveryStatus.remainingSeconds, toBanglaCountdownDigits]);

  // Automatically consume & clear Spin Wheel reward if an order in onlineOrders has already used it (1-Order Limit)
  useEffect(() => {
    if (!claimedSpinReward) return;
    if (dailySpinRecord?.used) {
      setClaimedSpinReward(null);
      try {
        window.localStorage.removeItem('stockmaster_spin_reward_v1');
      } catch {
        // ignore
      }
      return;
    }

    const spinPhone = normalizeBdPhone(dailySpinRecord?.phone || customerPhone || '');
    const spunTimeMs = dailySpinRecord?.spunAt ? new Date(dailySpinRecord.spunAt).getTime() : 0;

    const alreadyUsedOrder = onlineOrders.find(o => {
      if (o.orderStatus === 'cancelled') return false;
      const hasSpinNote = Boolean(o.notes && o.notes.includes('স্পিন দ্য হুইল পুরস্কার'));
      if (!hasSpinNote) return false;
      if (spinPhone && isValidBdPhone11(spinPhone)) {
        if (normalizeBdPhone(o.customerPhone) !== spinPhone) return false;
      }
      if (spunTimeMs > 0 && !Number.isNaN(spunTimeMs)) {
        const orderTimeMs = new Date(o.createdAt).getTime();
        if (!Number.isNaN(orderTimeMs) && orderTimeMs + 5000 < spunTimeMs) return false;
      }
      return true;
    });

    if (alreadyUsedOrder) {
      setClaimedSpinReward(null);
      try {
        window.localStorage.removeItem('stockmaster_spin_reward_v1');
      } catch {
        // ignore
      }
      if (dailySpinRecord && !dailySpinRecord.used) {
        const updatedLock = {
          ...dailySpinRecord,
          used: true,
          usedOrderNo: alreadyUsedOrder.orderNo
        };
        setDailySpinRecord(updatedLock);
        try {
          window.localStorage.setItem('stockmaster_spin_daily_lock_v1', JSON.stringify(updatedLock));
        } catch {
          // ignore
        }
      }
    }
  }, [claimedSpinReward, dailySpinRecord, customerPhone, onlineOrders]);

  const isSpinWheelActive =
    currentBusiness.spinWheelEnabled !== false && !dailySpinRecord?.used;
  const isSpinFreeDelivery =
    isSpinWheelActive && claimedSpinReward?.type === 'free_delivery';

  // Smart Quantity-Based Free Delivery ("2 পিস বা 3 পিস কিনলে ডেলিভারি ফ্রি")
  const isQtyFreeDeliveryEnabled = Boolean(currentBusiness.freeDeliveryByQtyEnabled);
  const freeDeliveryMinQty = Math.max(1, currentBusiness.freeDeliveryMinQty || 2);
  const effectiveTotalItems = isCheckoutModalOpen ? totalCheckoutItems : totalCartItems;
  const effectiveSubtotal = isCheckoutModalOpen ? checkoutSubtotal : cartSubtotal;
  const isQtyFreeDeliveryUnlocked =
    isQtyFreeDeliveryEnabled && effectiveTotalItems >= freeDeliveryMinQty;
  const remainingQtyForFreeDelivery = isQtyFreeDeliveryEnabled
    ? Math.max(0, freeDeliveryMinQty - effectiveTotalItems)
    : 0;

  // Offer #1: Minimum Order Amount Free Delivery + Animated Live Progress Bar (e.g., ৳1,500 or ৳2,000)
  const isMinAmountFreeDeliveryEnabled = Boolean(currentBusiness.freeDeliveryByMinAmountEnabled);
  const freeDeliveryMinOrderAmt = Math.max(
    100,
    Number(currentBusiness.freeDeliveryMinOrder || 1500)
  );
  const isMinAmountFreeDeliveryUnlocked =
    isMinAmountFreeDeliveryEnabled && effectiveSubtotal >= freeDeliveryMinOrderAmt;
  const remainingAmtForFreeDelivery = isMinAmountFreeDeliveryEnabled
    ? Math.max(0, freeDeliveryMinOrderAmt - effectiveSubtotal)
    : 0;
  const minAmountProgressPct = isMinAmountFreeDeliveryEnabled
    ? Math.min(100, Math.round((effectiveSubtotal / freeDeliveryMinOrderAmt) * 100))
    : 0;

  // Cart-specific Minimum Order Amount Progress (for Shopping Bag Drawer)
  const isCartMinAmountUnlocked =
    isMinAmountFreeDeliveryEnabled && cartSubtotal >= freeDeliveryMinOrderAmt;
  const cartRemainingAmtForFreeDelivery = isMinAmountFreeDeliveryEnabled
    ? Math.max(0, freeDeliveryMinOrderAmt - cartSubtotal)
    : 0;
  const cartMinAmountProgressPct = isMinAmountFreeDeliveryEnabled
    ? Math.min(100, Math.round((cartSubtotal / freeDeliveryMinOrderAmt) * 100))
    : 0;

  // Offer #6: Product-Specific Free Delivery Badge & Rule (if any product in order has freeDelivery = true, whole order delivery is free)
  const isProductSpecificFreeDeliveryEnabled =
    currentBusiness.productSpecificFreeDeliveryEnabled !== false;
  const activeOrderEntries = isCheckoutModalOpen ? checkoutEntries : cartEntries;
  const hasFreeDeliveryProductInOrder =
    isProductSpecificFreeDeliveryEnabled &&
    activeOrderEntries.some(e => Boolean(e.product.freeDelivery || e.product.freeDeliveryOnLanding));
  const hasFreeDeliveryProductInCart =
    isProductSpecificFreeDeliveryEnabled &&
    cartEntries.some(e => Boolean(e.product.freeDelivery || e.product.freeDeliveryOnLanding));

  // Smart Stock Out Image Overlay Style ('center_glass' default, or 'diagonal_ribbon' | 'bottom_banner' | 'classic_corner')
  const stockOutBadgeStyle: StockOutBadgeDesign =
    currentBusiness.stockOutBadgeStyle || 'center_glass';

  const stockOutStyleOptions: Array<{
    id: StockOutBadgeDesign;
    label: string;
    shortLabel: string;
  }> = [
    {
      id: 'center_glass',
      label: '১. ছবির মাঝে স্মার্ট ব্যাজ (Smart Image Overlay)',
      shortLabel: '১. ছবির মাঝে স্মার্ট ভিউ'
    },
    {
      id: 'diagonal_ribbon',
      label: '২. ছবির ওপর কোণাকুণি রিবন (Diagonal Ribbon)',
      shortLabel: '২. কোণাকুণি রিবন'
    },
    {
      id: 'bottom_banner',
      label: '৩. ছবির নিচে ফুল-বার (Bottom Image Banner)',
      shortLabel: '৩. ছবির নিচে বার'
    },
    {
      id: 'classic_corner',
      label: '৪. আগের ক্লাসিক কর্নার ব্যাজ (Classic Corner)',
      shortLabel: '৪. আগের ক্লাসিক ভিউ'
    }
  ];

  const renderStockOutImageOverlay = (isOutOfStock: boolean, isLarge = false) => {
    if (!isOutOfStock) return null;

    if (stockOutBadgeStyle === 'classic_corner') {
      return (
        <span
          className={`absolute ${
            isLarge ? 'top-2.5 left-2.5 text-xs px-3 py-1' : 'top-2 left-2 text-[10px] px-2 py-0.5'
          } bg-slate-900/90 text-white font-bold rounded-lg z-10 pointer-events-none shadow-2xs`}
        >
          স্টক শেষ
        </span>
      );
    }

    if (stockOutBadgeStyle === 'diagonal_ribbon') {
      return (
        <div className="absolute inset-0 bg-slate-900/25 backdrop-blur-[1px] flex items-center justify-center z-10 pointer-events-none overflow-hidden">
          <div
            className={`w-[140%] -rotate-12 bg-gradient-to-r from-slate-950/95 via-[#c30000]/95 to-slate-950/95 text-white text-center font-extrabold tracking-wide shadow-lg border-y border-white/30 ${
              isLarge ? 'py-2 text-sm sm:text-base' : 'py-1 text-[11px] sm:text-xs'
            }`}
          >
            🚫 স্টক শেষ · STOCK OUT
          </div>
        </div>
      );
    }

    if (stockOutBadgeStyle === 'bottom_banner') {
      return (
        <div className="absolute inset-0 bg-slate-900/15 z-10 pointer-events-none flex flex-col justify-end">
          <div
            className={`w-full bg-gradient-to-r from-slate-950/95 via-rose-900/95 to-slate-950/95 backdrop-blur-xs text-white font-extrabold text-center border-t border-white/20 flex items-center justify-center gap-1.5 ${
              isLarge ? 'py-2.5 px-3 text-xs sm:text-sm' : 'py-1.5 px-2 text-[10px] sm:text-xs'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse shrink-0" />
            <span>বর্তমানে স্টক শেষ (Stock Out)</span>
          </div>
        </div>
      );
    }

    // Default: 'center_glass' — Smart, high-visibility centered glass badge right over the product image
    return (
      <div className="absolute inset-0 bg-slate-950/35 backdrop-blur-[1.5px] flex items-center justify-center p-2 z-10 pointer-events-none">
        <div
          className={`bg-slate-950/90 text-white border border-white/25 shadow-xl rounded-2xl flex flex-col items-center justify-center text-center ${
            isLarge ? 'px-5 py-3 gap-1' : 'px-3 py-1.5 gap-0.5'
          }`}
        >
          <span
            className={`inline-flex items-center gap-1.5 font-extrabold text-rose-300 leading-none ${
              isLarge ? 'text-sm sm:text-base' : 'text-[11px] sm:text-xs'
            }`}
          >
            <span>🚫</span>
            <span>স্টক শেষ</span>
          </span>
          <span
            className={`font-mono font-bold uppercase tracking-widest text-white/80 leading-none ${
              isLarge ? 'text-[10px] sm:text-[11px]' : 'text-[8px] sm:text-[9px]'
            }`}
          >
            STOCK OUT
          </span>
        </div>
      </div>
    );
  };

  const selectedZoneFee =
    selectedDeliveryZone === 'outside_dhaka' ? outsideDhakaFee : insideDhakaFee;
  const selectedRawZoneFee =
    selectedDeliveryZone === 'outside_dhaka' ? rawOutsideDhakaFee : rawInsideDhakaFee;
  const configuredDeliveryFee =
    isAdminFreeDeliveryEnabled ||
    isSpinFreeDelivery ||
    isQtyFreeDeliveryUnlocked ||
    isMinAmountFreeDeliveryUnlocked ||
    hasFreeDeliveryProductInOrder ||
    isFlashFreeDeliveryActive
      ? 0
      : selectedZoneFee;
  const isFreeDelivery =
    isAdminFreeDeliveryEnabled ||
    isSpinFreeDelivery ||
    isQtyFreeDeliveryUnlocked ||
    isMinAmountFreeDeliveryUnlocked ||
    hasFreeDeliveryProductInOrder ||
    isFlashFreeDeliveryActive ||
    configuredDeliveryFee <= 0;
  const deliveryCharge = effectiveSubtotal === 0 ? 0 : isFreeDelivery ? 0 : selectedZoneFee;

  const spinDiscountAmount = useMemo(() => {
    if (!isSpinWheelActive || !claimedSpinReward || effectiveSubtotal <= 0) return 0;
    if (claimedSpinReward.type === 'flat') {
      return Math.min(effectiveSubtotal, claimedSpinReward.value);
    }
    if (claimedSpinReward.type === 'percent') {
      return Math.min(effectiveSubtotal, Math.round((effectiveSubtotal * claimedSpinReward.value) / 100));
    }
    return 0;
  }, [isSpinWheelActive, claimedSpinReward, effectiveSubtotal]);

  const grandTotal = Math.max(0, effectiveSubtotal - spinDiscountAmount) + deliveryCharge;

  // Real-time Incomplete Order / Abandoned Checkout Capture + Facebook Pixel/CAPI Lead Event
  const checkoutSessionKeyRef = useRef<string>(
    `chk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
  );
  const firedLeadPhoneRef = useRef<string>('');
  const upsertIncompleteRef = useRef(upsertIncompleteOrder);
  upsertIncompleteRef.current = upsertIncompleteOrder;

  const captureStorefrontIncompleteLeadNow = (
    nameOverride?: string,
    phoneOverride?: string,
    addressOverride?: string
  ) => {
    const activeEntries = directBuyItem ? [directBuyItem] : cartEntries;
    if (!isCheckoutModalOpen || isSubmittingOrder || confirmedOrder || activeEntries.length === 0) {
      return;
    }

    const effName = (nameOverride !== undefined ? nameOverride : customerName).trim();
    const effPhone = (phoneOverride !== undefined ? phoneOverride : customerPhone).trim();
    const effAddress = (addressOverride !== undefined ? addressOverride : deliveryAddress).trim();

    const normPhone = normalizeBdPhone(effPhone);
    if (!isValidBdPhone11(normPhone)) {
      return;
    }

    const itemsSnapshot: SaleItem[] = activeEntries.map(entry => {
      const unitRetail = entry.variant ? entry.variant.retailPrice : entry.product.retailPrice;
      const unitCost = entry.variant
        ? entry.variant.purchasePrice
        : entry.product.avgCost ?? entry.product.purchasePrice;
      const fullName = entry.variant
        ? `${entry.product.nameBn} (${entry.variant.label})`
        : entry.product.nameBn;

      const resolvedVarSku = entry.variant
        ? entry.variant.sku?.trim() ||
          buildVariantSkuCode(entry.product.sku, entry.variant.label)
        : undefined;

      return {
        productId: entry.product.id,
        productName: fullName,
        productNameClean: entry.product.nameBn,
        sku: resolvedVarSku || entry.product.sku,
        parentSku: entry.product.sku,
        variantSku: resolvedVarSku,
        wpProductId: entry.product.wpProductId,
        wpVariationId: entry.variant?.wpVariationId,
        variantId: entry.variant?.id,
        variantLabel: entry.variant?.label,
        unit: entry.variant ? entry.variant.label : entry.product.unit,
        quantity: entry.quantity,
        unitPrice: unitRetail,
        costPrice: unitCost,
        discount: 0,
        vatAmount: 0,
        total: unitRetail * entry.quantity
      };
    });

    const areaLabel = isAdminFreeDeliveryEnabled
      ? 'ফ্রি ডেলিভারি (Free Delivery)'
      : isQtyFreeDeliveryUnlocked
      ? `ফ্রি ডেলিভারি (${freeDeliveryMinQty}+ পিস অফার - ${
          selectedDeliveryZone === 'outside_dhaka' ? 'ঢাকার বাইরে' : 'ঢাকার ভিতরে'
        })`
      : selectedDeliveryZone === 'outside_dhaka'
      ? 'ঢাকার বাইরে (Outside Dhaka)'
      : 'ঢাকার ভিতরে (Inside Dhaka)';

    const { fbp, fbc, externalId } = ensureMetaFirstPartyIdentifiers();
    const resolvedLeadCity =
      selectedDeliveryZone === 'inside_dhaka'
        ? extractLocationForMeta(effAddress, 'dhaka').ct
        : extractLocationForMeta(effAddress).ct;

    if (normPhone.length === 11 && normPhone.startsWith('01') && firedLeadPhoneRef.current !== normPhone) {
      firedLeadPhoneRef.current = normPhone;
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'Lead',
        customer: {
          name: effName || undefined,
          phone: normPhone,
          address: effAddress || undefined,
          city: resolvedLeadCity || undefined,
          externalId,
          fbp,
          fbc
        },
        customData: buildMetaOrderItemsCustomData({
          items: itemsSnapshot,
          totalValue: grandTotal,
          orderSource: directBuyItem ? 'landing_page' : 'storefront'
        })
      }).catch(() => {});
    }

    upsertIncompleteRef.current({
      sessionKey: checkoutSessionKeyRef.current,
      customerName: effName,
      customerPhone: normPhone,
      deliveryArea: areaLabel,
      deliveryAddress: effAddress,
      deliverySlot,
      items: itemsSnapshot,
      subtotal: effectiveSubtotal,
      deliveryCharge,
      grandTotal,
      fbLeadSent: true,
      fbp,
      fbc,
      externalId,
      clientUserAgent: typeof navigator !== 'undefined' ? navigator.userAgent : undefined,
      eventSourceUrl: typeof window !== 'undefined' ? window.location.href : undefined,
      orderSource: directBuyItem ? 'landing_page' : 'storefront',
      notes: orderNotes.trim() || undefined
    });
  };

  useEffect(() => {
    const activeEntriesCount = directBuyItem ? 1 : cartEntries.length;
    if (!isCheckoutModalOpen || isSubmittingOrder || confirmedOrder || activeEntriesCount === 0) {
      return;
    }

    const normPhone = normalizeBdPhone(customerPhone);
    if (!isValidBdPhone11(normPhone)) {
      return;
    }

    const timer = setTimeout(() => {
      captureStorefrontIncompleteLeadNow();
    }, 250);

    return () => clearTimeout(timer);
  }, [
    isCheckoutModalOpen,
    isSubmittingOrder,
    confirmedOrder,
    customerName,
    customerPhone,
    deliveryAddress,
    selectedDeliveryZone,
    deliverySlot,
    orderNotes,
    cartEntries,
    cartSubtotal,
    deliveryCharge,
    grandTotal
  ]);

  // Filtered & Sorted Products (Strictly exclude Landing Page-only products from Home Page)
  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = products.filter(p => {
      if (p.isLandingPageProduct) return false;
      const matchesCat = selectedCategoryId === 'all' || p.categoryId === selectedCategoryId;
      const matchesBrand = selectedBrandId === 'all' || p.brandId === selectedBrandId;
      const matchesSearch =
        !q ||
        p.nameBn.toLowerCase().includes(q) ||
        p.nameEn.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.includes(q);
      return matchesCat && matchesBrand && matchesSearch;
    });

    if (sortBy === 'price_asc') {
      return [...list].sort((a, b) => a.retailPrice - b.retailPrice);
    }
    if (sortBy === 'price_desc') {
      return [...list].sort((a, b) => b.retailPrice - a.retailPrice);
    }
    return list;
  }, [products, selectedCategoryId, selectedBrandId, searchQuery, sortBy]);

  // ============================================================================
  // SMART HYBRID INFINITE SCROLL + LOAD MORE SYSTEM (Auto Scroll + Manual Button + Instant Full Search)
  // ============================================================================
  const isHomeInfiniteScrollEnabled = currentBusiness.homeInfiniteScrollEnabled !== false;
  const homeProductsPerBatch = Math.max(
    8,
    Number(currentBusiness.homeProductsPerBatch) || 20
  );
  const [visibleProductsCount, setVisibleProductsCount] = useState<number>(homeProductsPerBatch);
  const loadMoreSentinelRef = useRef<HTMLDivElement | null>(null);

  // Reset visible count whenever batch size, category, brand, or search changes
  useEffect(() => {
    setVisibleProductsCount(homeProductsPerBatch);
  }, [homeProductsPerBatch, selectedCategoryId, selectedBrandId, searchQuery]);

  // When searching, show all matching products immediately; otherwise use hybrid infinite scroll slice
  const isSearchingNow = searchQuery.trim().length > 0;
  const displayedProducts = useMemo(() => {
    if (!isHomeInfiniteScrollEnabled || isSearchingNow) {
      return filteredProducts;
    }
    return filteredProducts.slice(0, visibleProductsCount);
  }, [filteredProducts, isHomeInfiniteScrollEnabled, isSearchingNow, visibleProductsCount]);

  const hasMoreProductsToLoad =
    isHomeInfiniteScrollEnabled &&
    !isSearchingNow &&
    visibleProductsCount < filteredProducts.length;

  // Auto-load next batch when customer scrolls near the bottom of the product grid
  useEffect(() => {
    if (!hasMoreProductsToLoad) return;
    const node = loadMoreSentinelRef.current;
    if (!node || typeof IntersectionObserver === 'undefined') return;

    const observer = new IntersectionObserver(
      entries => {
        const first = entries[0];
        if (first && first.isIntersecting) {
          setVisibleProductsCount(prev =>
            Math.min(filteredProducts.length, prev + homeProductsPerBatch)
          );
        }
      },
      { root: null, rootMargin: '360px 0px', threshold: 0.01 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [hasMoreProductsToLoad, filteredProducts.length, homeProductsPerBatch]);

  // ============================================================================
  // STOREFRONT LIVE RECENT ORDER NOTIFICATION POPUP (Social Proof Toast — ON/OFF + Speed + 56+ BD Buyers Dataset)
  // ============================================================================
  const showStorefrontSocialProof = currentBusiness.storefrontSocialProofEnabled !== false;
  const storefrontSocialProofGapSec =
    typeof currentBusiness.storefrontSocialProofIntervalSec === 'number' &&
    currentBusiness.storefrontSocialProofIntervalSec >= 2
      ? Math.min(300, Math.round(currentBusiness.storefrontSocialProofIntervalSec))
      : 16;

  const storefrontCatalogProducts = useMemo(() => {
    const nonLanding = products.filter(p => !p.isLandingPageProduct);
    return nonLanding.length > 0 ? nonLanding : products;
  }, [products]);

  const storefrontSocialProofBuyers = useMemo(() => {
    const customList = Array.isArray(currentBusiness.storefrontSocialProofCustomEntries)
      ? currentBusiness.storefrontSocialProofCustomEntries.map(s => s.trim()).filter(Boolean)
      : [];
    if (customList.length > 0) {
      return customList.map((line, idx) => {
        const parts = line.split('|').map(p => p.trim());
        return {
          name: parts[0] || 'ভেরিফাইড ক্রেতা',
          location: parts[1] || 'ঢাকা',
          timeAgo: parts[2] || `${toBanglaCountdownDigits((idx + 1) * 3, 1)} মিনিট আগে`
        };
      });
    }
    return DEFAULT_SOCIAL_PROOF_BUYERS;
  }, [currentBusiness.storefrontSocialProofCustomEntries]);

  const [sfSocialProofOrder, setSfSocialProofOrder] = useState<number[]>([]);
  const [sfSocialProofCursor, setSfSocialProofCursor] = useState<number>(0);
  const [isSfSocialProofVisible, setIsSfSocialProofVisible] = useState<boolean>(false);
  const [isSfSocialProofDismissed, setIsSfSocialProofDismissed] = useState<boolean>(false);

  useEffect(() => {
    const total = storefrontSocialProofBuyers.length;
    if (total === 0) return;

    const storageKey = `sf_sp_rotation_v2_${currentBusiness.id}_${total}`;
    const createShuffledIndices = (len: number, avoidFirst?: number): number[] => {
      const arr = Array.from({ length: len }, (_, i) => i);
      for (let i = len - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
      if (avoidFirst !== undefined && len > 1 && arr[0] === avoidFirst) {
        const swapIdx = 1 + Math.floor(Math.random() * (len - 1));
        const tmp = arr[0];
        arr[0] = arr[swapIdx];
        arr[swapIdx] = tmp;
      }
      return arr;
    };

    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw) as { order?: number[]; cursor?: number };
        if (
          Array.isArray(parsed.order) &&
          parsed.order.length === total &&
          typeof parsed.cursor === 'number'
        ) {
          const nextCursor = parsed.cursor + 1;
          if (nextCursor < total) {
            setSfSocialProofOrder(parsed.order);
            setSfSocialProofCursor(nextCursor);
            window.localStorage.setItem(
              storageKey,
              JSON.stringify({ order: parsed.order, cursor: nextCursor })
            );
            return;
          } else {
            const lastSeenIdx = parsed.order[total - 1];
            const reshuffled = createShuffledIndices(total, lastSeenIdx);
            setSfSocialProofOrder(reshuffled);
            setSfSocialProofCursor(0);
            window.localStorage.setItem(
              storageKey,
              JSON.stringify({ order: reshuffled, cursor: 0 })
            );
            return;
          }
        }
      }

      const freshOrder = createShuffledIndices(total);
      setSfSocialProofOrder(freshOrder);
      setSfSocialProofCursor(0);
      window.localStorage.setItem(
        storageKey,
        JSON.stringify({ order: freshOrder, cursor: 0 })
      );
    } catch {
      setSfSocialProofOrder(createShuffledIndices(total));
      setSfSocialProofCursor(0);
    }
  }, [currentBusiness.id, storefrontSocialProofBuyers.length]);

  useEffect(() => {
    const total = storefrontSocialProofBuyers.length;
    if (
      !showStorefrontSocialProof ||
      isSfSocialProofDismissed ||
      isCheckoutModalOpen ||
      Boolean(confirmedOrder) ||
      isSpinWheelModalOpen ||
      Boolean(variantSelectionModal) ||
      total === 0 ||
      storefrontCatalogProducts.length === 0
    ) {
      setIsSfSocialProofVisible(false);
      return;
    }

    const storageKey = `sf_sp_rotation_v2_${currentBusiness.id}_${total}`;
    const visibleDurationMs = 4500;
    const gapDurationMs = Math.max(2000, storefrontSocialProofGapSec * 1000);
    let activeTimerId: number | undefined;
    let isCancelled = false;

    const scheduleShow = (delayMs: number, advanceCursor: boolean) => {
      activeTimerId = window.setTimeout(() => {
        if (isCancelled) return;
        if (advanceCursor) {
          setSfSocialProofCursor(prev => {
            const next = (prev + 1) % total;
            try {
              const raw = window.localStorage.getItem(storageKey);
              const parsed = raw ? JSON.parse(raw) : {};
              window.localStorage.setItem(
                storageKey,
                JSON.stringify({
                  order:
                    Array.isArray(parsed.order) && parsed.order.length === total
                      ? parsed.order
                      : sfSocialProofOrder,
                  cursor: next
                })
              );
            } catch {}
            return next;
          });
        }
        setIsSfSocialProofVisible(true);

        activeTimerId = window.setTimeout(() => {
          if (isCancelled) return;
          setIsSfSocialProofVisible(false);
          scheduleShow(gapDurationMs, true);
        }, visibleDurationMs);
      }, delayMs);
    };

    scheduleShow(3200, false);

    return () => {
      isCancelled = true;
      if (activeTimerId !== undefined) {
        window.clearTimeout(activeTimerId);
      }
    };
  }, [
    showStorefrontSocialProof,
    isSfSocialProofDismissed,
    isCheckoutModalOpen,
    confirmedOrder,
    isSpinWheelModalOpen,
    variantSelectionModal,
    currentBusiness.id,
    storefrontSocialProofBuyers.length,
    storefrontCatalogProducts.length,
    sfSocialProofOrder,
    storefrontSocialProofGapSec
  ]);

  const resolvedSfBuyerIndex =
    sfSocialProofOrder.length === storefrontSocialProofBuyers.length
      ? sfSocialProofOrder[sfSocialProofCursor % Math.max(1, sfSocialProofOrder.length)] ?? 0
      : sfSocialProofCursor % Math.max(1, storefrontSocialProofBuyers.length);

  const currentSfSocialProofBuyer =
    storefrontSocialProofBuyers[resolvedSfBuyerIndex] || DEFAULT_SOCIAL_PROOF_BUYERS[0];

  const currentSfSocialProofProduct: Product | null = useMemo(() => {
    if (quickViewProduct) return quickViewProduct;
    if (storefrontCatalogProducts.length === 0) return null;
    const prodIdx = resolvedSfBuyerIndex % storefrontCatalogProducts.length;
    return storefrontCatalogProducts[prodIdx] || storefrontCatalogProducts[0];
  }, [quickViewProduct, storefrontCatalogProducts, resolvedSfBuyerIndex]);

  const scrollToCheckoutField = (fieldId: string, fieldKey: 'name' | 'phone' | 'address', messageBn: string, messageEn: string) => {
    setCheckoutErrorField(fieldKey);
    showToast(language === 'bn' ? messageBn : messageEn, 'error');
    const el = document.getElementById(fieldId) as HTMLInputElement | HTMLTextAreaElement | null;
    if (!el) return;

    // On computer / desktop screens (>= 768px), keep the original smooth center scroll behavior
    const isMobileScreen = typeof window !== 'undefined' && window.innerWidth < 768;
    if (!isMobileScreen) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => {
        el.focus({ preventScroll: true });
      }, 300);
      return;
    }

    // Mobile only: Focus immediately inside user gesture without browser jump so mobile keyboard opens smoothly
    el.focus({ preventScroll: true });

    const alignFieldInVisibleViewport = (behavior: ScrollBehavior = 'smooth') => {
      const wrapper = (el.closest('[data-checkout-field]') as HTMLElement | null) || el.parentElement || el;
      const vv = typeof window !== 'undefined' ? window.visualViewport : null;
      const visibleHeight = vv ? vv.height : window.innerHeight;
      const vvOffsetTop = vv ? vv.offsetTop : 0;

      const rect = wrapper.getBoundingClientRect();
      const currentTopInVv = rect.top - vvOffsetTop;

      // Safe top margin so sticky header never covers the field label
      const minTopGap = visibleHeight < 360 ? Math.max(56, Math.round(visibleHeight * 0.2)) : 88;
      // Comfortable gap between the input (+ error message) and the top of the mobile keyboard
      const minBottomKeyboardGap = visibleHeight < 380 ? 64 : 96;

      // Place slightly above the center (38%) of the visible space above the keyboard
      const idealTop = Math.round((visibleHeight - rect.height) * 0.38);
      const maxAllowedTop = Math.max(minTopGap, visibleHeight - rect.height - minBottomKeyboardGap);
      const desiredTopInVv = Math.max(minTopGap, Math.min(idealTop, maxAllowedTop));

      const deltaY = currentTopInVv - desiredTopInVv;
      if (Math.abs(deltaY) > 6) {
        window.scrollBy({ top: deltaY, behavior });
      }
    };

    requestAnimationFrame(() => {
      alignFieldInVisibleViewport('smooth');
    });

    const vv = typeof window !== 'undefined' ? window.visualViewport : null;
    const handleVvResize = () => alignFieldInVisibleViewport('smooth');
    if (vv) {
      vv.addEventListener('resize', handleVvResize);
    }
    const t1 = window.setTimeout(() => alignFieldInVisibleViewport('smooth'), 180);
    const t2 = window.setTimeout(() => alignFieldInVisibleViewport('smooth'), 380);
    window.setTimeout(() => {
      if (vv) vv.removeEventListener('resize', handleVvResize);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    }, 650);
  };

  const handlePlaceOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const activeEntries = directBuyItem ? [directBuyItem] : cartEntries;
    if (activeEntries.length === 0) return;

    // Strict Internet Connection Check: Prevent fake offline orders when Mobile Data / Wi-Fi is off
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      setIsBrowserOnline(false);
      showToast(
        language === 'bn'
          ? 'আপনার ইন্টারনেট সংযোগ (Mobile Data / Wi-Fi) বন্ধ আছে! অর্ডার সম্পন্ন করতে অনুগ্রহ করে ইন্টারনেট চালু করে আবার চেষ্টা করুন।'
          : 'No internet connection! Please turn on Mobile Data or Wi-Fi and try again.',
        'error'
      );
      return;
    }

    const cleanPhone = customerPhone.trim();
    const normPhone = normalizeBdPhone(cleanPhone);

    if (!customerName.trim()) {
      scrollToCheckoutField(
        'checkout-input-name',
        'name',
        'অনুগ্রহ করে আপনার নাম লিখুন',
        'Please enter your name'
      );
      return;
    }

    if (!isValidBdPhone11(normPhone)) {
      scrollToCheckoutField(
        'checkout-input-phone',
        'phone',
        'অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন (যেমন: 017XXXXXXXX)',
        'Please enter a valid 11-digit mobile number'
      );
      return;
    }
    if (cleanPhone !== normPhone) {
      setCustomerPhone(normPhone);
    }

    if (!deliveryAddress.trim()) {
      scrollToCheckoutField(
        'checkout-input-address',
        'address',
        'অনুগ্রহ করে সম্পূর্ণ ডেলিভারি ঠিকানা লিখুন',
        'Please enter your delivery address'
      );
      return;
    }

    setCheckoutErrorField(null);

    // Check Daily Order Limit (Same Product Max 2 & Total Products Max 5 by Mobile Number & IP/Device) before placing order
    const targetOrderProductIds = Array.from(
      new Set(activeEntries.map(entry => entry.product.id).filter(Boolean))
    );
    let limitResult = checkDailyOrderLimit(normPhone, targetOrderProductIds);
    if (!limitResult.blocked) {
      limitResult = await verifyDailyOrderLimitServer(normPhone, targetOrderProductIds);
    }
    if (limitResult.blocked) {
      setInlineLimitTitle(limitResult.title);
      setInlineLimitMessage(limitResult.message);
      setInlineLimitSameProdMaxCount(limitResult.sameProductMaxCount);
      setInlineLimitMaxCount(limitResult.maxCount);
      setIsEditingLimitPopupInline(false);
      setOrderLimitPopupData(limitResult);
      return;
    }

    setIsSubmittingOrder(true);
    try {
      const orderItems: SaleItem[] = activeEntries.map(entry => {
        const unitRetail = entry.variant ? entry.variant.retailPrice : entry.product.retailPrice;
        const unitCost = entry.variant
          ? entry.variant.purchasePrice
          : entry.product.avgCost ?? entry.product.purchasePrice;
        const fullName = entry.variant
          ? `${entry.product.nameBn} (${entry.variant.label})`
          : entry.product.nameBn;

        const resolvedVarSku = entry.variant
          ? entry.variant.sku?.trim() || buildVariantSkuCode(entry.product.sku, entry.variant.label)
          : undefined;

        return {
          productId: entry.product.id,
          productName: fullName,
          productNameClean: entry.product.nameBn,
          sku: resolvedVarSku || entry.variant?.sku || entry.product.sku,
          parentSku: entry.product.sku,
          variantSku: resolvedVarSku,
          wpProductId: entry.product.wpProductId,
          wpVariationId: entry.variant?.wpVariationId,
          variantId: entry.variant?.id,
          variantLabel: entry.variant?.label,
          unit: entry.variant ? entry.variant.label : entry.product.unit,
          quantity: entry.quantity,
          unitPrice: unitRetail,
          costPrice: unitCost,
          discount: 0,
          total: unitRetail * entry.quantity,
          batchNumber: entry.product.batchNumber
        };
      });

      // Capture _fbp / _fbc and normalize Bangladesh customer data before submitting order
      const { fbp, fbc } = captureAndPersistFbParams();
      const storedFbIdentity = getFbCustomerIdentity();
      const resolvedCity =
        selectedDeliveryZone === 'inside_dhaka'
          ? extractLocationForMeta(deliveryAddress.trim(), 'dhaka').ct
          : extractLocationForMeta(deliveryAddress.trim()).ct;
      const preNormalized = normalizeCustomerDataForMeta({
        name: customerName.trim(),
        phone: normPhone,
        address: deliveryAddress.trim(),
        city: resolvedCity
      });

      const created = await placeOnlineOrder({
        businessId: currentBusiness.id,
        outletId: 'outlet_01',
        customerName: customerName.trim(),
        customerPhone: normPhone,
        deliveryArea: isAdminFreeDeliveryEnabled
          ? 'ফ্রি ডেলিভারি (Free Delivery)'
          : isQtyFreeDeliveryUnlocked
          ? `ফ্রি ডেলিভারি (${freeDeliveryMinQty}+ পিস অফার - ${
              selectedDeliveryZone === 'outside_dhaka' ? 'ঢাকার বাইরে' : 'ঢাকার ভিতরে'
            })`
          : selectedDeliveryZone === 'outside_dhaka'
          ? 'ঢাকার বাইরে (Outside Dhaka)'
          : 'ঢাকার ভিতরে (Inside Dhaka)',
        deliveryAddress: deliveryAddress.trim(),
        deliverySlot,
        items: orderItems,
        subtotal: effectiveSubtotal,
        deliveryCharge,
        discountAmount: spinDiscountAmount,
        grandTotal,
        paymentMethod: 'cod',
        paymentStatus: 'unpaid',
        orderSource: directBuyItem ? 'landing_page' : 'storefront',
        fbp,
        fbc,
        fbExternalId: storedFbIdentity.externalId || preNormalized.ph || normPhone,
        clientUserAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
        eventSourceUrl: typeof window !== 'undefined' ? window.location.href : '',
        notes: orderNotes.trim() || undefined
      });

      // If customer is logged in and updated their name/address during checkout, persist it to their database account
      if (currentCustomerAccount) {
        await registerOrUpdateOnlineCustomer({
          name: customerName.trim(),
          phone: currentCustomerAccount.phone,
          address: deliveryAddress.trim(),
          password: currentCustomerAccount.password
        });
        const updatedAccounts = customerAccounts.map(acc =>
          normalizeBdPhone(acc.phone) === normalizeBdPhone(currentCustomerAccount.phone)
            ? {
                ...acc,
                name: customerName.trim(),
                address: deliveryAddress.trim()
              }
            : acc
        );
        persistCustomerAccounts(updatedAccounts);
      }

      // Fire 100% Deduplicated Facebook Pixel + Server-Side CAPI Purchase Event with exact event_id stored in DB (`order_${created.orderNo}`)
      const purchaseEventId = created.fbEventId || generateMetaEventId('Purchase', created.orderNo);
      const purchaseCustomerIdentity = {
        name: customerName.trim(),
        phone: preNormalized.ph || normPhone,
        email: storedFbIdentity.email || undefined,
        address: deliveryAddress.trim(),
        city: resolvedCity || undefined,
        externalId: storedFbIdentity.externalId,
        fbp,
        fbc
      };
      saveFbCustomerIdentity(purchaseCustomerIdentity, currentBusiness);
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'Purchase',
        eventIdOverride: purchaseEventId,
        customer: purchaseCustomerIdentity,
        customData: buildMetaOrderItemsCustomData({
          items: orderItems,
          orderId: created.orderNo,
          totalValue: created.grandTotal,
          orderSource: directBuyItem ? 'landing_page' : 'storefront'
        })
      }).catch(() => {});

      // Automatically create order on external WordPress (WooCommerce) website if configured in Developer Account
      syncOrderToWordPress({
        business: currentBusiness,
        order: created,
        productsCatalog: products
      }).catch(() => {});

      // Consume Spin Wheel reward immediately after 1 order so it never stays stuck on future checkouts
      if (isSpinWheelActive && claimedSpinReward) {
        setClaimedSpinReward(null);
        setDailySpinRecord(prev => {
          const nextLock = prev
            ? { ...prev, used: true, usedOrderNo: created.orderNo }
            : {
                dateKey: getLocalTodayDateKey(),
                name: customerName.trim(),
                phone: normPhone,
                reward: claimedSpinReward,
                spunAt: new Date().toISOString(),
                used: true,
                usedOrderNo: created.orderNo
              };
          try {
            window.localStorage.setItem('stockmaster_spin_daily_lock_v1', JSON.stringify(nextLock));
          } catch {
            // ignore
          }
          return nextLock;
        });
        try {
          window.localStorage.removeItem('stockmaster_spin_reward_v1');
        } catch {
          // ignore
        }
      }

      clearCart();
      setIsCheckoutModalOpen(false);
      setIsCartOpen(false);
      setConfirmedOrder(created);
      if (currentBusiness.storefrontOrderConfettiEnabled !== false) {
        triggerOrderSuccessConfetti();
      }
    } catch (err: any) {
      showToast(
        language === 'bn'
          ? 'ইন্টারনেট সংযোগ বিচ্ছিন্ন! সার্ভারে অর্ডার পাঠানো যায়নি। অনুগ্রহ করে মোবাইল ডাটা বা Wi-Fi সংযোগ চালু করে আবার চেষ্টা করুন।'
          : 'Internet disconnected! Could not reach the server. Please check your Mobile Data or Wi-Fi and try again.',
        'error'
      );
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  const finalizeCustomerSignupAccount = async () => {
    const cleanName = signupName.trim();
    const cleanPhone = signupPhone.trim();
    const normPhone = normalizeBdPhone(cleanPhone);
    const cleanAddress = signupAddress.trim();
    const cleanPass = signupPassword.trim();

    // 1. Save Online Customer Account directly into the main Database (`customers` in AppContext + `/api/state`)
    const dbCustomer = await registerOrUpdateOnlineCustomer({
      name: cleanName,
      phone: normPhone,
      address: cleanAddress,
      password: cleanPass
    });

    // 2. Also mirror in localCustomerAccounts for instant local lookup
    const newAccount: StorefrontCustomerAccount = {
      id: dbCustomer.id,
      name: cleanName,
      phone: normPhone,
      address: cleanAddress,
      password: cleanPass,
      createdAt: new Date().toISOString()
    };

    const filteredLocal = localCustomerAccounts.filter(
      acc => normalizeBdPhone(acc.phone) !== normPhone
    );
    persistCustomerAccounts([newAccount, ...filteredLocal]);
    persistCustomerSession(normPhone);

    // Pre-fill checkout fields immediately
    setCustomerName(cleanName);
    setCustomerPhone(normPhone);
    setDeliveryAddress(cleanAddress);

    setSignupName('');
    setSignupPhone('');
    setSignupAddress('');
    setSignupPassword('');
    setSignupOtpInput('');
    setSignupGeneratedOtp('');
    setSignupStep('form');

    showToast(`অভিনন্দন ${cleanName}! আপনার একাউন্ট ডাটাবেজে সংরক্ষিত ও লগইন সম্পন্ন হয়েছে।`, 'success');

    // Enrich Facebook Customer Identity & Fire CompleteRegistration Event on Account Signup
    saveFbCustomerIdentity(
      {
        name: cleanName,
        phone: normPhone,
        address: cleanAddress
      },
      currentBusiness
    );
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'CompleteRegistration',
      customer: {
        name: cleanName,
        phone: normPhone,
        address: cleanAddress
      },
      customData: {
        content_name: 'Customer Account Registration',
        status: 'registered',
        currency: 'BDT',
        value: 0
      }
    }).catch(() => {});

    if (returnToCheckoutAfterAuth) {
      setReturnToCheckoutAfterAuth(false);
      setIsCustomerAccountOpen(false);
      setIsCheckoutModalOpen(true);
    }
  };

  // Send Signup OTP Helper
  const sendSignupVerificationOtp = async (cleanName: string, cleanPhone: string) => {
    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();
    setSignupGeneratedOtp(otpCode);
    setSignupOtpInput('');

    if (hasBusinessSmsConfigured(currentBusiness)) {
      setIsSendingSignupOtp(true);
      try {
        const shopTitle = currentBusiness.name.replace('স্টকমাস্টার বিডি - ', '');
        const template =
          currentBusiness.smsSignupOtpTemplate ||
          DEFAULT_SMS_TEMPLATES.signupOtp ||
          DEFAULT_SMS_TEMPLATES.otpReset;
        const msg = formatSmsMessage(template, {
          name: cleanName,
          phone: cleanPhone,
          otp: otpCode,
          shop_name: shopTitle
        });

        const res = await sendBusinessSms(currentBusiness, cleanPhone, msg);

        if (res.error === 0) {
          setSignupOtpSentViaSms(true);
          setSignupStep('verify_otp');
          showToast(
            `আপনার ${cleanPhone} নম্বরে ৪-ডিজিটের সাইনআপ ভেরিফিকেশন কোড (OTP) পাঠানো হয়েছে`,
            'success'
          );
        } else {
          setSignupOtpSentViaSms(false);
          setSignupStep('verify_otp');
          showToast(`SMS গেটওয়ে: ${res.msg}। ভেরিফিকেশন কোড দিয়ে সাইনআপ সম্পন্ন করুন।`, 'info');
        }
      } finally {
        setIsSendingSignupOtp(false);
      }
    } else {
      setSignupOtpSentViaSms(false);
      setSignupStep('verify_otp');
      showToast(
        `আপনার মোবাইল নম্বর যাচাইয়ের জন্য ভেরিফিকেশন কোড (OTP: ${otpCode}) প্রস্তুত হয়েছে`,
        'info'
      );
    }
  };

  // Customer Sign Up Handler (Name, Mobile Number, Address, Password + Admin-controlled OTP Verification)
  const handleCustomerSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = signupName.trim();
    const cleanPhone = signupPhone.trim();
    const normPhone = normalizeBdPhone(cleanPhone);
    const cleanAddress = signupAddress.trim();
    const cleanPass = signupPassword.trim();

    if (!cleanName) {
      showToast('অনুগ্রহ করে আপনার নাম লিখুন', 'error');
      return;
    }
    if (normPhone.length < 10) {
      showToast('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন', 'error');
      return;
    }
    if (!cleanAddress) {
      showToast('অনুগ্রহ করে আপনার ডেলিভারি ঠিকানা লিখুন', 'error');
      return;
    }
    if (cleanPass.length < 4) {
      showToast('অনুগ্রহ করে কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন', 'error');
      return;
    }

    const existing = customerAccounts.find(acc => normalizeBdPhone(acc.phone) === normPhone);
    if (existing && existing.password) {
      showToast('এই মোবাইল নম্বর দিয়ে আগেই একাউন্ট খোলা হয়েছে। অনুগ্রহ করে লগইন করুন।', 'info');
      setLoginPhone(normPhone);
      setCustomerAuthTab('login');
      return;
    }

    // Check if Admin enabled Signup OTP Verification in Settings (defaults to false for instant signup)
    const isOtpRequired = Boolean(currentBusiness.signupOtpRequired);
    if (isOtpRequired) {
      await sendSignupVerificationOtp(cleanName, normPhone);
      return;
    }

    await finalizeCustomerSignupAccount();
  };

  const handleVerifySignupOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (signupOtpInput.trim() !== signupGeneratedOtp) {
      showToast('ভেরিফিকেশন কোড (OTP) সঠিক নয়! অনুগ্রহ করে সঠিক ৪-ডিজিট কোড দিন।', 'error');
      return;
    }
    await finalizeCustomerSignupAccount();
  };

  // Customer Login Handler (Strictly Mobile Number + Password only, backed by Database `customers`)
  const handleCustomerLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = loginPhone.trim();
    const normPhone = normalizeBdPhone(cleanPhone);
    const cleanPass = loginPassword.trim();

    if (normPhone.length < 10) {
      showToast('অনুগ্রহ করে সঠিক মোবাইল নম্বর লিখুন', 'error');
      return;
    }
    if (!cleanPass) {
      showToast('অনুগ্রহ করে পাসওয়ার্ড লিখুন', 'error');
      return;
    }

    const accountByPhone = customerAccounts.find(acc => normalizeBdPhone(acc.phone) === normPhone);
    if (!accountByPhone) {
      showToast('এই মোবাইল নম্বরে কোনো একাউন্ট পাওয়া যায়নি। অনুগ্রহ করে নতুন একাউন্ট খুলুন।', 'error');
      setSignupPhone(normPhone);
      setCustomerAuthTab('signup');
      return;
    }

    // If customer exists in database from a previous order without a password set yet, save this password & log them in
    if (!accountByPhone.password) {
      await registerOrUpdateOnlineCustomer({
        name: accountByPhone.name,
        phone: normPhone,
        address: accountByPhone.address,
        password: cleanPass
      });
    } else if (accountByPhone.password !== cleanPass) {
      showToast('মোবাইল নম্বর অথবা পাসওয়ার্ড সঠিক নয়', 'error');
      return;
    }

    persistCustomerSession(normPhone);
    setCustomerName(accountByPhone.name);
    setCustomerPhone(normPhone);
    setDeliveryAddress(accountByPhone.address);
    setLoginPassword('');

    showToast(`স্বাগতম, ${accountByPhone.name}! সফলভাবে লগইন হয়েছে।`, 'success');

    if (returnToCheckoutAfterAuth) {
      setReturnToCheckoutAfterAuth(false);
      setIsCustomerAccountOpen(false);
      setIsCheckoutModalOpen(true);
    }
  };

  const handleCustomerProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCustomerAccount) return;
    if (!editProfileName.trim() || !editProfileAddress.trim()) {
      showToast('নাম এবং ঠিকানা খালি রাখা যাবে না', 'error');
      return;
    }

    await registerOrUpdateOnlineCustomer({
      name: editProfileName.trim(),
      phone: currentCustomerAccount.phone,
      address: editProfileAddress.trim(),
      password: currentCustomerAccount.password
    });

    const updated = customerAccounts.map(acc =>
      normalizeBdPhone(acc.phone) === normalizeBdPhone(currentCustomerAccount.phone)
        ? {
            ...acc,
            name: editProfileName.trim(),
            address: editProfileAddress.trim()
          }
        : acc
    );
    persistCustomerAccounts(updated);
    setCustomerName(editProfileName.trim());
    setDeliveryAddress(editProfileAddress.trim());
    setIsEditingCustomerProfile(false);
    showToast('আপনার প্রোফাইল ও ডেলিভারি ঠিকানা ডাটাবেজে আপডেট হয়েছে', 'success');
  };

  const handleCustomerLogout = () => {
    persistCustomerSession('');
    setIsEditingCustomerProfile(false);
    showToast('আপনার একাউন্ট থেকে লগআউট করা হয়েছে', 'info');
  };

  // Forgot Password Step 1: Send OTP to Mobile Number via Alpha SMS API (api.sms.net.bd)
  const handleForgotSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = forgotPhone.trim();
    const normPhone = normalizeBdPhone(cleanPhone);

    if (normPhone.length < 10) {
      showToast('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন', 'error');
      return;
    }

    const accountByPhone = customerAccounts.find(acc => normalizeBdPhone(acc.phone) === normPhone);
    if (!accountByPhone) {
      showToast('এই মোবাইল নম্বরে কোনো একাউন্ট পাওয়া যায়নি। নতুন একাউন্ট খুলুন।', 'error');
      return;
    }

    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(otpCode);
    setForgotOtpInput('');
    setForgotNewPassword('');

    // Check if Admin enabled Forgot Password OTP SMS and SMS Gateway is configured
    if (
      currentBusiness.smsForgotPasswordOtpEnabled !== false &&
      hasBusinessSmsConfigured(currentBusiness)
    ) {
      setIsSendingOtp(true);
      try {
        const shopTitle = currentBusiness.name.replace('স্টকমাস্টার বিডি - ', '');
        const template = currentBusiness.smsOtpTemplate || DEFAULT_SMS_TEMPLATES.otpReset;
        const msg = formatSmsMessage(template, {
          name: accountByPhone.name,
          phone: accountByPhone.phone,
          otp: otpCode,
          shop_name: shopTitle
        });

        const res = await sendBusinessSms(currentBusiness, accountByPhone.phone, msg);

        if (res.error === 0) {
          setOtpSentViaSms(true);
          setForgotStep('verify_reset');
          showToast(`আপনার ${accountByPhone.phone} নম্বরে ভেরিফিকেশন কোড (OTP) SMS পাঠানো হয়েছে`, 'success');
        } else {
          setOtpSentViaSms(false);
          setForgotStep('verify_reset');
          showToast(
            `SMS গেটওয়ে রেসপন্স: ${res.msg}। নিচে নতুন পাসওয়ার্ড সেট করুন।`,
            'info'
          );
          setForgotOtpInput(otpCode);
        }
      } finally {
        setIsSendingOtp(false);
      }
    } else {
      // When Forgot Password SMS is turned OFF by Admin or SMS API is not configured yet, allow direct password reset by mobile number
      setOtpSentViaSms(false);
      setForgotOtpInput(otpCode);
      setForgotStep('verify_reset');
      showToast('মোবাইল নম্বর যাচাই হয়েছে। আপনার নতুন পাসওয়ার্ড লিখুন।', 'info');
    }
  };

  // Forgot Password Step 2: Verify OTP & Save New Password into Database
  const handleForgotResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const normPhone = normalizeBdPhone(forgotPhone.trim());
    const accountByPhone = customerAccounts.find(acc => normalizeBdPhone(acc.phone) === normPhone);

    if (!accountByPhone) {
      showToast('একাউন্ট খুঁজে পাওয়া যায়নি', 'error');
      setForgotStep('request_otp');
      return;
    }

    if (otpSentViaSms && forgotOtpInput.trim() !== generatedOtp) {
      showToast('ভেরিফিকেশন কোড (OTP) সঠিক নয়', 'error');
      return;
    }

    if (forgotNewPassword.trim().length < 4) {
      showToast('অনুগ্রহ করে কমপক্ষে ৪ অক্ষরের নতুন পাসওয়ার্ড দিন', 'error');
      return;
    }

    await registerOrUpdateOnlineCustomer({
      name: accountByPhone.name,
      phone: normPhone,
      address: accountByPhone.address,
      password: forgotNewPassword.trim()
    });

    const updatedAccounts = customerAccounts.map(acc =>
      normalizeBdPhone(acc.phone) === normPhone
        ? { ...acc, password: forgotNewPassword.trim() }
        : acc
    );
    persistCustomerAccounts(updatedAccounts);
    persistCustomerSession(normPhone);

    setCustomerName(accountByPhone.name);
    setCustomerPhone(normPhone);
    setDeliveryAddress(accountByPhone.address);

    setForgotPhone('');
    setForgotOtpInput('');
    setForgotNewPassword('');
    setGeneratedOtp('');
    setForgotStep('request_otp');
    setCustomerAuthTab('login');

    showToast('আপনার পাসওয়ার্ড ডাটাবেজে সফলভাবে পরিবর্তন ও লগইন করা হয়েছে!', 'success');

    if (returnToCheckoutAfterAuth) {
      setReturnToCheckoutAfterAuth(false);
      setIsCustomerAccountOpen(false);
      setIsCheckoutModalOpen(true);
    }
  };

  const handleReorderFromHistory = (order: OnlineOrder) => {
    const updatedCart = { ...cart };
    let addedCount = 0;

    order.items.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      if (!product) return;
      const available = getProductAvailableStock(product);
      if (available <= 0) return;

      const variant = item.variantId
        ? product.variants?.find(v => v.id === item.variantId)
        : undefined;
      const key = buildCartKey(product.id, variant);
      const currentQty = updatedCart[key]?.quantity || 0;
      const nextQty = Math.min(available, currentQty + item.quantity);

      updatedCart[key] = {
        cartKey: key,
        product,
        variant,
        quantity: nextQty
      };
      addedCount += 1;
    });

    if (addedCount === 0) {
      showToast('দুঃখিত, এই অর্ডারের পণ্যগুলো বর্তমানে স্টকে নেই', 'error');
      return;
    }

    persistCart(updatedCart);
    showToast('অর্ডারের পণ্যগুলো শপিং ব্যাগে যোগ করা হয়েছে!', 'success');
    openCheckoutModal(updatedCart);
  };

  const isWinterTheme =
    Boolean(currentBusiness.winterThemeEnabled) ||
    currentBusiness.storefrontTheme === 'winter_frost';
  const activeStorefrontTheme: StorefrontThemeStyle = isWinterTheme
    ? 'winter_frost'
    : currentBusiness.storefrontTheme || 'emerald_default';
  const isCoolBluePalette = isWinterTheme || activeStorefrontTheme === 'cool_blue';
  const isSnowfallEnabled = currentBusiness.winterSnowfallEnabled !== false;
  const snowfallIntensity = Math.max(
    10,
    Math.min(100, Number(currentBusiness.winterSnowfallIntensity ?? 50))
  );
  const snowfallSpeed = Math.max(
    30,
    Math.min(200, Number(currentBusiness.winterSnowfallSpeed ?? 100))
  );
  const snowfallAutoOffSec = Math.max(
    0,
    Number(currentBusiness.winterSnowfallAutoOffSec ?? 0)
  );

  // Auto-Off Timer state for Falling Snow Overlay (0 = Always On, >0 = Automatically stops after N seconds)
  const [isSnowAutoStopped, setIsSnowAutoStopped] = useState(false);
  const [snowReplaySeed, setSnowReplaySeed] = useState(0);

  // 🎉 Order Success Celebration (60fps Canvas Physics + 4 Luxury Styles + Center Golden Badge)
  const isOrderConfettiEnabled = currentBusiness.storefrontOrderConfettiEnabled !== false;
  const orderCelebrationStyle: OrderCelebrationStyle =
    currentBusiness.storefrontOrderConfettiStyle || 'dual_cannon_badge';
  const isOrderCelebrationBadgeOn =
    currentBusiness.storefrontOrderCelebrationBadgeEnabled !== false;
  const [isConfettiBurstActive, setIsConfettiBurstActive] = useState(false);
  const [confettiBurstSeed, setConfettiBurstSeed] = useState(0);
  const confettiTimerRef = useRef<number | null>(null);

  const triggerOrderSuccessConfetti = () => {
    if (confettiTimerRef.current) {
      window.clearTimeout(confettiTimerRef.current);
    }
    setConfettiBurstSeed(prev => prev + 1);
    setIsConfettiBurstActive(true);
    confettiTimerRef.current = window.setTimeout(() => {
      setIsConfettiBurstActive(false);
      confettiTimerRef.current = null;
    }, 2600);
  };

  useEffect(() => {
    return () => {
      if (confettiTimerRef.current) {
        window.clearTimeout(confettiTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!isSnowfallEnabled || snowfallAutoOffSec <= 0) {
      setIsSnowAutoStopped(false);
      return;
    }
    setIsSnowAutoStopped(false);
    const timer = window.setTimeout(() => {
      setIsSnowAutoStopped(true);
    }, snowfallAutoOffSec * 1000);

    return () => window.clearTimeout(timer);
  }, [isSnowfallEnabled, snowfallAutoOffSec, snowfallIntensity, snowfallSpeed, snowReplaySeed]);

  // Dynamic seasonal particle generator driven by Intensity (particle count + speed) & Falling Speed
  const storefrontSnowParticles = useMemo(() => {
    const glyphs =
      activeStorefrontTheme === 'summer_mango'
        ? ['☀️', '🌴', '✨']
        : activeStorefrontTheme === 'ramadan_noor'
        ? ['🌙', '🏮', '✨']
        : activeStorefrontTheme === 'eid_festive'
        ? ['🌙', '🕌', '🎉', '✨']
        : ['❄', '❅', '❆'];
    // Intensity 10% -> 8 particles, 50% (default) -> 34 particles, 100% -> 68 particles
    const particleCount = Math.max(6, Math.min(80, Math.round((snowfallIntensity / 100) * 68)));
    // Combined speed factor: adjusted by both Intensity slider and dedicated Falling Speed slider
    const speedMultiplier = (snowfallSpeed / 100) * (0.65 + (snowfallIntensity / 100) * 0.7);

    return Array.from({ length: particleCount }, (_, i) => {
      const seed = (i * 37 + 13) % 100;
      const seed2 = (i * 61 + 29) % 100;
      const isGlyph = i % 3 === 0;
      const leftPct = ((i * 100) / particleCount + (seed % 5) * 0.45) % 99;
      const sizePx = isGlyph ? 10 + (seed % 7) : 5 + (seed % 6);
      const baseDurationSec = 12 + (seed2 % 13); // 12s to 24s base fall
      const durationSec = Number(
        Math.max(3.2, Math.min(36, baseDurationSec / Math.max(0.25, speedMultiplier))).toFixed(2)
      );
      const delaySec = -((i * 1.7 + (seed % 9)) % Math.max(6, Math.round(durationSec)));
      const driftMidPx = (i % 2 === 0 ? 1 : -1) * (12 + (seed % 22));
      const driftEndPx = (i % 2 === 0 ? -1 : 1) * (10 + (seed2 % 18));
      const opacity = isGlyph
        ? Number((0.48 + (seed % 35) * 0.01).toFixed(2))
        : Number((0.42 + (seed2 % 40) * 0.01).toFixed(2));
      const blurPx = i % 5 === 0 ? 0.8 : 0;
      const glyph = glyphs[i % glyphs.length];

      return {
        id: `snow_${activeStorefrontTheme}_${i}_${particleCount}`,
        isGlyph,
        glyph,
        leftPct: Number(leftPct.toFixed(2)),
        sizePx,
        durationSec,
        delaySec: Number(delaySec.toFixed(2)),
        driftMidPx,
        driftEndPx,
        opacity,
        blurPx
      };
    });
  }, [activeStorefrontTheme, snowfallIntensity, snowfallSpeed]);

  return (
    <div
      className="storefront-font-scale-scope min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col antialiased relative"
      data-storefront-theme={activeStorefrontTheme}
    >
      {/* Subtle Falling Snow Overlay (GPU-composited CSS 3D transforms; auto-paused during Checkout/Order Confirmation for 60fps smoothness) */}
      {isSnowfallEnabled && !isSnowAutoStopped && !confirmedOrder && !isCheckoutModalOpen && (
        <div className="storefront-snowfall-overlay" aria-hidden="true">
          {storefrontSnowParticles.map(p => (
            <span
              key={p.id}
              className={`storefront-snow-particle ${
                p.isGlyph ? 'storefront-snow-glyph' : 'storefront-snow-orb'
              }`}
              style={
                {
                  left: `${p.leftPct}%`,
                  width: p.isGlyph ? undefined : `${p.sizePx}px`,
                  height: p.isGlyph ? undefined : `${p.sizePx}px`,
                  fontSize: p.isGlyph ? `${p.sizePx}px` : undefined,
                  animationDuration: `${p.durationSec}s`,
                  animationDelay: `${p.delaySec}s`,
                  '--snow-drift-mid': `${p.driftMidPx}px`,
                  '--snow-drift-end': `${p.driftEndPx}px`,
                  '--snow-opacity': String(p.opacity)
                } as React.CSSProperties
              }
            >
              {p.isGlyph ? p.glyph : null}
            </span>
          ))}
        </div>
      )}

      {/* 🎉 60fps High-DPI Canvas Physics Order Celebration Overlay (4 Luxury Styles + Center Golden Badge) */}
      <OrderCelebrationOverlay
        active={isConfettiBurstActive}
        seed={confettiBurstSeed}
        styleMode={orderCelebrationStyle}
        showCenterBadge={isOrderCelebrationBadgeOn}
        orderNo={confirmedOrder?.orderNo}
      />

      {/* Dynamic React Helmet SEO & OpenGraph Meta Tags for Product Pages (Facebook & WhatsApp Previews) */}
      <ProductSeoHelmet
        business={currentBusiness}
        product={quickViewProduct}
        activeVariant={quickViewProduct ? getActiveVariant(quickViewProduct) : undefined}
        availableStock={quickViewProduct ? getProductAvailableStock(quickViewProduct) : 10}
      />

      {/* 0. Admin-Controlled Top Scrolling Announcement Bar (ON/OFF + Editable Text & Speed) */}
      {currentBusiness.topAnnouncementEnabled !== false &&
        (
          currentBusiness.topAnnouncementText ??
          '❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।'
        ).trim() !== '' && (() => {
          const announcementMsg = (
            currentBusiness.topAnnouncementText ??
            '❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।'
          ).trim();
          const speedMode = currentBusiness.topAnnouncementSpeed || 'normal';
          const speedClass =
            speedMode === 'slow'
              ? 'top-announcement-speed-slow'
              : speedMode === 'fast'
              ? 'top-announcement-speed-fast'
              : 'top-announcement-speed-normal';

          return (
            <div className="sf-theme-topbar bg-gradient-to-r from-[#064E3B] via-[#047857] to-[#065F46] text-white border-b border-white/15 py-1.5 overflow-hidden select-none">
              {speedMode === 'static' ? (
                <div className="max-w-7xl mx-auto px-3 sm:px-6 text-center text-xs sm:text-[13px] font-extrabold tracking-wide text-amber-200 truncate">
                  {announcementMsg}
                </div>
              ) : (
                <div className="relative w-full overflow-hidden flex items-center">
                  <div className={`top-announcement-marquee-track ${speedClass} items-center`}>
                    {[0, 1].map(groupIdx => (
                      <div key={groupIdx} className="flex items-center shrink-0">
                        {[0, 1, 2, 3].map(itemIdx => (
                          <span
                            key={`${groupIdx}_${itemIdx}`}
                            className="inline-flex items-center gap-3 px-5 text-xs sm:text-[13px] font-extrabold tracking-wide text-white whitespace-nowrap"
                          >
                            <span>{announcementMsg}</span>
                            <span
                              className={
                                isWinterTheme
                                  ? 'text-sky-200 text-xs animate-winter-snowflake'
                                  : activeStorefrontTheme === 'summer_mango' ||
                                    activeStorefrontTheme === 'ramadan_noor' ||
                                    activeStorefrontTheme === 'eid_festive'
                                  ? 'text-amber-200 text-xs animate-winter-snowflake'
                                  : 'text-amber-300 text-[10px]'
                              }
                            >
                              {isWinterTheme
                                ? '❄️'
                                : activeStorefrontTheme === 'summer_mango'
                                ? '☀️'
                                : activeStorefrontTheme === 'ramadan_noor'
                                ? '🌙'
                                : activeStorefrontTheme === 'eid_festive'
                                ? '🕌'
                                : '✦'}
                            </span>
                          </span>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })()}

      {/* 1. Modern Top Utility Bar (Customer-Only — Hotline hidden on mobile, Login/Signup/Logout shown — Admin ON/OFF Toggleable) */}
      {currentBusiness.topUtilityBarEnabled !== false && (
        <div className="sf-theme-topbar bg-gradient-to-r from-[#064E3B] via-[#047857] to-[#065F46] text-emerald-50 text-[11px] sm:text-xs py-1.5 px-3 sm:px-6">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
            <div className="hidden sm:flex items-center gap-2.5 sm:gap-3 min-w-0">
              <a
                href={`tel:${currentBusiness.phone}`}
                className="hidden sm:inline-flex items-center gap-1.5 font-bold text-amber-300 hover:text-amber-200 transition-colors shrink-0"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>হটলাইন: {currentBusiness.phone}</span>
              </a>
            </div>

            <div className="w-full sm:w-auto flex items-center justify-between sm:justify-end gap-2 sm:gap-3 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => openCustomerAccountPage('login', false)}
                  className="inline-flex items-center gap-1 text-emerald-50 hover:text-amber-300 font-bold transition-colors cursor-pointer whitespace-nowrap"
                >
                  <UserIcon className="w-3.5 h-3.5 text-amber-300" />
                  <span>
                    {currentCustomerAccount
                      ? `${currentCustomerAccount.name.split(' ')[0]} (অর্ডার হিস্ট্রি)`
                      : 'লগইন / সাইনআপ'}
                  </span>
                </button>

                {currentCustomerAccount && (
                  <>
                    <span className="text-emerald-400/40">|</span>
                    <button
                      type="button"
                      onClick={handleCustomerLogout}
                      className="inline-flex items-center gap-1 text-rose-200 hover:text-white font-bold transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <LogOut className="w-3 h-3 text-rose-300" />
                      <span>লগআউট</span>
                    </button>
                  </>
                )}
              </div>

              {isAuthenticated && (
                <div className="flex items-center gap-2 sm:gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      updateBusiness({ topUtilityBarEnabled: false });
                      showToast(
                        'হটলাইন ও লগইন টপ বার হাইড (OFF) করা হয়েছে! (সেটিংস বা হোমপেজ অ্যাডমিন বার থেকে আবার ON করতে পারবেন)',
                        'info'
                      );
                    }}
                    className="ml-1 px-2 py-0.5 rounded-md bg-black/30 hover:bg-black/50 text-amber-200 border border-white/20 text-[10px] font-extrabold cursor-pointer transition-colors whitespace-nowrap"
                    title="অ্যাডমিন কন্ট্রোল: এই টপ বারটি হাইড (OFF) করুন"
                  >
                    টপ বার OFF
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. Modern Sticky Mobile-First Glassmorphic Brand & Search Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md text-slate-900 border-b border-slate-200/80 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3">
          <div className="flex items-center justify-between gap-2 sm:gap-5">
            {/* Left: Storefront Banner Logo Only (Icon & Text Removed — Uploadable from Developer Account) */}
            <div className="flex items-center min-w-0 shrink-0">
              <button
                type="button"
                onClick={() => {
                  closeAllSubPagesAndRestoreScroll();
                  handleSelectCategory('all');
                  setSelectedBrandId('all');
                  setSearchQuery('');
                }}
                className="flex items-center text-left cursor-pointer group shrink-0 min-h-[36px]"
                title={currentBusiness.name}
              >
                {currentBusiness.logoUrl && currentBusiness.logoUrl.trim() !== '' ? (
                  <img
                    src={currentBusiness.logoUrl}
                    alt={currentBusiness.name}
                    className="h-9 sm:h-12 w-auto max-w-[195px] sm:max-w-[260px] object-contain transition-opacity group-hover:opacity-90"
                  />
                ) : null}
              </button>
            </div>

            {/* Right: Helpline & Shopping Bag Button (Login & Search removed for clean direct-order marketing flow) */}
            <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
              <a
                href={`tel:${currentBusiness.phone}`}
                className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-50/80 hover:bg-emerald-100/80 border border-emerald-200/80 text-xs font-semibold transition-colors"
              >
                <PhoneCall className="w-4 h-4 text-emerald-700" />
                <div className="leading-tight">
                  <span className="text-[10px] text-slate-500 block">অর্ডার করতে কল করুন</span>
                  <span className="font-mono font-bold text-emerald-900">{currentBusiness.phone}</span>
                </div>
              </a>

              <div
                className={
                  currentBusiness.cartBorderBeamEnabled !== false
                    ? 'cart-border-beam-wrapper shrink-0'
                    : 'inline-flex shrink-0'
                }
              >
                <button
                  type="button"
                  onClick={openCartDrawer}
                  className={`sf-theme-cart-btn relative z-10 min-h-[40px] sm:min-h-[42px] px-3 sm:px-4 py-1.5 sm:py-2 bg-gradient-to-r from-[#047857] to-[#065F46] hover:from-[#065F46] hover:to-[#064E3B] text-white font-extrabold text-xs sm:text-sm ${
                    currentBusiness.cartBorderBeamEnabled !== false ? 'rounded-[11px]' : 'rounded-xl shadow-xs'
                  } flex items-center gap-2 transition-all cursor-pointer shrink-0`}
                >
                  <div className="relative">
                    <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" />
                    <span className="absolute -top-2 -right-2 bg-[#FF5A1F] text-white text-[10px] font-mono font-extrabold px-1.5 py-0.2 rounded-full shadow-2xs">
                      {totalCartItems}
                    </span>
                  </div>
                  <div className="text-left leading-tight">
                    <span className="text-[9px] sm:text-[10px] font-medium text-emerald-100 block">
                      শপিং ব্যাগ
                    </span>
                    <span className="font-mono font-extrabold text-xs sm:text-sm tabular-nums text-white">
                      {formatCurrency(cartSubtotal)}
                    </span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* 3. Main Storefront Content (Full-Page Subviews or Main Product Catalog) */}
      <main className="max-w-7xl w-full mx-auto px-3 sm:px-6 py-3 sm:py-6 space-y-4 sm:space-y-6 flex-1">
        {confirmedOrder ? (
          /* SUB-PAGE A: Simple, Clean & 100% Mobile-Responsive Order Confirmed Page */
          <div key="page-order-confirmed" className="max-w-xl mx-auto py-2 sm:py-6 animate-page-rise">
            <div className="bg-white rounded-3xl border border-emerald-200 shadow-md overflow-hidden">
              {/* Clean Top Header */}
              <div className="bg-gradient-to-b from-emerald-50/80 to-white px-4 sm:px-7 pt-6 sm:pt-7 pb-4 text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-md shadow-emerald-600/20">
                  <CheckCircle2 className="w-9 h-9" />
                </div>

                <div className="space-y-1.5">
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                    আপনার অর্ডারের জন্য ধন্যবাদ!
                  </h2>
                  <p className="text-[15px] sm:text-base text-slate-600 leading-relaxed max-w-md mx-auto">
                    আপনার অর্ডার নম্বর{' '}
                    <span className="inline-block px-2.5 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 font-mono font-extrabold">
                      #{confirmedOrder.orderNo}
                    </span>{' '}
                    সফলভাবে গৃহীত হয়েছে। প্রোডাক্ট ডেলিভারি নেওয়ার সময় ক্যাশ অন ডেলিভারিতে পেমেন্ট করবেন।
                  </p>
                </div>
              </div>

              <div className="px-4 sm:px-7 pb-6 pt-2 space-y-4">
                {/* 1-Click WhatsApp Order Confirmation Button at TOP with Cart Border Beam + Login Shine Animation & 1-Line Mobile Layout */}
                {(() => {
                  const rawWaPhone = (
                    currentBusiness.whatsappOrderPhone ||
                    currentBusiness.callOrderPhone ||
                    currentBusiness.phone ||
                    '01711234567'
                  ).trim();
                  const cleanDigits = rawWaPhone.replace(/\D/g, '');
                  const formattedWa = cleanDigits.startsWith('880')
                    ? cleanDigits
                    : cleanDigits.startsWith('0')
                    ? `88${cleanDigits}`
                    : `880${cleanDigits}`;
                  const itemsSummary = confirmedOrder.items
                    .map(it => `• ${it.productName} × ${it.quantity} = ৳${it.total}`)
                    .join('\n');
                  const confirmWaText = [
                    `আসসালামু আলাইকুম, আমি ওয়েবসাইটে একটি অর্ডার কনফার্ম করেছি:`,
                    `📦 অর্ডার নম্বর: #${confirmedOrder.orderNo}`,
                    `👤 নাম: ${confirmedOrder.customerName}`,
                    `📞 মোবাইল: ${confirmedOrder.customerPhone}`,
                    `🛍️ অর্ডারকৃত পণ্য:`,
                    itemsSummary,
                    `🚚 ডেলিভারি চার্জ: ${
                      confirmedOrder.deliveryCharge === 0
                        ? 'ফ্রি ডেলিভারি (৳০)'
                        : `৳${confirmedOrder.deliveryCharge}`
                    }`,
                    `💰 সর্বমোট বিল: ৳${confirmedOrder.grandTotal} (ক্যাশ অন ডেলিভারি)`,
                    `📍 ঠিকানা: ${confirmedOrder.deliveryAddress}`,
                    `অনুগ্রহ করে আমার অর্ডারটি দ্রুত কনফার্ম করবেন।`
                  ].join('\n');
                  const confirmWaHref = `https://wa.me/${formattedWa}?text=${encodeURIComponent(
                    confirmWaText
                  )}`;

                  return (
                    <div className="p-3 sm:p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2 text-center">
                      <p className="text-[11px] sm:text-sm font-extrabold text-emerald-950 whitespace-nowrap overflow-hidden text-ellipsis">
                        ⚡ দ্রুত কনফার্মেশনের জন্য ১-ক্লিকে হোয়াটসঅ্যাপে অর্ডার মেসেজ পাঠিয়ে দিন
                      </p>
                      <div className="wa-confirm-beam-wrapper">
                        <a
                          href={confirmWaHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="relative z-10 w-full py-3 px-3 sm:px-4 bg-gradient-to-r from-[#1fa855] via-[#25D366] to-[#128C7E] hover:from-[#1b944a] hover:to-[#0f7a6e] text-white font-extrabold text-[13px] sm:text-base rounded-[12px] flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer btn-premium-shine"
                        >
                          <WhatsAppOriginalIcon className="w-4 h-4 sm:w-5 sm:h-5 text-white shrink-0 animate-bounce" />
                          <span className="whitespace-nowrap">হোয়াটসঅ্যাপে অর্ডার কনফার্মেশন পাঠান</span>
                        </a>
                      </div>
                    </div>
                  );
                })()}

                {/* Simple "এরপর কী হবে?" Card */}
                <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-left space-y-2">
                  <h3 className="text-[15px] sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <PhoneCall className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>এরপর কী হবে?</span>
                  </h3>
                  <p className="text-sm sm:text-[15px] text-slate-700 leading-relaxed">
                    আমাদের একজন প্রতিনিধি শীঘ্রই আপনার অর্ডারটি কনফার্ম করার জন্য কল করবেন। কনফার্ম হওয়ার পর, আমরা কুরিয়ারের মাধ্যমে আপনার প্রোডাক্টটি পাঠিয়ে দিবো।
                  </p>
                  <div className="pt-1 flex flex-wrap items-center gap-2">
                    <a
                      href={`tel:${(currentBusiness.callOrderPhone || currentBusiness.phone || '').replace(/\s+/g, '')}`}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-700 border border-amber-200 font-bold text-xs sm:text-sm transition-colors"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>কল করুন: {currentBusiness.callOrderPhone || currentBusiness.phone}</span>
                    </a>
                  </div>
                </div>

                {/* Simple, Clean & 100% Mobile-Responsive Order Summary Box */}
                <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/90 text-left space-y-3 text-[15px] sm:text-base">
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">ক্রেতার নাম:</span>
                    <span className="font-bold text-slate-900 text-right break-words">
                      {confirmedOrder.customerName}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 shrink-0">মোবাইল নম্বর:</span>
                    <span className="font-mono font-bold text-slate-900 text-right">
                      {confirmedOrder.customerPhone}
                    </span>
                  </div>

                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">ডেলিভারি ঠিকানা:</span>
                    <span className="font-bold text-slate-900 text-right break-words leading-snug">
                      {confirmedOrder.deliveryAddress}
                    </span>
                  </div>

                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">পেমেন্ট পদ্ধতি:</span>
                    <span className="font-bold text-emerald-700 text-right">
                      ক্যাশ অন ডেলিভারি
                    </span>
                  </div>

                  {/* Ordered Items & Delivery Breakdown */}
                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    {confirmedOrder.items.map((it, idx) => (
                      <div
                        key={idx}
                        className="flex items-start justify-between gap-3 font-bold text-slate-800"
                      >
                        <span className="break-words leading-snug">
                          {it.productName}{' '}
                          <span className="text-emerald-700 whitespace-nowrap">× {it.quantity}</span>
                        </span>
                        <span className="font-mono shrink-0">{formatCurrency(it.total)}</span>
                      </div>
                    ))}

                    {confirmedOrder.discountAmount > 0 && (
                      <div className="flex items-center justify-between gap-3 text-emerald-700 font-bold">
                        <span>ডিসকাউন্ট ছাড়:</span>
                        <span className="font-mono shrink-0">
                          - {formatCurrency(confirmedOrder.discountAmount)}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-3 text-slate-600">
                      <span>ডেলিভারি চার্জ:</span>
                      <span className="font-mono font-bold text-slate-800 shrink-0">
                        {confirmedOrder.deliveryCharge === 0
                          ? 'ফ্রি ডেলিভারি'
                          : formatCurrency(confirmedOrder.deliveryCharge)}
                      </span>
                    </div>
                  </div>

                  {/* Grand Total Row */}
                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3 text-base sm:text-lg font-extrabold text-emerald-700">
                    <span>সর্বমোট বিল:</span>
                    <span className="font-mono text-lg sm:text-xl shrink-0">
                      {formatCurrency(confirmedOrder.grandTotal)}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmedOrder(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="w-full py-3 px-4 bg-[#c30000] hover:bg-[#9e0000] text-white font-bold text-[15px] sm:text-base rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
                  >
                    <ShoppingBag className="w-4 h-4 shrink-0" />
                    <span>আরও শপিং করুন</span>
                  </button>
                </div>

                {/* Subtle Admin-Only Celebration Controls at Bottom */}
                {isAuthenticated && (
                  <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = !isOrderConfettiEnabled;
                        updateBusiness({ storefrontOrderConfettiEnabled: nextVal });
                        if (nextVal) {
                          triggerOrderSuccessConfetti();
                        }
                        showToast(
                          nextVal
                            ? '🎉 অর্ডার কনফার্ম সেলিব্রেশন অ্যানিমেশন চালু (ON) করা হয়েছে!'
                            : 'অর্ডার কনফার্ম সেলিব্রেশন অ্যানিমেশন বন্ধ (OFF) করা হয়েছে।',
                          nextVal ? 'success' : 'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold border cursor-pointer transition-all inline-flex items-center gap-1.5 ${
                        isOrderConfettiEnabled
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      <span>🎉 সেলিব্রেশন: {isOrderConfettiEnabled ? 'ON' : 'OFF'}</span>
                    </button>

                    <select
                      value={orderCelebrationStyle}
                      onChange={(e) => {
                        const nextStyle = e.target.value as OrderCelebrationStyle;
                        updateBusiness({
                          storefrontOrderConfettiEnabled: true,
                          storefrontOrderConfettiStyle: nextStyle
                        });
                        setTimeout(() => triggerOrderSuccessConfetti(), 30);
                      }}
                      className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer outline-hidden"
                    >
                      <option value="dual_cannon_badge">🎊 ১. ডাবল পার্টি ক্যানন</option>
                      <option value="royal_fireworks">🎆 ২. রয়্যাল আতশবাজি</option>
                      <option value="luxury_gold_fountain">✨ ৩. গোল্ড ফাউন্টেন</option>
                      <option value="festive_balloons">🎈 ৪. বেলুন ও হার্টস</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => triggerOrderSuccessConfetti()}
                      className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      ✨ প্রিভিউ
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : isCheckoutModalOpen ? (
          /* SUB-PAGE B: Clean, Minimal & Easy 1-Step Checkout View with Mobile Floating Confirm Bar */
          <div key="page-checkout" className="max-w-5xl mx-auto space-y-3.5 pb-24 lg:pb-4 animate-page-rise">
            {/* Simple, Uncluttered Back Button (Removed 'ক্যাশ অন ডেলিভারি চেকআউট' badge) */}
            <div>
              <button
                type="button"
                onClick={closeAllSubPagesAndRestoreScroll}
                className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-extrabold text-emerald-800 hover:text-emerald-950 py-1 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>আরও পণ্য যোগ করতে ফিরে যান</span>
              </button>
            </div>

            {checkoutEntries.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-4">
                <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
                <p className="text-base font-bold text-slate-800">আপনার শপিং ব্যাগে কোনো পণ্য নেই</p>
                <button
                  type="button"
                  onClick={closeAllSubPagesAndRestoreScroll}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold rounded-xl cursor-pointer"
                >
                  পণ্য পছন্দ করতে ফিরে যান
                </button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6 items-start">
                  {/* Order Items & Bill Summary Card (Supports উপায় ২: Mobile Form-First vs Order-Box-First) */}
                  <div
                    className={`lg:col-span-5 ${
                      currentBusiness.checkoutMobileFormFirst ? 'order-2 lg:order-2' : 'order-1 lg:order-2'
                    } bg-white rounded-2xl border border-slate-200/85 shadow-2xs p-4 sm:p-5 space-y-3.5`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                      <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                        <ShoppingBag className="w-4 h-4 text-emerald-700" />
                        <span>অর্ডার বক্স ({totalCheckoutItems} টি পণ্য)</span>
                      </h3>
                      {isAuthenticated && (
                        <button
                          type="button"
                          onClick={() => {
                            const curFullCheckout = currentBusiness.showFullProductNameOnCheckout !== false;
                            const nextFullCheckout = !curFullCheckout;
                            updateBusiness({ showFullProductNameOnCheckout: nextFullCheckout });
                            showToast(
                              nextFullCheckout
                                ? 'চেকআউট পেজে প্রোডাক্টের সম্পূর্ণ নাম দেখানো চালু (ON) করা হয়েছে!'
                                : 'চেকআউট পেজে ১-লাইনে সংক্ষিপ্ত নাম (OFF) সেট করা হয়েছে!',
                              nextFullCheckout ? 'success' : 'info'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                            currentBusiness.showFullProductNameOnCheckout !== false
                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                              : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                          }`}
                          title="অ্যাডমিন কন্ট্রোল: চেকআউট পেজে প্রোডাক্টের সম্পূর্ণ নাম ON / OFF করুন"
                        >
                          {currentBusiness.showFullProductNameOnCheckout !== false
                            ? '📝 সম্পূর্ণ নাম: ON'
                            : '📝 ১-লাইন নাম: OFF'}
                        </button>
                      )}
                    </div>

                    {/* Free Delivery Banner when Admin enabled Free Delivery */}
                    {isAdminFreeDeliveryEnabled && (
                      <div className="p-3 rounded-xl border text-xs bg-emerald-50/90 border-emerald-200 text-emerald-900">
                        <div className="flex items-center gap-2 font-bold">
                          <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                          <span>অভিনন্দন! আপনার এই অর্ডারে হোম ডেলিভারি সম্পূর্ণ ফ্রি!</span>
                        </div>
                      </div>
                    )}

                    {/* Offer #7: Happy Hour / Flash Free Delivery Live Countdown Banner */}
                    {!isAdminFreeDeliveryEnabled && isFlashFreeDeliveryActive && (
                      <div className="p-3 rounded-xl border border-amber-300 bg-gradient-to-r from-amber-50 via-yellow-50/90 to-orange-50 text-amber-950 text-xs space-y-1 shadow-2xs">
                        <div className="flex items-center justify-between gap-2 font-extrabold">
                          <span className="inline-flex items-center gap-1.5 text-[#c30000]">
                            <Flame className="w-4 h-4 text-[#c30000] animate-pulse shrink-0" />
                            <span>⚡ ফ্ল্যাশ ফ্রি ডেলিভারি অফার চলছে!</span>
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-emerald-700 text-white text-[10px] font-extrabold shrink-0">
                            ডেলিভারি ফ্রি (৳০) ✓
                          </span>
                        </div>
                        <p className="text-[11px] font-bold text-slate-800">
                          আগামী <strong className="text-[#c30000]">{flashCountdownLabelBn}</strong> এর মধ্যে অর্ডার করলেই আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!
                        </p>
                      </div>
                    )}

                    {/* Offer #6: Product-Specific Free Delivery Unlocked Banner */}
                    {!isAdminFreeDeliveryEnabled &&
                      !isFlashFreeDeliveryActive &&
                      hasFreeDeliveryProductInOrder && (
                        <div className="p-3 rounded-xl border border-emerald-300 bg-emerald-50/95 text-emerald-950 text-xs">
                          <div className="flex items-center gap-2 font-extrabold">
                            <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                            <span>
                              🚚 অভিনন্দন! ফ্রি ডেলিভারি অফারের পণ্য অর্ডারে থাকায় আপনার সম্পূর্ণ অর্ডারের ডেলিভারি চার্জ ফ্রি (৳০)!
                            </span>
                          </div>
                        </div>
                      )}

                    {/* Offer #1: Minimum Order Amount Free Delivery + Animated Live Progress Bar */}
                    {!isAdminFreeDeliveryEnabled &&
                      !isFlashFreeDeliveryActive &&
                      !hasFreeDeliveryProductInOrder &&
                      isMinAmountFreeDeliveryEnabled && (
                        <div
                          className={`p-3 rounded-xl border text-xs space-y-2 transition-all ${
                            isMinAmountFreeDeliveryUnlocked
                              ? 'bg-emerald-50/95 border-emerald-300 text-emerald-950'
                              : 'bg-gradient-to-r from-teal-50/90 via-emerald-50/75 to-cyan-50/80 border-teal-300 text-slate-900'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 font-extrabold">
                            <div className="flex items-center gap-1.5">
                              <Truck
                                className={`w-4 h-4 shrink-0 ${
                                  isMinAmountFreeDeliveryUnlocked
                                    ? 'text-emerald-700'
                                    : 'text-[#c30000]'
                                }`}
                              />
                              <span>
                                {isMinAmountFreeDeliveryUnlocked
                                  ? `🎉 অভিনন্দন! ৳${freeDeliveryMinOrderAmt.toLocaleString(
                                      'en-IN'
                                    )}+ টাকার অর্ডারে আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি (৳০)!`
                                  : `🚚 আর মাত্র ৳${remainingAmtForFreeDelivery.toLocaleString(
                                      'en-IN'
                                    )} টাকার পণ্য যোগ করলেই আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!`}
                              </span>
                            </div>
                            <span className="font-mono text-[11px] font-black text-emerald-800 shrink-0">
                              {minAmountProgressPct}%
                            </span>
                          </div>

                          {/* Animated Live Progress Bar */}
                          <div className="w-full h-2.5 rounded-full bg-white/90 border border-teal-200/80 overflow-hidden p-0.5">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${
                                isMinAmountFreeDeliveryUnlocked
                                  ? 'bg-gradient-to-r from-emerald-600 to-teal-500'
                                  : 'bg-gradient-to-r from-[#c30000] via-amber-500 to-emerald-600'
                              }`}
                              style={{ width: `${Math.max(8, minAmountProgressPct)}%` }}
                            />
                          </div>
                        </div>
                      )}

                    {/* Smart Quantity-Based Free Delivery Banner ("2 pcs / 3 pcs কিনলে ডেলিভারি ফ্রি") */}
                    {!isAdminFreeDeliveryEnabled &&
                      !isFlashFreeDeliveryActive &&
                      !hasFreeDeliveryProductInOrder &&
                      isQtyFreeDeliveryEnabled && (
                      <div
                        className={`p-3 rounded-xl border text-xs transition-all ${
                          isQtyFreeDeliveryUnlocked
                            ? 'bg-emerald-50/95 border-emerald-300 text-emerald-950'
                            : 'bg-amber-50/90 border-amber-300 text-amber-950'
                        }`}
                      >
                        {isQtyFreeDeliveryUnlocked ? (
                          <div className="flex items-center gap-2 font-extrabold">
                            <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                            <span>
                              🎉 অভিনন্দন! {toBanglaCountdownDigits(totalCheckoutItems, 1)} পিস অর্ডারে আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি (৳০)!
                            </span>
                          </div>
                        ) : (
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center gap-2 font-extrabold">
                              <Truck className="w-4 h-4 text-[#c30000] shrink-0" />
                              <span>
                                🚚 আর মাত্র {toBanglaCountdownDigits(remainingQtyForFreeDelivery, 1)} পিস যোগ করলেই ডেলিভারি সম্পূর্ণ ফ্রি! ({toBanglaCountdownDigits(freeDeliveryMinQty, 1)} পিসে ডেলিভারি ফ্রি অফার)
                              </span>
                            </div>
                            {checkoutEntries[0] && (
                              <button
                                type="button"
                                onClick={() => {
                                  if (directBuyItem) {
                                    setDirectBuyItem(prev =>
                                      prev ? { ...prev, quantity: prev.quantity + remainingQtyForFreeDelivery } : null
                                    );
                                  } else {
                                    addToCart(
                                      checkoutEntries[0].product,
                                      remainingQtyForFreeDelivery,
                                      true,
                                      checkoutEntries[0].variant,
                                      true
                                    );
                                  }
                                }}
                                className="px-2.5 py-1 rounded-lg bg-[#c30000] hover:bg-[#9e0000] text-white text-[11px] font-extrabold cursor-pointer shrink-0 shadow-2xs transition-colors"
                              >
                                + {toBanglaCountdownDigits(remainingQtyForFreeDelivery, 1)} পিস বাড়িয়ে ফ্রি ডেলিভারি নিন
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Admin Quick Control for Quantity-Based Free Delivery right on Checkout Page */}
                    {isAuthenticated && (
                      <div className="p-2.5 rounded-xl bg-slate-900 text-white border border-slate-700 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                        <span className="font-extrabold text-amber-300 flex items-center gap-1.5">
                          <Truck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>পিস হিসেবে ফ্রি ডেলিভারি অফার (অ্যাডমিন):</span>
                        </span>
                        <div className="flex flex-wrap items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              updateBusiness({ freeDeliveryByQtyEnabled: false });
                              showToast('পিস হিসেবে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে', 'info');
                            }}
                            className={`px-2 py-1 rounded-lg font-extrabold border cursor-pointer ${
                              !isQtyFreeDeliveryEnabled
                                ? 'bg-rose-600 text-white border-rose-400'
                                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                            }`}
                          >
                            OFF
                          </button>
                          {[2, 3, 4, 5].map(qtyOpt => {
                            const isSel = isQtyFreeDeliveryEnabled && freeDeliveryMinQty === qtyOpt;
                            return (
                              <button
                                key={qtyOpt}
                                type="button"
                                onClick={() => {
                                  updateBusiness({
                                    freeDeliveryByQtyEnabled: true,
                                    freeDeliveryMinQty: qtyOpt,
                                    landingFreeDeliveryByQtyEnabled: true,
                                    landingFreeDeliveryMinQty: qtyOpt
                                  });
                                  showToast(
                                    `ওয়েবসাইট ও ল্যান্ডিং পেজে "${toBanglaCountdownDigits(qtyOpt, 1)} পিস কিনলে ডেলিভারি ফ্রি" চালু করা হয়েছে!`,
                                    'success'
                                  );
                                }}
                                className={`px-2.5 py-1 rounded-lg font-extrabold border cursor-pointer ${
                                  isSel
                                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-2xs'
                                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                                }`}
                              >
                                {toBanglaCountdownDigits(qtyOpt, 1)} পিসে ফ্রি
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Cart Items List with Clean Icon Controls */}
                    <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto pr-0.5">
                      {checkoutEntries.map(({ cartKey, product, variant, quantity }) => {
                        const unitPrice = variant ? variant.retailPrice : product.retailPrice;
                        const isCheckoutFullTitle = currentBusiness.showFullProductNameOnCheckout !== false;
                        return (
                          <div
                            key={cartKey}
                            className={`py-2.5 flex ${
                              isCheckoutFullTitle ? 'items-start' : 'items-center'
                            } gap-2.5`}
                          >
                            <div className="w-12 h-12 rounded-xl border border-slate-200/80 overflow-hidden shrink-0 bg-slate-50/50">
                              <ProductThumbnail product={product} imgClassName="p-1" />
                            </div>

                            <div className="min-w-0 flex-1 space-y-1">
                              <p
                                className={
                                  isCheckoutFullTitle
                                    ? 'text-xs sm:text-[13px] font-bold text-slate-900 leading-snug break-words'
                                    : 'text-xs font-bold text-slate-900 truncate'
                                }
                              >
                                {product.nameBn}
                              </p>
                              <div className="flex items-center gap-2">
                                <div className="inline-flex items-center gap-1 bg-slate-100 rounded-lg p-0.5 border border-slate-200/80">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (directBuyItem) {
                                        setDirectBuyItem(prev => {
                                          if (!prev) return null;
                                          if (prev.quantity <= 1) {
                                            closeAllSubPagesAndRestoreScroll();
                                            return null;
                                          }
                                          return { ...prev, quantity: prev.quantity - 1 };
                                        });
                                      } else {
                                        addToCart(product, -1, true, variant);
                                      }
                                    }}
                                    className="w-6 h-6 rounded-md bg-white hover:bg-emerald-50 flex items-center justify-center text-slate-700 shadow-2xs cursor-pointer"
                                    aria-label="Decrease quantity"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="font-mono font-extrabold text-xs w-6 text-center text-slate-900 tabular-nums">
                                    {quantity}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (directBuyItem) {
                                        setDirectBuyItem(prev =>
                                          prev ? { ...prev, quantity: prev.quantity + 1 } : null
                                        );
                                      } else {
                                        addToCart(product, 1, true, variant);
                                      }
                                    }}
                                    className="w-6 h-6 rounded-md bg-white hover:bg-emerald-50 flex items-center justify-center text-slate-700 shadow-2xs cursor-pointer"
                                    aria-label="Increase quantity"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                                <span className="text-[11px] text-slate-500 truncate">
                                  {variant ? variant.label.split(' (')[0] : product.unit}
                                </span>
                              </div>
                            </div>

                            {/* Right Price & Trash Icon Button */}
                            <div className="flex items-center gap-2 shrink-0">
                              <p className="font-mono font-extrabold text-xs sm:text-sm text-emerald-800 tabular-nums">
                                ৳{unitPrice * quantity}
                              </p>
                              <button
                                type="button"
                                onClick={() => removeFromCart(cartKey)}
                                title="সরিয়ে ফেলুন"
                                aria-label="Remove item"
                                className="w-8 h-8 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200/60 flex items-center justify-center transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Clean Bill Breakdown */}
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5 text-xs">
                      <div className="flex justify-between text-slate-600">
                        <span>পণ্যের মূল্য:</span>
                        <span className="font-mono font-bold text-slate-900 tabular-nums">
                          {formatCurrency(effectiveSubtotal)}
                        </span>
                      </div>
                      {isSpinWheelActive && claimedSpinReward && (spinDiscountAmount > 0 || isSpinFreeDelivery) && (
                        <div className="flex items-start sm:items-center justify-between gap-2 text-rose-700 bg-rose-50 px-2.5 py-2 rounded-lg border border-rose-200">
                          <span className="font-extrabold flex items-start gap-1.5 min-w-0 flex-1 leading-snug break-words">
                            <Gift className="w-3.5 h-3.5 text-[#c30000] shrink-0 mt-0.5" />
                            <span>
                              স্পিন হুইল অফার ({claimedSpinReward.code}): {claimedSpinReward.label}
                            </span>
                          </span>
                          <span className="font-mono font-extrabold tabular-nums shrink-0 whitespace-nowrap">
                            {isSpinFreeDelivery ? 'ফ্রি ডেলিভারি ✓' : `- ${formatCurrency(spinDiscountAmount)}`}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between text-slate-600">
                        <span>
                          ডেলিভারি চার্জ
                          {deliveryCharge > 0
                            ? ` (${selectedDeliveryZone === 'outside_dhaka' ? 'ঢাকার বাইরে' : 'ঢাকার ভিতরে'}${
                                isHalfDeliveryOfferEnabled ? ` · ${deliveryDiscountPct}% ছাড়` : ''
                              })`
                            : isFlashFreeDeliveryActive
                            ? ' (⚡ ফ্ল্যাশ অফার)'
                            : hasFreeDeliveryProductInOrder
                            ? ' (🚚 ফ্রি ডেলিভারি পণ্য)'
                            : isMinAmountFreeDeliveryUnlocked
                            ? ` (৳${freeDeliveryMinOrderAmt}+ অফার)`
                            : isQtyFreeDeliveryUnlocked
                            ? ` (${toBanglaCountdownDigits(freeDeliveryMinQty, 1)}+ পিস অফার)`
                            : ''}
                          :
                        </span>
                        <span className="font-mono font-bold text-emerald-700 tabular-nums">
                          {deliveryCharge === 0 ? (
                            'ফ্রি ডেলিভারি (৳০)'
                          ) : isHalfDeliveryOfferEnabled && selectedRawZoneFee > deliveryCharge ? (
                            <span className="inline-flex items-center gap-1.5">
                              <span className="line-through text-slate-400 text-[11px]">
                                ৳{selectedRawZoneFee}
                              </span>
                              <span className="text-[#c30000] font-extrabold">
                                {formatCurrency(deliveryCharge)}
                              </span>
                            </span>
                          ) : (
                            formatCurrency(deliveryCharge)
                          )}
                        </span>
                      </div>

                      {/* উপায় ১: অর্ডার বক্সের ভেতরেই ১-ট্যাপ ডেলিভারি এরিয়া বাটন [✓ ঢাকার ভিতরে (৳৬০)] [ঢাকার বাইরে (৳১২০)] */}
                      {deliveryCharge > 0 && currentBusiness.checkoutSummaryZoneToggleEnabled !== false && (
                        <div
                          className={`pt-1 pb-0.5 ${
                            currentBusiness.checkoutSummaryZoneHideOnDesktop !== false ? 'lg:hidden' : ''
                          }`}
                        >
                          {(() => {
                            const btnStyle = currentBusiness.checkoutSummaryZoneButtonStyle || 'emerald_pill';
                            const isInside = selectedDeliveryZone === 'inside_dhaka';
                            const isOutside = selectedDeliveryZone === 'outside_dhaka';

                            if (btnStyle === 'segmented_tab') {
                              return (
                                <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-200/80 border border-slate-300/70">
                                  <button
                                    type="button"
                                    onClick={() => setSelectedDeliveryZone('inside_dhaka')}
                                    className={`py-1.5 px-2 rounded-lg text-[11px] font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                                      isInside
                                        ? 'bg-white text-emerald-900 shadow-xs border border-emerald-300'
                                        : 'text-slate-600 hover:text-slate-900'
                                    }`}
                                  >
                                    <span>{isInside ? '✓ ' : ''}ঢাকার ভিতরে</span>
                                    <span className="font-mono text-emerald-700">(৳{insideDhakaFee})</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setSelectedDeliveryZone('outside_dhaka')}
                                    className={`py-1.5 px-2 rounded-lg text-[11px] font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                                      isOutside
                                        ? 'bg-white text-emerald-900 shadow-xs border border-emerald-300'
                                        : 'text-slate-600 hover:text-slate-900'
                                    }`}
                                  >
                                    <span>{isOutside ? '✓ ' : ''}ঢাকার বাইরে</span>
                                    <span className="font-mono text-emerald-700">(৳{outsideDhakaFee})</span>
                                  </button>
                                </div>
                              );
                            }

                            if (btnStyle === 'crimson_bold') {
                              return (
                                <div className="grid grid-cols-2 gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => setSelectedDeliveryZone('inside_dhaka')}
                                    className={`py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                                      isInside
                                        ? 'bg-[#c30000] text-white border-[#c30000] shadow-xs'
                                        : 'bg-white text-slate-700 border-slate-300 hover:border-rose-300'
                                    }`}
                                  >
                                    <span>{isInside ? '✓ ' : ''}ঢাকার ভিতরে (৳{insideDhakaFee})</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setSelectedDeliveryZone('outside_dhaka')}
                                    className={`py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                                      isOutside
                                        ? 'bg-[#c30000] text-white border-[#c30000] shadow-xs'
                                        : 'bg-white text-slate-700 border-slate-300 hover:border-rose-300'
                                    }`}
                                  >
                                    <span>{isOutside ? '✓ ' : ''}ঢাকার বাইরে (৳{outsideDhakaFee})</span>
                                  </button>
                                </div>
                              );
                            }

                            if (btnStyle === 'radio_compact') {
                              return (
                                <div className="grid grid-cols-2 gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => setSelectedDeliveryZone('inside_dhaka')}
                                    className={`py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-between gap-1 ${
                                      isInside
                                        ? 'bg-emerald-50 text-emerald-950 border-emerald-500 ring-1 ring-emerald-500/30'
                                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                                    }`}
                                  >
                                    <span className="inline-flex items-center gap-1.5">
                                      <span
                                        className={`w-3 h-3 rounded-full border flex items-center justify-center ${
                                          isInside ? 'border-emerald-600 bg-emerald-600' : 'border-slate-400'
                                        }`}
                                      >
                                        {isInside && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                                      </span>
                                      <span>ঢাকার ভিতরে</span>
                                    </span>
                                    <span className="font-mono text-emerald-700">৳{insideDhakaFee}</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setSelectedDeliveryZone('outside_dhaka')}
                                    className={`py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-between gap-1 ${
                                      isOutside
                                        ? 'bg-emerald-50 text-emerald-950 border-emerald-500 ring-1 ring-emerald-500/30'
                                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                                    }`}
                                  >
                                    <span className="inline-flex items-center gap-1.5">
                                      <span
                                        className={`w-3 h-3 rounded-full border flex items-center justify-center ${
                                          isOutside ? 'border-emerald-600 bg-emerald-600' : 'border-slate-400'
                                        }`}
                                      >
                                        {isOutside && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                                      </span>
                                      <span>ঢাকার বাইরে</span>
                                    </span>
                                    <span className="font-mono text-emerald-700">৳{outsideDhakaFee}</span>
                                  </button>
                                </div>
                              );
                            }

                            // Default: 'emerald_pill'
                            return (
                              <div className="grid grid-cols-2 gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => setSelectedDeliveryZone('inside_dhaka')}
                                  className={`py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                                    isInside
                                      ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                                      : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-400'
                                  }`}
                                >
                                  <span>{isInside ? '✓ ' : ''}ঢাকার ভিতরে (৳{insideDhakaFee})</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setSelectedDeliveryZone('outside_dhaka')}
                                  className={`py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                                    isOutside
                                      ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                                      : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-400'
                                  }`}
                                >
                                  <span>{isOutside ? '✓ ' : ''}ঢাকার বাইরে (৳{outsideDhakaFee})</span>
                                </button>
                              </div>
                            );
                          })()}

                          {/* অর্ডার বক্সের ভেতরেও আনুমানিক ডেলিভারির সময় ব্যাজ (উপায় ১ বাটনের ঠিক নিচে) */}
                          {currentBusiness.checkoutEstimatedDeliveryEnabled !== false && (
                            <div className="mt-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-50/85 border border-emerald-200/80 text-[11px] font-extrabold text-emerald-950 flex items-center gap-1.5 leading-snug">
                              <span className="shrink-0">📦</span>
                              <span>
                                {selectedDeliveryZone === 'inside_dhaka'
                                  ? (currentBusiness.checkoutEstimatedDeliveryInsideText || '').trim() ||
                                    '🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে'
                                  : (currentBusiness.checkoutEstimatedDeliveryOutsideText || '').trim() ||
                                    '🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)'}
                              </span>
                            </div>
                          )}
                        </div>
                      )}

                      <div className="flex justify-between items-baseline text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-200">
                        <span>সর্বমোট বিল (ক্যাশ অন ডেলিভারি):</span>
                        <span className="font-mono text-base text-emerald-700 tabular-nums">
                          {formatCurrency(grandTotal)}
                        </span>
                      </div>

                      {/* Admin Live Controls for উপায় ১ (Inline Zone Buttons + 4 Designs) & উপায় ২ (Mobile Form First) */}
                      {isAuthenticated && (
                        <div className="mt-2 pt-2.5 border-t border-slate-200/90 space-y-2 text-[11px]">
                          <div className="flex flex-wrap items-center justify-between gap-1.5">
                            <span className="font-extrabold text-slate-700">
                              ⚙️ মোবাইল চেকআউট কন্ট্রোল (উপায় ১ ও ২):
                            </span>
                            <div className="flex flex-wrap items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  const nextVal = currentBusiness.checkoutSummaryZoneToggleEnabled === false;
                                  updateBusiness({ checkoutSummaryZoneToggleEnabled: nextVal });
                                  showToast(
                                    nextVal
                                      ? 'উপায় ১: অর্ডার বক্সে ১-ট্যাপ এরিয়া বাটন চালু (ON) হয়েছে!'
                                      : 'উপায় ১: অর্ডার বক্সে ১-ট্যাপ এরিয়া বাটন বন্ধ (OFF) হয়েছে!',
                                    nextVal ? 'success' : 'info'
                                  );
                                }}
                                className={`px-2 py-1 rounded-lg font-extrabold border cursor-pointer ${
                                  currentBusiness.checkoutSummaryZoneToggleEnabled !== false
                                    ? 'bg-emerald-700 text-white border-emerald-700'
                                    : 'bg-white text-slate-600 border-slate-300'
                                }`}
                              >
                                উপায় ১ (বাটন): {currentBusiness.checkoutSummaryZoneToggleEnabled !== false ? 'ON' : 'OFF'}
                              </button>

                              {currentBusiness.checkoutSummaryZoneToggleEnabled !== false && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const isCurrentlyHiddenOnDesktop =
                                      currentBusiness.checkoutSummaryZoneHideOnDesktop !== false;
                                    const nextHideOnDesktop = !isCurrentlyHiddenOnDesktop;
                                    updateBusiness({ checkoutSummaryZoneHideOnDesktop: nextHideOnDesktop });
                                    showToast(
                                      nextHideOnDesktop
                                        ? '🖥️ ডেক্সটপে হাইড চালু (ON): ঢাকার ভিতরে/বাইরে বাটনটি এখন শুধু মোবাইলে দেখাবে, ডেক্সটপে হাইড থাকবে!'
                                        : '💻 ডেক্সটপে হাইড বন্ধ (OFF): ঢাকার ভিতরে/বাইরে বাটনটি এখন মোবাইল ও ডেক্সটপ উভয় ভিউতে দেখাবে!',
                                      nextHideOnDesktop ? 'success' : 'info'
                                    );
                                  }}
                                  className={`px-2 py-1 rounded-lg font-extrabold border cursor-pointer transition-all ${
                                    currentBusiness.checkoutSummaryZoneHideOnDesktop !== false
                                      ? 'bg-sky-700 text-white border-sky-700 shadow-2xs'
                                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                                  }`}
                                  title="অর্ডার বক্সের ভেতরের ঢাকার ভিতরে/বাইরে বাটনটি ডেক্সটপ থেকে হাইড (ON) অথবা ডেক্সটপেও দৃশ্যমান (OFF) করুন"
                                >
                                  {currentBusiness.checkoutSummaryZoneHideOnDesktop !== false
                                    ? '🖥️ ডেক্সটপে হাইড: ON (শুধু মোবাইলে)'
                                    : '💻 ডেক্সটপে হাইড: OFF (সব ডিভাইসে)'}
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => {
                                  const nextOrder = !Boolean(currentBusiness.checkoutMobileFormFirst);
                                  updateBusiness({ checkoutMobileFormFirst: nextOrder });
                                  showToast(
                                    nextOrder
                                      ? 'উপায় ২ (ON): মোবাইলে আগে ফর্ম, পরে নিচে অর্ডার বিল দেখানো হচ্ছে!'
                                      : 'উপায় ২ (OFF): মোবাইলে উপরে অর্ডার বিল, নিচে ফর্ম দেখানো হচ্ছে!',
                                    'success'
                                  );
                                }}
                                className={`px-2 py-1 rounded-lg font-extrabold border cursor-pointer ${
                                  currentBusiness.checkoutMobileFormFirst
                                    ? 'bg-indigo-700 text-white border-indigo-700'
                                    : 'bg-white text-slate-600 border-slate-300'
                                }`}
                              >
                                উপায় ২ (আগে ফর্ম): {currentBusiness.checkoutMobileFormFirst ? 'ON' : 'OFF'}
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  const nextEst = currentBusiness.checkoutEstimatedDeliveryEnabled === false;
                                  updateBusiness({ checkoutEstimatedDeliveryEnabled: nextEst });
                                  showToast(
                                    nextEst
                                      ? '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন চালু (ON) করা হয়েছে!'
                                      : '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন বন্ধ (OFF) করা হয়েছে!',
                                    nextEst ? 'success' : 'info'
                                  );
                                }}
                                className={`px-2 py-1 rounded-lg font-extrabold border cursor-pointer transition-all ${
                                  currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                                    ? 'bg-teal-700 text-white border-teal-700 shadow-2xs'
                                    : 'bg-white text-slate-600 border-slate-300'
                                }`}
                                title="ডেলিভারির আনুমানিক তারিখ প্রদর্শন (Estimated Delivery Date Badge) ON / OFF করুন"
                              >
                                📦 ডেলিভারি সময়: {currentBusiness.checkoutEstimatedDeliveryEnabled !== false ? 'ON' : 'OFF'}
                              </button>
                            </div>
                          </div>

                          {currentBusiness.checkoutSummaryZoneToggleEnabled !== false && (
                            <div className="flex flex-wrap items-center gap-1">
                              <span className="text-[10px] font-bold text-slate-500 mr-1">বাটন ডিজাইন:</span>
                              {(
                                [
                                  { id: 'emerald_pill', label: '১. গ্রিন পিল' },
                                  { id: 'segmented_tab', label: '২. স্লাইড ট্যাব' },
                                  { id: 'crimson_bold', label: '৩. রেড বোল্ড' },
                                  { id: 'radio_compact', label: '৪. রেডিও কার্ড' }
                                ] as const
                              ).map(st => {
                                const activeSt =
                                  (currentBusiness.checkoutSummaryZoneButtonStyle || 'emerald_pill') === st.id;
                                return (
                                  <button
                                    key={st.id}
                                    type="button"
                                    onClick={() => {
                                      updateBusiness({ checkoutSummaryZoneButtonStyle: st.id });
                                      showToast(`ডেলিভারি এরিয়া বাটন ডিজাইন "${st.label}" সেট করা হয়েছে!`, 'success');
                                    }}
                                    className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border cursor-pointer ${
                                      activeSt
                                        ? 'bg-amber-500 text-slate-950 border-amber-600'
                                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                                    }`}
                                  >
                                    {st.label}
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Clean Customer Delivery Info Form (Supports উপায় ২: Mobile Form-First vs Order-Box-First) */}
                  <form
                    id="checkout-delivery-form"
                    noValidate
                    onSubmit={handlePlaceOrderSubmit}
                    className={`lg:col-span-7 ${
                      currentBusiness.checkoutMobileFormFirst ? 'order-1 lg:order-1' : 'order-2 lg:order-1'
                    } bg-white rounded-2xl border border-slate-200/85 shadow-2xs p-4 sm:p-6 space-y-4 text-sm`}
                  >
                    <div className="pb-2.5 border-b border-slate-100">
                      <h2 className="font-extrabold text-base sm:text-lg text-slate-900">
                        ডেলিভারি ঠিকানা ও তথ্য দিন
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                        পণ্য হাতে পেয়ে ডেলিভারিম্যানের কাছে নগদ টাকা পরিশোধ করবেন
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      <div data-checkout-field="name" className="max-md:scroll-mt-24 max-md:scroll-mb-40">
                        <label htmlFor="checkout-input-name" className="block text-[14px] sm:text-[15px] font-extrabold text-slate-800 mb-1.5">
                          আপনার নাম <span className="text-rose-600">*</span>
                        </label>
                        <input
                          id="checkout-input-name"
                          type="text"
                          value={customerName}
                          onChange={(e) => {
                            const val = e.target.value;
                            setCustomerName(val);
                            if (checkoutErrorField === 'name') setCheckoutErrorField(null);
                            saveFbCustomerIdentity(
                              {
                                name: val.trim() || undefined,
                                phone: customerPhone.trim() || undefined,
                                address: deliveryAddress.trim() || undefined
                              },
                              currentBusiness
                            );
                          }}
                          onBlur={(e) => {
                            const val = e.target.value;
                            saveFbCustomerIdentity(
                              {
                                name: val.trim() || undefined,
                                phone: customerPhone.trim() || undefined,
                                address: deliveryAddress.trim() || undefined
                              },
                              currentBusiness
                            );
                            captureStorefrontIncompleteLeadNow(val, customerPhone, deliveryAddress);
                          }}
                          placeholder="আপনার নাম লিখুন"
                          className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl text-[14px] sm:text-[15px] text-slate-900 font-medium placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:font-normal placeholder:text-slate-400 outline-hidden transition-all border max-md:scroll-mt-24 max-md:scroll-mb-40 ${
                            checkoutErrorField === 'name'
                              ? 'bg-rose-50/50 border-rose-500 ring-2 ring-rose-500/20'
                              : 'bg-slate-50 border-slate-300 focus:border-emerald-600 focus:bg-white'
                          }`}
                        />
                        {checkoutErrorField === 'name' && (
                          <p className="text-xs font-bold text-rose-600 mt-1">
                            * অনুগ্রহ করে আপনার নাম লিখুন
                          </p>
                        )}
                      </div>

                      <div data-checkout-field="phone" className="max-md:scroll-mt-24 max-md:scroll-mb-40">
                        <label htmlFor="checkout-input-phone" className="block text-[14px] sm:text-[15px] font-extrabold text-slate-800 mb-1.5">
                          মোবাইল নম্বর <span className="text-rose-600">*</span>
                        </label>
                        <input
                          id="checkout-input-phone"
                          type="tel"
                          inputMode="tel"
                          value={customerPhone}
                          onChange={(e) => {
                            const val = e.target.value;
                            setCustomerPhone(val);
                            if (checkoutErrorField === 'phone') setCheckoutErrorField(null);
                            saveFbCustomerIdentity(
                              {
                                name: customerName.trim() || undefined,
                                phone: val.trim() || undefined,
                                address: deliveryAddress.trim() || undefined
                              },
                              currentBusiness
                            );
                          }}
                          onBlur={(e) => {
                            const val = e.target.value;
                            const norm = normalizeBdPhone(val);
                            const finalPhone = isValidBdPhone11(norm) ? norm : val.trim();
                            if (isValidBdPhone11(norm) && val.trim() !== norm) {
                              setCustomerPhone(norm);
                            }
                            saveFbCustomerIdentity(
                              {
                                name: customerName.trim() || undefined,
                                phone: finalPhone || undefined,
                                address: deliveryAddress.trim() || undefined
                              },
                              currentBusiness
                            );
                            captureStorefrontIncompleteLeadNow(customerName, finalPhone, deliveryAddress);
                          }}
                          placeholder="017XXXXXXXX (১১ ডিজিট)"
                          className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl text-[14px] sm:text-[15px] tabular-nums text-slate-900 font-semibold placeholder:font-sans placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:font-normal placeholder:tracking-normal placeholder:text-slate-400 outline-hidden transition-all border max-md:scroll-mt-24 max-md:scroll-mb-40 ${
                            checkoutErrorField === 'phone'
                              ? 'bg-rose-50/50 border-rose-500 ring-2 ring-rose-500/20'
                              : 'bg-slate-50 border-slate-300 focus:border-emerald-600 focus:bg-white'
                          }`}
                        />
                        {checkoutErrorField === 'phone' && (
                          <p className="text-xs font-bold text-rose-600 mt-1">
                            * সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন
                          </p>
                        )}
                      </div>
                    </div>

                    <div data-checkout-field="address" className="max-md:scroll-mt-24 max-md:scroll-mb-40">
                      <label htmlFor="checkout-input-address" className="block text-[14px] sm:text-[15px] font-extrabold text-slate-800 mb-1.5">
                        সম্পূর্ণ ডেলিভারি ঠিকানা <span className="text-rose-600">*</span>
                      </label>
                      <input
                        id="checkout-input-address"
                        type="text"
                        value={deliveryAddress}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDeliveryAddress(val);
                          if (checkoutErrorField === 'address') setCheckoutErrorField(null);
                          saveFbCustomerIdentity(
                            {
                              name: customerName.trim() || undefined,
                              phone: customerPhone.trim() || undefined,
                              address: val.trim() || undefined
                            },
                            currentBusiness
                          );
                        }}
                        onBlur={(e) => {
                          const val = e.target.value;
                          saveFbCustomerIdentity(
                            {
                              name: customerName.trim() || undefined,
                              phone: customerPhone.trim() || undefined,
                              address: val.trim() || undefined
                            },
                            currentBusiness
                          );
                          captureStorefrontIncompleteLeadNow(customerName, customerPhone, val);
                        }}
                        placeholder="বাসা নং, রোড নং, এলাকা ও জেলা লিখুন"
                        className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl text-[14px] sm:text-[15px] text-slate-900 font-medium placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:font-normal placeholder:text-slate-400 outline-hidden transition-all border max-md:scroll-mt-24 max-md:scroll-mb-40 ${
                          checkoutErrorField === 'address'
                            ? 'bg-rose-50/50 border-rose-500 ring-2 ring-rose-500/20'
                            : 'bg-slate-50 border-slate-300 focus:border-emerald-600 focus:bg-white'
                        }`}
                      />
                      {checkoutErrorField === 'address' && (
                        <p className="text-xs font-bold text-rose-600 mt-1">
                          * সম্পূর্ণ ডেলিভারি ঠিকানা লিখুন
                        </p>
                      )}
                    </div>

                    {/* Conditional Delivery Area Selection ("ঢাকার ভিতরে" / "ঢাকার বাইরে") — Hidden when Admin enables Free Delivery */}
                    {!isAdminFreeDeliveryEnabled && (
                      <div>
                        <div className="flex flex-wrap items-center justify-between gap-1.5 mb-1.5">
                          <label className="block text-[14px] sm:text-[15px] font-extrabold text-slate-800">
                            ডেলিভারি এরিয়া নির্বাচন করুন <span className="text-rose-600">*</span>
                          </label>
                          {!isFreeDelivery && isHalfDeliveryOfferEnabled && (
                            <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-extrabold animate-pulse">
                              🔥 ডেলিভারি চার্জে {deliveryDiscountPct}% ছাড় চলছে!
                            </span>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <label
                            onClick={() => setSelectedDeliveryZone('inside_dhaka')}
                            className={`flex items-center justify-between p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                              selectedDeliveryZone === 'inside_dhaka'
                                ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-2xs'
                                : 'border-slate-200 bg-slate-50 hover:border-slate-300 text-slate-700'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <input
                                type="radio"
                                name="deliveryZone"
                                value="inside_dhaka"
                                checked={selectedDeliveryZone === 'inside_dhaka'}
                                onChange={() => setSelectedDeliveryZone('inside_dhaka')}
                                className="w-4 h-4 accent-emerald-600 cursor-pointer"
                              />
                              <span className="font-extrabold text-[14px] sm:text-[15px]">ঢাকার ভিতরে</span>
                            </div>
                            <span className="font-mono font-extrabold text-sm sm:text-[15px] text-emerald-700">
                              {isFreeDelivery ? (
                                <span className="inline-flex items-center gap-1">
                                  <span className="line-through text-slate-400 text-xs">৳{rawInsideDhakaFee}</span>
                                  <span className="text-emerald-700">ফ্রি (৳০)</span>
                                </span>
                              ) : isHalfDeliveryOfferEnabled && rawInsideDhakaFee > insideDhakaFee ? (
                                <span className="inline-flex items-center gap-1.5">
                                  <span className="line-through text-slate-400 text-xs">৳{rawInsideDhakaFee}</span>
                                  <span className="text-[#c30000] font-black">৳{insideDhakaFee}</span>
                                </span>
                              ) : (
                                `৳${insideDhakaFee}`
                              )}
                            </span>
                          </label>

                          <label
                            onClick={() => setSelectedDeliveryZone('outside_dhaka')}
                            className={`flex items-center justify-between p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                              selectedDeliveryZone === 'outside_dhaka'
                                ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-2xs'
                                : 'border-slate-200 bg-slate-50 hover:border-slate-300 text-slate-700'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <input
                                type="radio"
                                name="deliveryZone"
                                value="outside_dhaka"
                                checked={selectedDeliveryZone === 'outside_dhaka'}
                                onChange={() => setSelectedDeliveryZone('outside_dhaka')}
                                className="w-4 h-4 accent-emerald-600 cursor-pointer"
                              />
                              <span className="font-extrabold text-[14px] sm:text-[15px]">ঢাকার বাইরে</span>
                            </div>
                            <span className="font-mono font-extrabold text-sm sm:text-[15px] text-emerald-700">
                              {isFreeDelivery ? (
                                <span className="inline-flex items-center gap-1">
                                  <span className="line-through text-slate-400 text-xs">৳{rawOutsideDhakaFee}</span>
                                  <span className="text-emerald-700">ফ্রি (৳০)</span>
                                </span>
                              ) : isHalfDeliveryOfferEnabled && rawOutsideDhakaFee > outsideDhakaFee ? (
                                <span className="inline-flex items-center gap-1.5">
                                  <span className="line-through text-slate-400 text-xs">৳{rawOutsideDhakaFee}</span>
                                  <span className="text-[#c30000] font-black">৳{outsideDhakaFee}</span>
                                </span>
                              ) : (
                                `৳${outsideDhakaFee}`
                              )}
                            </span>
                          </label>
                        </div>

                        {/* ৫. 📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন (Estimated Delivery Date Badge — ON / OFF) */}
                        {(currentBusiness.checkoutEstimatedDeliveryEnabled !== false || isAuthenticated) && (
                          <div
                            className={`mt-2.5 p-2.5 sm:px-3.5 sm:py-2.5 rounded-xl border flex flex-wrap items-center justify-between gap-2 transition-all ${
                              currentBusiness.checkoutEstimatedDeliveryEnabled === false
                                ? 'bg-slate-100/80 border-dashed border-slate-300 text-slate-500'
                                : selectedDeliveryZone === 'inside_dhaka'
                                ? 'bg-emerald-50/90 border-emerald-200/90 text-emerald-950'
                                : 'bg-teal-50/90 border-teal-200/90 text-teal-950'
                            }`}
                          >
                            <div className="flex items-center gap-2 text-xs sm:text-[13px] font-extrabold leading-snug">
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-white border border-emerald-200/80 shadow-2xs shrink-0 text-sm">
                                📦
                              </span>
                              <span>
                                {selectedDeliveryZone === 'inside_dhaka'
                                  ? (currentBusiness.checkoutEstimatedDeliveryInsideText || '').trim() ||
                                    '🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে'
                                  : (currentBusiness.checkoutEstimatedDeliveryOutsideText || '').trim() ||
                                    '🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)'}
                              </span>
                            </div>

                            {isAuthenticated && (
                              <button
                                type="button"
                                onClick={() => {
                                  const nextEstOn = currentBusiness.checkoutEstimatedDeliveryEnabled === false;
                                  updateBusiness({ checkoutEstimatedDeliveryEnabled: nextEstOn });
                                  showToast(
                                    nextEstOn
                                      ? '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন চালু (ON) করা হয়েছে!'
                                      : '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন বন্ধ (OFF) করা হয়েছে!',
                                    nextEstOn ? 'success' : 'info'
                                  );
                                }}
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all shrink-0 ${
                                  currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                    : 'bg-slate-700 text-white border-slate-700'
                                }`}
                                title="অ্যাডমিন কন্ট্রোল: ডেলিভারির আনুমানিক তারিখ প্রদর্শন (Estimated Delivery Badge) ON / OFF করুন"
                              >
                                {currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                                  ? '📦 ডেলিভারি সময়: ON'
                                  : '📦 ডেলিভারি সময়: OFF (লুকানো)'}
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    <div>
                      <label className="block text-[14px] sm:text-[15px] font-extrabold text-slate-800 mb-1.5">
                        অর্ডার নোট (ঐচ্ছিক)
                      </label>
                      <input
                        type="text"
                        value={orderNotes}
                        onChange={(e) => setOrderNotes(e.target.value)}
                        placeholder="ডেলিভারির আগে কল দিন..."
                        className="w-full min-h-[46px] px-3.5 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-[14px] sm:text-[15px] font-medium placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:font-normal placeholder:text-slate-400 text-slate-900 outline-hidden transition-colors"
                      />
                    </div>

                    {!isBrowserOnline && (
                      <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs font-bold flex items-start gap-2">
                        <span className="text-sm leading-none mt-0.5">⚠️</span>
                        <span>
                          আপনার ইন্টারনেট সংযোগ (Mobile Data / Wi-Fi) বন্ধ আছে! অর্ডার কনফার্ম করার জন্য অনুগ্রহ করে ইন্টারনেট চালু করুন।
                        </span>
                      </div>
                    )}

                    {/* Desktop Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmittingOrder || checkoutEntries.length === 0}
                      className="hidden lg:flex w-full min-h-[50px] sm:min-h-[52px] py-3.5 px-5 bg-[#c30000] hover:bg-[#9e0000] disabled:opacity-60 text-white font-extrabold text-base sm:text-lg rounded-xl shadow-sm items-center justify-center gap-2 transition-all cursor-pointer active:scale-[0.99] whitespace-nowrap"
                    >
                      <CheckCircle2 className="w-5 h-5 shrink-0" />
                      <span className="tabular-nums whitespace-nowrap">
                        {isSubmittingOrder
                          ? 'অর্ডার প্রসেস হচ্ছে...'
                          : isStorefrontFloatingPriceOn
                          ? `অর্ডার কনফার্ম করুন (${formatCurrency(grandTotal)})`
                          : 'অর্ডার কনফার্ম করুন'}
                      </span>
                    </button>
                  </form>
                </div>

                {/* Mobile Sticky Floating Bottom "অর্ডার কনফার্ম করুন" Button (Matches Landing Page Size & Typography) */}
                {isStorefrontFloatingBtnOn && (
                  <div className="lg:hidden fixed bottom-3.5 left-3 right-3 z-40 pointer-events-none">
                    <div className="max-w-md mx-auto pointer-events-auto">
                      <div className={sfIsBeamAnim ? `rounded-2xl ${sfWrapperAnimClass}` : ''}>
                        <button
                          type="submit"
                          form="checkout-delivery-form"
                          disabled={isSubmittingOrder || checkoutEntries.length === 0}
                          className={`w-full min-h-[50px] sm:min-h-[52px] py-3 sm:py-3.5 px-3.5 sm:px-5 bg-[#c30000] hover:bg-[#9e0000] disabled:opacity-60 text-white font-extrabold text-[14px] min-[380px]:text-[15px] sm:text-lg rounded-2xl shadow-xl flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer active:scale-[0.97] whitespace-nowrap ${sfInnerAnimClass}`}
                        >
                          <CheckCircle2 className="w-4 h-4 min-[380px]:w-5 min-[380px]:h-5 shrink-0" />
                          <span className="tabular-nums whitespace-nowrap">
                            {isSubmittingOrder
                              ? 'অর্ডার প্রসেস হচ্ছে...'
                              : isStorefrontFloatingPriceOn
                              ? `অর্ডার কনফার্ম করুন (${formatCurrency(grandTotal)})`
                              : 'অর্ডার কনফার্ম করুন'}
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        ) : quickViewProduct ? (
          /* SUB-PAGE C: Dedicated Full-Page Product Details View (No Blur Popup!) */
          (() => {
            const qvActiveVariant = getActiveVariant(quickViewProduct);
            const qvRetailPrice = qvActiveVariant
              ? qvActiveVariant.retailPrice
              : quickViewProduct.retailPrice;
            const qvMrpPrice = getRegularMrpFromRetail(
              qvRetailPrice,
              qvActiveVariant?.regularPrice ?? quickViewProduct.regularPrice,
              qvActiveVariant?.discountPrice ?? quickViewProduct.discountPrice
            );
            const qvDiscount = Math.max(0, qvMrpPrice - qvRetailPrice);
            const qvStock = getProductAvailableStock(quickViewProduct);
            const relatedProducts = [
              ...products.filter(
                p => !p.isLandingPageProduct && p.categoryId === quickViewProduct.categoryId && p.id !== quickViewProduct.id
              ),
              ...products.filter(
                p => !p.isLandingPageProduct && p.categoryId !== quickViewProduct.categoryId && p.id !== quickViewProduct.id
              )
            ].slice(0, 5);

            // Configured WhatsApp Order & Call For Order Numbers (from Developer Account)
            const rawWhatsappPhone = (
              currentBusiness.whatsappOrderPhone ||
              currentBusiness.phone ||
              '01711234567'
            ).trim();
            const cleanWaDigits = rawWhatsappPhone.replace(/\D/g, '');
            const formattedWaNumber = cleanWaDigits.startsWith('880')
              ? cleanWaDigits
              : cleanWaDigits.startsWith('0')
              ? `88${cleanWaDigits}`
              : `880${cleanWaDigits}`;
            const rawCallOrderPhone = (
              currentBusiness.callOrderPhone ||
              currentBusiness.phone ||
              '01711234567'
            ).trim();
            const productFullUrl =
              typeof window !== 'undefined'
                ? `${window.location.origin}${buildProductPath(quickViewProduct)}`
                : buildProductPath(quickViewProduct);
            const waOrderText = [
              `আসসালামু আলাইকুম, আমি এই পণ্যটি অর্ডার করতে চাই:`,
              `পণ্য: ${quickViewProduct.nameBn}${qvActiveVariant ? ` (${qvActiveVariant.label})` : ''}`,
              `পরিমাণ: ${quickViewQty} টি`,
              `মোট মূল্য: ৳${qvRetailPrice * quickViewQty}`,
              `পণ্যের লিংক: ${productFullUrl}`
            ].join('\n');
            const whatsappOrderHref = `https://wa.me/${formattedWaNumber}?text=${encodeURIComponent(
              waOrderText
            )}`;

            // Build Product Image Gallery items (Strictly real uploaded images only — 1 uploaded image = 1 slide, no 4x fake duplication)
            const uploadedImagesList = Array.from(
              new Set(
                [
                  quickViewProduct.image,
                  ...(Array.isArray(quickViewProduct.galleryImages)
                    ? quickViewProduct.galleryImages
                    : []),
                  ...(Array.isArray(quickViewProduct.variants)
                    ? quickViewProduct.variants.map(v => v.imageUrl)
                    : [])
                ].filter(
                  (img): img is string =>
                    Boolean(
                      img &&
                        img.trim() !== '' &&
                        !img.includes('images.unsplash.com/photo-1599599810769') &&
                        !img.includes('images.unsplash.com/photo-1607623814075') &&
                        !img.includes('images.unsplash.com/photo-1509440159596')
                    )
                )
              )
            );

            const galleryItems: Array<{
              id: string;
              label: string;
              imageUrl?: string;
            }> =
              uploadedImagesList.length > 0
                ? uploadedImagesList.map((imgUrl, idx) => ({
                    id: `gal_${idx}`,
                    label: idx === 0 ? 'মেইন ছবি' : `গ্যালারি ছবি ${idx + 1}`,
                    imageUrl: imgUrl
                  }))
                : [
                    {
                      id: 'gal_default',
                      label: 'মেইন ভিউ',
                      imageUrl: ''
                    }
                  ];

            const safeGalleryIdx =
              activeGalleryIndex >= 0 && activeGalleryIndex < galleryItems.length
                ? activeGalleryIndex
                : 0;
            const currentGallerySlide = galleryItems[safeGalleryIdx];
            const productDescriptionText =
              quickViewProduct.description !== undefined
                ? quickViewProduct.description.trim()
                : getEffectiveProductDescription(quickViewProduct);

            const handleQvPrevSlide = () => {
              if (galleryItems.length <= 1) return;
              setActiveGalleryIndex(
                (safeGalleryIdx - 1 + galleryItems.length) % galleryItems.length
              );
            };

            const handleQvNextSlide = () => {
              if (galleryItems.length <= 1) return;
              setActiveGalleryIndex((safeGalleryIdx + 1) % galleryItems.length);
            };

            const handleQvTouchStart = (e: React.TouchEvent) => {
              qvTouchEndXRef.current = null;
              qvTouchStartXRef.current = e.targetTouches[0]?.clientX ?? null;
            };

            const handleQvTouchMove = (e: React.TouchEvent) => {
              qvTouchEndXRef.current = e.targetTouches[0]?.clientX ?? null;
            };

            const handleQvTouchEnd = () => {
              if (qvTouchStartXRef.current === null || qvTouchEndXRef.current === null) return;
              const distance = qvTouchStartXRef.current - qvTouchEndXRef.current;
              if (Math.abs(distance) > 30) {
                if (distance > 0) {
                  handleQvNextSlide();
                } else {
                  handleQvPrevSlide();
                }
              }
              qvTouchStartXRef.current = null;
              qvTouchEndXRef.current = null;
            };

            const handleQvMouseDown = (e: React.MouseEvent) => {
              qvMouseStartXRef.current = e.clientX;
            };

            const handleQvMouseUp = (e: React.MouseEvent) => {
              if (qvMouseStartXRef.current === null) return;
              const distance = qvMouseStartXRef.current - e.clientX;
              if (Math.abs(distance) > 35) {
                if (distance > 0) {
                  handleQvNextSlide();
                } else {
                  handleQvPrevSlide();
                }
              } else if (isLightboxAllowed && Math.abs(distance) < 6) {
                setQvLightboxScale(1);
                setQvLightboxPan({ x: 50, y: 50 });
                setQvLightboxOpen(true);
              }
              qvMouseStartXRef.current = null;
            };

            const handleQvMouseMoveZoom = (e: React.MouseEvent<HTMLDivElement>) => {
              if (!isHoverZoomAllowed) return;
              const rect = e.currentTarget.getBoundingClientRect();
              if (!rect.width || !rect.height) return;
              const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
              const y = Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100));
              setQvHoverZoom({ active: true, x, y });
            };

            const zoomStyleLabels: Record<
              'woocommerce_lightbox' | 'hover_and_lightbox' | 'hover_only',
              string
            > = {
              woocommerce_lightbox: 'উকমার্স লাইটবক্স (WooCommerce)',
              hover_and_lightbox: 'হোভার জুম + লাইটবক্স',
              hover_only: 'শুধু হোভার ম্যাগনিফায়ার'
            };

            return (
              <div key={`page-product-${quickViewProduct.id}`} className="space-y-5 pb-24 animate-page-rise">
                {/* Main Product Details Card (With Hand-Swipeable Larger Image Gallery & WooCommerce Lightbox / Zoom) */}
                <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-2 sm:p-5">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4 sm:gap-6 items-start">
                    {/* Left Column: Hand-Swipeable Larger Product Image Gallery */}
                    <div className="md:col-span-6 space-y-2.5 w-full">
                      {/* Main Gallery Stage (Swipe Left/Right by Hand or Mouse + WooCommerce Lightbox Trigger) */}
                      <div
                        onTouchStart={handleQvTouchStart}
                        onTouchMove={handleQvTouchMove}
                        onTouchEnd={handleQvTouchEnd}
                        onMouseDown={handleQvMouseDown}
                        onMouseUp={handleQvMouseUp}
                        onMouseMove={handleQvMouseMoveZoom}
                        onMouseLeave={() => setQvHoverZoom(prev => ({ ...prev, active: false }))}
                        className={`relative aspect-square w-full rounded-xl border border-slate-200/60 overflow-hidden bg-white select-none group ${
                          isGlobalImageZoomEnabled
                            ? 'cursor-zoom-in'
                            : galleryItems.length > 1
                              ? 'cursor-grab active:cursor-grabbing'
                              : 'cursor-default'
                        }`}
                      >
                        <div
                          className="flex w-full h-full transition-transform duration-300 ease-out"
                          style={{
                            transform: `translateX(-${safeGalleryIdx * 100}%)`
                          }}
                        >
                          {galleryItems.map((item, idx) => {
                            const isCurrentZooming =
                              isHoverZoomAllowed && qvHoverZoom.active && idx === safeGalleryIdx;
                            return (
                              <div
                                key={item.id}
                                className="w-full h-full shrink-0 overflow-hidden flex items-center justify-center bg-white"
                              >
                                <div
                                  className="w-full h-full transition-transform duration-200 ease-out"
                                  style={
                                    isCurrentZooming
                                      ? {
                                          transform: 'scale(1.85)',
                                          transformOrigin: `${qvHoverZoom.x}% ${qvHoverZoom.y}%`
                                        }
                                      : undefined
                                  }
                                >
                                  <ProductThumbnail
                                    eager
                                    product={{
                                      ...quickViewProduct,
                                      image: item.imageUrl || quickViewProduct.image
                                    }}
                                    imgClassName="p-0"
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {qvDiscount > 0 && qvStock > 0 && (
                          <span className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-xs font-extrabold px-2.5 py-1 rounded-lg shadow-2xs z-10 pointer-events-none">
                            সাশ্রয় ৳{qvDiscount}
                          </span>
                        )}

                        {/* Smart Stock Out Image Overlay on Product Detail Page */}
                        {renderStockOutImageOverlay(qvStock <= 0, true)}

                        {/* Classic WooCommerce Floating Magnifier Trigger Button (.woocommerce-product-gallery__trigger) */}
                        {isLightboxAllowed && (
                          <button
                            type="button"
                            onMouseDown={e => e.stopPropagation()}
                            onMouseUp={e => e.stopPropagation()}
                            onClick={e => {
                              e.stopPropagation();
                              setQvLightboxScale(1);
                              setQvLightboxPan({ x: 50, y: 50 });
                              setQvLightboxOpen(true);
                            }}
                            className="absolute top-2.5 right-2.5 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/95 hover:bg-white text-slate-800 hover:text-emerald-700 border border-slate-200/90 shadow-md flex items-center justify-center z-20 cursor-pointer transition-all hover:scale-105 active:scale-95"
                            title="ছবি বড় করে দেখুন (WooCommerce Fullscreen Lightbox)"
                            aria-label="Open product image in fullscreen lightbox"
                          >
                            <Search className="w-4 h-4 sm:w-[18px] sm:h-[18px] stroke-[2.4]" />
                          </button>
                        )}

                        {/* Gallery Counter Badge (Shown only when multiple images exist) */}
                        {galleryItems.length > 1 && (
                          <span
                            className={`absolute ${
                              isLightboxAllowed ? 'top-14 right-2.5' : 'top-2.5 right-2.5'
                            } bg-slate-900/75 text-white text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg backdrop-blur-xs z-10 pointer-events-none`}
                          >
                            {safeGalleryIdx + 1} / {galleryItems.length}
                          </span>
                        )}

                        {/* Slide Dots Indicator on Bottom of Image (Only when multiple images exist) */}
                        {galleryItems.length > 1 && (
                          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/55 backdrop-blur-xs z-10">
                            {galleryItems.map((item, idx) => (
                              <button
                                key={`qv_dot_${item.id}`}
                                type="button"
                                onMouseDown={e => e.stopPropagation()}
                                onMouseUp={e => e.stopPropagation()}
                                onClick={e => {
                                  e.stopPropagation();
                                  setActiveGalleryIndex(idx);
                                }}
                                className={`h-2 rounded-full transition-all cursor-pointer ${
                                  safeGalleryIdx === idx
                                    ? 'w-5 bg-white'
                                    : 'w-2 bg-white/55 hover:bg-white/80'
                                }`}
                                aria-label={`Slide ${idx + 1}`}
                              />
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Thumbnail Strip Below Main Image (Strictly shown ONLY when multiple gallery images exist) */}
                      {galleryItems.length > 1 && (
                        <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                          {galleryItems.map((item, idx) => {
                            const isSelectedThumb = idx === safeGalleryIdx;
                            return (
                              <button
                                key={item.id}
                                type="button"
                                onClick={() => setActiveGalleryIndex(idx)}
                                className={`relative aspect-square rounded-xl overflow-hidden border-2 bg-white transition-all cursor-pointer ${
                                  isSelectedThumb
                                    ? 'border-[#c30000] ring-2 ring-[#c30000]/20 shadow-xs'
                                    : 'border-slate-200 hover:border-slate-400 opacity-80 hover:opacity-100'
                                }`}
                              >
                                <ProductThumbnail
                                  eager
                                  product={{
                                    ...quickViewProduct,
                                    image: item.imageUrl || quickViewProduct.image
                                  }}
                                  imgClassName="p-0.5"
                                />
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Authentic WooCommerce PhotoSwipe Fullscreen Dark Lightbox Modal */}
                      {isLightboxAllowed && qvLightboxOpen && (
                        <div
                          onClick={() => setQvLightboxOpen(false)}
                          className="fixed inset-0 z-[120] bg-black/95 backdrop-blur-xs flex flex-col justify-between select-none animate-fade-in"
                        >
                          {/* PhotoSwipe Top Toolbar */}
                          <div
                            onClick={e => e.stopPropagation()}
                            className="w-full px-3 sm:px-6 py-3 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between gap-3 text-white z-20"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <span className="font-mono text-xs sm:text-sm font-extrabold text-white/90 bg-white/10 px-2.5 py-1 rounded-lg border border-white/15 shrink-0">
                                {safeGalleryIdx + 1} / {galleryItems.length}
                              </span>
                              <span className="text-xs sm:text-sm font-bold text-white/90 truncate">
                                {quickViewProduct.nameBn}
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                              <button
                                type="button"
                                onClick={() => {
                                  const nextScale = qvLightboxScale <= 1 ? 2 : qvLightboxScale < 2.6 ? 2.8 : 1;
                                  setQvLightboxScale(nextScale);
                                  if (nextScale === 1) setQvLightboxPan({ x: 50, y: 50 });
                                }}
                                className="h-9 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-colors"
                                title="Zoom In / Out"
                              >
                                <Search className="w-3.5 h-3.5 text-amber-400" />
                                <span className="font-mono">
                                  {qvLightboxScale === 1 ? 'Zoom +' : `${qvLightboxScale}x`}
                                </span>
                              </button>

                              {qvLightboxScale > 1 && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setQvLightboxScale(1);
                                    setQvLightboxPan({ x: 50, y: 50 });
                                  }}
                                  className="h-9 px-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-amber-300 border border-white/15 text-xs font-mono font-bold cursor-pointer transition-colors"
                                  title="Reset Zoom (1x)"
                                >
                                  1:1
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => setQvLightboxOpen(false)}
                                className="w-9 h-9 rounded-xl bg-white/10 hover:bg-rose-600 text-white border border-white/15 flex items-center justify-center cursor-pointer transition-colors"
                                aria-label="Close lightbox"
                                title="বন্ধ করুন (Close)"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* PhotoSwipe Center Full-Bleed Dark Stage (Click to Toggle 1x <-> 2x Zoom + Cursor Pan + Touch Swipe) */}
                          <div
                            onClick={e => e.stopPropagation()}
                            onTouchStart={handleQvTouchStart}
                            onTouchMove={handleQvTouchMove}
                            onTouchEnd={handleQvTouchEnd}
                            onMouseMove={e => {
                              if (qvLightboxScale <= 1) return;
                              const rect = e.currentTarget.getBoundingClientRect();
                              if (!rect.width || !rect.height) return;
                              const x = Math.max(
                                0,
                                Math.min(100, ((e.clientX - rect.left) / rect.width) * 100)
                              );
                              const y = Math.max(
                                0,
                                Math.min(100, ((e.clientY - rect.top) / rect.height) * 100)
                              );
                              setQvLightboxPan({ x, y });
                            }}
                            className="relative flex-1 w-full overflow-hidden flex items-center justify-center px-2 sm:px-12"
                          >
                            <div
                              onClick={e => {
                                const rect = e.currentTarget.getBoundingClientRect();
                                if (qvLightboxScale <= 1) {
                                  if (rect.width && rect.height) {
                                    const x = Math.max(
                                      0,
                                      Math.min(100, ((e.clientX - rect.left) / rect.width) * 100)
                                    );
                                    const y = Math.max(
                                      0,
                                      Math.min(100, ((e.clientY - rect.top) / rect.height) * 100)
                                    );
                                    setQvLightboxPan({ x, y });
                                  }
                                  setQvLightboxScale(2);
                                } else {
                                  setQvLightboxScale(1);
                                  setQvLightboxPan({ x: 50, y: 50 });
                                }
                              }}
                              className={`relative w-full max-w-[82vw] sm:max-w-[540px] max-h-[70vh] aspect-square rounded-2xl overflow-hidden bg-white shadow-2xl transition-transform duration-200 ease-out ${
                                qvLightboxScale > 1 ? 'cursor-zoom-out' : 'cursor-zoom-in'
                              }`}
                              style={{
                                transform: `scale(${qvLightboxScale})`,
                                transformOrigin: `${qvLightboxPan.x}% ${qvLightboxPan.y}%`
                              }}
                            >
                              <ProductThumbnail
                                eager
                                product={{
                                  ...quickViewProduct,
                                  image: currentGallerySlide?.imageUrl || quickViewProduct.image
                                }}
                                imgClassName="p-0"
                              />
                            </div>

                            {galleryItems.length > 1 && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setQvLightboxScale(1);
                                    setQvLightboxPan({ x: 50, y: 50 });
                                    handleQvPrevSlide();
                                  }}
                                  className="fixed left-3 sm:left-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/15 hover:bg-white/30 text-white border border-white/20 flex items-center justify-center shadow-lg cursor-pointer z-20 transition-all"
                                  aria-label="Previous image"
                                >
                                  <ChevronLeft className="w-5 h-5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setQvLightboxScale(1);
                                    setQvLightboxPan({ x: 50, y: 50 });
                                    handleQvNextSlide();
                                  }}
                                  className="fixed right-3 sm:right-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/15 hover:bg-white/30 text-white border border-white/20 flex items-center justify-center shadow-lg cursor-pointer z-20 transition-all"
                                  aria-label="Next image"
                                >
                                  <ChevronRight className="w-5 h-5" />
                                </button>
                              </>
                            )}
                          </div>

                          {/* PhotoSwipe Bottom Filmstrip & Caption Bar */}
                          <div
                            onClick={e => e.stopPropagation()}
                            className="w-full px-3 sm:px-6 py-3 bg-gradient-to-t from-black/90 via-black/70 to-transparent flex flex-col items-center gap-2.5 z-20"
                          >
                            {galleryItems.length > 1 && (
                              <div className="flex items-center justify-center gap-2 overflow-x-auto max-w-full py-1">
                                {galleryItems.map((item, idx) => {
                                  const isActive = idx === safeGalleryIdx;
                                  return (
                                    <button
                                      key={`lb_thumb_${item.id}`}
                                      type="button"
                                      onClick={() => {
                                        setQvLightboxScale(1);
                                        setQvLightboxPan({ x: 50, y: 50 });
                                        setActiveGalleryIndex(idx);
                                      }}
                                      className={`w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden border-2 bg-white shrink-0 transition-all cursor-pointer ${
                                        isActive
                                          ? 'border-amber-400 scale-105 shadow-md'
                                          : 'border-white/20 opacity-60 hover:opacity-100'
                                      }`}
                                    >
                                      <ProductThumbnail
                                        eager
                                        product={{
                                          ...quickViewProduct,
                                          image: item.imageUrl || quickViewProduct.image
                                        }}
                                        imgClassName="p-0.5"
                                      />
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                            <p className="text-[11px] sm:text-xs text-white/75 text-center font-medium">
                              🔍 ছবির ওপর ক্লিক করে জুম ইন / আউট করুন · বর্তমান ভিউ:{' '}
                              <strong className="text-amber-300 font-mono">{qvLightboxScale}x</strong>
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Right Product Info & Order Actions Column */}
                    <div className="md:col-span-6 space-y-4">
                      <div className="space-y-1.5">
                        {(Boolean(currentBusiness.showProductSkuOnStorefront) || isAuthenticated) && (
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            {Boolean(currentBusiness.showProductSkuOnStorefront) ? (
                              <span className="text-xs font-mono text-slate-500">
                                SKU: {quickViewProduct.sku}
                              </span>
                            ) : (
                              <span />
                            )}
                            {isAuthenticated && (
                              <div className="flex flex-wrap items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextSkuOn = !Boolean(currentBusiness.showProductSkuOnStorefront);
                                    updateBusiness({ showProductSkuOnStorefront: nextSkuOn });
                                    showToast(
                                      nextSkuOn
                                        ? 'প্রোডাক্ট পেজে SKU কোড প্রদর্শন চালু (ON) করা হয়েছে!'
                                        : 'প্রোডাক্ট পেজে SKU কোড হাইড (OFF) করা হয়েছে!',
                                      nextSkuOn ? 'success' : 'info'
                                    );
                                  }}
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                                    Boolean(currentBusiness.showProductSkuOnStorefront)
                                      ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                                      : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                                  }`}
                                  title="প্রোডাক্ট পেজে SKU কোড প্রদর্শন ON / OFF করুন"
                                >
                                  <span>SKU: {Boolean(currentBusiness.showProductSkuOnStorefront) ? 'ON' : 'OFF (Hidden)'}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextZoomOn = !isGlobalImageZoomEnabled;
                                    updateBusiness({ productImageZoomEnabled: nextZoomOn });
                                    showToast(
                                      nextZoomOn
                                        ? 'প্রোডাক্ট ছবি জুম ও উকমার্স লাইটবক্স চালু (ON) করা হয়েছে!'
                                        : 'প্রোডাক্ট ছবি জুম বন্ধ (OFF) করা হয়েছে!',
                                      nextZoomOn ? 'success' : 'info'
                                    );
                                  }}
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                                    isGlobalImageZoomEnabled
                                      ? 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100'
                                      : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                                  }`}
                                  title="গ্লোবাল প্রোডাক্ট ছবি জুম ও উকমার্স লাইটবক্স ON / OFF করুন"
                                >
                                  <Search className="w-3 h-3" />
                                  <span>ছবি জুম: {isGlobalImageZoomEnabled ? 'ON' : 'OFF'}</span>
                                </button>

                                {isGlobalImageZoomEnabled && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const styles: Array<
                                        'woocommerce_lightbox' | 'hover_and_lightbox' | 'hover_only'
                                      > = ['woocommerce_lightbox', 'hover_and_lightbox', 'hover_only'];
                                      const nextStyle =
                                        styles[(styles.indexOf(imageZoomStyle) + 1) % styles.length];
                                      updateBusiness({ productImageZoomStyle: nextStyle });
                                      showToast(
                                        `ছবি জুম স্টাইল: "${zoomStyleLabels[nextStyle]}" সেট করা হয়েছে!`,
                                        'success'
                                      );
                                    }}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-violet-50 hover:bg-violet-100 text-violet-900 border border-violet-200 text-[11px] font-bold transition-colors cursor-pointer"
                                    title="ছবি জুমের স্টাইল পরিবর্তন করুন (উকমার্স লাইটবক্স / হোভার+লাইটবক্স / শুধু হোভার)"
                                  >
                                    <span>স্টাইল: {zoomStyleLabels[imageZoomStyle]}</span>
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={async () => {
                                    const nextOn = !qvShowLiveViewers;
                                    await updateProduct(quickViewProduct.id, {
                                      landingLiveViewersEnabled: nextOn
                                    });
                                    setQuickViewProduct(prev =>
                                      prev ? { ...prev, landingLiveViewersEnabled: nextOn } : null
                                    );
                                    showToast(
                                      nextOn
                                        ? 'লাইভ ভিউয়ার কাউন্টার (12-48) চালু (ON) করা হয়েছে'
                                        : 'লাইভ ভিউয়ার কাউন্টার বন্ধ (OFF) করা হয়েছে',
                                      'info'
                                    );
                                  }}
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                                    qvShowLiveViewers
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                                      : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                                  }`}
                                  title="এই প্রোডাক্ট পেজে 'People currently viewing this product' কাউন্টার ON / OFF করুন"
                                >
                                  <Eye className="w-3 h-3" />
                                  <span>লাইভ ভিউয়ার: {qvShowLiveViewers ? 'ON' : 'OFF'}</span>
                                </button>

                                {/* Admin Live Controls for Main Store Sticky Floating Button (Mobile Only / Desktop+Mobile / Completely OFF) */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextOn = !isStorefrontFloatingBtnOn;
                                    updateBusiness({ storefrontFloatingBtnEnabled: nextOn });
                                    showToast(
                                      nextOn
                                        ? 'প্রোডাক্ট পেজের ফ্লোটিং অর্ডার বাটন চালু (ON) করা হয়েছে!'
                                        : 'প্রোডাক্ট পেজের ফ্লোটিং অর্ডার বাটন একদম বন্ধ (OFF) করা হয়েছে!',
                                      nextOn ? 'success' : 'info'
                                    );
                                  }}
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                                    isStorefrontFloatingBtnOn
                                      ? 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100'
                                      : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                                  }`}
                                  title="প্রোডাক্ট পেজের নিচের স্টিকি ফ্লোটিং 'এখনই অর্ডার করুন' বাটন একদম চালু বা বন্ধ (ON / OFF) করুন"
                                >
                                  <ShoppingBag className="w-3 h-3" />
                                  <span>ফ্লোটিং বাটন: {isStorefrontFloatingBtnOn ? 'ON' : 'একদম OFF'}</span>
                                </button>

                                {isStorefrontFloatingBtnOn && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const nextHideDesktop = !isStorefrontFloatingHideOnDesktop;
                                        updateBusiness({
                                          storefrontFloatingBtnHideOnDesktop: nextHideDesktop
                                        });
                                        showToast(
                                          nextHideDesktop
                                            ? 'প্রোডাক্ট পেজের ফ্লোটিং বাটন ডেক্সটপ থেকে হাইড করা হয়েছে (শুধু মোবাইলে দেখাবে)!'
                                            : 'প্রোডাক্ট পেজের ফ্লোটিং বাটন ডেক্সটপ ও মোবাইল উভয় ভিউতে চালু করা হয়েছে!',
                                          'success'
                                        );
                                      }}
                                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-colors cursor-pointer ${
                                        isStorefrontFloatingHideOnDesktop
                                          ? 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100'
                                          : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                                      }`}
                                      title="ডেক্সটপ ভিউ থেকে প্রোডাক্ট পেজের ফ্লোটিং বাটন হাইড বা শো করুন"
                                    >
                                      <span>
                                        {isStorefrontFloatingHideOnDesktop
                                          ? '📱 শুধু মোবাইলে (ডেক্সটপে হাইড)'
                                          : '💻 ডেক্সটপ + মোবাইল: ON'}
                                      </span>
                                    </button>

                                    <button
                                      type="button"
                                      onClick={() => {
                                        const nextPriceOn = !isStorefrontFloatingPriceOn;
                                        updateBusiness({
                                          storefrontFloatingBtnPriceEnabled: nextPriceOn
                                        });
                                        showToast(
                                          nextPriceOn
                                            ? 'ফ্লোটিং বাটনে দাম দেখানো চালু (ON) করা হয়েছে!'
                                            : 'ফ্লোটিং বাটনে দাম দেখানো বন্ধ (OFF) করা হয়েছে!',
                                          nextPriceOn ? 'success' : 'info'
                                        );
                                      }}
                                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                                        isStorefrontFloatingPriceOn
                                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                                          : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                                      }`}
                                      title="মেইন স্টোরের ফ্লোটিং বাটনে মোট দাম দেখানো ON / OFF করুন"
                                    >
                                      <span>ফ্লোটিং দাম: {isStorefrontFloatingPriceOn ? 'ON' : 'OFF'}</span>
                                    </button>

                                    <button
                                      type="button"
                                      onClick={() => {
                                        const curIdx = storefrontFloatingAnimOptions.findIndex(
                                          o => o.id === storefrontFloatingAnim
                                        );
                                        const nextOpt =
                                          storefrontFloatingAnimOptions[
                                            (curIdx + 1) % storefrontFloatingAnimOptions.length
                                          ];
                                        updateBusiness({
                                          storefrontFloatingBtnAnimation: nextOpt.id
                                        });
                                        showToast(
                                          `মেইন স্টোর ফ্লোটিং বাটন অ্যানিমেশন: "${nextOpt.label}" সেট করা হয়েছে!`,
                                          'success'
                                        );
                                      }}
                                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-extrabold transition-colors cursor-pointer"
                                      title="মেইন স্টোরের ফ্লোটিং বাটনের অ্যানিমেশন স্টাইল পরিবর্তন বা বন্ধ (OFF) করুন"
                                    >
                                      <Sparkles className="w-3 h-3 text-amber-600" />
                                      <span>অ্যানিমেশন: {currentSfFloatingAnimObj.shortLabel}</span>
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                        <h1 className="text-lg sm:text-2xl font-extrabold text-slate-900 leading-snug">
                          {quickViewProduct.nameBn}
                        </h1>
                        <p className="text-xs sm:text-sm text-slate-500">{quickViewProduct.nameEn}</p>
                      </div>

                      {/* Small, Non-Intrusive 'People currently viewing this product' Counter (12-48 Randomized, ON/OFF, Isolated Memo Component) */}
                      {qvShowLiveViewers && (
                        <StorefrontLiveViewerBadge productId={quickViewProduct.id} />
                      )}

                      {/* Price Display */}
                      <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/80 flex items-baseline gap-3">
                        <span className="font-mono font-extrabold text-2xl sm:text-3xl text-emerald-800">
                          ৳{qvRetailPrice}
                        </span>
                        {qvMrpPrice > qvRetailPrice && (
                          <span className="font-mono text-sm text-slate-400 line-through">
                            ৳{qvMrpPrice}
                          </span>
                        )}
                        <span className="text-xs font-bold text-emerald-700 ml-auto">
                          সাইজ: {qvActiveVariant ? qvActiveVariant.label : quickViewProduct.unit}
                        </span>
                      </div>

                      {/* Global Synchronized Offer Countdown Timer on Storefront Product Page (1-Click Global ON/OFF + Per-Product Show/Hide + Centralized Realistic Time) */}
                      {isAuthenticated && (
                        <div className="p-2.5 rounded-xl bg-rose-50/70 border border-rose-200/80 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-1.5">
                            {/* 1-Click Global ON/OFF across ALL products */}
                            <button
                              type="button"
                              onClick={() => {
                                const nextGlobalOn = !isGlobalCountdownEnabled;
                                updateBusiness({ storefrontCountdownEnabled: nextGlobalOn });
                                showToast(
                                  nextGlobalOn
                                    ? '১-ক্লিকে সব প্রোডাক্টে গ্লোবাল অফার কাউন্টডাউন চালু (ON) করা হয়েছে!'
                                    : '১-ক্লিকে সব প্রোডাক্টে গ্লোবাল অফার কাউন্টডাউন বন্ধ (OFF) করা হয়েছে!',
                                  nextGlobalOn ? 'success' : 'info'
                                );
                              }}
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-colors cursor-pointer ${
                                isGlobalCountdownEnabled
                                  ? 'bg-rose-600 text-white border-rose-700 hover:bg-rose-700 shadow-2xs'
                                  : 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                              }`}
                              title="১-ক্লিকে ওয়েবসাইটের সব প্রোডাক্টে একসাথে অফার কাউন্টডাউন ON / OFF করুন"
                            >
                              <Clock className="w-3 h-3" />
                              <span>
                                সব প্রোডাক্টে কাউন্টডাউন: {isGlobalCountdownEnabled ? 'ON' : 'OFF'}
                              </span>
                            </button>

                            {/* Per-Product Show/Hide Toggle */}
                            <button
                              type="button"
                              onClick={async () => {
                                const nextProdOn = !isProductCountdownEnabled;
                                await updateProduct(quickViewProduct.id, {
                                  landingCountdownEnabled: nextProdOn
                                });
                                setQuickViewProduct(prev =>
                                  prev ? { ...prev, landingCountdownEnabled: nextProdOn } : null
                                );
                                showToast(
                                  nextProdOn
                                    ? 'এই প্রোডাক্টে কাউন্টডাউন দেখানো চালু (ON) করা হয়েছে!'
                                    : 'শুধু এই প্রোডাক্টে কাউন্টডাউন হাইড (OFF) করা হয়েছে!',
                                  nextProdOn ? 'success' : 'info'
                                );
                              }}
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                                isProductCountdownEnabled
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                                  : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'
                              }`}
                              title="শুধু এই প্রোডাক্ট পেজে কাউন্টডাউন দেখানো বা লুকানো নিয়ন্ত্রণ করুন (সময় সব প্রোডাক্টে একই থাকবে)"
                            >
                              <span>
                                শুধু এই প্রোডাক্টে: {isProductCountdownEnabled ? 'Show (ON)' : 'Hide (OFF)'}
                              </span>
                            </button>
                          </div>

                          {/* 1-Click Centralized Realistic Global Time Presets & Randomizer */}
                          {isGlobalCountdownEnabled && (
                            <div className="flex flex-wrap items-center gap-1">
                              {[
                                { h: 8, m: 30, s: 34, label: '৮ঘ:৩০মি:৩৪সে' },
                                { h: 5, m: 42, s: 18, label: '৫ঘ:৪২মি:১৮সে' },
                                { h: 2, m: 35, s: 47, label: '২ঘ:৩৫মি:৪৭সে' },
                                { h: 11, m: 28, s: 19, label: '১১ঘ:২৮মি:১৯সে' }
                              ].map(preset => {
                                const isActivePreset =
                                  effectiveInitialHours === preset.h &&
                                  effectiveInitialMinutes === preset.m &&
                                  effectiveInitialSeconds === preset.s;
                                return (
                                  <button
                                    key={preset.label}
                                    type="button"
                                    onClick={() => {
                                      updateBusiness({
                                        storefrontCountdownHours: preset.h,
                                        storefrontCountdownMinutes: preset.m,
                                        storefrontCountdownSeconds: preset.s,
                                        storefrontCountdownResetSeed: Date.now()
                                      });
                                      showToast(
                                        `গ্লোবাল কাউন্টডাউন সব প্রোডাক্টের জন্য ${preset.label} থেকে শুরু করা হয়েছে!`,
                                        'success'
                                      );
                                    }}
                                    className={`px-2 py-1 rounded-lg text-[10px] font-extrabold border transition-colors cursor-pointer ${
                                      isActivePreset
                                        ? 'bg-amber-500 text-white border-amber-600'
                                        : 'bg-white text-slate-700 border-rose-200 hover:bg-rose-100'
                                    }`}
                                    title="সব প্রোডাক্টের জন্য এক জায়গা থেকে রিয়েলিস্টিক কাউন্টডাউন টাইম সেট করুন"
                                  >
                                    {preset.label}
                                  </button>
                                );
                              })}

                              <button
                                type="button"
                                onClick={() => {
                                  const randH = [3, 5, 7, 8, 10][Math.floor(Math.random() * 5)];
                                  const randM = Math.floor(18 + Math.random() * 31); // 18..48
                                  const randS = Math.floor(12 + Math.random() * 43); // 12..54
                                  updateBusiness({
                                    storefrontCountdownHours: randH,
                                    storefrontCountdownMinutes: randM,
                                    storefrontCountdownSeconds: randS,
                                    storefrontCountdownResetSeed: Date.now()
                                  });
                                  showToast(
                                    `নতুন রিয়েলিস্টিক গ্লোবাল টাইম (${toBanglaCountdownDigits(randH)} ঘণ্টা ${toBanglaCountdownDigits(randM)} মিনিট ${toBanglaCountdownDigits(randS)} সেকেন্ড) সব প্রোডাক্টে সেট হয়েছে!`,
                                    'success'
                                  );
                                }}
                                className="px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[10px] font-extrabold transition-colors cursor-pointer"
                                title="১-ক্লিকে র‍্যান্ডম রিয়েলিস্টিক টাইম জেনারেট ও রিস্টার্ট করুন"
                              >
                                🎲 র‍্যান্ডম টাইম
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {qvShowCountdown && (
                        <div
                          onClick={() => {
                            if (qvStock > 0) {
                              handleDirectOrderNow(quickViewProduct, quickViewQty, qvActiveVariant);
                            }
                          }}
                          role="button"
                          tabIndex={0}
                          onKeyDown={e => {
                            if ((e.key === 'Enter' || e.key === ' ') && qvStock > 0) {
                              handleDirectOrderNow(quickViewProduct, quickViewQty, qvActiveVariant);
                            }
                          }}
                          className="p-3.5 rounded-xl bg-gradient-to-r from-rose-50 via-amber-50/75 to-rose-50 border border-rose-200/90 animate-countdown-glow cursor-pointer transition-all hover:border-rose-300"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5">
                              <span className="relative flex h-9 w-9 rounded-xl bg-gradient-to-br from-[#dc2626] to-[#991b1b] text-white items-center justify-center shrink-0 shadow-xs">
                                <Flame className="w-5 h-5 text-amber-200 animate-pulse" />
                              </span>
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="relative flex h-2 w-2">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75" />
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600" />
                                  </span>
                                  <p className="text-xs sm:text-sm font-extrabold text-rose-950 leading-tight">
                                    {qvCountdownTitle}
                                  </p>
                                </div>
                                <p className="text-[11px] font-bold text-rose-700 mt-0.5">
                                  সময় শেষ হওয়ার আগেই ডিসকাউন্ট মূল্যে অর্ডার করুন
                                </p>
                              </div>
                            </div>

                            {/* Live Ticking Hours : Minutes : Seconds Digital Blocks (Isolated Memo Component for 0 Parent Re-renders) */}
                            <StorefrontCountdownDigits
                              businessId={currentBusiness.id}
                              effectiveInitialHours={effectiveInitialHours}
                              effectiveInitialMinutes={effectiveInitialMinutes}
                              effectiveInitialSeconds={effectiveInitialSeconds}
                              globalInitialDurationSec={globalInitialDurationSec}
                              globalResetSeed={globalResetSeed}
                            />
                          </div>
                        </div>
                      )}

                      {/* Variation Selector Pills (1-2 Years .. 11-12 Years / M / L / XL) + Size Chart Popup Trigger */}
                      {quickViewProduct.variants && quickViewProduct.variants.length > 0 && (
                        <div className="space-y-2.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex flex-wrap items-center gap-2">
                              <label className="text-xs sm:text-sm font-extrabold text-slate-800 block">
                                {hasDualColorAndSizeVariants(quickViewProduct)
                                  ? 'পছন্দের কালার ও সাইজ নির্বাচন করুন:'
                                  : quickViewProduct.variants.every(v => v.type === 'color')
                                  ? 'পছন্দের কালার নির্বাচন করুন:'
                                  : 'পছন্দের সাইজ / বয়স নির্বাচন করুন:'}
                              </label>
                              {isVariantSelectionRequired &&
                                !getExplicitSelectedVariant(quickViewProduct) && (
                                  <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-300 text-[11px] font-bold">
                                    {hasDualColorAndSizeVariants(quickViewProduct)
                                      ? 'কালার এবং সাইজ উভয়ই সিলেক্ট করুন'
                                      : quickViewProduct.variants.every(v => v.type === 'color')
                                      ? 'যেকোনো ১টি কালার সিলেক্ট করুন'
                                      : 'যেকোনো ১টি সাইজ সিলেক্ট করুন'}
                                  </span>
                                )}
                            </div>
                            <div className="flex flex-wrap items-center gap-1.5">
                              {isAuthenticated && (
                                <>
                                  {/* 1-Click Product Page Variation Price ON/OFF */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const nextShowPrice = !showProductPageVariantPrice;
                                      updateBusiness({ productPageVariantShowPrice: nextShowPrice });
                                      showToast(
                                        nextShowPrice
                                          ? 'প্রোডাক্ট পেজে ভ্যারিয়েশনের সাথে দাম (Price) দেখানো চালু (ON) করা হয়েছে!'
                                          : 'প্রোডাক্ট পেজে ভ্যারিয়েশনের দাম বন্ধ (OFF) করা হয়েছে (এখন শুধু সাইজ দেখাবে)!',
                                        nextShowPrice ? 'success' : 'info'
                                      );
                                    }}
                                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-colors ${
                                      showProductPageVariantPrice
                                        ? 'bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700 shadow-2xs'
                                        : 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                                    }`}
                                    title="প্রোডাক্ট পেজে সাইজ/ভ্যারিয়েশন বাটনের ভেতরে দাম (৳) দেখানো ON / OFF করুন"
                                  >
                                    <span>
                                      ভ্যারিয়েশন প্রাইস: {showProductPageVariantPrice ? 'ON' : 'OFF'}
                                    </span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      const nextState = !isVariantSelectionRequired;
                                      updateBusiness({ requireVariantSelectionBeforeOrder: nextState });
                                      showToast(
                                        nextState
                                          ? 'সাইজ সিলেকশন পপআপ ও ওয়ার্নিং চালু (ON) করা হয়েছে!'
                                          : 'সাইজ সিলেকশন পপআপ বন্ধ (OFF) করা হয়েছে (ডিফল্ট ১ম সাইজ সিলেক্ট থাকবে)!',
                                        nextState ? 'success' : 'info'
                                      );
                                    }}
                                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-colors ${
                                      isVariantSelectionRequired
                                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                                        : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                                    }`}
                                    title="অ্যাডমিন কন্ট্রোল: সাইজ সিলেক্ট না করে অর্ডার করলে পপআপ দেখানো ON/OFF করুন"
                                  >
                                    <span>সাইজ পপআপ: {isVariantSelectionRequired ? 'ON' : 'OFF'}</span>
                                  </button>
                                </>
                              )}
                              {quickViewProduct.landingSizeChartEnabled !== false && (
                                <button
                                  type="button"
                                  onClick={() => setIsQvSizeChartModalOpen(true)}
                                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-extrabold cursor-pointer transition-colors shadow-2xs"
                                >
                                  <Ruler className="w-3.5 h-3.5 text-indigo-700" />
                                  <span>📏 সাইজ চার্ট দেখুন</span>
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Admin Live Design Switcher Bar (4 Designs including exact current default) */}
                          {isAuthenticated && (
                            <div className="p-2 rounded-xl bg-slate-50 border border-slate-200/90 flex flex-wrap items-center justify-between gap-1.5">
                              <span className="text-[11px] font-extrabold text-slate-700">
                                ভ্যারিয়েশন ডিজাইন স্টাইল:
                              </span>
                              <div className="flex flex-wrap items-center gap-1">
                                {productPageVariantStyleOptions.map(opt => {
                                  const isActiveStyle = productPageVariantStyle === opt.id;
                                  return (
                                    <button
                                      key={opt.id}
                                      type="button"
                                      onClick={() => {
                                        updateBusiness({ productPageVariantStyle: opt.id });
                                        showToast(
                                          `প্রোডাক্ট পেজ ভ্যারিয়েশন স্টাইল: "${opt.label}" সেট করা হয়েছে!`,
                                          'success'
                                        );
                                      }}
                                      className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                                        isActiveStyle
                                          ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                          : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-500'
                                      }`}
                                      title={opt.label}
                                    >
                                      {opt.shortLabel}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* Admin 1-Click Variation Out-of-Stock Control Bar */}
                          {isAuthenticated && (
                            <div className="p-2.5 rounded-xl bg-rose-50/70 border border-rose-200/90 space-y-1.5">
                              <div className="flex flex-wrap items-center justify-between gap-1.5">
                                <span className="text-[11px] font-extrabold text-rose-950">
                                  📦 অ্যাডমিন স্টক কন্ট্রোল (যেকোনো সাইজ বা পুরো প্রোডাক্ট ১-ক্লিকে স্টক আউট করুন):
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextOut = !quickViewProduct.isOutOfStock;
                                    updateProduct(quickViewProduct.id, { isOutOfStock: nextOut });
                                    setQuickViewProduct(prev =>
                                      prev ? { ...prev, isOutOfStock: nextOut } : null
                                    );
                                    showToast(
                                      nextOut
                                        ? `"${quickViewProduct.nameBn}" পুরো প্রোডাক্টটি স্টক আউট (Out of Stock) করা হয়েছে!`
                                        : `"${quickViewProduct.nameBn}" পুনরায় ইন-স্টক (In Stock) করা হয়েছে!`,
                                      nextOut ? 'info' : 'success'
                                    );
                                  }}
                                  className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                                    quickViewProduct.isOutOfStock
                                      ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                      : 'bg-white text-emerald-800 border-emerald-300 hover:bg-emerald-50'
                                  }`}
                                >
                                  {quickViewProduct.isOutOfStock
                                    ? '🚫 পুরো প্রোডাক্ট স্টক শেষ (চালু করুন)'
                                    : '✓ পুরো প্রোডাক্ট স্টকে আছে (আউট করুন)'}
                                </button>
                              </div>
                              <div className="flex flex-wrap items-center gap-1.5">
                                {quickViewProduct.variants.map((v, vIdx) => {
                                  const isVarOut = Boolean(v.outOfStock);
                                  return (
                                    <button
                                      key={v.id}
                                      type="button"
                                      onClick={() => {
                                        const nextVariants = (quickViewProduct.variants || []).map(
                                          (item, idx) =>
                                            idx === vIdx
                                              ? { ...item, outOfStock: !item.outOfStock }
                                              : item
                                        );
                                        updateProduct(quickViewProduct.id, { variants: nextVariants });
                                        setQuickViewProduct(prev =>
                                          prev ? { ...prev, variants: nextVariants } : null
                                        );
                                        if (
                                          !isVarOut &&
                                          selectedVariantByProduct[quickViewProduct.id] === v.id
                                        ) {
                                          const firstInStock = nextVariants.find(
                                            item => !item.outOfStock
                                          );
                                          setSelectedVariantByProduct(prev => ({
                                            ...prev,
                                            [quickViewProduct.id]: firstInStock?.id || ''
                                          }));
                                        }
                                        showToast(
                                          !isVarOut
                                            ? `"${v.label}" সাইজ/ভ্যারিয়েশনটি স্টক আউট করা হয়েছে`
                                            : `"${v.label}" সাইজ/ভ্যারিয়েশনটি পুনরায় স্টকে চালু করা হয়েছে`,
                                          !isVarOut ? 'info' : 'success'
                                        );
                                      }}
                                      className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                                        isVarOut
                                          ? 'bg-rose-600 text-white border-rose-600'
                                          : 'bg-white text-slate-700 border-slate-300 hover:border-rose-400'
                                      }`}
                                    >
                                      {v.label}: {isVarOut ? '🚫 স্টক শেষ' : '✓ চালু'}
                                    </button>
                                  );
                                })}
                              </div>

                              {/* 1-Click Stock Out Image Overlay Style Switcher inside Admin Stock Control Box */}
                              <div className="pt-1.5 border-t border-rose-200/80 flex flex-wrap items-center justify-between gap-1.5">
                                <span className="text-[10px] font-extrabold text-rose-900">
                                  🖼️ ছবির ওপর "স্টক শেষ" ভিউ স্টাইল:
                                </span>
                                <div className="flex flex-wrap items-center gap-1">
                                  {stockOutStyleOptions.map(opt => {
                                    const isSel = stockOutBadgeStyle === opt.id;
                                    return (
                                      <button
                                        key={opt.id}
                                        type="button"
                                        onClick={() => {
                                          updateBusiness({ stockOutBadgeStyle: opt.id });
                                          showToast(
                                            `স্টক শেষ ভিউ স্টাইল: "${opt.label}" সেট করা হয়েছে!`,
                                            'success'
                                          );
                                        }}
                                        className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                                          isSel
                                            ? 'bg-slate-900 text-amber-300 border-slate-900 shadow-2xs'
                                            : 'bg-white text-slate-700 border-rose-200 hover:bg-rose-100'
                                        }`}
                                        title={opt.label}
                                      >
                                        {opt.shortLabel}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Dual Variation Mode: Separate Color Selector Box when product has BOTH Color and Size */}
                          {hasDualColorAndSizeVariants(quickViewProduct) && (
                            <div className="p-3 rounded-xl bg-rose-50/45 border border-rose-200/80 space-y-2">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-xs font-extrabold text-rose-950 flex items-center gap-1.5">
                                  <span>🎨 ১. পছন্দের কালার (Color) নির্বাচন করুন:</span>
                                </span>
                                {selectedColorByProduct[quickViewProduct.id] ? (
                                  <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-extrabold">
                                    ✓ কালার:{' '}
                                    {
                                      getProductColorVariants(quickViewProduct).find(
                                        c => c.id === selectedColorByProduct[quickViewProduct.id]
                                      )?.label
                                    }
                                  </span>
                                ) : (
                                  <span className="text-[11px] font-bold text-rose-700">
                                    যেকোনো ১টি কালার ট্যাপ করুন
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {getProductColorVariants(quickViewProduct).map(cVar => {
                                  const isColorOut = Boolean(cVar.outOfStock);
                                  const isColorSelected =
                                    !isColorOut &&
                                    (isVariantSelectionRequired
                                      ? selectedColorByProduct[quickViewProduct.id] === cVar.id
                                      : (selectedColorByProduct[quickViewProduct.id] ||
                                          getProductColorVariants(quickViewProduct).find(
                                            x => !x.outOfStock
                                          )?.id) === cVar.id);
                                  return (
                                    <button
                                      key={cVar.id}
                                      type="button"
                                      onClick={() => {
                                        if (isColorOut) {
                                          showToast(
                                            `দুঃখিত, "${cVar.label}" কালারটি বর্তমানে স্টকে নেই (স্টক শেষ)!`,
                                            'error'
                                          );
                                          return;
                                        }
                                        setSelectedColorByProduct(prev => ({
                                          ...prev,
                                          [quickViewProduct.id]: cVar.id
                                        }));
                                        if (cVar.imageUrl) {
                                          const matchedIdx = galleryItems.findIndex(
                                            g => g.imageUrl === cVar.imageUrl
                                          );
                                          if (matchedIdx >= 0) {
                                            setActiveGalleryIndex(matchedIdx);
                                          }
                                        }
                                      }}
                                      className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer border-2 inline-flex items-center gap-1.5 ${
                                        isColorOut
                                          ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-75'
                                          : isColorSelected
                                          ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                                          : 'bg-white text-slate-800 border-rose-200 hover:border-rose-500'
                                      }`}
                                    >
                                      {cVar.imageUrl ? (
                                        <img
                                          src={cVar.imageUrl}
                                          alt={cVar.label}
                                          className="w-5 h-5 rounded-md object-cover border border-white/60 shrink-0"
                                        />
                                      ) : (
                                        isColorSelected &&
                                        !isColorOut && (
                                          <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                                        )
                                      )}
                                      <span>{cVar.label}</span>
                                      {isColorOut && (
                                        <span className="text-[10px] font-extrabold text-rose-600 no-underline">
                                          (স্টক শেষ)
                                        </span>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {hasDualColorAndSizeVariants(quickViewProduct) && (
                            <div className="flex items-center justify-between pt-0.5">
                              <span className="text-xs font-extrabold text-emerald-950">
                                📏 ২. পছন্দের সাইজ / বয়স (Size) নির্বাচন করুন:
                              </span>
                            </div>
                          )}

                          {/* Variation Buttons Rendered by Selected Design Style (1, 2, 3, or 4) */}
                          <div className="flex flex-wrap gap-2">
                            {(hasDualColorAndSizeVariants(quickViewProduct)
                              ? getProductSizeVariants(quickViewProduct)
                              : quickViewProduct.variants
                            ).map(v => {
                              const isVarOut = Boolean(v.outOfStock);
                              const isDualQv = hasDualColorAndSizeVariants(quickViewProduct);
                              const isSelected =
                                !isVarOut &&
                                (isVariantSelectionRequired
                                  ? selectedVariantByProduct[quickViewProduct.id] === v.id
                                  : isDualQv
                                  ? (selectedVariantByProduct[quickViewProduct.id] ||
                                      getProductSizeVariants(quickViewProduct).find(
                                        x => !x.outOfStock
                                      )?.id) === v.id
                                  : qvActiveVariant?.id === v.id);

                              const handleVariantClick = () => {
                                if (isVarOut) {
                                  showToast(
                                    `দুঃখিত, "${v.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`,
                                    'error'
                                  );
                                  return;
                                }
                                setSelectedVariantByProduct(prev => ({
                                  ...prev,
                                  [quickViewProduct.id]: v.id
                                }));
                                if (v.imageUrl) {
                                  const matchedIdx = galleryItems.findIndex(
                                    g => g.imageUrl === v.imageUrl
                                  );
                                  if (matchedIdx >= 0) {
                                    setActiveGalleryIndex(matchedIdx);
                                  }
                                }
                              };

                              // Design 2: 2-Line Stacked Box Card (Size on top, Price below + Corner Check)
                              if (productPageVariantStyle === 'stacked_card') {
                                return (
                                  <button
                                    key={v.id}
                                    type="button"
                                    onClick={handleVariantClick}
                                    className={`relative min-w-[92px] sm:min-w-[106px] px-3 py-2 rounded-xl text-center transition-all cursor-pointer border-2 ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-emerald-50/90 text-emerald-950 border-emerald-700 shadow-xs'
                                        : 'bg-white text-slate-800 border-slate-200 hover:border-emerald-500'
                                    }`}
                                  >
                                    {isSelected && !isVarOut && (
                                      <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-emerald-700 text-white flex items-center justify-center shadow-2xs">
                                        <CheckCircle2 className="w-3 h-3" />
                                      </span>
                                    )}
                                    <span
                                      className={`block text-xs sm:text-sm font-extrabold leading-tight ${
                                        isVarOut ? 'line-through' : ''
                                      }`}
                                    >
                                      {v.label}
                                    </span>
                                    {isVarOut ? (
                                      <span className="block text-[10px] font-extrabold text-rose-600 mt-0.5">
                                        স্টক শেষ
                                      </span>
                                    ) : (
                                      showProductPageVariantPrice && (
                                        <span
                                          className={`block font-mono text-[11px] sm:text-xs font-extrabold mt-0.5 ${
                                            isSelected ? 'text-emerald-700' : 'text-slate-600'
                                          }`}
                                        >
                                          ৳{v.retailPrice}
                                        </span>
                                      )
                                    )}
                                  </button>
                                );
                              }

                              // Design 3: Modern Price Tag / Pill Badge Style (Size on left, distinct price badge on right)
                              if (productPageVariantStyle === 'price_badge') {
                                return (
                                  <button
                                    key={v.id}
                                    type="button"
                                    onClick={handleVariantClick}
                                    className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer border-2 ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-600'
                                    }`}
                                  >
                                    <span className={isVarOut ? 'line-through' : ''}>{v.label}</span>
                                    {isVarOut ? (
                                      <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-700 text-[10px] font-extrabold">
                                        স্টক শেষ
                                      </span>
                                    ) : (
                                      showProductPageVariantPrice && (
                                        <span
                                          className={`px-2 py-0.5 rounded-lg font-mono text-[11px] sm:text-xs font-extrabold ${
                                            isSelected
                                              ? 'bg-amber-300 text-slate-950'
                                              : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                          }`}
                                        >
                                          ৳{v.retailPrice}
                                        </span>
                                      )
                                    )}
                                  </button>
                                );
                              }

                              // Design 4: Fashion Boutique Outline & Checkmark Style
                              if (productPageVariantStyle === 'minimal_check') {
                                return (
                                  <button
                                    key={v.id}
                                    type="button"
                                    onClick={handleVariantClick}
                                    className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer border-2 ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-emerald-50/90 text-emerald-950 border-emerald-700 shadow-xs'
                                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-600'
                                    }`}
                                  >
                                    <span
                                      className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 border ${
                                        isSelected && !isVarOut
                                          ? 'bg-emerald-700 border-emerald-700 text-white'
                                          : 'border-slate-300 bg-slate-50'
                                      }`}
                                    >
                                      {isSelected && !isVarOut && (
                                        <span className="w-1.5 h-1.5 rounded-full bg-white" />
                                      )}
                                    </span>
                                    <span className={isVarOut ? 'line-through' : ''}>{v.label}</span>
                                    {isVarOut ? (
                                      <span className="text-[10px] font-extrabold text-rose-600">
                                        (স্টক শেষ)
                                      </span>
                                    ) : (
                                      showProductPageVariantPrice && (
                                        <span
                                          className={`font-mono font-extrabold ${
                                            isSelected ? 'text-rose-700' : 'text-emerald-700'
                                          }`}
                                        >
                                          (৳{v.retailPrice})
                                        </span>
                                      )
                                    )}
                                  </button>
                                );
                              }

                              // Design 1 (Default / classic_inline): Exact Current Style ("1-2 Years · ৳990" or "1-2 Years" when price is OFF)
                              return (
                                <button
                                  key={v.id}
                                  type="button"
                                  onClick={handleVariantClick}
                                  className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer border-2 ${
                                    isVarOut
                                      ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                      : isSelected
                                      ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                                      : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-600'
                                  }`}
                                >
                                  <span className={isVarOut ? 'line-through' : ''}>{v.label}</span>
                                  {isVarOut ? (
                                    <span className="ml-1.5 text-[10px] font-extrabold text-rose-600">
                                      (স্টক শেষ)
                                    </span>
                                  ) : (
                                    showProductPageVariantPrice && (
                                      <span className="ml-1.5 font-mono opacity-90">· ৳{v.retailPrice}</span>
                                    )
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Standalone Product Out-of-Stock Admin Control & Size Chart when product has no variants */}
                      {(!quickViewProduct.variants || quickViewProduct.variants.length === 0) && (
                        <div className="flex flex-wrap items-center gap-2">
                          {isAuthenticated && (
                            <button
                              type="button"
                              onClick={() => {
                                const nextOut = !quickViewProduct.isOutOfStock;
                                updateProduct(quickViewProduct.id, { isOutOfStock: nextOut });
                                setQuickViewProduct(prev =>
                                  prev ? { ...prev, isOutOfStock: nextOut } : null
                                );
                                showToast(
                                  nextOut
                                    ? `"${quickViewProduct.nameBn}" স্টক আউট (Out of Stock) করা হয়েছে!`
                                    : `"${quickViewProduct.nameBn}" পুনরায় ইন-স্টক (In Stock) করা হয়েছে!`,
                                  nextOut ? 'info' : 'success'
                                );
                              }}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer transition-colors ${
                                quickViewProduct.isOutOfStock
                                  ? 'bg-rose-600 text-white border-rose-600'
                                  : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                              }`}
                            >
                              {quickViewProduct.isOutOfStock
                                ? '🚫 স্টক শেষ (চালু করুন)'
                                : '✓ স্টকে আছে (স্টক আউট করুন)'}
                            </button>
                          )}
                          {quickViewProduct.landingSizeChartEnabled !== false && (
                            <button
                              type="button"
                              onClick={() => setIsQvSizeChartModalOpen(true)}
                              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-extrabold cursor-pointer transition-colors shadow-2xs"
                            >
                              <Ruler className="w-3.5 h-3.5 text-indigo-700" />
                              <span>📏 সাইজ চার্ট ও মাপ দেখুন (Size Chart)</span>
                            </button>
                          )}
                        </div>
                      )}

                      {/* Quantity & Smart Marketing Low-Stock Urgency Display (Controlled by 1-Click Admin Toggle) */}
                      {(() => {
                        const isScarcityOn = currentBusiness.scarcityStockEnabled !== false;
                        const marketingLeftCount = getMarketingUrgencyStock(quickViewProduct, qvStock);
                        return (
                          <div className="space-y-2.5 pt-1">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <div className="flex items-center gap-3">
                                <span className="text-xs sm:text-sm font-bold text-slate-800">পরিমাণ:</span>
                                <div className="flex items-center border-2 border-slate-300 rounded-xl overflow-hidden bg-white">
                                  <button
                                    type="button"
                                    onClick={() => setQuickViewQty(Math.max(1, quickViewQty - 1))}
                                    className="w-10 h-10 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-900 cursor-pointer"
                                  >
                                    <Minus className="w-4 h-4" />
                                  </button>
                                  <span className="w-12 text-center font-mono font-extrabold text-sm">
                                    {quickViewQty}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => setQuickViewQty(Math.min(qvStock, quickViewQty + 1))}
                                    className="w-10 h-10 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-900 cursor-pointer"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>

                              {qvStock <= 0 ? (
                                <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
                                  বর্তমানে স্টকে নেই
                                </span>
                              ) : isScarcityOn ? (
                                <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-rose-700 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200">
                                  <Flame className="w-3.5 h-3.5 text-[#c30000] fill-[#c30000] shrink-0" />
                                  <span>অফার মূল্যে আর মাত্র {marketingLeftCount} টি বাকি আছে!</span>
                                </span>
                              ) : null}
                            </div>

                            {qvStock > 0 && isScarcityOn && (
                              <div className="p-2.5 rounded-xl bg-rose-50/60 border border-rose-200/80 space-y-1.5">
                                <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                                  <span>🔥 প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে</span>
                                  <span className="text-[#c30000] font-extrabold">সীমিত স্টক</span>
                                </div>
                                <div className="w-full h-1.5 bg-rose-200/70 rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-gradient-to-r from-[#c30000] to-amber-500 rounded-full"
                                    style={{ width: `${Math.min(92, Math.max(74, 100 - marketingLeftCount * 2))}%` }}
                                  />
                                </div>
                              </div>
                            )}

                            {/* Smart Quantity-Based Free Delivery Offer Banner on Product Detail Page ("2 পিস বা 3 পিস কিনলে ডেলিভারি ফ্রি") */}
                            {qvStock > 0 && !isAdminFreeDeliveryEnabled && isQtyFreeDeliveryEnabled && (
                              <div
                                className={`p-3 rounded-xl border transition-all ${
                                  quickViewQty >= freeDeliveryMinQty || isQtyFreeDeliveryUnlocked
                                    ? 'bg-emerald-50/95 border-emerald-300 text-emerald-950'
                                    : 'bg-gradient-to-r from-amber-50 via-orange-50/80 to-rose-50/80 border-amber-300 text-slate-900'
                                }`}
                              >
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-2 text-xs font-extrabold">
                                    <Truck
                                      className={`w-4 h-4 shrink-0 ${
                                        quickViewQty >= freeDeliveryMinQty || isQtyFreeDeliveryUnlocked
                                          ? 'text-emerald-700'
                                          : 'text-[#c30000]'
                                      }`}
                                    />
                                    <span>
                                      {quickViewQty >= freeDeliveryMinQty || isQtyFreeDeliveryUnlocked
                                        ? `🎉 অভিনন্দন! ${toBanglaCountdownDigits(
                                            Math.max(quickViewQty, totalCartItems),
                                            1
                                          )} পিস অর্ডারে সারাদেশে ডেলিভারি চার্জ সম্পূর্ণ ফ্রি (৳০)!`
                                        : `🚚 বিশেষ অফার: ${toBanglaCountdownDigits(
                                            freeDeliveryMinQty,
                                            1
                                          )} পিস অর্ডার করলেই সারাদেশে ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!`}
                                    </span>
                                  </div>

                                  {quickViewQty < freeDeliveryMinQty && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setQuickViewQty(Math.min(qvStock, freeDeliveryMinQty))
                                      }
                                      className="px-2.5 py-1 rounded-lg bg-[#c30000] hover:bg-[#9e0000] text-white text-[11px] font-extrabold cursor-pointer shadow-2xs transition-colors shrink-0"
                                    >
                                      🔥 {toBanglaCountdownDigits(freeDeliveryMinQty, 1)} পিস নিন (ডেলিভারি ফ্রি)
                                    </button>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Admin Quick Toggle for "শপিং ব্যাগে যোগ করুন" (Product Page), "ব্যাগে যোগ করুন" (Home Page), and Separate Stock Scarcity Controls */}
                      {isAuthenticated && (
                        <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-2">
                          <div className="flex flex-wrap items-center justify-between gap-1.5">
                            <span className="text-[11px] font-extrabold text-slate-800">
                              ব্যাগে যোগ বাটন কন্ট্রোল:
                            </span>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  const nextState = !showAddToBagOnProductPage;
                                  updateBusiness({ showAddToBagOnProductPage: nextState });
                                  showToast(
                                    nextState
                                      ? 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন চালু (ON) করা হয়েছে!'
                                      : 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন বন্ধ (OFF) করা হয়েছে!',
                                    nextState ? 'success' : 'info'
                                  );
                                }}
                                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-colors cursor-pointer ${
                                  showAddToBagOnProductPage
                                    ? 'bg-[#006A4E] text-white border-[#006A4E] shadow-2xs'
                                    : 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                                }`}
                                title="প্রোডাক্ট পেজে 'শপিং ব্যাগে যোগ করুন' বাটন ON / OFF করুন"
                              >
                                <span>
                                  প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন":{' '}
                                  {showAddToBagOnProductPage ? 'ON' : 'OFF'}
                                </span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  const nextState = !showAddToBagOnHomePage;
                                  updateBusiness({ showAddToBagOnHomePage: nextState });
                                  showToast(
                                    nextState
                                      ? 'হোমপেজে "+ ব্যাগে যোগ করুন" বাটন চালু (ON) করা হয়েছে!'
                                      : 'হোমপেজে "+ ব্যাগে যোগ করুন" বাটন বন্ধ (OFF) করা হয়েছে!',
                                    nextState ? 'success' : 'info'
                                  );
                                }}
                                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-colors cursor-pointer ${
                                  showAddToBagOnHomePage
                                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                                    : 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                                }`}
                                title="হোমপেজে প্রোডাক্টের নিচে '+ ব্যাগে যোগ করুন' বাটন ON / OFF করুন"
                              >
                                <span>
                                  হোমপেজে "ব্যাগে যোগ করুন": {showAddToBagOnHomePage ? 'ON' : 'OFF'}
                                </span>
                              </button>
                            </div>
                          </div>

                          {/* Separate Admin Controls for Inner Product Page Scarcity vs Home Page Front Box "মাত্র ৫ টি বাকি" */}
                          <div className="pt-1.5 border-t border-emerald-200/70 flex flex-wrap items-center justify-between gap-1.5">
                            <span className="text-[11px] font-extrabold text-rose-900">
                              🔥 "মাত্র ৫ টি বাকি" স্টক কন্ট্রোল (আলাদা ON/OFF):
                            </span>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  const curInner = currentBusiness.scarcityStockEnabled !== false;
                                  const nextInner = !curInner;
                                  updateBusiness({ scarcityStockEnabled: nextInner });
                                  showToast(
                                    nextInner
                                      ? 'ভিতরের প্রোডাক্ট পেজে "অফার মূল্যে আর মাত্র ৫ টি বাকি" চালু (ON) করা হয়েছে!'
                                      : 'ভিতরের প্রোডাক্ট পেজে "অফার মূল্যে আর মাত্র ৫ টি বাকি" বন্ধ (OFF) করা হয়েছে! (হোমপেজের বক্সে কোনো পরিবর্তন হবে না)',
                                    nextInner ? 'success' : 'info'
                                  );
                                }}
                                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-colors cursor-pointer ${
                                  currentBusiness.scarcityStockEnabled !== false
                                    ? 'bg-[#c30000] text-white border-[#c30000] shadow-2xs'
                                    : 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                                }`}
                                title="ভিতরের প্রোডাক্ট পেজের স্টক অ্যালার্ট আলাদাভাবে ON / OFF করুন"
                              >
                                <span>
                                  প্রোডাক্ট পেজে স্টক অ্যালার্ট:{' '}
                                  {currentBusiness.scarcityStockEnabled !== false ? 'ON' : 'OFF'}
                                </span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  const curHome = currentBusiness.homePageScarcityStockEnabled !== false;
                                  const nextHome = !curHome;
                                  updateBusiness({ homePageScarcityStockEnabled: nextHome });
                                  showToast(
                                    nextHome
                                      ? 'হোমপেজ বক্সে "মাত্র ৫ টি বাকি" লেখাটি চালু (ON) করা হয়েছে!'
                                      : 'হোমপেজ বক্সে "মাত্র ৫ টি বাকি" লেখাটি বন্ধ (OFF) করা হয়েছে! (ভিতরের প্রোডাক্ট পেজের স্টক অ্যালার্ট আগের মতোই থাকবে)',
                                    nextHome ? 'success' : 'info'
                                  );
                                }}
                                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-colors cursor-pointer ${
                                  currentBusiness.homePageScarcityStockEnabled !== false
                                    ? 'bg-rose-600 text-white border-rose-700 shadow-2xs'
                                    : 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                                }`}
                                title="হোমপেজের প্রোডাক্ট বক্সে 'মাত্র ৫ টি বাকি' লেখাটি আলাদাভাবে ON / OFF করুন"
                              >
                                <span>
                                  হোমপেজ বক্সে "মাত্র ৫ টি বাকি":{' '}
                                  {currentBusiness.homePageScarcityStockEnabled !== false ? 'ON' : 'OFF'}
                                </span>
                              </button>
                            </div>
                          </div>

                          {/* Admin 1-Click Quantity-Based Free Delivery ("2 পিস / 3 পিস কিনলে ডেলিভারি ফ্রি") Control on Product Page */}
                          <div className="pt-1.5 border-t border-emerald-200/70 flex flex-wrap items-center justify-between gap-1.5">
                            <span className="text-[11px] font-extrabold text-emerald-950">
                              🚚 ২/৩ পিস কিনলে ডেলিভারি ফ্রি (ওয়েবসাইট ও ল্যান্ডিং পেজ):
                            </span>
                            <div className="flex flex-wrap items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  updateBusiness({ freeDeliveryByQtyEnabled: false });
                                  showToast('পিস হিসেবে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে!', 'info');
                                }}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold border cursor-pointer ${
                                  !isQtyFreeDeliveryEnabled
                                    ? 'bg-slate-800 text-white border-slate-800'
                                    : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                                }`}
                              >
                                OFF
                              </button>
                              {[2, 3, 4].map(qtyOpt => {
                                const isSel =
                                  isQtyFreeDeliveryEnabled && freeDeliveryMinQty === qtyOpt;
                                return (
                                  <button
                                    key={qtyOpt}
                                    type="button"
                                    onClick={() => {
                                      updateBusiness({
                                        freeDeliveryByQtyEnabled: true,
                                        freeDeliveryMinQty: qtyOpt,
                                        landingFreeDeliveryByQtyEnabled: true,
                                        landingFreeDeliveryMinQty: qtyOpt
                                      });
                                      showToast(
                                        `"${toBanglaCountdownDigits(qtyOpt, 1)} পিস কিনলে ডেলিভারি ফ্রি" অফার চালু (ON) করা হয়েছে!`,
                                        'success'
                                      );
                                    }}
                                    className={`px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold border cursor-pointer ${
                                      isSel
                                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                        : 'bg-white text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                                    }`}
                                  >
                                    {toBanglaCountdownDigits(qtyOpt, 1)} পিসে ফ্রি
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Primary Action Buttons */}
                      <div
                        className={`grid grid-cols-1 ${
                          showAddToBagOnProductPage ? 'sm:grid-cols-2' : ''
                        } gap-3 pt-2`}
                      >
                        <button
                          type="button"
                          disabled={qvStock <= 0}
                          onClick={() =>
                            handleDirectOrderNow(quickViewProduct, quickViewQty, qvActiveVariant)
                          }
                          className={`min-h-[48px] py-3 px-5 font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 transition-colors ${
                            qvStock <= 0
                              ? 'sf-stock-out-btn bg-slate-200 text-slate-500 border border-slate-300 cursor-not-allowed'
                              : 'bg-[#c30000] hover:bg-[#9e0000] text-white shadow-sm cursor-pointer animate-order-cta-attention'
                          }`}
                        >
                          <ShoppingBag className="w-4 h-4" />
                          <span>
                            {qvStock <= 0
                              ? 'স্টক নেই'
                              : `এখনই অর্ডার করুন (৳${qvRetailPrice * quickViewQty})`}
                          </span>
                        </button>

                        {showAddToBagOnProductPage && (
                          <button
                            type="button"
                            disabled={qvStock <= 0}
                            onClick={() => {
                              addToCart(quickViewProduct, quickViewQty, false, qvActiveVariant);
                            }}
                            className={`min-h-[48px] py-3 px-5 font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 transition-colors ${
                              qvStock <= 0
                                ? 'bg-emerald-50/70 text-emerald-700/60 border border-emerald-200/80 cursor-not-allowed'
                                : 'bg-[#006A4E] hover:bg-[#005840] text-white shadow-sm cursor-pointer'
                            }`}
                          >
                            <Plus className="w-4 h-4" />
                            <span>শপিং ব্যাগে যোগ করুন</span>
                          </button>
                        )}
                      </div>

                      {/* WhatsApp Order & Call For Order Buttons — Sleek single-line pair matching primary buttons */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <a
                          href={whatsappOrderHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => {
                            trackFacebookEvent({
                              business: currentBusiness,
                              eventName: 'Lead',
                              customData: {
                                content_ids: [quickViewProduct.id],
                                content_name: `WhatsApp Order - ${quickViewProduct.nameBn}`,
                                content_type: 'product',
                                value: qvRetailPrice * quickViewQty
                              }
                            }).catch(() => {});
                          }}
                          className="min-h-[46px] py-2.5 px-4 bg-emerald-50/90 hover:bg-[#25D366] text-emerald-950 hover:text-white border border-[#25D366]/60 hover:border-[#25D366] font-extrabold text-xs sm:text-sm rounded-xl shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer group"
                        >
                          <WhatsAppOriginalIcon className="w-4 h-4 text-[#25D366] group-hover:text-white shrink-0 transition-colors" />
                          <span>WhatsApp Order</span>
                        </a>

                        <a
                          href={`tel:${rawCallOrderPhone.replace(/\s+/g, '')}`}
                          onClick={() => {
                            trackFacebookEvent({
                              business: currentBusiness,
                              eventName: 'Lead',
                              customData: {
                                content_ids: [quickViewProduct.id],
                                content_name: `Call For Order - ${quickViewProduct.nameBn}`,
                                content_type: 'product',
                                value: qvRetailPrice * quickViewQty
                              }
                            }).catch(() => {});
                          }}
                          className="min-h-[46px] py-2.5 px-4 bg-orange-50/90 hover:bg-[#F97316] text-orange-950 hover:text-white border border-orange-300/90 hover:border-[#F97316] font-extrabold text-xs sm:text-sm rounded-xl shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer group"
                        >
                          <PhoneCall className="w-4 h-4 text-[#EA580C] group-hover:text-white shrink-0 transition-colors" />
                          <span>Call For Order</span>
                        </a>
                      </div>

                      {/* Delivery Info Box */}
                      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5 text-xs text-slate-700">
                        {isFlashFreeDeliveryActive && (
                          <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-950 font-extrabold flex items-center justify-between gap-2">
                            <span>
                              ⚡ ফ্ল্যাশ অফার: আগামী <strong className="text-[#c30000]">{flashCountdownLabelBn}</strong> এর মধ্যে অর্ডার করলেই ডেলিভারি ফ্রি!
                            </span>
                            <span className="px-2 py-0.5 rounded-full bg-emerald-700 text-white text-[10px] shrink-0">
                              ফ্রি ডেলিভারি
                            </span>
                          </div>
                        )}
                        {!isFlashFreeDeliveryActive &&
                          isProductSpecificFreeDeliveryEnabled &&
                          (quickViewProduct.freeDelivery || quickViewProduct.freeDeliveryOnLanding) && (
                            <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-950 font-extrabold flex items-center gap-2">
                              <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                              <span>
                                🚚 বিশেষ অফার: এই পণ্যটি অর্ডার করলেই আপনার পুরো অর্ডারের হোম ডেলিভারি সম্পূর্ণ ফ্রি (৳০)!
                              </span>
                            </div>
                          )}
                        {!isFlashFreeDeliveryActive &&
                          !(
                            isProductSpecificFreeDeliveryEnabled &&
                            (quickViewProduct.freeDelivery || quickViewProduct.freeDeliveryOnLanding)
                          ) &&
                          isMinAmountFreeDeliveryEnabled && (
                            <div className="p-2.5 rounded-lg bg-teal-50/90 border border-teal-200 text-teal-950 space-y-1.5">
                              {(() => {
                                const qvSub = Math.max(qvRetailPrice * quickViewQty, cartSubtotal);
                                const qvRem = Math.max(0, freeDeliveryMinOrderAmt - qvSub);
                                const qvPct = Math.min(
                                  100,
                                  Math.round((qvSub / freeDeliveryMinOrderAmt) * 100)
                                );
                                return (
                                  <>
                                    <div className="flex items-center justify-between gap-2 font-extrabold">
                                      <span>
                                        {qvRem <= 0
                                          ? `🎉 অভিনন্দন! ৳${freeDeliveryMinOrderAmt.toLocaleString(
                                              'en-IN'
                                            )}+ অর্ডারে ডেলিভারি সম্পূর্ণ ফ্রি!`
                                          : `🚚 আর মাত্র ৳${qvRem.toLocaleString(
                                              'en-IN'
                                            )} টাকার পণ্য যোগ করলেই ডেলিভারি সম্পূর্ণ ফ্রি!`}
                                      </span>
                                      <span className="font-mono text-[11px]">{qvPct}%</span>
                                    </div>
                                    <div className="w-full h-2 rounded-full bg-white border border-teal-200 overflow-hidden p-0.5">
                                      <div
                                        className="h-full rounded-full bg-gradient-to-r from-[#c30000] via-amber-500 to-emerald-600 transition-all duration-300"
                                        style={{ width: `${Math.max(8, qvPct)}%` }}
                                      />
                                    </div>
                                  </>
                                );
                              })()}
                            </div>
                          )}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div className="flex items-center gap-2">
                            <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                            <span>
                              {isAdminFreeDeliveryEnabled ||
                              isFlashFreeDeliveryActive ||
                              (isProductSpecificFreeDeliveryEnabled &&
                                (quickViewProduct.freeDelivery ||
                                  quickViewProduct.freeDeliveryOnLanding)) ||
                              (insideDhakaFee <= 0 && outsideDhakaFee <= 0)
                                ? 'হোম ডেলিভারি সম্পূর্ণ ফ্রি (দ্রুত ডেলিভারি)'
                                : isQtyFreeDeliveryEnabled && quickViewQty >= freeDeliveryMinQty
                                ? `🎉 ${toBanglaCountdownDigits(quickViewQty, 1)} পিস অর্ডারে ডেলিভারি সম্পূর্ণ ফ্রি!`
                                : isHalfDeliveryOfferEnabled
                                ? `🔥 ${deliveryDiscountPct}% ছাড়: ঢাকার ভিতরে ৳${insideDhakaFee} (আগে ৳${rawInsideDhakaFee}) / বাইরে ৳${outsideDhakaFee} (আগে ৳${rawOutsideDhakaFee})`
                                : isQtyFreeDeliveryEnabled
                                ? `ডেলিভারি: ঢাকার ভিতরে ৳${insideDhakaFee} / বাইরে ৳${outsideDhakaFee} (${toBanglaCountdownDigits(freeDeliveryMinQty, 1)} পিসে ফ্রি!)`
                                : `ডেলিভারি চার্জ: ঢাকার ভিতরে ৳${insideDhakaFee} / ঢাকার বাইরে ৳${outsideDhakaFee}`}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                            <span>ক্যাশ অন ডেলিভারি (পণ্য হাতে পেয়ে পেমেন্ট)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Product Description Section (পণ্যের বিস্তারিত বিবরণ — প্রোডাক্ট আপলোড বা এডিটের সময় যা লেখা হবে তাই দেখাবে) */}
                <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-4 sm:p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                    <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#c30000]" />
                      <span>পণ্যের বিস্তারিত বিবরণ (Product Description)</span>
                    </h2>
                    <div className="flex items-center gap-2">
                      {isAuthenticated && (
                        <button
                          type="button"
                          onClick={() => {
                            if (isEditingQvDescription) {
                              setIsEditingQvDescription(false);
                            } else {
                              setQvDescriptionDraft(productDescriptionText);
                              setIsEditingQvDescription(true);
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[11px] font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>{isEditingQvDescription ? 'বাতিল করুন' : 'বিবরণ এডিট করুন'}</span>
                        </button>
                      )}
                      {Boolean(currentBusiness.showProductSkuOnStorefront) && (
                        <span className="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg">
                          কোড: {quickViewProduct.sku}
                        </span>
                      )}
                    </div>
                  </div>

                  {isEditingQvDescription ? (
                    <div className="space-y-2.5 p-3.5 rounded-xl bg-indigo-50/50 border border-indigo-200">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-extrabold text-slate-800">
                          পণ্যের বিস্তারিত বিবরণ লিখুন (যা লিখবেন সেটাই নিচে দেখাবে):
                        </span>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              setQvDescriptionDraft(prev =>
                                prev.trim() ? `${prev.trimEnd()}\n✅ ` : '✅ '
                              )
                            }
                            className="px-2 py-1 rounded-lg bg-white hover:bg-indigo-50 text-slate-800 border border-slate-300 text-[11px] font-bold cursor-pointer"
                          >
                            + ✅ পয়েন্ট
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setQvDescriptionDraft(prev =>
                                prev.trim() ? `${prev.trimEnd()}\n• ` : '• '
                              )
                            }
                            className="px-2 py-1 rounded-lg bg-white hover:bg-indigo-50 text-slate-800 border border-slate-300 text-[11px] font-bold cursor-pointer"
                          >
                            + • বুলেট
                          </button>
                          <button
                            type="button"
                            onClick={() => setQvDescriptionDraft('')}
                            className="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-bold cursor-pointer"
                          >
                            মুছুন
                          </button>
                        </div>
                      </div>

                      <textarea
                        rows={5}
                        value={qvDescriptionDraft}
                        onChange={e => setQvDescriptionDraft(e.target.value)}
                        placeholder="এখানে পণ্যের বিস্তারিত বিবরণ লিখুন..."
                        className="w-full p-3 rounded-xl bg-white border border-indigo-300 focus:border-indigo-600 outline-hidden text-xs sm:text-sm text-slate-900 leading-relaxed"
                      />

                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setIsEditingQvDescription(false)}
                          className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-bold cursor-pointer"
                        >
                          বাতিল
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            const cleanText = qvDescriptionDraft.trim();
                            await updateProduct(quickViewProduct.id, {
                              description: cleanText
                            });
                            setQuickViewProduct(prev =>
                              prev ? { ...prev, description: cleanText } : null
                            );
                            setIsEditingQvDescription(false);
                            showToast('পণ্যের বিস্তারিত বিবরণ সফলভাবে আপডেট হয়েছে!', 'success');
                          }}
                          className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold cursor-pointer shadow-2xs"
                        >
                          বিবরণ সংরক্ষণ করুন
                        </button>
                      </div>
                    </div>
                  ) : productDescriptionText ? (
                    <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                      {productDescriptionText}
                    </div>
                  ) : (
                    <p className="text-xs sm:text-sm text-slate-400 italic">
                      এই পণ্যের কোনো বিস্তারিত বিবরণ যুক্ত করা হয়নি।
                    </p>
                  )}
                </div>

                {/* ======================================================================== */}
                {/* SIZE CHART SECTION ON STOREFRONT PRODUCT PAGE (সাইজ চার্ট ও মাপ)         */}
                {/* ======================================================================== */}
                {(quickViewProduct.landingSizeChartEnabled !== false || isAuthenticated) && (
                  <div className="bg-white rounded-2xl border border-indigo-200/90 shadow-2xs p-4 sm:p-6 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-indigo-100">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                          <Ruler className="w-4 h-4" />
                        </div>
                        <div>
                          <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                            {quickViewProduct.landingSizeChartTitle || 'সাইজ চার্ট ও বডির মাপ (Size Chart)'}
                          </h2>
                          {(quickViewProduct.landingSizeChartSubtitle !== undefined
                            ? quickViewProduct.landingSizeChartSubtitle
                            : 'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন') && (
                            <p className="text-[11px] text-slate-500">
                              {quickViewProduct.landingSizeChartSubtitle !== undefined
                                ? quickViewProduct.landingSizeChartSubtitle
                                : 'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন'}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {isAuthenticated && (
                          <>
                            <button
                              type="button"
                              onClick={async () => {
                                const nextState = quickViewProduct.landingSizeChartEnabled === false;
                                await updateProduct(quickViewProduct.id, {
                                  landingSizeChartEnabled: nextState
                                });
                                setQuickViewProduct(prev =>
                                  prev ? { ...prev, landingSizeChartEnabled: nextState } : null
                                );
                                showToast(
                                  nextState
                                    ? 'প্রোডাক্ট পেজে সাইজ চার্ট চালু (ON) করা হয়েছে!'
                                    : 'প্রোডাক্ট পেজে সাইজ চার্ট বন্ধ (OFF) করা হয়েছে!',
                                  nextState ? 'success' : 'info'
                                );
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer ${
                                quickViewProduct.landingSizeChartEnabled !== false
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                  : 'bg-slate-100 text-slate-600 border-slate-300'
                              }`}
                            >
                              {quickViewProduct.landingSizeChartEnabled !== false
                                ? 'সাইজ চার্ট: ON'
                                : 'সাইজ চার্ট: OFF'}
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                if (isEditingQvSizeChart) {
                                  setIsEditingQvSizeChart(false);
                                } else {
                                  const hdrs: [string, string, string] =
                                    Array.isArray(quickViewProduct.landingSizeChartHeaders) &&
                                    quickViewProduct.landingSizeChartHeaders.length === 3
                                      ? ([...quickViewProduct.landingSizeChartHeaders] as [
                                          string,
                                          string,
                                          string
                                        ])
                                      : [...DEFAULT_LANDING_SIZE_CHART_HEADERS];
                                  const rows =
                                    Array.isArray(quickViewProduct.landingSizeChartRows) &&
                                    quickViewProduct.landingSizeChartRows.length > 0
                                      ? quickViewProduct.landingSizeChartRows.map(r => ({ ...r }))
                                      : DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }));
                                  setQvSizeChartTitleDraft(
                                    quickViewProduct.landingSizeChartTitle ||
                                      'সাইজ চার্ট ও বডির মাপ (Size Chart)'
                                  );
                                  setQvSizeChartSubtitleDraft(
                                    quickViewProduct.landingSizeChartSubtitle !== undefined
                                      ? quickViewProduct.landingSizeChartSubtitle
                                      : 'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন'
                                  );
                                  setQvSizeChartHeadersDraft(hdrs);
                                  setQvSizeChartRowsDraft(rows);
                                  setIsEditingQvSizeChart(true);
                                }
                              }}
                              className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>{isEditingQvSizeChart ? 'বাতিল করুন' : 'সাইজ চার্ট এডিট'}</span>
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    {isEditingQvSizeChart ? (
                      <div className="space-y-3 p-3.5 rounded-xl bg-indigo-50/50 border border-indigo-200">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pb-2 border-b border-indigo-200/80">
                          <div>
                            <label className="block text-[11px] font-extrabold text-indigo-950 mb-1">
                              সাইজ চার্ট শিরোনাম (Title):
                            </label>
                            <input
                              type="text"
                              value={qvSizeChartTitleDraft}
                              onChange={e => setQvSizeChartTitleDraft(e.target.value)}
                              placeholder="সাইজ চার্ট ও বডির মাপ (Size Chart)"
                              className="w-full p-2 bg-white border border-indigo-300 rounded-lg text-xs font-bold text-slate-900"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-extrabold text-indigo-950 mb-1">
                              সাইজ চার্ট সাব-টাইটেল / নির্দেশনা (Subtitle):
                            </label>
                            <input
                              type="text"
                              value={qvSizeChartSubtitleDraft}
                              onChange={e => setQvSizeChartSubtitleDraft(e.target.value)}
                              placeholder="অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন"
                              className="w-full p-2 bg-white border border-indigo-300 rounded-lg text-xs font-semibold text-slate-800"
                            />
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-xs font-extrabold text-indigo-950">
                            সাইজ চার্ট টেবিল এডিট করুন:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setQvSizeChartHeadersDraft([...DEFAULT_LANDING_SIZE_CHART_HEADERS]);
                                setQvSizeChartRowsDraft(DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r })));
                              }}
                              className="px-2.5 py-1 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-lg text-[11px] font-bold cursor-pointer"
                            >
                              বেবি সাইজ (১-১২ বছর)
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setQvSizeChartHeadersDraft([
                                  'সাইজ (Size)',
                                  'বডি / চেস্ট (ইঞ্চি)',
                                  'লম্বা / Length (ইঞ্চি)'
                                ]);
                                setQvSizeChartRowsDraft([
                                  { id: 'sc_m', size: 'M (Medium)', chest: '৩৮ ইঞ্চি', length: '২৭ ইঞ্চি' },
                                  { id: 'sc_l', size: 'L (Large)', chest: '৪০ ইঞ্চি', length: '২৮ ইঞ্চি' },
                                  { id: 'sc_xl', size: 'XL (Extra Large)', chest: '৪২ ইঞ্চি', length: '২৯ ইঞ্চি' },
                                  { id: 'sc_xxl', size: 'XXL (Double XL)', chest: '৪৪ ইঞ্চি', length: '৩০ ইঞ্চি' }
                                ]);
                              }}
                              className="px-2.5 py-1 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-lg text-[11px] font-bold cursor-pointer"
                            >
                              বড়দের সাইজ (M-XXL)
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-1.5">
                          {qvSizeChartHeadersDraft.map((hdr, idx) => (
                            <input
                              key={idx}
                              type="text"
                              value={hdr}
                              onChange={e => {
                                const next = [...qvSizeChartHeadersDraft] as [string, string, string];
                                next[idx] = e.target.value;
                                setQvSizeChartHeadersDraft(next);
                              }}
                              className="p-2 bg-white border border-indigo-300 rounded-lg text-xs font-extrabold text-indigo-950"
                            />
                          ))}
                        </div>

                        <div className="space-y-1.5">
                          {qvSizeChartRowsDraft.map((row, rIdx) => (
                            <div key={row.id || rIdx} className="grid grid-cols-12 gap-1.5 items-center">
                              <input
                                type="text"
                                value={row.size}
                                onChange={e => {
                                  const val = e.target.value;
                                  setQvSizeChartRowsDraft(prev =>
                                    prev.map((it, i) => (i === rIdx ? { ...it, size: val } : it))
                                  );
                                }}
                                className="col-span-4 p-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold"
                              />
                              <input
                                type="text"
                                value={row.chest}
                                onChange={e => {
                                  const val = e.target.value;
                                  setQvSizeChartRowsDraft(prev =>
                                    prev.map((it, i) => (i === rIdx ? { ...it, chest: val } : it))
                                  );
                                }}
                                className="col-span-4 p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                              />
                              <input
                                type="text"
                                value={row.length}
                                onChange={e => {
                                  const val = e.target.value;
                                  setQvSizeChartRowsDraft(prev =>
                                    prev.map((it, i) => (i === rIdx ? { ...it, length: val } : it))
                                  );
                                }}
                                className="col-span-3 p-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                              />
                              <button
                                type="button"
                                onClick={() =>
                                  setQvSizeChartRowsDraft(prev => prev.filter((_, i) => i !== rIdx))
                                }
                                className="col-span-1 p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg flex justify-center cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                          <button
                            type="button"
                            onClick={() =>
                              setQvSizeChartRowsDraft(prev => [
                                ...prev,
                                {
                                  id: `sc_${Date.now()}`,
                                  size: 'নতুন সাইজ',
                                  chest: '৩০ ইঞ্চি',
                                  length: '২৬ ইঞ্চি'
                                }
                              ])
                            }
                            className="px-3 py-1.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-xl text-xs font-extrabold cursor-pointer"
                          >
                            + নতুন সাইজ সারি যোগ করুন
                          </button>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => setIsEditingQvSizeChart(false)}
                              className="px-3.5 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                            >
                              বাতিল
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                const nextTitle =
                                  qvSizeChartTitleDraft.trim() || 'সাইজ চার্ট ও বডির মাপ (Size Chart)';
                                const nextSubtitle = qvSizeChartSubtitleDraft.trim();
                                await updateProduct(quickViewProduct.id, {
                                  landingSizeChartEnabled: true,
                                  landingSizeChartTitle: nextTitle,
                                  landingSizeChartSubtitle: nextSubtitle,
                                  landingSizeChartHeaders: qvSizeChartHeadersDraft,
                                  landingSizeChartRows: qvSizeChartRowsDraft
                                });
                                setQuickViewProduct(prev =>
                                  prev
                                    ? {
                                        ...prev,
                                        landingSizeChartEnabled: true,
                                        landingSizeChartTitle: nextTitle,
                                        landingSizeChartSubtitle: nextSubtitle,
                                        landingSizeChartHeaders: qvSizeChartHeadersDraft,
                                        landingSizeChartRows: qvSizeChartRowsDraft
                                      }
                                    : null
                                );
                                setIsEditingQvSizeChart(false);
                                showToast('সাইজ চার্ট সফলভাবে আপডেট হয়েছে!', 'success');
                              }}
                              className="px-4 py-1.5 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl text-xs font-extrabold cursor-pointer"
                            >
                              সাইজ চার্ট সংরক্ষণ করুন
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : quickViewProduct.landingSizeChartEnabled !== false ? (
                      <div className="space-y-3">
                        {quickViewProduct.landingSizeChartImage && (
                          <div className="rounded-xl overflow-hidden border border-indigo-100 bg-slate-50 p-2 flex justify-center">
                            <img
                              src={quickViewProduct.landingSizeChartImage}
                              alt="Size Chart"
                              className="max-h-72 w-auto object-contain rounded-lg"
                            />
                          </div>
                        )}
                        <div className="overflow-x-auto rounded-xl border border-indigo-200/80">
                          {(() => {
                            const headers =
                              Array.isArray(quickViewProduct.landingSizeChartHeaders) &&
                              quickViewProduct.landingSizeChartHeaders.length === 3
                                ? quickViewProduct.landingSizeChartHeaders
                                : DEFAULT_LANDING_SIZE_CHART_HEADERS;
                            const rows =
                              Array.isArray(quickViewProduct.landingSizeChartRows) &&
                              quickViewProduct.landingSizeChartRows.length > 0
                                ? quickViewProduct.landingSizeChartRows
                                : DEFAULT_LANDING_SIZE_CHART_ROWS;
                            return (
                              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                                <thead>
                                  <tr className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-emerald-900 text-white">
                                    {headers.map((h, i) => (
                                      <th
                                        key={i}
                                        className="py-2.5 px-3 font-extrabold border-r border-white/15 last:border-r-0"
                                      >
                                        {h}
                                      </th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-indigo-100">
                                  {rows.map((r, rIdx) => (
                                    <tr
                                      key={r.id || rIdx}
                                      className={
                                        rIdx % 2 === 0 ? 'bg-white' : 'bg-indigo-50/40'
                                      }
                                    >
                                      <td className="py-2 px-3 font-extrabold text-indigo-950 border-r border-indigo-100">
                                        {r.size}
                                      </td>
                                      <td className="py-2 px-3 font-semibold text-slate-700 border-r border-indigo-100">
                                        {r.chest}
                                      </td>
                                      <td className="py-2 px-3 font-semibold text-slate-700">
                                        {r.length}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            );
                          })()}
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">
                        এই পণ্যের সাইজ চার্ট বর্তমানে বন্ধ (OFF) আছে।
                      </p>
                    )}
                  </div>
                )}

                {/* ======================================================================== */}
                {/* REAL CUSTOMER PHOTO & UNBOXING VIDEO GALLERY (Clean, Fast, Click-to-Play) */}
                {/* ======================================================================== */}
                {((qvRealGalleryEnabled &&
                  (qvRealCustomerPhotos.length > 0 || qvUnboxingVideoEmbed.type !== 'none')) ||
                  isAuthenticated) && (
                  <div
                    className={`rounded-2xl border shadow-2xs p-4 sm:p-6 space-y-4 ${
                      qvRealGalleryEnabled
                        ? 'bg-white border-emerald-200/90'
                        : 'bg-slate-100/80 border-dashed border-slate-300 opacity-85'
                    }`}
                  >
                    {/* Hidden File Input for Real Customer Photos Upload */}
                    {isAuthenticated && (
                      <input
                        ref={qvRealCustomerPhotosInputRef}
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleQvRealCustomerPhotosUpload}
                        className="hidden"
                      />
                    )}

                    {/* Compact Admin Bar (Visible ONLY to Admin) */}
                    {isAuthenticated && (
                      <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/90 space-y-2.5 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-extrabold text-emerald-950">
                              📸 অ্যাডমিন কন্ট্রোল (ছবি ও ভিডিও):
                            </span>
                            {!qvRealGalleryEnabled && (
                              <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-extrabold">
                                কাস্টমারদের জন্য এখন বন্ধ (OFF) আছে
                              </span>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => qvRealCustomerPhotosInputRef.current?.click()}
                              disabled={isUploadingQvReviewAvatar}
                              className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-[11px] inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
                            >
                              <Upload className="w-3.5 h-3.5" />
                              <span>+ ছবি আপলোড</span>
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                const next = !qvRealGalleryEnabled;
                                await updateProduct(quickViewProduct.id, {
                                  realCustomerGalleryEnabled: next
                                });
                                setQuickViewProduct(prev =>
                                  prev ? { ...prev, realCustomerGalleryEnabled: next } : null
                                );
                                showToast(
                                  next
                                    ? 'ছবি ও ভিডিও সেকশন চালু (ON) করা হয়েছে!'
                                    : 'ছবি ও ভিডিও সেকশন বন্ধ (OFF) করা হয়েছে!',
                                  next ? 'success' : 'info'
                                );
                              }}
                              className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold border cursor-pointer ${
                                qvRealGalleryEnabled
                                  ? 'bg-white text-emerald-800 border-emerald-300'
                                  : 'bg-rose-600 text-white border-rose-600'
                              }`}
                            >
                              {qvRealGalleryEnabled ? 'গ্যালারি: ON ✓' : 'গ্যালারি: OFF'}
                            </button>
                          </div>
                        </div>

                        <div>
                          <input
                            type="text"
                            defaultValue={qvRawUnboxingVideoUrl}
                            placeholder="YouTube / Shorts / FB Reels ভিডিও লিংক পেস্ট করুন..."
                            onBlur={async e => {
                              const val = e.target.value.trim();
                              if (val !== qvRawUnboxingVideoUrl) {
                                await updateProduct(quickViewProduct.id, {
                                  realUnboxingVideoUrl: val,
                                  realCustomerGalleryEnabled: true
                                });
                                setQuickViewProduct(prev =>
                                  prev
                                    ? {
                                        ...prev,
                                        realUnboxingVideoUrl: val,
                                        realCustomerGalleryEnabled: true
                                      }
                                    : null
                                );
                                setQvRealVideoPlaying(false);
                                showToast(
                                  val
                                    ? 'ভিডিও লিংক সেভ হয়েছে!'
                                    : 'ভিডিও লিংক সরানো হয়েছে',
                                  'success'
                                );
                              }
                            }}
                            onKeyDown={async e => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                const val = (e.target as HTMLInputElement).value.trim();
                                await updateProduct(quickViewProduct.id, {
                                  realUnboxingVideoUrl: val,
                                  realCustomerGalleryEnabled: true
                                });
                                setQuickViewProduct(prev =>
                                  prev
                                    ? {
                                        ...prev,
                                        realUnboxingVideoUrl: val,
                                        realCustomerGalleryEnabled: true
                                      }
                                    : null
                                );
                                setQvRealVideoPlaying(false);
                                showToast('ভিডিও লিংক সেভ হয়েছে!', 'success');
                              }
                            }}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-emerald-200 text-xs font-semibold text-slate-800 outline-hidden focus:border-emerald-600"
                          />
                        </div>
                      </div>
                    )}

                    {/* Clean Content Area: Photos Grid + Click-to-Play Video */}
                    {qvRealCustomerPhotos.length === 0 && qvUnboxingVideoEmbed.type === 'none' ? (
                      isAuthenticated && (
                        <p className="text-xs text-slate-400 italic text-center py-2">
                          এখনো কোনো ছবি বা ভিডিও যুক্ত করা হয়নি (কাস্টমারদের কাছে এই বক্সটি এখন লুকানো থাকবে)।
                        </p>
                      )
                    ) : (
                      <div className="space-y-4">
                        {/* 1. Real Customer Wearing Photos Grid (Lazy WebP + Click to Zoom) */}
                        {qvRealCustomerPhotos.length > 0 && (
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
                            {qvRealCustomerPhotos.map((photoUrl, pIdx) => (
                              <div
                                key={`real_cust_photo_${pIdx}`}
                                onClick={() => setQvSelectedRealPhotoLightbox(photoUrl)}
                                className="group relative aspect-square rounded-xl overflow-hidden bg-slate-50 border border-slate-200/90 hover:border-emerald-500 cursor-pointer shadow-2xs"
                              >
                                <img
                                  src={photoUrl}
                                  alt={`${quickViewProduct.nameBn} ${pIdx + 1}`}
                                  loading="lazy"
                                  decoding="async"
                                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                                />

                                {isAuthenticated && (
                                  <button
                                    type="button"
                                    onClick={async e => {
                                      e.stopPropagation();
                                      const nextPhotos = qvRealCustomerPhotos.filter(
                                        (_, i) => i !== pIdx
                                      );
                                      await updateProduct(quickViewProduct.id, {
                                        realCustomerPhotos: nextPhotos
                                      });
                                      setQuickViewProduct(prev =>
                                        prev ? { ...prev, realCustomerPhotos: nextPhotos } : null
                                      );
                                      showToast('ছবিটি মুছে ফেলা হয়েছে', 'info');
                                    }}
                                    title="এই ছবিটি মুছে ফেলুন"
                                    className="absolute top-2 right-2 w-6 h-6 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center shadow-md cursor-pointer"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            ))}
                          </div>
                        )}

                        {/* 2. Click-to-Play Video Box (0 KB video loaded until customer clicks Play!) */}
                        {qvUnboxingVideoEmbed.type !== 'none' && Boolean(qvUnboxingVideoEmbed.embedUrl) && (
                          <div className="w-full max-w-2xl mx-auto rounded-2xl overflow-hidden border border-slate-200 bg-slate-950 shadow-xs">
                            {!qvRealVideoPlaying ? (
                              <button
                                type="button"
                                onClick={() => setQvRealVideoPlaying(true)}
                                aria-label="Play video"
                                className="group relative w-full aspect-video flex flex-col items-center justify-center overflow-hidden cursor-pointer bg-slate-900"
                              >
                                {(() => {
                                  const posterSrc = (
                                    qvRealCustomerPhotos[0] ||
                                    getProductImageUrl(quickViewProduct.image, false) ||
                                    ''
                                  ).trim();
                                  return posterSrc ? (
                                    <img
                                      src={posterSrc}
                                      alt={quickViewProduct.nameBn}
                                      loading="lazy"
                                      decoding="async"
                                      className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
                                    />
                                  ) : (
                                    <div className="absolute inset-0 w-full h-full opacity-60 pointer-events-none">
                                      <ProductThumbnail
                                        product={quickViewProduct}
                                        className="w-full h-full"
                                        imgClassName="object-cover"
                                      />
                                    </div>
                                  );
                                })()}
                                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-slate-950/25 to-slate-950/40" />

                                <div className="relative z-10 flex items-center justify-center p-4">
                                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-rose-600 group-hover:bg-rose-500 text-white flex items-center justify-center shadow-xl ring-4 ring-white/25 transition-transform group-hover:scale-110">
                                    <Play className="w-6 h-6 sm:w-7 sm:h-7 fill-white ml-0.5" />
                                  </div>
                                </div>
                              </button>
                            ) : qvUnboxingVideoEmbed.type === 'iframe' ? (
                              <div className="relative w-full aspect-video bg-black">
                                <iframe
                                  src={qvUnboxingVideoEmbed.embedUrl || undefined}
                                  title={`${quickViewProduct.nameBn} - আনবক্সিং ভিডিও`}
                                  className="w-full h-full border-0"
                                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                  allowFullScreen
                                />
                              </div>
                            ) : (
                              <video
                                src={qvUnboxingVideoEmbed.embedUrl || undefined}
                                controls
                                autoPlay
                                playsInline
                                className="w-full max-h-[460px] object-contain mx-auto"
                              />
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Clean Lightbox Modal when Customer taps a Real Customer Photo */}
                    {qvSelectedRealPhotoLightbox && (
                      <div
                        onClick={() => setQvSelectedRealPhotoLightbox(null)}
                        className="fixed inset-0 z-[120] bg-black/90 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
                      >
                        <div
                          onClick={e => e.stopPropagation()}
                          className="relative max-w-lg w-full rounded-2xl overflow-hidden bg-white shadow-2xl"
                        >
                          <img
                            src={qvSelectedRealPhotoLightbox}
                            alt="বাস্তব ছবি"
                            className="w-full max-h-[80vh] object-contain bg-slate-950"
                          />
                          <button
                            type="button"
                            onClick={() => setQvSelectedRealPhotoLightbox(null)}
                            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-slate-950/80 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-lg"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* ======================================================================== */}
                {/* CUSTOMER REVIEWS SLIDER & REVIEWER CIRCULAR PHOTO SYSTEM ON PRODUCT PAGE */}
                {/* ======================================================================== */}
                {(qvReviewsEnabled || isAuthenticated) && (
                  <div
                    className={`rounded-2xl border shadow-2xs p-4 sm:p-6 space-y-4 ${
                      qvReviewsEnabled
                        ? 'bg-white border-amber-200/90'
                        : 'bg-slate-100/80 border-dashed border-slate-300 opacity-85'
                    }`}
                  >
                    {/* Hidden File Inputs for Circular Avatar & Screenshot Uploads */}
                    <input
                      ref={qvReviewerAvatarInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleQvReviewerAvatarFileChange}
                      className="hidden"
                    />
                    <input
                      ref={qvNewReviewerAvatarInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleQvNewReviewerAvatarUpload}
                      className="hidden"
                    />
                    {isAuthenticated && (
                      <input
                        ref={qvScreenshotUploadInputRef}
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleQvScreenshotUpload}
                        className="hidden"
                      />
                    )}

                    {/* Minimal Top Header Badge + Write Review Button */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-50 text-amber-900 border border-amber-200 text-xs font-extrabold">
                          <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                          <span>১০০% ভেরিফাইড কাস্টমার ফিডব্যাক</span>
                        </div>
                        {!qvReviewsEnabled && isAuthenticated && (
                          <span className="px-2.5 py-0.5 rounded-md bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold">
                            কাস্টমারদের জন্য এখন লুকানো (OFF) আছে
                          </span>
                        )}
                      </div>

                      {isAuthenticated && (
                        <button
                          type="button"
                          onClick={() => setIsWritingQvReview(prev => !prev)}
                          className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>
                            {isWritingQvReview
                              ? 'ফর্ম বন্ধ করুন'
                              : '+ নতুন রিভিউ ও ছবি যোগ/এডিট'}
                          </span>
                        </button>
                      )}
                    </div>

                    {/* Admin Inline Control Bar for Reviews (Slider ON/OFF + Avatar & Review Manager) */}
                    {isAuthenticated && (
                      <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200/90 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-xs font-extrabold text-amber-950">
                          <span>✨ অ্যাডমিন রিভিউ কন্ট্রোল:</span>
                          <span className="text-[11px] font-semibold text-amber-800">
                            (যেকোনো কাস্টমারের নামের পাশের গোল বৃত্তে ক্লিক করলেই তার ছবি আপলোড করতে পারবেন)
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <button
                            type="button"
                            onClick={async () => {
                              const next = !qvReviewsSliderEnabled;
                              await updateProduct(quickViewProduct.id, {
                                landingReviewsSliderEnabled: next
                              });
                              setQuickViewProduct(prev =>
                                prev
                                  ? { ...prev, landingReviewsSliderEnabled: next }
                                  : null
                              );
                              showToast(
                                next
                                  ? '🎠 প্রোডাক্ট পেজে কাস্টমার রিভিউ স্লাইডার ভিউ চালু (ON) করা হয়েছে!'
                                  : '📋 প্রোডাক্ট পেজে কাস্টমার রিভিউ গ্রিড ভিউ সেট (OFF) করা হয়েছে!',
                                next ? 'success' : 'info'
                              );
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                              qvReviewsSliderEnabled
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            {qvReviewsSliderEnabled
                              ? '🎠 স্লাইডার ভিউ: ON (কম জায়গায় অনেক রিভিউ) ✓'
                              : '📋 গ্রিড ভিউ (স্লাইডার চালু করতে ক্লিক করুন)'}
                          </button>

                          <button
                            type="button"
                            onClick={() => qvScreenshotUploadInputRef.current?.click()}
                            className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>স্ক্রিনশট আপলোড</span>
                          </button>

                          <button
                            type="button"
                            onClick={async () => {
                              const nextState = !qvReviewsEnabled;
                              await updateProduct(quickViewProduct.id, {
                                landingReviewsEnabled: nextState
                              });
                              setQuickViewProduct(prev =>
                                prev ? { ...prev, landingReviewsEnabled: nextState } : null
                              );
                              showToast(
                                nextState
                                  ? 'প্রোডাক্ট পেজে রিভিউ সেকশন চালু (ON) করা হয়েছে!'
                                  : 'প্রোডাক্ট পেজে রিভিউ সেকশন বন্ধ (OFF) করা হয়েছে!',
                                nextState ? 'success' : 'info'
                              );
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-colors cursor-pointer ${
                              qvReviewsEnabled
                                ? 'bg-white text-emerald-800 border-emerald-300 hover:bg-emerald-50'
                                : 'bg-rose-600 text-white border-rose-600'
                            }`}
                          >
                            {qvReviewsEnabled ? 'রিভিউ সেকশন: ON' : 'রিভিউ সেকশন: OFF'}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Write Custom Review Form on Product Page (Admin Only) */}
                    {isAuthenticated && isWritingQvReview && (
                      <div className="p-4 rounded-2xl bg-amber-50/70 border-2 border-amber-300 space-y-3.5 animate-page-rise">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <h4 className="text-xs sm:text-sm font-extrabold text-amber-950">
                            ✍️ প্রোডাক্ট পেজে নতুন রিভিউ যুক্ত করুন (প্রোফাইল ছবিসহ):
                          </h4>
                          {isAuthenticated && (
                            <button
                              type="button"
                              onClick={async () => {
                                const presetReviews: LandingReviewItem[] = [
                                  {
                                    id: `rev_${Date.now()}_1`,
                                    customerName: 'সাদিয়া আফরিন মিম',
                                    location: 'ধানমন্ডি, ঢাকা',
                                    rating: 5,
                                    comment:
                                      'আলহামদুলিল্লাহ! ছবির চেয়েও বাস্তবে প্রোডাক্টটি অনেক বেশি সুন্দর। কাপড় ও সেলাই একদম প্রিমিয়াম কোয়ালিটির। ডেলিভারিও খুব দ্রুত পেয়েছি।',
                                    status: 'approved'
                                  },
                                  {
                                    id: `rev_${Date.now()}_2`,
                                    customerName: 'তানজিনা আক্তার',
                                    location: 'খুলশী, চট্টগ্রাম',
                                    rating: 5,
                                    comment:
                                      'সাইজ চার্ট দেখে অর্ডার করেছিলাম, একদম পারফেক্ট ফিট হয়েছে! ডেলিভারি ম্যানের সামনে চেক করে টাকা পরিশোধ করেছি। ধন্যবাদ।',
                                    status: 'approved'
                                  },
                                  {
                                    id: `rev_${Date.now()}_3`,
                                    customerName: 'রাকিবুল ইসলাম',
                                    location: 'বোয়ালিয়া, রাজশাহী',
                                    rating: 5,
                                    comment:
                                      'অফার প্রাইসে এত ভালো মানের প্রোডাক্ট পাবো আশা করিনি। প্যাকেজিং ও সার্ভিস ১০০ তে ১০০!',
                                    status: 'approved'
                                  }
                                ];
                                const merged = [...presetReviews, ...qvAllReviews];
                                await updateProduct(quickViewProduct.id, {
                                  landingReviewsEnabled: true,
                                  landingReviewItems: merged
                                });
                                setQuickViewProduct(prev =>
                                  prev
                                    ? {
                                        ...prev,
                                        landingReviewsEnabled: true,
                                        landingReviewItems: merged
                                      }
                                    : null
                                );
                                setQvActiveReviewSlide(0);
                                showToast('৩টি ভেরিফাইড কাস্টমার রিভিউ যুক্ত হয়েছে!', 'success');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-100 text-amber-900 border border-amber-400 text-[11px] font-extrabold cursor-pointer"
                            >
                              + ১-ক্লিকে ৩টি রেডি ফেক রিভিউ যোগ করুন
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                          {/* Circular Reviewer Avatar Upload */}
                          <div className="sm:col-span-3 flex items-center gap-2.5">
                            <div className="relative shrink-0">
                              {qvNewRevAvatar ? (
                                <img
                                  src={qvNewRevAvatar}
                                  alt="Preview"
                                  className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500 shadow-2xs"
                                />
                              ) : (
                                <div className="w-11 h-11 rounded-full bg-emerald-700 text-white font-extrabold text-sm flex items-center justify-center">
                                  {(qvNewRevName.trim() || 'ক').slice(0, 1)}
                                </div>
                              )}
                              {qvNewRevAvatar && (
                                <button
                                  type="button"
                                  onClick={() => setQvNewRevAvatar('')}
                                  className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                  title="ছবি মুছুন"
                                >
                                  ×
                                </button>
                              )}
                            </div>
                            <div>
                              <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                ক্রেতার ছবি (ঐচ্ছিক)
                              </label>
                              <button
                                type="button"
                                disabled={isUploadingQvReviewAvatar}
                                onClick={() => qvNewReviewerAvatarInputRef.current?.click()}
                                className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-extrabold inline-flex items-center gap-1 cursor-pointer"
                              >
                                <Upload className="w-3 h-3" />
                                <span>{qvNewRevAvatar ? 'ছবি পরিবর্তন' : '📷 ছবি দিন'}</span>
                              </button>
                            </div>
                          </div>

                          <div className="sm:col-span-3">
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              কাস্টমারের নাম *
                            </label>
                            <input
                              type="text"
                              value={qvNewRevName}
                              onChange={e => setQvNewRevName(e.target.value)}
                              placeholder="যেমন: নুসরাত জাহান তন্বী"
                              className="w-full p-2.5 bg-white border border-amber-300 rounded-xl text-xs font-bold"
                            />
                          </div>

                          <div className="sm:col-span-3">
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              লোকেশন / জেলা
                            </label>
                            <input
                              type="text"
                              value={qvNewRevLocation}
                              onChange={e => setQvNewRevLocation(e.target.value)}
                              placeholder="যেমন: উত্তরা, ঢাকা"
                              className="w-full p-2.5 bg-white border border-amber-300 rounded-xl text-xs"
                            />
                          </div>

                          <div className="sm:col-span-3">
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              রেটিং (স্টার)
                            </label>
                            <select
                              value={qvNewRevRating}
                              onChange={e => setQvNewRevRating(Number(e.target.value) || 5)}
                              className="w-full p-2.5 bg-white border border-amber-300 rounded-xl text-xs font-extrabold text-amber-700"
                            >
                              <option value={5}>⭐⭐⭐⭐⭐ (৫ স্টার - অসাধারণ)</option>
                              <option value={4}>⭐⭐⭐⭐ (৪ স্টার - খুব ভালো)</option>
                              <option value={3}>⭐⭐⭐ (৩ স্টার - ভালো)</option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">
                            রিভিউ কমেন্ট / মতামত *
                          </label>
                          <textarea
                            rows={3}
                            value={qvNewRevComment}
                            onChange={e => setQvNewRevComment(e.target.value)}
                            placeholder="পণ্যটি কেমন লেগেছে তা এখানে বিস্তারিত লিখুন..."
                            className="w-full p-2.5 bg-white border border-amber-300 rounded-xl text-xs sm:text-sm"
                          />
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                          {isAuthenticated && (
                            <p className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                              ✓ অ্যাডমিন হিসেবে লেখা রিভিউ সরাসরি পেজে প্রকাশিত (Approved) হবে।
                            </p>
                          )}
                          <div className="flex justify-end gap-2 ml-auto">
                            <button
                              type="button"
                              onClick={() => setIsWritingQvReview(false)}
                              className="px-3.5 py-2 rounded-xl bg-white border border-slate-300 text-xs font-bold text-slate-700 cursor-pointer"
                            >
                              বাতিল
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                if (!qvNewRevName.trim() || !qvNewRevComment.trim()) {
                                  showToast('অনুগ্রহ করে নাম এবং রিভিউ কমেন্ট লিখুন!', 'error');
                                  return;
                                }
                                const isDirectApprove = Boolean(isAuthenticated);
                                const newReview: LandingReviewItem = {
                                  id: `rev_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
                                  customerName: qvNewRevName.trim(),
                                  location: qvNewRevLocation.trim() || 'ঢাকা',
                                  rating: qvNewRevRating,
                                  comment: qvNewRevComment.trim(),
                                  avatarUrl: qvNewRevAvatar || undefined,
                                  status: isDirectApprove ? 'approved' : 'pending',
                                  submittedBy: isDirectApprove ? 'admin' : 'customer',
                                  createdAt: new Date().toISOString()
                                };
                                const nextList = [newReview, ...qvAllReviews.map(r => ({ ...r }))];
                                await updateProduct(quickViewProduct.id, {
                                  landingReviewsEnabled: true,
                                  landingReviewItems: nextList
                                });
                                setQuickViewProduct(prev =>
                                  prev
                                    ? {
                                        ...prev,
                                        landingReviewsEnabled: true,
                                        landingReviewItems: nextList
                                      }
                                    : null
                                );
                                setQvNewRevName('');
                                setQvNewRevComment('');
                                setQvNewRevAvatar('');
                                setQvActiveReviewSlide(0);
                                setIsWritingQvReview(false);
                                if (isDirectApprove) {
                                  showToast('রিভিউ সফলভাবে প্রোডাক্ট পেজে যুক্ত ও প্রকাশিত হয়েছে!', 'success');
                                } else {
                                  showToast(
                                    'ধন্যবাদ! আপনার রিভিউটি জমা হয়েছে। অ্যাডমিন অ্যাপ্রুভ করলেই এটি প্রকাশিত হবে।',
                                    'success'
                                  );
                                }
                              }}
                              className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold cursor-pointer shadow-xs"
                            >
                              {isAuthenticated ? 'রিভিউ প্রকাশ করুন' : 'রিভিউ জমা দিন'}
                            </button>
                          </div>
                        </div>

                        {/* Admin Quick List of All Existing Reviews to Change Avatar or Delete */}
                        {isAuthenticated && qvAllReviews.length > 0 && (
                          <div className="pt-3 border-t border-amber-200 space-y-2 max-h-60 overflow-y-auto pr-1">
                            <p className="text-[11px] font-extrabold text-amber-950">
                              📋 সকল রিভিউ ও ক্রেতার গোল ছবি ম্যানেজার ({qvAllReviews.length}টি):
                            </p>
                            {qvAllReviews.map((rev, idx) => (
                              <div
                                key={rev.id || idx}
                                className="p-2.5 rounded-xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                              >
                                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                                  {rev.avatarUrl ? (
                                    <img
                                      src={rev.avatarUrl}
                                      alt={rev.customerName}
                                      className="w-9 h-9 rounded-full object-cover border-2 border-emerald-500 shrink-0"
                                    />
                                  ) : (
                                    <div className="w-9 h-9 rounded-full bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center shrink-0">
                                      {(rev.customerName || 'ক').trim().slice(0, 1)}
                                    </div>
                                  )}
                                  <div className="min-w-0 flex-1">
                                    <div className="flex flex-wrap items-center gap-1.5">
                                      <span className="text-xs font-extrabold text-slate-900">
                                        {rev.customerName}
                                      </span>
                                      {rev.location && (
                                        <span className="text-[10px] font-semibold text-slate-500">
                                          · {rev.location}
                                        </span>
                                      )}
                                      {rev.status === 'pending' && (
                                        <span className="px-1.5 py-0.5 rounded bg-amber-200 text-amber-950 text-[10px] font-extrabold">
                                          ⏳ পেন্ডিং
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-xs text-slate-600 truncate">{rev.comment}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => handleQvTriggerReviewerAvatarUpload(rev.id)}
                                    className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-extrabold inline-flex items-center gap-1 cursor-pointer"
                                  >
                                    <Upload className="w-3 h-3" />
                                    <span>{rev.avatarUrl ? 'ছবি পরিবর্তন' : '📷 ছবি দিন'}</span>
                                  </button>
                                  {rev.avatarUrl && (
                                    <button
                                      type="button"
                                      onClick={() => handleQvRemoveReviewerAvatar(rev.id)}
                                      className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold cursor-pointer"
                                    >
                                      ছবি মুছুন
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      const filtered = qvAllReviews.filter(r => r.id !== rev.id);
                                      await updateProduct(quickViewProduct.id, {
                                        landingReviewItems: filtered
                                      });
                                      setQuickViewProduct(prev =>
                                        prev ? { ...prev, landingReviewItems: filtered } : null
                                      );
                                      showToast('রিভিউটি মুছে ফেলা হয়েছে', 'info');
                                    }}
                                    className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer"
                                    title="রিভিউ ডিলিট করুন"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Pending Approval Banner for Admin */}
                    {isAuthenticated && qvPendingReviews.length > 0 && (
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-xs font-extrabold text-amber-950">
                          <span className="px-2 py-0.5 rounded-md bg-amber-500 text-slate-950">
                            ⏳ পেন্ডিং রিভিউ: {qvPendingReviews.length}টি
                          </span>
                          <span>
                            কাস্টমারের দেওয়া রিভিউ নিচে অ্যাপ্রুভালের অপেক্ষায় আছে। Approve করলে সবার জন্য পাবলিশ হবে।
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            const approvedAll = qvAllReviews.map(r => ({
                              ...r,
                              status: 'approved' as const
                            }));
                            await updateProduct(quickViewProduct.id, {
                              landingReviewItems: approvedAll
                            });
                            setQuickViewProduct(prev =>
                              prev ? { ...prev, landingReviewItems: approvedAll } : null
                            );
                            showToast('সব পেন্ডিং রিভিউ অ্যাপ্রুভ ও পাবলিশ করা হয়েছে!', 'success');
                          }}
                          className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-extrabold cursor-pointer shadow-2xs"
                        >
                          ✓ সব অ্যাপ্রুভ করুন
                        </button>
                      </div>
                    )}

                    {/* Uploaded Review Screenshots: Slider Mode vs Grid Mode */}
                    {qvReviewScreenshots.length > 0 && (
                      qvReviewsSliderEnabled && qvReviewScreenshots.length > 1 ? (
                        <div className="space-y-3">
                          <div
                            className="relative overflow-hidden rounded-2xl select-none cursor-grab active:cursor-grabbing touch-pan-y"
                            onTouchStart={e => {
                              qvShotTouchEndXRef.current = null;
                              qvShotTouchStartXRef.current = e.targetTouches[0]?.clientX ?? null;
                              setIsQvReviewSliderPaused(true);
                            }}
                            onTouchMove={e => {
                              qvShotTouchEndXRef.current = e.targetTouches[0]?.clientX ?? null;
                            }}
                            onTouchEnd={() => {
                              if (
                                qvShotTouchStartXRef.current !== null &&
                                qvShotTouchEndXRef.current !== null
                              ) {
                                const dist =
                                  qvShotTouchStartXRef.current - qvShotTouchEndXRef.current;
                                if (Math.abs(dist) > 28) {
                                  if (dist > 0) {
                                    setQvActiveScreenshotSlide(
                                      prev => (prev + 1) % qvReviewScreenshots.length
                                    );
                                  } else {
                                    setQvActiveScreenshotSlide(
                                      prev =>
                                        (prev - 1 + qvReviewScreenshots.length) %
                                        qvReviewScreenshots.length
                                    );
                                  }
                                }
                              }
                              qvShotTouchStartXRef.current = null;
                              qvShotTouchEndXRef.current = null;
                              setIsQvReviewSliderPaused(false);
                            }}
                            onMouseDown={e => {
                              qvShotMouseStartXRef.current = e.clientX;
                              setIsQvReviewSliderPaused(true);
                            }}
                            onMouseUp={e => {
                              if (qvShotMouseStartXRef.current !== null) {
                                const dist = qvShotMouseStartXRef.current - e.clientX;
                                if (Math.abs(dist) > 30) {
                                  if (dist > 0) {
                                    setQvActiveScreenshotSlide(
                                      prev => (prev + 1) % qvReviewScreenshots.length
                                    );
                                  } else {
                                    setQvActiveScreenshotSlide(
                                      prev =>
                                        (prev - 1 + qvReviewScreenshots.length) %
                                        qvReviewScreenshots.length
                                    );
                                  }
                                }
                              }
                              qvShotMouseStartXRef.current = null;
                              setIsQvReviewSliderPaused(false);
                            }}
                            onMouseLeave={() => {
                              qvShotMouseStartXRef.current = null;
                              setIsQvReviewSliderPaused(false);
                            }}
                          >
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                              {Array.from({
                                length: Math.min(3, qvReviewScreenshots.length)
                              }).map((_, offset) => {
                                const shotIdx =
                                  (safeQvScreenshotSlide + offset) % qvReviewScreenshots.length;
                                const imgUrl = qvReviewScreenshots[shotIdx];
                                return (
                                  <div
                                    key={`qv_shot_${shotIdx}_${offset}`}
                                    className={`${
                                      offset === 0
                                        ? 'block'
                                        : offset === 1
                                        ? 'hidden sm:block'
                                        : 'hidden md:block'
                                    } relative rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden shadow-2xs transition-all duration-300`}
                                  >
                                    <LazyImage
                                      src={imgUrl}
                                      alt={`Customer Review ${shotIdx + 1}`}
                                      wrapperClassName="relative w-full overflow-hidden flex justify-center"
                                      skeletonClassName="min-h-[180px]"
                                      className="w-full h-auto max-h-80 object-contain mx-auto"
                                    />
                                    {isAuthenticated && (
                                      <button
                                        type="button"
                                        onClick={async () => {
                                          const nextShots = qvReviewScreenshots.filter(
                                            (_, i) => i !== shotIdx
                                          );
                                          await updateProduct(quickViewProduct.id, {
                                            landingReviewImages: nextShots
                                          });
                                          setQuickViewProduct(prev =>
                                            prev ? { ...prev, landingReviewImages: nextShots } : null
                                          );
                                          showToast('স্ক্রিনশট মুছে ফেলা হয়েছে', 'info');
                                        }}
                                        className="absolute top-2 right-2 w-7 h-7 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs font-bold shadow-md cursor-pointer"
                                        title="স্ক্রিনশট মুছুন"
                                      >
                                        ×
                                      </button>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Screenshot Slider Dots */}
                          <div className="flex items-center justify-center gap-1.5">
                            {qvReviewScreenshots.map((_, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setQvActiveScreenshotSlide(idx)}
                                className={`h-2 rounded-full transition-all cursor-pointer ${
                                  safeQvScreenshotSlide === idx
                                    ? 'w-6 bg-amber-500'
                                    : 'w-2 bg-slate-300 hover:bg-slate-400'
                                }`}
                                aria-label={`Screenshot slide ${idx + 1}`}
                              />
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                          {qvReviewScreenshots.map((imgUrl, idx) => (
                            <div
                              key={idx}
                              className="relative rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden shadow-2xs"
                            >
                              <LazyImage
                                src={imgUrl}
                                alt={`Customer Review ${idx + 1}`}
                                wrapperClassName="relative w-full overflow-hidden flex justify-center"
                                skeletonClassName="min-h-[180px]"
                                className="w-full h-auto max-h-96 object-contain mx-auto"
                              />
                              {isAuthenticated && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    const nextShots = qvReviewScreenshots.filter((_, i) => i !== idx);
                                    await updateProduct(quickViewProduct.id, {
                                      landingReviewImages: nextShots
                                    });
                                    setQuickViewProduct(prev =>
                                      prev ? { ...prev, landingReviewImages: nextShots } : null
                                    );
                                    showToast('স্ক্রিনশট মুছে ফেলা হয়েছে', 'info');
                                  }}
                                  className="absolute top-2 right-2 w-7 h-7 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs font-bold shadow-md cursor-pointer"
                                  title="স্ক্রিনশট মুছুন"
                                >
                                  ×
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      )
                    )}

                    {/* Written Customer Reviews: Touch & Mouse Swipe Slider Mode vs Grid Mode */}
                    {qvDisplayReviews.length === 0 && qvReviewScreenshots.length === 0 ? (
                      <p className="text-xs text-slate-400 italic py-2">
                        এখনো কোনো প্রকাশিত রিভিউ নেই। প্রথম রিভিউটি আপনিই লিখুন!
                      </p>
                    ) : qvDisplayReviews.length > 0 ? (
                      qvReviewsSliderEnabled ? (
                        <div className="space-y-3">
                          <div
                            className="relative select-none cursor-grab active:cursor-grabbing touch-pan-y"
                            onTouchStart={e => {
                              qvRevTouchEndXRef.current = null;
                              qvRevTouchStartXRef.current = e.targetTouches[0]?.clientX ?? null;
                              setIsQvReviewSliderPaused(true);
                            }}
                            onTouchMove={e => {
                              qvRevTouchEndXRef.current = e.targetTouches[0]?.clientX ?? null;
                            }}
                            onTouchEnd={() => {
                              if (
                                qvRevTouchStartXRef.current !== null &&
                                qvRevTouchEndXRef.current !== null
                              ) {
                                const dist =
                                  qvRevTouchStartXRef.current - qvRevTouchEndXRef.current;
                                if (Math.abs(dist) > 25) {
                                  if (dist > 0) {
                                    handleQvNextReviewSlide();
                                  } else {
                                    handleQvPrevReviewSlide();
                                  }
                                }
                              }
                              qvRevTouchStartXRef.current = null;
                              qvRevTouchEndXRef.current = null;
                              setIsQvReviewSliderPaused(false);
                            }}
                            onMouseDown={e => {
                              qvRevMouseStartXRef.current = e.clientX;
                              setIsQvReviewSliderPaused(true);
                            }}
                            onMouseUp={e => {
                              if (qvRevMouseStartXRef.current !== null) {
                                const dist = qvRevMouseStartXRef.current - e.clientX;
                                if (Math.abs(dist) > 30) {
                                  if (dist > 0) {
                                    handleQvNextReviewSlide();
                                  } else {
                                    handleQvPrevReviewSlide();
                                  }
                                }
                              }
                              qvRevMouseStartXRef.current = null;
                              setIsQvReviewSliderPaused(false);
                            }}
                            onMouseLeave={() => {
                              qvRevMouseStartXRef.current = null;
                              setIsQvReviewSliderPaused(false);
                            }}
                          >
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              {Array.from({
                                length: Math.min(3, qvDisplayReviews.length)
                              }).map((_, offset) => {
                                const revIdx = (safeQvReviewSlide + offset) % qvDisplayReviews.length;
                                const rev = qvDisplayReviews[revIdx];
                                const isPending = rev.status === 'pending';

                                return (
                                  <div
                                    key={`${rev.id || revIdx}_qv_slide_${offset}`}
                                    className={`${
                                      offset === 0 ? 'flex' : 'hidden md:flex'
                                    } p-4 sm:p-5 rounded-2xl flex-col justify-between gap-4 shadow-2xs transition-all duration-300 ${
                                      isPending
                                        ? 'bg-amber-50/90 border-2 border-dashed border-amber-400'
                                        : 'bg-gradient-to-b from-amber-50/35 via-white to-slate-50/80 border border-amber-200/80'
                                    }`}
                                  >
                                    <div className="space-y-2.5">
                                      <div className="flex items-center justify-between gap-2 flex-wrap">
                                        <div className="flex items-center gap-0.5 text-amber-400">
                                          {Array.from({ length: rev.rating || 5 }).map((_, sIdx) => (
                                            <Star
                                              key={sIdx}
                                              className="w-3.5 h-3.5 fill-amber-400 text-amber-400"
                                            />
                                          ))}
                                        </div>
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          {isPending ? (
                                            <span className="px-2 py-0.5 rounded-md bg-amber-200 text-amber-950 text-[10px] font-extrabold">
                                              ⏳ পেন্ডিং
                                            </span>
                                          ) : (
                                            <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-extrabold">
                                              ✓ ভেরিফাইড ক্রেতা
                                            </span>
                                          )}
                                          {isAuthenticated && isPending && (
                                            <button
                                              type="button"
                                              onClick={async e => {
                                                e.stopPropagation();
                                                const updated = qvAllReviews.map(r =>
                                                  r.id === rev.id
                                                    ? { ...r, status: 'approved' as const }
                                                    : r
                                                );
                                                await updateProduct(quickViewProduct.id, {
                                                  landingReviewItems: updated
                                                });
                                                setQuickViewProduct(prev =>
                                                  prev
                                                    ? { ...prev, landingReviewItems: updated }
                                                    : null
                                                );
                                                showToast(
                                                  'রিভিউটি অ্যাপ্রুভ ও পাবলিশ করা হয়েছে!',
                                                  'success'
                                                );
                                              }}
                                              className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer"
                                            >
                                              Approve
                                            </button>
                                          )}
                                        </div>
                                      </div>

                                      <p className="text-sm sm:text-base text-slate-800 font-medium leading-relaxed">
                                        &ldquo;{rev.comment}&rdquo;
                                      </p>
                                    </div>

                                    <div className="pt-3 border-t border-slate-200/70 flex items-center justify-between gap-2.5">
                                      <div className="flex items-center gap-3 min-w-0">
                                        {/* Circular Reviewer Profile Photo OR First-Letter Circle (Clickable by Admin to Upload Photo) */}
                                        <div className="relative shrink-0 group">
                                          {rev.avatarUrl ? (
                                            <img
                                              src={rev.avatarUrl}
                                              alt={rev.customerName}
                                              loading="lazy"
                                              decoding="async"
                                              onClick={e => {
                                                e.stopPropagation();
                                                if (isAuthenticated) {
                                                  handleQvTriggerReviewerAvatarUpload(rev.id);
                                                }
                                              }}
                                              className={`w-11 h-11 rounded-full object-cover border-2 border-emerald-500/50 shadow-2xs ${
                                                isAuthenticated
                                                  ? 'cursor-pointer hover:opacity-90'
                                                  : ''
                                              }`}
                                              title={
                                                isAuthenticated
                                                  ? 'ক্লিক করে এই ক্রেতার গোল ছবি পরিবর্তন করুন'
                                                  : rev.customerName
                                              }
                                            />
                                          ) : (
                                            <div
                                              onClick={e => {
                                                e.stopPropagation();
                                                if (isAuthenticated) {
                                                  handleQvTriggerReviewerAvatarUpload(rev.id);
                                                }
                                              }}
                                              className={`w-11 h-11 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 text-white font-extrabold text-base flex items-center justify-center shrink-0 shadow-2xs ${
                                                isAuthenticated
                                                  ? 'cursor-pointer ring-2 ring-amber-400/70 hover:from-emerald-700 hover:to-teal-800'
                                                  : ''
                                              }`}
                                              title={
                                                isAuthenticated
                                                  ? 'এখানে ক্লিক করে নামের প্রথম অক্ষরের বদলে ক্রেতার ছবি আপলোড করুন'
                                                  : rev.customerName
                                              }
                                            >
                                              {(rev.customerName || 'ক').trim().slice(0, 1)}
                                            </div>
                                          )}

                                          {isAuthenticated && (
                                            <button
                                              type="button"
                                              onClick={e => {
                                                e.stopPropagation();
                                                handleQvTriggerReviewerAvatarUpload(rev.id);
                                              }}
                                              className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 hover:bg-amber-600 text-white border border-white flex items-center justify-center shadow-xs cursor-pointer"
                                              title="এই গোল বৃত্তে ক্রেতার ছবি আপলোড করুন"
                                            >
                                              <Upload className="w-2.5 h-2.5" />
                                            </button>
                                          )}

                                          {isAuthenticated && rev.avatarUrl && (
                                            <button
                                              type="button"
                                              onClick={e => {
                                                e.stopPropagation();
                                                handleQvRemoveReviewerAvatar(rev.id);
                                              }}
                                              className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-[10px] leading-none flex items-center justify-center shadow-xs cursor-pointer"
                                              title="ছবি সরিয়ে প্রথম অক্ষর দেখান"
                                            >
                                              ×
                                            </button>
                                          )}
                                        </div>

                                        <div className="min-w-0">
                                          <p className="text-sm font-extrabold text-slate-900 truncate">
                                            {rev.customerName}
                                          </p>
                                          {rev.location && (
                                            <p className="text-xs text-slate-500 font-medium truncate">
                                              {rev.location}
                                            </p>
                                          )}
                                        </div>
                                      </div>

                                      {isAuthenticated && (
                                        <div className="flex items-center gap-1 shrink-0">
                                          <button
                                            type="button"
                                            onClick={e => {
                                              e.stopPropagation();
                                              handleQvTriggerReviewerAvatarUpload(rev.id);
                                            }}
                                            className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-extrabold cursor-pointer"
                                          >
                                            {rev.avatarUrl ? '📷 ছবি বদলান' : '📷 ছবি দিন'}
                                          </button>
                                          <button
                                            type="button"
                                            onClick={async e => {
                                              e.stopPropagation();
                                              const filtered = qvAllReviews.filter(
                                                r => r.id !== rev.id
                                              );
                                              await updateProduct(quickViewProduct.id, {
                                                landingReviewItems: filtered
                                              });
                                              setQuickViewProduct(prev =>
                                                prev
                                                  ? { ...prev, landingReviewItems: filtered }
                                                  : null
                                              );
                                              showToast('রিভিউটি মুছে ফেলা হয়েছে', 'info');
                                            }}
                                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                                            title="রিভিউ ডিলিট করুন"
                                          >
                                            <Trash2 className="w-3 h-3" />
                                          </button>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Minimal Pagination Dots Only (No Prev/Next Buttons) */}
                          {qvDisplayReviews.length > 1 && (
                            <div className="flex items-center justify-center gap-1.5 pt-0.5">
                              {qvDisplayReviews.map((rev, idx) => (
                                <button
                                  key={rev.id || idx}
                                  type="button"
                                  onClick={() => setQvActiveReviewSlide(idx)}
                                  className={`h-2 rounded-full transition-all cursor-pointer ${
                                    safeQvReviewSlide === idx
                                      ? 'w-6 bg-amber-500'
                                      : 'w-2 bg-slate-300 hover:bg-amber-300'
                                  }`}
                                  aria-label={`Go to review ${idx + 1}`}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      ) : (
                        /* Classic Grid Mode (when Slider is turned OFF) */
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {qvDisplayReviews.map((rev, idx) => {
                            const isPending = rev.status === 'pending';
                            return (
                              <div
                                key={rev.id || idx}
                                className={`p-4 sm:p-5 rounded-2xl flex flex-col justify-between gap-4 shadow-2xs ${
                                  isPending
                                    ? 'bg-amber-50/90 border-2 border-dashed border-amber-400'
                                    : 'bg-gradient-to-b from-slate-50/90 to-white border border-slate-200/90'
                                }`}
                              >
                                <div className="space-y-2.5">
                                  <div className="flex items-center justify-between gap-2 flex-wrap">
                                    <div className="flex items-center gap-0.5 text-amber-400">
                                      {Array.from({ length: rev.rating || 5 }).map((_, sIdx) => (
                                        <Star
                                          key={sIdx}
                                          className="w-3.5 h-3.5 fill-amber-400 text-amber-400"
                                        />
                                      ))}
                                    </div>
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      {isPending ? (
                                        <span className="px-2 py-0.5 rounded-md bg-amber-200 text-amber-950 text-[10px] font-extrabold">
                                          ⏳ পেন্ডিং
                                        </span>
                                      ) : (
                                        <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-extrabold">
                                          ✓ ভেরিফাইড ক্রেতা
                                        </span>
                                      )}
                                      {isAuthenticated && isPending && (
                                        <button
                                          type="button"
                                          onClick={async () => {
                                            const updated = qvAllReviews.map(r =>
                                              r.id === rev.id
                                                ? { ...r, status: 'approved' as const }
                                                : r
                                            );
                                            await updateProduct(quickViewProduct.id, {
                                              landingReviewItems: updated
                                            });
                                            setQuickViewProduct(prev =>
                                              prev ? { ...prev, landingReviewItems: updated } : null
                                            );
                                            showToast(
                                              'রিভিউটি অ্যাপ্রুভ ও পাবলিশ করা হয়েছে!',
                                              'success'
                                            );
                                          }}
                                          className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer"
                                        >
                                          Approve
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                  <p className="text-sm sm:text-base text-slate-800 font-medium leading-relaxed">
                                    &ldquo;{rev.comment}&rdquo;
                                  </p>
                                </div>

                                <div className="pt-3 border-t border-slate-200/70 flex items-center justify-between gap-2.5">
                                  <div className="flex items-center gap-3 min-w-0">
                                    <div className="relative shrink-0">
                                      {rev.avatarUrl ? (
                                        <img
                                          src={rev.avatarUrl}
                                          alt={rev.customerName}
                                          loading="lazy"
                                          decoding="async"
                                          onClick={() => {
                                            if (isAuthenticated) {
                                              handleQvTriggerReviewerAvatarUpload(rev.id);
                                            }
                                          }}
                                          className={`w-11 h-11 rounded-full object-cover border-2 border-emerald-500/50 shadow-2xs ${
                                            isAuthenticated
                                              ? 'cursor-pointer hover:opacity-90'
                                              : ''
                                          }`}
                                        />
                                      ) : (
                                        <div
                                          onClick={() => {
                                            if (isAuthenticated) {
                                              handleQvTriggerReviewerAvatarUpload(rev.id);
                                            }
                                          }}
                                          className={`w-11 h-11 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 text-white font-extrabold text-base flex items-center justify-center shrink-0 ${
                                            isAuthenticated
                                              ? 'cursor-pointer ring-2 ring-amber-400/70'
                                              : ''
                                          }`}
                                        >
                                          {(rev.customerName || 'ক').trim().slice(0, 1)}
                                        </div>
                                      )}

                                      {isAuthenticated && (
                                        <button
                                          type="button"
                                          onClick={e => {
                                            e.stopPropagation();
                                            handleQvTriggerReviewerAvatarUpload(rev.id);
                                          }}
                                          className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 hover:bg-amber-600 text-white border border-white flex items-center justify-center shadow-xs cursor-pointer"
                                          title="এই গোল বৃত্তে ক্রেতার ছবি আপলোড করুন"
                                        >
                                          <Upload className="w-2.5 h-2.5" />
                                        </button>
                                      )}

                                      {isAuthenticated && rev.avatarUrl && (
                                        <button
                                          type="button"
                                          onClick={e => {
                                            e.stopPropagation();
                                            handleQvRemoveReviewerAvatar(rev.id);
                                          }}
                                          className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-[10px] leading-none flex items-center justify-center shadow-xs cursor-pointer"
                                          title="ছবি সরিয়ে প্রথম অক্ষর দেখান"
                                        >
                                          ×
                                        </button>
                                      )}
                                    </div>

                                    <div className="min-w-0">
                                      <p className="text-sm font-extrabold text-slate-900 truncate">
                                        {rev.customerName}
                                      </p>
                                      {rev.location && (
                                        <p className="text-xs text-slate-500 font-medium truncate">
                                          {rev.location}
                                        </p>
                                      )}
                                    </div>
                                  </div>

                                  {isAuthenticated && (
                                    <div className="flex items-center gap-1 shrink-0">
                                      <button
                                        type="button"
                                        onClick={() => handleQvTriggerReviewerAvatarUpload(rev.id)}
                                        className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-extrabold cursor-pointer"
                                      >
                                        {rev.avatarUrl ? '📷 ছবি বদলান' : '📷 ছবি দিন'}
                                      </button>
                                      <button
                                        type="button"
                                        onClick={async () => {
                                          const filtered = qvAllReviews.filter(
                                            r => r.id !== rev.id
                                          );
                                          await updateProduct(quickViewProduct.id, {
                                            landingReviewItems: filtered
                                          });
                                          setQuickViewProduct(prev =>
                                            prev ? { ...prev, landingReviewItems: filtered } : null
                                          );
                                          showToast('রিভিউটি মুছে ফেলা হয়েছে', 'info');
                                        }}
                                        className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                                        title="রিভিউ ডিলিট করুন"
                                      >
                                        <Trash2 className="w-3 h-3" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )
                    ) : null}
                  </div>
                )}

                {/* SIZE CHART POPUP MODAL WHEN CLICKING "📏 সাইজ চার্ট দেখুন" */}
                {isQvSizeChartModalOpen && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-page-rise">
                    <div className="bg-white rounded-2xl max-w-xl w-full p-4 sm:p-6 border border-indigo-200 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                        <div className="flex items-center gap-2">
                          <Ruler className="w-5 h-5 text-indigo-700 shrink-0" />
                          <div>
                            <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                              {quickViewProduct.landingSizeChartTitle ||
                                'সাইজ চার্ট ও বডির মাপ (Size Chart)'}
                            </h3>
                            {(quickViewProduct.landingSizeChartSubtitle !== undefined
                              ? quickViewProduct.landingSizeChartSubtitle
                              : 'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন') && (
                              <p className="text-[11px] text-slate-500">
                                {quickViewProduct.landingSizeChartSubtitle !== undefined
                                  ? quickViewProduct.landingSizeChartSubtitle
                                  : 'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন'}
                              </p>
                            )}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setIsQvSizeChartModalOpen(false)}
                          className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>

                      {quickViewProduct.landingSizeChartImage && (
                        <div className="rounded-xl overflow-hidden border border-indigo-100 bg-slate-50 p-2 flex justify-center">
                          <img
                            src={quickViewProduct.landingSizeChartImage}
                            alt="Size Chart"
                            className="max-h-64 w-auto object-contain rounded-lg"
                          />
                        </div>
                      )}

                      <div className="overflow-x-auto rounded-xl border border-indigo-200">
                        {(() => {
                          const headers =
                            Array.isArray(quickViewProduct.landingSizeChartHeaders) &&
                            quickViewProduct.landingSizeChartHeaders.length === 3
                              ? quickViewProduct.landingSizeChartHeaders
                              : DEFAULT_LANDING_SIZE_CHART_HEADERS;
                          const rows =
                            Array.isArray(quickViewProduct.landingSizeChartRows) &&
                            quickViewProduct.landingSizeChartRows.length > 0
                              ? quickViewProduct.landingSizeChartRows
                              : DEFAULT_LANDING_SIZE_CHART_ROWS;
                          return (
                            <table className="w-full text-left border-collapse text-xs sm:text-sm">
                              <thead>
                                <tr className="bg-gradient-to-r from-indigo-900 to-emerald-900 text-white">
                                  {headers.map((h, i) => (
                                    <th
                                      key={i}
                                      className="py-2.5 px-3 font-extrabold border-r border-white/15 last:border-r-0"
                                    >
                                      {h}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-indigo-100">
                                {rows.map((r, rIdx) => (
                                  <tr
                                    key={r.id || rIdx}
                                    className={rIdx % 2 === 0 ? 'bg-white' : 'bg-indigo-50/40'}
                                  >
                                    <td className="py-2 px-3 font-extrabold text-indigo-950 border-r border-indigo-100">
                                      {r.size}
                                    </td>
                                    <td className="py-2 px-3 font-semibold text-slate-700 border-r border-indigo-100">
                                      {r.chest}
                                    </td>
                                    <td className="py-2 px-3 font-semibold text-slate-700">
                                      {r.length}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          );
                        })()}
                      </div>

                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => setIsQvSizeChartModalOpen(false)}
                          className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold cursor-pointer"
                        >
                          ঠিক আছে, বুঝেছি
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* More Products Section (With Full Variation Selector Pills & Order/Bag Buttons) */}
                {relatedProducts.length > 0 && (
                  <div className="space-y-3 pt-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                        আমাদের আরও পণ্য
                      </h3>
                      {isAuthenticated && (
                        <button
                          type="button"
                          onClick={() => {
                            const nextFull = !Boolean(currentBusiness.showFullProductNameOnCards);
                            updateBusiness({ showFullProductNameOnCards: nextFull });
                            showToast(
                              nextFull
                                ? 'হোমপেজ ও রিলেটেড প্রোডাক্টে সম্পূর্ণ নাম দেখানো চালু (ON) করা হয়েছে!'
                                : 'হোমপেজ ও রিলেটেড প্রোডাক্টে ২-লাইনে সংক্ষিপ্ত নাম (OFF) সেট করা হয়েছে!',
                              nextFull ? 'success' : 'info'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-extrabold border cursor-pointer transition-all ${
                            currentBusiness.showFullProductNameOnCards
                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                              : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-500'
                          }`}
                          title="হোমপেজ এবং রিলেটেড প্রোডাক্টে সম্পূর্ণ নাম দেখানো ON / OFF করুন"
                        >
                          {currentBusiness.showFullProductNameOnCards
                            ? '📝 প্রোডাক্টের সম্পূর্ণ নাম: চালু (ON)'
                            : '📝 প্রোডাক্টের নাম: ২-লাইন সংক্ষিপ্ত (OFF)'}
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-4">
                      {relatedProducts.map(rp => {
                        const rpAvailable = getProductAvailableStock(rp);
                        const rpIsOut = rpAvailable <= 0;
                        const rpVar = getActiveVariant(rp);
                        const rpPrice = rpVar ? rpVar.retailPrice : rp.retailPrice;
                        const rpMrp = getRegularMrpFromRetail(
                          rpPrice,
                          rpVar?.regularPrice ?? rp.regularPrice,
                          rpVar?.discountPrice ?? rp.discountPrice
                        );
                        const rpDiscount = Math.max(0, rpMrp - rpPrice);
                        const rpExplicitVar = getExplicitSelectedVariant(rp);
                        const rpHasVars = Boolean(rp.variants && rp.variants.length > 0);
                        const rpCartKey = buildCartKey(rp.id, rpVar);
                        const rpInCartQty =
                          isVariantSelectionRequired && rpHasVars && !rpExplicitVar
                            ? 0
                            : cart[rpCartKey]?.quantity || 0;

                        return (
                          <div
                            key={rp.id}
                            className="bg-white rounded-2xl border border-slate-200/85 hover:border-emerald-500/80 shadow-2xs hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 flex flex-col justify-between overflow-hidden group"
                          >
                            <div>
                              <div
                                onClick={() => openQuickView(rp)}
                                className="relative aspect-square w-full bg-slate-50/40 border-b border-slate-100 cursor-pointer overflow-hidden"
                              >
                                <ProductThumbnail
                                  product={rp}
                                  imgClassName="p-2.5 group-hover:scale-105 transition-transform duration-300"
                                />
                                {rpDiscount > 0 && !rpIsOut && (
                                  <span className="absolute top-2 left-2 bg-rose-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-lg shadow-2xs">
                                    ছাড় ৳{rpDiscount}
                                  </span>
                                )}
                                {renderStockOutImageOverlay(rpIsOut, false)}
                              </div>

                              <div className="px-2.5 pt-2.5 pb-1 sm:px-3.5 sm:pt-3 sm:pb-1.5 space-y-1.5">
                                {(showVariantsOnHomePage || !rpHasVars || (!rpIsOut && currentBusiness.homePageScarcityStockEnabled !== false)) && (
                                  <div className="flex items-center justify-between gap-1 text-[10px] sm:text-[11px]">
                                    <span className="text-slate-500 truncate">
                                      {!showVariantsOnHomePage && rpHasVars
                                        ? ''
                                        : rpHasVars && isVariantSelectionRequired
                                        ? rpExplicitVar
                                          ? rpExplicitVar.label
                                          : 'সাইজ সিলেক্ট করুন'
                                        : rpVar
                                        ? rpVar.label
                                        : rp.unit}
                                    </span>
                                    {!rpIsOut && currentBusiness.homePageScarcityStockEnabled !== false && (
                                      <span className="text-[#c30000] font-bold shrink-0">
                                        মাত্র {getMarketingUrgencyStock(rp, rpAvailable)} টি বাকি
                                      </span>
                                    )}
                                  </div>
                                )}
                                <h4
                                  onClick={() => openQuickView(rp)}
                                  className={`sf-home-product-title text-xs sm:text-sm font-extrabold text-slate-900 group-hover:text-emerald-800 leading-snug cursor-pointer ${
                                    currentBusiness.showFullProductNameOnCards
                                      ? 'break-words'
                                      : 'line-clamp-2 min-h-[34px] sm:min-h-[40px]'
                                  }`}
                                >
                                  {language === 'bn' ? rp.nameBn : rp.nameEn}
                                </h4>

                                {/* Interactive Variation Pills (Shown on cards only when showVariantsOnHomePage is ON) */}
                                {showVariantsOnHomePage && rp.variants && rp.variants.length > 0 && (
                                  <div className="flex flex-wrap gap-1 pt-0.5">
                                    {rp.variants.map(v => {
                                      const isVarOut = Boolean(v.outOfStock);
                                      const isSelected =
                                        !isVarOut &&
                                        (isVariantSelectionRequired
                                          ? selectedVariantByProduct[rp.id] === v.id
                                          : rpVar?.id === v.id);
                                      return (
                                        <button
                                          key={v.id}
                                          type="button"
                                          onClick={() => {
                                            if (isVarOut) {
                                              showToast(
                                                `দুঃখিত, "${v.label}" বর্তমানে স্টকে নেই (স্টক শেষ)!`,
                                                'error'
                                              );
                                              return;
                                            }
                                            setSelectedVariantByProduct(prev => ({
                                              ...prev,
                                              [rp.id]: v.id
                                            }));
                                          }}
                                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                                            isVarOut
                                              ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-75'
                                              : isSelected
                                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-emerald-500'
                                          }`}
                                        >
                                          {v.label}
                                        </button>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="px-2.5 pb-2.5 pt-1 sm:px-3.5 sm:pb-3.5 sm:pt-1 space-y-1.5">
                              <div className="flex items-baseline gap-2 pb-0.5">
                                <span className="font-mono font-black text-lg sm:text-xl text-emerald-700 tabular-nums leading-none">
                                  ৳{rpPrice}
                                </span>
                                {rpMrp > rpPrice && (
                                  <span className="font-mono font-semibold text-xs sm:text-sm text-slate-400 line-through tabular-nums leading-none">
                                    ৳{rpMrp}
                                  </span>
                                )}
                              </div>

                              <button
                                type="button"
                                disabled={rpIsOut}
                                onClick={() => handleDirectOrderNow(rp, 1, rpVar)}
                                className={`w-full min-h-[38px] py-1.5 px-2 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                                  rpIsOut
                                    ? 'sf-stock-out-btn bg-slate-200 text-slate-500 border border-slate-200/90 cursor-not-allowed'
                                    : 'bg-[#c30000] hover:bg-[#9e0000] text-white shadow-2xs cursor-pointer active:scale-[0.98]'
                                }`}
                              >
                                <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                                <span>{rpIsOut ? 'স্টক নেই' : language === 'bn' ? 'অর্ডার করুন' : 'Order Now'}</span>
                              </button>

                              {showAddToBagOnHomePage &&
                                (rpInCartQty === 0 ? (
                                  <button
                                    type="button"
                                    disabled={rpIsOut}
                                    onClick={() => addToCart(rp, 1, false, rpVar)}
                                    className="w-full min-h-[34px] py-1 px-2 bg-emerald-50/90 hover:bg-emerald-100 disabled:opacity-55 text-emerald-900 border border-emerald-200/90 font-bold text-[11px] rounded-xl flex items-center justify-center gap-1 transition-colors cursor-pointer disabled:cursor-not-allowed"
                                  >
                                    <Plus className="w-3.5 h-3.5 text-emerald-700" />
                                    <span>{language === 'bn' ? 'ব্যাগে যোগ করুন' : 'Add to Bag'}</span>
                                  </button>
                                ) : (
                                  <div className="w-full min-h-[34px] flex items-center justify-between bg-emerald-800 text-white rounded-xl px-1.5 py-0.5">
                                    <button
                                      type="button"
                                      onClick={() => addToCart(rp, -1, true, rpVar)}
                                      className="w-7 h-6 flex items-center justify-center rounded-lg hover:bg-emerald-700 cursor-pointer"
                                    >
                                      <Minus className="w-3.5 h-3.5" />
                                    </button>
                                    <span className="font-mono font-bold text-xs tabular-nums">
                                      {rpInCartQty} টি ব্যাগে
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => addToCart(rp, 1, true, rpVar)}
                                      className="w-7 h-6 flex items-center justify-center rounded-lg hover:bg-emerald-700 cursor-pointer"
                                    >
                                      <Plus className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Product Page Sticky/Floating Bottom "এখনই অর্ডার করুন" Button Bar (Hidden on Desktop by default via lg:hidden + 1-Click Desktop Hide or Full OFF) */}
                {isStorefrontFloatingBtnOn && (
                  <div
                    className={`${
                      isStorefrontFloatingHideOnDesktop ? 'lg:hidden ' : ''
                    }fixed bottom-3.5 left-3 right-3 z-40 pointer-events-none`}
                  >
                    <div className="max-w-md mx-auto pointer-events-auto">
                      {isAuthenticated && (
                        <div className="mb-1 flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              const nextHideDesktop = !isStorefrontFloatingHideOnDesktop;
                              updateBusiness({
                                storefrontFloatingBtnHideOnDesktop: nextHideDesktop
                              });
                              showToast(
                                nextHideDesktop
                                  ? 'ডেক্সটপ থেকে ফ্লোটিং বাটন হাইড করা হয়েছে (শুধু মোবাইলে দেখাবে)!'
                                  : 'ডেক্সটপ ও মোবাইল উভয় ভিউতে ফ্লোটিং বাটন চালু করা হয়েছে!',
                                'info'
                              );
                            }}
                            className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-indigo-700 text-white text-[10px] font-extrabold border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer"
                            title="ডেক্সটপ থেকে হাইড করুন অথবা ডেক্সটপেও দেখান"
                          >
                            <span>
                              {isStorefrontFloatingHideOnDesktop
                                ? '📱 শুধু মোবাইলে (ডেক্সটপে হাইড)'
                                : '💻 ডেক্সটপ থেকে হাইড করুন'}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              updateBusiness({ storefrontFloatingBtnEnabled: false });
                              showToast(
                                'প্রোডাক্ট পেজের ফ্লোটিং অর্ডার বাটন একদম বন্ধ (OFF) করা হয়েছে!',
                                'info'
                              );
                            }}
                            className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-rose-700 text-white text-[10px] font-extrabold border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer"
                            title="প্রোডাক্ট পেজের ফ্লোটিং বাটন একদম বন্ধ (OFF) করুন"
                          >
                            <X className="w-2.5 h-2.5 text-rose-300" />
                            <span>একদম OFF করুন</span>
                          </button>
                        </div>
                      )}
                      <div
                        className={
                          qvStock > 0 && sfIsBeamAnim ? `rounded-2xl ${sfWrapperAnimClass}` : ''
                        }
                      >
                        <button
                          type="button"
                          disabled={qvStock <= 0}
                          onClick={() =>
                            handleDirectOrderNow(quickViewProduct, quickViewQty, qvActiveVariant)
                          }
                          className={`w-full min-h-[50px] sm:min-h-[52px] py-3 sm:py-3.5 px-3.5 sm:px-5 font-extrabold text-[14px] min-[380px]:text-[15px] sm:text-lg rounded-2xl flex items-center justify-center gap-1.5 sm:gap-2 transition-all whitespace-nowrap ${
                            qvStock <= 0
                              ? 'sf-stock-out-btn bg-slate-200 text-slate-500 border border-slate-300 cursor-not-allowed shadow-md'
                              : `bg-[#c30000] hover:bg-[#9e0000] text-white shadow-xl cursor-pointer active:scale-[0.97] ${sfInnerAnimClass}`
                          }`}
                        >
                          <ShoppingBag className="w-4 h-4 min-[380px]:w-5 min-[380px]:h-5 shrink-0" />
                          <span className="tabular-nums whitespace-nowrap">
                            {qvStock <= 0
                              ? 'স্টক নেই'
                              : isStorefrontFloatingPriceOn
                              ? `এখনই অর্ডার করুন (৳${qvRetailPrice * quickViewQty})`
                              : 'এখনই অর্ডার করুন'}
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })()
        ) : isCustomerAccountOpen ? (
          /* SUB-PAGE E: Dedicated Full-Page Customer Login, Sign Up & Order History View */
          <div key="page-customer-account" className="max-w-3xl mx-auto space-y-4 animate-page-rise">
            {/* Top Back Bar */}
            <div className="flex items-center justify-between bg-white px-4 py-3 rounded-xl border border-slate-200/90 shadow-2xs">
              <button
                type="button"
                onClick={() => {
                  if (returnToCheckoutAfterAuth) {
                    setReturnToCheckoutAfterAuth(false);
                    setIsCustomerAccountOpen(false);
                    setIsCheckoutModalOpen(true);
                  } else {
                    closeAllSubPagesAndRestoreScroll();
                  }
                }}
                className="inline-flex items-center gap-2 text-xs sm:text-sm font-extrabold text-emerald-800 hover:text-emerald-950 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>
                  {returnToCheckoutAfterAuth
                    ? '← চেকআউট পেজে ফিরে যান'
                    : '← শপিংয়ে ফিরে যান'}
                </span>
              </button>
              <span className="text-xs font-bold text-slate-500">
                {currentCustomerAccount ? 'আমার একাউন্ট ও অর্ডার হিস্ট্রি' : 'কাস্টমার একাউন্ট'}
              </span>
            </div>

            {!currentCustomerAccount ? (
              /* Logged Out View: Smart Modern Login (Mobile + Password) & Sign Up (Name + Mobile + Address + Password) */
              (() => {
                const normLoginPhone = normalizeBdPhone(loginPhone);
                const matchedLoginAccount =
                  normLoginPhone.length === 11
                    ? customerAccounts.find(acc => normalizeBdPhone(acc.phone) === normLoginPhone)
                    : undefined;
                const normSignupPhone = normalizeBdPhone(signupPhone);
                const existingSignupAccount =
                  normSignupPhone.length === 11
                    ? customerAccounts.find(
                        acc => normalizeBdPhone(acc.phone) === normSignupPhone && Boolean(acc.password)
                      )
                    : undefined;

                return (
                  <div className="max-w-lg mx-auto bg-white rounded-3xl border border-emerald-200/80 shadow-sm overflow-hidden">
                    {/* Theme-Synced Top Header Accent Strip */}
                    <div className="sf-theme-topbar bg-gradient-to-r from-emerald-900 via-emerald-700 to-emerald-800 px-5 py-3.5 text-white flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        { customerAuthTab === 'signup' ? (
                          <UserPlus className="w-4 h-4 text-amber-300 shrink-0" />
                        ) : (
                          <LogIn className="w-4 h-4 text-amber-300 shrink-0" />
                        ) }
                        <span className="font-extrabold text-xs sm:text-sm tracking-wide">
                          {customerAuthTab === 'signup'
                            ? 'নতুন কাস্টমার একাউন্ট তৈরি করুন'
                            : customerAuthTab === 'forgot'
                            ? 'পাসওয়ার্ড রিসেট করুন'
                            : 'কাস্টমার একাউন্টে লগইন করুন'}
                        </span>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/15 text-emerald-50 border border-white/20">
                        {currentBusiness.name}
                      </span>
                    </div>

                    <div className="p-5 sm:p-7 space-y-5">
                      {/* Segmented Auth Mode Switcher Tabs (Synced with Storefront Theme!) */}
                      <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-emerald-50/70 rounded-2xl border border-emerald-200/70">
                        <button
                          type="button"
                          onClick={() => {
                            if (!loginPhone && signupPhone) setLoginPhone(signupPhone);
                            setCustomerAuthTab('login');
                            setForgotStep('request_otp');
                          }}
                          className={`py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            customerAuthTab === 'login' || customerAuthTab === 'forgot'
                              ? 'sf-theme-cart-btn bg-emerald-700 text-white shadow-xs'
                              : 'text-slate-600 hover:text-emerald-900 hover:bg-white/80'
                          }`}
                        >
                          <LogIn className="w-3.5 h-3.5" />
                          <span>লগইন করুন</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (!signupPhone && loginPhone) setSignupPhone(loginPhone);
                            setCustomerAuthTab('signup');
                            setForgotStep('request_otp');
                          }}
                          className={`py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            customerAuthTab === 'signup'
                              ? 'sf-theme-cart-btn bg-emerald-700 text-white shadow-xs'
                              : 'text-slate-600 hover:text-emerald-900 hover:bg-white/80'
                          }`}
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>নতুন একাউন্ট (সাইনআপ)</span>
                        </button>
                      </div>

                      {customerAuthTab === 'login' ? (
                        /* LOGIN FORM: Strictly Mobile Number + Password Only with Smart Live Detection */
                        <form onSubmit={handleCustomerLoginSubmit} className="space-y-4 text-xs">
                          <div>
                            <div className="flex items-center justify-between mb-1.5">
                              <label className="font-extrabold text-slate-800">
                                মোবাইল নম্বর <span className="text-rose-600">*</span>
                              </label>
                              {loginPhone.trim() && (
                                <span
                                  className={`text-[10px] font-mono font-extrabold px-2 py-0.5 rounded-full ${
                                    normLoginPhone.length === 11
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                                  }`}
                                >
                                  {normLoginPhone.length === 11
                                    ? '✓ ১১ ডিজিট সঠিক'
                                    : `${ loginPhone.replace(/\D/g, '').length }/১১ ডিজিট`}
                                </span>
                              )}
                            </div>
                            <div className="relative flex items-center">
                              <span className="absolute left-3 px-2 py-1 rounded-lg bg-slate-200/80 text-slate-700 font-mono font-extrabold text-[11px] pointer-events-none select-none">
                                +88
                              </span>
                              <input
                                type="tel"
                                required
                                value={loginPhone}
                                onChange={(e) => setLoginPhone(e.target.value)}
                                placeholder="017XXXXXXXX (১১ ডিজিট)"
                                className="w-full min-h-[46px] pl-14 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-bold text-sm text-slate-900 outline-hidden transition-all"
                              />
                            </div>

                            {/* Smart Account Recognition Hint */}
                            {matchedLoginAccount && (
                              <div className="mt-1.5 px-3 py-1.5 rounded-xl bg-emerald-50/90 border border-emerald-200 text-[11px] font-bold text-emerald-800 flex items-center justify-between">
                                <span className="flex items-center gap-1.5">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  <span>একাউন্ট পাওয়া গেছে: {matchedLoginAccount.name}</span>
                                </span>
                                <span className="text-[10px] text-emerald-600">পাসওয়ার্ড দিন</span>
                              </div>
                            )}
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1.5">
                              <label className="font-extrabold text-slate-800">
                                পাসওয়ার্ড <span className="text-rose-600">*</span>
                              </label>
                              {currentBusiness.smsForgotPasswordOtpEnabled !== false && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setForgotPhone(loginPhone);
                                    setForgotStep('request_otp');
                                    setCustomerAuthTab('forgot');
                                  }}
                                  className="text-[11px] font-extrabold text-emerald-700 hover:text-emerald-900 hover:underline cursor-pointer"
                                >
                                  পাসওয়ার্ড ভুলে গেছেন?
                                </button>
                              )}
                            </div>
                            <div className="relative flex items-center">
                              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                              <input
                                type={showLoginPass ? 'text' : 'password'}
                                required
                                value={loginPassword}
                                onChange={(e) => setLoginPassword(e.target.value)}
                                placeholder="আপনার পাসওয়ার্ড লিখুন"
                                className="w-full min-h-[46px] pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 font-medium outline-hidden transition-all"
                              />
                              <button
                                type="button"
                                onClick={() => setShowLoginPass(!showLoginPass)}
                                className="absolute right-3 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                                aria-label="Toggle password visibility"
                              >
                                {showLoginPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                              </button>
                            </div>
                          </div>

                          <button
                            type="submit"
                            className="btn-premium-shine btn-customer-login-glow sf-theme-cart-btn w-full min-h-[48px] py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm rounded-xl border border-emerald-400/40 shadow-md flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98]"
                          >
                            <LogIn className="w-4 h-4 text-amber-300" />
                            <span>লগইন করুন</span>
                          </button>

                          <div className="pt-2 border-t border-slate-100 text-center">
                            <p className="text-slate-500">
                              এখনও একাউন্ট খোলা হয়নি?{' '}
                              <button
                                type="button"
                                onClick={() => {
                                  if (!signupPhone && loginPhone) setSignupPhone(loginPhone);
                                  setCustomerAuthTab('signup');
                                }}
                                className="font-extrabold text-emerald-700 hover:text-emerald-900 hover:underline cursor-pointer ml-1"
                              >
                                নতুন একাউন্ট খুলুন →
                              </button>
                            </p>
                          </div>
                        </form>
                      ) : customerAuthTab === 'forgot' ? (
                        /* FORGOT PASSWORD FORM: Reset Password by Mobile Number + SMS OTP */
                        forgotStep === 'request_otp' ? (
                          <form onSubmit={handleForgotSendOtp} className="space-y-4 text-xs">
                            <div>
                              <label className="block font-extrabold text-slate-800 mb-1.5">
                                আপনার একাউন্টের মোবাইল নম্বর <span className="text-rose-600">*</span>
                              </label>
                              <div className="relative flex items-center">
                                <span className="absolute left-3 px-2 py-1 rounded-lg bg-slate-200/80 text-slate-700 font-mono font-extrabold text-[11px] pointer-events-none select-none">
                                  +88
                                </span>
                                <input
                                  type="tel"
                                  required
                                  value={forgotPhone}
                                  onChange={(e) => setForgotPhone(e.target.value)}
                                  placeholder="017XXXXXXXX (১১ ডিজিট)"
                                  className="w-full min-h-[46px] pl-14 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-bold text-sm text-slate-900 outline-hidden transition-colors"
                                />
                              </div>
                            </div>

                            <button
                              type="submit"
                              disabled={isSendingOtp}
                              className="sf-theme-cart-btn w-full min-h-[48px] py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-extrabold text-sm rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                            >
                              <KeyRound className="w-4 h-4" />
                              <span>
                                {isSendingOtp
                                  ? 'ভেরিফিকেশন SMS পাঠানো হচ্ছে...'
                                  : 'পাসওয়ার্ড রিসেট কোড পাঠান'}
                              </span>
                            </button>

                            <p className="text-center text-slate-500 pt-1">
                              পাসওয়ার্ড মনে পড়েছে?{' '}
                              <button
                                type="button"
                                onClick={() => setCustomerAuthTab('login')}
                                className="font-extrabold text-emerald-700 hover:underline cursor-pointer"
                              >
                                লগইন পেজে ফিরে যান
                              </button>
                            </p>
                          </form>
                        ) : (
                          <form onSubmit={handleForgotResetPasswordSubmit} className="space-y-4 text-xs">
                            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-[11px] font-semibold">
                              মোবাইল নম্বর: <span className="font-mono font-extrabold">{forgotPhone}</span>
                              {otpSentViaSms && (
                                <span className="block mt-0.5 text-emerald-700">
                                  আপনার মোবাইলে পাঠানো ৪-ডিজিটের OTP কোড এবং নতুন পাসওয়ার্ড লিখুন।
                                </span>
                              )}
                            </div>

                            {otpSentViaSms && (
                              <div>
                                <label className="block font-bold text-slate-800 mb-1">
                                  ভেরিফিকেশন কোড (OTP) <span className="text-rose-600">*</span>
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={forgotOtpInput}
                                  onChange={(e) => setForgotOtpInput(e.target.value)}
                                  placeholder="৪-ডিজিটের কোড লিখুন"
                                  className="w-full min-h-[46px] px-3.5 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-bold text-slate-900 outline-hidden transition-colors"
                                />
                              </div>
                            )}

                            <div>
                              <label className="block font-bold text-slate-800 mb-1">
                                নতুন পাসওয়ার্ড দিন <span className="text-rose-600">*</span>
                              </label>
                              <div className="relative flex items-center">
                                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                                <input
                                  type={showForgotPass ? 'text' : 'password'}
                                  required
                                  value={forgotNewPassword}
                                  onChange={(e) => setForgotNewPassword(e.target.value)}
                                  placeholder="কমপক্ষে ৪ অক্ষরের নতুন পাসওয়ার্ড"
                                  className="w-full min-h-[46px] pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden transition-colors"
                                />
                                <button
                                  type="button"
                                  onClick={() => setShowForgotPass(!showForgotPass)}
                                  className="absolute right-3 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                                >
                                  {showForgotPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                </button>
                              </div>
                            </div>

                            <button
                              type="submit"
                              className="sf-theme-cart-btn w-full min-h-[48px] py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>নতুন পাসওয়ার্ড সেভ করুন</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => setForgotStep('request_otp')}
                              className="w-full py-2 text-center font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                            >
                              ← মোবাইল নম্বর পরিবর্তন করুন
                            </button>
                          </form>
                        )
                      ) : signupStep === 'verify_otp' ? (
                        /* SIGN UP STEP 2: Mobile OTP Verification before creating customer account */
                        <form onSubmit={handleVerifySignupOtpSubmit} className="space-y-4 text-xs">
                          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 space-y-1">
                            <p className="font-extrabold text-xs flex items-center gap-1.5 text-emerald-800">
                              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span>মোবাইল নম্বর ভেরিফিকেশন (OTP)</span>
                            </p>
                            <p className="text-[11px] text-slate-700 leading-relaxed">
                              আপনার <span className="font-mono font-extrabold text-slate-900">{signupPhone}</span> নম্বরে পাঠানো ৪-ডিজিটের ভেরিফিকেশন কোডটি নিচে লিখুন।
                            </p>
                            {!signupOtpSentViaSms && signupGeneratedOtp && (
                              <div className="mt-2 p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px] flex items-center justify-between">
                                <span>ভেরিফিকেশন কোড (OTP):</span>
                                <span className="font-mono font-extrabold text-sm tracking-widest bg-white px-2.5 py-0.5 rounded border border-amber-300">
                                  {signupGeneratedOtp}
                                </span>
                              </div>
                            )}
                          </div>

                          <div>
                            <label className="block font-bold text-slate-800 mb-1">
                              ৪-ডিজিটের ভেরিফিকেশন কোড (OTP) <span className="text-rose-600">*</span>
                            </label>
                            <input
                              type="text"
                              required
                              maxLength={6}
                              value={signupOtpInput}
                              onChange={(e) => setSignupOtpInput(e.target.value)}
                              placeholder="এখানে ৪-ডিজিট OTP কোড লিখুন"
                              className="w-full min-h-[46px] px-4 py-2.5 bg-slate-50 border-2 border-emerald-500/70 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-extrabold text-base tracking-widest text-center text-slate-900 outline-hidden transition-colors"
                            />
                          </div>

                          <button
                            type="submit"
                            className="sf-theme-cart-btn w-full min-h-[48px] py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-[0.98]"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>ওটিপি যাচাই ও একাউন্ট তৈরি করুন</span>
                          </button>

                          <div className="flex items-center justify-between pt-1 text-[11px]">
                            <button
                              type="button"
                              onClick={() => setSignupStep('form')}
                              className="font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                            >
                              ← তথ্য পরিবর্তন করুন
                            </button>

                            <button
                              type="button"
                              disabled={isSendingSignupOtp}
                              onClick={() => sendSignupVerificationOtp(signupName.trim(), signupPhone.trim())}
                              className="font-extrabold text-emerald-700 hover:text-emerald-900 hover:underline cursor-pointer disabled:opacity-50"
                            >
                              {isSendingSignupOtp ? 'পাঠানো হচ্ছে...' : 'আবার কোড পাঠান (Resend OTP)'}
                            </button>
                          </div>
                        </form>
                      ) : (
                        /* SIGN UP FORM: Name + Mobile Number + Address + Password with Smart Validation */
                        <form onSubmit={handleCustomerSignupSubmit} className="space-y-3.5 text-xs">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                            <div>
                              <label className="block font-extrabold text-slate-800 mb-1.5">
                                আপনার নাম <span className="text-rose-600">*</span>
                              </label>
                              <div className="relative flex items-center">
                                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                                <input
                                  type="text"
                                  required
                                  value={signupName}
                                  onChange={(e) => setSignupName(e.target.value)}
                                  placeholder="আপনার পূর্ণ নাম"
                                  className="w-full min-h-[46px] pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 font-medium outline-hidden transition-colors"
                                />
                              </div>
                            </div>

                            <div>
                              <div className="flex items-center justify-between mb-1.5">
                                <label className="font-extrabold text-slate-800">
                                  মোবাইল নম্বর <span className="text-rose-600">*</span>
                                </label>
                                {signupPhone.trim() && (
                                  <span
                                    className={`text-[10px] font-mono font-extrabold px-2 py-0.5 rounded-full ${
                                      normSignupPhone.length === 11
                                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                                    }`}
                                  >
                                    {normSignupPhone.length === 11
                                      ? '✓ ১১ ডিজিট'
                                      : `${signupPhone.replace(/\D/g, '').length}/১১`}
                                  </span>
                                )}
                              </div>
                              <div className="relative flex items-center">
                                <span className="absolute left-2.5 px-1.5 py-0.5 rounded-md bg-slate-200/80 text-slate-700 font-mono font-extrabold text-[10px] pointer-events-none select-none">
                                  +88
                                </span>
                                <input
                                  type="tel"
                                  required
                                  value={signupPhone}
                                  onChange={(e) => setSignupPhone(e.target.value)}
                                  placeholder="017XXXXXXXX"
                                  className="w-full min-h-[46px] pl-12 pr-3 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono font-bold text-slate-900 outline-hidden transition-colors"
                                />
                              </div>
                            </div>
                          </div>

                          {existingSignupAccount && (
                            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-[11px] flex items-center justify-between gap-2">
                              <span>এই নম্বরে আগেই একাউন্ট খোলা আছে ({existingSignupAccount.name})</span>
                              <button
                                type="button"
                                onClick={() => {
                                  setLoginPhone(normSignupPhone);
                                  setCustomerAuthTab('login');
                                }}
                                className="px-2.5 py-1 rounded-lg bg-emerald-700 text-white font-extrabold text-[10px] shrink-0 cursor-pointer"
                              >
                                লগইন করুন
                              </button>
                            </div>
                          )}

                          <div>
                            <label className="block font-extrabold text-slate-800 mb-1.5">
                              ডেলিভারি ঠিকানা <span className="text-rose-600">*</span>
                            </label>
                            <div className="relative flex items-center">
                              <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                              <input
                                type="text"
                                required
                                value={signupAddress}
                                onChange={(e) => setSignupAddress(e.target.value)}
                                placeholder="বাসা নং, রোড নং, এলাকা ও জেলা লিখুন"
                                className="w-full min-h-[46px] pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden transition-colors"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block font-extrabold text-slate-800 mb-1.5">
                              পাসওয়ার্ড সেট করুন <span className="text-rose-600">*</span>
                            </label>
                            <div className="relative flex items-center">
                              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                              <input
                                type={showSignupPass ? 'text' : 'password'}
                                required
                                value={signupPassword}
                                onChange={(e) => setSignupPassword(e.target.value)}
                                placeholder="কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন"
                                className="w-full min-h-[46px] pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-slate-900 outline-hidden transition-colors"
                              />
                              <button
                                type="button"
                                onClick={() => setShowSignupPass(!showSignupPass)}
                                className="absolute right-3 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                                aria-label="Toggle password visibility"
                              >
                                {showSignupPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                              </button>
                            </div>
                          </div>

                          <button
                            type="submit"
                            disabled={isSendingSignupOtp}
                            className="btn-premium-shine sf-theme-cart-btn w-full min-h-[48px] py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-extrabold text-sm rounded-xl border border-emerald-400/40 shadow-md flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98]"
                          >
                            <UserPlus className="w-4 h-4 text-amber-200" />
                            <span>
                              {isSendingSignupOtp
                                ? 'ভেরিফিকেশন কোড পাঠানো হচ্ছে...'
                                : Boolean(currentBusiness.signupOtpRequired)
                                ? 'ওটিপি কোড পাঠান ও একাউন্ট খুলুন'
                                : 'একাউন্ট তৈরি করুন'}
                            </span>
                          </button>

                          <div className="pt-2 border-t border-slate-100 text-center">
                            <p className="text-slate-500">
                              আগে থেকেই একাউন্ট আছে?{' '}
                              <button
                                type="button"
                                onClick={() => {
                                  if (!loginPhone && signupPhone) setLoginPhone(signupPhone);
                                  setCustomerAuthTab('login');
                                }}
                                className="font-extrabold text-emerald-700 hover:underline cursor-pointer ml-1"
                              >
                                লগইন করুন →
                              </button>
                            </p>
                          </div>
                        </form>
                      )}
                    </div>
                  </div>
                );
              })()
            ) : (
              /* Logged In View: Customer Profile Card + Full Order History */
              <div className="space-y-4">
                {/* Customer Profile & Saved Delivery Info Card */}
                <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-4 sm:p-6 space-y-4">
                  <div className="flex flex-wrap items-start justify-between gap-3 pb-3.5 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-white font-extrabold text-lg flex items-center justify-center shrink-0 shadow-xs">
                        {currentCustomerAccount.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                            {currentCustomerAccount.name}
                          </h2>
                          <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                            ভেরিফাইড কাস্টমার
                          </span>
                        </div>
                        <p className="text-xs font-mono font-bold text-emerald-700 mt-0.5">
                          মোবাইল: {currentCustomerAccount.phone}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setIsEditingCustomerProfile(!isEditingCustomerProfile)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>{isEditingCustomerProfile ? 'বাতিল' : 'ঠিকানা পরিবর্তন'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleCustomerLogout}
                        className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/70 font-bold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>লগআউট</span>
                      </button>
                    </div>
                  </div>

                  {isEditingCustomerProfile ? (
                    <form onSubmit={handleCustomerProfileSave} className="space-y-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">আপনার নাম</label>
                          <input
                            type="text"
                            required
                            value={editProfileName}
                            onChange={(e) => setEditProfileName(e.target.value)}
                            className="w-full min-h-[40px] px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 font-medium outline-hidden"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">ডেলিভারি ঠিকানা</label>
                          <input
                            type="text"
                            required
                            value={editProfileAddress}
                            onChange={(e) => setEditProfileAddress(e.target.value)}
                            className="w-full min-h-[40px] px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 outline-hidden"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl cursor-pointer"
                        >
                          সংরক্ষণ করুন
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="sm:col-span-2 p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-2.5">
                        <MapPin className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[11px] text-slate-400 font-semibold block">
                            ডিফল্ট ডেলিভারি ঠিকানা:
                          </span>
                          <p className="font-bold text-slate-800 mt-0.5">
                            {currentCustomerAccount.address}
                          </p>
                        </div>
                      </div>

                      <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80 flex items-center justify-between">
                        <div>
                          <span className="text-[11px] text-emerald-800 font-semibold block">
                            মোট অর্ডার সংখ্যা
                          </span>
                          <p className="font-mono font-extrabold text-lg text-emerald-900">
                            {customerOrderHistory.length} টি
                          </p>
                        </div>
                        <ShoppingBag className="w-6 h-6 text-emerald-700/70" />
                      </div>
                    </div>
                  )}
                </div>

                {/* Customer Order History Section */}
                <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-4 sm:p-6 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div>
                      <h3 className="font-extrabold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                        <PackageCheck className="w-4.5 h-4.5 text-emerald-700" />
                        <span>আমার অর্ডার হিস্ট্রি ({customerOrderHistory.length})</span>
                      </h3>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        আপনার মোবাইল নম্বরে করা সকল অর্ডারের তালিকা ও বর্তমান ডেলিভারি স্ট্যাটাস
                      </p>
                    </div>
                  </div>

                  {customerOrderHistory.length === 0 ? (
                    <div className="p-8 text-center space-y-3 bg-slate-50/60 rounded-2xl border border-dashed border-slate-200">
                      <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-xs sm:text-sm font-bold text-slate-700">
                        আপনার একাউন্টে এখনও কোনো অর্ডার নেই
                      </p>
                      <button
                        type="button"
                        onClick={closeAllSubPagesAndRestoreScroll}
                        className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold rounded-xl cursor-pointer"
                      >
                        পণ্য পছন্দ করতে শপিংয়ে যান
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {customerOrderHistory.map(ord => {
                        const steps = [
                          { key: 'pending', label: 'অর্ডার গৃহীত' },
                          { key: 'confirmed', label: 'কনফার্মড' },
                          { key: 'packaging', label: 'প্যাকিং চলছে' },
                          { key: 'dispatched', label: 'ডেলিভারি পথে' },
                          { key: 'delivered', label: 'ডেলিভারি সম্পন্ন' }
                        ];
                        const currentStepIdx = steps.findIndex(s => s.key === ord.orderStatus);

                        return (
                          <div
                            key={ord.id}
                            className="p-4 sm:p-5 rounded-2xl border border-slate-200/90 hover:border-emerald-300 bg-slate-50/60 text-xs space-y-3.5 transition-colors"
                          >
                            {/* Order Top Header */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-200/80">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-extrabold text-sm sm:text-base text-emerald-800">
                                    {ord.orderNo}
                                  </span>
                                  <span className="text-[11px] font-mono text-slate-400">
                                    ({ord.invoiceNo})
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-500 mt-0.5">
                                  অর্ডারের তারিখ: {formatDate(ord.createdAt)} · ক্যাশ অন ডেলিভারি
                                </p>
                              </div>

                              <div className="flex items-center gap-2.5">
                                <div className="text-right">
                                  <span className="text-[10px] text-slate-400 block">সর্বমোট বিল</span>
                                  <span className="font-mono font-extrabold text-sm sm:text-base text-slate-900">
                                    {formatCurrency(ord.grandTotal)}
                                  </span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleReorderFromHistory(ord)}
                                  className="px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-[11px] inline-flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                  <span>পুনরায় অর্ডার</span>
                                </button>
                              </div>
                            </div>

                            {/* Live 5-Step Progress Bar */}
                            {ord.orderStatus === 'cancelled' ? (
                              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 font-extrabold text-xs text-center">
                                এই অর্ডারটি বাতিল (Cancelled) করা হয়েছে
                              </div>
                            ) : (
                              <div className="grid grid-cols-5 gap-1.5 pt-0.5">
                                {steps.map((st, idx) => {
                                  const isCompleted = currentStepIdx >= idx;
                                  const isCurrent = currentStepIdx === idx;
                                  return (
                                    <div key={st.key} className="text-center space-y-1">
                                      <div
                                        className={`h-2 rounded-full transition-all ${
                                          isCompleted ? 'bg-emerald-600' : 'bg-slate-200'
                                        }`}
                                      />
                                      <p
                                        className={`text-[10px] sm:text-[11px] leading-tight ${
                                          isCurrent
                                            ? 'font-extrabold text-emerald-800'
                                            : isCompleted
                                            ? 'font-bold text-slate-700'
                                            : 'font-medium text-slate-400'
                                        }`}
                                      >
                                        {st.label}
                                      </p>
                                    </div>
                                  );
                                })}
                              </div>
                            )}

                            {/* Ordered Items List + Customer Review Submission from Order History */}
                            {ord.items && ord.items.length > 0 && (
                              <div className="bg-white p-3 rounded-xl border border-slate-200/80 space-y-2">
                                <input
                                  ref={orderHistoryReviewerAvatarInputRef}
                                  type="file"
                                  accept="image/*"
                                  onChange={handleOrderHistoryReviewAvatarUpload}
                                  className="hidden"
                                />
                                <p className="text-[11px] font-bold text-slate-500">অর্ডারকৃত পণ্যসমূহ ও রিভিউ:</p>
                                {ord.items.map((item, idx) => {
                                  const matchedProd = products.find(
                                    p =>
                                      p.id === item.productId ||
                                      p.nameBn === item.productName ||
                                      p.nameEn === item.productName
                                  );
                                  const itemRevKey = `${ord.id}_${item.productId || idx}`;
                                  const isWritingThisItemReview = orderReviewTargetKey === itemRevKey;

                                  return (
                                    <div
                                      key={idx}
                                      className="py-1.5 border-b border-slate-100 last:border-b-0 space-y-2"
                                    >
                                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-700">
                                        <span className="font-semibold text-slate-800">
                                          {item.productName} × {item.quantity}
                                        </span>
                                        <div className="flex items-center gap-2 ml-auto">
                                          <span className="font-mono font-semibold text-slate-900">
                                            {formatCurrency(item.total)}
                                          </span>
                                          {matchedProd && ord.orderStatus !== 'cancelled' && (
                                            <button
                                              type="button"
                                              onClick={() => {
                                                if (isWritingThisItemReview) {
                                                  setOrderReviewTargetKey(null);
                                                } else {
                                                  setOrderReviewTargetKey(itemRevKey);
                                                  setOrderReviewRating(5);
                                                  setOrderReviewComment('');
                                                  setOrderReviewAvatar('');
                                                }
                                              }}
                                              className="px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-extrabold text-[11px] inline-flex items-center gap-1 cursor-pointer transition-colors"
                                            >
                                              <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                                              <span>
                                                {isWritingThisItemReview ? 'বন্ধ করুন' : 'রিভিউ দিন'}
                                              </span>
                                            </button>
                                          )}
                                        </div>
                                      </div>

                                      {isWritingThisItemReview && matchedProd && (
                                        <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2.5 animate-page-rise">
                                          <div className="flex flex-wrap items-center justify-between gap-2">
                                            <p className="text-[11px] font-extrabold text-amber-950">
                                              ✍️ &ldquo;{matchedProd.nameBn || matchedProd.nameEn}&rdquo; পণ্যের রিভিউ লিখুন:
                                            </p>
                                            <select
                                              value={orderReviewRating}
                                              onChange={e =>
                                                setOrderReviewRating(Number(e.target.value) || 5)
                                              }
                                              className="px-2.5 py-1 bg-white border border-amber-300 rounded-lg text-[11px] font-extrabold text-amber-800"
                                            >
                                              <option value={5}>⭐⭐⭐⭐⭐ (৫ স্টার - অসাধারণ)</option>
                                              <option value={4}>⭐⭐⭐⭐ (৪ স্টার - খুব ভালো)</option>
                                              <option value={3}>⭐⭐⭐ (৩ স্টার - ভালো)</option>
                                              <option value={2}>⭐⭐ (২ স্টার - মোটামুটি)</option>
                                              <option value={1}>⭐ (১ স্টার)</option>
                                            </select>
                                          </div>

                                          <div className="flex items-center gap-2.5">
                                            {orderReviewAvatar ? (
                                              <div className="relative shrink-0">
                                                <img
                                                  src={orderReviewAvatar}
                                                  alt="Preview"
                                                  className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500"
                                                />
                                                <button
                                                  type="button"
                                                  onClick={() => setOrderReviewAvatar('')}
                                                  className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                                >
                                                  ×
                                                </button>
                                              </div>
                                            ) : (
                                              <div className="w-10 h-10 rounded-full bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center shrink-0">
                                                {(
                                                  currentCustomerAccount?.name ||
                                                  ord.customerName ||
                                                  'ক'
                                                )
                                                  .trim()
                                                  .slice(0, 1)}
                                              </div>
                                            )}
                                            <button
                                              type="button"
                                              disabled={isUploadingOrderReviewAvatar}
                                              onClick={() =>
                                                orderHistoryReviewerAvatarInputRef.current?.click()
                                              }
                                              className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-extrabold inline-flex items-center gap-1 cursor-pointer"
                                            >
                                              <Upload className="w-3 h-3" />
                                              <span>
                                                {orderReviewAvatar ? 'ছবি পরিবর্তন' : '📷 ছবি দিন'}
                                              </span>
                                            </button>
                                          </div>

                                          <textarea
                                            rows={2}
                                            value={orderReviewComment}
                                            onChange={e => setOrderReviewComment(e.target.value)}
                                            placeholder="পণ্যটি আপনার কেমন লেগেছে তা এখানে লিখুন..."
                                            className="w-full p-2.5 bg-white border border-amber-300 rounded-xl text-xs"
                                          />

                                          <div className="flex justify-end gap-2">
                                            <button
                                              type="button"
                                              onClick={() => setOrderReviewTargetKey(null)}
                                              className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-[11px] font-bold text-slate-700 cursor-pointer"
                                            >
                                              বাতিল
                                            </button>
                                            <button
                                              type="button"
                                              onClick={async () => {
                                                if (!orderReviewComment.trim()) {
                                                  showToast('অনুগ্রহ করে আপনার মতামত বা কমেন্ট লিখুন!', 'error');
                                                  return;
                                                }
                                                const existingRevs = Array.isArray(
                                                  matchedProd.landingReviewItems
                                                )
                                                  ? matchedProd.landingReviewItems.map(r => ({
                                                      ...r
                                                    }))
                                                  : [];
                                                const newCustomerRev: LandingReviewItem = {
                                                  id: `rev_${Date.now()}_${Math.random()
                                                    .toString(36)
                                                    .slice(2, 5)}`,
                                                  customerName:
                                                    currentCustomerAccount?.name?.trim() ||
                                                    ord.customerName?.trim() ||
                                                    'ভেরিফাইড ক্রেতা',
                                                  location:
                                                    currentCustomerAccount?.address?.trim() ||
                                                    ord.deliveryAddress?.trim() ||
                                                    'ঢাকা',
                                                  rating: orderReviewRating,
                                                  comment: orderReviewComment.trim(),
                                                  avatarUrl: orderReviewAvatar || undefined,
                                                  status: 'pending',
                                                  submittedBy: 'customer',
                                                  createdAt: new Date().toISOString()
                                                };
                                                const updatedList = [
                                                  newCustomerRev,
                                                  ...existingRevs
                                                ];
                                                await updateProduct(matchedProd.id, {
                                                  landingReviewsEnabled: true,
                                                  landingReviewItems: updatedList
                                                });
                                                setOrderReviewTargetKey(null);
                                                setOrderReviewComment('');
                                                setOrderReviewAvatar('');
                                                showToast(
                                                  'ধন্যবাদ! আপনার রিভিউটি সফলভাবে জমা হয়েছে।',
                                                  'success'
                                                );
                                              }}
                                              className="px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-extrabold cursor-pointer shadow-2xs"
                                            >
                                              রিভিউ জমা দিন
                                            </button>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                                {ord.discountAmount > 0 && (
                                  <div className="flex justify-between text-xs text-emerald-700 font-bold pt-1 border-t border-slate-100">
                                    <span>ডিসকাউন্ট ছাড়:</span>
                                    <span className="font-mono">- {formatCurrency(ord.discountAmount)}</span>
                                  </div>
                                )}
                                <div className="flex justify-between text-xs text-slate-600 pt-1 border-t border-slate-100">
                                  <span>ডেলিভারি চার্জ:</span>
                                  <span className="font-mono font-bold">
                                    {ord.deliveryCharge === 0
                                      ? 'ফ্রি ডেলিভারি (৳০)'
                                      : formatCurrency(ord.deliveryCharge)}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          <>
        {/* Clean Product-Only Homepage Grid (All Banners, Category Bars & Filter Boxes Removed) */}
        <section
          id="dokanghor-products"
          className="space-y-3 sm:space-y-4 animate-page-rise"
        >
          {/* Admin Quick Bar on Home Page for Independent "মাত্র ৫ টি বাকি" Front Box ON/OFF Control */}
          {isAuthenticated && (
            <div className="bg-white rounded-2xl border border-emerald-200/90 px-3.5 py-2.5 shadow-2xs flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-[#c30000] fill-[#c30000] shrink-0" />
                <span>অ্যাডমিন হোমপেজ কার্ড কন্ট্রোল (আলাদা ON/OFF):</span>
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const curHome = currentBusiness.homePageScarcityStockEnabled !== false;
                    const nextHome = !curHome;
                    updateBusiness({ homePageScarcityStockEnabled: nextHome });
                    showToast(
                      nextHome
                        ? 'হোমপেজে প্রোডাক্ট বক্সে "মাত্র ৫ টি বাকি" দেখানো চালু (ON) করা হয়েছে!'
                        : 'হোমপেজে প্রোডাক্ট বক্সে "মাত্র ৫ টি বাকি" বন্ধ (OFF) করা হয়েছে! (ভিতরের প্রোডাক্ট পেজের স্টক অ্যালার্ট আলাদা থাকবে)',
                      nextHome ? 'success' : 'info'
                    );
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer flex items-center gap-1.5 ${
                    currentBusiness.homePageScarcityStockEnabled !== false
                      ? 'bg-rose-600 text-white border-rose-700 shadow-2xs'
                      : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                  }`}
                  title="হোমপেজের প্রোডাক্ট বক্সে 'মাত্র ৫ টি বাকি' লেখাটি আলাদাভাবে ON / OFF করুন"
                >
                  <span>
                    হোমপেজ বক্সে "মাত্র ৫ টি বাকি":{' '}
                    {currentBusiness.homePageScarcityStockEnabled !== false ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const curInner = currentBusiness.scarcityStockEnabled !== false;
                    const nextInner = !curInner;
                    updateBusiness({ scarcityStockEnabled: nextInner });
                    showToast(
                      nextInner
                        ? 'ভিতরের প্রোডাক্ট পেজে স্টক অ্যালার্ট চালু (ON) করা হয়েছে!'
                        : 'ভিতরের প্রোডাক্ট পেজে স্টক অ্যালার্ট বন্ধ (OFF) করা হয়েছে!',
                      nextInner ? 'success' : 'info'
                    );
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer flex items-center gap-1.5 ${
                    currentBusiness.scarcityStockEnabled !== false
                      ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                      : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                  }`}
                  title="ভিতরের প্রোডাক্ট পেজে স্টক অ্যালার্ট আলাদাভাবে ON / OFF করুন"
                >
                  <span>
                    ভিতরের প্রোডাক্ট পেজে স্টক:{' '}
                    {currentBusiness.scarcityStockEnabled !== false ? 'ON' : 'OFF'}
                  </span>
                </button>

                {/* 1-Click Stock Out Image Overlay Style Switcher on Home Page */}
                <button
                  type="button"
                  onClick={() => {
                    const curIdx = stockOutStyleOptions.findIndex(
                      o => o.id === stockOutBadgeStyle
                    );
                    const nextOpt =
                      stockOutStyleOptions[(curIdx + 1) % stockOutStyleOptions.length];
                    updateBusiness({ stockOutBadgeStyle: nextOpt.id });
                    showToast(
                      `ছবির ওপর স্টক শেষ স্টাইল: "${nextOpt.label}" সেট করা হয়েছে!`,
                      'success'
                    );
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-slate-700 text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5"
                  title="প্রোডাক্ট ছবির ওপর 'স্টক শেষ' দেখানোর ডিজাইন পরিবর্তন করুন (স্মার্ট ওভারলে অথবা আগের ক্লাসিক ব্যাজ)"
                >
                  <span>
                    🚫 স্টক আউট ভিউ:{' '}
                    {
                      (
                        stockOutStyleOptions.find(o => o.id === stockOutBadgeStyle) ||
                        stockOutStyleOptions[0]
                      ).shortLabel
                    }
                  </span>
                </button>

                {/* 1-Click Quantity-Based Free Delivery ("2 পিস / 3 পিস কিনলে ডেলিভারি ফ্রি") Switcher on Home Page */}
                <div className="inline-flex items-center gap-1 bg-emerald-50 border border-emerald-200 rounded-xl p-1">
                  <span className="text-[11px] font-extrabold text-emerald-950 px-1.5">
                    🚚 ফ্রি ডেলিভারি অফার:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      updateBusiness({ freeDeliveryByQtyEnabled: false });
                      showToast('পিস হিসেবে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে', 'info');
                    }}
                    className={`px-2 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer transition-colors ${
                      !isQtyFreeDeliveryEnabled
                        ? 'bg-slate-800 text-white'
                        : 'text-slate-600 hover:bg-white'
                    }`}
                  >
                    OFF
                  </button>
                  {[2, 3].map(qtyOpt => {
                    const isSel = isQtyFreeDeliveryEnabled && freeDeliveryMinQty === qtyOpt;
                    return (
                      <button
                        key={qtyOpt}
                        type="button"
                        onClick={() => {
                          updateBusiness({
                            freeDeliveryByQtyEnabled: true,
                            freeDeliveryMinQty: qtyOpt,
                            landingFreeDeliveryByQtyEnabled: true,
                            landingFreeDeliveryMinQty: qtyOpt
                          });
                          showToast(
                            `"${toBanglaCountdownDigits(qtyOpt, 1)} পিস কিনলে ডেলিভারি ফ্রি" অফার চালু (ON) করা হয়েছে!`,
                            'success'
                          );
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer transition-colors ${
                          isSel
                            ? 'bg-emerald-700 text-white shadow-2xs'
                            : 'text-emerald-900 hover:bg-white'
                        }`}
                      >
                        {toBanglaCountdownDigits(qtyOpt, 1)} পিসে ফ্রি
                      </button>
                    );
                  })}
                </div>

                {/* 1-Click Storefront Color Theme & Seasonal Theme Quick Selector on Home Page */}
                <div className="inline-flex flex-wrap items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl p-1">
                  <button
                    type="button"
                    onClick={() => {
                      const nextWinter = !isWinterTheme;
                      updateBusiness({
                        winterThemeEnabled: nextWinter,
                        storefrontTheme: nextWinter ? 'winter_frost' : 'emerald_default',
                        ...(nextWinter ? { winterSnowfallEnabled: true } : {})
                      });
                      showToast(
                        nextWinter
                          ? '❄️ Winter Theme (Cool Blues & Snowy Whites) চালু করা হয়েছে!'
                          : 'Winter Theme বন্ধ করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextWinter ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      isWinterTheme
                        ? 'bg-sky-600 text-white border-sky-700 shadow-2xs'
                        : 'bg-white text-sky-900 border-sky-300 hover:bg-sky-50'
                    }`}
                    title="Toggle Winter Theme ON / OFF"
                  >
                    <span>❄️ Winter: {isWinterTheme ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isSummer = activeStorefrontTheme === 'summer_mango';
                      const nextSummer = !isSummer;
                      updateBusiness({
                        winterThemeEnabled: false,
                        storefrontTheme: nextSummer ? 'summer_mango' : 'emerald_default',
                        ...(nextSummer ? { winterSnowfallEnabled: true } : { winterSnowfallEnabled: false })
                      });
                      showToast(
                        nextSummer
                          ? '☀️ Summer Theme (সামার সানশাইন ও ট্রপিক্যাল ম্যাঙ্গো) চালু করা হয়েছে!'
                          : 'Summer Theme বন্ধ করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextSummer ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      activeStorefrontTheme === 'summer_mango'
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-2xs'
                        : 'bg-white text-amber-900 border-amber-300 hover:bg-amber-50'
                    }`}
                    title="১-ক্লিকে Summer Theme ON / OFF করুন"
                  >
                    <span>☀️ Summer: {activeStorefrontTheme === 'summer_mango' ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isRamadan = activeStorefrontTheme === 'ramadan_noor';
                      const nextRamadan = !isRamadan;
                      updateBusiness({
                        winterThemeEnabled: false,
                        storefrontTheme: nextRamadan ? 'ramadan_noor' : 'emerald_default',
                        ...(nextRamadan ? { winterSnowfallEnabled: true } : { winterSnowfallEnabled: false })
                      });
                      showToast(
                        nextRamadan
                          ? '🌙 Ramadan Theme (পবিত্র মাহে রমজান নূর ও গোল্ড) চালু করা হয়েছে!'
                          : 'Ramadan Theme বন্ধ করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextRamadan ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      activeStorefrontTheme === 'ramadan_noor'
                        ? 'bg-emerald-800 text-amber-200 border-emerald-900 shadow-2xs'
                        : 'bg-white text-emerald-950 border-emerald-300 hover:bg-emerald-50'
                    }`}
                    title="১-ক্লিকে Ramadan Theme ON / OFF করুন"
                  >
                    <span>🌙 Ramadan: {activeStorefrontTheme === 'ramadan_noor' ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isEid = activeStorefrontTheme === 'eid_festive';
                      const nextEid = !isEid;
                      updateBusiness({
                        winterThemeEnabled: false,
                        storefrontTheme: nextEid ? 'eid_festive' : 'emerald_default',
                        ...(nextEid ? { winterSnowfallEnabled: true } : { winterSnowfallEnabled: false })
                      });
                      showToast(
                        nextEid
                          ? '🕌 Eid Vacation Theme (ঈদ উৎসব ও ভ্যাকেশন স্পেশাল) চালু করা হয়েছে!'
                          : 'Eid Vacation Theme বন্ধ করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                        nextEid ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      activeStorefrontTheme === 'eid_festive'
                        ? 'bg-pink-700 text-amber-100 border-pink-800 shadow-2xs'
                        : 'bg-white text-pink-900 border-pink-300 hover:bg-pink-50'
                    }`}
                    title="১-ক্লিকে Eid Vacation Theme ON / OFF করুন"
                  >
                    <span>🕌 Eid Theme: {activeStorefrontTheme === 'eid_festive' ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (isSnowfallEnabled && isSnowAutoStopped) {
                        setIsSnowAutoStopped(false);
                        setSnowReplaySeed(prev => prev + 1);
                        showToast(
                          `🌨️ তুষারপাত অ্যানিমেশন আবার চালু হয়েছে (${snowfallAutoOffSec} সেকেন্ড পর অটো বন্ধ হবে)!`,
                          'info'
                        );
                        return;
                      }
                      const nextSnow = !isSnowfallEnabled;
                      updateBusiness({
                        winterSnowfallEnabled: nextSnow
                      });
                      showToast(
                        nextSnow
                          ? '🌨️ তুষারপাত অ্যানিমেশন (Falling Snow) চালু (ON) করা হয়েছে!'
                          : 'তুষারপাত অ্যানিমেশন (Falling Snow) বন্ধ (OFF) করা হয়েছে।',
                        nextSnow ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      isSnowfallEnabled
                        ? isSnowAutoStopped
                          ? 'bg-sky-100 text-sky-900 border-sky-300 hover:bg-sky-200'
                          : 'bg-cyan-600 text-white border-cyan-700 shadow-2xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                    title="Toggle Subtle Falling Snow Animation ON / OFF (or Replay if Auto-Stopped)"
                  >
                    <span>
                      {isSnowfallEnabled
                        ? isSnowAutoStopped
                          ? `🌨️ Snowfall: Auto-Stopped (${snowfallAutoOffSec}s) · 🔄 Replay`
                          : `🌨️ Snowfall: ON (${snowfallIntensity}%${snowfallAutoOffSec > 0 ? ` · ${snowfallAutoOffSec}s` : ''})`
                        : '🌨️ Snowfall: OFF'}
                    </span>
                  </button>

                  {/* 1-Click Order Success Celebration ON/OFF + 4-Style Switcher + Center Badge Toggle + Live Test */}
                  <button
                    type="button"
                    onClick={() => {
                      const nextConfetti = !isOrderConfettiEnabled;
                      updateBusiness({
                        storefrontOrderConfettiEnabled: nextConfetti
                      });
                      if (nextConfetti) {
                        triggerOrderSuccessConfetti();
                      }
                      showToast(
                        nextConfetti
                          ? '🎉 অর্ডার কনফার্ম সেলিব্রেশন অ্যানিমেশন চালু (ON) করা হয়েছে!'
                          : 'অর্ডার কনফার্ম সেলিব্রেশন অ্যানিমেশন বন্ধ (OFF) করা হয়েছে।',
                        nextConfetti ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      isOrderConfettiEnabled
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-2xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                    title="কাস্টমার অর্ডার কনফার্ম করলে প্রিমিয়াম সেলিব্রেশন অ্যানিমেশন ON / OFF করুন"
                  >
                    <span>🎉 Celebration: {isOrderConfettiEnabled ? 'ON' : 'OFF'}</span>
                  </button>

                  <select
                    value={orderCelebrationStyle}
                    onChange={(e) => {
                      const nextStyle = e.target.value as OrderCelebrationStyle;
                      updateBusiness({
                        storefrontOrderConfettiEnabled: true,
                        storefrontOrderConfettiStyle: nextStyle
                      });
                      setTimeout(() => triggerOrderSuccessConfetti(), 30);
                      showToast('✨ নতুন সেলিব্রেশন অ্যানিমেশন স্টাইল সেট ও টেস্ট করা হচ্ছে!', 'success');
                    }}
                    className="px-2 py-1 rounded-lg bg-white border border-amber-300 text-[11px] font-extrabold text-slate-800 cursor-pointer outline-hidden"
                    title="৬টি প্রিমিয়াম সেলিব্রেশন ডিজাইন থেকে পছন্দেরটি বেছে নিন"
                  >
                    <option value="dual_cannon_badge">🎊 ১. ডাবল পার্টি ক্যানন (Default)</option>
                    <option value="royal_fireworks">🎆 ২. রয়্যাল আতশবাজি (Fireworks)</option>
                    <option value="luxury_gold_fountain">✨ ৩. ২৪-ক্যারেট গোল্ড ফাউন্টেন</option>
                    <option value="festive_balloons">🎈 ৪. উৎসবমুখর বেলুন ও হার্টস</option>
                    <option value="ramadan_noor_lanterns">🌙 ৫. রমজান নূর, ফানুস ও চাঁদ-তারা (Ramadan)</option>
                    <option value="eid_mubarak_royal">🕌 ৬. ঈদ মোবারক রয়্যাল উৎসব (Eid Special)</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => {
                      const nextBadge = !isOrderCelebrationBadgeOn;
                      updateBusiness({
                        storefrontOrderCelebrationBadgeEnabled: nextBadge
                      });
                      setTimeout(() => triggerOrderSuccessConfetti(), 30);
                      showToast(
                        nextBadge
                          ? '🏅 মাঝখানের গোল্ডেন সেলিব্রেশন পপ-আপ ব্যাজ চালু (ON) করা হয়েছে!'
                          : 'মাঝখানের সেলিব্রেশন পপ-আপ ব্যাজ বন্ধ (OFF) — শুধু পার্টিকেল দেখাবে।',
                        'info'
                      );
                    }}
                    className={`px-2 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all flex items-center gap-1 ${
                      isOrderCelebrationBadgeOn
                        ? 'bg-emerald-700 text-white border-emerald-800'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                    }`}
                    title="মাঝখানের গোল্ডেন চেকমার্ক সেলিব্রেশন ব্যাজ ON / OFF করুন"
                  >
                    <span>🏅 পপ-ব্যাজ: {isOrderCelebrationBadgeOn ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerOrderSuccessConfetti();
                      showToast('🎉 সেলিব্রেশন অ্যানিমেশন লাইভ টেস্ট চলছে!', 'success');
                    }}
                    className="px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 border border-amber-600 cursor-pointer transition-all flex items-center gap-1 shadow-2xs"
                    title="১-ক্লিকে সেলিব্রেশন অ্যানিমেশন টেস্ট করে দেখুন"
                  >
                    <span>✨ টেস্ট দেখুন</span>
                  </button>

                  <span className="text-[11px] font-extrabold text-slate-800 px-1.5">
                    🎨 Theme:
                  </span>
                  <select
                    value={activeStorefrontTheme}
                    onChange={(e) => {
                      const nextTheme = e.target.value as StorefrontThemeStyle;
                      const isSeasonal =
                        nextTheme === 'winter_frost' ||
                        nextTheme === 'summer_mango' ||
                        nextTheme === 'ramadan_noor' ||
                        nextTheme === 'eid_festive';
                      updateBusiness({
                        storefrontTheme: nextTheme,
                        winterThemeEnabled: nextTheme === 'winter_frost',
                        ...(isSeasonal ? { winterSnowfallEnabled: true } : { winterSnowfallEnabled: false })
                      });
                      showToast(`Storefront Theme updated!`, 'success');
                    }}
                    className="px-2 py-1 rounded-lg bg-white border border-slate-300 text-[11px] font-extrabold text-slate-800 cursor-pointer outline-hidden"
                    title="Change Website Color Theme"
                  >
                    <option value="emerald_default">1. Classic Emerald (Default)</option>
                    <option value="winter_frost">❄️ Winter Frost (উইন্টার ও তুষারপাত)</option>
                    <option value="summer_mango">☀️ Summer Sunshine (গ্রীষ্মকালীন সামার থিম)</option>
                    <option value="ramadan_noor">🌙 Ramadan Kareem (মাহে রমজান নূর থিম)</option>
                    <option value="eid_festive">🕌 Eid Vacation (ঈদ মোবারক ও ভ্যাকেশন থিম)</option>
                    <option value="cool_blue">💎 2. Cool Blue (উইন্টার ছাড়া কুল ব্লু)</option>
                    <option value="royal_crimson">3. Royal Crimson &amp; Maroon</option>
                    <option value="ocean_indigo">4. Ocean Royal Blue</option>
                    <option value="royal_purple">5. Velvet Royal Purple</option>
                    <option value="sunset_coral">6. Sunset Orange &amp; Coral</option>
                    <option value="rose_magenta">7. Rose Pink &amp; Magenta</option>
                    <option value="coffee_bronze">8. Espresso &amp; Bronze</option>
                    <option value="luxury_midnight">9. Midnight Gold &amp; Slate</option>
                  </select>

                  <span className="text-[11px] font-extrabold text-slate-800 px-1">
                    🔤 Font:
                  </span>
                  <select
                    value={currentBusiness.banglaFont || 'noto_sans'}
                    onChange={(e) => {
                      const nextFont = e.target.value as any;
                      updateBusiness({ banglaFont: nextFont });
                      showToast(`Bangla Font updated!`, 'success');
                    }}
                    className="px-2 py-1 rounded-lg bg-white border border-slate-300 text-[11px] font-extrabold text-slate-800 cursor-pointer outline-hidden"
                    title="Change Website Bangla Font"
                  >
                    <option value="noto_sans">1. Noto Sans Bengali (Default)</option>
                    <option value="anek_bangla">2. Anek Bangla (Modern)</option>
                    <option value="hind_siliguri">3. Hind Siliguri (Popular)</option>
                    <option value="baloo_da_2">4. Baloo Da 2 (Rounded)</option>
                    <option value="tiro_bangla">5. Tiro Bangla (Editorial)</option>
                    <option value="noto_serif_bengali">6. Noto Serif Bengali (Luxury)</option>
                    <option value="mina">7. Mina (Geometric Clean)</option>
                    <option value="atma">8. Atma (Playful Kids)</option>
                    <option value="galada">9. Galada (Festive Display)</option>
                    <option value="kalpurush">10. Kalpurush (কালপুরুষ)</option>
                    <option value="kalpurush_bold">11. Kalpurush Bold (কালপুরুষ বোল্ড)</option>
                    <option value="solaiman_lipi">12. SolaimanLipi (সোলাইমানলিপি)</option>
                    <option value="solaiman_lipi_bold">13. SolaimanLipi Bold (সোলাইমানলিপি বোল্ড)</option>
                    <option value="adorsho_lipi">14. AdorshoLipi (আদর্শলিপি)</option>
                    <option value="nikosh">15. Nikosh (নিকষ)</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => {
                      const nextFull = !Boolean(currentBusiness.showFullProductNameOnCards);
                      updateBusiness({ showFullProductNameOnCards: nextFull });
                      showToast(
                        nextFull
                          ? 'হোমপেজ ও রিলেটেড প্রোডাক্টে সম্পূর্ণ নাম দেখানো চালু (ON) করা হয়েছে!'
                          : 'হোমপেজ ও রিলেটেড প্রোডাক্টে ২-লাইনে সংক্ষিপ্ত নাম (OFF) সেট করা হয়েছে!',
                        nextFull ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                      currentBusiness.showFullProductNameOnCards
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500'
                    }`}
                    title="হোমপেজ ও রিলেটেড প্রোডাক্টে প্রোডাক্টের সম্পূর্ণ নাম দেখানো ON / OFF করুন"
                  >
                    {currentBusiness.showFullProductNameOnCards
                      ? '📝 সম্পূর্ণ নাম: ON'
                      : '📝 ২-লাইন নাম: OFF (Full করুন)'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const curCheckoutFull = currentBusiness.showFullProductNameOnCheckout !== false;
                      const nextCheckoutFull = !curCheckoutFull;
                      updateBusiness({ showFullProductNameOnCheckout: nextCheckoutFull });
                      showToast(
                        nextCheckoutFull
                          ? 'চেকআউট পেজে প্রোডাক্টের সম্পূর্ণ নাম দেখানো চালু (ON) করা হয়েছে!'
                          : 'চেকআউট পেজে ১-লাইনে সংক্ষিপ্ত নাম (OFF) সেট করা হয়েছে!',
                        nextCheckoutFull ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                      currentBusiness.showFullProductNameOnCheckout !== false
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500'
                    }`}
                    title="চেকআউট পেজে প্রোডাক্টের সম্পূর্ণ নাম দেখানো ON / OFF করুন"
                  >
                    {currentBusiness.showFullProductNameOnCheckout !== false
                      ? '🛒 চেকআউট সম্পূর্ণ নাম: ON'
                      : '🛒 চেকআউট ১-লাইন নাম: OFF'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const curTopBar = currentBusiness.topUtilityBarEnabled !== false;
                      const nextTopBar = !curTopBar;
                      updateBusiness({ topUtilityBarEnabled: nextTopBar });
                      showToast(
                        nextTopBar
                          ? 'হটলাইন ও লগইন টপ বার চালু (ON) করা হয়েছে!'
                          : 'হটলাইন ও লগইন টপ বার হাইড (OFF) করা হয়েছে!',
                        nextTopBar ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                      currentBusiness.topUtilityBarEnabled !== false
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500'
                    }`}
                    title="স্টোরফ্রন্টের হটলাইন ও লগইন/সাইনআপ টপ বার শো বা হাইড (ON / OFF) করুন"
                  >
                    {currentBusiness.topUtilityBarEnabled !== false
                      ? '🔝 টপ বার (হটলাইন/লগইন): ON'
                      : '🔝 টপ বার (হটলাইন/লগইন): OFF'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const nextCatBar = !isHomeCategoryBarEnabled;
                      updateBusiness({ homeCategoryBarEnabled: nextCatBar });
                      if (!nextCatBar && selectedCategoryId !== 'all') {
                        setSelectedCategoryId('all');
                      }
                      showToast(
                        nextCatBar
                          ? 'হোমপেজে ক্যাটাগরি স্লাইডার চালু (ON) করা হয়েছে!'
                          : 'হোমপেজে ক্যাটাগরি স্লাইডার বন্ধ (OFF) করা হয়েছে!',
                        nextCatBar ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                      isHomeCategoryBarEnabled
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500'
                    }`}
                    title="হোমপেজে ক্যাটাগরি স্লাইডার শো করবে নাকি বন্ধ থাকবে তা ১-ক্লিকে ON / OFF করুন"
                  >
                    {isHomeCategoryBarEnabled
                      ? '🗂️ হোম ক্যাটাগরি: ON'
                      : '🗂️ হোম ক্যাটাগরি: OFF'}
                  </button>

                  {isHomeCategoryBarEnabled && (
                    <>
                      <select
                        value={homeCategoryBarDesign}
                        onChange={(e) => {
                          const nextDesign = e.target.value as HomeCategoryBarDesign;
                          updateBusiness({
                            homeCategoryBarEnabled: true,
                            homeCategoryBarDesign: nextDesign
                          });
                          const found = homeCategoryDesignOptions.find(o => o.id === nextDesign);
                          showToast(
                            `ক্যাটাগরি ডিজাইন: "${found?.shortLabel || nextDesign}" সেট করা হয়েছে!`,
                            'success'
                          );
                        }}
                        className="px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-300 text-[11px] font-extrabold text-emerald-950 cursor-pointer outline-hidden"
                        title="৫টি প্রিমিয়াম ক্যাটাগরি স্লাইডার ডিজাইন থেকে পছন্দেরটি বেছে নিন"
                      >
                        {homeCategoryDesignOptions.map(opt => (
                          <option key={opt.id} value={opt.id}>
                            🎨 ক্যাটাগরি: {opt.label}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => {
                          const nextAuto = !isHomeCategoryAutoSlide;
                          updateBusiness({ homeCategoryAutoSlide: nextAuto });
                          showToast(
                            nextAuto
                              ? '🔄 ক্যাটাগরি অটো স্মুথ স্লাইডার চালু (ON) করা হয়েছে!'
                              : '⏸️ ক্যাটাগরি অটো স্লাইড বন্ধ (OFF) করা হয়েছে!',
                            nextAuto ? 'success' : 'info'
                          );
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                          isHomeCategoryAutoSlide
                            ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:border-amber-500'
                        }`}
                        title="ক্যাটাগরি স্লাইডার অটোমেটিক স্মুথলি স্লাইড হবে কি না তা ON / OFF করুন"
                      >
                        {isHomeCategoryAutoSlide ? '🔄 অটো স্লাইড: ON' : '⏸️ অটো স্লাইড: OFF'}
                      </button>
                    </>
                  )}

                  {/* Smart Hybrid Infinite Scroll + Load More Admin Controls (ON/OFF + Batch Size: 12 / 20 / 30 / 40) */}
                  <button
                    type="button"
                    onClick={() => {
                      const nextScroll = !isHomeInfiniteScrollEnabled;
                      updateBusiness({ homeInfiniteScrollEnabled: nextScroll });
                      showToast(
                        nextScroll
                          ? `⚡ স্মার্ট অটো স্ক্রল লোড (${homeProductsPerBatch}টি করে) চালু (ON) করা হয়েছে!`
                          : '📄 অটো স্ক্রল লোড বন্ধ (OFF) করা হয়েছে — এখন সব প্রোডাক্ট একসাথে দেখাবে!',
                        nextScroll ? 'success' : 'info'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                      isHomeInfiniteScrollEnabled
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500'
                    }`}
                    title="হোমপেজে একসাথে সব প্রোডাক্ট লোড না করে ২০টি করে অটো স্ক্রল লোড সিস্টেম ON / OFF করুন"
                  >
                    {isHomeInfiniteScrollEnabled
                      ? `⚡ অটো স্ক্রল লোড: ON (${homeProductsPerBatch}টি)`
                      : '⚡ অটো স্ক্রল লোড: OFF'}
                  </button>

                  {isHomeInfiniteScrollEnabled && (
                    <select
                      value={homeProductsPerBatch}
                      onChange={e => {
                        const nextBatch = Number(e.target.value) || 20;
                        updateBusiness({
                          homeInfiniteScrollEnabled: true,
                          homeProductsPerBatch: nextBatch
                        });
                        setVisibleProductsCount(nextBatch);
                        showToast(
                          `হোমপেজে প্রতি ধাপে ${nextBatch}টি করে প্রোডাক্ট লোড সেট করা হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-300 text-[11px] font-extrabold text-emerald-950 cursor-pointer outline-hidden"
                      title="শুরুতে এবং প্রতিবার স্ক্রল করলে কতটি করে প্রোডাক্ট লোড হবে তা সিলেক্ট করুন"
                    >
                      <option value={12}>📦 প্রতি ধাপে ১২টি প্রোডাক্ট</option>
                      <option value={20}>📦 প্রতি ধাপে ২০টি প্রোডাক্ট (সেরা)</option>
                      <option value={30}>📦 প্রতি ধাপে ৩০টি প্রোডাক্ট</option>
                      <option value={40}>📦 প্রতি ধাপে ৪০টি প্রোডাক্ট</option>
                    </select>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Dedicated Single-Category View Header (When a Category is clicked, hide other categories & show back button) OR Home Page Category Slider (When on 'all') */}
          {(selectedCategoryId !== 'all' || (isHomeCategoryBarEnabled && homeSliderCategories.length > 0)) && (() => {
            const totalStoreProds = products.filter(p => !p.isLandingPageProduct).length;
            const isTwoColLargeMode =
              homeCategoryBarDesign === 'large_poster_2col' ||
              homeCategoryBarDesign === 'pure_image_card' ||
              homeCategoryBarDesign === 'modern_grid_card';

            const renderCategoryVisual = (cat: typeof homeSliderCategories[number], imgClass = 'w-full h-full object-cover') => {
              const catProds = products.filter(
                p => !p.isLandingPageProduct && p.categoryId === cat.id
              );
              const fallbackProduct = catProds.find(p => p.image) || catProds[0];
              const resolvedCatImg = cat.image ? getProductImageUrl(cat.image, false) : '';

              if (resolvedCatImg) {
                return (
                  <img
                    src={resolvedCatImg}
                    alt={cat.nameBn}
                    loading="lazy"
                    className={`${imgClass} transition-transform duration-500 group-hover:scale-105`}
                  />
                );
              }
              if (fallbackProduct) {
                return (
                  <ProductThumbnail
                    product={fallbackProduct}
                    className="w-full h-full"
                    imgClassName="p-0 object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                );
              }
              return (
                <div className="w-full h-full bg-gradient-to-br from-emerald-50 to-teal-100 flex items-center justify-center">
                  <ShoppingBag
                    className={`w-8 h-8 ${
                      isCoolBluePalette ? 'text-sky-700' : 'text-emerald-700'
                    }`}
                  />
                </div>
              );
            };

            if (selectedCategoryId !== 'all') {
              const activeCat = categories.find(c => c.id === selectedCategoryId);
              const activeCatProdsCount = products.filter(
                p => !p.isLandingPageProduct && p.categoryId === selectedCategoryId
              ).length;

              return (
                <div className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-4 shadow-2xs flex flex-wrap items-center justify-between gap-3 animate-page-rise">
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleSelectCategory('all')}
                      className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 flex items-center justify-center shrink-0 cursor-pointer transition-colors"
                      title="হোম পেজে ফিরে যান"
                    >
                      <ArrowLeft className="w-4.5 h-4.5" />
                    </button>
                    {activeCat && (
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl overflow-hidden border border-slate-200 bg-slate-50 shrink-0">
                        {renderCategoryVisual(activeCat)}
                      </div>
                    )}
                    <div className="min-w-0">
                      <h2 className="text-sm sm:text-lg font-extrabold text-slate-900 truncate">
                        {activeCat
                          ? language === 'bn'
                            ? activeCat.nameBn
                            : activeCat.nameEn
                          : 'নির্বাচিত ক্যাটাগরি'}
                      </h2>
                      <p className="text-[11px] sm:text-xs font-semibold text-emerald-700">
                        এই ক্যাটাগরিতে মোট {toBanglaCountdownDigits(activeCatProdsCount, 1)} টি পণ্য রয়েছে
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSelectCategory('all')}
                    className={`px-3.5 py-2 rounded-xl text-xs sm:text-[13px] font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-2xs transition-all ${
                      isCoolBluePalette
                        ? 'bg-sky-700 text-white hover:bg-sky-800'
                        : 'bg-emerald-800 text-white hover:bg-emerald-900'
                    }`}
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>সকল ক্যাটাগরিতে ফিরে যান</span>
                  </button>
                </div>
              );
            }

            return (
              <div
                className={`${
                  homeCategoryBarDesign === 'pure_image_card'
                    ? 'py-0.5'
                    : 'bg-white rounded-2xl border border-slate-200/90 p-2.5 sm:p-3.5 shadow-2xs'
                } relative space-y-2`}
                onMouseEnter={() => {
                  isCategorySliderPausedRef.current = true;
                }}
                onMouseLeave={() => {
                  pauseCategoryAutoSlideTemporarily(1800);
                }}
                onTouchStart={() => {
                  isCategorySliderPausedRef.current = true;
                }}
                onTouchEnd={() => {
                  pauseCategoryAutoSlideTemporarily(3800);
                }}
              >
                {isAuthenticated && (
                  <div className="flex flex-wrap items-center justify-end gap-2 px-0.5">
                    <div className="flex items-center gap-1.5 ml-auto">
                      <button
                        type="button"
                        onClick={() => {
                          const curIdx = homeCategoryDesignOptions.findIndex(
                            o => o.id === homeCategoryBarDesign
                          );
                          const nextOpt =
                            homeCategoryDesignOptions[
                              (curIdx + 1) % homeCategoryDesignOptions.length
                            ];
                          updateBusiness({ homeCategoryBarDesign: nextOpt.id });
                          showToast(
                            `ক্যাটাগরি ডিজাইন: "${nextOpt.shortLabel}" সেট করা হয়েছে!`,
                            'success'
                          );
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 text-[10px] sm:text-[11px] font-extrabold cursor-pointer flex items-center gap-1 shadow-2xs"
                        title="১-ক্লিকে ক্যাটাগরির পরবর্তী ডিজাইন দেখুন"
                      >
                        <span>
                          🎨 ডিজাইন পাল্টান:{' '}
                          {
                            (
                              homeCategoryDesignOptions.find(
                                o => o.id === homeCategoryBarDesign
                              ) || homeCategoryDesignOptions[0]
                            ).shortLabel
                          }
                        </span>
                      </button>
                    </div>
                  </div>
                )}

                <div className="relative flex items-center">
                  {/* Horizontal Smooth Auto-Sliding & Hand-Draggable Track (No Left/Right Arrow Buttons) */}
                  <div
                    ref={homeCategoryScrollRef}
                    onMouseDown={handleCatTrackMouseDown}
                    onMouseMove={handleCatTrackMouseMove}
                    onMouseUp={handleCatTrackMouseUpOrLeave}
                    onMouseLeave={handleCatTrackMouseUpOrLeave}
                    onClickCapture={(e) => {
                      if (catDragStateRef.current.moved) {
                        e.stopPropagation();
                        e.preventDefault();
                      }
                    }}
                    className={`flex items-stretch overflow-x-auto scroll-smooth touch-pan-x cursor-grab active:cursor-grabbing flex-1 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden ${
                      isTwoColLargeMode
                        ? 'gap-2.5 sm:gap-3.5 py-0.5'
                        : homeCategoryBarDesign === 'circle_story'
                        ? 'gap-3 sm:gap-4 py-1 px-1'
                        : 'gap-2 sm:gap-2.5 py-0.5'
                    }`}
                  >
                    {/* "All Products" Item for Circle Story & Compact Pill modes */}
                    {(homeCategoryBarDesign === 'compact_pill' ||
                      homeCategoryBarDesign === 'circle_story') &&
                      (() => {
                        const isAllActive = selectedCategoryId === 'all';

                        if (homeCategoryBarDesign === 'circle_story') {
                          return (
                            <button
                              type="button"
                              onClick={(e) => {
                                pauseCategoryAutoSlideTemporarily(4500);
                                handleSelectCategory('all');
                                e.currentTarget.scrollIntoView({
                                  behavior: 'smooth',
                                  inline: 'center',
                                  block: 'nearest'
                                });
                              }}
                              className="group flex flex-col items-center gap-1.5 w-[76px] sm:w-[92px] snap-start shrink-0 cursor-pointer select-none"
                            >
                              <div
                                className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full p-[2.5px] transition-transform duration-300 group-hover:scale-105 ${
                                  isAllActive
                                    ? isCoolBluePalette
                                      ? 'bg-gradient-to-tr from-sky-600 via-cyan-500 to-blue-700 shadow-md'
                                      : 'bg-gradient-to-tr from-emerald-700 via-teal-500 to-amber-500 shadow-md'
                                    : 'bg-slate-200 group-hover:bg-emerald-400'
                                }`}
                              >
                                <div
                                  className={`w-full h-full rounded-full flex flex-col items-center justify-center border-2 border-white ${
                                    isAllActive
                                      ? isCoolBluePalette
                                        ? 'bg-sky-700 text-white'
                                        : 'bg-emerald-800 text-white'
                                      : 'bg-slate-50 text-emerald-800'
                                  }`}
                                >
                                  <LayoutGrid className="w-6 h-6 sm:w-7 sm:h-7" />
                                </div>
                              </div>
                              <p
                                className={`text-[11px] sm:text-xs font-extrabold text-center leading-tight line-clamp-1 ${
                                  isAllActive
                                    ? isCoolBluePalette
                                      ? 'text-sky-700'
                                      : 'text-emerald-800'
                                    : 'text-slate-800'
                                }`}
                              >
                                {language === 'bn' ? 'সকল পণ্য' : 'All Items'}
                              </p>
                            </button>
                          );
                        }

                        return (
                          <button
                            type="button"
                            onClick={(e) => {
                              pauseCategoryAutoSlideTemporarily(4500);
                              handleSelectCategory('all');
                              e.currentTarget.scrollIntoView({
                                behavior: 'smooth',
                                inline: 'center',
                                block: 'nearest'
                              });
                            }}
                            className={`group flex items-center gap-2 sm:gap-2.5 pl-1.5 pr-3 sm:pr-3.5 py-1.5 rounded-xl border transition-all duration-200 snap-start shrink-0 cursor-pointer select-none ${
                              isAllActive
                                ? isCoolBluePalette
                                  ? 'bg-sky-700 text-white border-sky-700 shadow-sm'
                                  : 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
                                : 'bg-slate-50/90 hover:bg-white text-slate-800 border-slate-200/90 hover:border-emerald-300'
                            }`}
                          >
                            <div
                              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:scale-105 ${
                                isAllActive
                                  ? 'bg-white/20 text-white'
                                  : isCoolBluePalette
                                  ? 'bg-sky-100 text-sky-700'
                                  : 'bg-emerald-100/80 text-emerald-800'
                              }`}
                            >
                              <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5" />
                            </div>
                            <div className="text-left leading-tight">
                              <p className="text-xs sm:text-[13px] font-extrabold whitespace-nowrap">
                                {language === 'bn' ? 'সকল পণ্য' : 'All Items'}
                              </p>
                              <p
                                className={`text-[10px] font-semibold whitespace-nowrap ${
                                  isAllActive ? 'text-white/85' : 'text-slate-500'
                                }`}
                              >
                                {language === 'bn'
                                  ? `${toBanglaCountdownDigits(totalStoreProds, 1)} টি পণ্য`
                                  : `${totalStoreProds} items`}
                              </p>
                            </div>
                          </button>
                        );
                      })()}

                    {/* Category Items Rendered According to Active Design */}
                    {homeSliderCategories.map(cat => {
                      const isActive = selectedCategoryId === cat.id;
                      const catProds = products.filter(
                        p => !p.isLandingPageProduct && p.categoryId === cat.id
                      );

                      // DESIGN 1: Large Image Poster (2 per view on mobile, smooth auto-slider, large image + bottom glass overlay)
                      if (homeCategoryBarDesign === 'large_poster_2col') {
                        return (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={(e) => {
                              pauseCategoryAutoSlideTemporarily(4500);
                              handleSelectCategory(isActive ? 'all' : cat.id);
                              e.currentTarget.scrollIntoView({
                                behavior: 'smooth',
                                inline: 'center',
                                block: 'nearest'
                              });
                            }}
                            className={`group relative w-[calc(50%-5px)] sm:w-[210px] md:w-[235px] aspect-[4/3] rounded-2xl overflow-hidden snap-start shrink-0 cursor-pointer select-none border-2 transition-all duration-300 ${
                              isActive
                                ? isCoolBluePalette
                                  ? 'border-sky-600 ring-2 ring-sky-500/40 shadow-md'
                                  : 'border-emerald-600 ring-2 ring-emerald-500/40 shadow-md'
                                : 'border-slate-200/80 hover:border-emerald-400 shadow-2xs'
                            }`}
                          >
                            <div className="w-full h-full bg-slate-100">
                              {renderCategoryVisual(cat)}
                            </div>

                            {/* Sleek Bottom Gradient + Category Title */}
                            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-950/55 to-transparent pt-7 pb-2.5 px-2.5 flex items-end justify-between gap-1.5">
                              <div className="text-left min-w-0">
                                <p className="text-xs sm:text-sm font-extrabold text-white leading-tight line-clamp-1 drop-shadow-xs">
                                  {language === 'bn' ? cat.nameBn : cat.nameEn}
                                </p>
                                <p className="text-[10px] font-semibold text-emerald-200 leading-tight mt-0.5">
                                  {language === 'bn'
                                    ? `${toBanglaCountdownDigits(catProds.length, 1)} টি পণ্য`
                                    : `${catProds.length} items`}
                                </p>
                              </div>
                              {isActive && (
                                <span className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </span>
                              )}
                            </div>
                          </button>
                        );
                      }

                      // DESIGN 2: Pure Large Image Card (Only large category photo, 2 per view on mobile, zero text clutter)
                      if (homeCategoryBarDesign === 'pure_image_card') {
                        return (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={(e) => {
                              pauseCategoryAutoSlideTemporarily(4500);
                              handleSelectCategory(isActive ? 'all' : cat.id);
                              e.currentTarget.scrollIntoView({
                                behavior: 'smooth',
                                inline: 'center',
                                block: 'nearest'
                              });
                            }}
                            title={language === 'bn' ? cat.nameBn : cat.nameEn}
                            className={`group relative w-[calc(50%-5px)] sm:w-[210px] md:w-[235px] aspect-[4/3] rounded-2xl overflow-hidden snap-start shrink-0 cursor-pointer select-none border-2 transition-all duration-300 bg-white ${
                              isActive
                                ? isCoolBluePalette
                                  ? 'border-sky-600 ring-2 ring-sky-500/40 shadow-md'
                                  : 'border-emerald-600 ring-2 ring-emerald-500/40 shadow-md'
                                : 'border-slate-200/90 hover:border-emerald-400 shadow-2xs'
                            }`}
                          >
                            <div className="w-full h-full bg-slate-50">
                              {renderCategoryVisual(cat)}
                            </div>

                            {isActive && (
                              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-emerald-700/95 text-white text-[10px] font-extrabold flex items-center gap-1 shadow-md">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>সিলেক্টেড</span>
                              </div>
                            )}
                          </button>
                        );
                      }

                      // DESIGN 3: Modern Fashion Box (2 per view on mobile, large square/4:3 image on top + clean title bar below)
                      if (homeCategoryBarDesign === 'modern_grid_card') {
                        return (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={(e) => {
                              pauseCategoryAutoSlideTemporarily(4500);
                              handleSelectCategory(isActive ? 'all' : cat.id);
                              e.currentTarget.scrollIntoView({
                                behavior: 'smooth',
                                inline: 'center',
                                block: 'nearest'
                              });
                            }}
                            className={`group flex flex-col w-[calc(50%-5px)] sm:w-[195px] md:w-[215px] rounded-2xl overflow-hidden snap-start shrink-0 cursor-pointer select-none border transition-all duration-300 ${
                              isActive
                                ? isCoolBluePalette
                                  ? 'bg-sky-700 text-white border-sky-700 shadow-md'
                                  : 'bg-emerald-800 text-white border-emerald-800 shadow-md'
                                : 'bg-white hover:bg-slate-50 text-slate-900 border-slate-200/90 hover:border-emerald-400 shadow-2xs'
                            }`}
                          >
                            <div className="w-full aspect-[4/3] bg-slate-100 overflow-hidden relative">
                              {renderCategoryVisual(cat)}
                              <span
                                className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-[10px] font-extrabold backdrop-blur-xs ${
                                  isActive
                                    ? 'bg-emerald-600 text-white'
                                    : 'bg-slate-900/70 text-white'
                                }`}
                              >
                                {toBanglaCountdownDigits(catProds.length, 1)}টি
                              </span>
                            </div>
                            <div className="px-2.5 py-2 text-center">
                              <p className="text-xs sm:text-[13px] font-extrabold line-clamp-1">
                                {language === 'bn' ? cat.nameBn : cat.nameEn}
                              </p>
                            </div>
                          </button>
                        );
                      }

                      // DESIGN 4: Circle Story Ring (Large Circular Image + Title Below)
                      if (homeCategoryBarDesign === 'circle_story') {
                        return (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={(e) => {
                              pauseCategoryAutoSlideTemporarily(4500);
                              handleSelectCategory(isActive ? 'all' : cat.id);
                              e.currentTarget.scrollIntoView({
                                behavior: 'smooth',
                                inline: 'center',
                                block: 'nearest'
                              });
                            }}
                            className="group flex flex-col items-center gap-1.5 w-[76px] sm:w-[92px] snap-start shrink-0 cursor-pointer select-none"
                          >
                            <div
                              className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full p-[2.5px] transition-transform duration-300 group-hover:scale-105 ${
                                isActive
                                  ? isCoolBluePalette
                                    ? 'bg-gradient-to-tr from-sky-600 via-cyan-400 to-blue-700 shadow-md'
                                    : 'bg-gradient-to-tr from-emerald-700 via-teal-500 to-amber-500 shadow-md'
                                  : 'bg-gradient-to-tr from-slate-200 via-slate-300 to-slate-200 group-hover:from-emerald-500 group-hover:to-teal-500'
                              }`}
                            >
                              <div className="w-full h-full rounded-full overflow-hidden border-2 border-white bg-white">
                                {renderCategoryVisual(cat)}
                              </div>
                            </div>
                            <p
                              className={`text-[11px] sm:text-xs font-extrabold text-center leading-tight line-clamp-1 ${
                                isActive
                                  ? isCoolBluePalette
                                    ? 'text-sky-700'
                                    : 'text-emerald-800'
                                  : 'text-slate-800'
                              }`}
                            >
                              {language === 'bn' ? cat.nameBn : cat.nameEn}
                            </p>
                          </button>
                        );
                      }

                      // DESIGN 5: Compact Simple Pill (Previous Clean Pill Design)
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={(e) => {
                            pauseCategoryAutoSlideTemporarily(4500);
                            handleSelectCategory(isActive ? 'all' : cat.id);
                            e.currentTarget.scrollIntoView({
                              behavior: 'smooth',
                              inline: 'center',
                              block: 'nearest'
                            });
                          }}
                          className={`group flex items-center gap-2 sm:gap-2.5 pl-1.5 pr-3 sm:pr-3.5 py-1.5 rounded-xl border transition-all duration-200 snap-start shrink-0 cursor-pointer select-none ${
                            isActive
                              ? isCoolBluePalette
                                ? 'bg-sky-700 text-white border-sky-700 shadow-sm'
                                : 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
                              : 'bg-slate-50/90 hover:bg-white text-slate-800 border-slate-200/90 hover:border-emerald-300'
                          }`}
                        >
                          <div
                            className={`w-9 h-9 sm:w-10 sm:h-10 rounded-lg overflow-hidden flex items-center justify-center shrink-0 border transition-transform duration-200 group-hover:scale-105 ${
                              isActive
                                ? 'border-white/40 bg-white'
                                : 'border-slate-200/80 bg-white'
                            }`}
                          >
                            {renderCategoryVisual(cat)}
                          </div>

                          <div className="text-left leading-tight">
                            <p className="text-xs sm:text-[13px] font-extrabold whitespace-nowrap">
                              {language === 'bn' ? cat.nameBn : cat.nameEn}
                            </p>
                            <p
                              className={`text-[10px] font-semibold whitespace-nowrap ${
                                isActive ? 'text-white/85' : 'text-slate-500'
                              }`}
                            >
                              {language === 'bn'
                                ? `${toBanglaCountdownDigits(catProds.length, 1)} টি পণ্য`
                                : `${catProds.length} items`}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Product Cards Grid: 2 Columns on Mobile (grid-cols-2), 3 on sm, 4 on lg, 5 on xl */}
          {!isServerHydrated &&
          products.length === 0 &&
          currentBusiness.preloaderShimmerEnabled !== false ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2.5 sm:gap-4">
              {Array.from({ length: 10 }).map((_, skIdx) => (
                <div
                  key={`sf_shimmer_card_${skIdx}`}
                  className="bg-white rounded-2xl border border-slate-200/80 p-2.5 sm:p-3.5 shadow-2xs flex flex-col gap-2.5"
                >
                  <div className="w-full aspect-square rounded-xl bg-slate-200/75 animate-pulse" />
                  <div className="h-3.5 w-4/5 rounded-md bg-slate-200/80 animate-pulse" />
                  <div className="h-3 w-3/5 rounded-md bg-slate-100 animate-pulse" />
                  <div className="flex items-center justify-between pt-1">
                    <div className="h-4 w-16 rounded-md bg-emerald-100/80 animate-pulse" />
                    <div className="h-3.5 w-10 rounded-md bg-slate-100 animate-pulse" />
                  </div>
                  <div className="h-9 w-full rounded-xl bg-slate-200/70 animate-pulse mt-0.5" />
                </div>
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-3">
              <p className="text-sm font-bold text-slate-800">
                {language === 'bn' ? 'কোনো পণ্য খুঁজে পাওয়া যায়নি!' : 'No matching products found!'}
              </p>
              <button
                type="button"
                onClick={() => {
                  handleSelectCategory('all');
                  setSelectedBrandId('all');
                  setSearchQuery('');
                }}
                className="px-4 py-2 bg-emerald-700 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                সকল পণ্য দেখুন
              </button>
            </div>
          ) : (
            <>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2.5 sm:gap-4">
              {displayedProducts.map(product => {
                const available = getProductAvailableStock(product);
                const isOut = available <= 0;
                const activeVariant = getActiveVariant(product);
                const activeRetailPrice = activeVariant
                  ? activeVariant.retailPrice
                  : product.retailPrice;
                const explicitVariant = getExplicitSelectedVariant(product);
                const hasVars = Boolean(product.variants && product.variants.length > 0);
                const cartKey = buildCartKey(product.id, activeVariant);
                const inCartQty =
                  isVariantSelectionRequired && hasVars && !explicitVariant
                    ? 0
                    : cart[cartKey]?.quantity || 0;
                const mrpPrice = getRegularMrpFromRetail(
                  activeRetailPrice,
                  activeVariant?.regularPrice ?? product.regularPrice,
                  activeVariant?.discountPrice ?? product.discountPrice
                );
                const discountTk = Math.max(0, mrpPrice - activeRetailPrice);
                const isProdFreeDelivery =
                  isProductSpecificFreeDeliveryEnabled &&
                  Boolean(product.freeDelivery || product.freeDeliveryOnLanding);

                return (
                  <div
                    key={product.id}
                    className={`bg-white rounded-2xl border ${
                      isCoolBluePalette
                        ? 'border-sky-200/90 hover:border-sky-500 shadow-xs hover:shadow-sky-500/15'
                        : 'border-slate-200/85 hover:border-emerald-500/80 shadow-2xs'
                    } hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 flex flex-col justify-between overflow-hidden group`}
                  >
                    {/* Top Image & Discount Tag */}
                    <div>
                      <div
                        onClick={() => openQuickView(product)}
                        className={`relative aspect-square w-full ${
                          isCoolBluePalette
                            ? 'bg-gradient-to-b from-sky-50/70 to-white border-b border-sky-100'
                            : 'bg-slate-50/40 border-b border-slate-100'
                        } cursor-pointer overflow-hidden`}
                      >
                        <ProductThumbnail
                          product={{
                            ...product,
                            image:
                              getProductColorVariants(product).find(
                                c => c.id === selectedColorByProduct[product.id]
                              )?.imageUrl ||
                              activeVariant?.imageUrl ||
                              product.image
                          }}
                          imgClassName="p-0.5 group-hover:scale-105 transition-transform duration-300"
                        />

                        {/* Savings Text Tag */}
                        {discountTk > 0 && !isOut && (
                          <span
                            className={`absolute top-2 left-2 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-lg shadow-2xs ${
                              isCoolBluePalette
                                ? 'bg-gradient-to-r from-sky-600 to-blue-700 border border-sky-300/40'
                                : 'bg-rose-600'
                            }`}
                          >
                            {isWinterTheme ? `❄️ ছাড় ৳${discountTk}` : `ছাড় ৳${discountTk}`}
                          </span>
                        )}

                        {/* Offer #6: Product-Specific Free Delivery Badge on Product Card */}
                        {isProdFreeDelivery && !isOut && (
                          <span className="absolute bottom-2 left-2 bg-emerald-700/95 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-lg shadow-2xs inline-flex items-center gap-1">
                            <span>🚚 ফ্রি ডেলিভারি</span>
                          </span>
                        )}

                        {renderStockOutImageOverlay(isOut, false)}

                        {/* Quick View Eye Button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            openQuickView(product);
                          }}
                          className="absolute top-2 right-2 w-7 h-7 rounded-lg bg-white/90 hover:bg-white text-slate-700 border border-slate-200 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-2xs cursor-pointer"
                          title="বিস্তারিত দেখুন"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Product Title & Variations */}
                      <div className="px-2.5 pt-2.5 pb-1 sm:px-3.5 sm:pt-3 sm:pb-1.5 space-y-1.5">
                        {(showVariantsOnHomePage || !hasVars || (!isOut && currentBusiness.homePageScarcityStockEnabled !== false)) && (
                          <div className="flex items-center justify-between gap-1 text-[10px] sm:text-[11px]">
                            <span className="text-slate-500 truncate">
                              {!showVariantsOnHomePage && hasVars
                                ? ''
                                : hasVars && isVariantSelectionRequired
                                ? explicitVariant
                                  ? explicitVariant.label
                                  : 'সাইজ সিলেক্ট করুন'
                                : activeVariant
                                ? activeVariant.label
                                : product.unit}
                            </span>
                            {!isOut && currentBusiness.homePageScarcityStockEnabled !== false && (
                              <span className="text-[#c30000] font-bold shrink-0">
                                মাত্র {getMarketingUrgencyStock(product, available)} টি বাকি
                              </span>
                            )}
                          </div>
                        )}
                        <h3
                          onClick={() => openQuickView(product)}
                          className={`sf-home-product-title text-xs sm:text-sm font-extrabold text-slate-900 group-hover:text-emerald-800 leading-snug cursor-pointer ${
                            currentBusiness.showFullProductNameOnCards
                              ? 'break-words'
                              : 'line-clamp-2 min-h-[34px] sm:min-h-[40px]'
                          }`}
                        >
                          {language === 'bn' ? product.nameBn : product.nameEn}
                        </h3>

                        {/* Interactive Product Variation Selector Buttons (Shown on Home Page cards only when showVariantsOnHomePage is ON) */}
                        {showVariantsOnHomePage && product.variants && product.variants.length > 0 && (
                          <div className="flex flex-wrap gap-1 pt-0.5">
                            {product.variants.map(v => {
                              const isVarOut = Boolean(v.outOfStock);
                              const isDualCard = hasDualColorAndSizeVariants(product);
                              const isColorPill = isDualCard && v.type === 'color';
                              const isSelected =
                                !isVarOut &&
                                (isColorPill
                                  ? selectedColorByProduct[product.id] === v.id
                                  : isVariantSelectionRequired || isDualCard
                                  ? selectedVariantByProduct[product.id] === v.id
                                  : activeVariant?.id === v.id);
                              return (
                                <button
                                  key={v.id}
                                  type="button"
                                  onClick={() => {
                                    if (isVarOut) {
                                      showToast(
                                        `দুঃখিত, "${v.label}" বর্তমানে স্টকে নেই (স্টক শেষ)!`,
                                        'error'
                                      );
                                      return;
                                    }
                                    if (isColorPill) {
                                      setSelectedColorByProduct(prev => ({
                                        ...prev,
                                        [product.id]: v.id
                                      }));
                                    } else {
                                      setSelectedVariantByProduct(prev => ({
                                        ...prev,
                                        [product.id]: v.id
                                      }));
                                    }
                                  }}
                                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                                    isVarOut
                                      ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-75'
                                      : isSelected
                                      ? isColorPill
                                        ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                        : 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                      : isColorPill
                                      ? 'bg-rose-50/70 text-rose-900 border-rose-200 hover:border-rose-500'
                                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-emerald-500'
                                  }`}
                                >
                                  {isColorPill ? `🎨 ${v.label}` : v.label}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Price + Dual Action Buttons: 1) অর্ডার করুন (Direct Checkout) + 2) ব্যাগে যোগ / Stepper */}
                    <div className="px-2.5 pb-2.5 pt-1 sm:px-3.5 sm:pb-3.5 sm:pt-1 space-y-1.5">
                      {/* Retail Price Row (Wholesale hidden on storefront) */}
                      <div className="flex items-baseline gap-2 pb-0.5">
                        <span className="font-mono font-black text-lg sm:text-xl text-emerald-700 tabular-nums leading-none">
                          ৳{activeRetailPrice}
                        </span>
                        {mrpPrice > activeRetailPrice && (
                          <span className="font-mono font-semibold text-xs sm:text-sm text-slate-400 line-through tabular-nums leading-none">
                            ৳{mrpPrice}
                          </span>
                        )}
                      </div>

                      {/* Primary "অর্ডার করুন / স্টক নেই" Button */}
                      <button
                        type="button"
                        disabled={isOut}
                        onClick={() => handleDirectOrderNow(product, 1, activeVariant)}
                        className={`w-full min-h-[38px] py-1.5 px-2 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                          isOut
                            ? 'sf-stock-out-btn bg-slate-200 text-slate-500 border border-slate-200/90 cursor-not-allowed'
                            : 'bg-[#c30000] hover:bg-[#9e0000] text-white shadow-2xs cursor-pointer active:scale-[0.98]'
                        }`}
                      >
                        <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                        <span>{isOut ? 'স্টক নেই' : language === 'bn' ? 'অর্ডার করুন' : 'Order Now'}</span>
                      </button>

                      {/* Secondary "+ ব্যাগে যোগ করুন" or Quantity Stepper (Controlled by showAddToBagOnHomePage) */}
                      {showAddToBagOnHomePage &&
                        (inCartQty === 0 ? (
                          <button
                            type="button"
                            disabled={isOut}
                            onClick={() => addToCart(product, 1, false, activeVariant)}
                            className="w-full min-h-[34px] py-1 px-2 bg-emerald-50/90 hover:bg-emerald-100 disabled:opacity-55 text-emerald-900 border border-emerald-200/90 font-bold text-[11px] rounded-xl flex items-center justify-center gap-1 transition-colors cursor-pointer disabled:cursor-not-allowed"
                          >
                            <Plus className="w-3.5 h-3.5 text-emerald-700" />
                            <span>{language === 'bn' ? 'ব্যাগে যোগ করুন' : 'Add to Bag'}</span>
                          </button>
                        ) : (
                          <div className="w-full min-h-[34px] flex items-center justify-between bg-emerald-800 text-white rounded-xl px-1.5 py-0.5">
                            <button
                              type="button"
                              onClick={() => addToCart(product, -1, true, activeVariant)}
                              className="w-7 h-6 flex items-center justify-center rounded-lg hover:bg-emerald-700 cursor-pointer"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="font-mono font-bold text-xs tabular-nums">
                              {inCartQty} টি ব্যাগে
                            </span>
                            <button
                              type="button"
                              onClick={() => addToCart(product, 1, true, activeVariant)}
                              className="w-7 h-6 flex items-center justify-center rounded-lg hover:bg-emerald-700 cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Smart Hybrid Infinite Scroll Sentinel + Manual "আরও প্রোডাক্ট দেখুন" Fallback Bar */}
            {hasMoreProductsToLoad && (
              <div
                ref={loadMoreSentinelRef}
                className="pt-5 pb-2 flex flex-col items-center justify-center gap-2.5 text-center"
              >
                <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-[11px] font-bold text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
                  <span>
                    মোট {toBanglaCountdownDigits(filteredProducts.length, 1)}টি পণ্যের মধ্যে{' '}
                    {toBanglaCountdownDigits(displayedProducts.length, 1)}টি দেখানো হচ্ছে
                  </span>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setVisibleProductsCount(prev =>
                        Math.min(filteredProducts.length, prev + homeProductsPerBatch)
                      )
                    }
                    className={`px-5 py-2.5 rounded-xl font-extrabold text-xs sm:text-sm text-white shadow-sm cursor-pointer transition-all active:scale-95 inline-flex items-center gap-2 ${
                      isCoolBluePalette
                        ? 'bg-sky-700 hover:bg-sky-800'
                        : 'bg-emerald-700 hover:bg-emerald-800'
                    }`}
                  >
                    <span>
                      আরও প্রোডাক্ট দেখুন (+
                      {toBanglaCountdownDigits(
                        Math.min(
                          homeProductsPerBatch,
                          filteredProducts.length - displayedProducts.length
                        ),
                        1
                      )}
                      টি)
                    </span>
                    <ChevronDown className="w-4 h-4" />
                  </button>

                  {filteredProducts.length - displayedProducts.length > homeProductsPerBatch && (
                    <button
                      type="button"
                      onClick={() => setVisibleProductsCount(filteredProducts.length)}
                      className="px-3.5 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs cursor-pointer transition-colors"
                    >
                      সবগুলো একসাথে দেখুন ({toBanglaCountdownDigits(filteredProducts.length, 1)}টি)
                    </button>
                  )}
                </div>
              </div>
            )}
            </>
          )}
        </section>
          </>
        )}
      </main>

      {/* 6. Floating Desktop Right Cart Widget (Chaldal / DokanGhor Style) */}
      {isHomeFloatingBarEnabled && totalCartItems > 0 && (
        <button
          type="button"
          onClick={openCartDrawer}
          className="hidden lg:flex fixed right-0 top-1/2 -translate-y-1/2 z-30 flex-col items-center bg-[#006A4E] hover:bg-[#005840] text-white rounded-l-2xl shadow-xl border-2 border-r-0 border-amber-400 overflow-hidden cursor-pointer transition-transform hover:scale-105"
        >
          <div className="px-3.5 py-2.5 flex flex-col items-center gap-1">
            <ShoppingBag className="w-5 h-5 text-amber-300" />
            <span className="text-xs font-extrabold">{totalCartItems} টি পণ্য</span>
          </div>
          <div className="w-full bg-amber-400 text-slate-950 px-3.5 py-1.5 font-mono font-extrabold text-xs tabular-nums">
            {formatCurrency(cartSubtotal)}
          </div>
        </button>
      )}

      {/* 6.2. Admin-Only Quick Spin Wheel Config & Test Bar (Controlled by Home Page Floating Bar ON/OFF — Placed on bottom-right so it never overlaps bottom-left Recent Sales Popup) */}
      {isHomeFloatingBarEnabled && isAuthenticated && !isCheckoutModalOpen && !confirmedOrder && !quickViewProduct && (
        <div className="fixed right-3 bottom-3.5 z-30 flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setIsSpinWheelModalOpen(true)}
            className="px-3 py-1.5 rounded-full bg-white hover:bg-amber-50 text-slate-900 border-2 border-amber-400 shadow-lg text-[11px] font-extrabold flex items-center gap-1.5 cursor-pointer transition-transform hover:scale-105"
            title="অ্যাডমিন প্রিভিউ: স্পিন দ্য হুইল পপআপ দেখুন"
          >
            <Gift className="w-3.5 h-3.5 text-[#c30000]" />
            <span>🎡 স্পিন হুইল প্রিভিউ</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setSpinAdminModalTab('settings');
              setIsSpinLeadsModalOpen(true);
            }}
            className="px-2.5 py-1.5 rounded-full bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-lg text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
            title="অ্যাডমিন: স্পিন হুইলের লেখা, পুরস্কার ও নাম্বার তালিকা সেটিংস"
          >
            <Edit3 className="w-3 h-3" />
            <span>কাস্টমাইজ ({allSpinWheelLeads.length})</span>
          </button>
          <button
            type="button"
            onClick={() => {
              updateBusiness({ homeFloatingBarEnabled: false });
              showToast(
                'হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করা হয়েছে! (সেটিংস বা ইনভেন্টরি থেকে আবার ON করতে পারবেন)',
                'info'
              );
            }}
            className="px-2 py-1.5 rounded-full bg-slate-900/90 hover:bg-rose-700 text-white shadow-lg text-[10px] font-extrabold flex items-center gap-1 cursor-pointer"
            title="হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করুন"
          >
            <X className="w-3 h-3" />
            <span>বার OFF</span>
          </button>
        </div>
      )}

      {/* SPIN THE WHEEL INTERACTIVE AUTO-POPUP MODAL (Bright, Attractive Light Design + Configurable Texts/Prizes + 7-Day/1-Day Cooldown) */}
      {isSpinWheelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/50 backdrop-blur-xs animate-page-rise overflow-y-auto">
          <div className="relative bg-gradient-to-b from-[#FFFDF9] via-[#FFF7ED] to-[#FDF2F8] text-slate-900 rounded-3xl max-w-md w-full p-4 sm:p-6 border-2 border-amber-300 shadow-[0_24px_65px_rgba(195,0,0,0.18)] space-y-3.5 text-center overflow-hidden my-auto max-h-[94vh] overflow-y-auto">
            {/* Soft Light Decorative Glows */}
            <div className="pointer-events-none absolute -top-16 -left-16 w-40 h-40 rounded-full bg-amber-300/30 blur-2xl" />
            <div className="pointer-events-none absolute -bottom-16 -right-16 w-40 h-40 rounded-full bg-rose-300/30 blur-2xl" />

            {/* Close (X) Button for Customers who don't want to spin */}
            <button
              type="button"
              onClick={handleCloseSpinWheelModal}
              className="absolute top-3.5 right-3.5 z-20 p-1.5 rounded-full bg-white hover:bg-rose-50 text-slate-600 hover:text-[#c30000] border border-slate-200 shadow-2xs cursor-pointer transition-colors"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Editable Header Badge, Title & Subtitle (Cooldown days text hidden per user request) */}
            <div className="relative z-10 space-y-1.5 pt-1">
              <div className="flex flex-wrap items-center justify-center gap-1.5 pb-0.5">
                <div className="spin-badge-focus-wrapper">
                  <span className="relative z-10 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full spin-badge-focus-inner btn-premium-shine text-white text-xs sm:text-[13px] font-extrabold tracking-wide shadow-sm">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-200 animate-spin shrink-0 relative z-10" />
                    <span className="relative z-10 drop-shadow-xs">{spinWheelConfig.badgeText}</span>
                    <Gift className="w-3.5 h-3.5 text-amber-200 animate-bounce shrink-0 relative z-10" />
                  </span>
                </div>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-snug pt-0.5">
                {spinWheelConfig.titleText}
              </h3>
              <p className="text-xs text-slate-600 font-semibold leading-relaxed max-w-sm mx-auto">
                {spinWheelConfig.subtitleText}
              </p>
            </div>

            {/* Bright Festive Animated Wheel Container */}
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 mx-auto my-2 flex items-center justify-center">
              {/* Outer Ambient Colorful Glow */}
              <div className="pointer-events-none absolute -inset-2 rounded-full bg-gradient-to-r from-rose-500/25 via-amber-400/30 to-violet-500/25 blur-xl animate-pulse" />

              {/* Top Pointer Arrow with Tick Animation while Spinning */}
              <div
                className={`absolute -top-3.5 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center origin-top ${
                  isWheelSpinning ? 'animate-wheel-pointer-tick' : ''
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-gradient-to-b from-amber-300 to-amber-500 border-2 border-white shadow-md -mb-1.5 z-10" />
                <div className="w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[28px] border-t-[#e11d48] drop-shadow-[0_4px_8px_rgba(225,29,72,0.5)]" />
              </div>

              {/* Outer Golden Casino Rim with 16 Animated Blinking LED Bulbs */}
              <div className="w-full h-full rounded-full p-3 bg-gradient-to-tr from-amber-500 via-yellow-300 to-rose-500 shadow-[0_14px_38px_rgba(225,29,72,0.28)] border-4 border-white relative flex items-center justify-center">
                {Array.from({ length: 16 }).map((_, dotIdx) => (
                  <div
                    key={dotIdx}
                    className="absolute inset-1 pointer-events-none flex justify-center items-start"
                    style={{ transform: `rotate(${dotIdx * 22.5}deg)` }}
                  >
                    <span
                      className={`w-2.5 h-2.5 rounded-full border border-white/80 ${
                        dotIdx % 2 === 0
                          ? 'bg-yellow-200 animate-wheel-led-even'
                          : 'bg-rose-500 animate-wheel-led-odd'
                      }`}
                    />
                  </div>
                ))}

                {/* Rotating Wheel Circle */}
                <div
                  className="w-full h-full rounded-full border-4 border-white shadow-inner relative overflow-hidden"
                  style={{
                    transform: `rotate(${wheelRotationDeg}deg)`,
                    transition: isWheelSpinning
                      ? 'transform 4.1s cubic-bezier(0.14, 0.85, 0.18, 1)'
                      : 'none',
                    background: `conic-gradient(${SPIN_WHEEL_SLICES.map((slice, idx) => {
                      const sliceAngle = 360 / SPIN_WHEEL_SLICES.length;
                      const startDeg = idx * sliceAngle;
                      const endDeg = (idx + 1) * sliceAngle;
                      return `${slice.color} ${startDeg}deg ${endDeg}deg`;
                    }).join(', ')})`
                  }}
                >
                  {/* Subtle Glossy Overlay on Wheel */}
                  <div
                    className="pointer-events-none absolute inset-0 rounded-full"
                    style={{
                      background:
                        'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.22) 0%, transparent 60%)'
                    }}
                  />

                  {/* Slice Divider Lines */}
                  {SPIN_WHEEL_SLICES.map((slice, idx) => {
                    const sliceAngle = 360 / SPIN_WHEEL_SLICES.length;
                    return (
                      <div
                        key={`line_${slice.id}_${idx}`}
                        className="absolute top-0 bottom-1/2 left-1/2 w-[2px] -translate-x-1/2 bg-white/75 origin-bottom pointer-events-none"
                        style={{ transform: `rotate(${idx * sliceAngle}deg)` }}
                      />
                    );
                  })}

                  {/* Slice Prize Labels */}
                  {SPIN_WHEEL_SLICES.map((slice, idx) => {
                    const sliceAngle = 360 / SPIN_WHEEL_SLICES.length;
                    const angle = idx * sliceAngle + sliceAngle / 2;
                    return (
                      <div
                        key={slice.id || idx}
                        className="absolute inset-0 flex justify-center items-start pt-4 sm:pt-5 pointer-events-none"
                        style={{ transform: `rotate(${angle}deg)` }}
                      >
                        <span className="px-2.5 py-0.5 rounded-full bg-white/95 text-slate-900 border border-amber-300 font-extrabold text-[10px] sm:text-[11px] tracking-tight shadow-sm max-w-[92px] truncate">
                          {slice.shortLabel}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Center Hub Spin Button */}
              <button
                type="button"
                disabled={isWheelSpinning || hasSpunInCooldownOnDevice}
                onClick={handleTriggerSpinWheel}
                className="absolute z-20 w-15 h-15 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-white via-amber-50 to-amber-200 text-[#c30000] font-extrabold text-xs border-4 border-amber-400 flex flex-col items-center justify-center cursor-pointer active:scale-95 disabled:opacity-75 disabled:cursor-not-allowed animate-spin-hub-pulse"
              >
                <Gift className="w-4 h-4 text-[#e11d48] -mb-0.5" />
                <span className="text-[10px] font-black tracking-wider">
                  {isWheelSpinning ? '...' : hasSpunInCooldownOnDevice ? 'DONE' : 'SPIN'}
                </span>
              </button>
            </div>

            {/* Required Name & Mobile Number Form (Clean Light Card) */}
            {!hasSpunInCooldownOnDevice && (
              <div className="relative z-10 bg-white border-2 border-amber-200/90 rounded-2xl p-3.5 text-left space-y-2.5 shadow-xs">
                <p className="text-xs font-extrabold text-[#c30000] text-center flex items-center justify-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span>স্পিন করতে আপনার নাম ও মোবাইল নাম্বার দিন:</span>
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-extrabold text-slate-700 mb-1">
                      আপনার নাম <span className="text-[#c30000]">*</span>
                    </label>
                    <input
                      ref={spinNameInputRef}
                      type="text"
                      value={spinLeadName}
                      disabled={isWheelSpinning}
                      onChange={e => {
                        setSpinLeadName(e.target.value);
                        if (spinFormError) setSpinFormError(null);
                      }}
                      placeholder="আপনার নাম লিখুন"
                      className="w-full px-3 py-2 rounded-xl bg-amber-50/40 focus:bg-white border border-slate-300 focus:border-[#c30000] text-slate-900 placeholder-slate-400 text-xs font-bold outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-extrabold text-slate-700 mb-1">
                      মোবাইল নাম্বার (১১ ডিজিট) <span className="text-[#c30000]">*</span>
                    </label>
                    <input
                      ref={spinPhoneInputRef}
                      type="tel"
                      inputMode="numeric"
                      maxLength={14}
                      value={spinLeadPhone}
                      disabled={isWheelSpinning}
                      onChange={e => {
                        setSpinLeadPhone(e.target.value);
                        if (spinFormError) setSpinFormError(null);
                      }}
                      placeholder="017XXXXXXXX"
                      className="w-full px-3 py-2 rounded-xl bg-amber-50/40 focus:bg-white border border-slate-300 focus:border-[#c30000] text-slate-900 placeholder-slate-400 text-xs font-mono font-extrabold outline-none transition-colors"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Inline Error or Cooldown Notice */}
            {spinFormError && (
              <div className="relative z-10 p-2.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs font-extrabold leading-relaxed">
                ⚠️ {spinFormError}
              </div>
            )}

            {/* Won Prize Banner or Colorful Animated "স্পিন করুন" CTA + Security Note */}
            {hasSpunInCooldownOnDevice && dailySpinRecord ? (
              <div className="relative z-10 p-4 rounded-2xl bg-gradient-to-br from-emerald-50 via-white to-amber-50 border-2 border-emerald-400 shadow-sm space-y-2">
                <p className="text-xs font-extrabold text-emerald-800">
                  🎉 অভিনন্দন {dailySpinRecord.name || spinLeadName}! আপনার স্পিন ফলাফল:
                </p>
                <p className="text-base sm:text-lg font-extrabold text-[#c30000]">
                  🎁 {dailySpinRecord.reward.label}{' '}
                  {dailySpinRecord.reward.type !== 'none' &&
                    `(কুপন: ${dailySpinRecord.reward.code})`}
                </p>
                {dailySpinRecord.reward.type !== 'none' && (
                  dailySpinRecord.used || !claimedSpinReward ? (
                    <p className="text-[11px] font-bold text-amber-800 bg-amber-100/80 border border-amber-300 rounded-lg px-2.5 py-1.5">
                      ✓ আপনি আপনার অর্ডারে{dailySpinRecord.usedOrderNo ? ` (#${dailySpinRecord.usedOrderNo})` : ''} এই স্পিন অফারটি ইতিমধ্যে ব্যবহার করেছেন। (স্পিন অফার শুধুমাত্র ১টি অর্ডারেই প্রযোজ্য)
                    </p>
                  ) : (
                    <p className="text-[11px] font-semibold text-slate-600">
                      এখনই অর্ডার করুন! চেকআউট বিলে এই ছাড়টি স্বয়ংক্রিয়ভাবে যুক্ত হবে।
                    </p>
                  )
                )}
                <div className="pt-1.5">
                  {dailySpinRecord.used || !claimedSpinReward ? (
                    <button
                      type="button"
                      onClick={handleCloseSpinWheelModal}
                      className="w-full py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs cursor-pointer shadow-md transition-colors"
                    >
                      ঠিক আছে, বন্ধ করুন
                    </button>
                  ) : (
                    <div className="spin-reward-beam-wrapper">
                      <button
                        type="button"
                        onClick={handleCloseSpinWheelModal}
                        className="group relative z-10 w-full py-3 px-5 rounded-[13.5px] btn-spin-reward-cta btn-premium-shine text-white font-extrabold text-sm sm:text-base cursor-pointer active:scale-[0.98] transition-all flex items-center justify-center gap-2.5"
                      >
                        <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-200 shrink-0 animate-bounce relative z-10" />
                        <span className="relative z-10 tracking-wide drop-shadow-xs">
                          {spinWheelConfig.claimButtonText}
                        </span>
                        <span className="relative z-10 w-7 h-7 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-sm group-hover:translate-x-1 transition-transform shrink-0">
                          <ArrowRight className="w-4 h-4 stroke-[2.75]" />
                        </span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="relative z-10 space-y-2.5 pt-0.5">
                <button
                  type="button"
                  disabled={isWheelSpinning}
                  onClick={handleTriggerSpinWheel}
                  className="group relative w-full py-3.5 px-6 rounded-2xl animate-spin-colorful-btn text-white font-extrabold text-base sm:text-lg shadow-[0_12px_28px_-6px_rgba(225,29,72,0.55)] hover:shadow-[0_16px_34px_-6px_rgba(225,29,72,0.7)] border border-white/30 cursor-pointer transition-all active:scale-[0.98] disabled:opacity-65 overflow-hidden flex items-center justify-center gap-3"
                >
                  {/* Animated Shimmer Sweep */}
                  <span className="pointer-events-none absolute inset-y-0 w-24 bg-gradient-to-r from-transparent via-white/35 to-transparent animate-spin-btn-shimmer" />
                  <Sparkles className="w-5 h-5 text-yellow-200 shrink-0 animate-pulse relative z-10" />
                  <span className="relative z-10 tracking-wide drop-shadow-xs">
                    {isWheelSpinning ? 'চাকা ঘুরছে...' : 'স্পিন করুন'}
                  </span>
                  <span className="relative z-10 w-8 h-8 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-md group-hover:translate-x-1 transition-transform shrink-0">
                    <ArrowRight className="w-4 h-4 stroke-[2.75]" />
                  </span>
                </button>

                {/* Security & Verification Note Below Spin Button (Matches Reference Screenshot) */}
                <div className="flex items-center justify-center gap-1.5 text-[11px] sm:text-xs font-bold text-slate-600 px-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>আপনার নাম ও ফোন নম্বর পুরস্কার যাচাই করতে ব্যবহার করা হবে।</span>
                </div>

                <button
                  type="button"
                  onClick={handleCloseSpinWheelModal}
                  className="w-full py-1 text-[11px] font-bold text-slate-400 hover:text-slate-700 cursor-pointer transition-colors"
                >
                  এখন নয়, ধন্যবাদ — বন্ধ করুন
                </button>
              </div>
            )}

            {/* Admin Controls inside Spin Modal (Customize Texts/Prizes, View Stored Numbers & Reset Lock) */}
            {isAuthenticated && (
              <div className="relative z-10 pt-2.5 border-t border-amber-200/80 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setIsSpinWheelModalOpen(false);
                      setSpinAdminModalTab('settings');
                      setIsSpinLeadsModalOpen(true);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 font-extrabold flex items-center gap-1 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>হুইল ও লেখা এডিট</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsSpinWheelModalOpen(false);
                      setSpinAdminModalTab('leads');
                      setIsSpinLeadsModalOpen(true);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-950 border border-emerald-300 font-extrabold flex items-center gap-1 cursor-pointer"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>নাম্বার তালিকা ({allSpinWheelLeads.length})</span>
                  </button>
                </div>
                <button
                  type="button"
                  onClick={handleResetTodaySpinLockForAdmin}
                  className="px-2.5 py-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 border border-rose-300 text-rose-800 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>টেস্ট রিসেট</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ADMIN MODAL: CUSTOMIZE SPIN WHEEL TEXTS/PRIZES & VIEW STORED CUSTOMER NUMBERS */}
      {isSpinLeadsModalOpen && isAuthenticated && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-page-rise">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col border border-slate-200 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-[#FFFDF9] via-amber-50 to-rose-50 border-b border-amber-200 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <Gift className="w-5 h-5 text-[#c30000]" />
                  <span>স্পিন দ্য হুইল কন্ট্রোল প্যানেল — লেখা, পুরস্কার ও কাস্টমার নাম্বার তালিকা</span>
                </h3>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  হুইলে কী কী ছাড় থাকবে, টাইটেল/সাব-টাইটেল লেখা এবং কতদিন পর পর পপআপ আসবে তা এখান থেকে কাস্টমাইজ করুন
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsSpinLeadsModalOpen(false)}
                className="p-1.5 rounded-xl bg-white hover:bg-rose-50 text-slate-600 border border-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs: 1) Customize Texts & Prizes  2) Stored Customer Numbers */}
            <div className="px-4 pt-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSpinAdminModalTab('settings')}
                  className={`px-4 py-2 rounded-t-xl text-xs font-extrabold border border-b-0 cursor-pointer transition-colors ${
                    spinAdminModalTab === 'settings'
                      ? 'bg-white text-[#c30000] border-slate-200'
                      : 'bg-slate-100 text-slate-600 border-transparent hover:bg-slate-200/70'
                  }`}
                >
                  🎨 হুইল লেখা ও পুরস্কার সেটিংস
                </button>
                <button
                  type="button"
                  onClick={() => setSpinAdminModalTab('leads')}
                  className={`px-4 py-2 rounded-t-xl text-xs font-extrabold border border-b-0 cursor-pointer transition-colors ${
                    spinAdminModalTab === 'leads'
                      ? 'bg-white text-emerald-800 border-slate-200'
                      : 'bg-slate-100 text-slate-600 border-transparent hover:bg-slate-200/70'
                  }`}
                >
                  📞 কাস্টমার নাম ও নাম্বার তালিকা ({allSpinWheelLeads.length})
                </button>
              </div>

              <div className="flex items-center gap-2 pb-2">
                <button
                  type="button"
                  onClick={() => {
                    const nextOn = currentBusiness.spinWheelEnabled === false;
                    updateBusiness({ spinWheelEnabled: nextOn });
                    showToast(
                      nextOn
                        ? 'স্পিন দ্য হুইল চালু (ON) করা হয়েছে!'
                        : 'স্পিন দ্য হুইল বন্ধ (OFF) করা হয়েছে!',
                      nextOn ? 'success' : 'info'
                    );
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer ${
                    currentBusiness.spinWheelEnabled !== false
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-slate-200 text-slate-700 border-slate-300'
                  }`}
                >
                  স্ট্যাটাস: {currentBusiness.spinWheelEnabled !== false ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                </button>
              </div>
            </div>

            {spinAdminModalTab === 'settings' ? (
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs">
                {/* Section 1: Texts & Timing */}
                <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-3.5">
                  <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">
                    ১. পপআপের লেখা ও অটো-পপআপ সময় নির্ধারণ:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        উপরের ব্যাজ টেক্সট:
                      </label>
                      <input
                        type="text"
                        value={spinDraftBadge}
                        onChange={e => setSpinDraftBadge(e.target.value)}
                        placeholder="স্পেশাল লাকি ডিসকাউন্ট হুইল"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        কত সেকেন্ড পর অটো ভেসে উঠবে?
                      </label>
                      <select
                        value={spinDraftDelaySec}
                        onChange={e => setSpinDraftDelaySec(Number(e.target.value) || 4)}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                      >
                        <option value={2}>২ সেকেন্ড পর</option>
                        <option value={4}>৪ সেকেন্ড পর (প্রস্তাবিত)</option>
                        <option value={6}>৬ সেকেন্ড পর</option>
                        <option value={10}>১০ সেকেন্ড পর</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        একজন কাস্টমারকে কতদিনে ১ বার দেখাবে?
                      </label>
                      <select
                        value={spinDraftCooldownDays}
                        onChange={e => setSpinDraftCooldownDays(Number(e.target.value) || 7)}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-emerald-900"
                      >
                        <option value={7}>৭ দিনে ১ বার (প্রস্তাবিত — বারবার বিরক্ত করবে না)</option>
                        <option value={3}>৩ দিনে ১ বার</option>
                        <option value={1}>১ দিনে ১ বার</option>
                        <option value={15}>১৫ দিনে ১ বার</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        মূল শিরোনাম (Main Title):
                      </label>
                      <input
                        type="text"
                        value={spinDraftTitle}
                        onChange={e => setSpinDraftTitle(e.target.value)}
                        placeholder="স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        সাব-টাইটেল / বিবরণ (Subtitle):
                      </label>
                      <input
                        type="text"
                        value={spinDraftSubtitle}
                        onChange={e => setSpinDraftSubtitle(e.target.value)}
                        placeholder="চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-semibold text-slate-800"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-bold text-slate-700 mb-1">
                        পুরস্কার গ্রহণের বাটন টেক্সট (Claim Button Text):
                      </label>
                      <input
                        type="text"
                        value={spinDraftClaimBtnText}
                        onChange={e => setSpinDraftClaimBtnText(e.target.value)}
                        placeholder="অফারটি গ্রহণ করে অর্ডার করুন"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-rose-700"
                      />
                    </div>
                  </div>
                </div>

                {/* Section 2: Wheel Slices / Prizes */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">
                        ২. স্পিন হুইলে কী কী পুরস্কার থাকবে ({spinDraftSlices.length} টি স্লাইস):
                      </h4>
                      <p className="text-[11px] text-slate-600 font-semibold mt-0.5">
                        🔓 আনলক ({spinDraftSlices.filter(s => !s.locked).length}টি): কাস্টমার স্পিন করলে বারবার পাবে • 🔒 লক ({spinDraftSlices.filter(s => s.locked).length}টি): চাকায় লেখা থাকবে আগ্রহ বাড়ানোর জন্য, কিন্তু কেউ পাবে না
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setSpinDraftSlices(DEFAULT_SPIN_WHEEL_SLICES.map(s => ({ ...s })))
                        }
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold cursor-pointer"
                      >
                        ডিফল্ট ৬টি পুরস্কার (৪ আনলক, ২ লক)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setSpinDraftSlices(prev => [
                            ...prev,
                            {
                              id: `sw_${Date.now()}`,
                              label: '৳৪০ স্পেশাল ছাড়',
                              shortLabel: '৳৪০ ছাড়',
                              type: 'flat',
                              value: 40,
                              color: '#e11d48',
                              code: 'SPIN40',
                              locked: false
                            }
                          ])
                        }
                        className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold cursor-pointer"
                      >
                        + নতুন পুরস্কার যোগ করুন
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {spinDraftSlices.map((slice, sIdx) => (
                      <div
                        key={slice.id || sIdx}
                        className={`p-2.5 rounded-xl border grid grid-cols-1 sm:grid-cols-12 gap-2 items-center ${
                          slice.locked
                            ? 'bg-rose-50/50 border-rose-200'
                            : 'bg-white border-slate-200'
                        }`}
                      >
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            চাকার ছোট লেখা
                          </label>
                          <input
                            type="text"
                            value={slice.shortLabel}
                            onChange={e => {
                              const val = e.target.value;
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, shortLabel: val } : it))
                              );
                            }}
                            placeholder="যেমন: ৳৫০ ছাড়"
                            className="w-full p-2 border border-slate-300 rounded-lg font-extrabold text-slate-900 bg-white"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            পুরস্কারের পূর্ণ নাম
                          </label>
                          <input
                            type="text"
                            value={slice.label}
                            onChange={e => {
                              const val = e.target.value;
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, label: val } : it))
                              );
                            }}
                            placeholder="যেমন: ৳৫০ ডিসকাউন্ট"
                            className="w-full p-2 border border-slate-300 rounded-lg font-semibold text-slate-800 bg-white"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            ছাড়ের ধরন
                          </label>
                          <select
                            value={slice.type}
                            onChange={e => {
                              const nextType = e.target.value as SpinWheelSliceConfig['type'];
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) =>
                                  i === sIdx
                                    ? {
                                        ...it,
                                        type: nextType,
                                        value:
                                          nextType === 'free_delivery' || nextType === 'none'
                                            ? 0
                                            : it.value || 20
                                      }
                                    : it
                                )
                              );
                            }}
                            className="w-full p-2 border border-slate-300 rounded-lg font-bold text-slate-800 bg-white"
                          >
                            <option value="flat">টাকা ছাড় (৳)</option>
                            <option value="percent">শতাংশ ছাড় (%)</option>
                            <option value="free_delivery">ফ্রি ডেলিভারি</option>
                            <option value="none">শুভকামনা (ছাড় নেই)</option>
                          </select>
                        </div>
                        <div className="sm:col-span-1">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            পরিমাণ
                          </label>
                          <input
                            type="number"
                            min={0}
                            disabled={slice.type === 'free_delivery' || slice.type === 'none'}
                            value={slice.value}
                            onChange={e => {
                              const val = Number(e.target.value) || 0;
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, value: val } : it))
                              );
                            }}
                            className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white disabled:bg-slate-100"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            লক / আনলক স্ট্যাটাস
                          </label>
                          <button
                            type="button"
                            onClick={() =>
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) =>
                                  i === sIdx ? { ...it, locked: !it.locked } : it
                                )
                              )
                            }
                            className={`w-full px-2.5 py-2 rounded-lg text-[11px] font-extrabold border flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                              slice.locked
                                ? 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200'
                                : 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200'
                            }`}
                            title={
                              slice.locked
                                ? 'লক করা: চাকায় শুধু দেখাবে, কিন্তু কেউ পাবে না'
                                : 'আনলক করা: কাস্টমার স্পিন করলে এই অফার পাবে'
                            }
                          >
                            <span>{slice.locked ? '🔒 লক (পাবে না)' : '🔓 আনলক (পাবে)'}</span>
                          </button>
                        </div>
                        <div className="sm:col-span-2 flex items-end gap-1.5 pt-3 sm:pt-4">
                          <input
                            type="text"
                            value={slice.code}
                            onChange={e => {
                              const val = e.target.value.toUpperCase();
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, code: val } : it))
                              );
                            }}
                            placeholder="CODE"
                            className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold uppercase bg-white"
                          />
                          <input
                            type="color"
                            value={slice.color}
                            onChange={e => {
                              const val = e.target.value;
                              setSpinDraftSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, color: val } : it))
                              );
                            }}
                            className="w-8 h-8 rounded cursor-pointer border border-slate-300 shrink-0"
                            title="স্লাইসের রঙ"
                          />
                          <button
                            type="button"
                            disabled={spinDraftSlices.length <= 2}
                            onClick={() =>
                              setSpinDraftSlices(prev => prev.filter((_, i) => i !== sIdx))
                            }
                            className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 disabled:opacity-40 cursor-pointer shrink-0"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => {
                      handleSaveSpinWheelAdminSettings();
                      handleResetTodaySpinLockForAdmin();
                      setIsSpinLeadsModalOpen(false);
                      setIsSpinWheelModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs cursor-pointer shadow-xs"
                  >
                    🎡 সেভ করে এখনই পপআপ প্রিভিউ দেখুন
                  </button>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsSpinLeadsModalOpen(false)}
                      className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold cursor-pointer"
                    >
                      বন্ধ করুন
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveSpinWheelAdminSettings}
                      className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold cursor-pointer shadow-sm"
                    >
                      সেটিংস সংরক্ষণ করুন
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={spinLeadsSearch}
                      onChange={e => setSpinLeadsSearch(e.target.value)}
                      placeholder="নাম বা মোবাইল নাম্বার দিয়ে খুঁজুন..."
                      className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:border-emerald-600"
                    />
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-extrabold">
                      আজকের স্পিন: {allSpinWheelLeads.filter(l => l.dateKey === todayDateKey).length} জন
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (allSpinWheelLeads.length === 0) {
                          showToast('ডাউনলোড করার মতো কোনো স্পিন হুইল ডাটা নেই', 'error');
                          return;
                        }
                        exportToExcel(
                          'Spin_Wheel_Marketing_Leads',
                          'Spin_Wheel_Leads',
                          ['ক্রমিক নং', 'কাস্টমারের নাম', 'মোবাইল নাম্বার', 'প্রাপ্ত পুরস্কার', 'কুপন কোড', 'তারিখ', 'সময়'],
                          allSpinWheelLeads.map((l, idx) => [
                            idx + 1,
                            l.name || l.customerName || 'কাস্টমার',
                            l.phone || l.customerPhone || '',
                            l.prizeLabel || l.rewardLabel || '',
                            l.prizeCode || l.couponCode || '',
                            l.dateKey || l.spinDateKey || '',
                            formatDate(l.createdAt)
                          ])
                        );
                        showToast(
                          `স্পিন হুইলের ${allSpinWheelLeads.length} জন কাস্টমারের ডাটা Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>১-ক্লিক Excel ডাউনলোড</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (allSpinWheelLeads.length === 0) {
                          showToast('ডাউনলোড করার মতো কোনো স্পিন হুইল ডাটা নেই', 'error');
                          return;
                        }
                        exportToCsv(
                          'Spin_Wheel_Google_Sheet_Leads',
                          ['SL', 'Customer_Name', 'Mobile_Number', 'Prize_Won', 'Coupon_Code', 'Date', 'Created_At'],
                          allSpinWheelLeads.map((l, idx) => [
                            idx + 1,
                            l.name || l.customerName || 'কাস্টমার',
                            l.phone || l.customerPhone || '',
                            l.prizeLabel || l.rewardLabel || '',
                            l.prizeCode || l.couponCode || '',
                            l.dateKey || l.spinDateKey || '',
                            formatDate(l.createdAt)
                          ])
                        );
                        showToast(
                          `স্পিন হুইলের ${allSpinWheelLeads.length} জন কাস্টমারের ডাটা Google Sheet / CSV ফাইলে ডাউনলোড হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Google Sheet (CSV)</span>
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-3 sm:p-4">
                  {(() => {
                    const q = spinLeadsSearch.trim().toLowerCase();
                    const filtered = q
                      ? allSpinWheelLeads.filter(
                          l =>
                            l.name.toLowerCase().includes(q) ||
                            l.phone.toLowerCase().includes(q) ||
                            l.prizeLabel.toLowerCase().includes(q)
                        )
                      : allSpinWheelLeads;

                    if (filtered.length === 0) {
                      return (
                        <div className="py-12 text-center space-y-2">
                          <Gift className="w-10 h-10 text-slate-300 mx-auto" />
                          <p className="text-sm font-bold text-slate-700">
                            এখনো কোনো স্পিন হুইল কাস্টমার নাম্বার পাওয়া যায়নি
                          </p>
                          <p className="text-xs text-slate-500">
                            কাস্টমার নাম ও মোবাইল নাম্বার দিয়ে স্পিন করলেই এখানে সাথে সাথে জমা হবে।
                          </p>
                        </div>
                      );
                    }

                    return filtered.map((lead, idx) => (
                      <div
                        key={lead.id}
                        className="py-3 px-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:bg-slate-50 rounded-xl transition-colors"
                      >
                        <div className="space-y-0.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[11px] font-mono font-bold text-slate-400">
                              #{idx + 1}
                            </span>
                            <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                              {lead.name}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-lg bg-emerald-50 border border-emerald-200 font-mono font-extrabold text-xs text-emerald-800">
                              {lead.phone}
                            </span>
                            <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 font-extrabold text-[11px]">
                              🎁 {lead.prizeLabel} ({lead.prizeCode})
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500">
                            তারিখ: {lead.dateKey} · সময়: {formatDate(lead.createdAt)}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard?.writeText(lead.phone).catch(() => {});
                              showToast(`মোবাইল নাম্বার (${lead.phone}) কপি হয়েছে!`, 'success');
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Copy className="w-3 h-3" /> কপি
                          </button>
                          <a
                            href={`tel:${lead.phone}`}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1"
                          >
                            <PhoneCall className="w-3 h-3" /> কল
                          </a>
                          <button
                            type="button"
                            onClick={() => handleDeleteSpinWheelLead(lead.id)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                            title="ডিলিট করুন (ও আজকের স্পিন লক রিসেট করুন)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ));
                  })()}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 6.5. Home Page Floating 1-Tap Checkout Pill Bar (Visible ONLY on the Home Page — Controlled by Home Page Floating Bar ON/OFF) */}
      {isHomeFloatingBarEnabled && totalCartItems > 0 && !quickViewProduct && !isCheckoutModalOpen && !confirmedOrder && !isCartOpen && !isCustomerAccountOpen && (
        <div className="lg:hidden fixed bottom-3 left-3 right-3 z-30 animate-page-rise">
          {isAuthenticated && (
            <div className="mb-1 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  updateBusiness({ homeFloatingBarEnabled: false });
                  showToast(
                    'হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করা হয়েছে! (সেটিংস বা ইনভেন্টরি থেকে আবার ON করতে পারবেন)',
                    'info'
                  );
                }}
                className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-rose-700 text-white text-[10px] font-extrabold border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer"
                title="হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করুন"
              >
                <X className="w-2.5 h-2.5 text-rose-300" />
                <span>ফ্লোটিং বার: ON (বন্ধ করুন)</span>
              </button>
            </div>
          )}
          <div className="w-full py-2.5 px-3.5 rounded-2xl bg-gradient-to-r from-white via-rose-50/40 to-white backdrop-blur-md text-slate-900 shadow-2xl border-2 border-rose-200/90 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={openCartDrawer}
              className="flex items-center gap-2.5 text-left min-w-0 flex-1 cursor-pointer"
            >
              <span className="w-8 h-8 rounded-xl bg-rose-50 border border-rose-200 font-mono font-extrabold text-xs flex items-center justify-center text-[#c30000] shrink-0">
                {totalCartItems}
              </span>
              <div className="leading-tight min-w-0">
                <p className="text-xs font-extrabold text-slate-900 truncate">
                  ব্যাগে {totalCartItems} টি পণ্য যোগ করা হয়েছে
                </p>
                <p className="text-[11px] text-slate-600 font-mono font-medium">
                  মোট: <strong className="text-[#c30000] font-extrabold">{formatCurrency(cartSubtotal)}</strong> · চেকআউট করুন
                </p>
              </div>
            </button>
            <button
              type="button"
              onClick={() => {
                setDirectBuyItem(null);
                openCheckoutModal();
              }}
              className="px-4 py-2.5 rounded-xl bg-[#c30000] hover:bg-[#9e0000] text-white font-extrabold text-xs flex items-center gap-1.5 shrink-0 shadow-md cursor-pointer transition-colors active:scale-[0.98]"
            >
              <span>অর্ডার কনফার্ম</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 8. Mobile Category Slide-Over Drawer (Customer-Only) */}
      {showMobileCategoryDrawer && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            onClick={() => setShowMobileCategoryDrawer(false)}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
          />
          <div className="relative w-72 max-w-[85vw] bg-white h-full z-10 flex flex-col justify-between shadow-2xl animate-page-rise">
            <div>
              <div className="p-4 sf-theme-topbar bg-gradient-to-r from-[#064E3B] to-[#047857] text-white flex items-center justify-between">
                <span className="font-extrabold text-sm">পণ্যের ক্যাটাগরি সমূহ</span>
                <button
                  type="button"
                  onClick={() => setShowMobileCategoryDrawer(false)}
                  className="p-1 rounded-lg bg-white/10 text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="divide-y divide-slate-100 overflow-y-auto max-h-[75vh]">
                <button
                  type="button"
                  onClick={() => {
                    handleSelectCategory('all');
                    setShowMobileCategoryDrawer(false);
                  }}
                  className="w-full px-4 py-3.5 text-left text-xs font-bold text-emerald-800 bg-emerald-50/50 flex items-center justify-between"
                >
                  <span>সকল পণ্য ({products.filter(p => !p.isLandingPageProduct).length})</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      handleSelectCategory(cat.id);
                      setShowMobileCategoryDrawer(false);
                    }}
                    className="w-full px-4 py-3.5 text-left text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center justify-between"
                  >
                    <span>{cat.nameBn}</span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-emerald-50/60 space-y-2">
              <button
                type="button"
                onClick={() => openCustomerAccountPage('login', false)}
                className="w-full py-2.5 px-3 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-extrabold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
              >
                <UserIcon className="w-3.5 h-3.5 text-emerald-700" />
                <span>
                  {currentCustomerAccount
                    ? `${currentCustomerAccount.name} (অর্ডার হিস্ট্রি)`
                    : 'কাস্টমার লগইন / সাইনআপ'}
                </span>
              </button>

              {currentCustomerAccount && (
                <button
                  type="button"
                  onClick={() => {
                    handleCustomerLogout();
                    setShowMobileCategoryDrawer(false);
                  }}
                  className="w-full py-2.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-extrabold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-600" />
                  <span>লগআউট করুন</span>
                </button>
              )}

              <p className="text-[11px] font-bold text-emerald-950 pt-1">হোম ডেলিভারি হেল্পলাইন:</p>
              <a
                href={`tel:${currentBusiness.phone}`}
                className="w-full py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5"
              >
                <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
                <span className="font-mono">কল করুন: {currentBusiness.phone}</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* 9. Slide-Over Shopping Cart Drawer (Viewport Fixed) */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
          />
          <div className="relative w-full max-w-md bg-white h-full z-10 flex flex-col justify-between shadow-2xl animate-drawer-left">
            <div className="p-4 bg-gradient-to-r from-[#064E3B] to-[#047857] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-300" />
                <span className="font-extrabold text-sm sm:text-base">
                  আপনার শপিং ব্যাগ ({totalCartItems} টি পণ্য)
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {cartEntries.length === 0 ? (
              <div className="p-8 text-center space-y-3 my-auto">
                <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
                <p className="text-sm font-bold text-slate-700">আপনার শপিং ব্যাগটি বর্তমানে খালি</p>
                <p className="text-xs text-slate-500">
                  পছন্দের পণ্যের নিচে "অর্ডার করুন" বা "ব্যাগে যোগ করুন" বাটনে ক্লিক করুন।
                </p>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-4">
                  {cartEntries.map(({ cartKey, product, variant, quantity }) => {
                    const unitPrice = variant ? variant.retailPrice : product.retailPrice;
                    return (
                      <div key={cartKey} className="py-3 flex items-center gap-3">
                        <div className="w-14 h-14 rounded-lg border border-slate-200 overflow-hidden shrink-0">
                          <ProductThumbnail product={product} imgClassName="p-1" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-slate-900 truncate">{product.nameBn}</p>
                          {variant && (
                            <span className="inline-block px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold mt-0.5">
                              {variant.label}
                            </span>
                          )}
                          <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                            ৳{unitPrice} × {quantity} ={' '}
                            <strong className="text-emerald-800">৳{unitPrice * quantity}</strong>
                          </p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <button
                              type="button"
                              onClick={() => addToCart(product, -1, true, variant, true)}
                              className="w-6 h-6 rounded border border-slate-300 flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="font-mono font-bold text-xs w-6 text-center">{quantity}</span>
                            <button
                              type="button"
                              onClick={() => addToCart(product, 1, true, variant, true)}
                              className="w-6 h-6 rounded border border-slate-300 flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFromCart(cartKey)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-3">
                  {/* Offer #7: Flash Free Delivery Banner inside Shopping Bag Drawer */}
                  {!isAdminFreeDeliveryEnabled && isFlashFreeDeliveryActive && (
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-[11px] font-extrabold space-y-0.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[#c30000]">⚡ ফ্ল্যাশ ফ্রি ডেলিভারি চলছে!</span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-700 text-white text-[10px]">
                          ফ্রি (৳০) ✓
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-700">
                        বাকি সময়: <strong className="text-[#c30000]">{flashCountdownLabelBn}</strong>
                      </p>
                    </div>
                  )}

                  {/* Offer #6: Product-Specific Free Delivery Banner inside Shopping Bag Drawer */}
                  {!isAdminFreeDeliveryEnabled &&
                    !isFlashFreeDeliveryActive &&
                    hasFreeDeliveryProductInCart && (
                      <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-[11px] font-extrabold flex items-center gap-1.5">
                        <Truck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>
                          🚚 ফ্রি ডেলিভারি পণ্য কার্টে থাকায় আপনার সম্পূর্ণ অর্ডারে ডেলিভারি ফ্রি (৳০)!
                        </span>
                      </div>
                    )}

                  {/* Offer #1: Minimum Order Amount Free Delivery Animated Progress Bar inside Shopping Bag Drawer */}
                  {!isAdminFreeDeliveryEnabled &&
                    !isFlashFreeDeliveryActive &&
                    !hasFreeDeliveryProductInCart &&
                    isMinAmountFreeDeliveryEnabled && (
                      <div
                        className={`p-2.5 rounded-xl border text-[11px] font-extrabold space-y-1.5 ${
                          isCartMinAmountUnlocked
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                            : 'bg-teal-50/90 border-teal-300 text-teal-950'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span>
                            {isCartMinAmountUnlocked
                              ? `🎉 অভিনন্দন! ৳${freeDeliveryMinOrderAmt.toLocaleString(
                                  'en-IN'
                                )}+ অর্ডারে ডেলিভারি সম্পূর্ণ ফ্রি (৳০)!`
                              : `🚚 আর মাত্র ৳${cartRemainingAmtForFreeDelivery.toLocaleString(
                                  'en-IN'
                                )} টাকার পণ্য যোগ করলেই ডেলিভারি সম্পূর্ণ ফ্রি!`}
                          </span>
                          <span className="font-mono text-[10px] shrink-0">
                            {cartMinAmountProgressPct}%
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-white border border-teal-200 overflow-hidden p-0.5">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isCartMinAmountUnlocked
                                ? 'bg-emerald-600'
                                : 'bg-gradient-to-r from-[#c30000] via-amber-500 to-emerald-600'
                            }`}
                            style={{ width: `${Math.max(8, cartMinAmountProgressPct)}%` }}
                          />
                        </div>
                      </div>
                    )}

                  {/* Smart Quantity-Based Free Delivery Progress inside Shopping Bag Drawer */}
                  {!isAdminFreeDeliveryEnabled &&
                    !isFlashFreeDeliveryActive &&
                    !hasFreeDeliveryProductInCart &&
                    isQtyFreeDeliveryEnabled && (
                    <div
                      className={`p-2.5 rounded-xl border text-[11px] font-extrabold ${
                        isQtyFreeDeliveryUnlocked
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                          : 'bg-amber-50 border-amber-300 text-amber-950'
                      }`}
                    >
                      {isQtyFreeDeliveryUnlocked ? (
                        <div className="flex items-center gap-1.5">
                          <Truck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                          <span>
                            🎉 অভিনন্দন! {toBanglaCountdownDigits(totalCartItems, 1)} পিস অর্ডারে ডেলিভারি সম্পূর্ণ ফ্রি (৳০)!
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2">
                          <span>
                            🚚 আর {toBanglaCountdownDigits(remainingQtyForFreeDelivery, 1)} পিস যোগ করলেই ডেলিভারি ফ্রি! ({toBanglaCountdownDigits(freeDeliveryMinQty, 1)} পিসে ফ্রি)
                          </span>
                          {cartEntries[0] && (
                            <button
                              type="button"
                              onClick={() =>
                                addToCart(
                                  cartEntries[0].product,
                                  remainingQtyForFreeDelivery,
                                  true,
                                  cartEntries[0].variant,
                                  true
                                )
                              }
                              className="px-2 py-1 rounded-lg bg-[#c30000] hover:bg-[#9e0000] text-white text-[10px] font-extrabold shrink-0 cursor-pointer"
                            >
                              + {toBanglaCountdownDigits(remainingQtyForFreeDelivery, 1)} পিস যোগ করুন
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>পণ্যের মোট মূল্য:</span>
                      <span className="font-mono font-bold">{formatCurrency(cartSubtotal)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>
                        ডেলিভারি চার্জ
                        {isFlashFreeDeliveryActive
                          ? ' (⚡ ফ্ল্যাশ অফার)'
                          : hasFreeDeliveryProductInCart
                          ? ' (🚚 ফ্রি ডেলিভারি পণ্য)'
                          : isCartMinAmountUnlocked
                          ? ` (৳${freeDeliveryMinOrderAmt}+ অফার)`
                          : isQtyFreeDeliveryUnlocked
                          ? ` (${toBanglaCountdownDigits(freeDeliveryMinQty, 1)}+ পিস অফার)`
                          : isHalfDeliveryOfferEnabled
                          ? ` (${deliveryDiscountPct}% ছাড়)`
                          : deliveryCharge > 0
                          ? ` (${selectedDeliveryZone === 'outside_dhaka' ? 'ঢাকার বাইরে' : 'ঢাকার ভিতরে'})`
                          : ''}
                        :
                      </span>
                      <span className="font-mono font-bold text-emerald-700">
                        {deliveryCharge === 0 ? (
                          'ফ্রি (৳০)'
                        ) : isHalfDeliveryOfferEnabled && selectedRawZoneFee > deliveryCharge ? (
                          <span className="inline-flex items-center gap-1">
                            <span className="line-through text-slate-400 text-[11px]">
                              ৳{selectedRawZoneFee}
                            </span>
                            <span className="text-[#c30000] font-extrabold">
                              {formatCurrency(deliveryCharge)}
                            </span>
                          </span>
                        ) : (
                          formatCurrency(deliveryCharge)
                        )}
                      </span>
                    </div>

                    {/* উপায় ১: শপিং ব্যাগ ড্রয়ারের ভেতরেও ১-ট্যাপ ডেলিভারি এরিয়া বাটন */}
                    {deliveryCharge > 0 && currentBusiness.checkoutSummaryZoneToggleEnabled !== false && (
                      <div
                        className={`pt-1 pb-0.5 grid grid-cols-2 gap-1.5 ${
                          currentBusiness.checkoutSummaryZoneHideOnDesktop !== false ? 'lg:hidden' : ''
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => setSelectedDeliveryZone('inside_dhaka')}
                          className={`py-1.5 px-2 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                            selectedDeliveryZone === 'inside_dhaka'
                              ? (currentBusiness.checkoutSummaryZoneButtonStyle || 'emerald_pill') === 'crimson_bold'
                                ? 'bg-[#c30000] text-white border-[#c30000] shadow-xs'
                                : 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-400'
                          }`}
                        >
                          <span>
                            {selectedDeliveryZone === 'inside_dhaka' ? '✓ ' : ''}ঢাকার ভিতরে (৳{insideDhakaFee})
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedDeliveryZone('outside_dhaka')}
                          className={`py-1.5 px-2 rounded-xl text-[11px] font-extrabold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                            selectedDeliveryZone === 'outside_dhaka'
                              ? (currentBusiness.checkoutSummaryZoneButtonStyle || 'emerald_pill') === 'crimson_bold'
                                ? 'bg-[#c30000] text-white border-[#c30000] shadow-xs'
                                : 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-400'
                          }`}
                        >
                          <span>
                            {selectedDeliveryZone === 'outside_dhaka' ? '✓ ' : ''}ঢাকার বাইরে (৳{outsideDhakaFee})
                          </span>
                        </button>
                      </div>
                    )}

                    <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-1.5 border-t border-slate-200">
                      <span>সর্বমোট প্রদেয়:</span>
                      <span className="font-mono text-emerald-800">{formatCurrency(grandTotal)}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setIsCartOpen(false);
                      openCheckoutModal();
                    }}
                    className="w-full min-h-[44px] py-3 bg-[#c30000] hover:bg-[#9e0000] text-white font-extrabold text-sm rounded-xl shadow-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <span>অর্ডার কনফার্ম করতে এগিয়ে যান</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 9.5 Storefront Size/Variation Selection Warning & Interactive Picker Popup Modal */}
      {variantSelectionModal && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in"
          onClick={() => setVariantSelectionModal(null)}
        >
          <div
            className="relative w-full max-w-md bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden animate-page-rise"
            onClick={e => e.stopPropagation()}
          >
            {/* Popup Top Banner */}
            <div className="bg-gradient-to-r from-emerald-50 via-amber-50/70 to-emerald-50 px-4 sm:px-5 py-3.5 border-b border-emerald-200/80 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Ruler className="w-4 h-4" />
                </span>
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
                    পছন্দের সাইজ / বয়স সিলেক্ট করুন
                  </h3>
                  <p className="text-[11px] font-semibold text-slate-600 truncate">
                    অর্ডার করার পূর্বে নিচের অপশন থেকে সাইজ বেছে নিন
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {isAuthenticated && (
                  <>
                    <button
                      type="button"
                      onClick={() => setShowVariantPopupCustomizer(prev => !prev)}
                      className={`px-2 py-1 rounded-lg border text-[10px] font-extrabold cursor-pointer transition-colors ${
                        showVariantPopupCustomizer
                          ? 'bg-indigo-700 text-white border-indigo-700'
                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-300'
                      }`}
                      title="অ্যাডমিন কন্ট্রোল: এই পপআপের বাটন, অ্যানিমেশন ও দাম কাস্টমাইজ করুন"
                    >
                      ⚙️ কাস্টমাইজ
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({ requireVariantSelectionBeforeOrder: false });
                        setVariantSelectionModal(null);
                        showToast(
                          'সাইজ সিলেকশন পপআপ বন্ধ (OFF) করা হয়েছে!',
                          'info'
                        );
                      }}
                      className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[10px] font-extrabold cursor-pointer transition-colors"
                      title="অ্যাডমিন কন্ট্রোল: এই পপআপটি বন্ধ (OFF) করুন"
                    >
                      OFF করুন
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => setVariantSelectionModal(null)}
                  className="w-8 h-8 rounded-xl bg-white hover:bg-slate-100 text-slate-500 hover:text-slate-800 border border-slate-200 flex items-center justify-center cursor-pointer transition-colors"
                  aria-label="Close modal"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Popup Body */}
            <div className="p-4 sm:p-5 space-y-4 max-h-[82vh] overflow-y-auto">
              {/* Product Mini Card & Options */}
              {(() => {
                const modalProd = variantSelectionModal.product;
                const isDualModal = hasDualColorAndSizeVariants(modalProd);
                const modalColorVars = getProductColorVariants(modalProd);
                const modalSizeVars = getProductSizeVariants(modalProd);
                const chosenColorObj = isDualModal
                  ? modalColorVars.find(
                      v => v.id === variantSelectionModal.chosenColorId && !v.outOfStock
                    )
                  : undefined;
                const chosenSizeObj = isDualModal
                  ? modalSizeVars.find(
                      v => v.id === variantSelectionModal.chosenVariantId && !v.outOfStock
                    )
                  : undefined;
                const chosenVarObj = isDualModal
                  ? chosenColorObj && chosenSizeObj
                    ? combineColorAndSizeVariant(modalProd, chosenColorObj, chosenSizeObj)
                    : undefined
                  : (modalProd.variants || []).find(
                      v => v.id === variantSelectionModal.chosenVariantId && !v.outOfStock
                    );
                const firstInStockVar =
                  (modalProd.variants || []).find(v => !v.outOfStock) || modalProd.variants?.[0];
                const displayPrice = chosenVarObj
                  ? chosenVarObj.retailPrice
                  : chosenSizeObj
                  ? chosenSizeObj.retailPrice
                  : firstInStockVar?.retailPrice ?? modalProd.retailPrice;
                const modalChartHeaders =
                  modalProd.landingSizeChartHeaders && modalProd.landingSizeChartHeaders.length === 3
                    ? modalProd.landingSizeChartHeaders
                    : DEFAULT_LANDING_SIZE_CHART_HEADERS;
                const modalChartRows =
                  modalProd.landingSizeChartRows && modalProd.landingSizeChartRows.length > 0
                    ? modalProd.landingSizeChartRows
                    : DEFAULT_LANDING_SIZE_CHART_ROWS;

                // Admin-configurable popup display settings (with clean defaults)
                const showOptionPrice = currentBusiness.variantPopupShowOptionPrice !== false;
                const showPopupSizeChart = currentBusiness.variantPopupShowSizeChart !== false;
                const showBtnSize = Boolean(currentBusiness.variantPopupShowButtonSize);
                const showBtnPrice = currentBusiness.variantPopupShowButtonPrice !== false;
                const btnAnim: LandingFloatingBtnAnimation =
                  currentBusiness.variantPopupButtonAnimation || 'login_shine';
                const orderBtnBaseText =
                  currentBusiness.variantPopupOrderButtonText &&
                  currentBusiness.variantPopupOrderButtonText.trim() !== ''
                    ? currentBusiness.variantPopupOrderButtonText.trim()
                    : 'অর্ডার কনফার্ম করুন';
                const cartBtnBaseText =
                  currentBusiness.variantPopupCartButtonText &&
                  currentBusiness.variantPopupCartButtonText.trim() !== ''
                    ? currentBusiness.variantPopupCartButtonText.trim()
                    : 'ব্যাগে যোগ করুন';

                const activeBaseLabel =
                  variantSelectionModal.mode === 'order_now' ? orderBtnBaseText : cartBtnBaseText;

                const suffixParts: string[] = [];
                if (chosenVarObj) {
                  if (showBtnSize) suffixParts.push(chosenVarObj.label);
                  if (showBtnPrice) {
                    suffixParts.push(`৳${chosenVarObj.retailPrice * variantSelectionModal.qty}`);
                  }
                }
                const finalConfirmLabel =
                  suffixParts.length > 0
                    ? `${activeBaseLabel} (${suffixParts.join(' · ')})`
                    : activeBaseLabel;

                const isBeamAnim = btnAnim === 'cart_beam' || btnAnim === 'combo_beam';
                const wrapperAnimClass =
                  btnAnim === 'cart_beam'
                    ? 'lp-floating-cart-beam-wrapper'
                    : btnAnim === 'combo_beam'
                    ? 'lp-floating-cart-beam-wrapper lp-floating-combo-pulse'
                    : '';
                const innerAnimClass =
                  btnAnim === 'login_shine'
                    ? 'lp-btn-red-shine lp-floating-login-glow border border-white/25'
                    : btnAnim === 'cart_beam'
                    ? 'border border-white/15 shadow-md'
                    : btnAnim === 'combo_beam'
                    ? 'lp-btn-red-shine border border-white/20'
                    : btnAnim === 'glow_pulse'
                    ? 'animate-order-cta-attention'
                    : btnAnim === 'jump'
                    ? 'animate-cta-jump'
                    : '';

                return (
                  <>
                    {/* Live Admin Customizer Panel Inside Popup */}
                    {isAuthenticated && showVariantPopupCustomizer && (
                      <div className="p-3.5 rounded-2xl bg-indigo-50/90 border border-indigo-200 space-y-3 text-xs animate-fade-in">
                        <div className="flex items-center justify-between border-b border-indigo-200/80 pb-2">
                          <span className="font-extrabold text-indigo-950 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-indigo-700" />
                            পপআপ বাটন ও ভিউ কাস্টমাইজেশন (অ্যাডমিন)
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowVariantPopupCustomizer(false)}
                            className="text-[11px] font-bold text-indigo-700 hover:underline cursor-pointer"
                          >
                            সংক্ষিপ্ত করুন
                          </button>
                        </div>

                        {/* Toggle Switches */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              updateBusiness({ variantPopupShowOptionPrice: !showOptionPrice })
                            }
                            className={`p-2 rounded-xl border text-left font-bold flex items-center justify-between gap-1.5 cursor-pointer transition-colors ${
                              showOptionPrice
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                : 'bg-white border-slate-200 text-slate-600'
                            }`}
                          >
                            <span className="text-[11px] leading-tight">সাইজে দাম</span>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                                showOptionPrice
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {showOptionPrice ? 'ON' : 'OFF'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              updateBusiness({ variantPopupShowButtonPrice: !showBtnPrice })
                            }
                            className={`p-2 rounded-xl border text-left font-bold flex items-center justify-between gap-1.5 cursor-pointer transition-colors ${
                              showBtnPrice
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                : 'bg-white border-slate-200 text-slate-600'
                            }`}
                          >
                            <span className="text-[11px] leading-tight">বাটনে দাম</span>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                                showBtnPrice
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {showBtnPrice ? 'ON' : 'OFF'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              updateBusiness({ variantPopupShowButtonSize: !showBtnSize })
                            }
                            className={`p-2 rounded-xl border text-left font-bold flex items-center justify-between gap-1.5 cursor-pointer transition-colors ${
                              showBtnSize
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                : 'bg-white border-slate-200 text-slate-600'
                            }`}
                          >
                            <span className="text-[11px] leading-tight">বাটনে সাইজ নাম</span>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                                showBtnSize
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {showBtnSize ? 'ON' : 'OFF'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              const nextVal = !showPopupSizeChart;
                              updateBusiness({ variantPopupShowSizeChart: nextVal });
                              if (!nextVal) setShowVariantModalSizeChart(false);
                              showToast(
                                nextVal
                                  ? 'পপআপে "সাইজ চার্ট" বাটন চালু (ON) করা হয়েছে!'
                                  : 'পপআপে "সাইজ চার্ট" বাটন বন্ধ (OFF) করা হয়েছে!',
                                nextVal ? 'success' : 'info'
                              );
                            }}
                            className={`sm:col-span-3 p-2 rounded-xl border text-left font-bold flex items-center justify-between gap-1.5 cursor-pointer transition-colors ${
                              showPopupSizeChart
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                : 'bg-white border-slate-200 text-slate-600'
                            }`}
                          >
                            <span className="text-[11px] leading-tight">
                              📏 পপআপে "সাইজ চার্ট" বাটন প্রদর্শন (ON / OFF)
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-extrabold shrink-0 ${
                                showPopupSizeChart
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {showPopupSizeChart ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              const nextVal = !showVariantsOnHomePage;
                              updateBusiness({ showVariantsOnHomePage: nextVal });
                              showToast(
                                nextVal
                                  ? 'হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন দেখানো চালু (ON) করা হয়েছে!'
                                  : 'হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন বন্ধ (OFF) করা হয়েছে! (এখন শুধু প্রোডাক্ট পেজে ও পপআপে দেখাবে)',
                                nextVal ? 'success' : 'info'
                              );
                            }}
                            className={`sm:col-span-3 p-2 rounded-xl border text-left font-bold flex items-center justify-between gap-1.5 cursor-pointer transition-colors ${
                              showVariantsOnHomePage
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                : 'bg-white border-slate-200 text-slate-600'
                            }`}
                          >
                            <span className="text-[11px] leading-tight">
                              হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন প্রদর্শন (বন্ধ করলে শুধু প্রোডাক্ট পেজে দেখাবে)
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-extrabold shrink-0 ${
                                showVariantsOnHomePage
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {showVariantsOnHomePage ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                            </span>
                          </button>
                        </div>

                        {/* Custom Button Texts */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[10px] font-extrabold text-indigo-900 mb-1">
                              অর্ডার বাটনের লেখা (১ লাইনে সুন্দর দেখাতে ছোট রাখুন):
                            </label>
                            <input
                              type="text"
                              value={currentBusiness.variantPopupOrderButtonText ?? 'অর্ডার কনফার্ম করুন'}
                              onChange={e =>
                                updateBusiness({ variantPopupOrderButtonText: e.target.value })
                              }
                              placeholder="অর্ডার কনফার্ম করুন"
                              className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-indigo-200 text-xs font-bold text-slate-900 focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-extrabold text-indigo-900 mb-1">
                              ব্যাগ বাটনের লেখা:
                            </label>
                            <input
                              type="text"
                              value={currentBusiness.variantPopupCartButtonText ?? 'ব্যাগে যোগ করুন'}
                              onChange={e =>
                                updateBusiness({ variantPopupCartButtonText: e.target.value })
                              }
                              placeholder="ব্যাগে যোগ করুন"
                              className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-indigo-200 text-xs font-bold text-slate-900 focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                        </div>

                        {/* Button Animation Style Selector */}
                        <div>
                          <label className="block text-[10px] font-extrabold text-indigo-900 mb-1">
                            কনফার্ম বাটনের অ্যানিমেশন (চালু / বন্ধ):
                          </label>
                          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                            {(
                              [
                                { id: 'login_shine', label: '✨ শাইন' },
                                { id: 'cart_beam', label: '💫 বর্ডার বিম' },
                                { id: 'combo_beam', label: '🔥 কম্বো' },
                                { id: 'glow_pulse', label: '💓 পালস' },
                                { id: 'jump', label: '🚀 বাউন্স' },
                                { id: 'none', label: '⏸️ বন্ধ (OFF)' }
                              ] as { id: LandingFloatingBtnAnimation; label: string }[]
                            ).map(opt => (
                              <button
                                key={opt.id}
                                type="button"
                                onClick={() =>
                                  updateBusiness({ variantPopupButtonAnimation: opt.id })
                                }
                                className={`px-2 py-1.5 rounded-lg border text-[10px] font-extrabold text-center cursor-pointer transition-all ${
                                  btnAnim === opt.id
                                    ? 'bg-indigo-700 text-white border-indigo-700 shadow-2xs'
                                    : 'bg-white hover:bg-indigo-100/60 text-slate-700 border-indigo-200'
                                }`}
                              >
                                {opt.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200/90">
                      <div className="w-16 h-16 rounded-xl bg-white border border-slate-200 overflow-hidden shrink-0">
                        <ProductThumbnail
                          product={{
                            ...modalProd,
                            image:
                              modalColorVars.find(
                                c => c.id === variantSelectionModal.chosenColorId
                              )?.imageUrl ||
                              chosenVarObj?.imageUrl ||
                              modalProd.image
                          }}
                          imgClassName="p-1"
                        />
                      </div>
                      <div className="min-w-0 flex-1 space-y-1">
                        <p className="text-xs sm:text-sm font-extrabold text-slate-900 line-clamp-2 leading-snug">
                          {language === 'bn' ? modalProd.nameBn : modalProd.nameEn}
                        </p>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono font-extrabold text-sm sm:text-base text-emerald-700">
                            ৳{displayPrice}
                          </span>
                          {chosenVarObj ? (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 border border-emerald-300 text-[11px] font-extrabold">
                              ✓ নির্বাচিত: {chosenVarObj.label}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-bold">
                              সাইজ নির্বাচন করা হয়নি
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Friendly Warning / Instruction Banner */}
                    <div
                      className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-between gap-2 transition-colors ${
                        variantModalError
                          ? 'bg-rose-50 border-rose-300 text-rose-800'
                          : 'bg-amber-50/80 border-amber-200/90 text-amber-950'
                      }`}
                    >
                      <span>
                        {variantModalError
                          ? isDualModal
                            ? '⚠️ অনুগ্রহ করে নিচের কালার এবং সাইজ উভয়ই সিলেক্ট করুন!'
                            : '⚠️ অনুগ্রহ করে নিচের যেকোনো একটি সাইজ / ভ্যারিয়েশন সিলেক্ট করুন!'
                          : isDualModal
                          ? '👇 নিচের অপশন থেকে আপনার পছন্দের কালার এবং সাইজ ট্যাপ করুন:'
                          : '👇 নিচের অপশন থেকে আপনার পছন্দের সাইজ / বয়স ট্যাপ করুন:'}
                      </span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {showPopupSizeChart && modalProd.landingSizeChartEnabled !== false && (
                          <button
                            type="button"
                            onClick={() => setShowVariantModalSizeChart(prev => !prev)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[11px] font-extrabold shrink-0 cursor-pointer"
                          >
                            <Ruler className="w-3 h-3" />
                            <span>{showVariantModalSizeChart ? 'চার্ট লুকান' : 'সাইজ চার্ট'}</span>
                          </button>
                        )}
                        {isAuthenticated && (
                          <button
                            type="button"
                            onClick={() => {
                              const nextVal = !showPopupSizeChart;
                              updateBusiness({ variantPopupShowSizeChart: nextVal });
                              if (!nextVal) setShowVariantModalSizeChart(false);
                              showToast(
                                nextVal
                                  ? 'পপআপে "সাইজ চার্ট" বাটন চালু (ON) করা হয়েছে!'
                                  : 'পপআপে "সাইজ চার্ট" বাটন বন্ধ (OFF) করা হয়েছে!',
                                nextVal ? 'success' : 'info'
                              );
                            }}
                            title="অ্যাডমিন কন্ট্রোল: পপআপে সাইজ চার্ট বাটন ON / OFF করুন"
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg border text-[10px] font-extrabold shrink-0 cursor-pointer transition-colors ${
                              showPopupSizeChart
                                ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700'
                                : 'bg-rose-100 hover:bg-rose-200 text-rose-800 border-rose-300'
                            }`}
                          >
                            <span>{showPopupSizeChart ? 'চার্ট: ON' : 'চার্ট: OFF'}</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Dual Mode Step 1: Color Options Grid (Only rendered if product has both Color and Size variations) */}
                    {isDualModal && (
                      <div className="space-y-1.5">
                        <span className="block text-xs font-extrabold text-rose-950">
                          🎨 ১. পছন্দের কালার (Color) সিলেক্ট করুন:
                        </span>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {modalColorVars.map(cVar => {
                            const isColorOut = Boolean(cVar.outOfStock);
                            const isColorPicked =
                              !isColorOut && variantSelectionModal.chosenColorId === cVar.id;
                            return (
                              <button
                                key={cVar.id}
                                type="button"
                                onClick={() => {
                                  if (isColorOut) {
                                    showToast(
                                      `দুঃখিত, "${cVar.label}" কালারটি বর্তমানে স্টকে নেই (স্টক শেষ)!`,
                                      'error'
                                    );
                                    return;
                                  }
                                  setVariantModalError(false);
                                  setSelectedColorByProduct(prev => ({
                                    ...prev,
                                    [modalProd.id]: cVar.id
                                  }));
                                  setVariantSelectionModal(prev =>
                                    prev ? { ...prev, chosenColorId: cVar.id } : null
                                  );
                                }}
                                className={`p-2.5 rounded-xl border-2 text-left transition-all cursor-pointer flex items-center justify-between gap-1.5 ${
                                  isColorOut
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                    : isColorPicked
                                    ? 'bg-rose-600 text-white border-rose-600 shadow-sm scale-[1.01]'
                                    : 'bg-white hover:bg-rose-50/50 text-slate-800 border-rose-200 hover:border-rose-500'
                                }`}
                              >
                                <div className="flex items-center gap-1.5 min-w-0">
                                  {cVar.imageUrl && (
                                    <img
                                      src={cVar.imageUrl}
                                      alt={cVar.label}
                                      className="w-5 h-5 rounded-md object-cover border border-white/60 shrink-0"
                                    />
                                  )}
                                  <span
                                    className={`text-xs sm:text-sm font-extrabold leading-tight truncate ${
                                      isColorOut ? 'line-through' : ''
                                    }`}
                                  >
                                    {cVar.label}
                                  </span>
                                </div>
                                {isColorOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600 shrink-0">
                                    স্টক শেষ
                                  </span>
                                ) : (
                                  isColorPicked && (
                                    <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Interactive Size / Age Options Grid */}
                    <div className="space-y-1.5">
                      {isDualModal && (
                        <span className="block text-xs font-extrabold text-emerald-950">
                          📏 ২. পছন্দের সাইজ / বয়স (Size) সিলেক্ট করুন:
                        </span>
                      )}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {(isDualModal ? modalSizeVars : modalProd.variants || []).map(v => {
                          const isVarOut = Boolean(v.outOfStock);
                          const isPicked =
                            !isVarOut && variantSelectionModal.chosenVariantId === v.id;
                          return (
                            <button
                              key={v.id}
                              type="button"
                              onClick={() => {
                                if (isVarOut) {
                                  showToast(
                                    `দুঃখিত, "${v.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`,
                                    'error'
                                  );
                                  return;
                                }
                                setVariantModalError(false);
                                setSelectedVariantByProduct(prev => ({
                                  ...prev,
                                  [modalProd.id]: v.id
                                }));
                                setVariantSelectionModal(prev =>
                                  prev ? { ...prev, chosenVariantId: v.id } : null
                                );
                              }}
                              className={`p-2.5 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                                isVarOut
                                  ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                  : isPicked
                                  ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm scale-[1.01]'
                                  : 'bg-white hover:bg-emerald-50/50 text-slate-800 border-slate-200 hover:border-emerald-500'
                              }`}
                            >
                              <div className="flex items-center justify-between gap-1">
                                <span
                                  className={`text-xs sm:text-sm font-extrabold leading-tight ${
                                    isVarOut ? 'line-through' : ''
                                  }`}
                                >
                                  {v.label}
                                </span>
                                {isPicked && (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                                )}
                              </div>
                              {isVarOut ? (
                                <span className="text-[10px] font-extrabold text-rose-600">
                                  স্টক শেষ
                                </span>
                              ) : (
                                showOptionPrice && (
                                  <span
                                    className={`font-mono text-xs font-bold ${
                                      isPicked ? 'text-emerald-100' : 'text-emerald-700'
                                    }`}
                                  >
                                    ৳{v.retailPrice}
                                  </span>
                                )
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Optional Expandable Size Chart Table Inside Popup */}
                    {showPopupSizeChart && showVariantModalSizeChart && modalChartRows.length > 0 && (
                      <div className="rounded-xl border border-indigo-200 overflow-hidden bg-white">
                        <div className="px-3 py-2 bg-indigo-50 border-b border-indigo-200 flex items-center justify-between">
                          <span className="text-xs font-extrabold text-indigo-950">
                            📏 {modalProd.landingSizeChartTitle || 'সাইজ চার্ট ও মাপ (ইঞ্চিতে)'}
                          </span>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead>
                              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-extrabold">
                                <th className="py-2 px-2.5">{modalChartHeaders[0]}</th>
                                <th className="py-2 px-2.5">{modalChartHeaders[1]}</th>
                                <th className="py-2 px-2.5">{modalChartHeaders[2]}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              {modalChartRows.map((r, rIdx) => (
                                <tr key={r.id || rIdx}>
                                  <td className="py-1.5 px-2.5 font-extrabold text-slate-900">{r.size}</td>
                                  <td className="py-1.5 px-2.5 text-slate-700">{r.chest}</td>
                                  <td className="py-1.5 px-2.5 text-slate-700">{r.length}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {/* Confirm Action Button (1-line guaranteed with whitespace-nowrap & customizable animation) */}
                    <div className="pt-1 flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => setVariantSelectionModal(null)}
                        className="px-4 min-h-[46px] rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm cursor-pointer transition-colors shrink-0"
                      >
                        বাতিল
                      </button>

                      <div
                        className={`flex-1 min-w-0 ${
                          isBeamAnim ? `rounded-xl ${wrapperAnimClass}` : ''
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => {
                            if (!chosenVarObj) {
                              setVariantModalError(true);
                              return;
                            }
                            const targetProd = variantSelectionModal.product;
                            const targetQty = variantSelectionModal.qty;
                            const targetMode = variantSelectionModal.mode;
                            if (isDualModal && chosenColorObj && chosenSizeObj) {
                              setSelectedColorByProduct(prev => ({
                                ...prev,
                                [targetProd.id]: chosenColorObj.id
                              }));
                              setSelectedVariantByProduct(prev => ({
                                ...prev,
                                [targetProd.id]: chosenSizeObj.id
                              }));
                            } else {
                              setSelectedVariantByProduct(prev => ({
                                ...prev,
                                [targetProd.id]: chosenVarObj.id
                              }));
                            }
                            setVariantSelectionModal(null);
                            if (targetMode === 'order_now') {
                              handleDirectOrderNow(targetProd, targetQty, chosenVarObj, true);
                            } else {
                              addToCart(targetProd, targetQty, false, chosenVarObj, true);
                            }
                          }}
                          className={`w-full min-h-[46px] py-2.5 px-3 sm:px-4 rounded-xl font-extrabold text-xs sm:text-sm text-white shadow-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-[0.98] whitespace-nowrap overflow-hidden text-ellipsis ${
                            variantSelectionModal.mode === 'order_now'
                              ? 'bg-[#c30000] hover:bg-[#9e0000]'
                              : 'bg-emerald-700 hover:bg-emerald-800'
                          } ${innerAnimClass}`}
                        >
                          <ShoppingBag className="w-4 h-4 shrink-0" />
                          <span className="truncate">{finalConfirmLabel}</span>
                        </button>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* STOREFRONT LIVE RECENT ORDER NOTIFICATION POPUP (Social Proof Toast — Positioned right at the bottom floating bar spot so Admin can keep whichever they prefer ON) */}
      {showStorefrontSocialProof &&
        !isSfSocialProofDismissed &&
        !isCheckoutModalOpen &&
        !confirmedOrder &&
        !isSpinWheelModalOpen &&
        !variantSelectionModal &&
        currentSfSocialProofProduct && (
          <div
            className={`fixed bottom-3 sm:bottom-3.5 left-3 sm:left-4 z-40 max-w-[325px] sm:max-w-[360px] transition-all duration-500 ${
              isSfSocialProofVisible
                ? 'translate-y-0 opacity-100 pointer-events-auto'
                : 'translate-y-6 opacity-0 pointer-events-none'
            }`}
          >
            {/* Quick Admin Control Pill right above Toast when Admin is logged in */}
            {isAuthenticated && (
              <div className="mb-1.5 flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    updateBusiness({ storefrontSocialProofEnabled: false });
                    showToast(
                      'স্টোরফ্রন্ট রিসেন্ট অর্ডার পপ-আপ বন্ধ (OFF) করা হয়েছে! (সেটিংস বা ইনভেন্টরি থেকে আবার ON করতে পারবেন)',
                      'info'
                    );
                  }}
                  className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-rose-700 text-white text-[10px] font-extrabold border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer transition-colors"
                  title="স্টোরফ্রন্ট অর্ডার পপ-আপ বন্ধ (OFF) করুন"
                >
                  <Bell className="w-2.5 h-2.5 text-emerald-400" />
                  <span>পপ-আপ: ON (বন্ধ করুন)</span>
                </button>
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    const nextBarState = !isHomeFloatingBarEnabled;
                    updateBusiness({ homeFloatingBarEnabled: nextBarState });
                    showToast(
                      nextBarState
                        ? 'হোমপেজের নিচের ফ্লোটিং বার চালু (ON) করা হয়েছে!'
                        : 'হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করা হয়েছে!',
                      nextBarState ? 'success' : 'info'
                    );
                  }}
                  className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-slate-800 text-sky-300 text-[10px] font-extrabold border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer transition-colors"
                  title="হোমপেজের নিচের ফ্লোটিং বার চালু বা বন্ধ (ON / OFF) করুন"
                >
                  <ShoppingBag className="w-2.5 h-2.5 text-sky-400" />
                  <span>ফ্লোটিং বার: {isHomeFloatingBarEnabled ? 'ON' : 'OFF'}</span>
                </button>
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    const gapOptions = [5, 10, 16, 25, 40, 60];
                    const idx = gapOptions.indexOf(storefrontSocialProofGapSec);
                    const nextGap = gapOptions[(idx + 1) % gapOptions.length];
                    updateBusiness({ storefrontSocialProofIntervalSec: nextGap });
                    showToast(
                      `স্টোরফ্রন্ট অর্ডার পপ-আপ স্পিড: প্রতি ${toBanglaCountdownDigits(nextGap, 1)} সেকেন্ড পর পর দেখাবে`,
                      'info'
                    );
                  }}
                  className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-slate-800 text-amber-300 text-[10px] font-extrabold border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer transition-colors"
                  title="অর্ডার পপ-আপ আসার স্পিড (স্লো / ফাস্ট) পরিবর্তন করুন"
                >
                  <Clock className="w-2.5 h-2.5 text-amber-400" />
                  <span>
                    স্পিড: {toBanglaCountdownDigits(storefrontSocialProofGapSec, 1)} সে.
                  </span>
                </button>
              </div>
            )}

            <div className="bg-white/98 backdrop-blur-md rounded-2xl border border-emerald-200 shadow-lg p-3 flex items-center gap-3">
              <div
                onClick={() => {
                  if (!quickViewProduct || quickViewProduct.id !== currentSfSocialProofProduct.id) {
                    openQuickView(currentSfSocialProofProduct);
                  } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 overflow-hidden shrink-0 cursor-pointer"
              >
                <ProductThumbnail product={currentSfSocialProofProduct} imgClassName="p-1" />
              </div>

              <div
                onClick={() => {
                  if (!quickViewProduct || quickViewProduct.id !== currentSfSocialProofProduct.id) {
                    openQuickView(currentSfSocialProofProduct);
                  } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className="min-w-0 flex-1 cursor-pointer space-y-0.5"
              >
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                  <p className="text-xs font-extrabold text-slate-900 truncate">
                    {currentSfSocialProofBuyer.name}{' '}
                    <span className="font-semibold text-slate-500">
                      ({currentSfSocialProofBuyer.location})
                    </span>
                  </p>
                </div>
                <p className="text-[11px] font-bold text-emerald-800 truncate">
                  {language === 'bn'
                    ? `${currentSfSocialProofProduct.nameBn} অর্ডার করেছেন ✓`
                    : `${currentSfSocialProofProduct.nameEn} অর্ডার করেছেন ✓`}
                </p>
                <p className="text-[10px] font-semibold text-slate-400">
                  {currentSfSocialProofBuyer.timeAgo} · ক্যাশ অন ডেলিভারি
                </p>
              </div>

              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  setIsSfSocialProofDismissed(true);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 shrink-0 cursor-pointer self-start"
                title="নোটিফিকেশন বন্ধ করুন"
                aria-label="Close notification"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

      {/* 10. Clean Customer Storefront Footer (Soft Light Gradient Design — Hidden on Mobile Checkout Page) */}
      <footer
        className={`${
          isCheckoutModalOpen ? 'hidden lg:block ' : ''
        }bg-gradient-to-br from-emerald-50/90 via-white to-amber-50/80 text-slate-700 border-t border-emerald-200/70 mt-10 shadow-inner`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="space-y-2.5">
            <div className="flex items-center gap-2.5 min-h-[28px]">
              {currentBusiness.logoUrl && currentBusiness.logoUrl.trim() !== '' ? (
                <img
                  src={currentBusiness.logoUrl}
                  alt={currentBusiness.name}
                  className="h-9 sm:h-10 w-auto max-w-[200px] object-contain"
                />
              ) : null}
            </div>
            <p className="text-slate-600 leading-relaxed">{currentBusiness.address}</p>
            <p className="font-mono font-extrabold text-[#c30000] bg-rose-50/80 border border-rose-200/70 inline-block px-2.5 py-1 rounded-lg">
              হটলাইন: {currentBusiness.phone}
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">গ্রাহক সেবা</h4>
            <div className="flex flex-col gap-1.5 text-slate-600 font-medium">
              <button
                type="button"
                onClick={() => openCustomerAccountPage('login', false)}
                className="text-left hover:text-[#c30000] transition-colors cursor-pointer"
              >
                {currentCustomerAccount
                  ? 'আমার একাউন্ট ও অর্ডার হিস্ট্রি'
                  : 'কাস্টমার লগইন / নতুন একাউন্ট'}
              </button>
              <button
                type="button"
                onClick={() => {
                  closeAllSubPagesAndRestoreScroll();
                  handleSelectCategory('all');
                }}
                className="text-left hover:text-[#c30000] transition-colors cursor-pointer"
              >
                সকল পণ্যের তালিকা
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">ডেলিভারি ও পেমেন্ট</h4>
            <p className="text-slate-600 leading-relaxed">
              ক্যাশ অন ডেলিভারি সুবিধা — পণ্য হাতে পেয়ে চেক করে মূল্য পরিশোধ করুন।
            </p>
            <p className="text-[11px] font-semibold text-slate-500 pt-1">
              © {new Date().getFullYear()}{' '}
              {language === 'bn'
                ? currentBusiness.name.replace('স্টকমাস্টার বিডি - ', '')
                : currentBusiness.nameEn.replace('StockMaster BD - ', '')}{' '}
              · সর্বস্বত্ব সংরক্ষিত
            </p>
          </div>
        </div>

        {/* Configurable Developer Credit Bar (ON/OFF, Editable Developer Name & Link) */}
        {currentBusiness.developerCreditEnabled !== false &&
          (currentBusiness.developerCreditName || 'Web Studio BD').trim() !== '' && (
            <div className="border-t border-emerald-200/60 bg-white/70">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-600">
                <span className="text-[11px] text-slate-500">
                  © {new Date().getFullYear()}{' '}
                  {language === 'bn'
                    ? currentBusiness.name.replace('স্টকমাস্টার বিডি - ', '')
                    : currentBusiness.nameEn.replace('StockMaster BD - ', '')}
                </span>
                <p className="inline-flex items-center gap-1.5 font-medium text-slate-600">
                  <span>Developed by</span>
                  {(() => {
                    const devName = (currentBusiness.developerCreditName || 'Web Studio BD').trim();
                    const rawLink = (currentBusiness.developerCreditLink || '').trim();
                    const normalizedLink =
                      rawLink && !/^(javascript|data|vbscript):/i.test(rawLink)
                        ? /^https?:\/\//i.test(rawLink)
                          ? rawLink
                          : `https://${rawLink}`
                        : '';
                    return normalizedLink ? (
                      <a
                        href={normalizedLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-bold text-emerald-700 hover:text-emerald-800 hover:underline transition-colors"
                      >
                        {devName}
                      </a>
                    ) : (
                      <span className="font-bold text-slate-800">{devName}</span>
                    );
                  })()}
                </p>
              </div>
            </div>
          )}
      </footer>

      {/* 🛡️ Clean Daily Order Limit Reached Popup Modal */}
      {orderLimitPopupData && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs animate-page-rise"
          onClick={() => setOrderLimitPopupData(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full p-6 border border-rose-200 shadow-2xl text-center relative overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            {/* Top-Right Cross (X) Button to Close Popup */}
            <button
              type="button"
              onClick={() => setOrderLimitPopupData(null)}
              className="absolute top-3.5 right-3.5 w-9 h-9 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 flex items-center justify-center transition-all cursor-pointer shadow-2xs"
              aria-label="Close"
              title="পপআপ বন্ধ করুন"
            >
              <X className="w-4.5 h-4.5 stroke-[2.5]" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-3.5 shadow-2xs">
              <ShieldCheck className="w-7 h-7" />
            </div>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-[11px] font-extrabold mb-2">
              {orderLimitPopupData.blockType === 'same_product'
                ? `একই পণ্য দিনে সর্বোচ্চ ${
                    currentBusiness.dailySameProductMaxCount ??
                    orderLimitPopupData.sameProductMaxCount
                  } বার অর্ডার করা যাবে`
                : `একই পণ্য ${
                    currentBusiness.dailySameProductMaxCount ??
                    orderLimitPopupData.sameProductMaxCount
                  } বার • মোট সর্বোচ্চ ${orderLimitPopupData.maxCount}টি অর্ডার/দিন`}
            </span>

            <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
              {(currentBusiness.dailyOrderLimitTitle || '').trim() || orderLimitPopupData.title}
            </h3>

            <p className="mt-2.5 text-xs sm:text-sm font-medium text-slate-600 leading-relaxed whitespace-pre-line">
              {(currentBusiness.dailyOrderLimitMessage || '').trim() || orderLimitPopupData.message}
            </p>

            {/* Quick Admin Inline Control if Admin is logged in */}
            {isAuthenticated && (
              <div className="mt-4 pt-3 border-t border-slate-200 text-left">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-extrabold text-indigo-700">
                    ⚙️ অ্যাডমিন কুইক কন্ট্রোল:
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setIsEditingLimitPopupInline(prev => !prev)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[11px] font-bold cursor-pointer"
                    >
                      {isEditingLimitPopupInline ? 'বন্ধ করুন' : '✏️ মেসেজ ও লিমিট এডিট'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({ dailyOrderLimitEnabled: false });
                        setOrderLimitPopupData(null);
                        showToast('দৈনিক অর্ডার লিমিট সাময়িকভাবে বন্ধ (OFF) করা হয়েছে!', 'info');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-bold cursor-pointer"
                    >
                      লিমিট OFF করুন
                    </button>
                  </div>
                </div>

                {isEditingLimitPopupInline && (
                  <div className="mt-2.5 space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-slate-700">একই প্রোডাক্ট সর্বোচ্চ:</span>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 5].map(n => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => setInlineLimitSameProdMaxCount(n)}
                            className={`px-2 py-0.5 rounded-md text-[11px] font-extrabold border cursor-pointer ${
                              inlineLimitSameProdMaxCount === n
                                ? 'bg-rose-600 text-white border-rose-600'
                                : 'bg-white text-slate-700 border-slate-300'
                            }`}
                          >
                            {n} বার
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-slate-700">সব মিলিয়ে মোট অর্ডার:</span>
                      <div className="flex items-center gap-1">
                        {[2, 3, 5, 8, 10].map(n => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => setInlineLimitMaxCount(n)}
                            className={`px-2 py-0.5 rounded-md text-[11px] font-extrabold border cursor-pointer ${
                              inlineLimitMaxCount === n
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white text-slate-700 border-slate-300'
                            }`}
                          >
                            {n}টি
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="text"
                      value={inlineLimitTitle}
                      onChange={e => setInlineLimitTitle(e.target.value)}
                      placeholder="পপআপ টাইটেল"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
                    />
                    <textarea
                      rows={2}
                      value={inlineLimitMessage}
                      onChange={e => setInlineLimitMessage(e.target.value)}
                      placeholder="পপআপ মেসেজ"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const nextSameMax = Math.max(1, Number(inlineLimitSameProdMaxCount) || 2);
                        const nextTotalMax = Math.max(1, Number(inlineLimitMaxCount) || 5);
                        updateBusiness({
                          dailyOrderLimitEnabled: true,
                          dailySameProductMaxCount: nextSameMax,
                          dailyOrderMaxCount: nextTotalMax,
                          dailyOrderLimitTitle: inlineLimitTitle.trim() || orderLimitPopupData.title,
                          dailyOrderLimitMessage:
                            inlineLimitMessage.trim() || orderLimitPopupData.message
                        });
                        setOrderLimitPopupData(prev =>
                          prev
                            ? {
                                ...prev,
                                sameProductMaxCount: nextSameMax,
                                maxCount: nextTotalMax,
                                title: inlineLimitTitle.trim() || prev.title,
                                message: inlineLimitMessage.trim() || prev.message
                              }
                            : null
                        );
                        setIsEditingLimitPopupInline(false);
                        showToast('পপআপ মেসেজ ও লিমিট আপডেট হয়েছে!', 'success');
                      }}
                      className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold cursor-pointer"
                    >
                      💾 সেভ করুন
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Helpline Call + Animated WhatsApp Button (Thank You / Login Shine & Beam Effect) */}
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
              <a
                href={`tel:${currentBusiness.callOrderPhone || currentBusiness.phone || '01711234567'}`}
                className="min-h-[44px] px-4 py-2.5 rounded-[12px] bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-sm transition-colors whitespace-nowrap"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>হেল্পলাইনে কল করুন</span>
              </a>

              <div className="wa-confirm-beam-wrapper">
                <a
                  href={`https://wa.me/${(() => {
                    const rawWa = (
                      currentBusiness.whatsappOrderPhone ||
                      currentBusiness.callOrderPhone ||
                      currentBusiness.phone ||
                      '01711234567'
                    ).replace(/\D/g, '');
                    return rawWa.startsWith('880')
                      ? rawWa
                      : rawWa.startsWith('0')
                      ? `88${rawWa}`
                      : `880${rawWa}`;
                  })()}?text=${encodeURIComponent(
                    `আসসালামু আলাইকুম, আমি আপনাদের "${currentBusiness.name}" ওয়েবসাইটে অর্ডার করতে চাচ্ছি কিন্তু অর্ডার লিমিট দেখাচ্ছে। অনুগ্রহ করে সাহায্য করবেন।`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="relative z-10 w-full min-h-[44px] py-2.5 px-3.5 bg-gradient-to-r from-[#1fa855] via-[#25D366] to-[#128C7E] hover:from-[#1b944a] hover:to-[#0f7a6e] text-white font-extrabold text-xs sm:text-sm rounded-[12px] flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer btn-premium-shine"
                >
                  <WhatsAppOriginalIcon className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-white shrink-0 animate-bounce" />
                  <span>হোয়াটসঅ্যাপে মেসেজ দিন</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
