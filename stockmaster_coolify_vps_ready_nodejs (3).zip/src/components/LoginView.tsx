import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  LogIn,
  ShieldCheck,
  ShoppingBag,
  AlertCircle,
  ShieldAlert
} from 'lucide-react';

interface LoginViewProps {
  onBackToStorefront?: () => void;
}

const LOCKOUT_STORAGE_KEY = 'admin_login_lockout_until';
const ATTEMPTS_STORAGE_KEY = 'admin_login_failed_attempts';
const MAX_ATTEMPTS = 5;
const LOCKOUT_SECONDS = 60;

export const LoginView: React.FC<LoginViewProps> = ({ onBackToStorefront }) => {
  const {
    language,
    currentBusiness,
    login
  } = useApp();

  const [identifier, setIdentifier] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string>('');
  // Invisible anti-bot honeypot field
  const [honeypot, setHoneypot] = useState<string>('');

  // Brute-force lockout state
  const [failedAttempts, setFailedAttempts] = useState<number>(() => {
    try {
      return Number(window.localStorage.getItem(ATTEMPTS_STORAGE_KEY) || '0');
    } catch {
      return 0;
    }
  });
  const [lockoutRemaining, setLockoutRemaining] = useState<number>(0);

  useEffect(() => {
    const checkLockout = () => {
      try {
        const until = Number(window.localStorage.getItem(LOCKOUT_STORAGE_KEY) || '0');
        const diff = Math.ceil((until - Date.now()) / 1000);
        if (diff > 0) {
          setLockoutRemaining(diff);
        } else {
          setLockoutRemaining(0);
          if (until > 0) {
            window.localStorage.removeItem(LOCKOUT_STORAGE_KEY);
            window.localStorage.removeItem(ATTEMPTS_STORAGE_KEY);
            setFailedAttempts(0);
          }
        }
      } catch {
        setLockoutRemaining(0);
      }
    };

    checkLockout();
    const timer = window.setInterval(checkLockout, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (honeypot) return; // Block automated bots silently
    if (lockoutRemaining > 0) return;

    setLoginError('');
    setIsSubmitting(true);

    const ok = await login(identifier, password);
    if (!ok) {
      const nextAttempts = failedAttempts + 1;
      setFailedAttempts(nextAttempts);
      try {
        window.localStorage.setItem(ATTEMPTS_STORAGE_KEY, String(nextAttempts));
      } catch {
        // Ignore storage error
      }

      if (nextAttempts >= MAX_ATTEMPTS) {
        const until = Date.now() + LOCKOUT_SECONDS * 1000;
        try {
          window.localStorage.setItem(LOCKOUT_STORAGE_KEY, String(until));
        } catch {
          // Ignore storage error
        }
        setLockoutRemaining(LOCKOUT_SECONDS);
        setLoginError(
          language === 'bn'
            ? `নিরাপত্তার কারণে পরপর ${MAX_ATTEMPTS} বার ভুল চেষ্টার জন্য লগইন ${LOCKOUT_SECONDS} সেকেন্ডের জন্য সাময়িক লক করা হয়েছে।`
            : `Too many failed attempts. Login is temporarily locked for ${LOCKOUT_SECONDS} seconds.`
        );
      } else {
        const left = MAX_ATTEMPTS - nextAttempts;
        setLoginError(
          language === 'bn'
            ? `ভুল ইউজারনেম/ইমেইল অথবা পাসওয়ার্ড! (আর ${left} বার চেষ্টা বাকি)`
            : `Invalid username/email or password! (${left} attempts remaining)`
        );
      }
    } else {
      try {
        window.localStorage.removeItem(LOCKOUT_STORAGE_KEY);
        window.localStorage.removeItem(ATTEMPTS_STORAGE_KEY);
      } catch {
        // Ignore
      }
      setFailedAttempts(0);
    }
    setIsSubmitting(false);
  };

  const activeStorefrontTheme =
    currentBusiness.storefrontTheme ||
    (currentBusiness.winterThemeEnabled ? 'winter_frost' : 'emerald_default');

  return (
    <div
      className="min-h-screen bg-slate-100 text-slate-900 flex flex-col justify-center items-center px-4 py-8"
      data-storefront-theme={activeStorefrontTheme}
    >
      <div className="w-full max-w-md bg-white rounded-2xl border border-emerald-200/80 shadow-sm overflow-hidden">
        <div className="sf-theme-topbar bg-gradient-to-r from-emerald-900 via-emerald-700 to-emerald-800 h-2 w-full" />
        <div className="p-6 sm:p-8">
          {/* Centered Website Logo & Store Identity */}
          <div className="flex flex-col items-center text-center pb-6 mb-6 border-b border-slate-100">
            {currentBusiness.logoUrl ? (
              <div className="mb-3 flex items-center justify-center">
                <img
                  src={currentBusiness.logoUrl}
                  alt={currentBusiness.name || 'Store Logo'}
                  className="max-h-16 sm:max-h-20 w-auto object-contain rounded-lg"
                />
              </div>
            ) : (
              <div className="w-12 h-12 rounded-2xl sf-theme-cart-btn bg-emerald-700 flex items-center justify-center text-white shadow-xs mb-3">
                <ShieldCheck className="w-6 h-6" />
              </div>
            )}
            <h1 className="font-bold text-base sm:text-lg text-slate-900">
              {currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট'}
            </h1>
            <p className="text-xs text-emerald-700 font-semibold mt-0.5">
              {language === 'bn' ? 'অ্যাডমিন প্যানেল লগইন' : 'Admin Panel Login'}
            </p>
          </div>

          {/* Lockout Banner */}
          {lockoutRemaining > 0 && (
            <div className="mb-4 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                {language === 'bn'
                  ? `ব্রুট-ফোর্স নিরাপত্তা লক সক্রিয়: অনুগ্রহ করে ${lockoutRemaining} সেকেন্ড অপেক্ষা করুন।`
                  : `Security lockout active: Please wait ${lockoutRemaining} seconds before trying again.`}
              </span>
            </div>
          )}

          {/* Error Message */}
          {loginError && lockoutRemaining === 0 && (
            <div className="mb-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{loginError}</span>
            </div>
          )}

          {/* Simple Login Form: Only Username/Email & Password */}
          <form onSubmit={handleFormSubmit} className="space-y-4">
            {/* Hidden Honeypot Trap for Bots */}
            <input
              type="text"
              name="website_url_verification"
              tabIndex={-1}
              autoComplete="off"
              value={honeypot}
              onChange={(e) => setHoneypot(e.target.value)}
              className="hidden"
              aria-hidden="true"
            />

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Username or Email Address
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  required
                  disabled={lockoutRemaining > 0}
                  autoComplete="username"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value);
                    if (loginError) setLoginError('');
                  }}
                  placeholder="Enter username or email"
                  className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 text-sm bg-slate-50/80 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-medium text-slate-900 placeholder:text-slate-400 outline-hidden transition-all disabled:opacity-60"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  disabled={lockoutRemaining > 0}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (loginError) setLoginError('');
                  }}
                  placeholder="••••••••"
                  className="w-full min-h-[44px] pl-10 pr-11 py-2.5 text-sm bg-slate-50/80 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl font-mono text-slate-900 placeholder:text-slate-400 outline-hidden transition-all disabled:opacity-60"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || lockoutRemaining > 0}
              className="w-full min-h-[46px] py-3 px-4 sf-theme-cart-btn bg-emerald-700 hover:bg-emerald-800 active:scale-[0.99] text-white font-semibold rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer text-sm mt-2 disabled:opacity-60"
            >
              <LogIn className="w-4 h-4" />
              <span>
                {lockoutRemaining > 0
                  ? language === 'bn'
                    ? `লক করা আছে (${lockoutRemaining}s)`
                    : `Locked (${lockoutRemaining}s)`
                  : isSubmitting
                  ? language === 'bn'
                    ? 'যাচাই করা হচ্ছে...'
                    : 'Verifying...'
                  : language === 'bn'
                  ? 'লগইন করুন'
                  : 'Sign In'}
              </span>
            </button>
          </form>

          {/* Bottom Back to Store Link */}
          {onBackToStorefront && (
            <div className="mt-6 pt-4 border-t border-slate-100 flex justify-center">
              <button
                type="button"
                onClick={onBackToStorefront}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-emerald-700 transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>
                  {language === 'bn' ? '← অনলাইন শপে ফিরে যান' : '← Back to Online Store'}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
