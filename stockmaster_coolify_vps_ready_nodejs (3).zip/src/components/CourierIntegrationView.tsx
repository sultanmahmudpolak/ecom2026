import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { OnlineOrder, CourierFraudCheckResult } from '../types';
import {
  normalizeBdPhone11,
  computeOwnStoreCustomerRecord,
  checkCustomerFraudAndRatio,
  bookSteadfastOrder,
  checkSteadfastOrderStatus,
  checkSteadfastBalance,
  fetchPathaoStores,
  bookPathaoOrder,
  getSecretWebhookUrl
} from '../utils/courierService';
import {
  Truck,
  ShieldCheck,
  ShieldAlert,
  Search,
  Send,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  KeyRound,
  Copy,
  Check,
  Eye,
  EyeOff,
  Store,
  Phone,
  MapPin,
  Package,
  Sparkles,
  Wallet,
  Webhook,
  Lock,
  Mail
} from 'lucide-react';

export const CourierIntegrationView: React.FC = () => {
  const {
    currentBusiness,
    updateBusiness,
    onlineOrders,
    incompleteOrders,
    updateOnlineOrder,
    updateOnlineOrderStatus,
    formatCurrency,
    formatDate,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'parcel_send' | 'fraud_checker' | 'api_settings'>('parcel_send');

  // --- API Settings Form State ---
  const [steadfastEnabled, setSteadfastEnabled] = useState<boolean>(
    currentBusiness.steadfastEnabled ?? true
  );
  const [steadfastApiKey, setSteadfastApiKey] = useState<string>(
    currentBusiness.steadfastApiKey || ''
  );
  const [steadfastSecretKey, setSteadfastSecretKey] = useState<string>(
    currentBusiness.steadfastSecretKey || ''
  );
  const [steadfastAuthEmail, setSteadfastAuthEmail] = useState<string>(
    currentBusiness.steadfastAuthEmail || ''
  );
  const [steadfastAuthPassword, setSteadfastAuthPassword] = useState<string>(
    currentBusiness.steadfastAuthPassword || ''
  );
  const [steadfastWebhookToken, setSteadfastWebhookToken] = useState<string>(
    currentBusiness.steadfastWebhookToken || ''
  );

  const [pathaoEnabled, setPathaoEnabled] = useState<boolean>(
    currentBusiness.pathaoEnabled ?? true
  );
  const [pathaoSandbox, setPathaoSandbox] = useState<boolean>(
    Boolean(currentBusiness.pathaoSandbox)
  );
  const [pathaoClientId, setPathaoClientId] = useState<string>(
    currentBusiness.pathaoClientId || ''
  );
  const [pathaoClientSecret, setPathaoClientSecret] = useState<string>(
    currentBusiness.pathaoClientSecret || ''
  );
  const [pathaoUsername, setPathaoUsername] = useState<string>(
    currentBusiness.pathaoUsername || ''
  );
  const [pathaoPassword, setPathaoPassword] = useState<string>(
    currentBusiness.pathaoPassword || ''
  );
  const [pathaoStoreId, setPathaoStoreId] = useState<string>(
    currentBusiness.pathaoStoreId || ''
  );
  const [pathaoWebhookToken, setPathaoWebhookToken] = useState<string>(
    currentBusiness.pathaoWebhookToken || ''
  );
  const [bdcourierApiKey, setBdcourierApiKey] = useState<string>(
    currentBusiness.bdcourierApiKey || ''
  );

  const [showSfSecret, setShowSfSecret] = useState(false);
  const [showSfPass, setShowSfPass] = useState(false);
  const [showPathaoSecret, setShowPathaoSecret] = useState(false);
  const [showPathaoPass, setShowPathaoPass] = useState(false);

  const [sfBalanceLoading, setSfBalanceLoading] = useState(false);
  const [sfBalanceValue, setSfBalanceValue] = useState<number | null>(null);
  const [pathaoStoresLoading, setPathaoStoresLoading] = useState(false);
  const [loadedPathaoStores, setLoadedPathaoStores] = useState<
    Array<{ store_id: string; store_name: string; store_address: string }>
  >([]);
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [copiedTextId, setCopiedTextId] = useState<string | null>(null);

  // --- Fraud Checker State ---
  const [lookupPhone, setLookupPhone] = useState<string>('');
  const [fraudLoading, setFraudLoading] = useState<boolean>(false);
  const [fraudResult, setFraudResult] = useState<CourierFraudCheckResult | null>(null);
  const [checkingOrderId, setCheckingOrderId] = useState<string | null>(null);

  // --- 1-Click Parcel Queue State ---
  const [queueFilter, setQueueFilter] = useState<'ready' | 'booked' | 'all'>('ready');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);
  const [bookingOrderId, setBookingOrderId] = useState<string | null>(null);
  const [bulkBookingCourier, setBulkBookingCourier] = useState<'steadfast' | 'pathao' | null>(null);
  const [syncingStatusOrderId, setSyncingStatusOrderId] = useState<string | null>(null);

  const secretWebhookUrl = useMemo(
    () => getSecretWebhookUrl(steadfastWebhookToken || pathaoWebhookToken),
    [steadfastWebhookToken, pathaoWebhookToken]
  );

  const isSteadfastConfigured = Boolean(steadfastApiKey.trim() && steadfastSecretKey.trim());
  const isPathaoConfigured = Boolean(
    pathaoClientId.trim() &&
      pathaoClientSecret.trim() &&
      pathaoUsername.trim() &&
      pathaoPassword.trim()
  );

  const currentDraftConfig = {
    steadfastEnabled,
    steadfastApiKey: steadfastApiKey.trim(),
    steadfastSecretKey: steadfastSecretKey.trim(),
    steadfastAuthEmail: steadfastAuthEmail.trim(),
    steadfastAuthPassword: steadfastAuthPassword.trim(),
    steadfastWebhookToken: steadfastWebhookToken.trim(),
    pathaoEnabled,
    pathaoSandbox,
    pathaoClientId: pathaoClientId.trim(),
    pathaoClientSecret: pathaoClientSecret.trim(),
    pathaoUsername: pathaoUsername.trim(),
    pathaoPassword: pathaoPassword.trim(),
    pathaoStoreId: pathaoStoreId.trim(),
    pathaoWebhookToken: pathaoWebhookToken.trim(),
    bdcourierApiKey: bdcourierApiKey.trim()
  };

  const handleSaveSettings = () => {
    updateBusiness(currentDraftConfig);
    showToast('Steadfast, Pathao ও ফ্রড চেকার সেটিংস সফলভাবে সেভ হয়েছে!', 'success');
  };

  const handleTestSteadfast = async () => {
    setSfBalanceLoading(true);
    try {
      updateBusiness(currentDraftConfig);
      const res = await checkSteadfastBalance(currentDraftConfig);
      if (res.ok) {
        if (res.balance !== undefined) setSfBalanceValue(res.balance);
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setSfBalanceLoading(false);
    }
  };

  const handleLoadPathaoStores = async () => {
    setPathaoStoresLoading(true);
    try {
      updateBusiness(currentDraftConfig);
      const res = await fetchPathaoStores(currentDraftConfig);
      if (res.ok) {
        setLoadedPathaoStores(res.stores);
        if (res.stores.length > 0 && !pathaoStoreId) {
          const firstId = res.stores[0].store_id;
          setPathaoStoreId(firstId);
          updateBusiness({ ...currentDraftConfig, pathaoStoreId: firstId });
        }
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setPathaoStoresLoading(false);
    }
  };

  const handleCopyWebhook = () => {
    navigator.clipboard?.writeText(secretWebhookUrl);
    setCopiedWebhook(true);
    showToast('Secret Webhook URL কপি করা হয়েছে!', 'success');
    setTimeout(() => setCopiedWebhook(false), 2000);
  };

  const handleCopyCode = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedTextId(id);
    showToast(`কপি করা হয়েছে: ${text}`, 'info');
    setTimeout(() => setCopiedTextId(null), 1800);
  };

  // --- Fraud Check Handlers ---
  const handleRunFraudLookup = async (phoneToCheck?: string, targetOrder?: OnlineOrder) => {
    const raw = phoneToCheck !== undefined ? phoneToCheck : lookupPhone;
    const clean = normalizeBdPhone11(raw);
    if (!/^01\d{9}$/.test(clean)) {
      showToast('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নাম্বার দিন (01XXXXXXXXX)', 'error');
      return;
    }

    setLookupPhone(clean);
    setFraudLoading(true);
    if (targetOrder) setCheckingOrderId(targetOrder.id);

    try {
      const result = await checkCustomerFraudAndRatio(
        clean,
        currentDraftConfig,
        onlineOrders,
        incompleteOrders
      );
      setFraudResult(result);

      if (targetOrder) {
        updateOnlineOrder(targetOrder.id, {
          fraudCheckSummary: {
            totalParcels: result.combinedTotalParcels,
            deliveredParcels: result.combinedDelivered,
            cancelledParcels: result.combinedCancelled,
            successRatio: result.combinedSuccessRatio,
            riskLevel: result.riskLevel,
            checkedAt: result.checkedAt
          }
        });
      }
      showToast(`${clean} নাম্বারের ডেলিভারি রেশিও ও ফ্রড রিপোর্ট প্রস্তুত!`, 'success');
    } finally {
      setFraudLoading(false);
      setCheckingOrderId(null);
    }
  };

  // --- 1-Click Parcel Booking Handlers ---
  const handleBookSingleOrder = async (
    order: OnlineOrder,
    provider: 'steadfast' | 'pathao'
  ) => {
    setBookingOrderId(`${order.id}_${provider}`);
    try {
      const res =
        provider === 'steadfast'
          ? await bookSteadfastOrder(order, currentDraftConfig)
          : await bookPathaoOrder(order, currentDraftConfig);

      if (res.ok) {
        updateOnlineOrder(order.id, {
          courierProvider: provider,
          courierConsignmentId: res.consignmentId || '',
          courierTrackingCode: res.trackingCode || res.consignmentId || '',
          courierStatus: res.status || 'in_review',
          courierBookedAt: new Date().toISOString(),
          orderStatus: order.orderStatus === 'pending' || order.orderStatus === 'confirmed' || order.orderStatus === 'packaging'
            ? 'dispatched'
            : order.orderStatus
        });
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setBookingOrderId(null);
    }
  };

  const handleBulkBookOrders = async (provider: 'steadfast' | 'pathao') => {
    const targets = onlineOrders.filter(
      o => selectedOrderIds.includes(o.id) && !o.courierConsignmentId
    );
    if (targets.length === 0) {
      showToast('বুকিং করার জন্য অন্তত ১টি আন-বুকড অর্ডার সিলেক্ট করুন।', 'error');
      return;
    }

    setBulkBookingCourier(provider);
    let successCount = 0;
    let failCount = 0;

    for (const ord of targets) {
      const res =
        provider === 'steadfast'
          ? await bookSteadfastOrder(ord, currentDraftConfig)
          : await bookPathaoOrder(ord, currentDraftConfig);

      if (res.ok) {
        successCount += 1;
        updateOnlineOrder(ord.id, {
          courierProvider: provider,
          courierConsignmentId: res.consignmentId || '',
          courierTrackingCode: res.trackingCode || res.consignmentId || '',
          courierStatus: res.status || 'in_review',
          courierBookedAt: new Date().toISOString(),
          orderStatus: 'dispatched'
        });
      } else {
        failCount += 1;
      }
    }

    setBulkBookingCourier(null);
    setSelectedOrderIds([]);

    if (successCount > 0) {
      showToast(
        `${successCount}টি পার্সেল সফলভাবে ${provider === 'steadfast' ? 'Steadfast' : 'Pathao'}-এ বুকিং হয়েছে!${
          failCount > 0 ? ` (${failCount}টি ব্যর্থ)` : ''
        }`,
        'success'
      );
    } else {
      showToast(
        `${provider === 'steadfast' ? 'Steadfast' : 'Pathao'} বাল্ক বুকিং ব্যর্থ হয়েছে। API সেটিংস চেক করুন।`,
        'error'
      );
    }
  };

  const handleRefreshCourierStatus = async (order: OnlineOrder) => {
    setSyncingStatusOrderId(order.id);
    try {
      const res = await checkSteadfastOrderStatus(order, currentDraftConfig);
      if (res.ok && res.deliveryStatus) {
        const raw = res.deliveryStatus.toLowerCase();
        let nextOrderStatus = order.orderStatus;
        if (raw.includes('deliver') && !raw.includes('un') && !raw.includes('cancel')) {
          nextOrderStatus = 'delivered';
          await updateOnlineOrderStatus(order.id, 'delivered', 'paid');
        } else if (raw.includes('cancel')) {
          nextOrderStatus = 'cancelled';
          await updateOnlineOrderStatus(order.id, 'cancelled');
        }
        updateOnlineOrder(order.id, {
          courierStatus: res.deliveryStatus,
          orderStatus: nextOrderStatus
        });
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setSyncingStatusOrderId(null);
    }
  };

  const readyToBookOrders = useMemo(
    () =>
      onlineOrders.filter(
        o =>
          !o.courierConsignmentId &&
          o.orderStatus !== 'cancelled' &&
          o.orderStatus !== 'delivered'
      ),
    [onlineOrders]
  );

  const bookedOrders = useMemo(
    () => onlineOrders.filter(o => Boolean(o.courierConsignmentId)),
    [onlineOrders]
  );

  const filteredOrders = useMemo(() => {
    const base =
      queueFilter === 'ready'
        ? readyToBookOrders
        : queueFilter === 'booked'
        ? bookedOrders
        : onlineOrders;
    const q = searchQuery.trim().toLowerCase();
    if (!q) return base;
    return base.filter(
      o =>
        o.orderNo.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerPhone.toLowerCase().includes(q) ||
        (o.courierConsignmentId || '').toLowerCase().includes(q) ||
        (o.courierTrackingCode || '').toLowerCase().includes(q)
    );
  }, [queueFilter, readyToBookOrders, bookedOrders, onlineOrders, searchQuery]);

  const toggleSelectOrder = (id: string) => {
    setSelectedOrderIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAllFiltered = () => {
    const selectableIds = filteredOrders.filter(o => !o.courierConsignmentId).map(o => o.id);
    if (selectableIds.length === 0) return;
    const allSelected = selectableIds.every(id => selectedOrderIds.includes(id));
    if (allSelected) {
      setSelectedOrderIds(prev => prev.filter(id => !selectableIds.includes(id)));
    } else {
      setSelectedOrderIds(Array.from(new Set([...selectedOrderIds, ...selectableIds])));
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Hero Banner */}
      <div className="rounded-2xl border border-indigo-200/80 dark:border-slate-800 bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-600 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800 p-5 sm:p-6 text-white shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-xs text-xs font-bold tracking-wide">
              <Truck className="w-3.5 h-3.5" />
              <span>Steadfast + Pathao + Own Store Fraud Checker</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              কুরিয়ার ইন্টিগ্রেশন ও ১-ক্লিক পার্সেল বুকিং (Courier Integration)
            </h1>
            <p className="text-xs sm:text-sm text-emerald-50/90 max-w-2xl">
              ১ ক্লিকে কাস্টমারের ডেলিভারি রেশিও ও ফ্রড হিস্ট্রি চেক করুন (আপনার নিজস্ব স্টোর + Steadfast + Pathao ডাইরেক্ট চেক — ১০০% ফ্রি) এবং ১ ক্লিকে পার্সেল বুকিং দিন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setActiveTab('parcel_send')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'parcel_send'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>১-ক্লিক পার্সেল বুকিং ({readyToBookOrders.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('fraud_checker')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'fraud_checker'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>ফ্রড ও ডেলিভারি রেশিও চেকার</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('api_settings')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'api_settings'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>API ও Webhook সেটিংস</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Colorful KPI Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-emerald-200 dark:border-emerald-900/50 bg-gradient-to-br from-emerald-50 via-white to-teal-50/70 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/30 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
              Steadfast Courier
            </span>
            <span
              className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                isSteadfastConfigured
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
              }`}
            >
              {isSteadfastConfigured ? 'প্রস্তুত (Ready)' : 'API Key বসান'}
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-lg font-extrabold text-slate-900 dark:text-white font-mono">
              {sfBalanceValue !== null ? `৳${sfBalanceValue}` : isSteadfastConfigured ? 'Connected' : 'Not Set'}
            </div>
            <button
              type="button"
              onClick={handleTestSteadfast}
              disabled={sfBalanceLoading}
              className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer flex items-center gap-1"
            >
              <RefreshCw className={`w-3 h-3 ${sfBalanceLoading ? 'animate-spin' : ''}`} />
              <span>ব্যালেন্স চেক</span>
            </button>
          </div>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            {steadfastAuthEmail ? `ফ্রড চেক ইমেইল: ${steadfastAuthEmail}` : '১-ক্লিকে পার্সেল ও ডাইরেক্ট ফ্রড চেক'}
          </p>
        </div>

        <div className="rounded-2xl border border-rose-200 dark:border-rose-900/50 bg-gradient-to-br from-rose-50 via-white to-orange-50/70 dark:from-slate-900 dark:via-slate-900 dark:to-rose-950/30 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-800 dark:text-rose-300">
              Pathao Courier
            </span>
            <span
              className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                isPathaoConfigured
                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
              }`}
            >
              {isPathaoConfigured ? `Store #${pathaoStoreId || 'Set'}` : 'API Key বসান'}
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-lg font-extrabold text-slate-900 dark:text-white font-mono">
              {isPathaoConfigured ? 'Hermes API' : 'Not Set'}
            </div>
            <button
              type="button"
              onClick={handleLoadPathaoStores}
              disabled={pathaoStoresLoading}
              className="text-[11px] font-bold text-rose-700 dark:text-rose-400 hover:underline cursor-pointer flex items-center gap-1"
            >
              <Store className={`w-3 h-3 ${pathaoStoresLoading ? 'animate-spin' : ''}`} />
              <span>স্টোর টেস্ট</span>
            </button>
          </div>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            Pathao পার্সেল বুকিং ও ডাইরেক্ট কাস্টমার রেশিও চেক
          </p>
        </div>

        <div className="rounded-2xl border border-sky-200 dark:border-sky-900/50 bg-gradient-to-br from-sky-50 via-white to-indigo-50/70 dark:from-slate-900 dark:via-slate-900 dark:to-sky-950/30 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-800 dark:text-sky-300">
              পার্সেল পাঠানোর অপেক্ষায়
            </span>
            <Package className="w-4 h-4 text-sky-600 dark:text-sky-400" />
          </div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
            {readyToBookOrders.length} টি অর্ডার
          </div>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            ১ ক্লিকে Steadfast বা Pathao-তে পাঠানোর জন্য প্রস্তুত
          </p>
        </div>

        <div className="rounded-2xl border border-violet-200 dark:border-violet-900/50 bg-gradient-to-br from-violet-50 via-white to-purple-50/70 dark:from-slate-900 dark:via-slate-900 dark:to-violet-950/30 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-violet-800 dark:text-violet-300">
              কুরিয়ারে বুকিংকৃত পার্সেল
            </span>
            <Truck className="w-4 h-4 text-violet-600 dark:text-violet-400" />
          </div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
            {bookedOrders.length} টি পার্সেল
          </div>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            Consignment ID ও লাইভ স্ট্যাটাস ট্র্যাকিংসহ
          </p>
        </div>
      </div>

      {/* =====================================================================
          TAB 1: 1-CLICK PARCEL SEND & TRACKING QUEUE
         ===================================================================== */}
      {activeTab === 'parcel_send' && (
        <div className="space-y-4">
          {/* Quick Instant Phone Fraud Lookup Bar right inside Parcel Send tab */}
          <div className="rounded-2xl border border-indigo-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    কুইক কাস্টমার ফ্রড ও ডেলিভারি রেশিও চেক (ফ্রি)
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    যেকোনো ১১ ডিজিটের নাম্বার দিয়ে নিজস্ব স্টোর + Steadfast + Pathao ডেলিভারি রেকর্ড দেখুন
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto">
                <div className="relative flex-1 md:w-64">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={lookupPhone}
                    onChange={e => setLookupPhone(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') handleRunFraudLookup();
                    }}
                    placeholder="01XXXXXXXXX নাম্বার দিন..."
                    className="w-full pl-9 pr-3 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleRunFraudLookup()}
                  disabled={fraudLoading}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shrink-0"
                >
                  {fraudLoading ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Search className="w-3.5 h-3.5" />
                  )}
                  <span>ফ্রড চেক করুন</span>
                </button>
              </div>
            </div>

            {/* Inline Fraud Check Result Banner if checked */}
            {fraudResult && (
              <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                <FraudResultSummaryCard
                  result={fraudResult}
                  formatCurrency={formatCurrency}
                  onClose={() => setFraudResult(null)}
                />
              </div>
            )}
          </div>

          {/* Filter & Bulk Action Toolbar */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs space-y-3">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setQueueFilter('ready')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                    queueFilter === 'ready'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  বুকিংয়ের জন্য প্রস্তুত ({readyToBookOrders.length})
                </button>
                <button
                  type="button"
                  onClick={() => setQueueFilter('booked')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                    queueFilter === 'booked'
                      ? 'bg-violet-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  কুরিয়ারে পাঠানো হয়েছে ({bookedOrders.length})
                </button>
                <button
                  type="button"
                  onClick={() => setQueueFilter('all')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                    queueFilter === 'all'
                      ? 'bg-slate-900 dark:bg-slate-700 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  সকল অর্ডার ({onlineOrders.length})
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative flex-1 sm:w-64">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="অর্ডার নং, নাম, ফোন বা ট্র্যাকিং কোড..."
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {selectedOrderIds.length > 0 && (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleBulkBookOrders('steadfast')}
                      disabled={bulkBookingCourier !== null}
                      className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>
                        {bulkBookingCourier === 'steadfast'
                          ? 'পাঠানো হচ্ছে...'
                          : `${selectedOrderIds.length}টি Steadfast-এ পাঠান`}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleBulkBookOrders('pathao')}
                      disabled={bulkBookingCourier !== null}
                      className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>
                        {bulkBookingCourier === 'pathao'
                          ? 'পাঠানো হচ্ছে...'
                          : `${selectedOrderIds.length}টি Pathao-তে পাঠান`}
                      </span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Orders Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-800/50">
                    <th className="py-3 px-3 w-9">
                      <input
                        type="checkbox"
                        onChange={toggleSelectAllFiltered}
                        checked={
                          filteredOrders.filter(o => !o.courierConsignmentId).length > 0 &&
                          filteredOrders
                            .filter(o => !o.courierConsignmentId)
                            .every(o => selectedOrderIds.includes(o.id))
                        }
                        className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                    </th>
                    <th className="py-3 px-3">অর্ডার ও তারিখ</th>
                    <th className="py-3 px-3">কাস্টমার ও ঠিকানা</th>
                    <th className="py-3 px-3">ডেলিভারি রেশিও / ফ্রড চেক</th>
                    <th className="py-3 px-3">ক্যাশ অন ডেলিভারি (COD)</th>
                    <th className="py-3 px-3 text-right">১-ক্লিক কুরিয়ার বুকিং ও ট্র্যাকিং</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/70 dark:divide-slate-800 text-xs">
                  {filteredOrders.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-10 text-center text-slate-500 dark:text-slate-400">
                        এই তালিকায় কোনো অর্ডার পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    filteredOrders.map(order => {
                      const ownStats = computeOwnStoreCustomerRecord(
                        order.customerPhone,
                        onlineOrders,
                        incompleteOrders
                      );
                      const cachedFraud = order.fraudCheckSummary;
                      const displayRatio = cachedFraud
                        ? cachedFraud.successRatio
                        : ownStats.successRatio;
                      const displayRisk = cachedFraud ? cachedFraud.riskLevel : ownStats.riskLevel;

                      const isBookingSf = bookingOrderId === `${order.id}_steadfast`;
                      const isBookingPt = bookingOrderId === `${order.id}_pathao`;
                      const isCheckingThis = checkingOrderId === order.id;

                      return (
                        <tr
                          key={order.id}
                          className="hover:bg-slate-50/90 dark:hover:bg-slate-800/40 transition-colors"
                        >
                          <td className="py-3.5 px-3 align-top">
                            {!order.courierConsignmentId && (
                              <input
                                type="checkbox"
                                checked={selectedOrderIds.includes(order.id)}
                                onChange={() => toggleSelectOrder(order.id)}
                                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer mt-1"
                              />
                            )}
                          </td>

                          <td className="py-3.5 px-3 align-top">
                            <div className="font-bold text-slate-900 dark:text-white font-mono">
                              #{order.orderNo}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                              {formatDate(order.createdAt)}
                            </div>
                            <span
                              className={`inline-block mt-1 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                                order.orderStatus === 'delivered'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : order.orderStatus === 'dispatched'
                                  ? 'bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-300'
                                  : order.orderStatus === 'cancelled'
                                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              }`}
                            >
                              {order.orderStatus}
                            </span>
                          </td>

                          <td className="py-3.5 px-3 align-top max-w-xs">
                            <div className="font-bold text-slate-900 dark:text-white">
                              {order.customerName}
                            </div>
                            <div className="font-mono text-xs font-semibold text-indigo-700 dark:text-indigo-300 mt-0.5">
                              {order.customerPhone}
                            </div>
                            <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2 flex items-start gap-1">
                              <MapPin className="w-3 h-3 shrink-0 mt-0.5 text-slate-400" />
                              <span>
                                {order.deliveryAddress} ({order.deliveryArea})
                              </span>
                            </div>
                          </td>

                          <td className="py-3.5 px-3 align-top">
                            <div className="flex flex-col gap-1.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span
                                  className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                    displayRisk === 'safe'
                                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                      : displayRisk === 'high_risk'
                                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                      : displayRisk === 'moderate'
                                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                      : 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                                  }`}
                                >
                                  {displayRisk === 'safe'
                                    ? `নিরাপদ (${displayRatio}%)`
                                    : displayRisk === 'high_risk'
                                    ? `ঝুঁকিপূর্ণ (${displayRatio}%)`
                                    : displayRisk === 'moderate'
                                    ? `মাঝারি (${displayRatio}%)`
                                    : 'নতুন কাস্টমার'}
                                </span>

                                <button
                                  type="button"
                                  onClick={() => handleRunFraudLookup(order.customerPhone, order)}
                                  disabled={isCheckingThis}
                                  className="px-2 py-0.5 rounded-md bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/70 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold cursor-pointer inline-flex items-center gap-1 border border-indigo-200 dark:border-indigo-800"
                                >
                                  {isCheckingThis ? (
                                    <RefreshCw className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <Search className="w-3 h-3" />
                                  )}
                                  <span>🔍 ফ্রড চেক</span>
                                </button>
                              </div>

                              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                                স্টোর রেকর্ড: অর্ডার {ownStats.totalOrders}টি · ডেলিভারি {ownStats.delivered} · বাতিল {ownStats.cancelled}
                                {cachedFraud && (
                                  <span className="ml-1 text-indigo-600 dark:text-indigo-400 font-semibold">
                                    | কুরিয়ার মোট: {cachedFraud.deliveredParcels}/{cachedFraud.totalParcels}
                                  </span>
                                )}
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-3 align-top">
                            <div className="font-bold text-slate-900 dark:text-white font-mono">
                              {formatCurrency(order.paymentStatus === 'paid' ? 0 : order.grandTotal)}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400">
                              {order.items.length}টি পণ্য ·{' '}
                              {order.paymentStatus === 'paid' ? 'Paid' : 'COD'}
                            </div>
                          </td>

                          <td className="py-3.5 px-3 align-top text-right">
                            {order.courierConsignmentId ? (
                              <div className="inline-flex flex-col items-end gap-1">
                                <div className="flex items-center gap-1.5">
                                  <span
                                    className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase ${
                                      order.courierProvider === 'pathao'
                                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                        : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                    }`}
                                  >
                                    {order.courierProvider === 'pathao' ? 'Pathao' : 'Steadfast'}
                                  </span>
                                  <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                                    CID: {order.courierConsignmentId}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleCopyCode(
                                        order.courierTrackingCode || order.courierConsignmentId || '',
                                        order.id
                                      )
                                    }
                                    className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 cursor-pointer"
                                    title="Copy Tracking / Consignment ID"
                                  >
                                    {copiedTextId === order.id ? (
                                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                                    ) : (
                                      <Copy className="w-3.5 h-3.5" />
                                    )}
                                  </button>
                                </div>

                                <div className="flex items-center gap-2">
                                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                                    স্ট্যাটাস:{' '}
                                    <strong className="text-slate-800 dark:text-slate-200">
                                      {order.courierStatus || 'in_review'}
                                    </strong>
                                  </span>
                                  {order.courierProvider !== 'pathao' && (
                                    <button
                                      type="button"
                                      onClick={() => handleRefreshCourierStatus(order)}
                                      disabled={syncingStatusOrderId === order.id}
                                      className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-[11px] font-bold text-slate-700 dark:text-slate-300 cursor-pointer inline-flex items-center gap-1"
                                    >
                                      <RefreshCw
                                        className={`w-3 h-3 ${
                                          syncingStatusOrderId === order.id ? 'animate-spin' : ''
                                        }`}
                                      />
                                      <span>স্ট্যাটাস চেক</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <div className="inline-flex flex-wrap items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleBookSingleOrder(order, 'steadfast')}
                                  disabled={isBookingSf || isBookingPt}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                                >
                                  {isBookingSf ? (
                                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <Truck className="w-3.5 h-3.5" />
                                  )}
                                  <span>Steadfast-এ পাঠান</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleBookSingleOrder(order, 'pathao')}
                                  disabled={isBookingSf || isBookingPt}
                                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                                >
                                  {isBookingPt ? (
                                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <Send className="w-3.5 h-3.5" />
                                  )}
                                  <span>Pathao-তে পাঠান</span>
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 2: DEDICATED CUSTOMER FRAUD & DELIVERY RATIO CHECKER
         ===================================================================== */}
      {activeTab === 'fraud_checker' && (
        <div className="space-y-5">
          <div className="rounded-2xl border border-indigo-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs space-y-5">
            <div className="max-w-2xl space-y-1.5">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <span>কাস্টমার ফ্রড ও ডেলিভারি সাকসেস রেশিও চেকার (১০০% ফ্রি)</span>
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                কাস্টমারের ১১ ডিজিটের মোবাইল নাম্বার দিয়ে সার্চ করলেই আপনার নিজস্ব স্টোরের রেকর্ড + Steadfast পোর্টাল + Pathao পোর্টালের ডেলিভারি ও ক্যানসেল রেশিও একসাথে দেখতে পাবেন।
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 max-w-xl">
              <div className="relative flex-1">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  value={lookupPhone}
                  onChange={e => setLookupPhone(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleRunFraudLookup();
                  }}
                  placeholder="কাস্টমারের মোবাইল নাম্বার লিখুন (যেমন: 017XXXXXXXX)"
                  className="w-full pl-10 pr-4 py-3 text-sm font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                type="button"
                onClick={() => handleRunFraudLookup()}
                disabled={fraudLoading}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white text-xs sm:text-sm font-bold cursor-pointer flex items-center justify-center gap-2 shadow-sm"
              >
                {fraudLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Search className="w-4 h-4" />
                )}
                <span>ডেলিভারি রেশিও ও ফ্রড চেক করুন</span>
              </button>
            </div>

            {fraudResult && (
              <FraudResultSummaryCard
                result={fraudResult}
                formatCurrency={formatCurrency}
              />
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: STEADFAST, PATHAO & WEBHOOK API SETTINGS
         ===================================================================== */}
      {activeTab === 'api_settings' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 1. Steadfast Courier & Webhook Configuration Card */}
            <div className="rounded-2xl border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs space-y-5">
              <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-extrabold text-sm">
                    SF
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                      Steadfast Courier & Fraud Check Setup
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      portal.packzy.com / steadfast.com.bd API ও ফ্রি ফ্রড চেকার সেটআপ
                    </p>
                  </div>
                </div>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={steadfastEnabled}
                    onChange={e => setSteadfastEnabled(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">সক্রিয়</span>
                </label>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    SteadFast ApiKey <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={steadfastApiKey}
                    onChange={e => setSteadfastApiKey(e.target.value)}
                    placeholder="আপনার Steadfast Api-Key পেস্ট করুন..."
                    className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    SteadFast Api Secret <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showSfSecret ? 'text' : 'password'}
                      value={steadfastSecretKey}
                      onChange={e => setSteadfastSecretKey(e.target.value)}
                      placeholder="আপনার Steadfast Secret-Key পেস্ট করুন..."
                      className="w-full pl-3.5 pr-10 py-2.5 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowSfSecret(!showSfSecret)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showSfSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Steadfast Account Email & Password for Direct Portal Fraud Checker */}
                <div className="rounded-xl border border-emerald-200/80 dark:border-emerald-900/50 bg-emerald-50/50 dark:bg-emerald-950/20 p-3.5 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 dark:text-emerald-300">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Steadfast ফ্রি ফ্রড চেকার লগইন তথ্য (Steadfast Account Email & Password)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    Steadfast-এর ফ্রি কাস্টমার ফ্রড ও ডেলিভারি রেশিও চেক করার জন্য আপনার Steadfast অ্যাকাউন্টের ইমেইল ও পাসওয়ার্ড দিন:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Steadfast Account Email
                      </label>
                      <div className="relative">
                        <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          value={steadfastAuthEmail}
                          onChange={e => setSteadfastAuthEmail(e.target.value)}
                          placeholder="merchant@email.com"
                          className="w-full pl-8 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Steadfast Account Password
                      </label>
                      <div className="relative">
                        <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type={showSfPass ? 'text' : 'password'}
                          value={steadfastAuthPassword}
                          onChange={e => setSteadfastAuthPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-8 pr-9 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                        />
                        <button
                          type="button"
                          onClick={() => setShowSfPass(!showSfPass)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          {showSfPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* STEADFAST Webhook Configuration */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-3.5 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <Webhook className="w-4 h-4 text-indigo-600" />
                    <span>STEADFAST Webhook Configuration</span>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      Secret Webhook URL (Steadfast ড্যাশবোর্ডে বসানোর জন্য কপি করুন)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        readOnly
                        value={secretWebhookUrl}
                        className="flex-1 px-3 py-2 text-[11px] font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300"
                      />
                      <button
                        type="button"
                        onClick={handleCopyWebhook}
                        className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1 shrink-0"
                      >
                        {copiedWebhook ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedWebhook ? 'কপি হয়েছে' : 'কপি URL'}</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      Steadfast Webhook Token (Optional)
                    </label>
                    <input
                      type="text"
                      value={steadfastWebhookToken}
                      onChange={e => setSteadfastWebhookToken(e.target.value)}
                      placeholder="অপশনাল ওয়েবহুক সিক্রেট টোকেন..."
                      className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleTestSteadfast}
                    disabled={sfBalanceLoading}
                    className="px-4 py-2.5 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-bold cursor-pointer inline-flex items-center gap-1.5"
                  >
                    <Wallet className="w-4 h-4" />
                    <span>
                      {sfBalanceLoading ? 'চেক হচ্ছে...' : 'ব্যালেন্স ও কানেকশন টেস্ট করুন'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveSettings}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Steadfast সেটিংস সেভ করুন</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 2. Pathao Courier Configuration Card */}
            <div className="rounded-2xl border border-rose-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs space-y-5">
              <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 flex items-center justify-center font-extrabold text-sm">
                    PT
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                      Pathao Courier API & Fraud Check Setup
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      merchant.pathao.com (Hermes API v1) ও ডাইরেক্ট কাস্টমার রেশিও চেক
                    </p>
                  </div>
                </div>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={pathaoEnabled}
                    onChange={e => setPathaoEnabled(e.target.checked)}
                    className="rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                  />
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">সক্রিয়</span>
                </label>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Pathao Client ID <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={pathaoClientId}
                      onChange={e => setPathaoClientId(e.target.value)}
                      placeholder="Client ID..."
                      className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Pathao Client Secret <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showPathaoSecret ? 'text' : 'password'}
                        value={pathaoClientSecret}
                        onChange={e => setPathaoClientSecret(e.target.value)}
                        placeholder="Client Secret..."
                        className="w-full pl-3.5 pr-9 py-2.5 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPathaoSecret(!showPathaoSecret)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showPathaoSecret ? (
                          <EyeOff className="w-3.5 h-3.5" />
                        ) : (
                          <Eye className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Pathao Username (Merchant Email) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={pathaoUsername}
                      onChange={e => setPathaoUsername(e.target.value)}
                      placeholder="merchant@email.com"
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Pathao Account Password <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showPathaoPass ? 'text' : 'password'}
                        value={pathaoPassword}
                        onChange={e => setPathaoPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-3.5 pr-9 py-2.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPathaoPass(!showPathaoPass)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showPathaoPass ? (
                          <EyeOff className="w-3.5 h-3.5" />
                        ) : (
                          <Eye className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Store ID Input + 1-Click Auto-Fetch Stores */}
                <div className="rounded-xl border border-rose-200/80 dark:border-rose-900/50 bg-rose-50/40 dark:bg-rose-950/20 p-3.5 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                      Pathao Store ID <span className="text-rose-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={handleLoadPathaoStores}
                      disabled={pathaoStoresLoading}
                      className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer inline-flex items-center gap-1"
                    >
                      <RefreshCw className={`w-3 h-3 ${pathaoStoresLoading ? 'animate-spin' : ''}`} />
                      <span>Pathao থেকে Store ID লোড করুন</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={pathaoStoreId}
                      onChange={e => setPathaoStoreId(e.target.value)}
                      placeholder="যেমন: 12345"
                      className="flex-1 px-3.5 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                    />
                    {loadedPathaoStores.length > 0 && (
                      <select
                        value={pathaoStoreId}
                        onChange={e => setPathaoStoreId(e.target.value)}
                        className="px-3 py-2 text-xs rounded-xl border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        {loadedPathaoStores.map(s => (
                          <option key={s.store_id} value={s.store_id}>
                            {s.store_name} (#{s.store_id})
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={pathaoSandbox}
                      onChange={e => setPathaoSandbox(e.target.checked)}
                      className="rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                    />
                    <span className="text-xs text-slate-600 dark:text-slate-400">
                      Sandbox (Test Mode) ব্যবহার করুন
                    </span>
                  </label>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleLoadPathaoStores}
                    disabled={pathaoStoresLoading}
                    className="px-4 py-2.5 rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 text-xs font-bold cursor-pointer inline-flex items-center gap-1.5"
                  >
                    <Store className="w-4 h-4" />
                    <span>
                      {pathaoStoresLoading ? 'টেস্ট হচ্ছে...' : 'টোকেন ও স্টোর কানেকশন টেস্ট'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveSettings}
                    className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Pathao সেটিংস সেভ করুন</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Optional BDCourier Aggregator Key */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 dark:text-indigo-300">
                  <Sparkles className="w-4 h-4" />
                  <span>অপশনাল: BDCourier API Key (যদি ভবিষ্যতে ৪-কুরিয়ার পেইড এগ্রিগেটর ব্যবহার করতে চান)</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  উপরের Steadfast ও Pathao ডাইরেক্ট চেক সম্পূর্ণ ফ্রি। তবে আপনি চাইলে অপশনাল BDCourier API টোকেনও এখানে যুক্ত রাখতে পারেন।
                </p>
              </div>
              <div className="flex items-center gap-2 w-full md:w-96">
                <input
                  type="password"
                  value={bdcourierApiKey}
                  onChange={e => setBdcourierApiKey(e.target.value)}
                  placeholder="Optional BDCourier Bearer API Key..."
                  className="flex-1 px-3.5 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <button
                  type="button"
                  onClick={handleSaveSettings}
                  className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-indigo-600 text-white text-xs font-bold cursor-pointer shrink-0"
                >
                  সেভ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface FraudResultSummaryCardProps {
  result: CourierFraudCheckResult;
  formatCurrency: (n: number) => string;
  onClose?: () => void;
}

const FraudResultSummaryCard: React.FC<FraudResultSummaryCardProps> = ({
  result,
  formatCurrency,
  onClose
}) => {
  const badgeColors =
    result.riskLevel === 'safe'
      ? 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-200 dark:border-emerald-800'
      : result.riskLevel === 'high_risk'
      ? 'bg-rose-100 text-rose-900 border-rose-300 dark:bg-rose-950/70 dark:text-rose-200 dark:border-rose-800'
      : result.riskLevel === 'moderate'
      ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950/70 dark:text-amber-200 dark:border-amber-800'
      : 'bg-sky-100 text-sky-900 border-sky-300 dark:bg-sky-950/70 dark:text-sky-200 dark:border-sky-800';

  return (
    <div className="rounded-2xl border border-indigo-200 dark:border-slate-700 bg-gradient-to-br from-slate-50 via-white to-indigo-50/40 dark:from-slate-800/90 dark:via-slate-900 dark:to-slate-800 p-4 sm:p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-2xl flex items-center justify-center font-extrabold text-sm border ${badgeColors}`}
          >
            {result.combinedSuccessRatio}%
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-sm font-extrabold text-slate-900 dark:text-white">
                {result.phone}
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeColors}`}>
                {result.riskLevel === 'safe'
                  ? 'নিরাপদ কাস্টমার (Safe)'
                  : result.riskLevel === 'high_risk'
                  ? 'ঝুঁকিপূর্ণ / ফ্রড সতর্কতা (High Risk)'
                  : result.riskLevel === 'moderate'
                  ? 'মাঝারি ঝুঁকি (Moderate)'
                  : 'নতুন কাস্টমার (New)'}
              </span>
            </div>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mt-0.5">
              {result.verdictBn}
            </p>
          </div>
        </div>

        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white self-end sm:self-center cursor-pointer"
          >
            বন্ধ করুন ✕
          </button>
        )}
      </div>

      {/* Delivery Ratio Visual Progress Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="text-emerald-700 dark:text-emerald-400">
            মোট সফল ডেলিভারি: {result.combinedDelivered}টি ({result.combinedSuccessRatio}%)
          </span>
          <span className="text-rose-600 dark:text-rose-400">
            মোট ক্যানসেল/রিটার্ন: {result.combinedCancelled}টি
          </span>
        </div>
        <div className="w-full h-3 rounded-full bg-rose-100 dark:bg-slate-700 overflow-hidden flex">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-300"
            style={{
              width: `${
                result.combinedTotalParcels > 0 ? result.combinedSuccessRatio : 50
              }%`
            }}
          />
        </div>
      </div>

      {/* 3 Breakdown Cards: Own Store + Steadfast + Pathao */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* 1. Own Store Record */}
        <div className="rounded-xl border border-indigo-200/80 dark:border-slate-700 bg-white dark:bg-slate-900 p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-indigo-800 dark:text-indigo-300">
              ১. আপনার নিজস্ব স্টোরের রেকর্ড
            </span>
            <span className="px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 text-[10px] font-bold">
              {result.ownStore.successRatio}% সফল
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center pt-1">
            <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-2">
              <div className="text-[10px] text-slate-500">মোট অর্ডার</div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono">
                {result.ownStore.totalOrders}
              </div>
            </div>
            <div className="rounded-lg bg-emerald-50 dark:bg-emerald-950/50 p-2">
              <div className="text-[10px] text-emerald-700 dark:text-emerald-300">ডেলিভারড</div>
              <div className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300 font-mono">
                {result.ownStore.delivered}
              </div>
            </div>
            <div className="rounded-lg bg-rose-50 dark:bg-rose-950/50 p-2">
              <div className="text-[10px] text-rose-700 dark:text-rose-300">বাতিল</div>
              <div className="text-sm font-extrabold text-rose-700 dark:text-rose-300 font-mono">
                {result.ownStore.cancelled}
              </div>
            </div>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between pt-1">
            <span>মোট কেনাকাটা: {formatCurrency(result.ownStore.totalSpentDelivered)}</span>
            <span>অসম্পূর্ণ লিড: {result.ownStore.abandonedLeads}টি</span>
          </div>
        </div>

        {/* 2. Steadfast Direct Record */}
        <div className="rounded-xl border border-emerald-200/80 dark:border-slate-700 bg-white dark:bg-slate-900 p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-emerald-800 dark:text-emerald-300">
              ২. Steadfast ডাইরেক্ট চেক
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold">
              {result.steadfast.successRatio}% সফল
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center pt-1">
            <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-2">
              <div className="text-[10px] text-slate-500">মোট পার্সেল</div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono">
                {result.steadfast.total}
              </div>
            </div>
            <div className="rounded-lg bg-emerald-50 dark:bg-emerald-950/50 p-2">
              <div className="text-[10px] text-emerald-700 dark:text-emerald-300">ডেলিভারড</div>
              <div className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300 font-mono">
                {result.steadfast.delivered}
              </div>
            </div>
            <div className="rounded-lg bg-rose-50 dark:bg-rose-950/50 p-2">
              <div className="text-[10px] text-rose-700 dark:text-rose-300">ক্যানসেল</div>
              <div className="text-sm font-extrabold text-rose-700 dark:text-rose-300 font-mono">
                {result.steadfast.cancelled}
              </div>
            </div>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 pt-1 truncate">
            {result.steadfast.message || 'Steadfast কুরিয়ার রিপোর্ট'}
          </div>
        </div>

        {/* 3. Pathao Direct Record */}
        <div className="rounded-xl border border-rose-200/80 dark:border-slate-700 bg-white dark:bg-slate-900 p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-rose-800 dark:text-rose-300">
              ৩. Pathao ডাইরেক্ট চেক
            </span>
            <span className="px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 text-[10px] font-bold">
              {result.pathao.successRatio}% সফল
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center pt-1">
            <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-2">
              <div className="text-[10px] text-slate-500">মোট পার্সেল</div>
              <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono">
                {result.pathao.total}
              </div>
            </div>
            <div className="rounded-lg bg-emerald-50 dark:bg-emerald-950/50 p-2">
              <div className="text-[10px] text-emerald-700 dark:text-emerald-300">ডেলিভারড</div>
              <div className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300 font-mono">
                {result.pathao.delivered}
              </div>
            </div>
            <div className="rounded-lg bg-rose-50 dark:bg-rose-950/50 p-2">
              <div className="text-[10px] text-rose-700 dark:text-rose-300">ক্যানসেল</div>
              <div className="text-sm font-extrabold text-rose-700 dark:text-rose-300 font-mono">
                {result.pathao.cancelled}
              </div>
            </div>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 pt-1 truncate">
            {result.pathao.message || 'Pathao কুরিয়ার রিপোর্ট'}
          </div>
        </div>
      </div>
    </div>
  );
};
