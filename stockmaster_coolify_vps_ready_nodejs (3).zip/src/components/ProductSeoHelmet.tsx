import React, { useEffect } from 'react';
import { Business, Product, ProductVariant } from '../types';

interface ProductSeoHelmetProps {
  business: Business;
  product?: Product | null;
  activeVariant?: ProductVariant;
  availableStock?: number;
}

/**
 * Helper to generate a rich default Bengali + English product description
 * when a product does not have a custom description saved yet.
 */
export const getEffectiveProductDescription = (product: Product): string => {
  if (product.description && product.description.trim() !== '') {
    return product.description.trim();
  }

  const sku = (product.sku || '').toUpperCase();
  const isBaby =
    sku.includes('BABY') ||
    product.nameBn.includes('বেবি') ||
    product.nameBn.includes('কিডস') ||
    product.variants?.some(v => v.label.toLowerCase().includes('year'));

  const variantLabels =
    product.variants && product.variants.length > 0
      ? product.variants.map(v => v.label).join(', ')
      : product.unit;

  if (isBaby) {
    return `${product.nameBn} (${product.nameEn}) — বাচ্চাদের ত্বকের জন্য ১০০% সফট, আরামদায়ক ও ব্রেদেবল প্রিমিয়াম ফেব্রিকে তৈরি। পার্টি, জন্মদিন, উৎসব কিংবা প্রতিদিনের ব্যবহারের জন্য অত্যন্ত আকর্ষণীয় ডিজাইন ও নিখুঁত সেলাই ফিনিশিং। এভেইলেবল বয়স/সাইজ ভেরিয়েশন: ${variantLabels}। সারাদেশে দ্রুত হোম ডেলিভারি এবং পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধের (Cash on Delivery) সুবিধা রয়েছে।`;
  }

  return `${product.nameBn} (${product.nameEn}) — উন্নতমানের আরামদায়ক ফেব্রিক ও আধুনিক ফ্যাশনেবল কাটিংয়ে তৈরি এক্সপোর্ট কোয়ালিটি পোশাক। দীর্ঘদিন ব্যবহারেও রঙ ও কাপড়ের মান অটুট থাকে। এভেইলেবল সাইজ ভেরিয়েশন: ${variantLabels}। সারাদেশে ক্যাশ অন ডেলিভারি (পণ্য হাতে পেয়ে পেমেন্ট) সুবিধায় অর্ডার করুন।`;
};

/**
 * Imperatively upserts a <meta> tag in document.head so Facebook, WhatsApp,
 * and browser share sheets always read the exact current tag without duplicates.
 */
function upsertMetaTag(
  attrName: 'name' | 'property',
  attrValue: string,
  content: string
) {
  if (typeof document === 'undefined') return;
  let el = document.head.querySelector(
    `meta[${attrName}="${attrValue}"]`
  ) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attrName, attrValue);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function upsertCanonicalLink(href: string) {
  if (typeof document === 'undefined') return;
  let link = document.head.querySelector(
    'link[rel="canonical"]'
  ) as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
}

export function upsertFaviconLink(href: string) {
  if (typeof document === 'undefined' || !href) return;
  const rels = ['icon', 'shortcut icon', 'apple-touch-icon'];
  rels.forEach(rel => {
    let link = document.head.querySelector(
      `link[rel="${rel}"]`
    ) as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.setAttribute('rel', rel);
      document.head.appendChild(link);
    }
    link.setAttribute('href', href);
  });
}

function upsertJsonLdScript(id: string, jsonPayload: Record<string, unknown>) {
  if (typeof document === 'undefined') return;
  let script = document.getElementById(id) as HTMLScriptElement | null;
  if (!script) {
    script = document.createElement('script');
    script.id = id;
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  script.textContent = JSON.stringify(jsonPayload);
}

/**
 * React Helmet SEO & OpenGraph Component for Individual Product Pages & Storefront.
 * Dynamically generates <title>, Meta Description, Favicon, Facebook/WhatsApp OpenGraph tags,
 * Twitter Cards, Canonical URLs, and Schema.org Product JSON-LD structured data.
 */
export const ProductSeoHelmet: React.FC<ProductSeoHelmetProps> = ({
  business,
  product,
  activeVariant,
  availableStock = 10
}) => {
  const cleanStoreName = business.name.replace('স্টকমাস্টার বিডি - ', '').trim();
  const origin =
    typeof window !== 'undefined' ? window.location.origin : '';
  const pathname =
    typeof window !== 'undefined' ? window.location.pathname : '/';

  const activePrice = product
    ? activeVariant
      ? activeVariant.retailPrice
      : product.retailPrice
    : 0;

  const rawRegularPrice = product
    ? Number(activeVariant?.regularPrice ?? product.regularPrice ?? 0)
    : 0;
  const rawDiscountPrice = product
    ? Number(activeVariant?.discountPrice ?? product.discountPrice ?? 0)
    : 0;
  const hasDiscount = rawRegularPrice > activePrice && rawDiscountPrice !== 0;
  const regularPriceForCatalog = hasDiscount ? rawRegularPrice : activePrice;

  const slugBase = product
    ? (product.nameEn || product.sku || product.id)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
    : '';
  const productSlugPath = product
    ? `/product/${slugBase ? `${slugBase}--${product.id}` : product.id}`
    : pathname;

  const canonicalUrl = product
    ? `${origin}${productSlugPath}`
    : `${origin}${pathname}`;

  const customGlobalTitle = business.seoTitle?.trim() || '';
  const customGlobalDescription = business.seoDescription?.trim() || '';
  const customGlobalKeywords = business.seoKeywords?.trim() || '';

  const pageTitle = product
    ? `${product.nameBn} – মাত্র ৳${activePrice} | ${cleanStoreName}`
    : customGlobalTitle || `${cleanStoreName} – প্রিমিয়াম ফ্যাশন ও বেবি ড্রেস কালেকশন`;

  const rawDescription = product
    ? getEffectiveProductDescription(product)
    : customGlobalDescription ||
      `${cleanStoreName} — প্রিমিয়াম বেবি ফ্রক, পার্টি ড্রেস, পাঞ্জাবি ও ফ্যাশন কালেকশন। ১-১২ বছরের বেবি ড্রেস ও সকল সাইজ ভেরিয়েশনে সারাদেশে ক্যাশ অন ডেলিভারি সুবিধা।`;

  const metaDescription =
    rawDescription.length > 160
      ? `${rawDescription.slice(0, 157)}...`
      : rawDescription;

  const effectiveFavicon =
    business.faviconUrl?.trim() ||
    business.logoUrl?.trim() ||
    '';

  const ogImage =
    (product?.image && product.image.trim() !== ''
      ? product.image
      : product?.galleryImages?.[0]) ||
    business.seoOgImageUrl?.trim() ||
    business.logoUrl ||
    business.faviconUrl ||
    '';

  const resolvedOgImage =
    ogImage.startsWith('http://') || ogImage.startsWith('https://')
      ? ogImage
      : ogImage.startsWith('data:') && product
      ? `${origin}/api/index.php?route=product-image&id=${encodeURIComponent(product.id)}`
      : ogImage.startsWith('data:')
      ? ogImage
      : `${origin}${ogImage.startsWith('/') ? '' : '/'}${ogImage}`;

  useEffect(() => {
    if (typeof document === 'undefined') return;

    // 1. Update Document Title & Favicon
    document.title = pageTitle;
    upsertFaviconLink(effectiveFavicon);

    // 2. Standard SEO Meta Tags
    upsertMetaTag('name', 'description', metaDescription);
    if (customGlobalKeywords) {
      upsertMetaTag('name', 'keywords', customGlobalKeywords);
    }

    // 3. OpenGraph Meta Tags for Facebook & WhatsApp Rich Previews
    upsertMetaTag('property', 'og:type', product ? 'product' : 'website');
    upsertMetaTag('property', 'og:site_name', cleanStoreName);
    upsertMetaTag('property', 'og:title', product ? product.nameBn : pageTitle);
    upsertMetaTag('property', 'og:description', rawDescription);
    upsertMetaTag('property', 'og:url', canonicalUrl);
    upsertMetaTag('property', 'og:image', resolvedOgImage);
    upsertMetaTag(
      'property',
      'og:image:alt',
      product ? `${product.nameBn} - ৳${activePrice}` : cleanStoreName
    );
    upsertMetaTag('property', 'og:locale', 'bn_BD');

    // Product-specific OpenGraph & Meta Pixel Catalog Microdata Tags
    if (product) {
      upsertMetaTag('property', 'product:retailer_item_id', product.id);
      upsertMetaTag('property', 'product:item_group_id', product.id);
      upsertMetaTag('property', 'product:brand', cleanStoreName);
      upsertMetaTag(
        'property',
        'product:availability',
        availableStock > 0 ? 'in stock' : 'out of stock'
      );
      upsertMetaTag('property', 'product:condition', 'new');
      upsertMetaTag('property', 'product:price:amount', String(regularPriceForCatalog));
      upsertMetaTag('property', 'product:price:currency', 'BDT');
      if (hasDiscount) {
        upsertMetaTag('property', 'product:sale_price:amount', String(activePrice));
        upsertMetaTag('property', 'product:sale_price:currency', 'BDT');
      } else {
        upsertMetaTag('property', 'product:sale_price:amount', String(activePrice));
        upsertMetaTag('property', 'product:sale_price:currency', 'BDT');
      }
    }

    // 4. Twitter / X Card Meta Tags
    upsertMetaTag('name', 'twitter:card', 'summary_large_image');
    upsertMetaTag('name', 'twitter:title', pageTitle);
    upsertMetaTag('name', 'twitter:description', metaDescription);
    upsertMetaTag('name', 'twitter:image', resolvedOgImage);

    // 5. Canonical Link
    upsertCanonicalLink(canonicalUrl);

    // 6. Schema.org Structured Data (JSON-LD) for Meta Pixel Microdata & Google Rich Snippets
    if (product) {
      upsertJsonLdScript('dynamic-seo-jsonld', {
        '@context': 'https://schema.org',
        '@type': 'Product',
        productID: product.id,
        sku: product.id,
        mpn: product.sku || product.id,
        name: product.nameBn,
        alternateName: product.nameEn,
        description: rawDescription,
        image: [resolvedOgImage, ...(product.galleryImages || [])],
        brand: {
          '@type': 'Brand',
          name: cleanStoreName
        },
        offers: {
          '@type': 'Offer',
          url: canonicalUrl,
          priceCurrency: 'BDT',
          price: String(activePrice),
          availability:
            availableStock > 0
              ? 'https://schema.org/InStock'
              : 'https://schema.org/OutOfStock',
          itemCondition: 'https://schema.org/NewCondition'
        }
      });
    } else {
      upsertJsonLdScript('dynamic-seo-jsonld', {
        '@context': 'https://schema.org',
        '@type': 'OnlineStore',
        name: cleanStoreName,
        description: metaDescription,
        address: {
          '@type': 'PostalAddress',
          streetAddress: business.address,
          addressCountry: 'BD'
        }
      });
    }

    // 7. Facebook Domain Verification Meta Tag
    if (business.fbDomainVerification && business.fbDomainVerification.trim() !== '') {
      let code = business.fbDomainVerification.trim();
      const metaMatch = code.match(/content=["']([^"']+)["']/i);
      if (metaMatch && metaMatch[1]) {
        code = metaMatch[1].trim();
      }
      upsertMetaTag('name', 'facebook-domain-verification', code);
    }

    // 8. Custom Header Code / Scripts Injection (<head> custom scripts & meta tags)
    if (business.customHeaderScripts && business.customHeaderScripts.trim() !== '') {
      const containerId = 'sm-custom-header-container';
      let container = document.getElementById(containerId);
      if (!container) {
        container = document.createElement('div');
        container.id = containerId;
        container.style.display = 'none';
        document.head.appendChild(container);
      }
      // Re-inject if changed
      if (container.getAttribute('data-raw') !== business.customHeaderScripts) {
        container.setAttribute('data-raw', business.customHeaderScripts);
        container.innerHTML = business.customHeaderScripts;
        // Execute any script tags dynamically
        Array.from(container.querySelectorAll('script')).forEach(oldScript => {
          const newScript = document.createElement('script');
          Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
          newScript.textContent = oldScript.textContent;
          oldScript.parentNode?.replaceChild(newScript, oldScript);
        });
      }
    }
  }, [
    pageTitle,
    metaDescription,
    rawDescription,
    customGlobalKeywords,
    effectiveFavicon,
    canonicalUrl,
    resolvedOgImage,
    cleanStoreName,
    product,
    activePrice,
    regularPriceForCatalog,
    hasDiscount,
    availableStock,
    business.phone,
    business.address,
    business.fbDomainVerification,
    business.customHeaderScripts
  ]);

  return null;
};
