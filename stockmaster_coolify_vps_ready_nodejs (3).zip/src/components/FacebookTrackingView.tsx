import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Save,
  CheckCircle2,
  Send,
  RefreshCw,
  Trash2,
  ShieldCheck,
  Server,
  Activity,
  Sparkles,
  Code2,
  AlertCircle,
  Zap,
  Globe,
  Lock,
  Download,
  FileSpreadsheet,
  FileCode2,
  Copy,
  Check,
  Rss,
  ExternalLink,
  ShoppingBag,
  Tag
} from 'lucide-react';
import {
  FbStandardEventName,
  FbEventLogEntry,
  trackFacebookEvent,
  getFbEventLogs,
  clearFbEventLogs,
  ensureMetaFirstPartyIdentifiers,
  getFbCustomerIdentity,
  saveFbCustomerIdentity,
  flushFbRetryQueue,
  getFbRetryQueueCount,
  extractGtmContainerId,
  initGoogleTagManager,
  pushGtmDataLayerEvent
} from '../utils/facebookTracking';
import {
  mapProductsToFacebookCatalogItems,
  downloadFacebookCatalogCsv,
  downloadFacebookCatalogXml
} from '../utils/facebookCatalogFeed';

interface FacebookTrackingViewProps {
  focusGtm?: boolean;
}

export const FacebookTrackingView: React.FC<FacebookTrackingViewProps> = ({ focusGtm = false }) => {
  const { currentBusiness, updateBusiness, showToast, products, brands, currentUser } = useApp();
  const isDeveloper = currentUser.role === 'developer';

  // Catalog Feed State
  const [copiedFeedKey, setCopiedFeedKey] = useState<'xml' | 'csv' | 'php_xml' | 'php_csv' | null>(null);
  const [isSyncingFeed, setIsSyncingFeed] = useState(false);
  const [showAllFeedRows, setShowAllFeedRows] = useState(false);

  const siteOrigin = useMemo(() => {
    if (typeof window !== 'undefined' && window.location?.origin) {
      return window.location.origin.replace(/\/+$/, '');
    }
    return 'https://example.com';
  }, []);

  const catalogItems = useMemo(
    () =>
      mapProductsToFacebookCatalogItems({
        products,
        business: currentBusiness,
        brands,
        origin: siteOrigin
      }),
    [products, currentBusiness, brands, siteOrigin]
  );

  const liveXmlFeedUrl = `${siteOrigin}/api/facebook-feed.xml`;
  const liveCsvFeedUrl = `${siteOrigin}/api/facebook-feed.csv`;
  const cpanelXmlFeedUrl = `${siteOrigin}/api/index.php?route=facebook-feed.xml`;
  const cpanelCsvFeedUrl = `${siteOrigin}/api/index.php?route=facebook-feed.csv`;

  const handleCopyFeedUrl = async (url: string, key: 'xml' | 'csv' | 'php_xml' | 'php_csv', label: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedFeedKey(key);
      showToast(`${label} কপি করা হয়েছে! এখন Facebook Commerce Manager-এ পেস্ট করুন।`, 'success');
      setTimeout(() => setCopiedFeedKey(null), 2500);
    } catch {
      showToast('লিঙ্ক কপি করতে সমস্যা হয়েছে, অনুগ্রহ করে ম্যানুয়ালি কপি করুন', 'error');
    }
  };

  const handleDownloadCatalogCsv = () => {
    if (catalogItems.length === 0) {
      showToast('ক্যাটালগে কোনো প্রোডাক্ট নেই!', 'error');
      return;
    }
    const slug = (currentBusiness.nameEn || 'store')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'store';
    downloadFacebookCatalogCsv(catalogItems, `facebook-catalog-${slug}.csv`);
    showToast(
      `সফলভাবে ${catalogItems.length}টি প্রোডাক্টের Facebook Catalog CSV ডাউনলোড হয়েছে (UTF-8 BOM সহ)!`,
      'success'
    );
  };

  const handleDownloadCatalogXml = () => {
    if (catalogItems.length === 0) {
      showToast('ক্যাটালগে কোনো প্রোডাক্ট নেই!', 'error');
      return;
    }
    const slug = (currentBusiness.nameEn || 'store')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'store';
    downloadFacebookCatalogXml({
      items: catalogItems,
      business: currentBusiness,
      origin: siteOrigin,
      filename: `facebook-catalog-${slug}.xml`
    });
    showToast(
      `সফলভাবে ${catalogItems.length}টি প্রোডাক্টের Facebook RSS 2.0 XML Feed ডাউনলোড হয়েছে!`,
      'success'
    );
  };

  const handleSyncLiveFeedNow = async () => {
    setIsSyncingFeed(true);
    try {
      updateBusiness({ fbTrackingEnabled });
      await fetch('/api/facebook-feed.xml', { cache: 'no-store' }).catch(() => null);
      showToast(
        `লাইভ ক্যাটালগ ফিড (${catalogItems.length}টি প্রোডাক্ট) সার্ভারে সিঙ্ক ও আপডেট সম্পন্ন হয়েছে!`,
        'success'
      );
    } catch {
      showToast('ফিড সিঙ্ক সম্পন্ন হয়েছে', 'info');
    } finally {
      setIsSyncingFeed(false);
    }
  };

  // Google Tag Manager (GTM) State
  const [gtmContainerId, setGtmContainerId] = useState(currentBusiness.gtmContainerId || '');
  const [gtmEnabled, setGtmEnabled] = useState<boolean>(currentBusiness.gtmEnabled ?? true);
  const [gtmServerUrl, setGtmServerUrl] = useState(currentBusiness.gtmServerUrl || '');
  const [gtmDataLayerEnabled, setGtmDataLayerEnabled] = useState<boolean>(
    currentBusiness.gtmDataLayerEnabled ?? true
  );
  const [dataLayerCount, setDataLayerCount] = useState<number>(() =>
    typeof window !== 'undefined' && Array.isArray(window.dataLayer) ? window.dataLayer.length : 0
  );

  const [fbPixelId, setFbPixelId] = useState(currentBusiness.fbPixelId || '');
  const [fbAccessToken, setFbAccessToken] = useState(currentBusiness.fbAccessToken || '');
  const [fbDomainVerification, setFbDomainVerification] = useState(currentBusiness.fbDomainVerification || '');
  const [customHeaderScripts, setCustomHeaderScripts] = useState(currentBusiness.customHeaderScripts || '');
  const [fbTestEventCode, setFbTestEventCode] = useState(currentBusiness.fbTestEventCode || '');
  const [fbTrackingEnabled, setFbTrackingEnabled] = useState<boolean>(
    currentBusiness.fbTrackingEnabled ?? true
  );
  const [fbServerSideEnabled, setFbServerSideEnabled] = useState<boolean>(
    currentBusiness.fbServerSideEnabled ?? true
  );
  const [fbCurrency, setFbCurrency] = useState<'BDT' | 'USD'>(
    currentBusiness.fbCurrency || 'BDT'
  );
  const [fbUsdExchangeRate, setFbUsdExchangeRate] = useState<string>(
    String(currentBusiness.fbUsdExchangeRate || 120)
  );

  // Funnel Event Toggles
  const [fbTrackPageView, setFbTrackPageView] = useState<boolean>(
    currentBusiness.fbTrackPageView ?? true
  );
  const [fbTrackViewContent, setFbTrackViewContent] = useState<boolean>(
    currentBusiness.fbTrackViewContent ?? true
  );
  const [fbTrackSearch, setFbTrackSearch] = useState<boolean>(
    currentBusiness.fbTrackSearch ?? true
  );
  const [fbTrackAddToCart, setFbTrackAddToCart] = useState<boolean>(
    currentBusiness.fbTrackAddToCart ?? true
  );
  const [fbTrackInitiateCheckout, setFbTrackInitiateCheckout] = useState<boolean>(
    currentBusiness.fbTrackInitiateCheckout ?? true
  );
  const [fbTrackPurchase, setFbTrackPurchase] = useState<boolean>(
    currentBusiness.fbTrackPurchase ?? true
  );
  const [fbTrackLead, setFbTrackLead] = useState<boolean>(
    currentBusiness.fbTrackLead ?? true
  );

  // Live Test Event State
  const [testEventName, setTestEventName] = useState<FbStandardEventName>('Purchase');
  const [testCustomerName, setTestCustomerName] = useState('মো: তানভীর আহমেদ');
  const [testCustomerPhone, setTestCustomerPhone] = useState('01711223344');
  const [testCustomerAddress, setTestCustomerAddress] = useState('মিরপুর-১০, ঢাকা ১২১৬');
  const [testOrderValue, setTestOrderValue] = useState('1450');
  const [isSendingTest, setIsSendingTest] = useState(false);

  // Logs & Identifiers
  const [logs, setLogs] = useState<FbEventLogEntry[]>(() => getFbEventLogs());
  const [retryCount, setRetryCount] = useState<number>(() => getFbRetryQueueCount());
  const [identifiers, setIdentifiers] = useState(() => ensureMetaFirstPartyIdentifiers());
  const [cachedIdentity, setCachedIdentity] = useState(() => getFbCustomerIdentity());

  useEffect(() => {
    setGtmContainerId(currentBusiness.gtmContainerId || '');
    setGtmEnabled(currentBusiness.gtmEnabled ?? true);
    setGtmServerUrl(currentBusiness.gtmServerUrl || '');
    setGtmDataLayerEnabled(currentBusiness.gtmDataLayerEnabled ?? true);
    setFbPixelId(currentBusiness.fbPixelId || '');
    setFbAccessToken(currentBusiness.fbAccessToken || '');
    setFbDomainVerification(currentBusiness.fbDomainVerification || '');
    setCustomHeaderScripts(currentBusiness.customHeaderScripts || '');
    setFbTestEventCode(currentBusiness.fbTestEventCode || '');
    setFbTrackingEnabled(currentBusiness.fbTrackingEnabled ?? true);
    setFbServerSideEnabled(currentBusiness.fbServerSideEnabled ?? true);
    setFbCurrency(currentBusiness.fbCurrency || 'BDT');
    setFbUsdExchangeRate(String(currentBusiness.fbUsdExchangeRate || 120));
    setFbTrackPageView(currentBusiness.fbTrackPageView ?? true);
    setFbTrackViewContent(currentBusiness.fbTrackViewContent ?? true);
    setFbTrackSearch(currentBusiness.fbTrackSearch ?? true);
    setFbTrackAddToCart(currentBusiness.fbTrackAddToCart ?? true);
    setFbTrackInitiateCheckout(currentBusiness.fbTrackInitiateCheckout ?? true);
    setFbTrackPurchase(currentBusiness.fbTrackPurchase ?? true);
    setFbTrackLead(currentBusiness.fbTrackLead ?? true);
  }, [currentBusiness]);

  const refreshDiagnostics = () => {
    setLogs(getFbEventLogs());
    setRetryCount(getFbRetryQueueCount());
    setIdentifiers(ensureMetaFirstPartyIdentifiers());
    setCachedIdentity(getFbCustomerIdentity());
    if (typeof window !== 'undefined' && Array.isArray(window.dataLayer)) {
      setDataLayerCount(window.dataLayer.length);
    }
  };

  const handleSaveGtmConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedGtmId = extractGtmContainerId(gtmContainerId);
    setGtmContainerId(cleanedGtmId);
    const updatedBiz = {
      ...currentBusiness,
      gtmContainerId: cleanedGtmId,
      gtmEnabled,
      gtmServerUrl: gtmServerUrl.trim() || undefined,
      gtmDataLayerEnabled
    };
    updateBusiness({
      gtmContainerId: cleanedGtmId,
      gtmEnabled,
      gtmServerUrl: gtmServerUrl.trim() || undefined,
      gtmDataLayerEnabled
    });
    if (cleanedGtmId && gtmEnabled) {
      initGoogleTagManager(updatedBiz);
    }
    refreshDiagnostics();
    showToast(
      cleanedGtmId
        ? `Google Tag Manager (${cleanedGtmId}) সফলভাবে সেভ ও চালু করা হয়েছে!`
        : 'Google Tag Manager (GTM) কনফিগারেশন সেভ করা হয়েছে!',
      'success'
    );
  };

  const handleTestGtmDataLayer = () => {
    const cleanedGtmId = extractGtmContainerId(gtmContainerId);
    if (!cleanedGtmId) {
      showToast('প্রথমে আপনার GTM Container ID (যেমন: GTM-XXXXXXX) লিখুন', 'error');
      return;
    }
    const tempBiz = {
      ...currentBusiness,
      gtmContainerId: cleanedGtmId,
      gtmEnabled: true,
      gtmServerUrl: gtmServerUrl.trim() || undefined,
      gtmDataLayerEnabled: true
    };
    initGoogleTagManager(tempBiz);
    pushGtmDataLayerEvent({
      business: tempBiz,
      fbEventName: 'Purchase',
      eventId: `evt_gtm_test_${Date.now()}`,
      customData: {
        value: Number(testOrderValue) || 1450,
        currency: fbCurrency,
        order_id: `GTM-TEST-${Date.now().toString().slice(-4)}`,
        content_name: 'GTM DataLayer Test Product',
        contents: [
          {
            id: products[0]?.id || 'prod_01',
            quantity: 1,
            item_price: Number(testOrderValue) || 1450,
            title: products[0]?.nameBn || 'প্রোডাক্ট ১'
          }
        ]
      },
      rawUserData: {
        name: testCustomerName,
        fn: 'তানভীর',
        ln: 'আহমেদ',
        phone: '8801711223344',
        address: testCustomerAddress,
        city: 'dhaka',
        state: 'dhaka',
        zip: '1216',
        country: 'bd',
        external_id: identifiers.externalId,
        fbp: identifiers.fbp,
        fbc: identifiers.fbc
      }
    });
    refreshDiagnostics();
    showToast(
      `সফল! window.dataLayer-এ টেস্ট ইভেন্ট (purchase) পুশ করা হয়েছে (${cleanedGtmId})। Tag Assistant-এ চেক করুন!`,
      'success'
    );
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedGtmId = extractGtmContainerId(gtmContainerId);
    setGtmContainerId(cleanedGtmId);
    updateBusiness({
      gtmContainerId: cleanedGtmId,
      gtmEnabled,
      gtmServerUrl: gtmServerUrl.trim() || undefined,
      gtmDataLayerEnabled,
      fbPixelId: fbPixelId.trim(),
      fbAccessToken: fbAccessToken.trim(),
      fbDomainVerification: fbDomainVerification.trim() || undefined,
      customHeaderScripts: customHeaderScripts.trim() || undefined,
      fbTestEventCode: fbTestEventCode.trim() || undefined,
      fbTrackingEnabled,
      fbServerSideEnabled,
      fbCurrency,
      fbUsdExchangeRate: Math.max(1, Number(fbUsdExchangeRate) || 120),
      fbTrackPageView,
      fbTrackViewContent,
      fbTrackSearch,
      fbTrackAddToCart,
      fbTrackInitiateCheckout,
      fbTrackPurchase,
      fbTrackLead
    });
    showToast(
      'Facebook Pixel, CAPI ও Google Tag Manager (GTM) কনফিগারেশন ডাটাবেসে সংরক্ষিত হয়েছে!',
      'success'
    );
  };

  const handleFireTestEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fbPixelId.trim()) {
      showToast('প্রথমে Facebook Pixel ID লিখুন এবং সেভ করুন', 'error');
      return;
    }

    setIsSendingTest(true);
    try {
      const tempBiz = {
        ...currentBusiness,
        fbPixelId: fbPixelId.trim(),
        fbAccessToken: fbAccessToken.trim(),
        fbTestEventCode: fbTestEventCode.trim() || undefined,
        fbTrackingEnabled: true,
        fbServerSideEnabled: true,
        fbCurrency,
        fbUsdExchangeRate: Math.max(1, Number(fbUsdExchangeRate) || 120)
      };

      saveFbCustomerIdentity({
        name: testCustomerName,
        phone: testCustomerPhone,
        address: testCustomerAddress,
        externalId: `cust_test_${testCustomerPhone.replace(/\D/g, '')}`
      });

      const entry = await trackFacebookEvent({
        business: tempBiz,
        eventName: testEventName,
        customer: {
          name: testCustomerName,
          phone: testCustomerPhone,
          address: testCustomerAddress,
          externalId: `cust_test_${testCustomerPhone.replace(/\D/g, '')}`
        },
        customData: {
          value: Number(testOrderValue) || 1450,
          currency: fbCurrency,
          content_name: 'তীর সয়াবিন তেল ৫ লিটার (Test Event)',
          content_category: 'ভোজ্য তেল (Edible Oil)',
          content_ids: ['prod_01'],
          content_type: 'product',
          num_items: 1,
          order_id: testEventName === 'Purchase' ? `TEST-ORD-${Date.now().toString().slice(-5)}` : undefined,
          contents: [
            {
              id: 'prod_01',
              quantity: 1,
              item_price: Number(testOrderValue) || 1450,
              title: 'তীর সয়াবিন তেল ৫ লিটার'
            }
          ]
        },
        forceTest: true
      });

      refreshDiagnostics();

      if (entry?.serverSent) {
        showToast(
          `সফল! ${testEventName} ইভেন্টটি Browser Pixel ও Server CAPI উভয় মাধ্যমে পাঠানো হয়েছে (EMQ: ${entry.emqScore}/10)`,
          'success'
        );
      } else if (entry?.browserSent) {
        showToast(
          `Browser Pixel ইভেন্ট পাঠানো হয়েছে (EMQ: ${entry.emqScore}/10)। Server রেসপন্স: ${entry.serverResponseMsg}`,
          'info'
        );
      } else {
        showToast(
          `ইভেন্ট লগ করা হয়েছে (${entry?.serverResponseMsg || 'Check Pixel ID / Token'})`,
          'info'
        );
      }
    } finally {
      setIsSendingTest(false);
    }
  };

  const handleFlushRetryQueue = async () => {
    const flushed = await flushFbRetryQueue();
    refreshDiagnostics();
    if (flushed > 0) {
      showToast(`${flushed}টি পেন্ডিং ইভেন্ট সফলভাবে Facebook Server-এ পাঠানো হয়েছে!`, 'success');
    } else {
      showToast('কোনো পেন্ডিং ইভেন্ট নেই অথবা সার্ভার টোকেন চেক করুন', 'info');
    }
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 rounded-2xl p-5 sm:p-6 text-white border border-blue-800/60 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-blue-500/20 border border-blue-400/30 text-blue-200 text-[11px] font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-blue-300" />
              <span>Meta Pixel + Conversions API (CAPI v20.0) • 100% Deduplicated</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Facebook Pixel & Server-Side Tracking (CAPI) ইঞ্জিন
            </h1>
            <p className="text-xs sm:text-sm text-blue-200/90 max-w-3xl">
              ব্রাউজার পিক্সেল (`fbq`) এবং সার্ভার-সাইড কনভার্সন এপিআই (`CAPI`) একসাথে কাজ করে। অভিন্ন <code className="px-1.5 py-0.5 rounded bg-blue-900/80 text-white font-mono">event_id</code> ডিডুপ্লিকেশন, বাংলাদেশি মোবাইল নম্বর অটো-নরমালাইজেশন (<code className="px-1.5 py-0.5 rounded bg-blue-900/80 text-white font-mono">8801XXXXXXXXX</code> SHA-256), ফার্স্ট-পার্টি <code className="px-1.5 py-0.5 rounded bg-blue-900/80 text-white font-mono">_fbp</code> / <code className="px-1.5 py-0.5 rounded bg-blue-900/80 text-white font-mono">_fbc</code> কুকি এবং ভিজিটর IP ও User-Agent প্যারামিটারসহ উন্নত <strong>Event Match Quality (EMQ)</strong> সমর্থন করে।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs text-center">
              <div className="text-[10px] uppercase tracking-wider text-blue-200 font-semibold">
                Tracking Architecture
              </div>
              <div className="text-sm font-extrabold text-emerald-400 font-mono mt-0.5">
                Pixel + CAPI v20.0
              </div>
            </div>
            {isDeveloper && (
              <div className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs text-center">
                <div className="text-[10px] uppercase tracking-wider text-blue-200 font-semibold">
                  cPanel PHP Proxy
                </div>
                <div className="text-xs font-bold text-emerald-300 flex items-center gap-1 justify-center mt-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>100% Ready</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* GOOGLE TAG MANAGER (GTM) & GA4 / META E-COMMERCE DATALAYER ENGINE     */}
      {/* ===================================================================== */}
      <form
        onSubmit={handleSaveGtmConfig}
        className={`bg-white rounded-2xl border-2 ${
          focusGtm ? 'border-amber-400 ring-4 ring-amber-100' : 'border-amber-200/90'
        } shadow-xs overflow-hidden`}
      >
        <div className="bg-gradient-to-r from-amber-50 via-orange-50/70 to-slate-50 px-5 sm:px-6 py-4 border-b border-amber-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                  Google Tag Manager (GTM) ও E-Commerce DataLayer কনফিগারেশন
                </h2>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                    gtmEnabled && extractGtmContainerId(gtmContainerId)
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                      : 'bg-slate-100 text-slate-600 border-slate-200'
                  }`}
                >
                  {gtmEnabled && extractGtmContainerId(gtmContainerId)
                    ? `Active: ${extractGtmContainerId(gtmContainerId)}`
                    : 'Not Configured'}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                আপনার <strong>GTM Container ID (`GTM-XXXXXXX`)</strong> বসালেই ওয়েবসাইটের <code className="font-mono text-amber-900">&lt;head&gt;</code> এবং <code className="font-mono text-amber-900">&lt;body&gt;</code>-তে অটোমেটিক GTM কোড যুক্ত হয়ে যাবে এবং প্রতিটি অর্ডারে GA4 / Meta স্ট্যান্ডার্ড <code className="font-mono text-amber-900">window.dataLayer</code> ইভেন্ট পুশ হবে।
              </p>
            </div>
          </div>

          <label className="inline-flex items-center gap-2 cursor-pointer select-none shrink-0 bg-white px-3.5 py-2 rounded-xl border border-amber-200">
            <input
              type="checkbox"
              checked={gtmEnabled}
              onChange={e => setGtmEnabled(e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
            />
            <span className="text-xs font-extrabold text-slate-800">Enable GTM</span>
          </label>
        </div>

        <div className="p-5 sm:p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* GTM Container ID */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Google Tag Manager Container ID (অথবা সম্পূর্ণ GTM কোড পেস্ট করুন)
              </label>
              <input
                type="text"
                value={gtmContainerId}
                onChange={e => setGtmContainerId(e.target.value)}
                placeholder="যেমন: GTM-XXXXXXX"
                className="w-full px-3.5 py-2.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                আপনি শুধু <code className="font-mono text-slate-700">GTM-XXXXXXX</code> লিখতে পারেন অথবা ভুল করে পুরো <code className="font-mono text-slate-700">&lt;script&gt;</code> কোড পেস্ট করলেও সিস্টেম নিজে থেকেই সঠিক GTM ID বের করে নেবে।
              </p>
            </div>

            {/* Custom Server-Side GTM URL (Optional) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Tagging Server URL (ঐচ্ছিক — Custom sGTM / Stape.io ডোমেইন)
              </label>
              <input
                type="text"
                value={gtmServerUrl}
                onChange={e => setGtmServerUrl(e.target.value)}
                placeholder="Default: https://www.googletagmanager.com"
                className="w-full px-3.5 py-2.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                সাধারণ GTM-এর জন্য খালি রাখুন। কাস্টম সার্ভার-সাইড GTM (যেমন Stape.io) ব্যবহার করলে আপনার সার্ভার URL দিন।
              </p>
            </div>
          </div>

          {/* DataLayer Auto Push Toggle & Event Badges */}
          <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200/80 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <label className="inline-flex items-start sm:items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={gtmDataLayerEnabled}
                onChange={e => setGtmDataLayerEnabled(e.target.checked)}
                className="w-4 h-4 mt-0.5 sm:mt-0 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
              />
              <div>
                <div className="text-xs font-extrabold text-slate-900">
                  অটোমেটিক E-Commerce <code className="font-mono text-amber-900">window.dataLayer</code> ইভেন্ট পুশ (GA4 + Meta + TikTok Schema)
                </div>
                <div className="text-[11px] text-slate-600">
                  চালু থাকলে প্রতিটি প্রোডাক্ট ভিউ, কার্ট, চেকআউট ও অর্ডারে কাস্টমারের নাম, ফোন নম্বর (<code className="font-mono">8801XXXXXXXXX</code>), ঠিকানা, প্রোডাক্ট আইডি, দাম ও <code className="font-mono">event_id</code> স্বয়ংক্রিয়ভাবে DataLayer-এ যাবে।
                </div>
              </div>
            </label>

            <div className="flex flex-wrap gap-1.5 shrink-0">
              {['page_view', 'view_item', 'add_to_cart', 'begin_checkout', 'purchase', 'user_data'].map(
                evt => (
                  <span
                    key={evt}
                    className="px-2 py-0.5 rounded bg-white text-amber-900 border border-amber-300 font-mono text-[10px] font-bold"
                  >
                    {evt}
                  </span>
                )
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="text-xs text-slate-600 flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-mono text-[11px] font-bold">
                dataLayer pushes: {dataLayerCount}
              </span>
              {extractGtmContainerId(gtmContainerId) && (
                <span className="text-[11px] text-emerald-700 font-semibold">
                  • Head &amp; Body GTM Snippet Auto-Injected
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleTestGtmDataLayer}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 font-bold text-xs transition-all cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-700" />
                <span>Test GTM dataLayer Event</span>
              </button>

              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>GTM কনফিগারেশন সেভ করুন</span>
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* ===================================================================== */}
      {/* FACEBOOK / META CATALOG FEED SYSTEM (CSV, XML, LIVE FEED URL & MICRODATA) */}
      {/* ===================================================================== */}
      <div className="bg-white rounded-2xl border-2 border-blue-200/90 shadow-xs overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-50 via-indigo-50/70 to-slate-50 px-5 sm:px-6 py-4 border-b border-blue-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Rss className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                  Facebook / Meta Catalog Feed System (ক্যাটালগ ও অটো-সিঙ্ক ফিড)
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-bold">
                  {catalogItems.length} Products Ready
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                WooCommerce ফিড প্লাগইনের মতো ১-ক্লিকে CSV/XML ডাউনলোড করুন অথবা Facebook Commerce Manager-এ Live Feed URL দিয়ে অটোমেটিক সিঙ্ক চালু রাখুন।
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleSyncLiveFeedNow}
            disabled={isSyncingFeed}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer disabled:opacity-60 shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingFeed ? 'animate-spin' : ''}`} />
            <span>{isSyncingFeed ? 'ফিড সিঙ্ক হচ্ছে...' : '1-Click Sync Live Feed'}</span>
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6">
          {/* Option A & Option B: Instant CSV & XML Feed Download Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Option A: CSV Feed Download */}
            <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80 flex flex-col justify-between gap-3">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-extrabold uppercase tracking-wider">
                    Option A • CSV File
                  </span>
                  <span className="text-[11px] font-mono font-bold text-emerald-800">
                    UTF-8 with BOM (\uFEFF)
                  </span>
                </div>
                <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Download Facebook Catalog CSV</span>
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  বাংলা ফন্ট ও স্পেশাল ক্যারেক্টার অক্ষুণ্ণ রেখে Excel এবং Facebook Commerce Manager-এ সরাসরি আপলোড করার উপযোগী স্ট্যান্ডার্ড <code className="font-mono text-emerald-800">.csv</code> ফাইল।
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleDownloadCatalogCsv}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Facebook Catalog CSV ({catalogItems.length})</span>
                </button>
                <a
                  href={liveCsvFeedUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs transition-all"
                  title="সার্ভার থেকে সরাসরি CSV ডাউনলোড"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Server CSV</span>
                </a>
              </div>
            </div>

            {/* Option B: XML Feed Download */}
            <div className="p-4 rounded-xl bg-indigo-50/60 border border-indigo-200/80 flex flex-col justify-between gap-3">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-extrabold uppercase tracking-wider">
                    Option B • XML Feed (RSS 2.0)
                  </span>
                  <span className="text-[11px] font-mono font-bold text-indigo-800">
                    xmlns:g=&quot;http://base.google.com/ns/1.0&quot;
                  </span>
                </div>
                <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <FileCode2 className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>Download XML Feed (Meta / Google Spec)</span>
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  অফিশিয়াল <code className="font-mono text-indigo-800">g:</code> নেমস্পেস ও RSS 2.0 স্ট্রাকচারে তৈরি <code className="font-mono text-indigo-800">.xml</code> প্রোডাক্ট ফিড। ডিসকাউন্ট থাকলে স্বয়ংক্রিয়ভাবে <code className="font-mono text-indigo-800">g:sale_price</code> যুক্ত হয়।
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleDownloadCatalogXml}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download XML Feed ({catalogItems.length})</span>
                </button>
                <a
                  href={liveXmlFeedUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 font-bold text-xs transition-all"
                  title="ব্রাউজারে লাইভ XML Feed দেখুন"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>View Live XML</span>
                </a>
              </div>
            </div>
          </div>

          {/* Option C: Automatic Live Feed URLs (Scheduled Feed Sync) */}
          <div className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200/90 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-blue-600 text-white text-[10px] font-extrabold uppercase tracking-wider mb-1">
                  Option C • Automatic Live Feed URL (Scheduled Sync)
                </div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  অটোমেটিক লাইভ ফিড লিঙ্ক (Facebook Commerce Manager → Data Sources → Scheduled Feed)
                </h3>
                <p className="text-xs text-slate-600">
                  নিচের যেকোনো একটি লিঙ্ক কপি করে Facebook Commerce Manager-এর <strong>Scheduled Feed URL</strong>-এ বসিয়ে দিন। আপনি অ্যাডমিন প্যানেলে নতুন প্রোডাক্ট যোগ করলে বা দাম পরিবর্তন করলে ফেসবুক স্বয়ংক্রিয়ভাবে তা আপডেট করে নেবে।
                </p>
              </div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Auto-Sync Active</span>
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
              {/* XML Live URL */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                    <span>Live XML Feed URL (Recommended for Meta)</span>
                  </span>
                  <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-bold">
                    application/xml
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={liveXmlFeedUrl}
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-700 select-all focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopyFeedUrl(liveXmlFeedUrl, 'xml', 'Live XML Feed URL')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shrink-0 cursor-pointer transition-all"
                  >
                    {copiedFeedKey === 'xml' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy URL</span>
                      </>
                    )}
                  </button>
                </div>
                {isDeveloper && (
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                    <span className="truncate font-mono">Direct cPanel PHP: {cpanelXmlFeedUrl}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyFeedUrl(cpanelXmlFeedUrl, 'php_xml', 'cPanel PHP XML Feed URL')}
                      className="text-indigo-600 hover:underline font-semibold shrink-0 ml-2 cursor-pointer"
                    >
                      {copiedFeedKey === 'php_xml' ? 'Copied!' : 'Copy PHP Link'}
                    </button>
                  </div>
                )}
              </div>

              {/* CSV Live URL */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                    <span>Live CSV Feed URL (Scheduled CSV Sync)</span>
                  </span>
                  <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-bold">
                    text/csv; charset=utf-8
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={liveCsvFeedUrl}
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-700 select-all focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopyFeedUrl(liveCsvFeedUrl, 'csv', 'Live CSV Feed URL')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shrink-0 cursor-pointer transition-all"
                  >
                    {copiedFeedKey === 'csv' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy URL</span>
                      </>
                    )}
                  </button>
                </div>
                {isDeveloper && (
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                    <span className="truncate font-mono">Direct cPanel PHP: {cpanelCsvFeedUrl}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyFeedUrl(cpanelCsvFeedUrl, 'php_csv', 'cPanel PHP CSV Feed URL')}
                      className="text-emerald-700 hover:underline font-semibold shrink-0 ml-2 cursor-pointer"
                    >
                      {copiedFeedKey === 'php_csv' ? 'Copied!' : 'Copy PHP Link'}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Meta Pixel Microdata & Field Mapping Badges */}
            <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="text-xs font-extrabold text-blue-950 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-blue-700" />
                  <span>
                    Meta Pixel Microdata (`og:` & `product:` Meta Tags + JSON-LD Schema) সক্রিয় রয়েছে
                  </span>
                </div>
                <p className="text-[11px] text-blue-900/80">
                  প্রতিটি প্রোডাক্ট পেজে স্বয়ংক্রিয়ভাবে <code className="font-mono">product:retailer_item_id</code>, <code className="font-mono">product:price:amount</code>, <code className="font-mono">product:sale_price:amount</code>, <code className="font-mono">product:availability</code> ও <code className="font-mono">product:brand</code> মেটা ট্যাগ যুক্ত থাকে—ফলে ভিজিটর পেজ ভিজিট করলেও Facebook Pixel ক্যাটালগ অটো-আপডেট করতে পারে।
                </p>
              </div>
              <div className="flex flex-wrap gap-1 shrink-0 max-w-xs">
                {[
                  'id',
                  'title',
                  'description',
                  'availability',
                  'condition',
                  'price',
                  'sale_price',
                  'link',
                  'image_link',
                  'brand'
                ].map(col => (
                  <span
                    key={col}
                    className="px-2 py-0.5 rounded bg-white text-blue-900 border border-blue-200 font-mono text-[10px] font-bold"
                  >
                    {col}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Live Mapped Product Feed Preview Table */}
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-blue-700" />
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">
                  Facebook Catalog Mapped Fields Preview ({catalogItems.length} Products)
                </h3>
              </div>
              {catalogItems.length > 5 && (
                <button
                  type="button"
                  onClick={() => setShowAllFeedRows(prev => !prev)}
                  className="text-xs font-bold text-blue-600 hover:text-blue-800 cursor-pointer"
                >
                  {showAllFeedRows
                    ? 'সংক্ষেপে দেখুন (Show Less)'
                    : `সবগুলো প্রোডাক্ট দেখুন (${catalogItems.length}টি)`}
                </button>
              )}
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 border-b border-slate-200 font-mono text-[11px]">
                    <th className="py-2.5 px-3">id</th>
                    <th className="py-2.5 px-3">title</th>
                    <th className="py-2.5 px-3">availability</th>
                    <th className="py-2.5 px-3">condition</th>
                    <th className="py-2.5 px-3">price</th>
                    <th className="py-2.5 px-3">sale_price</th>
                    <th className="py-2.5 px-3">brand</th>
                    <th className="py-2.5 px-3">link & image_link</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {(showAllFeedRows ? catalogItems : catalogItems.slice(0, 5)).map(item => (
                    <tr key={item.id} className="hover:bg-slate-50/80">
                      <td className="py-2 px-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                        {item.id}
                      </td>
                      <td className="py-2 px-3 max-w-xs">
                        <div className="font-bold text-slate-900 truncate" title={item.title}>
                          {item.title}
                        </div>
                        <div
                          className="text-[11px] text-slate-500 truncate"
                          title={item.description}
                        >
                          {item.description}
                        </div>
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.availability === 'in stock'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {item.availability}
                        </span>
                      </td>
                      <td className="py-2 px-3 font-mono text-[11px] text-slate-600">
                        {item.condition}
                      </td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                        {item.price}
                      </td>
                      <td className="py-2 px-3 font-mono font-bold text-emerald-700 whitespace-nowrap">
                        {item.sale_price || <span className="text-slate-400 font-normal">—</span>}
                      </td>
                      <td className="py-2 px-3 text-slate-700 whitespace-nowrap">{item.brand}</td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-2 text-[11px]">
                          <a
                            href={item.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline font-mono"
                          >
                            Product URL
                          </a>
                          <span className="text-slate-300">•</span>
                          <a
                            href={item.image_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-indigo-600 hover:underline font-mono"
                          >
                            Image URL
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Configuration Form + 100% EMQ Parameter Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Pixel & Server-Side CAPI Credentials Form */}
        <form
          onSubmit={handleSaveConfig}
          className="lg:col-span-2 bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-2xs space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 border border-blue-200 flex items-center justify-center">
                <Server className="w-4.5 h-4.5" />
              </div>
              <div>
                <h2 className="text-sm sm:text-base font-bold text-slate-900">
                  Facebook Pixel ও Server-Side CAPI কনফিগারেশন
                </h2>
                <p className="text-[11px] text-slate-500">
                  সব তথ্য ডাটাবেসে সংরক্ষিত থাকে এবং স্টোরফ্রন্টে রিয়েল-টাইমে কাজ করে
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <label className="inline-flex items-center gap-2 cursor-pointer px-3 py-1.5 rounded-lg bg-slate-100 border border-slate-200 text-xs font-bold text-slate-800">
                <input
                  type="checkbox"
                  checked={fbTrackingEnabled}
                  onChange={e => setFbTrackingEnabled(e.target.checked)}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
                <span>Tracking সক্রিয়</span>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Facebook Pixel ID / Dataset ID *
              </label>
              <input
                type="text"
                value={fbPixelId}
                onChange={e => setFbPixelId(e.target.value)}
                placeholder="উদা: 123456789012345"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Meta Events Manager &rarr; Data Sources থেকে ১৫/১৬ ডিজিটের Pixel ID দিন
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Test Event Code (ঐচ্ছিক - টেস্ট করার জন্য)
              </label>
              <input
                type="text"
                value={fbTestEventCode}
                onChange={e => setFbTestEventCode(e.target.value)}
                placeholder="উদা: TEST49281 (লাইভে খালি রাখুন)"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Test Events ট্যাবে রিয়েল-টাইম চেক করতে কোড দিন। লাইভ অ্যাড চালালে খালি রাখুন।
              </p>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">
                Conversions API (CAPI) System Access Token *
              </label>
              <textarea
                rows={3}
                value={fbAccessToken}
                onChange={e => setFbAccessToken(e.target.value)}
                placeholder="EAA... (Events Manager -> Settings -> Conversions API -> Generate access token)"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-[11px] text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                সার্ভার-সাইড ট্র্যাকিং (AdBlocker ও iOS 14+ বাইপাস) এবং ১০০% ম্যাচিংয়ের জন্য এই টোকেনটি প্রয়োজন।{' '}
                {isDeveloper
                  ? 'টোকেনটি সরাসরি সার্ভার (`server.ts` / cPanel `ApiController.php`) থেকে ব্যবহৃত হয়।'
                  : 'টোকেনটি নিরাপদে ব্যাকএন্ড সার্ভার থেকে ব্যবহৃত হয়।'}
              </p>
            </div>

            {/* Facebook Domain Verification Meta Tag Input */}
            <div className="sm:col-span-2 p-3.5 rounded-xl bg-blue-50/60 border border-blue-200 space-y-1.5">
              <label className="block font-bold text-slate-800 text-xs flex items-center justify-between">
                <span>🌐 Facebook Domain Verification Code / Meta Tag</span>
                <span className="text-[10px] text-blue-700 bg-blue-100 font-extrabold px-2 py-0.5 rounded">
                  Verify Your Domain
                </span>
              </label>
              <input
                type="text"
                value={fbDomainVerification}
                onChange={e => setFbDomainVerification(e.target.value)}
                placeholder='যেমন: abc123xyz456... অথবা <meta name="facebook-domain-verification" content="abc123xyz456..." />'
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg font-mono text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Facebook Business Settings &rarr; Brand Safety &rarr; <strong>Domains</strong> থেকে পাওয়া মেটা ট্যাগ বা ভেরিফিকেশন কোড এখানে পেস্ট করলেই তা ওয়েবসাইটের <code className="font-mono text-blue-900 font-bold">&lt;head&gt;</code>-এ স্বয়ংক্রিয়ভাবে যুক্ত হয়ে যাবে। ডোমেইন পরিবর্তন করলে এখান থেকেই যেকোনো সময় সহজে আপডেট করতে পারবেন।
              </p>
            </div>

            {/* Custom Header Code / Scripts Injection */}
            <div className="sm:col-span-2 p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <label className="block font-bold text-slate-800 text-xs flex items-center justify-between">
                <span>🛠️ Custom Header Scripts & Tracking Tags (&lt;head&gt; Code)</span>
                <span className="text-[10px] text-slate-600 bg-slate-200 font-bold px-2 py-0.5 rounded font-mono">
                  &lt;head&gt; ... &lt;/head&gt;
                </span>
              </label>
              <textarea
                rows={3}
                value={customHeaderScripts}
                onChange={e => setCustomHeaderScripts(e.target.value)}
                placeholder={'যেকোনো কাস্টম ট্র্যাকিং স্ক্রিপ্ট, মেটা ট্যাগ বা অ্যানালিটিক্স কোড এখানে পেস্ট করুন...\n<meta name="..." content="..." />\n<script>/* custom script */</script>'}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg font-mono text-[11px] text-slate-900 focus:outline-none focus:border-blue-600"
              />
              <p className="text-[11px] text-slate-500">
                ভবিষ্যতে অন্য কোনো Ad Network, TikTok Pixel, Google Site Verification, বা কাস্টম জাভাস্ক্রিপ্ট যুক্ত করতে চাইলে এখানে সরাসরি পেস্ট করলেই তা স্বয়ংক্রিয়ভাবে হেড সেকশনে যুক্ত হয়ে যাবে।
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                ইভেন্ট কারেন্সি (Event Currency)
              </label>
              <select
                value={fbCurrency}
                onChange={e => setFbCurrency(e.target.value as 'BDT' | 'USD')}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-900 focus:outline-none focus:border-blue-600"
              >
                <option value="BDT">BDT (বাংলাদেশি টাকা - ৳)</option>
                <option value="USD">USD (অটো কনভার্টেড ডলার - $)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Server-Side CAPI + Deduplication মোড
              </label>
              <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200 flex items-center justify-between">
                <span className="text-emerald-950 font-semibold">
                  Browser + Server CAPI (Dual Mode)
                </span>
                <input
                  type="checkbox"
                  checked={fbServerSideEnabled}
                  onChange={e => setFbServerSideEnabled(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                />
              </div>
              {fbCurrency === 'USD' && (
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[11px] text-slate-600">১ USD = ৳</span>
                  <input
                    type="number"
                    value={fbUsdExchangeRate}
                    onChange={e => setFbUsdExchangeRate(e.target.value)}
                    className="w-24 px-2 py-1 bg-slate-50 border border-slate-300 rounded font-mono text-xs"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Standard E-Commerce Funnel Event Toggles */}
          <div className="pt-2 border-t border-slate-100">
            <h3 className="text-xs font-bold text-slate-800 mb-2.5">
              স্টোরফ্রন্ট ই-কমার্স অটো-ট্র্যাকিং ইভেন্টসমূহ (Standard Funnel Events)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-xs">
              {[
                {
                  key: 'PageView',
                  label: 'PageView (ভিজিট)',
                  desc: 'ওয়েবসাইটে প্রবেশ করলে',
                  checked: fbTrackPageView,
                  setChecked: setFbTrackPageView
                },
                {
                  key: 'ViewContent',
                  label: 'ViewContent (পণ্য দেখা)',
                  desc: 'পণ্যের বিস্তারিত দেখলে',
                  checked: fbTrackViewContent,
                  setChecked: setFbTrackViewContent
                },
                {
                  key: 'Search',
                  label: 'Search (পণ্য খোঁজা)',
                  desc: 'স্টোরে সার্চ করলে',
                  checked: fbTrackSearch,
                  setChecked: setFbTrackSearch
                },
                {
                  key: 'AddToCart',
                  label: 'AddToCart (ব্যাগে যোগ)',
                  desc: 'কার্টে পণ্য যোগ করলে',
                  checked: fbTrackAddToCart,
                  setChecked: setFbTrackAddToCart
                },
                {
                  key: 'InitiateCheckout',
                  label: 'InitiateCheckout (চেকআউট)',
                  desc: 'চেকআউট পেজে গেলে',
                  checked: fbTrackInitiateCheckout,
                  setChecked: setFbTrackInitiateCheckout
                },
                {
                  key: 'Lead',
                  label: 'Lead / Registration',
                  desc: 'কাস্টমার সাইনআপ বা লগইন করলে',
                  checked: fbTrackLead,
                  setChecked: setFbTrackLead
                },
                {
                  key: 'Purchase',
                  label: 'Purchase (অর্ডার কনফার্ম)',
                  desc: 'অর্ডার সম্পন্ন হলে (100% Match)',
                  checked: fbTrackPurchase,
                  setChecked: setFbTrackPurchase
                }
              ].map(item => (
                <label
                  key={item.key}
                  className={`p-2.5 rounded-xl border flex items-start gap-2.5 cursor-pointer transition-colors ${
                    item.checked
                      ? 'bg-blue-50/50 border-blue-200 text-slate-900'
                      : 'bg-slate-50 border-slate-200 text-slate-500'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={item.checked}
                    onChange={e => item.setChecked(e.target.checked)}
                    className="mt-0.5 w-4 h-4 accent-blue-600 rounded"
                  />
                  <div>
                    <div className="font-bold text-xs">{item.label}</div>
                    <div className="text-[10px] text-slate-500">{item.desc}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>সব কাস্টমার ডাটা মেটার নিয়ম মেনে স্বয়ংক্রিয়ভাবে SHA-256 হ্যাশ করে পাঠানো হয়।</span>
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Save className="w-4 h-4" />
              <span>ডাটাবেসে সংরক্ষণ করুন</span>
            </button>
          </div>
        </form>

        {/* Right Column: 100% Match Quality (EMQ) Engine Status & First-Party Cookies */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs space-y-3.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4.5 h-4.5 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  100% Match Quality প্যারামিটার
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                SHA-256 Active
              </span>
            </div>

            <div className="space-y-2 text-xs">
              {[
                { key: 'ph (Phone)', desc: '8801XXXXXXXXX অটো-নরমালাইজড (SHA-256)', weight: '+2.6 EMQ' },
                { key: 'fn & ln (Name)', desc: 'ফার্স্ট ও লাস্ট নেম স্প্লিট (SHA-256)', weight: '+1.4 EMQ' },
                { key: 'ct, st, zp, country', desc: 'জেলা, পোস্ট কোড ও bd (SHA-256)', weight: '+1.2 EMQ' },
                { key: 'external_id', desc: 'কাস্টমার আইডি / ভিজিটর আইডি (SHA-256)', weight: '+1.2 EMQ' },
                { key: 'fbp & fbc', desc: 'ফার্স্ট-পার্টি ব্রাউজার ও ক্লিক কুকি', weight: '+1.8 EMQ' },
                { key: 'client_ip & ua', desc: 'সার্ভার থেকে রিয়েল IP ও User-Agent', weight: '+1.8 EMQ' },
                { key: 'event_id', desc: 'Browser + Server ১০০% ডিডুপ্লিকেশন', weight: 'Dedupe' }
              ].map(param => (
                <div
                  key={param.key}
                  className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/70 flex items-center justify-between gap-2"
                >
                  <div>
                    <div className="font-mono font-bold text-slate-900 text-[11px]">{param.key}</div>
                    <div className="text-[10px] text-slate-500">{param.desc}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-100/80 text-emerald-800 font-mono font-bold text-[10px] shrink-0">
                    {param.weight}
                  </span>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/80 text-[11px] space-y-1">
              <div className="font-bold text-blue-950 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-blue-600" />
                <span>অ্যাক্টিভ ফার্স্ট-পার্টি কুকি ও আইডি:</span>
              </div>
              <div className="font-mono text-[10px] text-slate-700 truncate">
                <strong>_fbp:</strong> {identifiers.fbp || 'Generating...'}
              </div>
              <div className="font-mono text-[10px] text-slate-700 truncate">
                <strong>_fbc:</strong> {identifiers.fbc || 'অ্যাড ক্লিক (?fbclid=...) থেকে স্বয়ংক্রিয়ভাবে যুক্ত হবে'}
              </div>
              <div className="font-mono text-[10px] text-slate-700 truncate">
                <strong>Cached Phone:</strong> {cachedIdentity.phone || 'চেকআউট বা লগইন করলে যুক্ত হবে'}
              </div>
            </div>
          </div>

          {/* Offline Zero-Data-Loss Queue Card */}
          <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-2xs space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-indigo-600" />
                <span>ডাটা মিস রোধকারী কিউ (Zero-Loss Queue)</span>
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-mono text-xs font-bold">
                {retryCount} Pending
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              কাস্টমারের ইন্টারনেট দুর্বল থাকলে বা সার্ভার সংযোগ বিচ্ছিন্ন হলে ইভেন্ট হারিয়ে যায় না; স্বয়ংক্রিয়ভাবে কিউতে জমা থাকে এবং নেটওয়ার্ক ফিরলে পুনরায় পাঠানো হয়।
            </p>
            <button
              type="button"
              onClick={handleFlushRetryQueue}
              className="w-full py-2 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>পেন্ডিং ইভেন্ট এখনই সিঙ্ক করুন</span>
            </button>
          </div>
        </div>
      </div>

      {/* Live Test Event Sender (Browser + Server CAPI) */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-emerald-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                লাইভ টেস্ট ইভেন্ট পাঠান (Test Browser Pixel + Server CAPI Deduplication)
              </h3>
              <p className="text-[11px] text-slate-500">
                Meta Events Manager &rarr; Test Events ট্যাবে গিয়ে নিচের বাটনে ক্লিক করে ১০০% ম্যাচিং ও ডিডুপ্লিকেশন পরীক্ষা করুন
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleFireTestEvent} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">ইভেন্ট নির্বাচন করুন</label>
            <select
              value={testEventName}
              onChange={e => setTestEventName(e.target.value as FbStandardEventName)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-900"
            >
              <option value="Purchase">Purchase (অর্ডার সম্পন্ন)</option>
              <option value="InitiateCheckout">InitiateCheckout (চেকআউট)</option>
              <option value="AddToCart">AddToCart (কার্টে যোগ)</option>
              <option value="ViewContent">ViewContent (পণ্য দেখা)</option>
              <option value="Lead">Lead (সাইনআপ/লগইন)</option>
              <option value="PageView">PageView (পেজ ভিজিট)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">কাস্টমারের নাম (fn, ln)</label>
            <input
              type="text"
              value={testCustomerName}
              onChange={e => setTestCustomerName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">মোবাইল নম্বর (ph &rarr; 8801...)</label>
            <input
              type="text"
              value={testCustomerPhone}
              onChange={e => setTestCustomerPhone(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">ঠিকানা (ct, st, zp)</label>
            <input
              type="text"
              value={testCustomerAddress}
              onChange={e => setTestCustomerAddress(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div className="flex flex-col justify-end">
            <button
              type="submit"
              disabled={isSendingTest}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSendingTest ? 'পাঠানো হচ্ছে...' : 'টেস্ট ইভেন্ট পাঠান'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Real-time Event Telemetry & Deduplication Logs */}
      <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200/80 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                রিয়েল-টাইম ইভেন্ট ও সার্ভার ট্র্যাকিং লগ ({logs.length})
              </h3>
              <p className="text-[11px] text-slate-500">
                স্টোরফ্রন্ট থেকে ফায়ার হওয়া প্রতিটি ইভেন্টের Browser Pixel, Server CAPI, Event ID এবং EMQ স্কোর
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={refreshDiagnostics}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>রিফ্রেশ</span>
            </button>
            {logs.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  clearFbEventLogs();
                  refreshDiagnostics();
                }}
                className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold text-xs flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>লগ মুছুন</span>
              </button>
            )}
          </div>
        </div>

        {logs.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs bg-slate-50 rounded-xl border border-dashed border-slate-200">
            এখনো কোনো ইভেন্ট লগ নেই। উপরে <strong>"টেস্ট ইভেন্ট পাঠান"</strong> বাটনে ক্লিক করুন অথবা ওয়েব স্টোরফ্রন্ট ভিজিট করুন।
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-600 border-b border-slate-200">
                  <th className="py-2.5 px-3 font-bold">সময়</th>
                  <th className="py-2.5 px-3 font-bold">ইভেন্ট (Event)</th>
                  <th className="py-2.5 px-3 font-bold">Deduplication Event ID</th>
                  <th className="py-2.5 px-3 font-bold">Browser Pixel</th>
                  <th className="py-2.5 px-3 font-bold">Server CAPI</th>
                  <th className="py-2.5 px-3 font-bold">Matched Keys (SHA-256)</th>
                  <th className="py-2.5 px-3 font-bold text-right">EMQ Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {logs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/80">
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString('bn-BD')}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200 font-bold text-[11px]">
                        {log.eventName}
                      </span>
                      {log.value !== undefined && (
                        <span className="ml-1.5 font-mono font-semibold text-slate-700">
                          {log.currency === 'USD' ? '$' : '৳'}
                          {log.value}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-700">
                      {log.eventId}
                    </td>
                    <td className="py-2.5 px-3">
                      {log.browserSent ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Sent</span>
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">Blocked / Skipped</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      {log.serverStatus === 'sent' ? (
                        <div>
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>CAPI 200 OK</span>
                          </span>
                          {log.fbTraceId && (
                            <div className="text-[10px] font-mono text-slate-400">
                              trace: {log.fbTraceId}
                            </div>
                          )}
                        </div>
                      ) : log.serverStatus === 'queued_retry' ? (
                        <span
                          className="inline-flex items-center gap-1 text-amber-700 font-semibold text-[11px]"
                          title={log.serverResponseMsg}
                        >
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>Queued ({log.serverResponseMsg?.slice(0, 32)})</span>
                        </span>
                      ) : (
                        <span className="text-slate-500 text-[11px]">{log.serverResponseMsg}</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {log.matchedKeys.map(k => (
                          <span
                            key={k}
                            className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[10px]"
                          >
                            {k}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-extrabold text-xs">
                        {log.emqScore.toFixed(1)} / 10
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* cPanel Deployment & Verification Note (Developer Only) */}
      {isDeveloper && (
        <div className="bg-slate-900 text-slate-200 p-5 rounded-xl border border-slate-800 text-xs space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Code2 className="w-4 h-4" />
            <span>cPanel পাবলিশিং ও সার্ভার-সাইড ট্র্যাকিং নোট (Zero Extra Configuration Needed)</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            এই প্রজেক্টের <strong>cPanel ZIP (`public_html`)</strong> ফাইলের ভেতরে <code className="text-emerald-300 font-mono">/api/index.php?route=fb/capi</code> এবং <code className="text-emerald-300 font-mono">backend/controllers/ApiController.php</code> আগে থেকেই যুক্ত করা হয়েছে। ফলে আপনি এখানে <strong>Pixel ID</strong> ও <strong>Access Token</strong> বসিয়ে সেভ করলেই তা সরাসরি MySQL ও ডিস্ক ডাটাবেসে সংরক্ষিত থাকবে এবং cPanel-এ পাবলিশ করার পর কোনো অতিরিক্ত কোডিং ছাড়াই ১০০% সার্ভার-সাইড ট্র্যাকিং কাজ করবে।
          </p>
        </div>
      )}
    </div>
  );
};
