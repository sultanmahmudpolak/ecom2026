import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Product,
  ProductVariant,
  LandingSizeChartRow,
  LandingReviewItem,
  SpinWheelLead,
  SpinWheelConfig,
  SpinWheelSliceConfig,
  HomeCategoryBarDesign
} from '../types';
import { ProductThumbnail } from './ProductThumbnail';
import { CameraBarcodeScannerModal } from './CameraBarcodeScannerModal';
import { processUploadedProductImage } from '../utils/imageUploader';
import { getEffectiveProductDescription } from './ProductSeoHelmet';
import {
  DEFAULT_LANDING_SIZE_CHART_HEADERS,
  DEFAULT_LANDING_SIZE_CHART_ROWS,
  DEFAULT_SPIN_WHEEL_CONFIG,
  DEFAULT_SPIN_WHEEL_SLICES
} from '../utils/landingConstants';
import {
  Plus,
  Search,
  Edit,
  X,
  ImagePlus,
  Trash2,
  Package,
  Upload,
  Link2,
  FolderPlus,
  Tag,
  Camera,
  Layers,
  Flame,
  Clock,
  Eye,
  FileText,
  Ruler,
  Star,
  Gift,
  ShoppingBag,
  PhoneCall,
  Copy,
  CheckCircle2,
  Bell
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const {
    t,
    language,
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
    brands,
    addBrand,
    deleteBrand,
    products,
    currentOutlet,
    currentBusiness,
    updateBusiness,
    addProduct,
    updateProduct,
    deleteProduct,
    addStockAdjustment,
    currentUser,
    showToast,
    confirmDelete
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [stockStatusFilter, setStockStatusFilter] = useState<'all' | 'low' | 'out'>('all');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [showCatalogManagerModal, setShowCatalogManagerModal] = useState(false);
  const [catalogManagerTab, setCatalogManagerTab] = useState<'categories' | 'brands'>('categories');
  const [showBarcodeCameraModal, setShowBarcodeCameraModal] = useState(false);
  const [showSpinWheelLeadsModal, setShowSpinWheelLeadsModal] = useState(false);
  const [spinModalTab, setSpinModalTab] = useState<'settings' | 'leads'>('settings');
  const [spinLeadsSearch, setSpinLeadsSearch] = useState('');

  const effectiveSpinConfig = useMemo<Required<SpinWheelConfig>>(() => {
    const cfg = currentBusiness.spinWheelConfig || {};
    return {
      badgeText:
        cfg.badgeText !== undefined && cfg.badgeText.trim() !== ''
          ? cfg.badgeText
          : DEFAULT_SPIN_WHEEL_CONFIG.badgeText,
      titleText:
        cfg.titleText !== undefined && cfg.titleText.trim() !== ''
          ? cfg.titleText
          : DEFAULT_SPIN_WHEEL_CONFIG.titleText,
      subtitleText:
        cfg.subtitleText !== undefined && cfg.subtitleText.trim() !== ''
          ? cfg.subtitleText
          : DEFAULT_SPIN_WHEEL_CONFIG.subtitleText,
      claimButtonText:
        cfg.claimButtonText !== undefined && cfg.claimButtonText.trim() !== ''
          ? cfg.claimButtonText
          : DEFAULT_SPIN_WHEEL_CONFIG.claimButtonText,
      autoPopupDelaySec:
        typeof cfg.autoPopupDelaySec === 'number' && cfg.autoPopupDelaySec >= 1
          ? cfg.autoPopupDelaySec
          : DEFAULT_SPIN_WHEEL_CONFIG.autoPopupDelaySec,
      cooldownDays:
        typeof cfg.cooldownDays === 'number' && cfg.cooldownDays >= 1
          ? cfg.cooldownDays
          : DEFAULT_SPIN_WHEEL_CONFIG.cooldownDays,
      slices:
        Array.isArray(cfg.slices) && cfg.slices.length >= 2
          ? cfg.slices
          : DEFAULT_SPIN_WHEEL_SLICES
    };
  }, [currentBusiness.spinWheelConfig]);

  const [invSpinBadge, setInvSpinBadge] = useState<string>(effectiveSpinConfig.badgeText);
  const [invSpinTitle, setInvSpinTitle] = useState<string>(effectiveSpinConfig.titleText);
  const [invSpinSubtitle, setInvSpinSubtitle] = useState<string>(effectiveSpinConfig.subtitleText);
  const [invSpinDelaySec, setInvSpinDelaySec] = useState<number>(
    effectiveSpinConfig.autoPopupDelaySec
  );
  const [invSpinCooldownDays, setInvSpinCooldownDays] = useState<number>(
    effectiveSpinConfig.cooldownDays
  );
  const [invSpinSlices, setInvSpinSlices] = useState<SpinWheelSliceConfig[]>(() =>
    effectiveSpinConfig.slices.map(s => ({ ...s }))
  );

  useEffect(() => {
    setInvSpinBadge(effectiveSpinConfig.badgeText);
    setInvSpinTitle(effectiveSpinConfig.titleText);
    setInvSpinSubtitle(effectiveSpinConfig.subtitleText);
    setInvSpinDelaySec(effectiveSpinConfig.autoPopupDelaySec);
    setInvSpinCooldownDays(effectiveSpinConfig.cooldownDays);
    setInvSpinSlices(effectiveSpinConfig.slices.map(s => ({ ...s })));
  }, [effectiveSpinConfig]);

  const handleSaveSpinConfigFromInventory = () => {
    const cleanedSlices = invSpinSlices
      .map((s, idx) => ({
        id: s.id || `sw_custom_${idx}_${Date.now()}`,
        label: s.label.trim() || `পুরস্কার #${idx + 1}`,
        shortLabel: s.shortLabel.trim() || s.label.trim() || `ছাড় #${idx + 1}`,
        type: s.type,
        value:
          s.type === 'free_delivery' || s.type === 'none' ? 0 : Math.max(0, Number(s.value) || 0),
        color: s.color || '#e11d48',
        code: s.type === 'none' ? 'TRYAGAIN' : (s.code || `SPIN${idx + 1}`).trim().toUpperCase()
      }))
      .filter(Boolean);

    if (cleanedSlices.length < 2) {
      showToast('স্পিন হুইলে কমপক্ষে ২টি পুরস্কার স্লাইস থাকতে হবে।', 'error');
      return;
    }

    updateBusiness({
      spinWheelEnabled: true,
      spinWheelConfig: {
        badgeText: invSpinBadge.trim() || DEFAULT_SPIN_WHEEL_CONFIG.badgeText,
        titleText: invSpinTitle.trim() || DEFAULT_SPIN_WHEEL_CONFIG.titleText,
        subtitleText: invSpinSubtitle.trim() || DEFAULT_SPIN_WHEEL_CONFIG.subtitleText,
        autoPopupDelaySec: Math.max(1, Math.min(60, Number(invSpinDelaySec) || 4)),
        cooldownDays: Math.max(1, Number(invSpinCooldownDays) || 7),
        slices: cleanedSlices
      }
    });
    showToast('স্পিন দ্য হুইল লেখা, সময় ও পুরস্কার সেটিংস সফলভাবে সেভ হয়েছে!', 'success');
  };

  const spinWheelLeads = useMemo<SpinWheelLead[]>(() => {
    const byId = new Map<string, SpinWheelLead>();
    (currentBusiness.spinWheelLeads || []).forEach(lead => {
      if (lead && lead.id) byId.set(lead.id, lead);
    });
    if (typeof window !== 'undefined') {
      try {
        const raw = window.localStorage.getItem('stockmaster_spin_wheel_leads_v1');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            parsed.forEach((lead: SpinWheelLead) => {
              if (lead && lead.id && !byId.has(lead.id)) {
                byId.set(lead.id, lead);
              }
            });
          }
        }
      } catch {
        // ignore
      }
    }
    return Array.from(byId.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [currentBusiness.spinWheelLeads, showSpinWheelLeadsModal]);

  const handleDeleteSpinLeadFromInventory = (leadId: string) => {
    const targetLead = spinWheelLeads.find(l => l.id === leadId);
    confirmDelete({
      title: 'স্পিন হুইল কাস্টমার নাম্বার মুছে ফেলতে চান?',
      itemName: targetLead
        ? `${targetLead.customerName || targetLead.name || 'Customer'} (${targetLead.customerPhone || targetLead.phone || ''})`
        : undefined,
      message: 'এই কাস্টমারের স্পিন হুইল রেকর্ডটি স্থায়ীভাবে মুছে ফেলা হবে।',
      confirmLabel: 'হ্যাঁ, মুছে ফেলুন',
      onConfirm: () => {
        const nextLeads = spinWheelLeads.filter(l => l.id !== leadId);
        updateBusiness({ spinWheelLeads: nextLeads });
        if (typeof window !== 'undefined') {
          try {
            window.localStorage.setItem('stockmaster_spin_wheel_leads_v1', JSON.stringify(nextLeads));
            window.localStorage.removeItem('stockmaster_spin_daily_lock_v1');
            window.localStorage.removeItem('stockmaster_spin_popup_state_v2');
          } catch {
            // ignore
          }
        }
        showToast('স্পিন হুইল কাস্টমার নাম্বারটি মুছে ফেলা হয়েছে।', 'info');
      }
    });
  };

  // Category & Brand Add Form States
  const [newCatNameBn, setNewCatNameBn] = useState('');
  const [newCatNameEn, setNewCatNameEn] = useState('');
  const [newCatImage, setNewCatImage] = useState('');
  const [newCatShowOnHome, setNewCatShowOnHome] = useState<boolean>(true);
  const newCatImageInputRef = useRef<HTMLInputElement | null>(null);
  const quickCatUploadInputRef = useRef<HTMLInputElement | null>(null);
  const [quickUploadCategoryId, setQuickUploadCategoryId] = useState<string | null>(null);
  const [newBrandName, setNewBrandName] = useState('');
  const [newBrandOrigin, setNewBrandOrigin] = useState('বাংলাদেশ');

  // Quick 1-Click Row Image Upload target
  const quickRowUploadInputRef = useRef<HTMLInputElement | null>(null);
  const [quickUploadProductId, setQuickUploadProductId] = useState<string | null>(null);

  // Form states for Add / Edit Product
  const [formNameBn, setFormNameBn] = useState('');
  const [formNameEn, setFormNameEn] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formBarcode, setFormBarcode] = useState('');
  const [formWpProductId, setFormWpProductId] = useState<string>('');
  const [formCategory, setFormCategory] = useState(categories[0]?.id || 'cat_01');
  const [formBrand, setFormBrand] = useState(brands[0]?.id || 'brand_01');
  const [formUnit, setFormUnit] = useState('প্যাকেট (Pack)');
  const [formPurchasePrice, setFormPurchasePrice] = useState<number>(0);
  const [formRegularPrice, setFormRegularPrice] = useState<number>(0);
  const [formDiscountPrice, setFormDiscountPrice] = useState<string>('');
  const [formRetailPrice, setFormRetailPrice] = useState<number>(0);
  const [formWholesalePrice, setFormWholesalePrice] = useState<number>(0);
  const [formLowStockAlert, setFormLowStockAlert] = useState<number>(15);
  const [formInitialStock, setFormInitialStock] = useState<number>(50);
  const [formIsOutOfStock, setFormIsOutOfStock] = useState<boolean>(false);
  const [formFreeDelivery, setFormFreeDelivery] = useState<boolean>(false);
  const [formBatchNo, setFormBatchNo] = useState('');
  const [formExpiryDate, setFormExpiryDate] = useState('');
  const [formImage, setFormImage] = useState<string>('');
  const [formGalleryImages, setFormGalleryImages] = useState<string[]>([]);
  const [newGalleryUrl, setNewGalleryUrl] = useState<string>('');
  const [formDescription, setFormDescription] = useState<string>('');
  const [formVariants, setFormVariants] = useState<ProductVariant[]>([]);
  const [newVarLabel, setNewVarLabel] = useState<string>('');
  const [newVarSku, setNewVarSku] = useState<string>('');
  const [newVarType, setNewVarType] = useState<'weight' | 'size' | 'color' | 'pack'>('size');
  const [newVarPurchasePrice, setNewVarPurchasePrice] = useState<string>('');
  const [newVarRegularPrice, setNewVarRegularPrice] = useState<string>('');
  const [newVarRetailPrice, setNewVarRetailPrice] = useState<string>('');
  const [formCountdownEnabled, setFormCountdownEnabled] = useState<boolean>(true);
  const [formCountdownHours, setFormCountdownHours] = useState<number>(9);
  const [formCountdownTitle, setFormCountdownTitle] = useState<string>('স্পেশাল অফার শেষ হতে বাকি:');
  const [formLiveViewersEnabled, setFormLiveViewersEnabled] = useState<boolean>(true);

  // Size Chart States for Storefront Product Page
  const [formSizeChartEnabled, setFormSizeChartEnabled] = useState<boolean>(true);
  const [formSizeChartTitle, setFormSizeChartTitle] = useState<string>('সাইজ চার্ট ও বডির মাপ (Size Chart)');
  const [formSizeChartSubtitle, setFormSizeChartSubtitle] = useState<string>(
    'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন'
  );
  const [formSizeChartHeaders, setFormSizeChartHeaders] = useState<[string, string, string]>(
    [...DEFAULT_LANDING_SIZE_CHART_HEADERS]
  );
  const [formSizeChartRows, setFormSizeChartRows] = useState<LandingSizeChartRow[]>(
    DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }))
  );
  const [formSizeChartImage, setFormSizeChartImage] = useState<string>('');
  const sizeChartFileInputRef = useRef<HTMLInputElement | null>(null);

  // Customer / Fake Reviews States for Storefront Product Page
  const [formReviewsEnabled, setFormReviewsEnabled] = useState<boolean>(true);
  const [formReviewsTitle, setFormReviewsTitle] = useState<string>('সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ');
  const [formReviewItems, setFormReviewItems] = useState<LandingReviewItem[]>([]);
  const [newRevName, setNewRevName] = useState<string>('');
  const [newRevLocation, setNewRevLocation] = useState<string>('ঢাকা');
  const [newRevRating, setNewRevRating] = useState<number>(5);
  const [newRevComment, setNewRevComment] = useState<string>('');

  // Real Customer Photo & Unboxing Video States for Storefront Product Page
  const [formRealGalleryEnabled, setFormRealGalleryEnabled] = useState<boolean>(true);
  const [formRealGalleryTitle, setFormRealGalleryTitle] = useState<string>(
    'আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও'
  );
  const [formRealCustomerPhotos, setFormRealCustomerPhotos] = useState<string[]>([]);
  const [formRealUnboxingVideoUrl, setFormRealUnboxingVideoUrl] = useState<string>('');
  const realCustomerPhotoInputRef = useRef<HTMLInputElement | null>(null);

  // Central Customer Review Approval & Delete Manager Modal States
  const [showReviewsManagerModal, setShowReviewsManagerModal] = useState<boolean>(false);
  const [reviewsManagerFilter, setReviewsManagerFilter] = useState<'all' | 'pending' | 'approved'>('all');
  const [reviewsManagerSearch, setReviewsManagerSearch] = useState<string>('');

  const allProductReviewsList = useMemo(() => {
    const list: Array<{ product: Product; review: LandingReviewItem }> = [];
    for (const prod of products) {
      if (Array.isArray(prod.landingReviewItems)) {
        for (const rev of prod.landingReviewItems) {
          list.push({ product: prod, review: rev });
        }
      }
    }
    return list.sort((a, b) => {
      const aPending = a.review.status === 'pending' ? 0 : 1;
      const bPending = b.review.status === 'pending' ? 0 : 1;
      if (aPending !== bPending) return aPending - bPending;
      return (b.review.createdAt || '').localeCompare(a.review.createdAt || '');
    });
  }, [products]);

  const pendingReviewsCount = useMemo(
    () => allProductReviewsList.filter(item => item.review.status === 'pending').length,
    [allProductReviewsList]
  );

  const [isProcessingImage, setIsProcessingImage] = useState<boolean>(false);
  const modalFileInputRef = useRef<HTMLInputElement | null>(null);
  const galleryFileInputRef = useRef<HTMLInputElement | null>(null);

  // Stock Update & Adjustment Form
  const [stockUpdateMode, setStockUpdateMode] = useState<'set' | 'add' | 'subtract'>('set');
  const [adjType, setAdjType] = useState<'damage' | 'expired' | 'wastage' | 'physical_count_correction'>('damage');
  const [adjQuantity, setAdjQuantity] = useState<number>(1);
  const [adjReason, setAdjReason] = useState<string>('নতুন স্টক আপডেট');

  // Filtered Products (Regular Storefront Products only)
  const regularStoreProducts = useMemo(
    () => products.filter(p => !p.isLandingPageProduct),
    [products]
  );

  const filteredProducts = useMemo(() => {
    return regularStoreProducts.filter(p => {
      const q = searchQuery.toLowerCase().trim();
      const matchQuery =
        !q ||
        p.nameBn.toLowerCase().includes(q) ||
        p.nameEn.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.includes(q);

      const matchCat = categoryFilter === 'all' || p.categoryId === categoryFilter;

      const currentStock = p.stockByOutlet[currentOutlet.id] ?? 0;
      const allVarsOut =
        Array.isArray(p.variants) && p.variants.length > 0 && p.variants.every(v => v.outOfStock);
      const effectiveOut = Boolean(p.isOutOfStock) || currentStock <= 0 || allVarsOut;
      let matchStock = true;
      if (stockStatusFilter === 'low') {
        matchStock = !effectiveOut && currentStock > 0 && currentStock <= (p.lowStockAlert || 15);
      } else if (stockStatusFilter === 'out') {
        matchStock = effectiveOut;
      }

      return matchQuery && matchCat && matchStock;
    });
  }, [regularStoreProducts, searchQuery, categoryFilter, stockStatusFilter, currentOutlet.id]);

  const PRODUCTS_PER_PAGE = 50;
  const [productPage, setProductPage] = useState<number>(1);

  useEffect(() => {
    setProductPage(1);
  }, [searchQuery, categoryFilter, stockStatusFilter, currentOutlet.id]);

  const totalProductPages = Math.max(1, Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE));
  const safeProductPage = Math.min(productPage, totalProductPages);
  const paginatedProducts = useMemo(() => {
    const start = (safeProductPage - 1) * PRODUCTS_PER_PAGE;
    return filteredProducts.slice(start, start + PRODUCTS_PER_PAGE);
  }, [filteredProducts, safeProductPage]);

  // Default regular price helper when opening an existing product that didn't have explicit regularPrice saved yet
  const computeDefaultRegularPrice = (p: Product): number => {
    if (p.regularPrice && p.regularPrice > 0) return p.regularPrice;
    const r = p.retailPrice;
    if (r >= 1000) return Math.round(r + 80);
    if (r >= 500) return Math.round(r + 40);
    if (r >= 150) return Math.round(r + 15);
    return Math.round(r + 5);
  };

  // Effective selling price from Regular Price + optional Discount Price
  const effectiveFormSellingPrice = useMemo(() => {
    const disc = parseFloat(formDiscountPrice);
    if (!Number.isNaN(disc) && disc > 0) {
      return disc;
    }
    return formRegularPrice > 0 ? formRegularPrice : formRetailPrice;
  }, [formRegularPrice, formDiscountPrice, formRetailPrice]);

  // Open Edit Form
  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setFormNameBn(p.nameBn);
    setFormNameEn(p.nameEn);
    setFormSku(p.sku);
    setFormBarcode(p.barcode);
    setFormWpProductId(p.wpProductId && p.wpProductId > 0 ? String(p.wpProductId) : '');
    setFormCategory(p.categoryId || categories[0]?.id || 'cat_01');
    setFormBrand(p.brandId || brands[0]?.id || 'brand_01');
    setFormUnit(p.unit);
    setFormPurchasePrice(p.purchasePrice);

    const resolvedRegular = computeDefaultRegularPrice(p);
    const hasDiscount = p.discountPrice !== undefined
      ? p.discountPrice > 0 && p.discountPrice < resolvedRegular
      : p.retailPrice < resolvedRegular;

    setFormRegularPrice(resolvedRegular);
    setFormDiscountPrice(hasDiscount ? String(p.discountPrice || p.retailPrice) : '');
    setFormRetailPrice(p.retailPrice);
    setFormWholesalePrice(p.wholesalePrice);
    setFormLowStockAlert(p.lowStockAlert);
    setFormInitialStock(p.stockByOutlet?.[currentOutlet.id] ?? p.stockByOutlet?.['outlet_01'] ?? 0);
    setFormIsOutOfStock(Boolean(p.isOutOfStock));
    setFormFreeDelivery(Boolean(p.freeDelivery || p.freeDeliveryOnLanding));
    setFormBatchNo(p.batchNumber || '');
    setFormExpiryDate(p.expiryDate || '');
    setFormImage(p.image || '');
    setFormGalleryImages(Array.isArray(p.galleryImages) ? [...p.galleryImages] : []);
    setNewGalleryUrl('');
    setFormDescription(
      p.description !== undefined ? p.description : getEffectiveProductDescription(p)
    );
    setFormVariants(Array.isArray(p.variants) ? [...p.variants] : []);
    setNewVarLabel('');
    setNewVarSku('');
    setNewVarPurchasePrice('');
    setNewVarRegularPrice('');
    setNewVarRetailPrice('');
    setFormCountdownEnabled(p.landingCountdownEnabled !== false);
    setFormCountdownHours(
      p.landingCountdownHours && p.landingCountdownHours > 0 ? p.landingCountdownHours : 9
    );
    setFormCountdownTitle(p.landingCountdownTitle || 'স্পেশাল অফার শেষ হতে বাকি:');
    setFormLiveViewersEnabled(p.landingLiveViewersEnabled !== false);
    setFormSizeChartEnabled(p.landingSizeChartEnabled !== false);
    setFormSizeChartTitle(p.landingSizeChartTitle || 'সাইজ চার্ট ও বডির মাপ (Size Chart)');
    setFormSizeChartSubtitle(
      p.landingSizeChartSubtitle !== undefined
        ? p.landingSizeChartSubtitle
        : 'অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন'
    );
    setFormSizeChartHeaders(
      Array.isArray(p.landingSizeChartHeaders) && p.landingSizeChartHeaders.length === 3
        ? ([...p.landingSizeChartHeaders] as [string, string, string])
        : [...DEFAULT_LANDING_SIZE_CHART_HEADERS]
    );
    setFormSizeChartRows(
      Array.isArray(p.landingSizeChartRows) && p.landingSizeChartRows.length > 0
        ? p.landingSizeChartRows.map(r => ({ ...r }))
        : DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }))
    );
    setFormSizeChartImage(p.landingSizeChartImage || '');
    setFormReviewsEnabled(p.landingReviewsEnabled !== false);
    setFormReviewsTitle(p.landingReviewsTitle || 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ');
    setFormReviewItems(Array.isArray(p.landingReviewItems) ? p.landingReviewItems.map(r => ({ ...r })) : []);
    setFormRealGalleryEnabled(p.realCustomerGalleryEnabled !== false);
    setFormRealGalleryTitle(
      p.realCustomerGalleryTitle || 'আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও'
    );
    setFormRealCustomerPhotos(Array.isArray(p.realCustomerPhotos) ? [...p.realCustomerPhotos] : []);
    setFormRealUnboxingVideoUrl(p.realUnboxingVideoUrl || '');
    setNewRevName('');
    setNewRevLocation('ঢাকা');
    setNewRevRating(5);
    setNewRevComment('');
    setShowAddModal(true);
  };

  // Helper to build a clean Variation SKU from Parent SKU + Size/Variation Label (e.g. "SKU-101-XL" or "SKU-101-5-6Y")
  const buildVariantSkuCode = (baseSku: string, label: string, idx = 0): string => {
    const cleanBase = (baseSku || 'ITEM').trim().toUpperCase().replace(/\s+/g, '-');
    const englishParen = label.match(/\(([^()]+)\)/);
    const rawPart = englishParen ? englishParen[1] : label;
    const slug = rawPart
      .trim()
      .toUpperCase()
      .replace(/YEARS?/gi, 'Y')
      .replace(/[^A-Z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    return `${cleanBase}-${slug || `V${idx + 1}`}`;
  };

  // Add a single custom variation row to the product form
  const handleAddVariantRow = () => {
    const cleanLabel = newVarLabel.trim();
    if (!cleanLabel) {
      showToast('ভ্যারিয়েশনের নাম লিখুন (যেমন: 500gm, 1kg, লাল, XL)', 'error');
      return;
    }
    const retail = Number(newVarRetailPrice) || effectiveFormSellingPrice || 100;
    const regular = Number(newVarRegularPrice) || (formRegularPrice > retail ? formRegularPrice : retail);
    const purchase = Number(newVarPurchasePrice) || Math.round(retail * 0.88);
    const autoSku = newVarSku.trim() || buildVariantSkuCode(formSku, cleanLabel, formVariants.length);
    const created: ProductVariant = {
      id: `var_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      label: cleanLabel,
      sku: autoSku,
      type: newVarType,
      purchasePrice: purchase,
      regularPrice: regular,
      discountPrice: retail < regular ? retail : undefined,
      retailPrice: retail
    };
    setFormVariants(prev => [...prev, created]);
    setNewVarLabel('');
    setNewVarSku('');
    setNewVarPurchasePrice('');
    setNewVarRegularPrice('');
    setNewVarRetailPrice('');
  };

  // Apply 1-click variation presets (Baby Years / Cloth Size / Color / Weight) with automatic Variation SKUs
  const handleApplyVariantPreset = (
    presetType: 'baby_years' | 'size_cloth' | 'color_set' | 'weight_kg' | 'liquid_l'
  ) => {
    const baseRetail = effectiveFormSellingPrice > 0 ? effectiveFormSellingPrice : 850;
    const baseRegular = formRegularPrice > baseRetail ? formRegularPrice : baseRetail;
    const basePurchase = formPurchasePrice > 0 ? formPurchasePrice : Math.round(baseRetail * 0.7);
    const ts = Date.now();

    let presetItems: ProductVariant[] = [];
    if (presetType === 'baby_years') {
      presetItems = [
        '1-2 Years',
        '3-4 Years',
        '5-6 Years',
        '7-8 Years',
        '9-10 Years',
        '11-12 Years'
      ].map((lbl, i) => ({
        id: `var_${ts}_yr_${i}`,
        label: lbl,
        sku: buildVariantSkuCode(formSku, lbl, i),
        type: 'size',
        purchasePrice: basePurchase,
        regularPrice: baseRegular,
        discountPrice: baseRetail < baseRegular ? baseRetail : undefined,
        retailPrice: baseRetail
      }));
    } else if (presetType === 'size_cloth') {
      presetItems = ['M', 'L', 'XL', 'XXL'].map((lbl, i) => ({
        id: `var_${ts}_sz_${i}`,
        label: lbl,
        sku: buildVariantSkuCode(formSku, lbl, i),
        type: 'size',
        purchasePrice: basePurchase,
        regularPrice: baseRegular,
        discountPrice: baseRetail < baseRegular ? baseRetail : undefined,
        retailPrice: baseRetail
      }));
    } else if (presetType === 'color_set') {
      presetItems = ['লাল (Red)', 'নীল (Blue)', 'কালো (Black)', 'সাদা (White)'].map((lbl, i) => ({
        id: `var_${ts}_clr_${i}`,
        label: lbl,
        sku: buildVariantSkuCode(formSku, lbl, i),
        type: 'color',
        purchasePrice: basePurchase,
        regularPrice: baseRegular,
        discountPrice: baseRetail < baseRegular ? baseRetail : undefined,
        retailPrice: baseRetail
      }));
    } else if (presetType === 'weight_kg') {
      presetItems = [
        {
          id: `var_${ts}_500g`,
          label: '৫০০ গ্রাম (500gm)',
          sku: buildVariantSkuCode(formSku, '500GM', 0),
          type: 'weight',
          purchasePrice: Math.round(basePurchase * 0.5),
          regularPrice: Math.round(baseRegular * 0.52),
          retailPrice: Math.round(baseRetail * 0.52)
        },
        {
          id: `var_${ts}_1kg`,
          label: '১ কেজি (1kg)',
          sku: buildVariantSkuCode(formSku, '1KG', 1),
          type: 'weight',
          purchasePrice: basePurchase,
          regularPrice: baseRegular,
          retailPrice: baseRetail
        },
        {
          id: `var_${ts}_2kg`,
          label: '২ কেজি (2kg)',
          sku: buildVariantSkuCode(formSku, '2KG', 2),
          type: 'weight',
          purchasePrice: Math.round(basePurchase * 1.98),
          regularPrice: Math.round(baseRegular * 1.96),
          retailPrice: Math.round(baseRetail * 1.96)
        }
      ];
    } else if (presetType === 'liquid_l') {
      presetItems = [
        {
          id: `var_${ts}_500ml`,
          label: '৫০০ মি.লি (500ml)',
          sku: buildVariantSkuCode(formSku, '500ML', 0),
          type: 'weight',
          purchasePrice: Math.round(basePurchase * 0.5),
          regularPrice: Math.round(baseRegular * 0.52),
          retailPrice: Math.round(baseRetail * 0.52)
        },
        {
          id: `var_${ts}_1l`,
          label: '১ লিটার (1L)',
          sku: buildVariantSkuCode(formSku, '1L', 1),
          type: 'weight',
          purchasePrice: basePurchase,
          regularPrice: baseRegular,
          retailPrice: baseRetail
        },
        {
          id: `var_${ts}_5l`,
          label: '৫ লিটার (5L)',
          sku: buildVariantSkuCode(formSku, '5L', 2),
          type: 'weight',
          purchasePrice: Math.round(basePurchase * 4.85),
          regularPrice: Math.round(baseRegular * 4.8),
          retailPrice: Math.round(baseRetail * 4.8)
        }
      ];
    }

    setFormVariants(prev => [...prev, ...presetItems]);
    showToast('ভ্যারিয়েশন ও অটো-SKU যুক্ত হয়েছে! প্রয়োজনে SKU বা দাম পরিবর্তন করতে পারেন।', 'info');
  };

  const handleUpdateVariantField = (
    varId: string,
    field: 'label' | 'sku' | 'purchasePrice' | 'regularPrice' | 'retailPrice' | 'type' | 'imageUrl',
    value: string | number | undefined
  ) => {
    setFormVariants(prev =>
      prev.map(v => (v.id === varId ? { ...v, [field]: value } : v))
    );
  };

  const handleRemoveVariantRow = (varId: string) => {
    setFormVariants(prev => prev.filter(v => v.id !== varId));
  };

  // Handle Modal File Selection
  const handleModalImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsProcessingImage(true);
    try {
      const compressedDataUrl = await processUploadedProductImage(file, 1200, 0.92);
      setFormImage(compressedDataUrl);
      // Remove any broken/demo unsplash URLs from gallery if user uploads a real main photo
      setFormGalleryImages(prev => prev.filter(u => !u.includes('images.unsplash.com/photo-1599599810769')));
      showToast(
        language === 'bn'
          ? 'পণ্যের এইচডি (HD) ছবি প্রস্তুত হয়েছে! সংরক্ষণ বাটনে ক্লিক করুন।'
          : 'HD Product photo ready! Click Save to apply.',
        'info'
      );
    } catch (err: any) {
      showToast(err?.message || 'ছবি প্রসেস করতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsProcessingImage(false);
      e.target.value = '';
    }
  };

  // Handle Multi-Image Gallery File Upload
  const handleGalleryFilesChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const filesList = e.target.files ? Array.from(e.target.files) : [];
    if (filesList.length === 0) return;
    setIsProcessingImage(true);
    try {
      const uploadedUrls: string[] = [];
      for (const file of filesList.slice(0, 6)) {
        const compressed = await processUploadedProductImage(file, 1200, 0.92);
        uploadedUrls.push(compressed);
      }
      setFormGalleryImages(prev => [...prev, ...uploadedUrls]);
      showToast(
        `${uploadedUrls.length} টি গ্যালারি ছবি যুক্ত হয়েছে! সংরক্ষণ বাটনে ক্লিক করুন।`,
        'success'
      );
    } catch (err: any) {
      showToast(err?.message || 'গ্যালারি ছবি আপলোড করতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsProcessingImage(false);
      e.target.value = '';
    }
  };

  // Handle 1-Click Row Image Upload
  const handleQuickRowImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetId = quickUploadProductId;
    if (!file || !targetId) return;
    try {
      const compressedDataUrl = await processUploadedProductImage(file, 1200, 0.92);
      await updateProduct(targetId, { image: compressedDataUrl });
      showToast(
        language === 'bn'
          ? 'পণ্যের এইচডি (HD) ছবি সফলভাবে আপলোড ও ই-কমার্স শপে আপডেট হয়েছে!'
          : 'Product HD photo uploaded and synced to E-Commerce Storefront!',
        'success'
      );
    } catch (err: any) {
      showToast(err?.message || 'ছবি আপলোড ব্যর্থ হয়েছে', 'error');
    } finally {
      setQuickUploadProductId(null);
      e.target.value = '';
    }
  };

  // Handle Category Image Upload in Create Category Form
  const handleNewCatImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsProcessingImage(true);
    try {
      const compressed = await processUploadedProductImage(file, 600, 0.9);
      setNewCatImage(compressed);
      showToast('ক্যাটাগরির ছবি যুক্ত হয়েছে!', 'success');
    } catch (err: any) {
      showToast(err?.message || 'ক্যাটাগরির ছবি আপলোড করতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsProcessingImage(false);
      e.target.value = '';
    }
  };

  // Handle 1-Click Category Image Upload on Existing Category Row
  const handleQuickCatImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetCatId = quickUploadCategoryId;
    if (!file || !targetCatId) return;
    setIsProcessingImage(true);
    try {
      const compressed = await processUploadedProductImage(file, 600, 0.9);
      updateCategory(targetCatId, { image: compressed });
      showToast('ক্যাটাগরির ছবি সফলভাবে আপডেট হয়েছে!', 'success');
    } catch (err: any) {
      showToast(err?.message || 'ক্যাটাগরির ছবি আপলোড ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsProcessingImage(false);
      setQuickUploadCategoryId(null);
      e.target.value = '';
    }
  };

  // Add Category Handler
  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatNameBn.trim()) {
      showToast('ক্যাটাগরির নাম লিখুন', 'error');
      return;
    }
    const created = addCategory({
      nameBn: newCatNameBn.trim(),
      nameEn: newCatNameEn.trim() || newCatNameBn.trim(),
      image: newCatImage.trim() || undefined,
      showOnHome: newCatShowOnHome
    });
    setFormCategory(created.id);
    setNewCatNameBn('');
    setNewCatNameEn('');
    setNewCatImage('');
    setNewCatShowOnHome(true);
  };

  // Add Brand Handler
  const handleAddBrandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBrandName.trim()) {
      showToast('ব্র্যান্ডের নাম লিখুন', 'error');
      return;
    }
    const created = addBrand({
      name: newBrandName.trim(),
      origin: newBrandOrigin.trim() || 'বাংলাদেশ'
    });
    setFormBrand(created.id);
    setNewBrandName('');
    setNewBrandOrigin('বাংলাদেশ');
  };

  // Submit Add / Edit
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNameBn || !formSku) {
      showToast('পণ্যের নাম ও এসকেইউ আবশ্যক', 'error');
      return;
    }

    const cleanRegularPrice = Number(formRegularPrice) || Number(formRetailPrice) || 0;
    const parsedDiscount = parseFloat(formDiscountPrice);
    const hasValidDiscount = !Number.isNaN(parsedDiscount) && parsedDiscount > 0;
    const finalSellingPrice = hasValidDiscount ? parsedDiscount : cleanRegularPrice;
    const finalRegularPrice = Math.max(cleanRegularPrice, finalSellingPrice);

    // Sync variants if their retailPrice matched the old product retailPrice or ensure regularPrice & SKU are set
    const syncedVariants = formVariants.map((v, idx) => {
      const vReg = v.regularPrice && v.regularPrice > 0 ? v.regularPrice : finalRegularPrice;
      const cleanVarSku = (v.sku || '').trim() || buildVariantSkuCode(formSku, v.label, idx);
      return {
        ...v,
        sku: cleanVarSku,
        regularPrice: Math.max(vReg, v.retailPrice),
        discountPrice: v.retailPrice < vReg ? v.retailPrice : undefined
      };
    });

    const parsedWpProdId = parseInt(formWpProductId.trim(), 10);
    const validWpProdId = !Number.isNaN(parsedWpProdId) && parsedWpProdId > 0 ? parsedWpProdId : undefined;

    if (editingProduct) {
      await updateProduct(editingProduct.id, {
        nameBn: formNameBn,
        nameEn: formNameEn || formNameBn,
        sku: formSku,
        barcode: formBarcode || formSku,
        wpProductId: validWpProdId,
        categoryId: formCategory,
        brandId: formBrand,
        unit: formUnit,
        purchasePrice: formPurchasePrice,
        regularPrice: finalRegularPrice,
        discountPrice: hasValidDiscount ? parsedDiscount : 0,
        retailPrice: finalSellingPrice,
        wholesalePrice: formWholesalePrice,
        stockByOutlet: {
          ...(editingProduct.stockByOutlet || {}),
          outlet_01: Math.max(0, Number(formInitialStock) || 0),
          [currentOutlet.id]: Math.max(0, Number(formInitialStock) || 0)
        },
        lowStockAlert: formLowStockAlert,
        batchNumber: formBatchNo,
        expiryDate: formExpiryDate,
        image: formImage.trim() || undefined,
        galleryImages: formGalleryImages,
        description: formDescription.trim(),
        isOutOfStock: formIsOutOfStock,
        freeDelivery: formFreeDelivery,
        freeDeliveryOnLanding: formFreeDelivery,
        variants: syncedVariants,
        landingCountdownEnabled: formCountdownEnabled,
        landingCountdownHours: Number(formCountdownHours) > 0 ? Number(formCountdownHours) : 9,
        landingCountdownTitle: formCountdownTitle.trim() || 'স্পেশাল অফার শেষ হতে বাকি:',
        landingLiveViewersEnabled: formLiveViewersEnabled,
        landingSizeChartEnabled: formSizeChartEnabled,
        landingSizeChartTitle: formSizeChartTitle.trim() || 'সাইজ চার্ট ও বডির মাপ (Size Chart)',
        landingSizeChartSubtitle: formSizeChartSubtitle.trim(),
        landingSizeChartHeaders: formSizeChartHeaders,
        landingSizeChartRows: formSizeChartRows,
        landingSizeChartImage: formSizeChartImage.trim() || undefined,
        landingReviewsEnabled: formReviewsEnabled,
        landingReviewsTitle: formReviewsTitle.trim() || 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ',
        landingReviewItems: formReviewItems,
        realCustomerGalleryEnabled: formRealGalleryEnabled,
        realCustomerGalleryTitle:
          formRealGalleryTitle.trim() || 'আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও',
        realCustomerPhotos: formRealCustomerPhotos,
        realUnboxingVideoUrl: formRealUnboxingVideoUrl.trim() || undefined
      });
    } else {
      await addProduct({
        businessId: currentBusiness.id,
        nameBn: formNameBn,
        nameEn: formNameEn || formNameBn,
        sku: formSku,
        barcode: formBarcode || Date.now().toString(),
        wpProductId: validWpProdId,
        categoryId: formCategory,
        brandId: formBrand,
        unit: formUnit,
        packSize: 1,
        purchasePrice: formPurchasePrice,
        regularPrice: finalRegularPrice,
        discountPrice: hasValidDiscount ? parsedDiscount : 0,
        retailPrice: finalSellingPrice,
        wholesalePrice: formWholesalePrice,
        minWholesaleQty: 5,
        stockByOutlet: {
          outlet_01: formInitialStock,
          [currentOutlet.id]: formInitialStock
        },
        lowStockAlert: formLowStockAlert,
        batchNumber: formBatchNo || `BT-${Date.now().toString().slice(-4)}`,
        expiryDate: formExpiryDate || '2028-12-31',
        vatPercent: 5,
        image: formImage.trim() || undefined,
        galleryImages: formGalleryImages,
        description: formDescription.trim(),
        isOutOfStock: formIsOutOfStock,
        freeDelivery: formFreeDelivery,
        freeDeliveryOnLanding: formFreeDelivery,
        variants: syncedVariants,
        landingCountdownEnabled: formCountdownEnabled,
        landingCountdownHours: Number(formCountdownHours) > 0 ? Number(formCountdownHours) : 9,
        landingCountdownTitle: formCountdownTitle.trim() || 'স্পেশাল অফার শেষ হতে বাকি:',
        landingLiveViewersEnabled: formLiveViewersEnabled,
        landingSizeChartEnabled: formSizeChartEnabled,
        landingSizeChartTitle: formSizeChartTitle.trim() || 'সাইজ চার্ট ও বডির মাপ (Size Chart)',
        landingSizeChartSubtitle: formSizeChartSubtitle.trim(),
        landingSizeChartHeaders: formSizeChartHeaders,
        landingSizeChartRows: formSizeChartRows,
        landingSizeChartImage: formSizeChartImage.trim() || undefined,
        landingReviewsEnabled: formReviewsEnabled,
        landingReviewsTitle: formReviewsTitle.trim() || 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ',
        landingReviewItems: formReviewItems,
        realCustomerGalleryEnabled: formRealGalleryEnabled,
        realCustomerGalleryTitle:
          formRealGalleryTitle.trim() || 'আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও',
        realCustomerPhotos: formRealCustomerPhotos,
        realUnboxingVideoUrl: formRealUnboxingVideoUrl.trim() || undefined
      });
    }

    setShowAddModal(false);
    setEditingProduct(null);
  };

  // Submit Stock Update / Adjustment
  const handleSaveAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;

    const currentStock =
      adjustingProduct.stockByOutlet?.[currentOutlet.id] ??
      adjustingProduct.stockByOutlet?.['outlet_01'] ??
      0;

    if (stockUpdateMode === 'set') {
      const nextStock = Math.max(0, Number(adjQuantity) || 0);
      await updateProduct(adjustingProduct.id, {
        stockByOutlet: {
          ...(adjustingProduct.stockByOutlet || {}),
          outlet_01: nextStock,
          [currentOutlet.id]: nextStock
        }
      });
      showToast(
        `"${adjustingProduct.nameBn}"-এর স্টক আপডেট হয়ে ${nextStock} ${adjustingProduct.unit.split(' ')[0]} করা হয়েছে!`,
        'success'
      );
    } else if (stockUpdateMode === 'add') {
      const addedQty = Math.max(1, Number(adjQuantity) || 0);
      const nextStock = currentStock + addedQty;
      await updateProduct(adjustingProduct.id, {
        stockByOutlet: {
          ...(adjustingProduct.stockByOutlet || {}),
          outlet_01: nextStock,
          [currentOutlet.id]: nextStock
        }
      });
      showToast(
        `"${adjustingProduct.nameBn}"-এ +${addedQty} স্টক যোগ হয়ে মোট স্টক ${nextStock} করা হয়েছে!`,
        'success'
      );
    } else {
      await addStockAdjustment({
        businessId: currentBusiness.id,
        outletId: currentOutlet.id,
        productId: adjustingProduct.id,
        productName: adjustingProduct.nameBn,
        type: adjType,
        quantity: -Math.abs(adjQuantity),
        costImpact: Math.abs(adjQuantity) * adjustingProduct.purchasePrice,
        reason: adjReason,
        createdBy: currentUser.name
      });
    }

    setAdjustingProduct(null);
  };

  return (
    <div className="space-y-5">
      {/* Hidden input for 1-click row image upload */}
      <input
        ref={quickRowUploadInputRef}
        type="file"
        accept="image/*"
        onChange={handleQuickRowImageChange}
        className="hidden"
      />
      {/* Hidden input for 1-click category image upload */}
      <input
        ref={quickCatUploadInputRef}
        type="file"
        accept="image/*"
        onChange={handleQuickCatImageChange}
        className="hidden"
      />

      {/* Header Strip with Category & Brand Management + Add Product */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-2xs space-y-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h1 className="text-lg sm:text-xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              {t.inventory}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {language === 'bn'
                ? `বর্তমান আউটলেট: ${currentOutlet.name} · মোট পণ্য: ${regularStoreProducts.length} টি · ক্যাটাগরি: ${categories.length} টি · ব্র্যান্ড: ${brands.length} টি`
                : `Current Location: ${currentOutlet.name} · Total Items: ${regularStoreProducts.length} · Categories: ${categories.length} · Brands: ${brands.length}`}
            </p>
          </div>

          {/* Primary Catalog Actions */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Customer Review Approval & Delete Manager Button */}
            <button
              type="button"
              onClick={() => {
                setReviewsManagerFilter(pendingReviewsCount > 0 ? 'pending' : 'all');
                setShowReviewsManagerModal(true);
              }}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border shadow-2xs transition-all cursor-pointer ${
                pendingReviewsCount > 0
                  ? 'bg-amber-50 hover:bg-amber-100 text-amber-950 border-amber-400'
                  : 'bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700'
              }`}
              title="কাস্টমারদের দেওয়া রিভিউ অ্যাপ্রুভ (Approve) অথবা ডিলিট করুন"
            >
              <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
              <span>কাস্টমার রিভিউ ({allProductReviewsList.length})</span>
              {pendingReviewsCount > 0 && (
                <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-extrabold animate-pulse">
                  পেন্ডিং: {pendingReviewsCount}
                </span>
              )}
            </button>

            {/* Category Add / Delete Button */}
            <button
              type="button"
              onClick={() => {
                setCatalogManagerTab('categories');
                setShowCatalogManagerModal(true);
              }}
              className="min-h-[38px] px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <FolderPlus className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <span>
                {language === 'bn'
                  ? `ক্যাটাগরি অ্যাড / ডিলিট (${categories.length})`
                  : `Manage Categories (${categories.length})`}
              </span>
            </button>

            {/* Brand Add / Delete Button */}
            <button
              type="button"
              onClick={() => {
                setCatalogManagerTab('brands');
                setShowCatalogManagerModal(true);
              }}
              className="min-h-[38px] px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <Tag className="w-4 h-4 text-blue-700 dark:text-blue-400" />
              <span>
                {language === 'bn'
                  ? `ব্র্যান্ড অ্যাড / ডিলিট (${brands.length})`
                  : `Manage Brands (${brands.length})`}
              </span>
            </button>

            {/* Add New Product Button */}
            <button
              type="button"
              onClick={() => {
                setEditingProduct(null);
                setFormNameBn('');
                setFormNameEn('');
                setFormSku(`SKU-${Date.now().toString().slice(-5)}`);
                setFormBarcode(Date.now().toString());
                setFormWpProductId('');
                setFormCategory(categories[0]?.id || 'cat_01');
                setFormBrand(brands[0]?.id || 'brand_01');
                setFormPurchasePrice(500);
                setFormRegularPrice(850);
                setFormDiscountPrice('750');
                setFormRetailPrice(750);
                setFormWholesalePrice(620);
                setFormInitialStock(100);
                setFormIsOutOfStock(false);
                setFormFreeDelivery(false);
                setFormImage('');
                setFormGalleryImages([]);
                setNewGalleryUrl('');
                setFormDescription('');
                setFormVariants([]);
                setNewVarLabel('');
                setNewVarPurchasePrice('');
                setNewVarRegularPrice('');
                setNewVarRetailPrice('');
                setFormCountdownEnabled(true);
                setFormCountdownHours(9);
                setFormCountdownTitle('স্পেশাল অফার শেষ হতে বাকি:');
                setFormLiveViewersEnabled(true);
                setFormSizeChartEnabled(true);
                setFormSizeChartTitle('সাইজ চার্ট ও বডির মাপ (Size Chart)');
                setFormSizeChartSubtitle('অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন');
                setFormSizeChartHeaders([...DEFAULT_LANDING_SIZE_CHART_HEADERS]);
                setFormSizeChartRows(DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r })));
                setFormSizeChartImage('');
                setFormReviewsEnabled(true);
                setFormReviewsTitle('সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ');
                setFormReviewItems([]);
                setFormRealGalleryEnabled(true);
                setFormRealGalleryTitle('আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও');
                setFormRealCustomerPhotos([]);
                setFormRealUnboxingVideoUrl('');
                setNewRevName('');
                setNewRevLocation('ঢাকা');
                setNewRevRating(5);
                setNewRevComment('');
                setShowAddModal(true);
              }}
              className="min-h-[38px] px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{language === 'bn' ? '+ ছবি ও ভ্যারিয়েশন সহ নতুন পণ্য' : '+ Add Product & Variations'}</span>
            </button>
          </div>
        </div>

        {/* Storefront Quick Toggles Panel */}
        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
          {/* 1-Click Separate Marketing Scarcity Controls: (1) Inner Product Page vs (2) Home Page Front Box "মাত্র 5 টি বাকি" */}
          {(() => {
            const isScarcityOn = currentBusiness.scarcityStockEnabled !== false;
            const isHomeScarcityOn = currentBusiness.homePageScarcityStockEnabled !== false;
            return (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isScarcityOn;
                    updateBusiness({ scarcityStockEnabled: nextState });
                    showToast(
                      nextState
                        ? 'ভিতরের প্রোডাক্ট পেজে "সীমিত স্টক / আর মাত্র X টি বাকি" দেখানো চালু (ON) করা হয়েছে!'
                        : 'ভিতরের প্রোডাক্ট পেজে "সীমিত স্টক / আর মাত্র X টি বাকি" দেখানো বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isScarcityOn
                      ? 'bg-rose-50 hover:bg-rose-100 text-rose-800 border-rose-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে ভিতরের প্রোডাক্ট পেজের সীমিত স্টক কাউন্টার আলাদাভাবে চালু বা বন্ধ করুন"
                >
                  <Flame
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isScarcityOn ? 'text-[#c30000] fill-[#c30000]' : 'text-slate-400'
                    }`}
                  />
                  <span>প্রোডাক্ট পেজে স্টক অ্যালার্ট:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isScarcityOn
                        ? 'bg-[#c30000] text-white'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isScarcityOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const nextHomeState = !isHomeScarcityOn;
                    updateBusiness({ homePageScarcityStockEnabled: nextHomeState });
                    showToast(
                      nextHomeState
                        ? 'হোমপেজ বক্সে "মাত্র ৫ টি বাকি" লেখাটি চালু (ON) করা হয়েছে!'
                        : 'হোমপেজ বক্সে "মাত্র ৫ টি বাকি" লেখাটি বন্ধ (OFF) করা হয়েছে! (ভিতরের প্রোডাক্ট পেজের স্টক আলাদা থাকবে)',
                      nextHomeState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isHomeScarcityOn
                      ? 'bg-amber-50 hover:bg-amber-100 text-amber-950 border-amber-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে হোমপেজের প্রোডাক্ট বক্সে 'মাত্র ৫ টি বাকি' লেখাটি আলাদাভাবে চালু বা বন্ধ করুন"
                >
                  <Flame
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isHomeScarcityOn ? 'text-amber-600 fill-amber-500' : 'text-slate-400'
                    }`}
                  />
                  <span>হোমপেজ বক্সে "মাত্র ৫ টি বাকি":</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isHomeScarcityOn
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isHomeScarcityOn ? 'ON' : 'OFF'}
                  </span>
                </button>
              </>
            );
          })()}

          {/* 1-Click Storefront Size/Variation Selection Warning Popup ON/OFF Toggle */}
          {(() => {
            const isVariantPopupOn = currentBusiness.requireVariantSelectionBeforeOrder !== false;
            return (
              <button
                type="button"
                onClick={() => {
                  const nextState = !isVariantPopupOn;
                  updateBusiness({ requireVariantSelectionBeforeOrder: nextState });
                  showToast(
                    nextState
                      ? 'স্টোরফ্রন্টে "সাইজ/ভ্যারিয়েশন সিলেকশন পপআপ" চালু (ON) করা হয়েছে! (সাইজ সিলেক্ট না করে অর্ডার করলে পপআপ আসবে)'
                      : 'স্টোরফ্রন্টে "সাইজ/ভ্যারিয়েশন সিলেকশন পপআপ" বন্ধ (OFF) করা হয়েছে! (ডিফল্ট ১ম সাইজ অটো-সিলেক্ট থাকবে)',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                  isVariantPopupOn
                    ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                }`}
                title="১-ক্লিকে স্টোরফ্রন্টের সাইজ সিলেকশন ওয়ার্নিং ও পপআপ চালু বা বন্ধ করুন"
              >
                <Layers
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isVariantPopupOn ? 'text-emerald-700' : 'text-slate-400'
                  }`}
                />
                <span>সাইজ সিলেকশন পপআপ:</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                    isVariantPopupOn
                      ? 'bg-emerald-700 text-white'
                      : 'bg-slate-300 text-slate-700'
                  }`}
                >
                  {isVariantPopupOn ? 'ON' : 'OFF'}
                </span>
              </button>
            );
          })()}

          {/* 1-Click Home Page Sliding Category Bar ON/OFF Toggle */}
          {(() => {
            const isHomeCategoryBarOn = currentBusiness.homeCategoryBarEnabled !== false;
            return (
              <button
                type="button"
                onClick={() => {
                  const nextState = !isHomeCategoryBarOn;
                  updateBusiness({ homeCategoryBarEnabled: nextState });
                  showToast(
                    nextState
                      ? 'হোমপেজে ক্যাটাগরি স্লাইডার দেখানো চালু (ON) করা হয়েছে!'
                      : 'হোমপেজে ক্যাটাগরি স্লাইডার বন্ধ (OFF) করা হয়েছে!',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                  isHomeCategoryBarOn
                    ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border-emerald-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                }`}
                title="হোমপেজে ক্যাটাগরি স্লাইডার শো করবে নাকি বন্ধ থাকবে তা ১-ক্লিকে ON / OFF করুন"
              >
                <FolderPlus
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isHomeCategoryBarOn ? 'text-emerald-700' : 'text-slate-400'
                  }`}
                />
                <span>হোমপেজ ক্যাটাগরি স্লাইডার:</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                    isHomeCategoryBarOn
                      ? 'bg-emerald-700 text-white'
                      : 'bg-slate-300 text-slate-700'
                  }`}
                >
                  {isHomeCategoryBarOn ? 'ON' : 'OFF'}
                </span>
              </button>
            );
          })()}

          {/* 1-Click Home Page Product Card Variations Show/Hide Toggle */}
          {(() => {
            const isHomeVariantsOn = currentBusiness.showVariantsOnHomePage !== false;
            return (
              <button
                type="button"
                onClick={() => {
                  const nextState = !isHomeVariantsOn;
                  updateBusiness({ showVariantsOnHomePage: nextState });
                  showToast(
                    nextState
                      ? 'হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন দেখানো চালু (ON) করা হয়েছে!'
                      : 'হোমপেজে প্রোডাক্টের নিচে ভ্যারিয়েশন বন্ধ (OFF) করা হয়েছে! (এখন প্রোডাক্ট পেজ ও অর্ডার পপআপ ছাড়া কোথাও ভ্যারিয়েশন দেখাবে না)',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                  isHomeVariantsOn
                    ? 'bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-300'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                }`}
                title="১-ক্লিকে হোমপেজে প্রোডাক্ট কার্ডের নিচে সাইজ ভ্যারিয়েশন চালু বা বন্ধ করুন (বন্ধ করলে শুধু প্রোডাক্ট পেজে ও পপআপে দেখাবে)"
              >
                <Ruler
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isHomeVariantsOn ? 'text-indigo-700' : 'text-slate-400'
                  }`}
                />
                <span>হোমপেজে সাইজ ভ্যারিয়েশন:</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                    isHomeVariantsOn
                      ? 'bg-indigo-700 text-white'
                      : 'bg-slate-300 text-slate-700'
                  }`}
                >
                  {isHomeVariantsOn ? 'ON' : 'OFF'}
                </span>
              </button>
            );
          })()}

          {/* 1-Click Product Page Variation Price (ON/OFF) & 4 Design Styles Switcher */}
          {(() => {
            const isVarPriceOn = currentBusiness.productPageVariantShowPrice !== false;
            const curStyle = currentBusiness.productPageVariantStyle || 'classic_inline';
            const styleList = [
              { id: 'classic_inline' as const, short: 'ডিজাইন ১ (বর্তমান)' },
              { id: 'stacked_card' as const, short: 'ডিজাইন ২ (২-লাইন বক্স)' },
              { id: 'price_badge' as const, short: 'ডিজাইন ৩ (প্রাইস ট্যাগ)' },
              { id: 'minimal_check' as const, short: 'ডিজাইন ৪ (টিক-মার্ক)' }
            ];
            const curStyleObj = styleList.find(s => s.id === curStyle) || styleList[0];
            return (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isVarPriceOn;
                    updateBusiness({ productPageVariantShowPrice: nextState });
                    showToast(
                      nextState
                        ? 'প্রোডাক্ট পেজে ভ্যারিয়েশনের সাথে দাম (Price) দেখানো চালু (ON) করা হয়েছে!'
                        : 'প্রোডাক্ট পেজে ভ্যারিয়েশনের দাম বন্ধ (OFF) করা হয়েছে (এখন শুধু সাইজ দেখাবে)!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isVarPriceOn
                      ? 'bg-teal-50 hover:bg-teal-100 text-teal-900 border-teal-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে প্রোডাক্ট পেজে সাইজ ভ্যারিয়েশনের ভেতরে দাম (৳) দেখানো চালু বা বন্ধ করুন"
                >
                  <span>ভ্যারিয়েশনে প্রাইস:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isVarPriceOn ? 'bg-teal-700 text-white' : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isVarPriceOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const idx = styleList.findIndex(s => s.id === curStyle);
                    const nextStyle = styleList[(idx + 1) % styleList.length];
                    updateBusiness({ productPageVariantStyle: nextStyle.id });
                    showToast(
                      `প্রোডাক্ট পেজ ভ্যারিয়েশন ডিজাইন: "${nextStyle.short}" সেট করা হয়েছে!`,
                      'success'
                    );
                  }}
                  className="min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 bg-white hover:bg-teal-50 text-teal-900 border border-teal-300 transition-all cursor-pointer"
                  title="১-ক্লিকে প্রোডাক্ট পেজের ভ্যারিয়েশন বাটনের ডিজাইন পরিবর্তন করুন (৪টি ডিজাইন)"
                >
                  <span>{curStyleObj.short}</span>
                </button>
              </>
            );
          })()}

          {/* 1-Click Home Page "ব্যাগে যোগ করুন" & Product Page "শপিং ব্যাগে যোগ করুন" Buttons ON/OFF */}
          {(() => {
            const isHomeBagOn = currentBusiness.showAddToBagOnHomePage !== false;
            const isProductBagOn = currentBusiness.showAddToBagOnProductPage !== false;
            return (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isHomeBagOn;
                    updateBusiness({ showAddToBagOnHomePage: nextState });
                    showToast(
                      nextState
                        ? 'হোমপেজে "+ ব্যাগে যোগ করুন" বাটন চালু (ON) করা হয়েছে!'
                        : 'হোমপেজে "+ ব্যাগে যোগ করুন" বাটন বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isHomeBagOn
                      ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে হোমপেজে প্রোডাক্টের নিচে '+ ব্যাগে যোগ করুন' বাটন চালু বা বন্ধ করুন"
                >
                  <ShoppingBag
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isHomeBagOn ? 'text-emerald-700' : 'text-slate-400'
                    }`}
                  />
                  <span>হোমপেজে ব্যাগে যোগ:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isHomeBagOn ? 'bg-emerald-700 text-white' : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isHomeBagOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isProductBagOn;
                    updateBusiness({ showAddToBagOnProductPage: nextState });
                    showToast(
                      nextState
                        ? 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন চালু (ON) করা হয়েছে!'
                        : 'প্রোডাক্ট পেজে "শপিং ব্যাগে যোগ করুন" বাটন বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isProductBagOn
                      ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে প্রোডাক্ট পেজে 'শপিং ব্যাগে যোগ করুন' বাটন চালু বা বন্ধ করুন"
                >
                  <ShoppingBag
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isProductBagOn ? 'text-[#006A4E]' : 'text-slate-400'
                    }`}
                  />
                  <span>প্রোডাক্ট পেজে শপিং ব্যাগ:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isProductBagOn ? 'bg-[#006A4E] text-white' : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isProductBagOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                {/* 3. Home Page Bottom Floating Bar ON/OFF */}
                {(() => {
                  const isHomeFloatingOn = currentBusiness.homeFloatingBarEnabled !== false;
                  return (
                    <button
                      type="button"
                      onClick={() => {
                        const nextState = !isHomeFloatingOn;
                        updateBusiness({ homeFloatingBarEnabled: nextState });
                        showToast(
                          nextState
                            ? 'হোমপেজের নিচের ফ্লোটিং বার চালু (ON) করা হয়েছে!'
                            : 'হোমপেজের নিচের ফ্লোটিং বার বন্ধ (OFF) করা হয়েছে!',
                          nextState ? 'success' : 'info'
                        );
                      }}
                      className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        isHomeFloatingOn
                          ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                      }`}
                      title="হোমপেজের নিচের ফ্লোটিং কার্ট ও প্রিভিউ বার চালু বা বন্ধ (ON / OFF) করুন"
                    >
                      <Layers
                        className={`w-3.5 h-3.5 shrink-0 ${
                          isHomeFloatingOn ? 'text-[#006A4E]' : 'text-slate-400'
                        }`}
                      />
                      <span>হোমপেজ ফ্লোটিং বার:</span>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                          isHomeFloatingOn ? 'bg-[#006A4E] text-white' : 'bg-slate-300 text-slate-700'
                        }`}
                      >
                        {isHomeFloatingOn ? 'ON' : 'OFF'}
                      </span>
                    </button>
                  );
                })()}

                {/* 4. Product Page Floating "এখনই অর্ডার করুন" Button Mode (Mobile Only / Desktop+Mobile / OFF) */}
                {(() => {
                  const isProdFloatingOn = currentBusiness.storefrontFloatingBtnEnabled !== false;
                  const isHideOnDesktop =
                    currentBusiness.storefrontFloatingBtnHideOnDesktop !== false;
                  const currentModeLabel = !isProdFloatingOn
                    ? 'একদম OFF'
                    : isHideOnDesktop
                    ? 'শুধু মোবাইলে'
                    : 'মোবাইল + ডেক্সটপ';
                  return (
                    <button
                      type="button"
                      onClick={() => {
                        if (isProdFloatingOn && isHideOnDesktop) {
                          updateBusiness({ storefrontFloatingBtnEnabled: false });
                          showToast(
                            'প্রোডাক্ট পেজের ফ্লোটিং অর্ডার বাটন একদম বন্ধ (OFF) করা হয়েছে!',
                            'info'
                          );
                        } else if (!isProdFloatingOn) {
                          updateBusiness({
                            storefrontFloatingBtnEnabled: true,
                            storefrontFloatingBtnHideOnDesktop: false
                          });
                          showToast(
                            'প্রোডাক্ট পেজের ফ্লোটিং বাটন মোবাইল ও ডেক্সটপ উভয় ভিউতে চালু করা হয়েছে!',
                            'success'
                          );
                        } else {
                          updateBusiness({
                            storefrontFloatingBtnEnabled: true,
                            storefrontFloatingBtnHideOnDesktop: true
                          });
                          showToast(
                            'প্রোডাক্ট পেজের ফ্লোটিং বাটন ডেক্সটপ থেকে হাইড করা হয়েছে (শুধু মোবাইলে দেখাবে)!',
                            'success'
                          );
                        }
                      }}
                      className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        !isProdFloatingOn
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                          : isHideOnDesktop
                          ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-300'
                      }`}
                      title="ক্লিক করে পরিবর্তন করুন: শুধু মোবাইলে (ডেক্সটপে হাইড) / একদম OFF / মোবাইল + ডেক্সটপ"
                    >
                      <ShoppingBag
                        className={`w-3.5 h-3.5 shrink-0 ${
                          !isProdFloatingOn
                            ? 'text-slate-400'
                            : isHideOnDesktop
                            ? 'text-[#006A4E]'
                            : 'text-indigo-700'
                        }`}
                      />
                      <span>প্রোডাক্ট ফ্লোটিং বাটন:</span>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                          !isProdFloatingOn
                            ? 'bg-slate-300 text-slate-700'
                            : isHideOnDesktop
                            ? 'bg-[#006A4E] text-white'
                            : 'bg-indigo-700 text-white'
                        }`}
                      >
                        {currentModeLabel}
                      </span>
                    </button>
                  );
                })()}
              </>
            );
          })()}

          {/* 1-Click Storefront Live Recent Order Notification Popup (Social Proof Toast) ON/OFF & Speed Toggle */}
          {(() => {
            const isSfSocialProofOn = currentBusiness.storefrontSocialProofEnabled !== false;
            const currentGapSec = currentBusiness.storefrontSocialProofIntervalSec ?? 16;
            return (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isSfSocialProofOn;
                    updateBusiness({ storefrontSocialProofEnabled: nextState });
                    showToast(
                      nextState
                        ? 'স্টোরফ্রন্টে রিসেন্ট সেলস পপআপ নোটিফিকেশন চালু (ON) করা হয়েছে!'
                        : 'স্টোরফ্রন্টে রিসেন্ট সেলস পপআপ নোটিফিকেশন বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isSfSocialProofOn
                      ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে স্টোরফ্রন্টের রিসেন্ট সেলস অর্ডার পপআপ নোটিফিকেশন চালু বা বন্ধ করুন"
                >
                  <Bell
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isSfSocialProofOn ? 'text-emerald-700' : 'text-slate-400'
                    }`}
                  />
                  <span>রিসেন্ট সেলস পপআপ:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isSfSocialProofOn
                        ? 'bg-emerald-700 text-white'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isSfSocialProofOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                {isSfSocialProofOn && (
                  <button
                    type="button"
                    onClick={() => {
                      const gapOptions = [5, 10, 16, 25, 40, 60];
                      const labels: Record<number, string> = {
                        5: 'ফাস্ট (৫ সে.)',
                        10: 'মিডিয়াম (১০ সে.)',
                        16: 'স্ট্যান্ডার্ড (১৬ সে.)',
                        25: '২৫ সে.',
                        40: 'স্লো (৪০ সে.)',
                        60: '১ মিনিট (৬০ সে.)'
                      };
                      const idx = gapOptions.indexOf(currentGapSec);
                      const nextGap = gapOptions[(idx + 1) % gapOptions.length];
                      updateBusiness({ storefrontSocialProofIntervalSec: nextGap });
                      showToast(
                        `রিসেন্ট সেলস পপআপ স্পিড: ${labels[nextGap] || `${nextGap} সে.`} সেট করা হয়েছে!`,
                        'info'
                      );
                    }}
                    className="min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition-all cursor-pointer"
                    title="১-ক্লিকে রিসেন্ট সেলস পপআপ আসার স্পিড পরিবর্তন করুন"
                  >
                    <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                    <span>পপআপ স্পিড: {currentGapSec} সে.</span>
                  </button>
                )}
              </>
            );
          })()}

          {/* 1-Click Global Storefront Countdown Timer */}
          {(() => {
            const isGlobalCdOn = currentBusiness.storefrontCountdownEnabled !== false;
            const curH = currentBusiness.storefrontCountdownHours ?? 8;
            const curM = currentBusiness.storefrontCountdownMinutes ?? 30;
            const curS = currentBusiness.storefrontCountdownSeconds ?? 34;
            return (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isGlobalCdOn;
                    updateBusiness({ storefrontCountdownEnabled: nextState });
                    showToast(
                      nextState
                        ? '১-ক্লিকে ওয়েবসাইটের সব প্রোডাক্টে গ্লোবাল কাউন্টডাউন টাইমার চালু (ON) করা হয়েছে!'
                        : '১-ক্লিকে ওয়েবসাইটের সব প্রোডাক্টে গ্লোবাল কাউন্টডাউন টাইমার বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isGlobalCdOn
                      ? 'bg-rose-50 hover:bg-rose-100 text-rose-900 border-rose-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে ফ্রন্ট ওয়েবসাইটের সব প্রোডাক্টে অফার কাউন্টডাউন টাইমার একসাথে চালু বা বন্ধ করুন"
                >
                  <Clock
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isGlobalCdOn ? 'text-rose-600' : 'text-slate-400'
                    }`}
                  />
                  <span>গ্লোবাল কাউন্টডাউন:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isGlobalCdOn
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isGlobalCdOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                {isGlobalCdOn && (
                  <button
                    type="button"
                    onClick={() => {
                      const presets = [
                        { h: 8, m: 30, s: 34, label: '৮ ঘণ্টা ৩০ মি. ৩৪ সে.' },
                        { h: 5, m: 42, s: 18, label: '৫ ঘণ্টা ৪২ মি. ১৮ সে.' },
                        { h: 2, m: 35, s: 47, label: '২ ঘণ্টা ৩৫ মি. ৪৭ সে.' },
                        { h: 11, m: 28, s: 19, label: '১১ ঘণ্টা ২৮ মি. ১৯ সে.' }
                      ];
                      const curIdx = presets.findIndex(
                        p => p.h === curH && p.m === curM && p.s === curS
                      );
                      const nextPreset = presets[(curIdx + 1) % presets.length];
                      updateBusiness({
                        storefrontCountdownHours: nextPreset.h,
                        storefrontCountdownMinutes: nextPreset.m,
                        storefrontCountdownSeconds: nextPreset.s,
                        storefrontCountdownResetSeed: Date.now()
                      });
                      showToast(
                        `সব প্রোডাক্টের গ্লোবাল কাউন্টডাউন টাইম: ${nextPreset.label} সেট করা হয়েছে!`,
                        'success'
                      );
                    }}
                    className="min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition-all cursor-pointer"
                    title="১-ক্লিকে সব প্রোডাক্টের গ্লোবাল রিয়েলিস্টিক কাউন্টডাউন টাইম পরিবর্তন করুন"
                  >
                    <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                    <span>
                      টাইম: {curH}ঘ:{curM}মি:{curS}সে
                    </span>
                  </button>
                )}
              </>
            );
          })()}

          {/* 1-Click Spin the Wheel ON/OFF Toggle & Stored Leads Button */}
          {(() => {
            const isSpinOn = currentBusiness.spinWheelEnabled !== false;
            return (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isSpinOn;
                    updateBusiness({ spinWheelEnabled: nextState });
                    showToast(
                      nextState
                        ? 'স্টোরফ্রন্টে "স্পিন দ্য হুইল (Spin the Wheel)" ডিসকাউন্ট হুইল চালু (ON) করা হয়েছে!'
                        : 'স্টোরফ্রন্টে "স্পিন দ্য হুইল (Spin the Wheel)" বন্ধ (OFF) করা হয়েছে!',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isSpinOn
                      ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
                  }`}
                  title="১-ক্লিকে ফ্রন্ট ওয়েবসাইটে স্পিন দ্য হুইল (Spin the Wheel) চালু বা বন্ধ করুন"
                >
                  <Gift
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isSpinOn ? 'text-amber-600' : 'text-slate-400'
                    }`}
                  />
                  <span>স্পিন দ্য হুইল:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                      isSpinOn
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isSpinOn ? 'ON' : 'OFF'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSpinModalTab('settings');
                    setShowSpinWheelLeadsModal(true);
                  }}
                  className="min-h-[36px] px-3 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition-all cursor-pointer"
                  title="স্পিন হুইলের লেখা, পুরস্কার কাস্টমাইজ করুন এবং কাস্টমার নাম্বার তালিকা দেখুন"
                >
                  <Edit className="w-3.5 h-3.5 text-emerald-700" />
                  <span>হুইল সেটিংস ও নাম্বার ({spinWheelLeads.length})</span>
                </button>
              </>
            );
          })()}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-xl overflow-x-auto">
            <button
              onClick={() => setStockStatusFilter('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                stockStatusFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              সকল স্টক ({products.length})
            </button>
            <button
              onClick={() => setStockStatusFilter('low')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                stockStatusFilter === 'low'
                  ? 'bg-white dark:bg-slate-900 text-amber-900 dark:text-amber-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              স্বল্প স্টক সতর্কতা
            </button>
            <button
              onClick={() => setStockStatusFilter('out')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                stockStatusFilter === 'out'
                  ? 'bg-white dark:bg-slate-900 text-rose-900 dark:text-rose-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              স্টক শেষ আইটেম
            </button>
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="min-h-[38px] px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 font-semibold outline-hidden"
          >
            <option value="all">সকল ক্যাটাগরি ({categories.length})</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {cat.nameBn}
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full lg:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="পণ্য, বারকোড বা এসকেইউ খুঁজুন..."
            className="w-full min-h-[38px] pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl outline-hidden text-slate-900 dark:text-slate-100"
          />
        </div>
      </div>

      {/* DESKTOP / COMPUTER VIEW: Clean Non-Overlapping Table (hidden on mobile/tablet) */}
      <div className="hidden lg:block bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 font-extrabold uppercase text-[11px]">
              <tr>
                <th className="px-4 py-3.5 min-w-[240px]">ছবি ও পণ্য বিবরণী</th>
                <th className="px-3 py-3.5 min-w-[140px]">ক্যাটাগরি, ব্র্যান্ড ও SKU</th>
                <th className="px-3 py-3.5 text-right min-w-[145px]">দর (ক্রয় / খুচরা / পাইকারি)</th>
                <th className="px-3.5 py-3.5 text-center min-w-[165px] border-l border-slate-200/70 dark:border-slate-800">
                  বর্তমান স্টক
                </th>
                <th className="px-4 py-3.5 text-center min-w-[235px] border-l border-slate-200/70 dark:border-slate-800">
                  {t.actions} (সম্পাদনা ও কন্ট্রোল)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedProducts.map((prod) => {
                const stock = prod.stockByOutlet[currentOutlet.id] ?? 0;
                const isOut = stock <= 0;
                const isLow = stock > 0 && stock <= (prod.lowStockAlert || 15);
                const catObj = categories.find(c => c.id === prod.categoryId);
                const brandObj = brands.find(b => b.id === prod.brandId);
                return (
                  <tr
                    key={prod.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors group align-middle"
                  >
                    {/* Col 1: Product Image, Name & Variants */}
                    <td className="px-4 py-3">
                      <div className="flex items-start gap-3">
                        <div
                          onClick={() => {
                            setQuickUploadProductId(prod.id);
                            quickRowUploadInputRef.current?.click();
                          }}
                          title="ক্লিক করে এই পণ্যের ছবি পরিবর্তন করুন"
                          className="w-13 h-13 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shrink-0 cursor-pointer relative group/img bg-white shadow-2xs"
                        >
                          <ProductThumbnail product={prod} imgClassName="p-1" />
                          <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center text-white">
                            <ImagePlus className="w-4 h-4" />
                          </div>
                        </div>
                        <div className="min-w-0 flex-1 max-w-[280px] xl:max-w-[340px]">
                          <p className="font-extrabold text-slate-900 dark:text-slate-100 text-xs xl:text-[13px] leading-snug line-clamp-2">
                            {prod.nameBn}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                            {prod.nameEn} · {prod.unit}
                          </p>
                          {prod.variants && prod.variants.length > 0 && (
                            <div className="flex flex-wrap items-center gap-1 mt-1.5">
                              {prod.variants.map(v => {
                                const isVarOut = Boolean(v.outOfStock);
                                return (
                                  <button
                                    key={v.id}
                                    type="button"
                                    onClick={async () => {
                                      const nextOut = !isVarOut;
                                      const updatedVariants = (prod.variants || []).map(item =>
                                        item.id === v.id ? { ...item, outOfStock: nextOut } : item
                                      );
                                      await updateProduct(prod.id, { variants: updatedVariants });
                                      showToast(
                                        nextOut
                                          ? `"${prod.nameBn}" এর "${v.label}" ভ্যারিয়েশনটি স্টক আউট (Out of Stock) করা হয়েছে!`
                                          : `"${prod.nameBn}" এর "${v.label}" ভ্যারিয়েশনটি পুনরায় ইন-স্টক (In Stock) করা হয়েছে!`,
                                        nextOut ? 'info' : 'success'
                                      );
                                    }}
                                    title={
                                      isVarOut
                                        ? 'এই ভ্যারিয়েশনটি স্টক আউট করা আছে — ক্লিক করে ইন-স্টক (In Stock) করুন'
                                        : '১-ক্লিকে এই ভ্যারিয়েশনটি ম্যানুয়ালি স্টক আউট (Out of Stock) করুন'
                                    }
                                    className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md border text-[10px] font-bold cursor-pointer transition-all ${
                                      isVarOut
                                        ? 'bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-800 line-through opacity-85 hover:opacity-100'
                                        : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                                    }`}
                                  >
                                    <span>{v.label}:</span>
                                    <span className="font-mono">৳{v.retailPrice}</span>
                                    {isVarOut && (
                                      <span className="ml-0.5 px-1 py-0.2 rounded bg-rose-600 text-white text-[8px] font-extrabold no-underline">
                                        স্টক আউট
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Col 2: Category, Brand & SKU */}
                    <td className="px-3 py-3 text-[11px] text-slate-600 dark:text-slate-300">
                      <div className="font-bold text-slate-800 dark:text-slate-200 truncate max-w-[165px]">
                        {catObj?.nameBn || 'সাধারণ পণ্য'}
                        {brandObj ? ` · ${brandObj.name}` : ''}
                      </div>
                      <div className="font-mono text-[10px] text-slate-400 truncate max-w-[165px] mt-0.5">
                        {prod.sku} · {prod.barcode}
                      </div>
                    </td>

                    {/* Col 3: Prices */}
                    <td className="px-3 py-3 text-right font-mono tabular-nums whitespace-nowrap">
                      {(() => {
                        const regP = computeDefaultRegularPrice(prod);
                        const hasDisc =
                          prod.discountPrice !== undefined
                            ? prod.discountPrice > 0 && prod.retailPrice < regP
                            : prod.retailPrice < regP;
                        return (
                          <div className="space-y-0.5">
                            <div className="flex items-center justify-end gap-1.5">
                              <span className="text-[10px] font-sans text-slate-400">খুচরা:</span>
                              <span className="font-extrabold text-emerald-700 dark:text-emerald-400 text-xs">
                                ৳{prod.retailPrice}
                              </span>
                              {hasDisc && (
                                <span className="text-[10px] text-slate-400 line-through">
                                  ৳{regP}
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-500 dark:text-slate-400">
                              ক্রয়:{' '}
                              <span className="font-semibold text-slate-700 dark:text-slate-300">
                                ৳{prod.purchasePrice}
                              </span>
                              {' · '}
                              পাইকারি:{' '}
                              <span className="font-semibold text-sky-700 dark:text-sky-400">
                                ৳{prod.wholesalePrice}
                              </span>
                            </div>
                          </div>
                        );
                      })()}
                    </td>

                    {/* Col 4: Current Stock (Cleanly Separated, Never Overlapping) */}
                    <td className="px-3.5 py-3 text-center whitespace-nowrap border-l border-slate-100 dark:border-slate-800/80">
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setAdjustingProduct(prod);
                            setStockUpdateMode('set');
                            setAdjQuantity(stock);
                            setAdjReason('নতুন স্টক আপডেট');
                          }}
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border font-mono font-extrabold text-xs tabular-nums cursor-pointer transition-all hover:scale-105 ${
                            isOut || prod.isOutOfStock
                              ? 'bg-rose-50 text-rose-700 border-rose-300 hover:bg-rose-100'
                              : isLow
                              ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                              : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                          }`}
                          title="ক্লিক করে সরাসরি স্টক পরিবর্তন বা যোগ করুন"
                        >
                          <span>
                            {stock} {prod.unit.split(' ')[0]}
                          </span>
                          <Edit className="w-3 h-3 opacity-75" />
                        </button>

                        {/* 1-Click Manual Out-of-Stock Toggle Button for Storefront */}
                        <button
                          type="button"
                          onClick={async () => {
                            const nextOut = !Boolean(prod.isOutOfStock);
                            await updateProduct(prod.id, { isOutOfStock: nextOut });
                            showToast(
                              nextOut
                                ? `"${prod.nameBn}" ম্যানুয়ালি স্টক আউট (Out of Stock) করে রাখা হয়েছে!`
                                : `"${prod.nameBn}" পুনরায় ইন-স্টক (In Stock) করা হয়েছে!`,
                              nextOut ? 'info' : 'success'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                            prod.isOutOfStock
                              ? 'bg-rose-600 text-white border-rose-700 hover:bg-rose-700 shadow-2xs'
                              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-rose-400 hover:text-rose-600'
                          }`}
                          title="স্টোরফ্রন্টে এই পণ্যটি ১-ক্লিকে ম্যানুয়ালি স্টক আউট (Out of Stock) বা ইন-স্টক রাখুন"
                        >
                          {prod.isOutOfStock ? '🚫 স্টক আউট (চালু করুন)' : '✓ স্টকে আছে (আউট করুন)'}
                        </button>

                        {isLow && !prod.isOutOfStock && (
                          <span className="text-[10px] text-amber-600 font-bold">স্বল্প স্টক</span>
                        )}
                        {isOut && !prod.isOutOfStock && (
                          <span className="text-[10px] text-rose-600 font-bold">স্টক শূন্য</span>
                        )}
                      </div>
                    </td>

                    {/* Col 5: Actions (Non-sticky so it never overlaps Current Stock) */}
                    <td className="px-4 py-3 border-l border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-800/20">
                      <div className="flex flex-col items-center justify-center gap-1.5 min-w-[225px]">
                        {/* Row 1: Primary Product Actions (Edit, Photo, Stock Update, Delete) */}
                        <div className="flex items-center justify-center gap-1.5 w-full">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(prod)}
                            className="px-2.5 py-1.5 text-[11px] font-extrabold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1 shadow-2xs cursor-pointer transition-colors"
                            title="পণ্য সম্পাদনা (Edit Product)"
                          >
                            <Edit className="w-3.5 h-3.5" />
                            <span>এডিট</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setQuickUploadProductId(prod.id);
                              quickRowUploadInputRef.current?.click();
                            }}
                            className="px-2.5 py-1.5 text-[11px] font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                            title="সরাসরি ছবি আপলোড করুন"
                          >
                            <ImagePlus className="w-3.5 h-3.5" />
                            <span>ছবি</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setAdjustingProduct(prod);
                              setStockUpdateMode('set');
                              setAdjQuantity(stock);
                              setAdjReason('নতুন স্টক আপডেট');
                            }}
                            className="px-2.5 py-1.5 text-[11px] font-extrabold text-indigo-800 dark:text-indigo-200 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 border border-indigo-200 dark:border-indigo-800 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                            title="স্টক আপডেট / যোগ-বিয়োগ করুন"
                          >
                            <Package className="w-3.5 h-3.5" />
                            <span>স্টক</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteProduct(prod.id)}
                            className="px-2.5 py-1.5 text-[11px] font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 border border-rose-200 dark:border-rose-800 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                            title="পণ্য ডিলিট করুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>ডিলিট</span>
                          </button>
                        </div>

                        {/* Row 2: Marketing Controls (Offer Timer & Live Viewer Toggles) */}
                        <div className="flex items-center justify-center gap-1.5 w-full">
                          <button
                            type="button"
                            onClick={async () => {
                              const nextTimerOn = prod.landingCountdownEnabled === false;
                              await updateProduct(prod.id, {
                                landingCountdownEnabled: nextTimerOn
                              });
                              showToast(
                                nextTimerOn
                                  ? `"${prod.nameBn}" পণ্যে অফার কাউন্টডাউন টাইমার চালু (ON) করা হয়েছে!`
                                  : `"${prod.nameBn}" পণ্যে অফার কাউন্টডাউন টাইমার বন্ধ (OFF) করা হয়েছে!`,
                                nextTimerOn ? 'success' : 'info'
                              );
                            }}
                            className={`px-2.5 py-1 text-[10px] font-bold rounded-lg flex items-center gap-1 border cursor-pointer transition-colors ${
                              prod.landingCountdownEnabled !== false
                                ? 'text-rose-800 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 border-rose-200 dark:border-rose-800'
                                : 'text-slate-500 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 border-slate-300 dark:border-slate-700'
                            }`}
                            title="১-ক্লিকে এই পণ্যের পেজে অফার কাউন্টডাউন টাইমার চালু বা বন্ধ করুন"
                          >
                            <Clock className="w-3 h-3" />
                            <span>টাইমার: {prod.landingCountdownEnabled !== false ? 'ON' : 'OFF'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              const nextViewersOn = prod.landingLiveViewersEnabled === false;
                              await updateProduct(prod.id, {
                                landingLiveViewersEnabled: nextViewersOn
                              });
                              showToast(
                                nextViewersOn
                                  ? `"${prod.nameBn}" পণ্যে লাইভ ভিউয়ার কাউন্টার (12-48) চালু (ON) করা হয়েছে!`
                                  : `"${prod.nameBn}" পণ্যে লাইভ ভিউয়ার কাউন্টার বন্ধ (OFF) করা হয়েছে!`,
                                nextViewersOn ? 'success' : 'info'
                              );
                            }}
                            className={`px-2.5 py-1 text-[10px] font-bold rounded-lg flex items-center gap-1 border cursor-pointer transition-colors ${
                              prod.landingLiveViewersEnabled !== false
                                ? 'text-amber-900 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 border-amber-200 dark:border-amber-800'
                                : 'text-slate-500 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 border-slate-300 dark:border-slate-700'
                            }`}
                            title="১-ক্লিকে এই পণ্যের পেজে 'People currently viewing this product' কাউন্টার চালু বা বন্ধ করুন"
                          >
                            <Eye className="w-3 h-3" />
                            <span>ভিউয়ার: {prod.landingLiveViewersEnabled !== false ? 'ON' : 'OFF'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              const nextFree = !Boolean(prod.freeDelivery || prod.freeDeliveryOnLanding);
                              await updateProduct(prod.id, {
                                freeDelivery: nextFree,
                                freeDeliveryOnLanding: nextFree
                              });
                              showToast(
                                nextFree
                                  ? `🚚 "${prod.nameBn}" পণ্যে আলাদা ফ্রি ডেলিভারি ব্যাজ ও অফার চালু (ON) করা হয়েছে!`
                                  : `"${prod.nameBn}" পণ্যে আলাদা ফ্রি ডেলিভারি বন্ধ (OFF) করা হয়েছে!`,
                                nextFree ? 'success' : 'info'
                              );
                            }}
                            className={`px-2.5 py-1 text-[10px] font-bold rounded-lg flex items-center gap-1 border cursor-pointer transition-colors ${
                              prod.freeDelivery || prod.freeDeliveryOnLanding
                                ? 'text-emerald-900 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/60 hover:bg-emerald-200 border-emerald-300 dark:border-emerald-800'
                                : 'text-slate-500 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 border-slate-300 dark:border-slate-700'
                            }`}
                            title="১-ক্লিকে এই পণ্যে আলাদা ফ্রি ডেলিভারি (Product-Specific Free Delivery) চালু বা বন্ধ করুন"
                          >
                            <span>🚚 ফ্রি ডেলিভারি: {prod.freeDelivery || prod.freeDeliveryOnLanding ? 'ON ✓' : 'OFF'}</span>
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* MOBILE & TABLET VIEW: Responsive Product Cards (Zero Overlap, Clean Stacked Layout) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 lg:hidden">
        {paginatedProducts.map((prod) => {
          const stock = prod.stockByOutlet[currentOutlet.id] ?? 0;
          const isOut = stock <= 0;
          const isLow = stock > 0 && stock <= (prod.lowStockAlert || 15);
          const catObj = categories.find(c => c.id === prod.categoryId);
          const brandObj = brands.find(b => b.id === prod.brandId);
          const regP = computeDefaultRegularPrice(prod);
          const hasDisc =
            prod.discountPrice !== undefined
              ? prod.discountPrice > 0 && prod.retailPrice < regP
              : prod.retailPrice < regP;

          return (
            <div
              key={prod.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-3.5 shadow-2xs space-y-3"
            >
              {/* Top Section: Image + Name + Category + Prices */}
              <div className="flex items-start gap-3">
                <div
                  onClick={() => {
                    setQuickUploadProductId(prod.id);
                    quickRowUploadInputRef.current?.click();
                  }}
                  title="ক্লিক করে এই পণ্যের ছবি পরিবর্তন করুন"
                  className="w-16 h-16 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shrink-0 cursor-pointer relative group/img bg-white shadow-2xs"
                >
                  <ProductThumbnail product={prod} imgClassName="p-1" />
                  <div className="absolute inset-0 bg-slate-900/50 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center text-white">
                    <ImagePlus className="w-4 h-4" />
                  </div>
                </div>

                <div className="min-w-0 flex-1 space-y-1">
                  <p className="font-extrabold text-slate-900 dark:text-slate-100 text-xs sm:text-sm leading-snug line-clamp-2">
                    {prod.nameBn}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {catObj?.nameBn || 'সাধারণ পণ্য'}
                    {brandObj ? ` · ${brandObj.name}` : ''} · <span className="font-mono">{prod.sku}</span>
                  </p>

                  {/* Price Row */}
                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 pt-0.5 font-mono text-xs">
                    <div className="flex items-center gap-1">
                      <span className="font-sans text-[10px] text-slate-500">খুচরা:</span>
                      <span className="font-extrabold text-emerald-700 dark:text-emerald-400">
                        ৳{prod.retailPrice}
                      </span>
                      {hasDisc && (
                        <span className="text-[10px] text-slate-400 line-through">৳{regP}</span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">
                      ক্রয়: <strong className="text-slate-700 dark:text-slate-200">৳{prod.purchasePrice}</strong>
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">
                      পাইকারি: <strong className="text-sky-700 dark:text-sky-400">৳{prod.wholesalePrice}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Variants Section (if any) */}
              {prod.variants && prod.variants.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100 dark:border-slate-800">
                  {prod.variants.map(v => {
                    const isVarOut = Boolean(v.outOfStock);
                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={async () => {
                          const nextOut = !isVarOut;
                          const updatedVariants = (prod.variants || []).map(item =>
                            item.id === v.id ? { ...item, outOfStock: nextOut } : item
                          );
                          await updateProduct(prod.id, { variants: updatedVariants });
                          showToast(
                            nextOut
                              ? `"${prod.nameBn}" এর "${v.label}" ভ্যারিয়েশনটি স্টক আউট করা হয়েছে!`
                              : `"${prod.nameBn}" এর "${v.label}" ভ্যারিয়েশনটি ইন-স্টক করা হয়েছে!`,
                            nextOut ? 'info' : 'success'
                          );
                        }}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[10px] font-bold cursor-pointer transition-all ${
                          isVarOut
                            ? 'bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-800 line-through'
                            : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                        }`}
                      >
                        <span>{v.label}:</span>
                        <span className="font-mono">৳{v.retailPrice}</span>
                        {isVarOut && (
                          <span className="ml-0.5 px-1 py-0.2 rounded bg-rose-600 text-white text-[8px] font-extrabold no-underline">
                            আউট
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Dedicated Current Stock Box (Separate from Actions) */}
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
                    বর্তমান স্টক:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setAdjustingProduct(prod);
                      setStockUpdateMode('set');
                      setAdjQuantity(stock);
                      setAdjReason('নতুন স্টক আপডেট');
                    }}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border font-mono font-extrabold text-xs tabular-nums cursor-pointer ${
                      isOut || prod.isOutOfStock
                        ? 'bg-rose-50 text-rose-700 border-rose-300'
                        : isLow
                        ? 'bg-amber-50 text-amber-800 border-amber-300'
                        : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                    }`}
                  >
                    <span>
                      {stock} {prod.unit.split(' ')[0]}
                    </span>
                    <Edit className="w-3 h-3 opacity-75" />
                  </button>
                  {isLow && !prod.isOutOfStock && (
                    <span className="text-[10px] text-amber-600 font-bold">স্বল্প স্টক</span>
                  )}
                  {isOut && !prod.isOutOfStock && (
                    <span className="text-[10px] text-rose-600 font-bold">স্টক শূন্য</span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={async () => {
                    const nextOut = !Boolean(prod.isOutOfStock);
                    await updateProduct(prod.id, { isOutOfStock: nextOut });
                    showToast(
                      nextOut
                        ? `"${prod.nameBn}" ম্যানুয়ালি স্টক আউট করে রাখা হয়েছে!`
                        : `"${prod.nameBn}" পুনরায় ইন-স্টক করা হয়েছে!`,
                      nextOut ? 'info' : 'success'
                    );
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                    prod.isOutOfStock
                      ? 'bg-rose-600 text-white border-rose-700'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  {prod.isOutOfStock ? '🚫 স্টক আউট (চালু করুন)' : '✓ স্টকে আছে (আউট করুন)'}
                </button>
              </div>

              {/* Dedicated Actions (সম্পাদনা ও কন্ট্রোল) Footer Box */}
              <div className="space-y-1.5 pt-0.5">
                <div className="grid grid-cols-4 gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(prod)}
                    className="min-h-[34px] px-2 py-1.5 text-[11px] font-extrabold text-white bg-blue-600 hover:bg-blue-700 rounded-xl flex items-center justify-center gap-1 shadow-2xs cursor-pointer"
                  >
                    <Edit className="w-3.5 h-3.5 shrink-0" />
                    <span>এডিট</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickUploadProductId(prod.id);
                      quickRowUploadInputRef.current?.click();
                    }}
                    className="min-h-[34px] px-2 py-1.5 text-[11px] font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <ImagePlus className="w-3.5 h-3.5 shrink-0" />
                    <span>ছবি</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAdjustingProduct(prod);
                      setStockUpdateMode('set');
                      setAdjQuantity(stock);
                      setAdjReason('নতুন স্টক আপডেট');
                    }}
                    className="min-h-[34px] px-2 py-1.5 text-[11px] font-extrabold text-indigo-800 dark:text-indigo-200 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 border border-indigo-200 dark:border-indigo-800 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Package className="w-3.5 h-3.5 shrink-0" />
                    <span>স্টক</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteProduct(prod.id)}
                    className="min-h-[34px] px-2 py-1.5 text-[11px] font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5 shrink-0" />
                    <span>ডিলিট</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={async () => {
                      const nextTimerOn = prod.landingCountdownEnabled === false;
                      await updateProduct(prod.id, {
                        landingCountdownEnabled: nextTimerOn
                      });
                      showToast(
                        nextTimerOn
                          ? `"${prod.nameBn}" পণ্যে অফার টাইমার চালু (ON) করা হয়েছে!`
                          : `"${prod.nameBn}" পণ্যে অফার টাইমার বন্ধ (OFF) করা হয়েছে!`,
                        nextTimerOn ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[30px] px-2.5 py-1 text-[10px] font-bold rounded-xl flex items-center justify-center gap-1 border cursor-pointer transition-colors ${
                      prod.landingCountdownEnabled !== false
                        ? 'text-rose-800 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800'
                        : 'text-slate-500 bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <Clock className="w-3 h-3 shrink-0" />
                    <span>টাইমার: {prod.landingCountdownEnabled !== false ? 'ON' : 'OFF'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const nextViewersOn = prod.landingLiveViewersEnabled === false;
                      await updateProduct(prod.id, {
                        landingLiveViewersEnabled: nextViewersOn
                      });
                      showToast(
                        nextViewersOn
                          ? `"${prod.nameBn}" পণ্যে লাইভ ভিউয়ার চালু (ON) করা হয়েছে!`
                          : `"${prod.nameBn}" পণ্যে লাইভ ভিউয়ার বন্ধ (OFF) করা হয়েছে!`,
                        nextViewersOn ? 'success' : 'info'
                      );
                    }}
                    className={`min-h-[30px] px-2.5 py-1 text-[10px] font-bold rounded-xl flex items-center justify-center gap-1 border cursor-pointer transition-colors ${
                      prod.landingLiveViewersEnabled !== false
                        ? 'text-amber-900 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800'
                        : 'text-slate-500 bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <Eye className="w-3 h-3 shrink-0" />
                    <span>ভিউয়ার: {prod.landingLiveViewersEnabled !== false ? 'ON' : 'OFF'}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredProducts.length > PRODUCTS_PER_PAGE && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs shadow-2xs">
          <p className="text-slate-600 dark:text-slate-300 font-semibold">
            মোট <span className="font-mono font-bold text-slate-900 dark:text-white">{filteredProducts.length}</span> টি পণ্যের মধ্যে{' '}
            <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
              {(safeProductPage - 1) * PRODUCTS_PER_PAGE + 1}–
              {Math.min(safeProductPage * PRODUCTS_PER_PAGE, filteredProducts.length)}
            </span>{' '}
            দেখানো হচ্ছে (প্রতি পেজে ৫০টি পণ্য)
          </p>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={safeProductPage <= 1}
              onClick={() => setProductPage(p => Math.max(1, p - 1))}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 font-bold disabled:opacity-40 cursor-pointer"
            >
              ← আগের পেজ
            </button>
            <span className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-mono font-bold">
              পেজ {safeProductPage} / {totalProductPages}
            </span>
            <button
              type="button"
              disabled={safeProductPage >= totalProductPages}
              onClick={() => setProductPage(p => Math.min(totalProductPages, p + 1))}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 font-bold disabled:opacity-40 cursor-pointer"
            >
              পরের পেজ →
            </button>
          </div>
        </div>
      )}

      {/* Category & Brand Add / Delete Manager Modal */}
      {showCatalogManagerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-5 sm:p-6 border border-slate-200 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h2 className="font-bold text-base sm:text-lg text-slate-900">
                  ক্যাটাগরি এবং ব্র্যান্ড ম্যানেজার (Add & Delete)
                </h2>
                <p className="text-[11px] text-slate-500">
                  নতুন ক্যাটাগরি বা ব্র্যান্ড যোগ করুন অথবা অপ্রয়োজনীয় ক্যাটাগরি/ব্র্যান্ড ডিলিট করুন
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowCatalogManagerModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tab Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl mt-4">
              <button
                type="button"
                onClick={() => setCatalogManagerTab('categories')}
                className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  catalogManagerTab === 'categories'
                    ? 'bg-emerald-700 text-white shadow-2xs'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                <FolderPlus className="w-4 h-4" />
                <span>ক্যাটাগরি সমূহ ({categories.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setCatalogManagerTab('brands')}
                className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  catalogManagerTab === 'brands'
                    ? 'bg-blue-700 text-white shadow-2xs'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                <Tag className="w-4 h-4" />
                <span>ব্র্যান্ড সমূহ ({brands.length})</span>
              </button>
            </div>

            {/* Tab 1: Categories Add, Image Upload & Home Page Show/Hide */}
            {catalogManagerTab === 'categories' && (
              <div className="mt-4 space-y-3.5 text-xs">
                {/* Master ON/OFF Switch, Auto-Slide Toggle & 5 Category Slider Designs */}
                {(() => {
                  const isHomeCatBarOn = currentBusiness.homeCategoryBarEnabled !== false;
                  const isAutoSlideOn = currentBusiness.homeCategoryAutoSlide !== false;
                  const activeCatDesign: HomeCategoryBarDesign =
                    currentBusiness.homeCategoryBarDesign || 'large_poster_2col';

                  const catDesignOptions: Array<{
                    id: HomeCategoryBarDesign;
                    label: string;
                    desc: string;
                  }> = [
                    {
                      id: 'large_poster_2col',
                      label: '১. বড় ইমেজ পোস্টার (মোবাইলে ২টা করে)',
                      desc: 'বড় ছবি + নিচে গ্লাস ব্যাজে নাম (২ কলাম স্লাইডার)'
                    },
                    {
                      id: 'pure_image_card',
                      label: '২. শুধু বড় ছবি (Pure Image Only)',
                      desc: 'কোনো লেখা ছাড়া শুধু বড় ক্যাটাগরি ছবি (মোবাইলে ২টা করে)'
                    },
                    {
                      id: 'modern_grid_card',
                      label: '৩. মডার্ন ফ্যাশন বক্স (২ কলাম কার্ড)',
                      desc: 'উপরে বড় ছবি ও নিচে ক্লিন টাইটেল বার'
                    },
                    {
                      id: 'circle_story',
                      label: '৪. গোল স্টোরি রিং (Circle Avatar)',
                      desc: 'বড় গোল ছবির রিং ও নিচে ক্যাটাগরির নাম'
                    },
                    {
                      id: 'compact_pill',
                      label: '৫. কম্প্যাক্ট সিম্পল পিল (আগের ডিজাইন)',
                      desc: 'ছোট ছবি ও নামের সিম্পল বাটন স্লাইডার'
                    }
                  ];

                  return (
                    <div
                      className={`p-3 rounded-xl border space-y-2.5 transition-all ${
                        isHomeCatBarOn
                          ? 'bg-emerald-50/90 border-emerald-300'
                          : 'bg-slate-100 border-slate-300'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="space-y-0.5">
                          <p className="font-extrabold text-slate-900 flex items-center gap-1.5 flex-wrap">
                            <span>🏠 হোমপেজ ক্যাটাগরি স্লাইডার ও ডিজাইন</span>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                                isHomeCatBarOn
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-rose-600 text-white'
                              }`}
                            >
                              {isHomeCatBarOn ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                            </span>
                          </p>
                          <p className="text-[11px] text-slate-600">
                            মোবাইলে প্রোডাক্টের মতো ২টা করে বড় ছবির অটো-স্মুথ স্লাইডার ও ৫টি প্রিমিয়াম ডিজাইন
                          </p>
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5">
                          {/* Auto Smooth Slider ON/OFF */}
                          <button
                            type="button"
                            onClick={() => {
                              const nextAuto = !isAutoSlideOn;
                              updateBusiness({ homeCategoryAutoSlide: nextAuto });
                              showToast(
                                nextAuto
                                  ? 'ক্যাটাগরি অটো স্মুথ স্লাইডার চালু (ON) করা হয়েছে!'
                                  : 'ক্যাটাগরি অটো স্লাইড বন্ধ (OFF) করা হয়েছে (হাতে টেনে স্লাইড করা যাবে)!',
                                nextAuto ? 'success' : 'info'
                              );
                            }}
                            className={`min-h-[34px] px-2.5 py-1 rounded-xl font-extrabold text-[11px] flex items-center gap-1.5 cursor-pointer border transition-all ${
                              isAutoSlideOn
                                ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-600 shadow-2xs'
                                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300'
                            }`}
                          >
                            <span>🔄 অটো স্লাইড: {isAutoSlideOn ? 'ON' : 'OFF'}</span>
                          </button>

                          {/* Master ON/OFF */}
                          <button
                            type="button"
                            onClick={() => {
                              const nextVal = !isHomeCatBarOn;
                              updateBusiness({ homeCategoryBarEnabled: nextVal });
                              showToast(
                                nextVal
                                  ? 'হোমপেজে ক্যাটাগরি স্লাইডার চালু (ON) করা হয়েছে!'
                                  : 'হোমপেজে ক্যাটাগরি স্লাইডার বন্ধ (OFF) করা হয়েছে!',
                                nextVal ? 'success' : 'info'
                              );
                            }}
                            className={`min-h-[34px] px-3 py-1 rounded-xl font-extrabold text-[11px] flex items-center gap-1.5 cursor-pointer transition-all shrink-0 shadow-2xs ${
                              isHomeCatBarOn
                                ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                                : 'bg-slate-800 hover:bg-slate-900 text-white'
                            }`}
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                isHomeCatBarOn ? 'bg-emerald-300 animate-pulse' : 'bg-rose-400'
                              }`}
                            />
                            <span>{isHomeCatBarOn ? 'স্লাইডার: ON' : 'স্লাইডার: OFF'}</span>
                          </button>
                        </div>
                      </div>

                      {/* 5 Design Style Buttons */}
                      <div className="pt-2 border-t border-emerald-200/80">
                        <p className="text-[11px] font-extrabold text-emerald-950 mb-1.5">
                          🎨 ক্যাটাগরি স্লাইডার ডিজাইন পরিবর্তন করুন (৫টি স্টাইল):
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                          {catDesignOptions.map(opt => {
                            const isSelected = activeCatDesign === opt.id;
                            return (
                              <button
                                key={opt.id}
                                type="button"
                                onClick={() => {
                                  updateBusiness({
                                    homeCategoryBarEnabled: true,
                                    homeCategoryBarDesign: opt.id
                                  });
                                  showToast(`ক্যাটাগরি ডিজাইন "${opt.label}" সেট করা হয়েছে!`, 'success');
                                }}
                                className={`p-2 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-2 ${
                                  isSelected
                                    ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                                    : 'bg-white hover:bg-emerald-50/60 text-slate-800 border-slate-200'
                                }`}
                              >
                                <div className="min-w-0">
                                  <p className="text-[11px] font-extrabold leading-tight truncate">
                                    {opt.label}
                                  </p>
                                  <p
                                    className={`text-[10px] leading-snug mt-0.5 ${
                                      isSelected ? 'text-emerald-100' : 'text-slate-500'
                                    }`}
                                  >
                                    {opt.desc}
                                  </p>
                                </div>
                                {isSelected && (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0 mt-0.5" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                <form
                  onSubmit={handleAddCategorySubmit}
                  className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-extrabold text-emerald-950">+ নতুন ক্যাটাগরি ও ছবি যুক্ত করুন:</p>

                    {/* Per-Category Show on Home Toggle in Create Form */}
                    <button
                      type="button"
                      onClick={() => setNewCatShowOnHome(prev => !prev)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border flex items-center gap-1.5 cursor-pointer transition-all ${
                        newCatShowOnHome
                          ? 'bg-emerald-700 text-white border-emerald-800'
                          : 'bg-white text-slate-600 border-slate-300'
                      }`}
                      title="এই নতুন ক্যাটাগরিটি হোমপেজে দেখাবে কি না তা ঠিক করুন"
                    >
                      <span>হোমপেজে শো: {newCatShowOnHome ? 'ON' : 'OFF'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      required
                      value={newCatNameBn}
                      onChange={(e) => setNewCatNameBn(e.target.value)}
                      placeholder="ক্যাটাগরির নাম (বাংলা) উদা: বেবি ফ্রক *"
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 outline-hidden"
                    />
                    <input
                      type="text"
                      value={newCatNameEn}
                      onChange={(e) => setNewCatNameEn(e.target.value)}
                      placeholder="ইংরেজি নাম (ঐচ্ছিক) উদা: Baby Frock"
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 outline-hidden"
                    />
                  </div>

                  {/* Category Image Upload & URL Row */}
                  <div className="p-2.5 rounded-xl bg-white border border-emerald-200/90 flex flex-col sm:flex-row sm:items-center gap-2.5">
                    <input
                      ref={newCatImageInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleNewCatImageUpload}
                      className="hidden"
                    />

                    <div className="flex items-center gap-2.5 shrink-0">
                      <div className="w-12 h-12 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                        {newCatImage ? (
                          <img
                            src={newCatImage}
                            alt="Category Preview"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Camera className="w-5 h-5 text-slate-400" />
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => newCatImageInputRef.current?.click()}
                        disabled={isProcessingImage}
                        className="min-h-[36px] px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-950 border border-emerald-300 rounded-lg font-extrabold text-[11px] flex items-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <Upload className="w-3.5 h-3.5 text-emerald-700" />
                        <span>{newCatImage ? 'ছবি পরিবর্তন করুন' : 'ক্যাটাগরির ছবি আপলোড'}</span>
                      </button>

                      {newCatImage && (
                        <button
                          type="button"
                          onClick={() => setNewCatImage('')}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                          title="ছবি মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <input
                      type="text"
                      value={newCatImage.startsWith('data:') ? '' : newCatImage}
                      onChange={(e) => setNewCatImage(e.target.value)}
                      placeholder="অথবা ছবির লিংক (URL) দিন (ঐচ্ছিক)"
                      className="w-full min-h-[36px] px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-[11px] text-slate-800 outline-hidden"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full min-h-[38px] py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>নতুন ক্যাটাগরি যোগ করুন</span>
                  </button>
                </form>

                <div className="space-y-1.5 max-h-72 overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-xl p-2">
                  {categories.length === 0 ? (
                    <p className="text-center py-6 text-slate-400">কোনো ক্যাটাগরি নেই</p>
                  ) : (
                    categories.map(cat => {
                      const catProducts = products.filter(p => !p.isLandingPageProduct && p.categoryId === cat.id);
                      const prodCount = products.filter(p => p.categoryId === cat.id).length;
                      const fallbackProdWithImage = catProducts.find(p => p.image) || catProducts[0];
                      const isCatVisibleOnHome = cat.showOnHome !== false;

                      return (
                        <div
                          key={cat.id}
                          className="py-2.5 px-2.5 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2.5 hover:bg-slate-50 rounded-lg"
                        >
                          <div className="flex items-center gap-2.5 min-w-0 flex-1">
                            {/* Category Image Preview Thumbnail */}
                            <div className="w-11 h-11 rounded-xl border border-slate-200 bg-white overflow-hidden flex items-center justify-center shrink-0 relative group">
                              {cat.image ? (
                                <img
                                  src={cat.image}
                                  alt={cat.nameBn}
                                  className="w-full h-full object-cover"
                                />
                              ) : fallbackProdWithImage ? (
                                <ProductThumbnail
                                  product={fallbackProdWithImage}
                                  className="w-full h-full"
                                  imgClassName="p-0.5 object-cover"
                                />
                              ) : (
                                <FolderPlus className="w-5 h-5 text-emerald-600" />
                              )}
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <p className="font-bold text-slate-900 truncate">{cat.nameBn}</p>
                                <span
                                  className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold ${
                                    isCatVisibleOnHome
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-slate-200 text-slate-600'
                                  }`}
                                >
                                  {isCatVisibleOnHome ? 'হোমপেজে: ON' : 'হোমপেজে: OFF'}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500 truncate">
                                {cat.nameEn} · পণ্য: <strong>{prodCount} টি</strong>
                                {cat.image ? ' · কাস্টম ছবি যুক্ত' : ' · অটো প্রোডাক্ট ছবি'}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {/* 1-Click Upload / Change Category Image */}
                            <button
                              type="button"
                              onClick={() => {
                                setQuickUploadCategoryId(cat.id);
                                quickCatUploadInputRef.current?.click();
                              }}
                              className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold rounded-lg flex items-center gap-1 cursor-pointer text-[11px]"
                              title="এই ক্যাটাগরির জন্য ছবি আপলোড বা পরিবর্তন করুন"
                            >
                              <Camera className="w-3.5 h-3.5 text-emerald-700" />
                              <span>{cat.image ? 'ছবি বদলান' : 'ছবি দিন'}</span>
                            </button>

                            {cat.image && (
                              <button
                                type="button"
                                onClick={() => {
                                  updateCategory(cat.id, { image: undefined });
                                  showToast(`"${cat.nameBn}"-এর কাস্টম ছবি সরানো হয়েছে`, 'info');
                                }}
                                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200 rounded-lg cursor-pointer"
                                title="কাস্টম ছবি মুছে ফেলুন"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* 1-Click Per-Category Show on Home ON/OFF Toggle */}
                            <button
                              type="button"
                              onClick={() => {
                                const nextShow = !isCatVisibleOnHome;
                                updateCategory(cat.id, { showOnHome: nextShow });
                                showToast(
                                  nextShow
                                    ? `"${cat.nameBn}" ক্যাটাগরিটি হোমপেজে দেখানো চালু (ON) করা হয়েছে!`
                                    : `"${cat.nameBn}" ক্যাটাগরিটি হোমপেজ থেকে হাইড (OFF) করা হয়েছে!`,
                                  nextShow ? 'success' : 'info'
                                );
                              }}
                              className={`px-2.5 py-1.5 font-extrabold rounded-lg border flex items-center gap-1 cursor-pointer text-[11px] transition-all ${
                                isCatVisibleOnHome
                                  ? 'bg-emerald-700 text-white border-emerald-800'
                                  : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                              }`}
                              title="এই ক্যাটাগরিটি হোমপেজে স্লাইডারে দেখাবে কি না তা ON / OFF করুন"
                            >
                              <span>{isCatVisibleOnHome ? 'হোম: ON' : 'হোম: OFF'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => deleteCategory(cat.id)}
                              className="px-2 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-lg flex items-center gap-1 cursor-pointer shrink-0"
                              title="ক্যাটাগরি ডিলিট করুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* Tab 2: Brands Add & Delete */}
            {catalogManagerTab === 'brands' && (
              <div className="mt-4 space-y-4 text-xs">
                <form
                  onSubmit={handleAddBrandSubmit}
                  className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-2.5"
                >
                  <p className="font-bold text-blue-950">+ নতুন ব্র্যান্ড / কোম্পানি যুক্ত করুন:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      required
                      value={newBrandName}
                      onChange={(e) => setNewBrandName(e.target.value)}
                      placeholder="ব্র্যান্ডের নাম (উদা: প্রাণ / বসুন্ধরা / ইউনিলিভার) *"
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 outline-hidden"
                    />
                    <input
                      type="text"
                      value={newBrandOrigin}
                      onChange={(e) => setNewBrandOrigin(e.target.value)}
                      placeholder="দেশ / অরিজিন (উদা: বাংলাদেশ)"
                      className="w-full min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 outline-hidden"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full min-h-[38px] py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>নতুন ব্র্যান্ড যোগ করুন</span>
                  </button>
                </form>

                <div className="space-y-1.5 max-h-64 overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-xl p-2">
                  {brands.length === 0 ? (
                    <p className="text-center py-6 text-slate-400">কোনো ব্র্যান্ড নেই</p>
                  ) : (
                    brands.map(brand => {
                      const prodCount = products.filter(p => p.brandId === brand.id).length;
                      return (
                        <div
                          key={brand.id}
                          className="py-2 px-2.5 flex items-center justify-between gap-2 hover:bg-slate-50 rounded-lg"
                        >
                          <div>
                            <p className="font-bold text-slate-900">{brand.name}</p>
                            <p className="text-[11px] text-slate-500">
                              অরিজিন: {brand.origin} · এই ব্র্যান্ডের পণ্য: <strong>{prodCount} টি</strong>
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => deleteBrand(brand.id)}
                            className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-lg flex items-center gap-1 cursor-pointer shrink-0"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>ডিলিট</span>
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            <div className="mt-4 pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setShowCatalogManagerModal(false)}
                className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                সম্পন্ন (বন্ধ করুন)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal (Wide Desktop Layout + 100% Mobile Responsive) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-1.5 sm:p-4 lg:p-6 bg-slate-900/65 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl shadow-2xl max-w-5xl xl:max-w-6xl w-full border border-slate-200 dark:border-slate-800 my-auto max-h-[96vh] sm:max-h-[92vh] flex flex-col overflow-hidden">
            {/* Sticky Modal Header */}
            <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-4 py-3.5 sm:px-6 sm:py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
              <div className="min-w-0">
                <h2 className="font-extrabold text-base sm:text-lg lg:text-xl text-slate-900 dark:text-slate-100 truncate">
                  {editingProduct ? 'পণ্য ও ভ্যারিয়েশন সম্পাদনা করুন (Edit Product)' : 'নতুন পণ্য, ছবি ও ভ্যারিয়েশন যুক্ত করুন (+ Add Product & Variations)'}
                </h2>
                <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 truncate">
                  এখানে যোগ করা পণ্য, ছবি ও ভ্যারিয়েশন সাথে সাথে ই-কমার্স ওয়েবসাইট এবং পিওএস কাউন্টারে যুক্ত হবে
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer shrink-0 transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex-1 overflow-y-auto p-3.5 sm:p-6 lg:p-7 space-y-5 text-xs">
              {/* Top Row on Desktop: Main Product Photo + Multi-Image Gallery Side-by-Side */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                {/* Product Main Photo Upload Box */}
                <div className="lg:col-span-6 p-3.5 sm:p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-28 h-28 sm:w-28 sm:h-28 rounded-2xl border border-slate-300 dark:border-slate-600 bg-white overflow-hidden shrink-0 flex items-center justify-center shadow-2xs">
                    {formImage ? (
                      <img
                        src={formImage}
                        alt="Preview"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain p-1.5"
                      />
                    ) : (
                      <ProductThumbnail
                        product={{
                          id: editingProduct?.id || 'preview',
                          businessId: currentBusiness.id,
                          nameBn: formNameBn || 'নতুন পণ্য',
                          nameEn: formNameEn || 'New Product',
                          sku: formSku || 'SKU-NEW',
                          barcode: formBarcode || '1001',
                          categoryId: formCategory,
                          brandId: formBrand,
                          unit: formUnit,
                          packSize: 1,
                          purchasePrice: formPurchasePrice,
                          retailPrice: formRetailPrice,
                          wholesalePrice: formWholesalePrice,
                          minWholesaleQty: 5,
                          stockByOutlet: {},
                          lowStockAlert: 10,
                          vatPercent: 5
                        }}
                      />
                    )}
                  </div>

                  <div className="flex-1 w-full space-y-2.5">
                    <div>
                      <span className="text-xs font-extrabold text-slate-800 dark:text-slate-100 block">
                        পণ্যের মূল ছবি (Main Product Image)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        হোমপেজ ও প্রোডাক্ট কার্ডে এই ছবিটি সবার আগে দেখাবে
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        ref={modalFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleModalImageFileChange}
                        className="hidden"
                      />
                      <button
                        type="button"
                        disabled={isProcessingImage}
                        onClick={() => modalFileInputRef.current?.click()}
                        className="w-full sm:w-auto min-h-[40px] px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          {isProcessingImage
                            ? 'প্রসেস হচ্ছে...'
                            : 'কম্পিউটার / মোবাইল থেকে ছবি আপলোড'}
                        </span>
                      </button>

                      {formImage && (
                        <button
                          type="button"
                          onClick={() => setFormImage('')}
                          className="w-full sm:w-auto min-h-[40px] px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5 shrink-0" />
                          <span>ছবি মুছুন</span>
                        </button>
                      )}
                    </div>

                    <div className="relative">
                      <Link2 className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={formImage.startsWith('data:') ? '' : formImage}
                        onChange={(e) => setFormImage(e.target.value)}
                        placeholder="অথবা ছবির সরাসরি লিংক (https://...) পেস্ট করুন"
                        className="w-full min-h-[38px] pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-[11px] text-slate-800 outline-hidden"
                      />
                    </div>
                  </div>
                </div>

                {/* Product Image Gallery Manager */}
                <div className="lg:col-span-6 p-3.5 sm:p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5 flex flex-col justify-between">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <label className="text-xs font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                        <ImagePlus className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span>প্রোডাক্ট ইমেজ গ্যালারি (অতিরিক্ত ছবি যুক্ত করুন)</span>
                      </label>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        প্রোডাক্ট পেজে মেইন ছবির নিচে থাম্বনেইল গ্যালারি হিসেবে একাধিক ছবি দেখাবে
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <input
                        ref={galleryFileInputRef}
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleGalleryFilesChange}
                        className="hidden"
                      />
                      <button
                        type="button"
                        disabled={isProcessingImage}
                        onClick={() => galleryFileInputRef.current?.click()}
                        className="w-full sm:w-auto min-h-[38px] px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-[11px] rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5 shrink-0" />
                        <span>+ গ্যালারি ছবি আপলোড (Multiple)</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={newGalleryUrl}
                      onChange={(e) => setNewGalleryUrl(e.target.value)}
                      placeholder="অথবা গ্যালারি ছবির লিংক (https://...) লিখে + লিংক যোগ বাটনে ক্লিক করুন"
                      className="flex-1 min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-[11px] text-slate-800 outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!newGalleryUrl.trim()) return;
                        setFormGalleryImages(prev => [...prev, newGalleryUrl.trim()]);
                        setNewGalleryUrl('');
                      }}
                      className="min-h-[38px] px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] rounded-xl cursor-pointer shrink-0"
                    >
                      + লিংক যোগ
                    </button>
                  </div>

                  {formGalleryImages.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-1">
                      {formGalleryImages.map((gImg, idx) => (
                        <div
                          key={`${idx}_${gImg.slice(0, 18)}`}
                          className="relative w-14 h-14 rounded-xl border border-slate-300 bg-white overflow-hidden group shadow-2xs"
                        >
                          <img
                            src={gImg}
                            alt={`Gallery ${idx + 1}`}
                            className="w-full h-full object-contain p-1"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setFormGalleryImages(prev => prev.filter((_, i) => i !== idx))
                            }
                            className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[10px] shadow-xs cursor-pointer"
                            title="মুছুন"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Product Name (Bangla & English) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">পণ্যের নাম (বাংলা) *</label>
                  <input
                    type="text"
                    required
                    value={formNameBn}
                    onChange={(e) => setFormNameBn(e.target.value)}
                    placeholder="উদা: প্রিমিয়াম বেবি পার্টি ফ্রক / তীর সয়াবিন তেল"
                    className="w-full min-h-[42px] p-2.5 bg-slate-50 border border-slate-300 focus:border-blue-600 focus:bg-white rounded-xl outline-hidden text-slate-900 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Product Name (English)</label>
                  <input
                    type="text"
                    value={formNameEn}
                    onChange={(e) => setFormNameEn(e.target.value)}
                    placeholder="e.g. Premium Baby Party Frock"
                    className="w-full min-h-[42px] p-2.5 bg-slate-50 border border-slate-300 focus:border-blue-600 focus:bg-white rounded-xl outline-hidden text-slate-900 font-semibold"
                  />
                </div>
              </div>

              {/* Dedicated Product Description Editor (পণ্যের বিস্তারিত বিবরণ — প্রোডাক্ট পেজে যা দেখাবে) */}
              <div className="p-3.5 sm:p-4 rounded-2xl bg-indigo-50/50 border-2 border-indigo-200/80 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <label className="text-slate-900 font-extrabold text-xs sm:text-sm flex flex-wrap items-center gap-1.5">
                      <FileText className="w-4 h-4 text-indigo-700 shrink-0" />
                      <span>পণ্যের বিস্তারিত বিবরণ (Product Description)</span>
                      <span className="px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-extrabold">
                        প্রোডাক্ট পেজে দেখাবে
                      </span>
                    </label>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      প্রোডাক্ট পেজের &ldquo;পণ্যের বিস্তারিত বিবরণ (Product Description)&rdquo; অংশে যা দেখাতে চান তা এখানে আপনার ইচ্ছামতো লিখুন।
                    </p>
                  </div>

                  {/* Quick Bullet / Formatting Insert Helpers */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        setFormDescription(prev =>
                          prev.trim() ? `${prev.trimEnd()}\n✅ ` : '✅ '
                        )
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-indigo-50 text-slate-800 border border-slate-300 text-[11px] font-bold cursor-pointer"
                    >
                      + ✅ পয়েন্ট
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setFormDescription(prev =>
                          prev.trim() ? `${prev.trimEnd()}\n• ` : '• '
                        )
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-indigo-50 text-slate-800 border border-slate-300 text-[11px] font-bold cursor-pointer"
                    >
                      + • বুলেট পয়েন্ট
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setFormDescription(prev =>
                          prev.trim() ? `${prev.trimEnd()}\n⭐ ` : '⭐ '
                        )
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-indigo-50 text-slate-800 border border-slate-300 text-[11px] font-bold cursor-pointer"
                    >
                      + ⭐ হাইলাইট
                    </button>
                    {formDescription.trim() !== '' && (
                      <button
                        type="button"
                        onClick={() => setFormDescription('')}
                        className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-bold cursor-pointer"
                      >
                        সব মুছুন (Clear)
                      </button>
                    )}
                  </div>
                </div>

                <textarea
                  rows={4}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder={
                    'এখানে পণ্যের বিস্তারিত বিবরণ লিখুন...\nযেমন:\n✅ প্রিমিয়াম কোয়ালিটি ও ১০০% অরিজিনাল পণ্য\n✅ অত্যন্ত আরামদায়ক ও আকর্ষণীয় ডিজাইন\n✅ সারাদেশে দ্রুত হোম ডেলিভারি (ক্যাশ অন ডেলিভারি সুবিধা)'
                  }
                  className="w-full p-3 bg-white border border-indigo-300 focus:border-indigo-600 rounded-xl outline-hidden text-xs sm:text-sm text-slate-900 leading-relaxed"
                />
              </div>

              {/* Category, Brand, SKU, Barcode & Unit Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3.5 p-3.5 sm:p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="lg:col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-700 font-bold">পণ্যের ক্যাটাগরি *</label>
                    <button
                      type="button"
                      onClick={() => {
                        setCatalogManagerTab('categories');
                        setShowCatalogManagerModal(true);
                      }}
                      className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 cursor-pointer"
                    >
                      + অ্যাড / ডিলিট করুন
                    </button>
                  </div>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-medium text-slate-900"
                  >
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>
                        {cat.nameBn} ({cat.nameEn})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="lg:col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-700 font-bold">ব্র্যান্ড / কোম্পানি</label>
                    <button
                      type="button"
                      onClick={() => {
                        setCatalogManagerTab('brands');
                        setShowCatalogManagerModal(true);
                      }}
                      className="text-[11px] font-bold text-blue-700 hover:text-blue-900 cursor-pointer"
                    >
                      + অ্যাড / ডিলিট করুন
                    </button>
                  </div>
                  <select
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-medium text-slate-900"
                  >
                    {brands.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="lg:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">পরিমাপ একক (Unit)</label>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-medium text-slate-900"
                  >
                    <option value="বোতল (Bottle)">বোতল (Bottle)</option>
                    <option value="প্যাকেট (Pack)">প্যাকেট (Pack)</option>
                    <option value="বস্তা (Sack)">বস্তা (Sack)</option>
                    <option value="জার (Jar)">জার (Jar)</option>
                    <option value="বক্স (Box)">বক্স (Box)</option>
                    <option value="পিস (Pcs)">পিস (Pcs)</option>
                    <option value="কেজি (Kg)">কেজি (Kg)</option>
                  </select>
                </div>

                <div className="lg:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">SKU কোড (WP অটো-ম্যাচ) *</label>
                  <input
                    type="text"
                    required
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div className="lg:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">
                    WordPress Product ID (ঐচ্ছিক)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formWpProductId}
                    onChange={(e) => setFormWpProductId(e.target.value)}
                    placeholder="উদা: 124 (খালি থাকলে অটো-ম্যাচ)"
                    className="w-full min-h-[42px] p-2.5 bg-sky-50/70 border border-sky-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div className="lg:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">বারকোড (EAN/UPC)</label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={formBarcode}
                      onChange={(e) => setFormBarcode(e.target.value)}
                      className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                    />
                    <button
                      type="button"
                      onClick={() => setShowBarcodeCameraModal(true)}
                      className="min-h-[42px] px-3 bg-blue-700 hover:bg-blue-800 text-white rounded-xl flex items-center justify-center shrink-0 cursor-pointer"
                      title="ক্যামেরা দিয়ে বারকোড স্ক্যান করুন"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Regular Price, Discount Price (Selling Price), Purchase Price & Wholesale Price */}
              <div className="p-3.5 sm:p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">
                      পণ্যের মূল্য ও ডিসকাউন্ট সেটআপ (Regular Price & Discount Selling Price)
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      ডিসকাউন্ট বিক্রয় মূল্য দিলে কাস্টমার সেই ডিসকাউন্ট দামে কিনবে এবং রেগুলার প্রাইসটি কাটা দাগ (<s>৳...</s>) হিসেবে পাশে থাকবে
                    </p>
                  </div>

                  {(() => {
                    const regVal = Number(formRegularPrice) || 0;
                    const sellVal = effectiveFormSellingPrice;
                    const savedTk = Math.max(0, regVal - sellVal);
                    return (
                      <div className="px-3 py-1.5 rounded-xl bg-white border border-rose-200 flex flex-wrap items-center gap-2 text-xs">
                        <span className="text-slate-500 font-semibold">ওয়েবসাইটে দেখাবে:</span>
                        <span className="font-mono font-extrabold text-emerald-700 text-sm">
                          ৳{sellVal}
                        </span>
                        {savedTk > 0 && (
                          <>
                            <span className="font-mono text-slate-400 line-through text-xs">
                              ৳{regVal}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-[#c30000] text-white font-extrabold text-[10px]">
                              ছাড় ৳{savedTk}
                            </span>
                          </>
                        )}
                      </div>
                    );
                  })()}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      ক্রয় দর (৳) *
                    </label>
                    <input
                      type="number"
                      required
                      value={formPurchasePrice}
                      onChange={(e) => setFormPurchasePrice(parseFloat(e.target.value) || 0)}
                      className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-800 font-extrabold mb-1">
                      রেগুলার প্রাইস (৳) *
                    </label>
                    <input
                      type="number"
                      required
                      value={formRegularPrice}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setFormRegularPrice(val);
                        if (!formDiscountPrice.trim()) {
                          setFormRetailPrice(val);
                        }
                      }}
                      placeholder="উদা: ১০৫০"
                      className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 focus:border-slate-600 rounded-xl font-mono font-bold text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[#c30000] font-extrabold mb-1">
                      ডিসকাউন্ট বিক্রয় মূল্য (৳)
                    </label>
                    <input
                      type="number"
                      value={formDiscountPrice}
                      onChange={(e) => {
                        const raw = e.target.value;
                        setFormDiscountPrice(raw);
                        const num = parseFloat(raw);
                        const nextSelling = !Number.isNaN(num) && num > 0 ? num : formRegularPrice;
                        setFormRetailPrice(nextSelling);
                        setFormVariants(prev =>
                          prev.map(v => ({
                            ...v,
                            regularPrice: formRegularPrice > 0 ? formRegularPrice : v.regularPrice,
                            discountPrice: !Number.isNaN(num) && num > 0 ? num : undefined,
                            retailPrice: nextSelling
                          }))
                        );
                      }}
                      placeholder="উদা: ৯৫০ (ফাঁকা রাখলে রেগুলার দামে বিক্রি)"
                      className="w-full min-h-[42px] p-2.5 bg-white border-2 border-[#c30000]/60 focus:border-[#c30000] rounded-xl font-mono font-extrabold text-[#c30000]"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      পাইকারি দর (৳) *
                    </label>
                    <input
                      type="number"
                      required
                      value={formWholesalePrice}
                      onChange={(e) => setFormWholesalePrice(parseFloat(e.target.value) || 0)}
                      className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-mono text-blue-800 font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Storefront Product Page Offer Countdown Timer */}
              <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-rose-50/80 via-amber-50/60 to-rose-50/80 border border-rose-200/90 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="flex items-start sm:items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                      <Clock className="w-4 h-4" />
                    </span>
                    <div>
                      <h3 className="text-xs sm:text-sm font-extrabold text-rose-950">
                        প্রোডাক্ট পেজ অফার কাউন্টডাউন টাইমার (গ্লোবাল একই টাইম + এই প্রোডাক্টে Show/Hide)
                      </h3>
                      <p className="text-[11px] text-slate-600">
                        সব প্রোডাক্টে একই গ্লোবাল টাইম একসাথে চলবে। নিচে থেকে শুধু এই প্রোডাক্টে দেখাবে কি না বা এক ক্লিকে সব প্রোডাক্টে ON/OFF কন্ট্রোল করুন।
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFormCountdownEnabled(prev => !prev)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        formCountdownEnabled
                          ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                          : 'bg-slate-200 text-slate-700 border-slate-300'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>
                        এই প্রোডাক্টে: {formCountdownEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextGlobal = currentBusiness.storefrontCountdownEnabled === false;
                        updateBusiness({ storefrontCountdownEnabled: nextGlobal });
                        showToast(
                          nextGlobal
                            ? '১-ক্লিকে সব প্রোডাক্টে গ্লোবাল কাউন্টডাউন চালু (ON) করা হয়েছে!'
                            : '১-ক্লিকে সব প্রোডাক্টে গ্লোবাল কাউন্টডাউন বন্ধ (OFF) করা হয়েছে!',
                          nextGlobal ? 'success' : 'info'
                        );
                      }}
                      className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        currentBusiness.storefrontCountdownEnabled !== false
                          ? 'bg-rose-600 text-white border-rose-700 shadow-2xs'
                          : 'bg-slate-200 text-slate-700 border-slate-300'
                      }`}
                    >
                      <span>
                        সব প্রোডাক্টে (Global):{' '}
                        {currentBusiness.storefrontCountdownEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>
                  </div>
                </div>

                {formCountdownEnabled && currentBusiness.storefrontCountdownEnabled !== false && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 pt-2 border-t border-rose-200/70">
                    <div className="lg:col-span-7 space-y-2">
                      <label className="block text-[11px] font-extrabold text-slate-800">
                        গ্লোবাল কাউন্টডাউন টাইম সেট (এক জায়গা থেকে সব প্রোডাক্টে একই সময় চলবে — ০ হলে অটো রিস্টার্ট হবে):
                      </label>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {[
                          { h: 8, m: 30, s: 34, label: '৮ঘ:৩০মি:৩৪সে (৯h রিয়েল)' },
                          { h: 5, m: 42, s: 18, label: '৫ঘ:৪২মি:১৮সে (৬h রিয়েল)' },
                          { h: 2, m: 35, s: 47, label: '২ঘ:৩৫মি:৪৭সে (৩h রিয়েল)' },
                          { h: 11, m: 28, s: 19, label: '১১ঘ:২৮মি:১৯সে (১২h রিয়েল)' }
                        ].map(preset => {
                          const curH = currentBusiness.storefrontCountdownHours ?? 8;
                          const curM = currentBusiness.storefrontCountdownMinutes ?? 30;
                          const curS = currentBusiness.storefrontCountdownSeconds ?? 34;
                          const isSelected =
                            curH === preset.h && curM === preset.m && curS === preset.s;
                          return (
                            <button
                              key={preset.label}
                              type="button"
                              onClick={() => {
                                setFormCountdownHours(preset.h + 1);
                                updateBusiness({
                                  storefrontCountdownHours: preset.h,
                                  storefrontCountdownMinutes: preset.m,
                                  storefrontCountdownSeconds: preset.s,
                                  storefrontCountdownResetSeed: Date.now()
                                });
                                showToast(
                                  `সব প্রোডাক্টে গ্লোবাল কাউন্টডাউন টাইম: ${preset.label} সেট করা হয়েছে!`,
                                  'success'
                                );
                              }}
                              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-colors ${
                                isSelected
                                  ? 'bg-rose-600 text-white border-rose-600'
                                  : 'bg-white text-slate-700 border-slate-300 hover:border-rose-400'
                              }`}
                            >
                              {preset.label}
                            </button>
                          );
                        })}

                        <button
                          type="button"
                          onClick={() => {
                            const randH = [3, 5, 7, 8, 10][Math.floor(Math.random() * 5)];
                            const randM = Math.floor(18 + Math.random() * 31);
                            const randS = Math.floor(12 + Math.random() * 43);
                            updateBusiness({
                              storefrontCountdownHours: randH,
                              storefrontCountdownMinutes: randM,
                              storefrontCountdownSeconds: randS,
                              storefrontCountdownResetSeed: Date.now()
                            });
                            showToast(
                              `নতুন রিয়েলিস্টিক গ্লোবাল টাইম (${randH} ঘণ্টা ${randM} মিনিট ${randS} সেকেন্ড) সব প্রোডাক্টে সেট হয়েছে!`,
                              'success'
                            );
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-extrabold cursor-pointer transition-colors"
                        >
                          🎲 র‍্যান্ডম টাইম
                        </button>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                        <span className="text-[11px] font-bold text-slate-600">কাস্টম সময়:</span>
                        <input
                          type="number"
                          min={0}
                          max={72}
                          value={currentBusiness.storefrontCountdownHours ?? 8}
                          onChange={e => {
                            const h = Math.max(0, Math.min(72, parseInt(e.target.value, 10) || 0));
                            updateBusiness({
                              storefrontCountdownHours: h,
                              storefrontCountdownResetSeed: Date.now()
                            });
                          }}
                          className="w-14 min-h-[34px] px-2 py-1 bg-white border border-rose-300 rounded-lg font-mono font-bold text-xs text-center text-slate-900"
                          title="ঘণ্টা"
                        />
                        <span className="text-[11px] font-bold text-slate-700">ঘণ্টা</span>
                        <input
                          type="number"
                          min={0}
                          max={59}
                          value={currentBusiness.storefrontCountdownMinutes ?? 30}
                          onChange={e => {
                            const m = Math.max(0, Math.min(59, parseInt(e.target.value, 10) || 0));
                            updateBusiness({
                              storefrontCountdownMinutes: m,
                              storefrontCountdownResetSeed: Date.now()
                            });
                          }}
                          className="w-14 min-h-[34px] px-2 py-1 bg-white border border-rose-300 rounded-lg font-mono font-bold text-xs text-center text-slate-900"
                          title="মিনিট"
                        />
                        <span className="text-[11px] font-bold text-slate-700">মিনিট</span>
                        <input
                          type="number"
                          min={1}
                          max={58}
                          value={currentBusiness.storefrontCountdownSeconds ?? 34}
                          onChange={e => {
                            const s = Math.max(1, Math.min(58, parseInt(e.target.value, 10) || 34));
                            updateBusiness({
                              storefrontCountdownSeconds: s,
                              storefrontCountdownResetSeed: Date.now()
                            });
                          }}
                          className="w-14 min-h-[34px] px-2 py-1 bg-white border border-rose-300 rounded-lg font-mono font-bold text-xs text-center text-slate-900"
                          title="সেকেন্ড"
                        />
                        <span className="text-[11px] font-bold text-slate-700">সেকেন্ড</span>
                      </div>
                    </div>

                    <div className="lg:col-span-5">
                      <label className="block text-[11px] font-extrabold text-slate-800 mb-1">
                        কাউন্টডাউন টাইটেল টেক্সট (গ্লোবাল)
                      </label>
                      <input
                        type="text"
                        value={
                          currentBusiness.storefrontCountdownTitle ?? formCountdownTitle
                        }
                        onChange={e => {
                          setFormCountdownTitle(e.target.value);
                          updateBusiness({ storefrontCountdownTitle: e.target.value });
                        }}
                        placeholder="স্পেশাল অফার শেষ হতে বাকি:"
                        className="w-full min-h-[40px] px-3 py-1.5 bg-white border border-slate-300 focus:border-rose-500 rounded-xl text-xs font-bold text-slate-900"
                      />
                    </div>
                  </div>
                )}

                {/* Per-Product Live Viewers Counter (12-48 Randomized) ON/OFF Toggle */}
                <div className="pt-2.5 border-t border-rose-200/70 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                      <span>
                        প্রোডাক্ট পেজে লাইভ ভিউয়ার কাউন্টার ("People currently viewing this product" 12–48)
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      চালু থাকলে প্রোডাক্ট পেজে ১২ থেকে ৪৮ জনের একটি র‍্যান্ডম লাইভ ভিউয়ার সংখ্যা দেখাবে যা ক্রেতাদের দ্রুত অর্ডার করতে উৎসাহিত করবে।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormLiveViewersEnabled(prev => !prev)}
                    className={`px-3.5 py-2 rounded-xl font-extrabold text-xs border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                      formLiveViewersEnabled
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{formLiveViewersEnabled ? 'চালু আছে (ON)' : 'বন্ধ আছে (OFF)'}</span>
                  </button>
                </div>

                {/* Product-Specific Free Delivery Toggle in Product Form */}
                <div className="pt-2.5 border-t border-rose-200/70 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                      <span>🚚</span>
                      <span>
                        এই প্রোডাক্টে আলাদা ফ্রি ডেলিভারি (Product-Specific Free Delivery Badge &amp; Offer)
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      চালু করলে এই প্রোডাক্টের কার্ডে &ldquo;🚚 ফ্রি ডেলিভারি&rdquo; ব্যাজ দেখাবে এবং কাস্টমার এটি একা বা অন্য পণ্যের সাথে কার্টে নিলে পুরো অর্ডারের ডেলিভারি চার্জ ফ্রি (৳০) হয়ে যাবে!
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormFreeDelivery(prev => !prev)}
                    className={`px-3.5 py-2 rounded-xl font-extrabold text-xs border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                      formFreeDelivery
                        ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <span>{formFreeDelivery ? '🚚 ফ্রি ডেলিভারি: চালু (ON) ✓' : '🚚 ফ্রি ডেলিভারি: বন্ধ (OFF)'}</span>
                  </button>
                </div>
              </div>

              {/* Stock Quantity, Manual Stock Status, Low Stock Alert & Expiry */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 p-3.5 sm:p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
                <div>
                  <label className="block text-emerald-950 font-extrabold mb-1">
                    {editingProduct ? '📦 বর্তমান স্টক পরিমাণ (Stock) *' : '📦 প্রারম্ভিক স্টক পরিমাণ *'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formInitialStock}
                    onChange={(e) => setFormInitialStock(Math.max(0, parseInt(e.target.value, 10) || 0))}
                    className="w-full min-h-[42px] p-2.5 bg-white border-2 border-emerald-500 focus:border-emerald-700 rounded-xl font-mono font-extrabold text-emerald-900 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-800 font-extrabold mb-1">
                    ওয়েবসাইটে স্টক স্ট্যাটাস (Manual)
                  </label>
                  <button
                    type="button"
                    onClick={() => setFormIsOutOfStock(prev => !prev)}
                    className={`w-full min-h-[42px] px-3 py-2 rounded-xl border-2 font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      formIsOutOfStock
                        ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                        : 'bg-white text-emerald-800 border-emerald-500 hover:bg-emerald-50'
                    }`}
                  >
                    <span>
                      {formIsOutOfStock
                        ? '🚫 স্টক শেষ (Out of Stock)'
                        : '✓ স্টকে আছে (In Stock)'}
                    </span>
                  </button>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">স্বল্প স্টক সতর্কতা লেভেল</label>
                  <input
                    type="number"
                    value={formLowStockAlert}
                    onChange={(e) => setFormLowStockAlert(parseInt(e.target.value) || 10)}
                    className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">মেয়াদোত্তীর্ণ তারিখ</label>
                  <input
                    type="date"
                    value={formExpiryDate}
                    onChange={(e) => setFormExpiryDate(e.target.value)}
                    className="w-full min-h-[42px] p-2.5 bg-white border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              {/* Product Variations Manager (Wide Desktop Table + 100% Mobile Responsive Cards) */}
              <div className="p-3.5 sm:p-5 rounded-2xl bg-emerald-50/60 border-2 border-emerald-600/30 space-y-3.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-emerald-200/80">
                  <div>
                    <h3 className="font-extrabold text-xs sm:text-sm text-emerald-950 flex flex-wrap items-center gap-1.5">
                      <Layers className="w-4 h-4 text-emerald-700 shrink-0" />
                      <span>
                        পণ্যের ভ্যারিয়েশন যুক্ত করুন (শুধু সাইজ / শুধু কালার / অথবা সাইজ ও কালার ২টাই একসাথে)
                      </span>
                    </h3>
                    <p className="text-[11px] text-emerald-800 mt-0.5">
                      💡 আপনার প্রোডাক্টে শুধু সাইজ লাগলে সাইজ দিন, শুধু কালার লাগলে কালার দিন, আর <strong>সাইজ ও কালার ২টাই থাকলে দুটোই যোগ করুন</strong> (ওয়েবসাইটে অটোমেটিক ২টি আলাদা সিলেকশন বক্স দেখাবে)। কোনো ভ্যারিয়েশন না থাকলে খালি রাখুন।
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 self-start sm:self-auto shrink-0">
                    {formVariants.length > 0 && (
                      <>
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-100 border border-emerald-300 text-[11px] font-extrabold text-emerald-900">
                          📏 সাইজ: {formVariants.filter(v => v.type !== 'color').length}টি • 🎨 কালার: {formVariants.filter(v => v.type === 'color').length}টি
                        </span>
                        <button
                          type="button"
                          onClick={() => setFormVariants([])}
                          className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-[11px] font-bold text-rose-700 cursor-pointer"
                        >
                          সব মুছুন ({formVariants.length})
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* 1-Click Quick Preset Buttons */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    ১-ক্লিকে রেডিমেড ভ্যারিয়েশন যোগ করুন (ইচ্ছেমতো ১টি বা ২টিই ব্যবহার করতে পারবেন):
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleApplyVariantPreset('baby_years')}
                      className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white border border-rose-600 font-extrabold text-[11px] cursor-pointer transition-colors shadow-2xs"
                    >
                      + বেবি ড্রেস বয়স সাইজ (1-2, 3-4, 5-6, 7-8, 9-10, 11-12 Years)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyVariantPreset('size_cloth')}
                      className="px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white border border-emerald-700 font-extrabold text-[11px] cursor-pointer transition-colors shadow-2xs"
                    >
                      + পোশাক সাইজ (M / L / XL / XXL)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyVariantPreset('color_set')}
                      className="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 border border-amber-600 font-extrabold text-[11px] cursor-pointer transition-colors shadow-2xs"
                    >
                      + কালার ভ্যারিয়েশন (লাল / নীল / কালো / সাদা)
                    </button>
                  </div>
                </div>

                {/* Custom Variation Input Row with Variation SKU */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 items-end bg-white p-3.5 rounded-xl border border-emerald-200 shadow-2xs">
                  <div className="lg:col-span-2">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      ভ্যারিয়েশন ধরন
                    </label>
                    <select
                      value={newVarType}
                      onChange={(e) => setNewVarType(e.target.value as any)}
                      className="w-full min-h-[40px] px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-extrabold text-slate-800"
                    >
                      <option value="size">📏 সাইজ (S, M, L, XL, Years)</option>
                      <option value="color">🎨 কালার / রঙ (Red, Blue, কালো)</option>
                      <option value="weight">⚖️ ওজন (500gm, 1kg)</option>
                      <option value="pack">📦 প্যাক সাইজ (Combo/Box)</option>
                    </select>
                  </div>

                  <div className="lg:col-span-3">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {newVarType === 'color' ? 'কালার / রঙের নাম *' : 'সাইজ / ভ্যারিয়েশন নাম *'}
                    </label>
                    <input
                      type="text"
                      value={newVarLabel}
                      onChange={(e) => {
                        const val = e.target.value;
                        setNewVarLabel(val);
                        if (val.trim()) {
                          setNewVarSku(buildVariantSkuCode(formSku, val, formVariants.length));
                        }
                      }}
                      placeholder={newVarType === 'color' ? 'উদা: লাল (Red) বা কালো' : 'উদা: XL বা 5-6 Years'}
                      className="w-full min-h-[40px] px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 font-semibold"
                    />
                  </div>

                  <div className="lg:col-span-3">
                    <label className="block text-[11px] font-bold text-sky-900 mb-1">
                      ভ্যারিয়েশন SKU (WP সাইজ ম্যাচ)
                    </label>
                    <input
                      type="text"
                      value={newVarSku}
                      onChange={(e) => setNewVarSku(e.target.value)}
                      placeholder={
                        newVarLabel
                          ? buildVariantSkuCode(formSku, newVarLabel, formVariants.length)
                          : `${formSku || 'SKU'}-XL`
                      }
                      className="w-full min-h-[40px] px-3 py-1.5 bg-sky-50/70 border border-sky-300 rounded-xl font-mono text-xs text-slate-900"
                    />
                  </div>

                  <div className="lg:col-span-2">
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      ক্রয় দর (৳)
                    </label>
                    <input
                      type="number"
                      value={newVarPurchasePrice}
                      onChange={(e) => setNewVarPurchasePrice(e.target.value)}
                      placeholder={String(formPurchasePrice || 500)}
                      className="w-full min-h-[40px] px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs text-slate-900"
                    />
                  </div>

                  <div className="sm:col-span-2 lg:col-span-2 flex flex-col sm:flex-row items-stretch sm:items-end gap-2">
                    <div className="flex-1">
                      <label className="block text-[11px] font-bold text-emerald-900 mb-1">
                        বিক্রয় দর (৳)
                      </label>
                      <input
                        type="number"
                        value={newVarRetailPrice}
                        onChange={(e) => setNewVarRetailPrice(e.target.value)}
                        placeholder={String(effectiveFormSellingPrice || 750)}
                        className="w-full min-h-[40px] px-2.5 py-1.5 bg-slate-50 border border-emerald-400 rounded-xl font-mono font-bold text-xs text-emerald-900"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleAddVariantRow}
                      className="min-h-[40px] px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1 shrink-0 cursor-pointer shadow-2xs"
                    >
                      <Plus className="w-4 h-4" />
                      <span>যোগ</span>
                    </button>
                  </div>
                </div>

                {/* List of Added Variations: Responsive Mobile Cards + Wide Desktop Table */}
                {formVariants.length > 0 && (
                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                    <div className="px-3.5 py-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                      <span className="text-[11px] font-extrabold text-slate-800">
                        যুক্ত করা সাইজ ও কালার ভ্যারিয়েশন তালিকা ({formVariants.length}টি)
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setFormVariants(prev =>
                            prev.map((v, i) => ({
                              ...v,
                              sku: buildVariantSkuCode(formSku, v.label, i)
                            }))
                          );
                          showToast('সব ভ্যারিয়েশনের জন্য অটো-SKU জেনারেট হয়েছে!', 'info');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-sky-100 hover:bg-sky-200 text-sky-900 font-extrabold text-[10px] cursor-pointer"
                      >
                        সব সাইজের অটো-SKU রিসেট করুন
                      </button>
                    </div>

                    {/* Desktop Table Header (Hidden on Mobile/Tablet) */}
                    <div className="hidden lg:grid px-3.5 py-2.5 bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-700 grid-cols-12 gap-2.5">
                      <span className="col-span-3">সাইজ / কালার নাম ও ধরন</span>
                      <span className="col-span-3 text-sky-900">ভ্যারিয়েশন SKU ও WP ID</span>
                      <span className="col-span-1">ক্রয় (৳)</span>
                      <span className="col-span-1">রেগুলার (৳)</span>
                      <span className="col-span-1 text-emerald-800">বিক্রয় (৳)</span>
                      <span className="col-span-2 text-center">স্টক স্ট্যাটাস</span>
                      <span className="col-span-1 text-right">ডিলিট</span>
                    </div>

                    <div className="divide-y divide-slate-200 max-h-80 overflow-y-auto">
                      {formVariants.map((v, idx) => (
                        <div
                          key={v.id}
                          className={`p-3 lg:px-3.5 lg:py-2.5 grid grid-cols-2 sm:grid-cols-6 lg:grid-cols-12 gap-2.5 items-center transition-colors ${
                            v.outOfStock ? 'bg-rose-50/60 hover:bg-rose-50' : 'hover:bg-slate-50'
                          }`}
                        >
                          {/* Variation Label + 1-Click Size/Color Type Switcher + Color Image Upload */}
                          <div className="col-span-2 sm:col-span-3 lg:col-span-3">
                            <label className="lg:hidden block text-[10px] font-bold text-slate-500 mb-1">
                              সাইজ / কালার নাম, ধরন ও ছবি
                            </label>
                            <div className="flex items-center gap-1.5">
                              {/* 1-Click Variation/Color Image Upload Swatch */}
                              <div className="relative shrink-0">
                                <label
                                  title={
                                    v.imageUrl
                                      ? 'কালার/ভ্যারিয়েশনের ছবি পরিবর্তন করতে ক্লিক করুন'
                                      : 'এই কালার/ভ্যারিয়েশনের ড্রেসের ছবি আপলোড করুন (কাস্টমার কালার সিলেক্ট করলে এই ছবি দেখাবে)'
                                  }
                                  className={`w-[38px] h-[38px] rounded-lg border-2 flex items-center justify-center overflow-hidden cursor-pointer transition-all ${
                                    v.imageUrl
                                      ? 'border-rose-500 bg-white shadow-2xs'
                                      : 'border-dashed border-slate-300 hover:border-rose-400 bg-slate-50 text-slate-500 hover:text-rose-600'
                                  }`}
                                >
                                  <input
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      if (!file) return;
                                      setIsProcessingImage(true);
                                      try {
                                        const compressed = await processUploadedProductImage(file, 1000, 0.9);
                                        handleUpdateVariantField(v.id, 'imageUrl', compressed);
                                        showToast(
                                          `"${v.label}"-এর জন্য ছবি যুক্ত হয়েছে! কাস্টমার এটি সিলেক্ট করলে মেইন ছবি বদলে যাবে।`,
                                          'success'
                                        );
                                      } catch (err: any) {
                                        showToast(err?.message || 'ছবি আপলোড ব্যর্থ হয়েছে', 'error');
                                      } finally {
                                        setIsProcessingImage(false);
                                        e.target.value = '';
                                      }
                                    }}
                                  />
                                  {v.imageUrl ? (
                                    <img
                                      src={v.imageUrl}
                                      alt={v.label}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <span className="text-[9px] font-extrabold text-center leading-none px-0.5">
                                      📷 ছবি
                                    </span>
                                  )}
                                </label>
                                {v.imageUrl && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      handleUpdateVariantField(v.id, 'imageUrl', undefined);
                                      showToast(`"${v.label}"-এর ছবি সরানো হয়েছে`, 'info');
                                    }}
                                    title="এই ভ্যারিয়েশনের ছবি মুছে ফেলুন"
                                    className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center shadow-xs cursor-pointer"
                                  >
                                    ×
                                  </button>
                                )}
                              </div>

                              <button
                                type="button"
                                onClick={() =>
                                  handleUpdateVariantField(
                                    v.id,
                                    'type',
                                    v.type === 'color' ? 'size' : 'color'
                                  )
                                }
                                title="ক্লিক করে সাইজ বা কালার পরিবর্তন করুন"
                                className={`min-h-[38px] px-2 py-1 rounded-lg border text-[10px] font-extrabold shrink-0 cursor-pointer transition-colors ${
                                  v.type === 'color'
                                    ? 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                                    : 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200'
                                }`}
                              >
                                {v.type === 'color' ? '🎨 কালার' : '📏 সাইজ'}
                              </button>
                              <input
                                type="text"
                                value={v.label}
                                onChange={(e) =>
                                  handleUpdateVariantField(v.id, 'label', e.target.value)
                                }
                                className={`w-full min-h-[38px] px-2.5 py-1.5 border rounded-lg text-xs font-bold ${
                                  v.outOfStock
                                    ? 'bg-rose-50 border-rose-300 text-rose-800 line-through'
                                    : 'bg-slate-50 border-slate-300 text-slate-900'
                                }`}
                              />
                            </div>
                          </div>

                          {/* Variation SKU + WP Variation ID */}
                          <div className="col-span-2 sm:col-span-3 lg:col-span-3">
                            <label className="lg:hidden block text-[10px] font-bold text-sky-800 mb-1">
                              ভ্যারিয়েশন SKU ও WP ID
                            </label>
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={v.sku ?? buildVariantSkuCode(formSku, v.label, idx)}
                                onChange={(e) =>
                                  handleUpdateVariantField(v.id, 'sku', e.target.value)
                                }
                                placeholder={buildVariantSkuCode(formSku, v.label, idx)}
                                className="w-full min-h-[38px] px-2.5 py-1.5 bg-sky-50/70 border border-sky-300 focus:border-sky-600 focus:bg-white rounded-lg font-mono text-xs text-slate-900"
                                title="WordPress Variable Product-এর এই সাইজের SKU কোড"
                              />
                              <input
                                type="number"
                                min={0}
                                value={v.wpVariationId || ''}
                                onChange={(e) => {
                                  const parsed = parseInt(e.target.value, 10);
                                  setFormVariants(prev =>
                                    prev.map(item =>
                                      item.id === v.id
                                        ? {
                                            ...item,
                                            wpVariationId:
                                              !Number.isNaN(parsed) && parsed > 0 ? parsed : undefined
                                          }
                                        : item
                                    )
                                  );
                                }}
                                placeholder="WP ID"
                                className="w-20 shrink-0 min-h-[38px] px-2 py-1.5 bg-white border border-sky-200 focus:border-sky-600 rounded-lg font-mono text-[11px] text-sky-900"
                                title="WordPress Variation ID (ঐচ্ছিক)"
                              />
                            </div>
                          </div>

                          {/* Purchase Price */}
                          <div className="col-span-1 sm:col-span-2 lg:col-span-1">
                            <label className="lg:hidden block text-[10px] font-bold text-slate-500 mb-1">
                              ক্রয় (৳)
                            </label>
                            <input
                              type="number"
                              value={v.purchasePrice}
                              onChange={(e) =>
                                handleUpdateVariantField(
                                  v.id,
                                  'purchasePrice',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-full min-h-[38px] px-2 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-xs text-slate-700"
                            />
                          </div>

                          {/* Regular Price */}
                          <div className="col-span-1 sm:col-span-2 lg:col-span-1">
                            <label className="lg:hidden block text-[10px] font-bold text-slate-500 mb-1">
                              রেগুলার (৳)
                            </label>
                            <input
                              type="number"
                              value={v.regularPrice ?? (Number(formRegularPrice) || v.retailPrice)}
                              onChange={(e) =>
                                handleUpdateVariantField(
                                  v.id,
                                  'regularPrice',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-full min-h-[38px] px-2 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-xs text-slate-800"
                              title="রেগুলার প্রাইস (কাটা দাম হিসেবে দেখাবে)"
                            />
                          </div>

                          {/* Retail Selling Price */}
                          <div className="col-span-2 sm:col-span-2 lg:col-span-1">
                            <label className="lg:hidden block text-[10px] font-bold text-emerald-800 mb-1">
                              বিক্রয় দর (৳)
                            </label>
                            <input
                              type="number"
                              value={v.retailPrice}
                              onChange={(e) =>
                                handleUpdateVariantField(
                                  v.id,
                                  'retailPrice',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-full min-h-[38px] px-2 py-1.5 bg-emerald-50/70 border border-emerald-400 rounded-lg font-mono font-extrabold text-xs text-emerald-900"
                              title="ডিসকাউন্ট বা বিক্রয় মূল্য (এই দামে সেল হবে)"
                            />
                          </div>

                          {/* Stock Status Toggle + Delete */}
                          <div className="col-span-2 sm:col-span-6 lg:col-span-3 flex items-center justify-between lg:justify-end gap-2 pt-1 lg:pt-0">
                            <button
                              type="button"
                              onClick={() =>
                                setFormVariants(prev =>
                                  prev.map(item =>
                                    item.id === v.id
                                      ? { ...item, outOfStock: !item.outOfStock }
                                      : item
                                  )
                                )
                              }
                              className={`flex-1 min-h-[38px] px-2.5 py-1.5 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                                v.outOfStock
                                  ? 'bg-rose-600 text-white border-rose-700 hover:bg-rose-700 shadow-2xs'
                                  : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                              }`}
                              title="এই নির্দিষ্ট ভ্যারিয়েশনটি স্টক আউট (Out of Stock) অথবা ইন-স্টক (In Stock) করুন"
                            >
                              {v.outOfStock ? '🚫 স্টক শেষ' : '✓ স্টকে আছে'}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleRemoveVariantRow(v.id)}
                              className="min-h-[38px] px-2.5 py-1.5 text-rose-600 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg cursor-pointer flex items-center justify-center shrink-0"
                              title="এই ভ্যারিয়েশনটি ডিলিট করুন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* ===================================================================== */}
              {/* SIZE CHART & REVIEWS SIDE-BY-SIDE ON XL DESKTOP, STACKED ON MOBILE    */}
              {/* ===================================================================== */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 items-start">
                {/* SIZE CHART BUILDER FOR STOREFRONT PRODUCT PAGE */}
                <div className="p-3.5 sm:p-4 rounded-2xl border-2 border-indigo-200 bg-indigo-50/40 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-indigo-200/80">
                    <div>
                      <h4 className="text-xs font-extrabold text-indigo-950 flex items-center gap-1.5">
                        <Ruler className="w-4 h-4 text-indigo-700 shrink-0" />
                        <span>📏 প্রোডাক্ট পেজ সাইজ চার্ট সেটআপ (ON/OFF)</span>
                      </h4>
                      <p className="text-[11px] text-indigo-800 mt-0.5">
                        ফ্রন্ট ওয়েবসাইটের প্রোডাক্ট পেজে বয়স বা সাইজের মাপ টেবিল ও পপ-আপ আকারে দেখাবে।
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setFormSizeChartHeaders([...DEFAULT_LANDING_SIZE_CHART_HEADERS]);
                          setFormSizeChartRows(DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r })));
                          showToast('বেবি ড্রেস (১-১২ বছর) সাইজ চার্ট লোড হয়েছে!', 'info');
                        }}
                        className="px-2.5 py-1.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-lg text-[10px] font-extrabold cursor-pointer"
                      >
                        + বেবি সাইজ (১-১২ বছর)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setFormSizeChartHeaders(['সাইজ (Size)', 'বডি / চেস্ট (ইঞ্চি)', 'লম্বা / Length (ইঞ্চি)']);
                          setFormSizeChartRows([
                            { id: 'sc_m', size: 'M (Medium)', chest: '৩৮ ইঞ্চি', length: '২৭ ইঞ্চি' },
                            { id: 'sc_l', size: 'L (Large)', chest: '৪০ ইঞ্চি', length: '২৮ ইঞ্চি' },
                            { id: 'sc_xl', size: 'XL (Extra Large)', chest: '৪২ ইঞ্চি', length: '২৯ ইঞ্চি' },
                            { id: 'sc_xxl', size: 'XXL (Double XL)', chest: '৪৪ ইঞ্চি', length: '৩০ ইঞ্চি' }
                          ]);
                          showToast('বড়দের পোশাকের (M, L, XL, XXL) সাইজ চার্ট লোড হয়েছে!', 'info');
                        }}
                        className="px-2.5 py-1.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-lg text-[10px] font-extrabold cursor-pointer"
                      >
                        + বড়দের সাইজ (M-XXL)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormSizeChartEnabled(prev => !prev)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer transition-all ${
                          formSizeChartEnabled
                            ? 'bg-indigo-700 text-white shadow-xs'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {formSizeChartEnabled ? 'সাইজ চার্ট: চালু (ON)' : 'সাইজ চার্ট: বন্ধ (OFF)'}
                      </button>
                    </div>
                  </div>

                  {formSizeChartEnabled && (
                    <div className="space-y-2.5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">
                            সাইজ চার্ট শিরোনাম (Title)
                          </label>
                          <input
                            type="text"
                            value={formSizeChartTitle}
                            onChange={(e) => setFormSizeChartTitle(e.target.value)}
                            placeholder="সাইজ চার্ট ও বডির মাপ (Size Chart)"
                            className="w-full min-h-[38px] p-2 bg-white border border-indigo-300 rounded-lg text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">
                            সাইজ চার্ট সাব-টাইটেল (Subtitle)
                          </label>
                          <input
                            type="text"
                            value={formSizeChartSubtitle}
                            onChange={(e) => setFormSizeChartSubtitle(e.target.value)}
                            placeholder="অর্ডার করার পূর্বে ইঞ্চি মেপে আপনার সঠিক সাইজ নির্বাচন করুন"
                            className="w-full min-h-[38px] p-2 bg-white border border-indigo-300 rounded-lg text-xs font-semibold"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          সাইজ চার্টের ছবি (ঐচ্ছিক - গ্যালারি থেকে বা লিংক)
                        </label>
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-1.5">
                          <input
                            ref={sizeChartFileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              setIsProcessingImage(true);
                              try {
                                const dataUrl = await processUploadedProductImage(file, 640, 0.85);
                                setFormSizeChartImage(dataUrl);
                                showToast('সাইজ চার্টের ছবি যুক্ত হয়েছে!', 'success');
                              } catch (err: any) {
                                showToast(err?.message || 'ছবি আপলোডে সমস্যা', 'error');
                              } finally {
                                setIsProcessingImage(false);
                                e.target.value = '';
                              }
                            }}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => sizeChartFileInputRef.current?.click()}
                            className="min-h-[38px] px-3 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded-lg text-[11px] font-bold shrink-0 cursor-pointer flex items-center justify-center gap-1"
                          >
                            <Upload className="w-3.5 h-3.5" /> ছবি আপলোড
                          </button>
                          <div className="flex items-center gap-1.5 flex-1">
                            <input
                              type="text"
                              value={formSizeChartImage}
                              onChange={(e) => setFormSizeChartImage(e.target.value)}
                              placeholder="অথবা ছবির URL..."
                              className="w-full min-h-[38px] p-2 bg-white border border-indigo-300 rounded-lg text-[11px]"
                            />
                            {formSizeChartImage && (
                              <button
                                type="button"
                                onClick={() => setFormSizeChartImage('')}
                                className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer shrink-0"
                                title="ছবি মুছুন"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Editable Headers */}
                      <div className="grid grid-cols-3 gap-1.5 bg-indigo-100/80 p-2 rounded-lg border border-indigo-200">
                        {formSizeChartHeaders.map((hdr, hIdx) => (
                          <input
                            key={hIdx}
                            type="text"
                            value={hdr}
                            onChange={(e) => {
                              const updated = [...formSizeChartHeaders] as [string, string, string];
                              updated[hIdx] = e.target.value;
                              setFormSizeChartHeaders(updated);
                            }}
                            className="w-full min-w-0 p-1.5 bg-white border border-indigo-300 rounded text-[11px] font-extrabold text-indigo-950"
                          />
                        ))}
                      </div>

                      {/* Editable Rows */}
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {formSizeChartRows.map((row, rIdx) => (
                          <div key={row.id || rIdx} className="grid grid-cols-12 gap-1.5 items-center">
                            <input
                              type="text"
                              value={row.size}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormSizeChartRows(prev =>
                                  prev.map((item, i) => (i === rIdx ? { ...item, size: val } : item))
                                );
                              }}
                              placeholder="সাইজ / বয়স"
                              className="col-span-4 min-w-0 p-1.5 bg-white border border-slate-300 rounded text-[11px] font-bold"
                            />
                            <input
                              type="text"
                              value={row.chest}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormSizeChartRows(prev =>
                                  prev.map((item, i) => (i === rIdx ? { ...item, chest: val } : item))
                                );
                              }}
                              placeholder="বডি/চেস্ট"
                              className="col-span-4 min-w-0 p-1.5 bg-white border border-slate-300 rounded text-[11px]"
                            />
                            <input
                              type="text"
                              value={row.length}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormSizeChartRows(prev =>
                                  prev.map((item, i) => (i === rIdx ? { ...item, length: val } : item))
                                );
                              }}
                              placeholder="লম্বা"
                              className="col-span-3 min-w-0 p-1.5 bg-white border border-slate-300 rounded text-[11px]"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setFormSizeChartRows(prev => prev.filter((_, i) => i !== rIdx))
                              }
                              className="col-span-1 p-1.5 text-rose-500 hover:bg-rose-50 rounded flex justify-center cursor-pointer"
                              title="রো মুছুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setFormSizeChartRows(prev => [
                            ...prev,
                            {
                              id: `sc_${Date.now()}`,
                              size: 'নতুন সাইজ',
                              chest: '২৮ ইঞ্চি',
                              length: '২৪ ইঞ্চি'
                            }
                          ])
                        }
                        className="px-3 py-1.5 bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-lg text-[11px] font-extrabold cursor-pointer flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" /> নতুন সাইজ সারি যোগ করুন
                      </button>
                    </div>
                  )}
                </div>

                {/* REAL CUSTOMER PHOTO & UNBOXING VIDEO GALLERY FOR PRODUCT PAGE */}
                <div className="p-3.5 sm:p-4 rounded-2xl border-2 border-emerald-200 bg-emerald-50/40 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-emerald-200/80">
                    <div>
                      <h4 className="text-xs font-extrabold text-emerald-950 flex items-center gap-1.5">
                        <Camera className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>📸 কাস্টমারের পরা আসল ছবি ও আনবক্সিং ভিডিও (Real Gallery)</span>
                      </h4>
                      <p className="text-[11px] text-emerald-800 mt-0.5">
                        সাইট স্লো না করে বাস্তব ছবি (অটো WebP) ও ক্লিক-টু-প্লে আনবক্সিং ভিডিও যুক্ত করুন। কিছু না দিলে প্রোডাক্ট পেজে খালি দেখাবে না।
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormRealGalleryEnabled(prev => !prev)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer transition-all shrink-0 ${
                        formRealGalleryEnabled
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {formRealGalleryEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                    </button>
                  </div>

                  {formRealGalleryEnabled && (
                    <div className="space-y-2.5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">
                            গ্যালারির শিরোনাম
                          </label>
                          <input
                            type="text"
                            value={formRealGalleryTitle}
                            onChange={(e) => setFormRealGalleryTitle(e.target.value)}
                            placeholder="আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও"
                            className="w-full min-h-[38px] p-2 bg-white border border-emerald-300 rounded-lg text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">
                            আনবক্সিং ভিডিও লিংক (YouTube / Shorts / FB Reels / MP4)
                          </label>
                          <input
                            type="text"
                            value={formRealUnboxingVideoUrl}
                            onChange={(e) => setFormRealUnboxingVideoUrl(e.target.value)}
                            placeholder="https://youtube.com/shorts/... বা ভিডিও লিংক দিন"
                            className="w-full min-h-[38px] p-2 bg-white border border-emerald-300 rounded-lg text-xs font-medium"
                          />
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        <input
                          ref={realCustomerPhotoInputRef}
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={async (e) => {
                            const files = Array.from(e.target.files || []);
                            if (files.length === 0) return;
                            try {
                              const uploaded: string[] = [];
                              for (const file of files) {
                                const compressed = await processUploadedProductImage(file, 900, 0.88);
                                uploaded.push(compressed);
                              }
                              setFormRealCustomerPhotos(prev => [...prev, ...uploaded]);
                              showToast(`${uploaded.length}টি বাস্তব ছবি যুক্ত হয়েছে!`, 'success');
                            } catch {
                              showToast('ছবি প্রসেস করতে সমস্যা হয়েছে', 'error');
                            }
                            e.target.value = '';
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => realCustomerPhotoInputRef.current?.click()}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>+ কাস্টমারের বাস্তব ছবি আপলোড করুন (একাধিক)</span>
                        </button>
                        {formRealCustomerPhotos.length > 0 && (
                          <span className="text-[11px] font-extrabold text-emerald-800">
                            মোট {formRealCustomerPhotos.length}টি ছবি যুক্ত আছে
                          </span>
                        )}
                      </div>

                      {formRealCustomerPhotos.length > 0 && (
                        <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 pt-1">
                          {formRealCustomerPhotos.map((imgUrl, idx) => (
                            <div
                              key={idx}
                              className="relative aspect-square rounded-xl overflow-hidden border border-emerald-300 bg-white group"
                            >
                              <img
                                src={imgUrl}
                                alt={`Customer ${idx + 1}`}
                                loading="lazy"
                                className="w-full h-full object-cover"
                              />
                              <button
                                type="button"
                                onClick={() =>
                                  setFormRealCustomerPhotos(prev => prev.filter((_, i) => i !== idx))
                                }
                                className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-sm cursor-pointer"
                                title="ছবি মুছুন"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* FAKE / CUSTOM CUSTOMER REVIEWS BUILDER FOR PRODUCT PAGE */}
                <div className="p-3.5 sm:p-4 rounded-2xl border-2 border-amber-200 bg-amber-50/40 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-amber-200/80">
                    <div>
                      <h4 className="text-xs font-extrabold text-amber-950 flex items-center gap-1.5">
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
                        <span>⭐ প্রোডাক্ট পেজ কাস্টমার রিভিউ সেটআপ (ON/OFF)</span>
                      </h4>
                      <p className="text-[11px] text-amber-800 mt-0.5">
                        এখানে কাস্টমারের নাম, লোকেশন, স্টার রেটিং ও কমেন্ট লিখে প্রোডাক্ট পেজে রিভিউ দেখাতে পারবেন।
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          const demoPresets: LandingReviewItem[] = [
                            {
                              id: `rev_${Date.now()}_1`,
                              customerName: 'সাদিয়া ইসলাম মৌ',
                              location: 'উত্তরা, ঢাকা',
                              rating: 5,
                              comment:
                                'আলহামদুলিল্লাহ! ছবির চেয়েও বাস্তবে প্রোডাক্টের কোয়ালিটি অনেক বেশি সুন্দর। কাপড় একদম নরম ও আরামদায়ক। ডেলিভারিও খুব দ্রুত পেয়েছি।'
                            },
                            {
                              id: `rev_${Date.now()}_2`,
                              customerName: 'ফারহানা ইয়াসমিন',
                              location: 'নাসিরাবাদ, চট্টগ্রাম',
                              rating: 5,
                              comment:
                                'আমার বাবুর জন্য নিয়েছিলাম, সাইজ একদম পারফেক্ট হয়েছে এবং সেলাই ও ফিনিশিং খুবই প্রিমিয়াম। সবাইকে নেওয়ার পরামর্শ দিচ্ছি।'
                            },
                            {
                              id: `rev_${Date.now()}_3`,
                              customerName: 'মাহমুদুল হাসান রনি',
                              location: 'জিন্দাবাজার, সিলেট',
                              rating: 5,
                              comment:
                                'দাম অনুযায়ী প্রোডাক্ট ১০০ তে ১০০! আগে ডেলিভারি ম্যানের সামনে চেক করে তারপর টাকা দিয়েছি। ধন্যবাদ সেলারকে।'
                            }
                          ];
                          setFormReviewItems(prev => [...prev, ...demoPresets]);
                          showToast('৩টি প্রিমিয়াম ডেমো কাস্টমার রিভিউ যুক্ত হয়েছে!', 'success');
                        }}
                        className="px-2.5 py-1.5 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-[10px] font-extrabold cursor-pointer"
                      >
                        + ১-ক্লিকে ৩টি রেডি রিভিউ
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormReviewsEnabled(prev => !prev)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer transition-all ${
                          formReviewsEnabled
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {formReviewsEnabled ? 'রিভিউ: চালু (ON)' : 'রিভিউ: বন্ধ (OFF)'}
                      </button>
                    </div>
                  </div>

                  {formReviewsEnabled && (
                    <div className="space-y-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          রিভিউ সেকশনের শিরোনাম
                        </label>
                        <input
                          type="text"
                          value={formReviewsTitle}
                          onChange={(e) => setFormReviewsTitle(e.target.value)}
                          placeholder="সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ"
                          className="w-full min-h-[38px] p-2 bg-white border border-amber-300 rounded-lg text-xs font-bold"
                        />
                      </div>

                      {/* Add New Fake / Custom Review Form */}
                      <div className="p-3 bg-white rounded-xl border border-amber-200 space-y-2">
                        <p className="text-[11px] font-extrabold text-amber-950">
                          ✍️ নতুন কাস্টমার রিভিউ লিখুন:
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <input
                            type="text"
                            value={newRevName}
                            onChange={(e) => setNewRevName(e.target.value)}
                            placeholder="কাস্টমারের নাম"
                            className="min-h-[38px] p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold"
                          />
                          <input
                            type="text"
                            value={newRevLocation}
                            onChange={(e) => setNewRevLocation(e.target.value)}
                            placeholder="লোকেশন (যেমন: ঢাকা)"
                            className="min-h-[38px] p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                          />
                          <select
                            value={newRevRating}
                            onChange={(e) => setNewRevRating(Number(e.target.value) || 5)}
                            className="min-h-[38px] p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-amber-700"
                          >
                            <option value={5}>⭐⭐⭐⭐⭐ (৫ স্টার)</option>
                            <option value={4}>⭐⭐⭐⭐ (৪ স্টার)</option>
                            <option value={3}>⭐⭐⭐ (৩ স্টার)</option>
                          </select>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <textarea
                            rows={2}
                            value={newRevComment}
                            onChange={(e) => setNewRevComment(e.target.value)}
                            placeholder="রিভিউ কমেন্ট লিখুন..."
                            className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (!newRevName.trim() || !newRevComment.trim()) {
                                showToast('কাস্টমারের নাম এবং রিভিউ কমেন্ট লিখুন', 'error');
                                return;
                              }
                              const item: LandingReviewItem = {
                                id: `rev_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
                                customerName: newRevName.trim(),
                                location: newRevLocation.trim() || 'ঢাকা',
                                rating: newRevRating,
                                comment: newRevComment.trim(),
                                status: 'approved',
                                submittedBy: 'admin',
                                createdAt: new Date().toISOString()
                              };
                              setFormReviewItems(prev => [item, ...prev]);
                              setNewRevName('');
                              setNewRevComment('');
                              showToast('রিভিউ তালিকায় যোগ হয়েছে!', 'success');
                            }}
                            className="min-h-[38px] px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-extrabold shrink-0 cursor-pointer flex items-center justify-center gap-1"
                          >
                            <Plus className="w-4 h-4" /> রিভিউ যোগ করুন
                          </button>
                        </div>
                      </div>

                      {/* Existing Reviews List */}
                      {formReviewItems.length > 0 && (
                        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                          {formReviewItems.map((rev) => {
                            const isPending = rev.status === 'pending';
                            return (
                              <div
                                key={rev.id}
                                className={`flex flex-col sm:flex-row sm:items-start justify-between gap-2 p-2.5 border rounded-lg text-xs ${
                                  isPending
                                    ? 'bg-amber-50/90 border-amber-400 border-dashed'
                                    : 'bg-white border-amber-200'
                                }`}
                              >
                                <div className="space-y-0.5 min-w-0 flex-1">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="font-extrabold text-slate-900">{rev.customerName}</span>
                                    <span className="text-[10px] text-slate-500">({rev.location})</span>
                                    <span className="text-amber-500 font-bold">
                                      {'★'.repeat(rev.rating || 5)}
                                    </span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                                        isPending
                                          ? 'bg-amber-200 text-amber-950'
                                          : 'bg-emerald-100 text-emerald-800'
                                      }`}
                                    >
                                      {isPending ? '⏳ পেন্ডিং' : '✓ প্রকাশিত'}
                                    </span>
                                  </div>
                                  <p className="text-slate-700 text-[11px] leading-relaxed">{rev.comment}</p>
                                </div>
                                <div className="flex items-center gap-1 shrink-0 self-end sm:self-start">
                                  {isPending && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setFormReviewItems(prev =>
                                          prev.map(r =>
                                            r.id === rev.id ? { ...r, status: 'approved' } : r
                                          )
                                        );
                                        showToast('রিভিউটি অ্যাপ্রুভ করা হয়েছে! নিচে সংরক্ষণ বাটনে ক্লিক করুন।', 'success');
                                      }}
                                      className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer flex items-center gap-1"
                                      title="রিভিউ অ্যাপ্রুভ করুন"
                                    >
                                      <CheckCircle2 className="w-3 h-3" />
                                      <span>Approve</span>
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setFormReviewItems(prev => prev.filter(r => r.id !== rev.id))
                                    }
                                    className="px-2 py-1 text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded text-[10px] font-extrabold cursor-pointer flex items-center gap-1 shrink-0"
                                    title="রিভিউ ডিলিট করুন"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                    <span>ডিলিট</span>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Sticky Bottom Action Bar */}
              <div className="sticky -bottom-3.5 sm:-bottom-6 lg:-bottom-7 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md -mx-3.5 sm:-mx-6 lg:-mx-7 px-3.5 sm:px-6 lg:px-7 py-3.5 border-t border-slate-200 dark:border-slate-800 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 mt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="min-h-[42px] px-5 py-2.5 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  বাতিল করুন (Cancel)
                </button>
                <button
                  type="submit"
                  className="min-h-[42px] px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-extrabold shadow-sm cursor-pointer"
                >
                  {editingProduct ? '✓ আপডেট সংরক্ষণ করুন (Save Changes)' : '✓ পণ্য ও ছবি সংরক্ষণ করুন (Save Product)'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Camera Barcode Scanner for Product Form */}
      <CameraBarcodeScannerModal
        isOpen={showBarcodeCameraModal}
        onClose={() => setShowBarcodeCameraModal(false)}
        onDetected={(code) => {
          setFormBarcode(code);
          showToast(`বারকোড স্ক্যান হয়েছে: ${code}`, 'info');
        }}
        products={products}
        continuousModeDefault={false}
        title="নতুন পণ্যের বারকোড ক্যামেরা দিয়ে স্ক্যান করুন"
      />

      {/* Quick Stock Update & Adjustment Modal */}
      {adjustingProduct && (() => {
        const currentProdStock =
          adjustingProduct.stockByOutlet?.[currentOutlet.id] ??
          adjustingProduct.stockByOutlet?.['outlet_01'] ??
          0;
        const unitLabel = adjustingProduct.unit.split(' ')[0];
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 border border-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-emerald-700" />
                    <span>প্রোডাক্ট স্টক আপডেট করুন</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    পণ্য: <strong className="text-slate-900">{adjustingProduct.nameBn}</strong> · বর্তমান স্টক:{' '}
                    <strong className="text-emerald-700 font-mono">
                      {currentProdStock} {unitLabel}
                    </strong>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setAdjustingProduct(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mode Selector Tabs */}
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl mb-4 text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => {
                    setStockUpdateMode('set');
                    setAdjQuantity(currentProdStock);
                  }}
                  className={`py-2 px-2 rounded-lg cursor-pointer transition-all ${
                    stockUpdateMode === 'set'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  সরাসরি স্টক সেট
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStockUpdateMode('add');
                    setAdjQuantity(10);
                  }}
                  className={`py-2 px-2 rounded-lg cursor-pointer transition-all ${
                    stockUpdateMode === 'add'
                      ? 'bg-blue-700 text-white shadow-2xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  + স্টক যোগ করুন
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStockUpdateMode('subtract');
                    setAdjQuantity(1);
                    setAdjReason('দোকানে কার্টুন ছেঁড়া বা ক্ষতি');
                  }}
                  className={`py-2 px-2 rounded-lg cursor-pointer transition-all ${
                    stockUpdateMode === 'subtract'
                      ? 'bg-rose-700 text-white shadow-2xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  - স্টক কমান/ক্ষতি
                </button>
              </div>

              <form onSubmit={handleSaveAdjustment} className="space-y-3.5 text-xs">
                {stockUpdateMode === 'set' && (
                  <div className="space-y-2.5">
                    <label className="block text-slate-800 font-extrabold">
                      নতুন মোট স্টক সংখ্যা লিখুন ({unitLabel}):
                    </label>
                    <input
                      type="number"
                      min="0"
                      required
                      value={adjQuantity}
                      onChange={(e) => setAdjQuantity(Math.max(0, parseInt(e.target.value, 10) || 0))}
                      className="w-full p-3 bg-emerald-50/60 border-2 border-emerald-500 rounded-xl font-mono font-extrabold text-base text-slate-900"
                    />
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] text-slate-500 mr-1">দ্রুত যোগ:</span>
                      {[10, 25, 50, 100].map(inc => (
                        <button
                          key={inc}
                          type="button"
                          onClick={() => setAdjQuantity(prev => Math.max(0, (Number(prev) || 0) + inc))}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-800 font-mono font-bold text-[11px] border border-slate-300 cursor-pointer"
                        >
                          +{inc}
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => setAdjQuantity(0)}
                        className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-[11px] border border-rose-200 cursor-pointer ml-auto"
                      >
                        স্টক শূন্য (0) করুন
                      </button>
                    </div>
                  </div>
                )}

                {stockUpdateMode === 'add' && (
                  <div className="space-y-2.5">
                    <label className="block text-slate-800 font-extrabold">
                      কত {unitLabel} নতুন স্টক যোগ করতে চান?
                    </label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={adjQuantity}
                      onChange={(e) => setAdjQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                      className="w-full p-3 bg-blue-50/60 border-2 border-blue-500 rounded-xl font-mono font-extrabold text-base text-slate-900"
                    />
                    <p className="text-[11px] text-blue-800 bg-blue-50 p-2 rounded-lg border border-blue-200">
                      আপডেটের পর মোট স্টক হবে:{' '}
                      <strong className="font-mono">
                        {currentProdStock + (Number(adjQuantity) || 0)} {unitLabel}
                      </strong>
                    </p>
                  </div>
                )}

                {stockUpdateMode === 'subtract' && (
                  <>
                    <div>
                      <label className="block text-slate-700 font-medium mb-1">কমানোর কারণ:</label>
                      <select
                        value={adjType}
                        onChange={(e) => setAdjType(e.target.value as any)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                      >
                        <option value="damage">ভেঙ্গে যাওয়া বা ক্ষতিগ্রস্ত পণ্য</option>
                        <option value="expired">মেয়াদোত্তীর্ণ পণ্য বাতিল</option>
                        <option value="wastage">স্বাভাবিক অপচয় ও ঘাটতি</option>
                        <option value="physical_count_correction">শারীরিক গণনা সংশোধন</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        কত {unitLabel} স্টক কমাতে চান:
                      </label>
                      <input
                        type="number"
                        min="1"
                        required
                        value={adjQuantity}
                        onChange={(e) => setAdjQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                        className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">মন্তব্য / বিবরণ:</label>
                      <input
                        type="text"
                        value={adjReason}
                        onChange={(e) => setAdjReason(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                      />
                    </div>
                  </>
                )}

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setAdjustingProduct(null)}
                    className="px-4 py-2 border border-slate-300 rounded-xl text-slate-600 font-semibold cursor-pointer"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className={`px-5 py-2 text-white font-extrabold rounded-xl cursor-pointer ${
                      stockUpdateMode === 'subtract'
                        ? 'bg-rose-700 hover:bg-rose-800'
                        : stockUpdateMode === 'add'
                        ? 'bg-blue-700 hover:bg-blue-800'
                        : 'bg-emerald-700 hover:bg-emerald-800'
                    }`}
                  >
                    স্টক সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* Spin the Wheel Admin Customization & Stored Customer Numbers Modal */}
      {showSpinWheelLeadsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-[#FFFDF9] via-amber-50 to-rose-50 border-b border-amber-200 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <Gift className="w-5 h-5 text-[#c30000]" />
                  <span>স্পিন দ্য হুইল কন্ট্রোল প্যানেল — লেখা, পুরস্কার ও কাস্টমার নাম্বার ({spinWheelLeads.length})</span>
                </h3>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  কাস্টমার ওয়েবসাইটে ঢুকলে কয়েক সেকেন্ড পর অটো আসবে · ৭ দিনে বা ১ দিনে ১ বার পপআপ · সম্পূর্ণ কাস্টমাইজেবল
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowSpinWheelLeadsModal(false)}
                className="p-1.5 rounded-xl bg-white hover:bg-rose-50 text-slate-600 border border-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-4 pt-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSpinModalTab('settings')}
                  className={`px-4 py-2 rounded-t-xl text-xs font-extrabold border border-b-0 cursor-pointer transition-colors ${
                    spinModalTab === 'settings'
                      ? 'bg-white text-[#c30000] border-slate-200'
                      : 'bg-slate-100 text-slate-600 border-transparent hover:bg-slate-200/70'
                  }`}
                >
                  🎨 হুইল লেখা ও পুরস্কার সেটিংস
                </button>
                <button
                  type="button"
                  onClick={() => setSpinModalTab('leads')}
                  className={`px-4 py-2 rounded-t-xl text-xs font-extrabold border border-b-0 cursor-pointer transition-colors ${
                    spinModalTab === 'leads'
                      ? 'bg-white text-emerald-800 border-slate-200'
                      : 'bg-slate-100 text-slate-600 border-transparent hover:bg-slate-200/70'
                  }`}
                >
                  📞 কাস্টমার নাম ও নাম্বার তালিকা ({spinWheelLeads.length})
                </button>
              </div>

              <div className="pb-2">
                <button
                  type="button"
                  onClick={() => {
                    try {
                      window.localStorage.removeItem('stockmaster_spin_daily_lock_v1');
                      window.localStorage.removeItem('stockmaster_spin_reward_v1');
                      window.localStorage.removeItem('stockmaster_spin_popup_state_v2');
                    } catch {
                      // ignore
                    }
                    showToast(
                      'অ্যাডমিন ডিভাইসে স্পিন পপআপ টাইমার রিসেট হয়েছে! এখন স্টোরফ্রন্টে গেলে অটো পপআপ দেখতে পাবেন।',
                      'info'
                    );
                  }}
                  className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-[11px] font-extrabold cursor-pointer"
                >
                  🔄 আমার ডিভাইসে পপআপ টেস্ট রিসেট করুন
                </button>
              </div>
            </div>

            {spinModalTab === 'settings' ? (
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs">
                <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-3.5">
                  <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">
                    ১. পপআপের লেখা ও অটো-পপআপ সময় নির্ধারণ:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        উপরের ব্যাজ টেক্সট:
                      </label>
                      <input
                        type="text"
                        value={invSpinBadge}
                        onChange={e => setInvSpinBadge(e.target.value)}
                        placeholder="স্পেশাল লাকি ডিসকাউন্ট হুইল"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        কত সেকেন্ড পর অটো ভেসে উঠবে?
                      </label>
                      <select
                        value={invSpinDelaySec}
                        onChange={e => setInvSpinDelaySec(Number(e.target.value) || 4)}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                      >
                        <option value={2}>২ সেকেন্ড পর</option>
                        <option value={4}>৪ সেকেন্ড পর (প্রস্তাবিত)</option>
                        <option value={6}>৬ সেকেন্ড পর</option>
                        <option value={10}>১০ সেকেন্ড পর</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        একজন কাস্টমারকে কতদিনে ১ বার দেখাবে?
                      </label>
                      <select
                        value={invSpinCooldownDays}
                        onChange={e => setInvSpinCooldownDays(Number(e.target.value) || 7)}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-emerald-900"
                      >
                        <option value={7}>৭ দিনে ১ বার (প্রস্তাবিত — বারবার বিরক্ত করবে না)</option>
                        <option value={3}>৩ দিনে ১ বার</option>
                        <option value={1}>১ দিনে ১ বার</option>
                        <option value={15}>১৫ দিনে ১ বার</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        মূল শিরোনাম (Main Title):
                      </label>
                      <input
                        type="text"
                        value={invSpinTitle}
                        onChange={e => setInvSpinTitle(e.target.value)}
                        placeholder="স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        সাব-টাইটেল / বিবরণ (Subtitle):
                      </label>
                      <input
                        type="text"
                        value={invSpinSubtitle}
                        onChange={e => setInvSpinSubtitle(e.target.value)}
                        placeholder="চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-semibold text-slate-800"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">
                        ২. স্পিন হুইলে কী কী পুরস্কার থাকবে ({invSpinSlices.length} টি স্লাইস):
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        টাকা ছাড় (৳), শতাংশ ছাড় (%), ফ্রি ডেলিভারি অথবা শুভকামনা (ছাড় নেই) যোগ বা পরিবর্তন করুন
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setInvSpinSlices(DEFAULT_SPIN_WHEEL_SLICES.map(s => ({ ...s })))
                        }
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold cursor-pointer"
                      >
                        ডিফল্ট ৬টি পুরস্কার রিসেট
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setInvSpinSlices(prev => [
                            ...prev,
                            {
                              id: `sw_${Date.now()}`,
                              label: '৳৪০ স্পেশাল ছাড়',
                              shortLabel: '৳৪০ ছাড়',
                              type: 'flat',
                              value: 40,
                              color: '#e11d48',
                              code: 'SPIN40'
                            }
                          ])
                        }
                        className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold cursor-pointer"
                      >
                        + নতুন পুরস্কার যোগ করুন
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {invSpinSlices.map((slice, sIdx) => (
                      <div
                        key={slice.id || sIdx}
                        className="p-2.5 rounded-xl bg-white border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-2 items-center"
                      >
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            চাকার ভেতরের ছোট লেখা
                          </label>
                          <input
                            type="text"
                            value={slice.shortLabel}
                            onChange={e => {
                              const val = e.target.value;
                              setInvSpinSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, shortLabel: val } : it))
                              );
                            }}
                            placeholder="যেমন: ৳৫০ ছাড়"
                            className="w-full p-2 border border-slate-300 rounded-lg font-extrabold text-slate-900"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            পুরস্কারের পূর্ণ নাম
                          </label>
                          <input
                            type="text"
                            value={slice.label}
                            onChange={e => {
                              const val = e.target.value;
                              setInvSpinSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, label: val } : it))
                              );
                            }}
                            placeholder="যেমন: ৳৫০ ডিসকাউন্ট"
                            className="w-full p-2 border border-slate-300 rounded-lg font-semibold text-slate-800"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            ছাড়ের ধরন
                          </label>
                          <select
                            value={slice.type}
                            onChange={e => {
                              const nextType = e.target.value as SpinWheelSliceConfig['type'];
                              setInvSpinSlices(prev =>
                                prev.map((it, i) =>
                                  i === sIdx
                                    ? {
                                        ...it,
                                        type: nextType,
                                        value:
                                          nextType === 'free_delivery' || nextType === 'none'
                                            ? 0
                                            : it.value || 20
                                      }
                                    : it
                                )
                              );
                            }}
                            className="w-full p-2 border border-slate-300 rounded-lg font-bold text-slate-800"
                          >
                            <option value="flat">টাকা ছাড় (৳)</option>
                            <option value="percent">শতাংশ ছাড় (%)</option>
                            <option value="free_delivery">ফ্রি ডেলিভারি</option>
                            <option value="none">শুভকামনা (ছাড় নেই)</option>
                          </select>
                        </div>
                        <div className="sm:col-span-1">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            পরিমাণ
                          </label>
                          <input
                            type="number"
                            min={0}
                            disabled={slice.type === 'free_delivery' || slice.type === 'none'}
                            value={slice.value}
                            onChange={e => {
                              const val = Number(e.target.value) || 0;
                              setInvSpinSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, value: val } : it))
                              );
                            }}
                            className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold disabled:bg-slate-100"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            কুপন কোড
                          </label>
                          <input
                            type="text"
                            value={slice.code}
                            onChange={e => {
                              const val = e.target.value.toUpperCase();
                              setInvSpinSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, code: val } : it))
                              );
                            }}
                            className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold uppercase"
                          />
                        </div>
                        <div className="sm:col-span-1 flex items-end gap-1.5 pt-3 sm:pt-4">
                          <input
                            type="color"
                            value={slice.color}
                            onChange={e => {
                              const val = e.target.value;
                              setInvSpinSlices(prev =>
                                prev.map((it, i) => (i === sIdx ? { ...it, color: val } : it))
                              );
                            }}
                            className="w-8 h-8 rounded cursor-pointer border border-slate-300"
                            title="স্লাইসের রঙ"
                          />
                          <button
                            type="button"
                            disabled={invSpinSlices.length <= 2}
                            onClick={() =>
                              setInvSpinSlices(prev => prev.filter((_, i) => i !== sIdx))
                            }
                            className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 disabled:opacity-40 cursor-pointer"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setShowSpinWheelLeadsModal(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold cursor-pointer"
                  >
                    বন্ধ করুন
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleSaveSpinConfigFromInventory();
                      setShowSpinWheelLeadsModal(false);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold cursor-pointer shadow-sm"
                  >
                    সেটিংস সংরক্ষণ করুন
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={spinLeadsSearch}
                      onChange={e => setSpinLeadsSearch(e.target.value)}
                      placeholder="কাস্টমারের নাম বা মোবাইল নাম্বার দিয়ে খুঁজুন..."
                      className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:border-emerald-600"
                    />
                  </div>
                  <span className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-extrabold">
                    মোট সংরক্ষিত নাম্বার: {spinWheelLeads.length} টি
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-4">
                  {(() => {
                    const q = spinLeadsSearch.trim().toLowerCase();
                    const filtered = q
                      ? spinWheelLeads.filter(
                          l =>
                            l.name.toLowerCase().includes(q) ||
                            l.phone.toLowerCase().includes(q) ||
                            l.prizeLabel.toLowerCase().includes(q)
                        )
                      : spinWheelLeads;

                    if (filtered.length === 0) {
                      return (
                        <div className="py-12 text-center space-y-2">
                          <Gift className="w-10 h-10 text-slate-300 mx-auto" />
                          <p className="text-sm font-bold text-slate-700">
                            এখনো কোনো স্পিন হুইল কাস্টমার নাম্বার জমা হয়নি
                          </p>
                          <p className="text-xs text-slate-500">
                            কাস্টমার ওয়েবসাইটে নাম ও মোবাইল নাম্বার দিয়ে স্পিন করলেই এখানে স্বয়ংক্রিয়ভাবে স্টোর হয়ে যাবে।
                          </p>
                        </div>
                      );
                    }

                    return filtered.map((lead, idx) => (
                      <div
                        key={lead.id}
                        className="py-3 px-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:bg-slate-50 rounded-xl transition-colors"
                      >
                        <div className="space-y-0.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[11px] font-mono font-bold text-slate-400">
                              #{idx + 1}
                            </span>
                            <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                              {lead.name}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-lg bg-emerald-50 border border-emerald-200 font-mono font-extrabold text-xs text-emerald-800">
                              {lead.phone}
                            </span>
                            <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 font-extrabold text-[11px]">
                              🎁 {lead.prizeLabel} ({lead.prizeCode})
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500">
                            তারিখ: {lead.dateKey} · সময়: {new Date(lead.createdAt).toLocaleString('bn-BD')}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard?.writeText(lead.phone).catch(() => {});
                              showToast(`মোবাইল নাম্বার (${lead.phone}) কপি হয়েছে!`, 'success');
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Copy className="w-3 h-3" /> কপি
                          </button>
                          <a
                            href={`tel:${lead.phone}`}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1"
                          >
                            <PhoneCall className="w-3 h-3" /> কল
                          </a>
                          <button
                            type="button"
                            onClick={() => handleDeleteSpinLeadFromInventory(lead.id)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                            title="এন্ট্রি মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ));
                  })()}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Central Customer Reviews Approval & Delete Manager Modal */}
      {showReviewsManagerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-page-rise">
          <div className="bg-white rounded-2xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 text-slate-950 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-white/90 text-amber-600 flex items-center justify-center shrink-0 shadow-xs">
                  <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold leading-tight">
                    কাস্টমার রিভিউ অ্যাপ্রুভাল ও ডিলিট ম্যানেজার
                  </h3>
                  <p className="text-[11px] text-slate-800 font-semibold mt-0.5">
                    কাস্টমার কোনো প্রোডাক্টে রিভিউ দিলে তা এখানে পেন্ডিং থাকবে। আপনি Approve করলেই কেবল ওয়েবসাইটে পাবলিশ হবে।
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowReviewsManagerModal(false)}
                className="p-1.5 rounded-xl bg-white/70 hover:bg-white text-slate-900 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter Tabs & Search Bar */}
            <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setReviewsManagerFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer transition-all ${
                    reviewsManagerFilter === 'all'
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  সব রিভিউ ({allProductReviewsList.length})
                </button>
                <button
                  type="button"
                  onClick={() => setReviewsManagerFilter('pending')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer transition-all flex items-center gap-1.5 ${
                    reviewsManagerFilter === 'pending'
                      ? 'bg-amber-500 text-slate-950 shadow-2xs'
                      : 'bg-white text-amber-900 border border-amber-300 hover:bg-amber-50'
                  }`}
                >
                  <span>⏳ পেন্ডিং রিভিউ ({pendingReviewsCount})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setReviewsManagerFilter('approved')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer transition-all ${
                    reviewsManagerFilter === 'approved'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-50'
                  }`}
                >
                  ✓ প্রকাশিত ({allProductReviewsList.length - pendingReviewsCount})
                </button>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative flex-1 sm:w-56">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={reviewsManagerSearch}
                    onChange={e => setReviewsManagerSearch(e.target.value)}
                    placeholder="নাম, পণ্য বা কমেন্ট খুঁজুন..."
                    className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:border-amber-500"
                  />
                </div>
                {pendingReviewsCount > 0 && (
                  <button
                    type="button"
                    onClick={async () => {
                      const productsWithPending = products.filter(
                        p =>
                          Array.isArray(p.landingReviewItems) &&
                          p.landingReviewItems.some(r => r.status === 'pending')
                      );
                      for (const prod of productsWithPending) {
                        const updatedList = (prod.landingReviewItems || []).map(r => ({
                          ...r,
                          status: 'approved' as const
                        }));
                        await updateProduct(prod.id, { landingReviewItems: updatedList });
                      }
                      showToast('সব পেন্ডিং রিভিউ অ্যাপ্রুভ ও পাবলিশ করা হয়েছে!', 'success');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold cursor-pointer shrink-0 shadow-2xs"
                  >
                    ✓ সব Approve করুন
                  </button>
                )}
              </div>
            </div>

            {/* Reviews List Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {(() => {
                const q = reviewsManagerSearch.trim().toLowerCase();
                const filtered = allProductReviewsList.filter(({ product, review }) => {
                  if (reviewsManagerFilter === 'pending' && review.status !== 'pending') {
                    return false;
                  }
                  if (reviewsManagerFilter === 'approved' && review.status === 'pending') {
                    return false;
                  }
                  if (!q) return true;
                  return (
                    review.customerName.toLowerCase().includes(q) ||
                    review.comment.toLowerCase().includes(q) ||
                    (review.location || '').toLowerCase().includes(q) ||
                    product.nameBn.toLowerCase().includes(q) ||
                    product.sku.toLowerCase().includes(q)
                  );
                });

                if (filtered.length === 0) {
                  return (
                    <div className="py-12 text-center space-y-2">
                      <Star className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-sm font-bold text-slate-700">
                        {reviewsManagerFilter === 'pending'
                          ? 'বর্তমানে অ্যাপ্রুভালের অপেক্ষায় কোনো পেন্ডিং রিভিউ নেই!'
                          : 'কোনো কাস্টমার রিভিউ পাওয়া যায়নি'}
                      </p>
                      <p className="text-xs text-slate-500">
                        কাস্টমার কোনো প্রোডাক্ট পেজে রিভিউ জমা দিলে তা এখানে সাথে সাথে চলে আসবে।
                      </p>
                    </div>
                  );
                }

                return filtered.map(({ product, review }) => {
                  const isPending = review.status === 'pending';
                  return (
                    <div
                      key={`${product.id}_${review.id}`}
                      className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                        isPending
                          ? 'bg-amber-50/90 border-2 border-dashed border-amber-400'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="space-y-1.5 min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-[11px] font-extrabold text-slate-800">
                            📦 {product.nameBn} ({product.sku})
                          </span>
                          {isPending ? (
                            <span className="px-2 py-0.5 rounded-md bg-amber-300 text-amber-950 text-[10px] font-extrabold">
                              ⏳ পেন্ডিং (Approve অপেক্ষায়)
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-extrabold">
                              ✓ প্রকাশিত (Approved)
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                            {review.customerName}
                          </span>
                          {review.location && (
                            <span className="text-xs text-slate-500">· {review.location}</span>
                          )}
                          <span className="text-amber-500 font-bold text-xs">
                            {'★'.repeat(review.rating || 5)}
                          </span>
                        </div>

                        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                          “{review.comment}”
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {isPending ? (
                          <button
                            type="button"
                            onClick={async () => {
                              const currentItems = Array.isArray(product.landingReviewItems)
                                ? product.landingReviewItems
                                : [];
                              const updated = currentItems.map(r =>
                                r.id === review.id ? { ...r, status: 'approved' as const } : r
                              );
                              await updateProduct(product.id, { landingReviewItems: updated });
                              showToast(
                                `"${review.customerName}"-এর রিভিউটি অ্যাপ্রুভ ও পাবলিশ করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Approve করুন</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={async () => {
                              const currentItems = Array.isArray(product.landingReviewItems)
                                ? product.landingReviewItems
                                : [];
                              const updated = currentItems.map(r =>
                                r.id === review.id ? { ...r, status: 'pending' as const } : r
                              );
                              await updateProduct(product.id, { landingReviewItems: updated });
                              showToast('রিভিউটি আন-পাবলিশ (পেন্ডিং) করা হয়েছে', 'info');
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[11px] font-bold cursor-pointer"
                            title="ওয়েবসাইট থেকে হাইড / পেন্ডিং করুন"
                          >
                            হাইড করুন
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            confirmDelete({
                              title: 'কাস্টমার রিভিউ ডিলিট করতে চান?',
                              itemName: `${review.name} — "${(review.comment || '').slice(0, 45)}${(review.comment || '').length > 45 ? '...' : ''}"`,
                              message: 'এই রিভিউটি স্থায়ীভাবে ডিলিট হয়ে যাবে এবং প্রোডাক্ট পেজে আর দেখা যাবে না।',
                              confirmLabel: 'হ্যাঁ, রিভিউ ডিলিট করুন',
                              onConfirm: async () => {
                                const currentItems = Array.isArray(product.landingReviewItems)
                                  ? product.landingReviewItems
                                  : [];
                                const filteredItems = currentItems.filter(r => r.id !== review.id);
                                await updateProduct(product.id, { landingReviewItems: filteredItems });
                                showToast('রিভিউটি স্থায়ীভাবে ডিলিট করা হয়েছে!', 'info');
                              }
                            });
                          }}
                          className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 text-xs font-extrabold flex items-center gap-1 cursor-pointer"
                          title="রিভিউ ডিলিট করুন"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>ডিলিট</span>
                        </button>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>

            <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                type="button"
                onClick={() => setShowReviewsManagerModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
