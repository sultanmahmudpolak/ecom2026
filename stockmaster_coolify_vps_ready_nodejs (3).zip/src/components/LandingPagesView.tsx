import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Product,
  ProductVariant,
  LandingReviewItem,
  LandingTrustItem,
  LandingSizeChartRow,
  SpinWheelLead,
  SpinWheelSliceConfig,
  SpinWheelConfig,
  LandingFloatingBtnAnimation,
  LandingVariantDesign,
  LandingImageBadgeDesign,
  OrderCelebrationStyle,
  LandingPageTemplate,
  LandingShowcaseProductItem
} from '../types';
import { OrderCelebrationOverlay } from './OrderCelebrationOverlay';
import { ProductThumbnail } from './ProductThumbnail';
import { processUploadedProductImage } from '../utils/imageUploader';
import {
  buildLandingPagePath,
  getProductLandingSlug,
  slugifyLandingText,
  DEFAULT_LANDING_TRUST_ITEMS,
  DEFAULT_LANDING_SIZE_CHART_HEADERS,
  DEFAULT_LANDING_SIZE_CHART_ROWS,
  DEFAULT_FOOTER_WARNING_TEXT,
  DEFAULT_LANDING_SPIN_WHEEL_SLICES,
  DEFAULT_LANDING_SPIN_WHEEL_CONFIG,
  LANDING_VARIANT_DESIGN_OPTIONS,
  LANDING_IMAGE_BADGE_DESIGN_OPTIONS
} from '../utils/landingConstants';
import {
  Plus,
  Search,
  Edit,
  X,
  Trash2,
  Upload,
  Copy,
  Check,
  ExternalLink,
  Rocket,
  Layers,
  ShoppingBag,
  Sparkles,
  Truck,
  Link2,
  RefreshCw,
  PhoneCall,
  MessageCircle,
  Star,
  BadgeCheck,
  ShieldCheck,
  Clock,
  Play,
  Ruler,
  Bell,
  Flame,
  AlertTriangle,
  Image as ImageIcon,
  Eye,
  Gift,
  Download,
  CheckCircle2
} from 'lucide-react';
import { exportToCsv, exportToExcel } from '../config/api';
import {
  syncSingleProductToWordPress,
  buildVariantSkuCode
} from '../utils/wordpressOrderSync';

interface LandingPagesViewProps {
  onPreviewLandingProduct: (product: Product) => void;
}

export const LandingPagesView: React.FC<LandingPagesViewProps> = ({
  onPreviewLandingProduct
}) => {
  const {
    categories,
    brands,
    products,
    onlineOrders,
    currentOutlet,
    currentBusiness,
    updateBusiness,
    addProduct,
    updateProduct,
    deleteProduct,
    formatCurrency,
    showToast,
    confirmDelete
  } = useApp();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Add / Edit Modal State
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form Fields (Same capabilities as regular product upload + Landing Page URL Slug + Template 1 / Template 2)
  const [formLandingTemplate, setFormLandingTemplate] = useState<LandingPageTemplate>('template_1');
  const [formShowcaseTitle, setFormShowcaseTitle] = useState<string>(
    'আমাদের এক্সক্লুসিভ কালেকশন — পছন্দের ডিজাইনটি বেছে নিন'
  );
  const [formShowcaseSubtitle, setFormShowcaseSubtitle] = useState<string>(
    'প্রতিটি ড্রেস ১০০% প্রিমিয়াম ফেব্রিক, আরামদায়ক ফিট এবং নিখুঁত ফিনিশিংয়ের নিশ্চয়তা'
  );
  const [formShowcaseSelectBtnEnabled, setFormShowcaseSelectBtnEnabled] = useState<boolean>(true);
  const [formShowcaseSelectBtnText, setFormShowcaseSelectBtnText] = useState<string>('সাইজ পছন্দ করুন');
  const [formShowcaseMobileTwoCols, setFormShowcaseMobileTwoCols] = useState<boolean>(false);
  const [formShowcaseItems, setFormShowcaseItems] = useState<LandingShowcaseProductItem[]>([]);
  const [showcaseProductSearch, setShowcaseProductSearch] = useState<string>('');

  const [formNameBn, setFormNameBn] = useState<string>('');
  const [formNameEn, setFormNameEn] = useState<string>('');
  const [formLandingSlug, setFormLandingSlug] = useState<string>('');
  const [formSku, setFormSku] = useState<string>('');
  const [formWpProductId, setFormWpProductId] = useState<string>('');
  const [formCategory, setFormCategory] = useState<string>(categories[0]?.id || 'cat_01');
  const [formBrand, setFormBrand] = useState<string>(brands[0]?.id || 'brand_01');
  const [formUnit, setFormUnit] = useState<string>('প্যাক (Pack)');
  const [formPurchasePrice, setFormPurchasePrice] = useState<number>(300);
  const [formRegularPrice, setFormRegularPrice] = useState<number>(550);
  const [formDiscountPrice, setFormDiscountPrice] = useState<string>('450');
  const [formInitialStock, setFormInitialStock] = useState<number>(100);
  const [formIsOutOfStock, setFormIsOutOfStock] = useState<boolean>(false);
  const [formFreeDelivery, setFormFreeDelivery] = useState<boolean>(false);
  const [formImage, setFormImage] = useState<string>('');
  const [formGalleryImages, setFormGalleryImages] = useState<string[]>([]);
  const [newGalleryUrl, setNewGalleryUrl] = useState<string>('');
  const [formDescription, setFormDescription] = useState<string>('');
  const [formVariants, setFormVariants] = useState<ProductVariant[]>([]);
  const [formBadgeText, setFormBadgeText] = useState<string>('১০০% প্রিমিয়াম ও অরিজিনাল প্রোডাক্ট');
  const [formVariantTitle, setFormVariantTitle] = useState<string>('পছন্দের সাইজ / বয়স নির্বাচন করুন:');
  const [formVariantStyle, setFormVariantStyle] = useState<LandingVariantDesign>(
    currentBusiness.landingVariantStyle || 'classic_radio_list'
  );
  const [formVariantShowPrice, setFormVariantShowPrice] = useState<boolean>(
    Boolean(currentBusiness.landingVariantShowPrice)
  );
  const [formImageBadgeEnabled, setFormImageBadgeEnabled] = useState<boolean>(
    currentBusiness.landingImageBadgeEnabled !== false
  );
  const [formImageBadgeStyle, setFormImageBadgeStyle] = useState<LandingImageBadgeDesign>(
    currentBusiness.landingImageBadgeStyle || 'classic_red'
  );

  // Product Features & Fabric Details Section (ON/OFF + Editable Texts & Topics)
  const [formFeaturesEnabled, setFormFeaturesEnabled] = useState<boolean>(true);
  const [formFeaturesBadgeEnabled, setFormFeaturesBadgeEnabled] = useState<boolean>(true);
  const [formFeaturesBadgeText, setFormFeaturesBadgeText] = useState<string>('প্রিমিয়াম কোয়ালিটি গ্যারান্টি');
  const [formHighlightsTitleEnabled, setFormHighlightsTitleEnabled] = useState<boolean>(true);
  const [formHighlightsTitle, setFormHighlightsTitle] = useState<string>('ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:');
  const [newFeatureTopicText, setNewFeatureTopicText] = useState<string>('');

  // Trust & Guarantee Topics Section below Details (ON/OFF + Editable Texts & Topics)
  const [formTrustSectionEnabled, setFormTrustSectionEnabled] = useState<boolean>(true);
  const [formTrustBadgeEnabled, setFormTrustBadgeEnabled] = useState<boolean>(true);
  const [formTrustBadgeText, setFormTrustBadgeText] = useState<string>('১০০% বিশ্বস্ত ও নিরাপদ শপিং');
  const [formTrustTitle, setFormTrustTitle] = useState<string>('কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?');
  const [formTrustItems, setFormTrustItems] = useState<LandingTrustItem[]>(
    DEFAULT_LANDING_TRUST_ITEMS.map(item => ({ ...item }))
  );

  // Top Animated Heading Before Product Image (ON/OFF + Animation ON/OFF + Style & Theme)
  const [formTopHeadingEnabled, setFormTopHeadingEnabled] = useState<boolean>(true);
  const [formTopHeadingAnimation, setFormTopHeadingAnimation] = useState<boolean>(true);
  const [formTopHeadingText, setFormTopHeadingText] = useState<string>('');
  const [formTopHeadingSubtext, setFormTopHeadingSubtext] = useState<string>('সীমিত সময়ের মেগা অফার • বিশেষ ছাড় চলছে!');
  const [formTopHeadingTheme, setFormTopHeadingTheme] = useState<'emerald' | 'crimson' | 'midnight' | 'light'>('emerald');
  const [formTopHeadingAnimStyle, setFormTopHeadingAnimStyle] = useState<'shimmer' | 'bounce' | 'glow'>('shimmer');

  // Elementor-Style Top Animated Regular & Offer Price Banner at the Start of Landing Page (ON/OFF + Animation ON/OFF + Speed + Theme + Style + Labels)
  const [formTopPriceBannerEnabled, setFormTopPriceBannerEnabled] = useState<boolean>(true);
  const [formTopPriceAnimationEnabled, setFormTopPriceAnimationEnabled] = useState<boolean>(true);
  const [formTopPriceAnimationSpeed, setFormTopPriceAnimationSpeed] = useState<'slow' | 'normal' | 'fast' | 'ultra_fast'>('normal');
  const [formTopPriceBannerTheme, setFormTopPriceBannerTheme] = useState<'emerald' | 'crimson' | 'midnight' | 'amber' | 'light'>('emerald');
  const [formTopPriceHighlightStyle, setFormTopPriceHighlightStyle] = useState<'circle' | 'underline' | 'burst'>('circle');
  const [formTopRegularPriceLabel, setFormTopRegularPriceLabel] = useState<string>('পূর্বের মূল্য —');
  const [formTopOfferPriceLabel, setFormTopOfferPriceLabel] = useState<string>('আজকের অফার মূল্য —');
  const [formTopOfferPricePrefix, setFormTopOfferPricePrefix] = useState<string>('মাত্র');

  // Banner 1 (Top of Landing Page) & Banner 2 (Before Video Section) Custom Image Upload Sections (ON/OFF + Image Upload + Title)
  const [formPromoBannerEnabled, setFormPromoBannerEnabled] = useState<boolean>(false);
  const [formPromoBannerImage, setFormPromoBannerImage] = useState<string>('');
  const [formPromoBannerPosition, setFormPromoBannerPosition] = useState<'top' | 'after_hero'>('top');
  const [formPromoBannerTitle, setFormPromoBannerTitle] = useState<string>('');

  const [formPromoBanner2Enabled, setFormPromoBanner2Enabled] = useState<boolean>(false);
  const [formPromoBanner2Image, setFormPromoBanner2Image] = useState<string>('');
  const [formPromoBanner2Title, setFormPromoBanner2Title] = useState<string>('');

  // Evergreen Offer Countdown Timer (ON/OFF + Hours Duration + Auto-Restart Loop + Label + Position)
  const [formCountdownEnabled, setFormCountdownEnabled] = useState<boolean>(true);
  const [formCountdownHours, setFormCountdownHours] = useState<number>(9);
  const [formCountdownTitle, setFormCountdownTitle] = useState<string>('স্পেশাল অফার শেষ হতে বাকি:');
  const [formCountdownPosition, setFormCountdownPosition] = useState<'hero_info' | 'top_heading'>('hero_info');

  // 1. Product Video / YouTube / Reels Section (ON/OFF + URL + Title)
  const [formVideoEnabled, setFormVideoEnabled] = useState<boolean>(true);
  const [formVideoTitle, setFormVideoTitle] = useState<string>('প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:');
  const [formVideoSubtitle, setFormVideoSubtitle] = useState<string>('১০০% অরিজিনাল প্রোডাক্টের রিয়েল ভিডিও শোকেস');
  const [formVideoUrl, setFormVideoUrl] = useState<string>('');

  // 2. Size Chart / Measurement Guide Section (Separate ON/OFF for Variation Popup vs Full Body Chart + Headers + Rows + Optional Image)
  const [formSizeChartEnabled, setFormSizeChartEnabled] = useState<boolean>(true);
  const [formBodySizeChartEnabled, setFormBodySizeChartEnabled] = useState<boolean>(true);
  const [formLandingSpinWheelEnabled, setFormLandingSpinWheelEnabled] = useState<boolean>(true);
  const [formFloatingBtnPriceEnabled, setFormFloatingBtnPriceEnabled] = useState<boolean>(true);
  const [formFloatingBtnAnimation, setFormFloatingBtnAnimation] = useState<LandingFloatingBtnAnimation>('jump');
  const [formSizeChartTitle, setFormSizeChartTitle] = useState<string>('সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):');
  const [formSizeChartSubtitle, setFormSizeChartSubtitle] = useState<string>('সঠিক সাইজ নির্বাচন করতে নিচের মাপগুলো দেখে নিন');
  const [formSizeChartHeaders, setFormSizeChartHeaders] = useState<[string, string, string]>([
    ...DEFAULT_LANDING_SIZE_CHART_HEADERS
  ]);
  const [formSizeChartRows, setFormSizeChartRows] = useState<LandingSizeChartRow[]>(
    DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }))
  );
  const [formSizeChartImage, setFormSizeChartImage] = useState<string>('');

  // 3. Live Recent Order Notification Popup (Social Proof — ON/OFF + Time Gap + Custom Buyers)
  const [formSocialProofEnabled, setFormSocialProofEnabled] = useState<boolean>(true);
  const [formSocialProofIntervalSec, setFormSocialProofIntervalSec] = useState<number>(16);
  const [formSocialProofCustomText, setFormSocialProofCustomText] = useState<string>('');
  const [formLiveViewersEnabled, setFormLiveViewersEnabled] = useState<boolean>(true);
  const [formScarcityEnabled, setFormScarcityEnabled] = useState<boolean>(true);
  const [formScarcityCount, setFormScarcityCount] = useState<number>(10);

  // Top Header Bar (Logo + Phone Number Bar) & Call / WhatsApp Buttons (Enable / Disable + Optional Custom Numbers)
  const [formTopHeaderEnabled, setFormTopHeaderEnabled] = useState<boolean>(true);
  const [formShowCallBtn, setFormShowCallBtn] = useState<boolean>(true);
  const [formShowWhatsappBtn, setFormShowWhatsappBtn] = useState<boolean>(true);
  const [formCallPhone, setFormCallPhone] = useState<string>('');
  const [formWhatsappPhone, setFormWhatsappPhone] = useState<string>('');

  // Optional Customer Reviews Section (Enable / Disable + Slider Mode + Screenshot Images + Written Reviews + Circular Avatar)
  const [formReviewsEnabled, setFormReviewsEnabled] = useState<boolean>(false);
  const [formReviewsSliderEnabled, setFormReviewsSliderEnabled] = useState<boolean>(true);
  const [formReviewsTitle, setFormReviewsTitle] = useState<string>('সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ');
  const [formReviewImages, setFormReviewImages] = useState<string[]>([]);
  const [formReviewItems, setFormReviewItems] = useState<LandingReviewItem[]>([]);
  const [newReviewName, setNewReviewName] = useState<string>('');
  const [newReviewLocation, setNewReviewLocation] = useState<string>('');
  const [newReviewComment, setNewReviewComment] = useState<string>('');
  const [newReviewAvatar, setNewReviewAvatar] = useState<string>('');

  // Footer Anti-Fake Order Warning Notice (ON/OFF + Editable Multi-Line Text)
  const [formFooterWarningEnabled, setFormFooterWarningEnabled] = useState<boolean>(true);
  const [formFooterWarningText, setFormFooterWarningText] = useState<string>(DEFAULT_FOOTER_WARNING_TEXT);

  // Footer Developer Credit Settings (ON/OFF + Custom Name & Link)
  const [formDevCreditEnabled, setFormDevCreditEnabled] = useState<boolean>(
    currentBusiness.developerCreditEnabled !== false
  );
  const [formDevCreditName, setFormDevCreditName] = useState<string>(
    currentBusiness.developerCreditName ?? 'Web Studio BD'
  );
  const [formDevCreditLink, setFormDevCreditLink] = useState<string>(
    currentBusiness.developerCreditLink ?? 'https://example.com'
  );

  // Custom Variation Builder Inputs
  const [newVarLabel, setNewVarLabel] = useState<string>('');
  const [newVarSku, setNewVarSku] = useState<string>('');
  const [newVarWpVariationId, setNewVarWpVariationId] = useState<string>('');
  const [newVarRegularPrice, setNewVarRegularPrice] = useState<string>('');
  const [newVarRetailPrice, setNewVarRetailPrice] = useState<string>('');
  const [newVarPurchasePrice, setNewVarPurchasePrice] = useState<string>('');

  const [syncingProductId, setSyncingProductId] = useState<string | null>(null);
  const [isSyncingAllWp, setIsSyncingAllWp] = useState<boolean>(false);
  const [isUploadingImage, setIsUploadingImage] = useState<boolean>(false);
  const mainImageInputRef = useRef<HTMLInputElement | null>(null);
  const galleryImageInputRef = useRef<HTMLInputElement | null>(null);
  const reviewImageInputRef = useRef<HTMLInputElement | null>(null);
  const newReviewAvatarInputRef = useRef<HTMLInputElement | null>(null);
  const existingReviewAvatarInputRef = useRef<HTMLInputElement | null>(null);
  const editingAvatarReviewIdxRef = useRef<number | null>(null);
  const sizeChartImageInputRef = useRef<HTMLInputElement | null>(null);
  const promoBannerInputRef = useRef<HTMLInputElement | null>(null);
  const promoBanner2InputRef = useRef<HTMLInputElement | null>(null);

  // ============================================================================
  // SEPARATE LANDING PAGE SPIN THE WHEEL & FALLING SNOW DASHBOARD CONTROL STATE
  // ============================================================================
  const globalLandingSpinEnabled = currentBusiness.landingSpinWheelEnabled !== false;
  const globalLandingWinterTheme =
    currentBusiness.landingWinterThemeEnabled !== undefined
      ? Boolean(currentBusiness.landingWinterThemeEnabled)
      : false;
  const globalLandingSnowEnabled =
    currentBusiness.landingSnowfallEnabled !== undefined
      ? currentBusiness.landingSnowfallEnabled !== false
      : currentBusiness.winterSnowfallEnabled !== false;
  const landingSnowfallIntensity = Math.max(
    10,
    Math.min(
      100,
      Number(
        currentBusiness.landingSnowfallIntensity ??
          currentBusiness.winterSnowfallIntensity ??
          50
      )
    )
  );
  const landingSnowfallSpeed = Math.max(
    30,
    Math.min(
      200,
      Number(
        currentBusiness.landingSnowfallSpeed ??
          currentBusiness.winterSnowfallSpeed ??
          100
      )
    )
  );
  const landingSnowfallAutoOffSec = Math.max(
    0,
    Number(
      currentBusiness.landingSnowfallAutoOffSec ??
        currentBusiness.winterSnowfallAutoOffSec ??
        0
    )
  );
  const [showLandingSnowControlCard, setShowLandingSnowControlCard] = useState(false);

  // 🎉 Global Landing Page Order Celebration State & Live Preview Test Trigger
  const globalLandingConfettiEnabled =
    currentBusiness.landingOrderConfettiEnabled !== undefined
      ? currentBusiness.landingOrderConfettiEnabled !== false
      : currentBusiness.storefrontOrderConfettiEnabled !== false;
  const globalLandingConfettiStyle: OrderCelebrationStyle =
    currentBusiness.landingOrderConfettiStyle ||
    currentBusiness.storefrontOrderConfettiStyle ||
    'dual_cannon_badge';
  const globalLandingConfettiBadgeEnabled =
    currentBusiness.landingOrderCelebrationBadgeEnabled !== undefined
      ? currentBusiness.landingOrderCelebrationBadgeEnabled !== false
      : currentBusiness.storefrontOrderCelebrationBadgeEnabled !== false;

  const [showLandingCelebrationCard, setShowLandingCelebrationCard] = useState(false);
  const [isAdminTestCelebrationActive, setIsAdminTestCelebrationActive] = useState(false);
  const [adminTestCelebrationSeed, setAdminTestCelebrationSeed] = useState(0);
  const adminTestCelebrationTimerRef = useRef<number | null>(null);

  const triggerAdminTestCelebration = () => {
    if (adminTestCelebrationTimerRef.current) {
      window.clearTimeout(adminTestCelebrationTimerRef.current);
    }
    setAdminTestCelebrationSeed(prev => prev + 1);
    setIsAdminTestCelebrationActive(true);
    adminTestCelebrationTimerRef.current = window.setTimeout(() => {
      setIsAdminTestCelebrationActive(false);
      adminTestCelebrationTimerRef.current = null;
    }, 2600);
  };

  const landingSpinWheelConfig: Required<SpinWheelConfig> = useMemo(() => {
    const raw = currentBusiness.landingSpinWheelConfig;
    const rawSlices =
      raw?.slices && Array.isArray(raw.slices) && raw.slices.length >= 2
        ? raw.slices
        : DEFAULT_LANDING_SPIN_WHEEL_SLICES;
    const hasExplicitLockState = rawSlices.some(s => typeof s.locked === 'boolean');
    const validSlices = hasExplicitLockState
      ? rawSlices
      : rawSlices.map((s, idx) => ({
          ...s,
          locked:
            s.id === 'lp_sw_4' ||
            s.id === 'lp_sw_5' ||
            (!['lp_sw_1', 'lp_sw_2', 'lp_sw_3', 'lp_sw_6'].includes(s.id) &&
              (idx === 3 || idx === 4))
        }));
    return {
      badgeText: raw?.badgeText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.badgeText || 'স্পেশাল লাকি ডিসকাউন্ট হুইল',
      titleText: raw?.titleText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.titleText || 'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
      subtitleText: raw?.subtitleText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.subtitleText || 'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
      claimButtonText: raw?.claimButtonText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.claimButtonText || 'ডিসকাউন্ট নিয়ে অর্ডার করুন',
      autoPopupDelaySec:
        typeof raw?.autoPopupDelaySec === 'number' && raw.autoPopupDelaySec >= 1
          ? raw.autoPopupDelaySec
          : DEFAULT_LANDING_SPIN_WHEEL_CONFIG.autoPopupDelaySec || 4,
      cooldownDays:
        typeof raw?.cooldownDays === 'number' && raw.cooldownDays >= 1
          ? raw.cooldownDays
          : DEFAULT_LANDING_SPIN_WHEEL_CONFIG.cooldownDays || 7,
      slices: validSlices
    };
  }, [currentBusiness.landingSpinWheelConfig]);

  const [showLandingSpinAdminModal, setShowLandingSpinAdminModal] = useState<boolean>(false);
  const [landingSpinAdminTab, setLandingSpinAdminTab] = useState<'settings' | 'leads'>('settings');
  const [landingSpinConfigDraft, setLandingSpinConfigDraft] = useState<SpinWheelConfig>(landingSpinWheelConfig);
  const [landingSpinLeadSearch, setLandingSpinLeadSearch] = useState<string>('');

  const storedLandingSpinLeads = useMemo<SpinWheelLead[]>(() => {
    const deletedSet = new Set(currentBusiness.deletedSpinLeadIds || []);
    const businessLeads = Array.isArray(currentBusiness.landingSpinWheelLeads)
      ? currentBusiness.landingSpinWheelLeads
      : [];
    let localLeads: SpinWheelLead[] = [];
    try {
      const raw = window.localStorage.getItem('lp_spin_wheel_leads_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) localLeads = parsed;
      }
    } catch {
      // ignore
    }
    const mergedMap = new Map<string, SpinWheelLead>();
    [...businessLeads, ...localLeads].forEach(item => {
      if (item && item.id && !deletedSet.has(item.id)) mergedMap.set(item.id, item);
    });
    return Array.from(mergedMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [
    currentBusiness.landingSpinWheelLeads,
    currentBusiness.deletedSpinLeadIds,
    showLandingSpinAdminModal
  ]);

  const filteredLandingSpinLeads = useMemo(() => {
    const q = landingSpinLeadSearch.trim().toLowerCase();
    if (!q) return storedLandingSpinLeads;
    return storedLandingSpinLeads.filter(
      l =>
        (l.customerName || l.name || '').toLowerCase().includes(q) ||
        (l.customerPhone || l.phone || '').toLowerCase().includes(q) ||
        (l.rewardLabel || l.prizeLabel || '').toLowerCase().includes(q) ||
        (l.couponCode || l.prizeCode || '').toLowerCase().includes(q)
    );
  }, [storedLandingSpinLeads, landingSpinLeadSearch]);

  const handleSaveLandingSpinConfig = () => {
    const cleanedSlices = (landingSpinConfigDraft.slices || [])
      .map((s, idx) => ({
        ...s,
        id: s.id || `lp_sw_${idx + 1}`,
        shortLabel: s.shortLabel.trim() || s.label.trim() || `অফার ${idx + 1}`,
        label: s.label.trim() || s.shortLabel.trim() || `অফার ${idx + 1}`,
        code: (s.code || `LP${idx + 1}`).trim().toUpperCase(),
        value: Number(s.value) || 0,
        locked: Boolean(s.locked)
      }))
      .filter(s => s.shortLabel !== '');

    if (cleanedSlices.length < 2) {
      showToast('হুইলে কমপক্ষে ২টি অফার স্লাইস থাকতে হবে', 'error');
      return;
    }

    if (cleanedSlices.every(s => s.locked)) {
      showToast('সবগুলো অফার লক রাখা যাবে না! কমপক্ষে ১টি অফার আনলক রাখুন যাতে কাস্টমার জিততে পারে।', 'error');
      return;
    }

    const updatedConfig: SpinWheelConfig = {
      ...landingSpinConfigDraft,
      badgeText:
        (landingSpinConfigDraft.badgeText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.badgeText,
      titleText:
        (landingSpinConfigDraft.titleText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.titleText,
      subtitleText:
        (landingSpinConfigDraft.subtitleText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.subtitleText,
      autoPopupDelaySec: Math.max(1, Number(landingSpinConfigDraft.autoPopupDelaySec) || 4),
      cooldownDays: Math.max(1, Number(landingSpinConfigDraft.cooldownDays) || 7),
      slices: cleanedSlices
    };

    updateBusiness({ landingSpinWheelConfig: updatedConfig });
    showToast('ল্যান্ডিং পেজের স্পিন হুইল সেটিংস সংরক্ষিত হয়েছে!', 'success');
  };

  const handleDeleteLandingSpinLead = (leadId: string) => {
    const targetLead = storedLandingSpinLeads.find(l => l.id === leadId);
    confirmDelete({
      title: 'স্পিন হুইল এন্ট্রি মুছে ফেলতে চান?',
      itemName: targetLead
        ? `${targetLead.customerName || targetLead.name || 'Customer'} (${targetLead.customerPhone || targetLead.phone || ''})`
        : undefined,
      message: 'এই কাস্টমারের ল্যান্ডিং পেজ স্পিন হুইল এন্ট্রিটি মুছে ফেলা হবে।',
      confirmLabel: 'হ্যাঁ, মুছে ফেলুন',
      onConfirm: () => {
        try {
          const updated = storedLandingSpinLeads.filter(l => l.id !== leadId);
          const nextDeletedIds = Array.from(
            new Set([...(currentBusiness.deletedSpinLeadIds || []), leadId])
          );
          window.localStorage.setItem('lp_spin_wheel_leads_v1', JSON.stringify(updated));
          updateBusiness({
            landingSpinWheelLeads: updated,
            deletedSpinLeadIds: nextDeletedIds
          });
          showToast('স্পিন হুইল এন্ট্রি মুছে ফেলা হয়েছে', 'info');
        } catch {
          // ignore
        }
      }
    });
  };

  // Only Landing Page Products (isLandingPageProduct === true)
  const landingProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return products
      .filter(p => Boolean(p.isLandingPageProduct))
      .filter(p => {
        if (!q) return true;
        const slug = getProductLandingSlug(p).toLowerCase();
        return (
          p.nameBn.toLowerCase().includes(q) ||
          p.nameEn.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          slug.includes(q)
        );
      });
  }, [products, searchQuery]);

  // Effective selling price
  const effectiveSellingPrice = useMemo(() => {
    const disc = parseFloat(formDiscountPrice);
    if (!Number.isNaN(disc) && disc > 0) return disc;
    return formRegularPrice > 0 ? formRegularPrice : 450;
  }, [formRegularPrice, formDiscountPrice]);

  // Existing website products (non-landing page products) for Template 2 Multi-Product Showcase
  const websiteProducts = useMemo(
    () => products.filter(p => !p.isLandingPageProduct),
    [products]
  );

  const filteredWebsiteProducts = useMemo(() => {
    const q = showcaseProductSearch.trim().toLowerCase();
    if (!q) return websiteProducts;
    return websiteProducts.filter(
      p =>
        p.nameBn.toLowerCase().includes(q) ||
        p.nameEn.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
    );
  }, [websiteProducts, showcaseProductSearch]);

  const SHOWCASE_BADGE_PRESETS = [
    'টপ সেলিং 🔥',
    'বেস্ট চয়েস ⭐',
    'লিমিটেড অফার ⏳',
    'নতুন কালেকশন ✨',
    'ট্রেন্ডিং 🌸'
  ];

  const SHOWCASE_FABRIC_PRESETS = [
    'প্রিমিয়াম চায়না মাইক্রো ভেলভেট',
    '১০০% পিওর সফট কটন ফেব্রিক',
    'এক্সপোর্ট কোয়ালিটি জর্জেট ও সিল্ক',
    'প্রিমিয়াম এমব্রয়ডারি কটন',
    'সফট লিলেন ও লেস ওয়ার্ক'
  ];

  const SHOWCASE_COLOR_PRESETS = [
    'রয়্যাল মেরুন',
    'রোজ পিঙ্ক',
    'ডিপ নেভি ব্লু',
    'এমেরাল্ড গ্রিন',
    'ক্লাসিক ব্ল্যাক'
  ];

  const handleToggleShowcaseProduct = (siteProd: Product) => {
    setFormShowcaseItems(prev => {
      const exists = prev.some(it => it.productId === siteProd.id);
      if (exists) {
        return prev.filter(it => it.productId !== siteProd.id);
      }
      const idx = prev.length;
      const defaultLineDesc =
        (siteProd.description || '')
          .split(/\n+/)
          .map(s => s.trim())
          .filter(Boolean)[0] ||
        siteProd.nameEn ||
        '১০০% প্রিমিয়াম ফেব্রিক ও নিখুঁত সেলাইয়ের গ্যারান্টি';

      const nextList: LandingShowcaseProductItem[] = [
        ...prev,
        {
          productId: siteProd.id,
          badgeText: SHOWCASE_BADGE_PRESETS[idx % SHOWCASE_BADGE_PRESETS.length],
          fabricSubtitle: SHOWCASE_FABRIC_PRESETS[idx % SHOWCASE_FABRIC_PRESETS.length],
          colorTag: SHOWCASE_COLOR_PRESETS[idx % SHOWCASE_COLOR_PRESETS.length],
          shortDescription: defaultLineDesc
        }
      ];

      // Auto-populate main campaign fields from first selected website product if empty
      if (prev.length === 0 && !formNameBn.trim()) {
        setFormNameBn(`${siteProd.nameBn} — স্পেশাল কালেকশন`);
        setFormNameEn(`${siteProd.nameEn} Collection`);
        if (!formLandingSlug.trim()) {
          setFormLandingSlug(
            slugifyLandingText(`${siteProd.nameEn || siteProd.sku}-collection`)
          );
        }
        const reg =
          siteProd.regularPrice && siteProd.regularPrice > siteProd.retailPrice
            ? siteProd.regularPrice
            : Math.round(siteProd.retailPrice * 1.35);
        setFormRegularPrice(reg);
        setFormDiscountPrice(String(siteProd.retailPrice));
        setFormPurchasePrice(siteProd.purchasePrice || Math.round(siteProd.retailPrice * 0.7));
        if (siteProd.image && !formImage) {
          setFormImage(siteProd.image);
        }
        if (Array.isArray(siteProd.variants) && siteProd.variants.length > 0 && formVariants.length === 0) {
          setFormVariants(siteProd.variants.map(v => ({ ...v })));
        }
      }

      return nextList;
    });
  };

  const handleUpdateShowcaseItemField = (
    productId: string,
    field: keyof LandingShowcaseProductItem,
    value: string
  ) => {
    setFormShowcaseItems(prev =>
      prev.map(it => (it.productId === productId ? { ...it, [field]: value } : it))
    );
  };

  const handleQuickSelectFiveWebsiteProducts = () => {
    const firstFive = websiteProducts.slice(0, 5);
    if (firstFive.length === 0) {
      showToast('ওয়েবসাইটে কোনো প্রোডাক্ট পাওয়া যায়নি', 'error');
      return;
    }
    const items: LandingShowcaseProductItem[] = firstFive.map((p, idx) => {
      const defaultLineDesc =
        (p.description || '')
          .split(/\n+/)
          .map(s => s.trim())
          .filter(Boolean)[0] ||
        p.nameEn ||
        '১০০% প্রিমিয়াম ফেব্রিক ও আরামদায়ক ফিনিশিং';
      return {
        productId: p.id,
        badgeText: SHOWCASE_BADGE_PRESETS[idx % SHOWCASE_BADGE_PRESETS.length],
        fabricSubtitle: SHOWCASE_FABRIC_PRESETS[idx % SHOWCASE_FABRIC_PRESETS.length],
        colorTag: SHOWCASE_COLOR_PRESETS[idx % SHOWCASE_COLOR_PRESETS.length],
        shortDescription: defaultLineDesc
      };
    });
    setFormShowcaseItems(items);
    const first = firstFive[0];
    if (!formNameBn.trim() && first) {
      setFormNameBn('এক্সক্লুসিভ ৫-ডিজাইন প্রিমিয়াম ড্রেস কালেকশন — মেগা অফার');
      setFormNameEn('Exclusive 5-Design Premium Dress Collection');
      if (!formLandingSlug.trim()) {
        setFormLandingSlug('dress-collection-offer');
      }
      const reg =
        first.regularPrice && first.regularPrice > first.retailPrice
          ? first.regularPrice
          : Math.round(first.retailPrice * 1.35);
      setFormRegularPrice(reg);
      setFormDiscountPrice(String(first.retailPrice));
      setFormPurchasePrice(first.purchasePrice || Math.round(first.retailPrice * 0.7));
      if (first.image && !formImage) {
        setFormImage(first.image);
      }
      if (Array.isArray(first.variants) && first.variants.length > 0) {
        setFormVariants(first.variants.map(v => ({ ...v })));
      }
    }
    showToast(
      `ওয়েবসাইট থেকে ${firstFive.length}টি প্রোডাক্ট (ছবি, দাম ও সাইজসহ) সিলেক্ট করা হয়েছে!`,
      'success'
    );
  };

  // Reset and open Create Modal
  const handleOpenAddModal = (initialTemplate: LandingPageTemplate = 'template_1') => {
    setEditingProduct(null);
    setFormLandingTemplate(initialTemplate);
    setFormShowcaseTitle('আমাদের এক্সক্লুসিভ কালেকশন — পছন্দের ডিজাইনটি বেছে নিন');
    setFormShowcaseSubtitle(
      'প্রতিটি ড্রেস ১০০% প্রিমিয়াম ফেব্রিক, আরামদায়ক ফিট এবং নিখুঁত ফিনিশিংয়ের নিশ্চয়তা'
    );
    setFormShowcaseSelectBtnEnabled(true);
    setFormShowcaseSelectBtnText('সাইজ পছন্দ করুন');
    setFormShowcaseMobileTwoCols(false);
    setShowcaseProductSearch('');
    if (initialTemplate === 'template_2' && websiteProducts.length > 0) {
      const firstFive = websiteProducts.slice(0, 5);
      const first = firstFive[0];
      setFormShowcaseItems(
        firstFive.map((p, idx) => ({
          productId: p.id,
          badgeText: SHOWCASE_BADGE_PRESETS[idx % SHOWCASE_BADGE_PRESETS.length],
          fabricSubtitle: SHOWCASE_FABRIC_PRESETS[idx % SHOWCASE_FABRIC_PRESETS.length],
          colorTag: SHOWCASE_COLOR_PRESETS[idx % SHOWCASE_COLOR_PRESETS.length],
          shortDescription:
            (p.description || '')
              .split(/\n+/)
              .map(s => s.trim())
              .filter(Boolean)[0] ||
            p.nameEn ||
            '১০০% প্রিমিয়াম ফেব্রিক ও আরামদায়ক ফিনিশিং'
        }))
      );
      setFormNameBn('এক্সক্লুসিভ ৫-ডিজাইন প্রিমিয়াম ড্রেস কালেকশন — মেগা অফার');
      setFormNameEn('Exclusive 5-Design Premium Dress Collection');
      setFormLandingSlug(`dress-collection-${Math.floor(10 + Math.random() * 89)}`);
      setFormSku(`LP2-${Math.floor(100 + Math.random() * 900)}`);
      setFormWpProductId(first?.wpProductId ? String(first.wpProductId) : '');
      setFormCategory(first?.categoryId || categories[0]?.id || 'cat_01');
      setFormBrand(first?.brandId || brands[0]?.id || 'brand_01');
      setFormUnit(first?.unit || 'পিস (Pcs)');
      setFormPurchasePrice(first?.purchasePrice || 620);
      const reg =
        first?.regularPrice && first.regularPrice > first.retailPrice
          ? first.regularPrice
          : Math.round((first?.retailPrice || 950) * 1.35);
      setFormRegularPrice(reg);
      setFormDiscountPrice(String(first?.retailPrice || 950));
      setFormVariants(
        Array.isArray(first?.variants) ? first.variants.map(v => ({ ...v })) : []
      );
    } else {
      setFormShowcaseItems([]);
      setFormNameBn('');
      setFormNameEn('');
      setFormLandingSlug('');
      setFormSku(`LP-${Math.floor(100 + Math.random() * 900)}`);
      setFormWpProductId('');
      setFormCategory(categories[0]?.id || 'cat_01');
      setFormBrand(brands[0]?.id || 'brand_01');
      setFormUnit('প্যাক (Pack)');
      setFormPurchasePrice(300);
      setFormRegularPrice(550);
      setFormDiscountPrice('450');
      setFormVariants([]);
    }
    setFormInitialStock(100);
    setFormIsOutOfStock(false);
    setFormFreeDelivery(false);
    setFormImage('');
    setFormGalleryImages([]);
    setNewGalleryUrl('');
    setFormDescription(
      '১০০% প্রিমিয়াম ও আরামদায়ক ফেব্রিকের নিশ্চয়তা\nসারা বাংলাদেশে দ্রুত হোম ডেলিভারি সুবিধা\nপণ্য হাতে পেয়ে দেখে মূল্য পরিশোধের সুবিধা (Cash on Delivery)'
    );
    setFormBadgeText('১০০% প্রিমিয়াম ও অরিজিনাল প্রোডাক্ট');
    setFormVariantTitle('পছন্দের সাইজ / বয়স নির্বাচন করুন:');
    setFormVariantStyle(currentBusiness.landingVariantStyle || 'classic_radio_list');
    setFormVariantShowPrice(Boolean(currentBusiness.landingVariantShowPrice));
    setFormImageBadgeEnabled(currentBusiness.landingImageBadgeEnabled !== false);
    setFormImageBadgeStyle(currentBusiness.landingImageBadgeStyle || 'classic_red');
    setFormFeaturesEnabled(true);
    setFormFeaturesBadgeEnabled(true);
    setFormFeaturesBadgeText('প্রিমিয়াম কোয়ালিটি গ্যারান্টি');
    setFormHighlightsTitleEnabled(true);
    setFormHighlightsTitle('ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:');
    setNewFeatureTopicText('');
    setFormTrustSectionEnabled(true);
    setFormTrustBadgeEnabled(true);
    setFormTrustBadgeText('১০০% বিশ্বস্ত ও নিরাপদ শপিং');
    setFormTrustTitle('কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?');
    setFormTrustItems(DEFAULT_LANDING_TRUST_ITEMS.map(item => ({ ...item })));
    setFormTopHeadingEnabled(true);
    setFormTopHeadingAnimation(true);
    setFormTopHeadingText('');
    setFormTopHeadingSubtext('সীমিত সময়ের মেগা অফার • বিশেষ ছাড় চলছে!');
    setFormTopHeadingTheme('emerald');
    setFormTopHeadingAnimStyle('shimmer');
    setFormTopPriceBannerEnabled(true);
    setFormTopPriceAnimationEnabled(true);
    setFormTopPriceAnimationSpeed('normal');
    setFormTopPriceBannerTheme('emerald');
    setFormTopPriceHighlightStyle('circle');
    setFormTopRegularPriceLabel('পূর্বের মূল্য —');
    setFormTopOfferPriceLabel('আজকের অফার মূল্য —');
    setFormTopOfferPricePrefix('মাত্র');
    setFormPromoBannerEnabled(false);
    setFormPromoBannerImage('');
    setFormPromoBannerPosition('top');
    setFormPromoBannerTitle('');
    setFormPromoBanner2Enabled(false);
    setFormPromoBanner2Image('');
    setFormPromoBanner2Title('');
    setFormCountdownEnabled(true);
    setFormCountdownHours(9);
    setFormCountdownTitle('স্পেশাল অফার শেষ হতে বাকি:');
    setFormCountdownPosition('hero_info');
    setFormVideoEnabled(true);
    setFormVideoTitle('প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:');
    setFormVideoSubtitle('১০০% অরিজিনাল প্রোডাক্টের রিয়েল ভিডিও শোকেস');
    setFormVideoUrl('');
    setFormSizeChartEnabled(true);
    setFormBodySizeChartEnabled(true);
    setFormLandingSpinWheelEnabled(true);
    setFormFloatingBtnPriceEnabled(true);
    setFormFloatingBtnAnimation('jump');
    setFormSizeChartTitle('সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):');
    setFormSizeChartSubtitle('সঠিক সাইজ নির্বাচন করতে নিচের মাপগুলো দেখে নিন');
    setFormSizeChartHeaders([...DEFAULT_LANDING_SIZE_CHART_HEADERS]);
    setFormSizeChartRows(DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r })));
    setFormSizeChartImage('');
    setFormSocialProofEnabled(true);
    setFormSocialProofIntervalSec(16);
    setFormSocialProofCustomText('');
    setFormLiveViewersEnabled(true);
    setFormScarcityEnabled(true);
    setFormScarcityCount(10);
    setFormTopHeaderEnabled(true);
    setFormShowCallBtn(true);
    setFormShowWhatsappBtn(true);
    setFormCallPhone(currentBusiness.callOrderPhone || currentBusiness.phone || '');
    setFormWhatsappPhone(currentBusiness.whatsappOrderPhone || currentBusiness.phone || '');
    setFormReviewsEnabled(true);
    setFormReviewsSliderEnabled(true);
    setFormReviewsTitle('সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ');
    setFormReviewImages([]);
    setFormReviewItems([]);
    setNewReviewName('');
    setNewReviewLocation('');
    setNewReviewComment('');
    setNewReviewAvatar('');
    setFormFooterWarningEnabled(true);
    setFormFooterWarningText(DEFAULT_FOOTER_WARNING_TEXT);
    setFormDevCreditEnabled(currentBusiness.developerCreditEnabled !== false);
    setFormDevCreditName(currentBusiness.developerCreditName ?? 'Web Studio BD');
    setFormDevCreditLink(currentBusiness.developerCreditLink ?? 'https://example.com');
    setNewVarLabel('');
    setNewVarSku('');
    setNewVarWpVariationId('');
    setNewVarRegularPrice('');
    setNewVarRetailPrice('');
    setNewVarPurchasePrice('');
    setShowModal(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormLandingTemplate(product.landingTemplate || 'template_1');
    setFormShowcaseTitle(
      product.landingShowcaseSectionTitle?.trim() ||
        'আমাদের এক্সক্লুসিভ কালেকশন — পছন্দের ডিজাইনটি বেছে নিন'
    );
    setFormShowcaseSubtitle(
      product.landingShowcaseSectionSubtitle?.trim() ||
        'প্রতিটি ড্রেস ১০০% প্রিমিয়াম ফেব্রিক, আরামদায়ক ফিট এবং নিখুঁত ফিনিশিংয়ের নিশ্চয়তা'
    );
    setFormShowcaseSelectBtnEnabled(product.landingShowcaseSelectBtnEnabled !== false);
    setFormShowcaseSelectBtnText(
      product.landingShowcaseSelectBtnText?.trim() || 'সাইজ পছন্দ করুন'
    );
    setFormShowcaseMobileTwoCols(Boolean(product.landingShowcaseMobileTwoCols));
    setFormShowcaseItems(
      Array.isArray(product.landingShowcaseItems)
        ? product.landingShowcaseItems.map(item => ({ ...item }))
        : []
    );
    setShowcaseProductSearch('');
    setFormNameBn(product.nameBn);
    setFormNameEn(product.nameEn);
    setFormLandingSlug(getProductLandingSlug(product));
    setFormSku(product.sku);
    setFormWpProductId(product.wpProductId && product.wpProductId > 0 ? String(product.wpProductId) : '');
    setFormCategory(product.categoryId || categories[0]?.id || 'cat_01');
    setFormBrand(product.brandId || brands[0]?.id || 'brand_01');
    setFormUnit(product.unit || 'প্যাক (Pack)');
    setFormPurchasePrice(product.purchasePrice || 0);
    const reg = product.regularPrice && product.regularPrice > 0 ? product.regularPrice : product.retailPrice;
    setFormRegularPrice(reg);
    setFormDiscountPrice(
      product.discountPrice && product.discountPrice < reg
        ? String(product.discountPrice)
        : String(product.retailPrice)
    );
    setFormInitialStock(product.stockByOutlet[currentOutlet.id] ?? 100);
    setFormIsOutOfStock(Boolean(product.isOutOfStock));
    setFormFreeDelivery(Boolean(product.freeDeliveryOnLanding));
    setFormImage(product.image || '');
    setFormGalleryImages(Array.isArray(product.galleryImages) ? [...product.galleryImages] : []);
    setNewGalleryUrl('');
    setFormDescription(product.description || '');
    setFormVariants(
      Array.isArray(product.variants)
        ? product.variants.map((v, i) => ({
            ...v,
            sku: v.sku || buildVariantSkuCode(product.sku, v.label, i)
          }))
        : []
    );
    setFormBadgeText(
      product.landingBadgeText !== undefined
        ? product.landingBadgeText
        : '১০০% প্রিমিয়াম ও অরিজিনাল প্রোডাক্ট'
    );
    setFormVariantTitle(
      product.landingVariantTitle && product.landingVariantTitle.trim() !== ''
        ? product.landingVariantTitle
        : 'পছন্দের সাইজ / বয়স নির্বাচন করুন:'
    );
    setFormVariantStyle(
      product.landingVariantStyle ||
        currentBusiness.landingVariantStyle ||
        'classic_radio_list'
    );
    setFormVariantShowPrice(
      product.landingVariantShowPrice ??
        currentBusiness.landingVariantShowPrice ??
        false
    );
    setFormImageBadgeEnabled(
      product.landingImageBadgeEnabled ??
        currentBusiness.landingImageBadgeEnabled ??
        true
    );
    setFormImageBadgeStyle(
      product.landingImageBadgeStyle ||
        currentBusiness.landingImageBadgeStyle ||
        'classic_red'
    );
    setFormFeaturesEnabled(product.landingFeaturesEnabled !== false);
    setFormFeaturesBadgeEnabled(product.landingFeaturesBadgeEnabled !== false);
    setFormFeaturesBadgeText(
      product.landingFeaturesBadgeText !== undefined && product.landingFeaturesBadgeText.trim() !== ''
        ? product.landingFeaturesBadgeText
        : 'প্রিমিয়াম কোয়ালিটি গ্যারান্টি'
    );
    setFormHighlightsTitleEnabled(product.landingHighlightsTitleEnabled !== false);
    setFormHighlightsTitle(
      product.landingHighlightsTitle !== undefined && product.landingHighlightsTitle.trim() !== ''
        ? product.landingHighlightsTitle
        : 'ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:'
    );
    setNewFeatureTopicText('');
    setFormTrustSectionEnabled(product.landingTrustSectionEnabled !== false);
    setFormTrustBadgeEnabled(product.landingTrustBadgeEnabled !== false);
    setFormTrustBadgeText(
      product.landingTrustBadgeText !== undefined && product.landingTrustBadgeText.trim() !== ''
        ? product.landingTrustBadgeText
        : '১০০% বিশ্বস্ত ও নিরাপদ শপিং'
    );
    setFormTrustTitle(
      product.landingTrustTitle !== undefined && product.landingTrustTitle.trim() !== ''
        ? product.landingTrustTitle
        : 'কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?'
    );
    setFormTrustItems(
      Array.isArray(product.landingTrustItems) && product.landingTrustItems.length > 0
        ? product.landingTrustItems.map(item => ({ ...item }))
        : DEFAULT_LANDING_TRUST_ITEMS.map(item => ({ ...item }))
    );
    setFormTopHeadingEnabled(product.landingTopHeadingEnabled !== false);
    setFormTopHeadingAnimation(product.landingTopHeadingAnimation !== false);
    setFormTopHeadingText(product.landingTopHeadingText ?? '');
    setFormTopHeadingSubtext(
      product.landingTopHeadingSubtext !== undefined
        ? product.landingTopHeadingSubtext
        : 'সীমিত সময়ের মেগা অফার • বিশেষ ছাড় চলছে!'
    );
    setFormTopHeadingTheme(product.landingTopHeadingTheme || 'emerald');
    setFormTopHeadingAnimStyle(product.landingTopHeadingAnimStyle || 'shimmer');
    setFormTopPriceBannerEnabled(product.landingTopPriceBannerEnabled !== false);
    setFormTopPriceAnimationEnabled(product.landingTopPriceAnimationEnabled !== false);
    setFormTopPriceAnimationSpeed(product.landingTopPriceAnimationSpeed || 'normal');
    setFormTopPriceBannerTheme(product.landingTopPriceBannerTheme || 'emerald');
    setFormTopPriceHighlightStyle(product.landingTopPriceHighlightStyle || 'circle');
    setFormTopRegularPriceLabel(
      product.landingTopRegularPriceLabel !== undefined && product.landingTopRegularPriceLabel.trim() !== ''
        ? product.landingTopRegularPriceLabel
        : 'পূর্বের মূল্য —'
    );
    setFormTopOfferPriceLabel(
      product.landingTopOfferPriceLabel !== undefined && product.landingTopOfferPriceLabel.trim() !== ''
        ? product.landingTopOfferPriceLabel
        : 'আজকের অফার মূল্য —'
    );
    setFormTopOfferPricePrefix(
      product.landingTopOfferPricePrefix !== undefined && product.landingTopOfferPricePrefix.trim() !== ''
        ? product.landingTopOfferPricePrefix
        : 'মাত্র'
    );
    setFormPromoBannerEnabled(
      product.landingPromoBannerEnabled !== undefined
        ? product.landingPromoBannerEnabled
        : Boolean(product.landingPromoBannerImage)
    );
    setFormPromoBannerImage(product.landingPromoBannerImage || '');
    setFormPromoBannerPosition(product.landingPromoBannerPosition || 'top');
    setFormPromoBannerTitle(product.landingPromoBannerTitle || '');
    setFormPromoBanner2Enabled(
      product.landingPromoBanner2Enabled !== undefined
        ? product.landingPromoBanner2Enabled
        : Boolean(product.landingPromoBanner2Image)
    );
    setFormPromoBanner2Image(product.landingPromoBanner2Image || '');
    setFormPromoBanner2Title(product.landingPromoBanner2Title || '');
    setFormCountdownEnabled(product.landingCountdownEnabled !== false);
    setFormCountdownHours(
      product.landingCountdownHours && product.landingCountdownHours > 0
        ? product.landingCountdownHours
        : 9
    );
    setFormCountdownTitle(
      product.landingCountdownTitle !== undefined && product.landingCountdownTitle.trim() !== ''
        ? product.landingCountdownTitle
        : 'স্পেশাল অফার শেষ হতে বাকি:'
    );
    setFormCountdownPosition(product.landingCountdownPosition || 'hero_info');
    setFormVideoEnabled(product.landingVideoEnabled !== false);
    setFormVideoTitle(
      product.landingVideoTitle !== undefined && product.landingVideoTitle.trim() !== ''
        ? product.landingVideoTitle
        : 'প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:'
    );
    setFormVideoSubtitle(
      product.landingVideoSubtitle !== undefined
        ? product.landingVideoSubtitle
        : '১০০% অরিজিনাল প্রোডাক্টের রিয়েল ভিডিও শোকেস'
    );
    setFormVideoUrl(product.landingVideoUrl || '');
    setFormLiveViewersEnabled(product.landingLiveViewersEnabled !== false);
    setFormScarcityEnabled(product.landingScarcityEnabled !== false);
    setFormScarcityCount(
      product.landingScarcityCount && product.landingScarcityCount > 0
        ? product.landingScarcityCount
        : 10
    );
    setFormSizeChartEnabled(product.landingSizeChartEnabled !== false);
    setFormBodySizeChartEnabled(product.landingBodySizeChartEnabled !== false);
    setFormLandingSpinWheelEnabled(product.landingSpinWheelEnabled !== false);
    setFormFloatingBtnPriceEnabled(product.landingFloatingBtnPriceEnabled !== false);
    setFormFloatingBtnAnimation(product.landingFloatingBtnAnimation || 'jump');
    setFormSizeChartTitle(
      product.landingSizeChartTitle !== undefined && product.landingSizeChartTitle.trim() !== ''
        ? product.landingSizeChartTitle
        : 'সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):'
    );
    setFormSizeChartSubtitle(
      product.landingSizeChartSubtitle !== undefined
        ? product.landingSizeChartSubtitle
        : 'সঠিক সাইজ নির্বাচন করতে নিচের মাপগুলো দেখে নিন'
    );
    setFormSizeChartHeaders(
      Array.isArray(product.landingSizeChartHeaders) && product.landingSizeChartHeaders.length === 3
        ? [...product.landingSizeChartHeaders]
        : [...DEFAULT_LANDING_SIZE_CHART_HEADERS]
    );
    setFormSizeChartRows(
      Array.isArray(product.landingSizeChartRows) && product.landingSizeChartRows.length > 0
        ? product.landingSizeChartRows.map(r => ({ ...r }))
        : DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }))
    );
    setFormSizeChartImage(product.landingSizeChartImage || '');
    setFormSocialProofEnabled(product.landingSocialProofEnabled !== false);
    setFormSocialProofIntervalSec(
      typeof product.landingSocialProofIntervalSec === 'number' &&
        product.landingSocialProofIntervalSec >= 2
        ? product.landingSocialProofIntervalSec
        : 16
    );
    setFormSocialProofCustomText(
      Array.isArray(product.landingSocialProofCustomEntries)
        ? product.landingSocialProofCustomEntries.join('\n')
        : ''
    );
    setFormTopHeaderEnabled(product.landingTopHeaderEnabled !== false);
    setFormShowCallBtn(product.landingShowCallButton !== false);
    setFormShowWhatsappBtn(product.landingShowWhatsappButton !== false);
    setFormCallPhone(
      product.landingCallPhone || currentBusiness.callOrderPhone || currentBusiness.phone || ''
    );
    setFormWhatsappPhone(
      product.landingWhatsappPhone || currentBusiness.whatsappOrderPhone || currentBusiness.phone || ''
    );
    setFormReviewsEnabled(product.landingReviewsEnabled !== false);
    setFormReviewsSliderEnabled(product.landingReviewsSliderEnabled !== false);
    setFormReviewsTitle(
      product.landingReviewsTitle && product.landingReviewsTitle.trim() !== ''
        ? product.landingReviewsTitle
        : 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ'
    );
    setFormReviewImages(Array.isArray(product.landingReviewImages) ? [...product.landingReviewImages] : []);
    setFormReviewItems(Array.isArray(product.landingReviewItems) ? [...product.landingReviewItems] : []);
    setNewReviewName('');
    setNewReviewLocation('');
    setNewReviewComment('');
    setNewReviewAvatar('');
    setFormFooterWarningEnabled(product.landingFooterWarningEnabled !== false);
    setFormFooterWarningText(
      product.landingFooterWarningText !== undefined && product.landingFooterWarningText.trim() !== ''
        ? product.landingFooterWarningText
        : DEFAULT_FOOTER_WARNING_TEXT
    );
    setFormDevCreditEnabled(
      product.landingDeveloperCreditEnabled !== undefined
        ? product.landingDeveloperCreditEnabled
        : currentBusiness.developerCreditEnabled !== false
    );
    setFormDevCreditName(
      product.landingDeveloperCreditName ?? currentBusiness.developerCreditName ?? 'Web Studio BD'
    );
    setFormDevCreditLink(
      product.landingDeveloperCreditLink !== undefined
        ? product.landingDeveloperCreditLink
        : currentBusiness.developerCreditLink ?? 'https://example.com'
    );
    setNewVarLabel('');
    setNewVarSku('');
    setNewVarWpVariationId('');
    setNewVarRegularPrice('');
    setNewVarRetailPrice('');
    setNewVarPurchasePrice('');
    setShowModal(true);
  };

  // Handle Main Image Upload
  const handleMainImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingImage(true);
    try {
      const prevMainImg = formImage;
      const dataUrl = await processUploadedProductImage(file, 1200, 0.92);
      setFormImage(dataUrl);
      setFormGalleryImages(prev =>
        prev.filter(
          u =>
            u !== prevMainImg &&
            !u.includes('images.unsplash.com/photo-1599599810769') &&
            !u.includes('images.unsplash.com/photo-1509440159596')
        )
      );
      showToast('প্রোডাক্টের এইচডি (HD) ছবি সফলভাবে আপলোড হয়েছে!', 'success');
    } catch {
      showToast('Could not process image file', 'error');
    } finally {
      setIsUploadingImage(false);
      e.target.value = '';
    }
  };

  // Handle Gallery Image Upload
  const handleGalleryImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsUploadingImage(true);
    try {
      const uploaded: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const dataUrl = await processUploadedProductImage(files[i]);
        uploaded.push(dataUrl);
      }
      setFormGalleryImages(prev => [...prev, ...uploaded]);
      showToast(`${uploaded.length} gallery image(s) added`, 'success');
    } catch {
      showToast('Could not upload gallery image', 'error');
    } finally {
      setIsUploadingImage(false);
      e.target.value = '';
    }
  };

  // Handle Customer Review Screenshot Upload
  const handleReviewImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsUploadingImage(true);
    try {
      const uploaded: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const dataUrl = await processUploadedProductImage(files[i]);
        uploaded.push(dataUrl);
      }
      setFormReviewImages(prev => [...prev, ...uploaded]);
      setFormReviewsEnabled(true);
      showToast(`${uploaded.length}টি কাস্টমার রিভিউ স্ক্রিনশট যুক্ত হয়েছে!`, 'success');
    } catch {
      showToast('Could not upload review image', 'error');
    } finally {
      setIsUploadingImage(false);
      e.target.value = '';
    }
  };

  // Handle Circular Avatar Upload for New Written Review
  const handleNewReviewAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingImage(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      setNewReviewAvatar(dataUrl);
      showToast('ক্রেতার গোল প্রোফাইল ছবি যুক্ত হয়েছে!', 'success');
    } catch {
      showToast('ছবি প্রসেস করা যায়নি', 'error');
    } finally {
      setIsUploadingImage(false);
      e.target.value = '';
    }
  };

  // Handle Circular Avatar Upload for an Existing Written Review
  const handleExistingReviewAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetIdx = editingAvatarReviewIdxRef.current;
    if (!file || targetIdx === null) return;
    setIsUploadingImage(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      setFormReviewItems(prev =>
        prev.map((item, idx) => (idx === targetIdx ? { ...item, avatarUrl: dataUrl } : item))
      );
      showToast('ক্রেতার প্রোফাইল ছবি আপডেট হয়েছে!', 'success');
    } catch {
      showToast('ছবি আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingImage(false);
      editingAvatarReviewIdxRef.current = null;
      e.target.value = '';
    }
  };

  // Add Written Customer Review
  const handleAddWrittenReview = () => {
    const cleanName = newReviewName.trim();
    const cleanComment = newReviewComment.trim();
    if (!cleanName || !cleanComment) {
      showToast('অনুগ্রহ করে ক্রেতার নাম ও রিভিউ কমেন্ট লিখুন', 'error');
      return;
    }
    const newItem: LandingReviewItem = {
      id: `rev_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      customerName: cleanName,
      location: newReviewLocation.trim() || 'ভেরিফাইড ক্রেতা',
      rating: 5,
      comment: cleanComment,
      avatarUrl: newReviewAvatar || undefined
    };
    setFormReviewItems(prev => [...prev, newItem]);
    setFormReviewsEnabled(true);
    setNewReviewName('');
    setNewReviewLocation('');
    setNewReviewComment('');
    setNewReviewAvatar('');
  };

  // 1-Click Sample Bangla Customer Reviews Loader (6 Reviews for Smooth Slider)
  const handleLoadSampleReviews = () => {
    const ts = Date.now();
    setFormReviewItems([
      {
        id: `rev_${ts}_1`,
        customerName: 'নুসরাত জাহান তানিয়া',
        location: 'ধানমন্ডি, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment: 'আলহামদুলিল্লাহ! ছবির চেয়েও বাস্তবে প্রোডাক্টের কোয়ালিটি ও ফেব্রিক অনেক বেশি সুন্দর। ডেলিভারিও খুব দ্রুত পেয়েছি।'
      },
      {
        id: `rev_${ts}_2`,
        customerName: 'ফারহানা ইসলাম মিম',
        location: 'চট্টগ্রাম · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment: 'সাইজ এবং সেলাই একদম পারফেক্ট হয়েছে। হাতে পেয়ে দেখে পেমেন্ট করেছি, বাচ্চার জন্য খুবই আরামদায়ক।'
      },
      {
        id: `rev_${ts}_3`,
        customerName: 'মোঃ তানভীর আহমেদ',
        location: 'উত্তরা, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment: '১০০% অরিজিনাল ও প্রিমিয়াম কোয়ালিটি। তাদের প্যাকেজিং এবং ব্যবহারও অনেক ভালো লেগেছে। ইনশাআল্লাহ আবার অর্ডার করব।'
      },
      {
        id: `rev_${ts}_4`,
        customerName: 'সাদিয়া আফরিন নিপা',
        location: 'সিলেট · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment: 'কালার গ্যারান্টি একদম ঠিক আছে, ধোয়ার পরেও একটুও রং ওঠেনি। এতো সুন্দর কালেকশনের জন্য ধন্যবাদ।'
      },
      {
        id: `rev_${ts}_5`,
        customerName: 'রুবাইয়াত শারমিন কেয়া',
        location: 'রাজশাহী · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment: 'অনলাইনে অনেক জায়গা থেকে কেনাকাটা করেছি কিন্তু আপনাদের ফেব্রিক ও ফিনিশিং সত্যিই অসাধারণ। সবাই খুব প্রশংসা করেছে।'
      },
      {
        id: `rev_${ts}_6`,
        customerName: 'মাহমুদুল হাসান রাকিব',
        location: 'মিরপুর, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment: 'ডেলিভারি ম্যান ভাই খুব আন্তরিক ছিলেন। প্রোডাক্ট খুলে চেক করে দেখে টাকা দিয়েছি। দামের তুলনায় সেরা জিনিস পেয়েছি।'
      }
    ]);
    setFormReviewsEnabled(true);
    showToast('৬টি কাস্টমার রিভিউ যুক্ত হয়েছে! চাইলে ক্রেতার গোল ছবি যুক্ত বা এডিট করতে পারবেন।', 'success');
  };

  // Add Single Variation Row
  const handleAddVariant = () => {
    const cleanLabel = newVarLabel.trim();
    if (!cleanLabel) {
      showToast('Please enter a variation name (e.g., 250g Pack, 500g Pack, XL)', 'error');
      return;
    }
    const retail = Number(newVarRetailPrice) || effectiveSellingPrice || 450;
    const regular = Number(newVarRegularPrice) || (formRegularPrice > retail ? formRegularPrice : retail);
    const purchase = Number(newVarPurchasePrice) || Math.round(retail * 0.75);
    const resolvedVarSku =
      newVarSku.trim() || buildVariantSkuCode(formSku || 'LP', cleanLabel, formVariants.length);
    const parsedWpVarId = parseInt(newVarWpVariationId, 10);

    const newVar: ProductVariant = {
      id: `lp_var_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      label: cleanLabel,
      sku: resolvedVarSku,
      wpVariationId: !Number.isNaN(parsedWpVarId) && parsedWpVarId > 0 ? parsedWpVarId : undefined,
      type: 'pack',
      purchasePrice: purchase,
      regularPrice: regular,
      discountPrice: retail < regular ? retail : undefined,
      retailPrice: retail
    };

    setFormVariants(prev => [...prev, newVar]);
    setNewVarLabel('');
    setNewVarSku('');
    setNewVarWpVariationId('');
    setNewVarRegularPrice('');
    setNewVarRetailPrice('');
    setNewVarPurchasePrice('');
  };

  // 1-Click Variation Presets (Weight Packs / Dress Sizes / Baby Age)
  const handleApplyPreset = (preset: 'makhana_packs' | 'cloth_sizes' | 'baby_years') => {
    const baseRetail = effectiveSellingPrice > 0 ? effectiveSellingPrice : 450;
    const baseRegular = formRegularPrice > baseRetail ? formRegularPrice : Math.round(baseRetail * 1.2);
    const basePurchase = formPurchasePrice > 0 ? formPurchasePrice : Math.round(baseRetail * 0.7);
    const ts = Date.now();
    const baseSku = (formSku || 'LP').trim();

    if (preset === 'makhana_packs') {
      setFormVariants([
        {
          id: `lp_var_${ts}_1`,
          label: '২৫০ গ্রাম প্যাক (250g Pack)',
          sku: buildVariantSkuCode(baseSku, '250G', 0),
          type: 'weight',
          purchasePrice: basePurchase,
          regularPrice: baseRegular,
          discountPrice: baseRetail,
          retailPrice: baseRetail
        },
        {
          id: `lp_var_${ts}_2`,
          label: '৫০০ গ্রাম ফ্যামিলি প্যাক (500g Pack)',
          sku: buildVariantSkuCode(baseSku, '500G', 1),
          type: 'weight',
          purchasePrice: Math.round(basePurchase * 1.9),
          regularPrice: Math.round(baseRegular * 1.95),
          discountPrice: Math.round(baseRetail * 1.88),
          retailPrice: Math.round(baseRetail * 1.88)
        },
        {
          id: `lp_var_${ts}_3`,
          label: '১ কেজি ভ্যালু প্যাক (1kg Value Pack)',
          sku: buildVariantSkuCode(baseSku, '1KG', 2),
          type: 'weight',
          purchasePrice: Math.round(basePurchase * 3.6),
          regularPrice: Math.round(baseRegular * 3.8),
          discountPrice: Math.round(baseRetail * 3.5),
          retailPrice: Math.round(baseRetail * 3.5)
        }
      ]);
      showToast('Added 250g, 500g & 1kg pack variations with Variation SKUs', 'success');
    } else if (preset === 'cloth_sizes') {
      setFormVariants(
        ['M', 'L', 'XL', 'XXL'].map((sz, idx) => ({
          id: `lp_var_${ts}_sz_${idx}`,
          label: `Size ${sz}`,
          sku: buildVariantSkuCode(baseSku, sz, idx),
          type: 'size',
          purchasePrice: basePurchase,
          regularPrice: baseRegular,
          discountPrice: baseRetail,
          retailPrice: baseRetail
        }))
      );
      showToast('Added M, L, XL, XXL variations with Variation SKUs', 'success');
    } else if (preset === 'baby_years') {
      setFormVariants(
        ['1-2 Years', '3-4 Years', '5-6 Years', '7-8 Years', '9-10 Years'].map((yr, idx) => ({
          id: `lp_var_${ts}_yr_${idx}`,
          label: yr,
          sku: buildVariantSkuCode(baseSku, yr, idx),
          type: 'size',
          purchasePrice: basePurchase,
          regularPrice: baseRegular,
          discountPrice: baseRetail,
          retailPrice: baseRetail
        }))
      );
      showToast('Added Baby Age variations with Variation SKUs', 'success');
    }
  };

  // Sync a single Landing Page product + all its variations to WordPress
  const handleSyncLandingProductToWordPress = async (product: Product) => {
    setSyncingProductId(product.id);
    try {
      const res = await syncSingleProductToWordPress({
        siteUrl: currentBusiness.wpSiteUrl || '',
        consumerKey: currentBusiness.wpConsumerKey || '',
        consumerSecret: currentBusiness.wpConsumerSecret || '',
        product
      });
      if (res.ok && res.wpProductId) {
        const nextVariants =
          Array.isArray(product.variants) && product.variants.length > 0
            ? product.variants.map((v, idx) => {
                const mapHit = res.variantMappings?.find(m => m.id === v.id);
                return {
                  ...v,
                  sku: mapHit?.sku || v.sku || buildVariantSkuCode(product.sku, v.label, idx),
                  wpVariationId: mapHit?.wpVariationId || v.wpVariationId
                };
              })
            : product.variants;

        await updateProduct(product.id, {
          wpProductId: res.wpProductId,
          variants: nextVariants
        });
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setSyncingProductId(null);
    }
  };

  // Sync all Landing Page products to WordPress
  const handleSyncAllLandingProductsToWordPress = async () => {
    if (landingProducts.length === 0) return;
    setIsSyncingAllWp(true);
    let syncedCount = 0;
    try {
      for (const prod of landingProducts) {
        const res = await syncSingleProductToWordPress({
          siteUrl: currentBusiness.wpSiteUrl || '',
          consumerKey: currentBusiness.wpConsumerKey || '',
          consumerSecret: currentBusiness.wpConsumerSecret || '',
          product: prod
        });
        if (res.ok && res.wpProductId) {
          const nextVariants =
            Array.isArray(prod.variants) && prod.variants.length > 0
              ? prod.variants.map((v, idx) => {
                  const mapHit = res.variantMappings?.find(m => m.id === v.id);
                  return {
                    ...v,
                    sku: mapHit?.sku || v.sku || buildVariantSkuCode(prod.sku, v.label, idx),
                    wpVariationId: mapHit?.wpVariationId || v.wpVariationId
                  };
                })
              : prod.variants;

          await updateProduct(prod.id, {
            wpProductId: res.wpProductId,
            variants: nextVariants
          });
          syncedCount++;
        }
      }
      if (syncedCount > 0) {
        showToast(
          `${syncedCount}টি Landing Page প্রোডাক্ট ও ভ্যারিয়েশন সফলভাবে WordPress-এ সিঙ্ক হয়েছে!`,
          'success'
        );
      } else {
        showToast(
          'WordPress কানেকশন সেটিংস চেক করুন (WordPress অর্ডার সিঙ্ক মেনু থেকে)।',
          'error'
        );
      }
    } finally {
      setIsSyncingAllWp(false);
    }
  };

  // Save Landing Page Product
  const handleSaveLandingProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanBn = formNameBn.trim() || formNameEn.trim();
    const cleanEn = formNameEn.trim() || formNameBn.trim();
    if (!cleanBn) {
      showToast('Please enter the product name', 'error');
      return;
    }

    const resolvedSlug =
      slugifyLandingText(formLandingSlug.trim()) ||
      slugifyLandingText(cleanEn) ||
      `item-${Date.now().toString().slice(-4)}`;

    const regular = Number(formRegularPrice) || effectiveSellingPrice;
    const retail = effectiveSellingPrice;
    const finalParentSku =
      formSku.trim() || editingProduct?.sku || `LP-${Date.now().toString().slice(-4)}`;
    const parsedWpProdId = parseInt(formWpProductId, 10);
    const finalWpProductId =
      !Number.isNaN(parsedWpProdId) && parsedWpProdId > 0 ? parsedWpProdId : undefined;

    // Ensure every variation has a clean Variation SKU so WordPress matches the exact variation
    const normalizedVariants: ProductVariant[] = formVariants.map((v, idx) => ({
      ...v,
      sku: (v.sku || '').trim() || buildVariantSkuCode(finalParentSku, v.label, idx)
    }));

    if (editingProduct) {
      await updateProduct(editingProduct.id, {
        nameBn: cleanBn,
        nameEn: cleanEn,
        sku: finalParentSku,
        wpProductId: finalWpProductId,
        categoryId: formCategory,
        brandId: formBrand,
        unit: formUnit,
        purchasePrice: Number(formPurchasePrice) || 0,
        regularPrice: regular,
        discountPrice: retail < regular ? retail : 0,
        retailPrice: retail,
        stockByOutlet: {
          ...editingProduct.stockByOutlet,
          [currentOutlet.id]: Number(formInitialStock) || 0
        },
        image: formImage.trim() || undefined,
        galleryImages: formGalleryImages,
        description: formDescription.trim(),
        variants: normalizedVariants,
        isOutOfStock: formIsOutOfStock,
        isLandingPageProduct: true,
        landingTemplate: formLandingTemplate,
        landingShowcaseSectionTitle:
          formShowcaseTitle.trim() ||
          'আমাদের এক্সক্লুসিভ কালেকশন — পছন্দের ডিজাইনটি বেছে নিন',
        landingShowcaseSectionSubtitle:
          formShowcaseSubtitle.trim() ||
          'প্রতিটি ড্রেস ১০০% প্রিমিয়াম ফেব্রিক, আরামদায়ক ফিট এবং নিখুঁত ফিনিশিংয়ের নিশ্চয়তা',
        landingShowcaseSelectBtnEnabled: formShowcaseSelectBtnEnabled,
        landingShowcaseSelectBtnText:
          formShowcaseSelectBtnText.trim() || 'সাইজ পছন্দ করুন',
        landingShowcaseMobileTwoCols: formShowcaseMobileTwoCols,
        landingShowcaseItems:
          formLandingTemplate === 'template_2' || formLandingTemplate === 'template_3'
            ? formShowcaseItems
            : editingProduct.landingShowcaseItems,
        landingSlug: resolvedSlug,
        freeDeliveryOnLanding: formFreeDelivery,
        landingBadgeText: formBadgeText.trim(),
        landingVariantTitle: formVariantTitle.trim() || 'পছন্দের সাইজ / বয়স নির্বাচন করুন:',
        landingVariantStyle: formVariantStyle,
        landingVariantShowPrice: formVariantShowPrice,
        landingImageBadgeEnabled: formImageBadgeEnabled,
        landingImageBadgeStyle: formImageBadgeStyle,
        landingFeaturesEnabled: formFeaturesEnabled,
        landingFeaturesBadgeEnabled: formFeaturesBadgeEnabled,
        landingFeaturesBadgeText: formFeaturesBadgeText.trim() || 'প্রিমিয়াম কোয়ালিটি গ্যারান্টি',
        landingHighlightsTitleEnabled: formHighlightsTitleEnabled,
        landingHighlightsTitle: formHighlightsTitle.trim() || 'ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:',
        landingTrustSectionEnabled: formTrustSectionEnabled,
        landingTrustBadgeEnabled: formTrustBadgeEnabled,
        landingTrustBadgeText: formTrustBadgeText.trim() || '১০০% বিশ্বস্ত ও নিরাপদ শপিং',
        landingTrustTitle: formTrustTitle.trim() || 'কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?',
        landingTrustItems: formTrustItems,
        landingTopHeadingEnabled: formTopHeadingEnabled,
        landingTopHeadingAnimation: formTopHeadingAnimation,
        landingTopHeadingText: formTopHeadingText.trim(),
        landingTopHeadingSubtext: formTopHeadingSubtext.trim(),
        landingTopHeadingTheme: formTopHeadingTheme,
        landingTopHeadingAnimStyle: formTopHeadingAnimStyle,
        landingTopPriceBannerEnabled: formTopPriceBannerEnabled,
        landingTopPriceAnimationEnabled: formTopPriceAnimationEnabled,
        landingTopPriceAnimationSpeed: formTopPriceAnimationSpeed,
        landingTopPriceBannerTheme: formTopPriceBannerTheme,
        landingTopPriceHighlightStyle: formTopPriceHighlightStyle,
        landingTopRegularPriceLabel: formTopRegularPriceLabel.trim() || 'পূর্বের মূল্য —',
        landingTopOfferPriceLabel: formTopOfferPriceLabel.trim() || 'আজকের অফার মূল্য —',
        landingTopOfferPricePrefix: formTopOfferPricePrefix.trim() || 'মাত্র',
        landingPromoBannerEnabled: formPromoBannerEnabled,
        landingPromoBannerImage: formPromoBannerImage.trim() || undefined,
        landingPromoBannerPosition: formPromoBannerPosition,
        landingPromoBannerTitle: formPromoBannerTitle.trim() || undefined,
        landingPromoBanner2Enabled: formPromoBanner2Enabled,
        landingPromoBanner2Image: formPromoBanner2Image.trim() || undefined,
        landingPromoBanner2Title: formPromoBanner2Title.trim() || undefined,
        landingCountdownEnabled: formCountdownEnabled,
        landingCountdownHours: Math.max(1, Number(formCountdownHours) || 9),
        landingCountdownTitle: formCountdownTitle.trim() || 'স্পেশাল অফার শেষ হতে বাকি:',
        landingCountdownPosition: formCountdownPosition,
        landingVideoEnabled: formVideoEnabled,
        landingVideoTitle: formVideoTitle.trim() || 'প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:',
        landingVideoSubtitle: formVideoSubtitle.trim(),
        landingVideoUrl: formVideoUrl.trim(),
        landingSizeChartEnabled: formSizeChartEnabled,
        landingBodySizeChartEnabled: formBodySizeChartEnabled,
        landingSpinWheelEnabled: formLandingSpinWheelEnabled,
        landingFloatingBtnPriceEnabled: formFloatingBtnPriceEnabled,
        landingFloatingBtnAnimation: formFloatingBtnAnimation,
        landingSizeChartTitle: formSizeChartTitle.trim() || 'সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):',
        landingSizeChartSubtitle: formSizeChartSubtitle.trim(),
        landingSizeChartHeaders: formSizeChartHeaders,
        landingSizeChartRows: formSizeChartRows,
        landingSizeChartImage: formSizeChartImage.trim() || undefined,
        landingSocialProofEnabled: formSocialProofEnabled,
        landingSocialProofIntervalSec: Math.max(2, Math.min(300, Number(formSocialProofIntervalSec) || 16)),
        landingSocialProofCustomEntries: formSocialProofCustomText
          .split(/\n+/)
          .map(s => s.trim())
          .filter(Boolean),
        landingLiveViewersEnabled: formLiveViewersEnabled,
        landingScarcityEnabled: formScarcityEnabled,
        landingScarcityCount: Math.max(1, Number(formScarcityCount) || 10),
        landingTopHeaderEnabled: formTopHeaderEnabled,
        landingShowCallButton: formShowCallBtn,
        landingShowWhatsappButton: formShowWhatsappBtn,
        landingCallPhone: formCallPhone.trim() || undefined,
        landingWhatsappPhone: formWhatsappPhone.trim() || undefined,
        landingReviewsEnabled: formReviewsEnabled,
        landingReviewsSliderEnabled: formReviewsSliderEnabled,
        landingReviewsTitle: formReviewsTitle.trim() || 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ',
        landingReviewImages: formReviewImages,
        landingReviewItems: formReviewItems,
        landingFooterWarningEnabled: formFooterWarningEnabled,
        landingFooterWarningText: formFooterWarningText.trim() || DEFAULT_FOOTER_WARNING_TEXT,
        landingDeveloperCreditEnabled: formDevCreditEnabled,
        landingDeveloperCreditName: formDevCreditName.trim(),
        landingDeveloperCreditLink: formDevCreditLink.trim()
      });
      updateBusiness({
        landingVariantStyle: formVariantStyle,
        landingVariantShowPrice: formVariantShowPrice,
        landingImageBadgeEnabled: formImageBadgeEnabled,
        landingImageBadgeStyle: formImageBadgeStyle,
        developerCreditEnabled: formDevCreditEnabled,
        developerCreditName: formDevCreditName.trim(),
        developerCreditLink: formDevCreditLink.trim()
      });
      showToast('Landing Page product & settings updated!', 'success');
    } else {
      await addProduct({
        businessId: currentBusiness.id,
        sku: finalParentSku,
        wpProductId: finalWpProductId,
        barcode: `${Date.now()}`.slice(-11),
        nameBn: cleanBn,
        nameEn: cleanEn,
        categoryId: formCategory,
        brandId: formBrand,
        unit: formUnit,
        packSize: 1,
        purchasePrice: Number(formPurchasePrice) || 0,
        avgCost: Number(formPurchasePrice) || 0,
        regularPrice: regular,
        discountPrice: retail < regular ? retail : 0,
        retailPrice: retail,
        wholesalePrice: retail,
        minWholesaleQty: 1,
        stockByOutlet: {
          outlet_01: Number(formInitialStock) || 100,
          outlet_02: Number(formInitialStock) || 100,
          [currentOutlet.id]: Number(formInitialStock) || 100
        },
        lowStockAlert: 10,
        vatPercent: 0,
        image: formImage.trim() || undefined,
        galleryImages: formGalleryImages,
        description: formDescription.trim(),
        variants: normalizedVariants,
        isOutOfStock: formIsOutOfStock,
        isLandingPageProduct: true,
        landingTemplate: formLandingTemplate,
        landingShowcaseSectionTitle:
          formShowcaseTitle.trim() ||
          'আমাদের এক্সক্লুসিভ কালেকশন — পছন্দের ডিজাইনটি বেছে নিন',
        landingShowcaseSectionSubtitle:
          formShowcaseSubtitle.trim() ||
          'প্রতিটি ড্রেস ১০০% প্রিমিয়াম ফেব্রিক, আরামদায়ক ফিট এবং নিখুঁত ফিনিশিংয়ের নিশ্চয়তা',
        landingShowcaseSelectBtnEnabled: formShowcaseSelectBtnEnabled,
        landingShowcaseSelectBtnText:
          formShowcaseSelectBtnText.trim() || 'সাইজ পছন্দ করুন',
        landingShowcaseMobileTwoCols: formShowcaseMobileTwoCols,
        landingShowcaseItems:
          formLandingTemplate === 'template_2' || formLandingTemplate === 'template_3'
            ? formShowcaseItems
            : undefined,
        landingSlug: resolvedSlug,
        freeDeliveryOnLanding: formFreeDelivery,
        landingBadgeText: formBadgeText.trim(),
        landingVariantTitle: formVariantTitle.trim() || 'পছন্দের সাইজ / বয়স নির্বাচন করুন:',
        landingVariantStyle: formVariantStyle,
        landingVariantShowPrice: formVariantShowPrice,
        landingImageBadgeEnabled: formImageBadgeEnabled,
        landingImageBadgeStyle: formImageBadgeStyle,
        landingFeaturesEnabled: formFeaturesEnabled,
        landingFeaturesBadgeEnabled: formFeaturesBadgeEnabled,
        landingFeaturesBadgeText: formFeaturesBadgeText.trim() || 'প্রিমিয়াম কোয়ালিটি গ্যারান্টি',
        landingHighlightsTitleEnabled: formHighlightsTitleEnabled,
        landingHighlightsTitle: formHighlightsTitle.trim() || 'ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:',
        landingTrustSectionEnabled: formTrustSectionEnabled,
        landingTrustBadgeEnabled: formTrustBadgeEnabled,
        landingTrustBadgeText: formTrustBadgeText.trim() || '১০০% বিশ্বস্ত ও নিরাপদ শপিং',
        landingTrustTitle: formTrustTitle.trim() || 'কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?',
        landingTrustItems: formTrustItems,
        landingTopHeadingEnabled: formTopHeadingEnabled,
        landingTopHeadingAnimation: formTopHeadingAnimation,
        landingTopHeadingText: formTopHeadingText.trim(),
        landingTopHeadingSubtext: formTopHeadingSubtext.trim(),
        landingTopHeadingTheme: formTopHeadingTheme,
        landingTopHeadingAnimStyle: formTopHeadingAnimStyle,
        landingTopPriceBannerEnabled: formTopPriceBannerEnabled,
        landingTopPriceAnimationEnabled: formTopPriceAnimationEnabled,
        landingTopPriceAnimationSpeed: formTopPriceAnimationSpeed,
        landingTopPriceBannerTheme: formTopPriceBannerTheme,
        landingTopPriceHighlightStyle: formTopPriceHighlightStyle,
        landingTopRegularPriceLabel: formTopRegularPriceLabel.trim() || 'পূর্বের মূল্য —',
        landingTopOfferPriceLabel: formTopOfferPriceLabel.trim() || 'আজকের অফার মূল্য —',
        landingTopOfferPricePrefix: formTopOfferPricePrefix.trim() || 'মাত্র',
        landingPromoBannerEnabled: formPromoBannerEnabled,
        landingPromoBannerImage: formPromoBannerImage.trim() || undefined,
        landingPromoBannerPosition: formPromoBannerPosition,
        landingPromoBannerTitle: formPromoBannerTitle.trim() || undefined,
        landingPromoBanner2Enabled: formPromoBanner2Enabled,
        landingPromoBanner2Image: formPromoBanner2Image.trim() || undefined,
        landingPromoBanner2Title: formPromoBanner2Title.trim() || undefined,
        landingCountdownEnabled: formCountdownEnabled,
        landingCountdownHours: Math.max(1, Number(formCountdownHours) || 9),
        landingCountdownTitle: formCountdownTitle.trim() || 'স্পেশাল অফার শেষ হতে বাকি:',
        landingCountdownPosition: formCountdownPosition,
        landingVideoEnabled: formVideoEnabled,
        landingVideoTitle: formVideoTitle.trim() || 'প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:',
        landingVideoSubtitle: formVideoSubtitle.trim(),
        landingVideoUrl: formVideoUrl.trim(),
        landingSizeChartEnabled: formSizeChartEnabled,
        landingBodySizeChartEnabled: formBodySizeChartEnabled,
        landingSpinWheelEnabled: formLandingSpinWheelEnabled,
        landingFloatingBtnPriceEnabled: formFloatingBtnPriceEnabled,
        landingFloatingBtnAnimation: formFloatingBtnAnimation,
        landingSizeChartTitle: formSizeChartTitle.trim() || 'সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):',
        landingSizeChartSubtitle: formSizeChartSubtitle.trim(),
        landingSizeChartHeaders: formSizeChartHeaders,
        landingSizeChartRows: formSizeChartRows,
        landingSizeChartImage: formSizeChartImage.trim() || undefined,
        landingSocialProofEnabled: formSocialProofEnabled,
        landingSocialProofIntervalSec: Math.max(2, Math.min(300, Number(formSocialProofIntervalSec) || 16)),
        landingSocialProofCustomEntries: formSocialProofCustomText
          .split(/\n+/)
          .map(s => s.trim())
          .filter(Boolean),
        landingLiveViewersEnabled: formLiveViewersEnabled,
        landingScarcityEnabled: formScarcityEnabled,
        landingScarcityCount: Math.max(1, Number(formScarcityCount) || 10),
        landingTopHeaderEnabled: formTopHeaderEnabled,
        landingShowCallButton: formShowCallBtn,
        landingShowWhatsappButton: formShowWhatsappBtn,
        landingCallPhone: formCallPhone.trim() || undefined,
        landingWhatsappPhone: formWhatsappPhone.trim() || undefined,
        landingReviewsEnabled: formReviewsEnabled,
        landingReviewsSliderEnabled: formReviewsSliderEnabled,
        landingReviewsTitle: formReviewsTitle.trim() || 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ',
        landingReviewImages: formReviewImages,
        landingReviewItems: formReviewItems,
        landingFooterWarningEnabled: formFooterWarningEnabled,
        landingFooterWarningText: formFooterWarningText.trim() || DEFAULT_FOOTER_WARNING_TEXT,
        landingDeveloperCreditEnabled: formDevCreditEnabled,
        landingDeveloperCreditName: formDevCreditName.trim(),
        landingDeveloperCreditLink: formDevCreditLink.trim()
      });
      updateBusiness({
        landingVariantStyle: formVariantStyle,
        landingVariantShowPrice: formVariantShowPrice,
        landingImageBadgeEnabled: formImageBadgeEnabled,
        landingImageBadgeStyle: formImageBadgeStyle,
        developerCreditEnabled: formDevCreditEnabled,
        developerCreditName: formDevCreditName.trim(),
        developerCreditLink: formDevCreditLink.trim()
      });
      showToast('New Landing Page created! Copy link to run ads.', 'success');
    }

    setShowModal(false);
    setEditingProduct(null);
  };

  // Copy Landing Page URL
  const handleCopyLandingUrl = async (product: Product) => {
    const path = buildLandingPagePath(product);
    const fullUrl =
      typeof window !== 'undefined' ? `${window.location.origin}${path}` : path;
    try {
      await navigator.clipboard.writeText(fullUrl);
      setCopiedId(product.id);
      setTimeout(() => {
        setCopiedId(prev => (prev === product.id ? null : prev));
      }, 2500);
      showToast(`Landing Page Link Copied: ${fullUrl}`, 'success');
    } catch {
      showToast(`Link: ${fullUrl}`, 'info');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Strip */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-2xs flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
              <Rocket className="w-3 h-3" />
              Single-Product Ad Funnel
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs font-medium text-slate-500">
              Hidden from Main Home Page · Unified Order Box
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Product Landing Pages ({landingProducts.length})
          </h1>
          <p className="text-xs text-slate-500">
            Upload products exclusively for Facebook/TikTok Ads. Each product gets a dedicated{' '}
            <span className="font-mono font-semibold text-slate-700">/landing/...</span> link with a direct one-page checkout form, and all orders go straight to your main Online Orders list.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search landing pages..."
              className="min-h-[40px] pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 focus:border-emerald-600 focus:bg-white rounded-xl text-xs text-slate-900 outline-hidden"
            />
          </div>

          {/* Separate Landing Page Spin the Wheel Global Toggle + Settings/Leads Modal Button */}
          <button
            type="button"
            onClick={() => {
              const nextVal = !globalLandingSpinEnabled;
              updateBusiness({ landingSpinWheelEnabled: nextVal });
              showToast(
                nextVal
                  ? 'সব ল্যান্ডিং পেজের স্পিন দ্য হুইল চালু (ON) করা হয়েছে'
                  : 'সব ল্যান্ডিং পেজের স্পিন দ্য হুইল বন্ধ (OFF) করা হয়েছে',
                'info'
              );
            }}
            className={`min-h-[40px] px-3 py-2 text-xs font-extrabold rounded-xl flex items-center gap-1.5 border transition-colors cursor-pointer ${
              globalLandingSpinEnabled
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
            }`}
            title="ল্যান্ডিং পেজের স্পিন দ্য হুইল গ্লোবাল ON / OFF করুন"
          >
            <Gift className="w-3.5 h-3.5 text-amber-600" />
            <span>স্পিন হুইল: {globalLandingSpinEnabled ? 'ON' : 'OFF'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setLandingSpinConfigDraft(landingSpinWheelConfig);
              setLandingSpinAdminTab('settings');
              setShowLandingSpinAdminModal(true);
            }}
            className="min-h-[40px] px-3.5 py-2 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="ল্যান্ডিং পেজের স্পিন দ্য হুইল অফার কাস্টমাইজ ও কাস্টমার নাম্বার লিস্ট দেখুন"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>স্পিন হুইল কন্ট্রোল ({storedLandingSpinLeads.length})</span>
          </button>

          {/* ❄️ Landing Page Winter Theme Global ON/OFF + Falling Snow Global ON/OFF + Storefront-Style Control Card Toggle */}
          <button
            type="button"
            onClick={() => {
              const nextWinter = !globalLandingWinterTheme;
              updateBusiness({
                landingWinterThemeEnabled: nextWinter,
                ...(nextWinter ? { landingSnowfallEnabled: true } : {})
              });
              showToast(
                nextWinter
                  ? '❄️ সব ল্যান্ডিং পেজে Winter Theme (Cool Blues & Snowy Whites) চালু (ON) করা হয়েছে!'
                  : 'সব ল্যান্ডিং পেজের Winter Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                nextWinter ? 'success' : 'info'
              );
            }}
            className={`min-h-[40px] px-3 py-2 text-xs font-extrabold rounded-xl flex items-center gap-1.5 border transition-colors cursor-pointer ${
              globalLandingWinterTheme
                ? 'bg-gradient-to-r from-sky-600 to-blue-700 text-white border-sky-500 shadow-2xs'
                : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
            }`}
            title="সব ল্যান্ডিং পেজে স্টোরফ্রন্টের মতো ❄️ Winter Theme (Cool Icy Blues & Snowy Whites) ON / OFF করুন"
          >
            <span>❄️ Winter Theme: {globalLandingWinterTheme ? 'ON' : 'OFF'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const nextSnow = !globalLandingSnowEnabled;
              updateBusiness({ landingSnowfallEnabled: nextSnow });
              showToast(
                nextSnow
                  ? '🌨️ সব ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow) চালু (ON) করা হয়েছে!'
                  : 'সব ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow) বন্ধ (OFF) করা হয়েছে।',
                nextSnow ? 'success' : 'info'
              );
            }}
            className={`min-h-[40px] px-3 py-2 text-xs font-extrabold rounded-xl flex items-center gap-1.5 border transition-colors cursor-pointer ${
              globalLandingSnowEnabled
                ? 'bg-sky-50 text-sky-900 border-sky-300 hover:bg-sky-100'
                : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
            }`}
            title="সব ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow) ON / OFF করুন"
          >
            <span>
              🌨️ স্নো ফল: {globalLandingSnowEnabled ? `ON (${landingSnowfallIntensity}%)` : 'OFF'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowLandingSnowControlCard(prev => !prev)}
            className={`min-h-[40px] px-3.5 py-2 text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer ${
              showLandingSnowControlCard
                ? 'bg-sky-700 text-white'
                : 'bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-700 hover:to-sky-700 text-white'
            }`}
            title="স্টোরফ্রন্টের মতো ল্যান্ডিং পেজের উইন্টার থিম, তুষারপাতের ঘনত্ব, পড়ার গতি ও অটো-অফ টাইমার নিয়ন্ত্রণ করুন"
          >
            <span>❄️ স্নো কন্ট্রোল {showLandingSnowControlCard ? '▲' : '▼'}</span>
          </button>

          {/* 🎉 Landing Page Order Celebration Global ON/OFF + Control Card Toggle */}
          <button
            type="button"
            onClick={() => {
              const nextState = !globalLandingConfettiEnabled;
              updateBusiness({ landingOrderConfettiEnabled: nextState });
              if (nextState) {
                triggerAdminTestCelebration();
              } else {
                setIsAdminTestCelebrationActive(false);
              }
              showToast(
                nextState
                  ? '🎉 সব ল্যান্ডিং পেজে অর্ডার কনফার্মেশন সেলিব্রেশন চালু (ON) করা হয়েছে!'
                  : 'সব ল্যান্ডিং পেজে অর্ডার কনফার্মেশন সেলিব্রেশন বন্ধ (OFF) করা হয়েছে।',
                nextState ? 'success' : 'info'
              );
            }}
            className={`min-h-[40px] px-3 py-2 text-xs font-extrabold rounded-xl flex items-center gap-1.5 border transition-colors cursor-pointer ${
              globalLandingConfettiEnabled
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
            }`}
            title="সব ল্যান্ডিং পেজে অর্ডার কনফার্ম হলে প্রিমিয়াম সেলিব্রেশন অ্যানিমেশন ON / OFF করুন"
          >
            <span>🎉 অর্ডার সেলিব্রেশন: {globalLandingConfettiEnabled ? 'ON' : 'OFF'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowLandingCelebrationCard(prev => !prev)}
            className={`min-h-[40px] px-3.5 py-2 text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer ${
              showLandingCelebrationCard
                ? 'bg-amber-700 text-white'
                : 'bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white'
            }`}
            title="ল্যান্ডিং পেজের অর্ডার কনফার্মেশন সেলিব্রেশনের ৪টি লাক্সারি স্টাইল ও পপ-ব্যাজ নিয়ন্ত্রণ করুন"
          >
            <span>🎊 সেলিব্রেশন কন্ট্রোল {showLandingCelebrationCard ? '▲' : '▼'}</span>
          </button>

          {landingProducts.length > 0 && (
            <button
              type="button"
              disabled={isSyncingAllWp}
              onClick={handleSyncAllLandingProductsToWordPress}
              className="min-h-[40px] px-3.5 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
              title="Sync all Landing Page Products & Variations to WordPress WooCommerce"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAllWp ? 'animate-spin' : ''}`} />
              <span>{isSyncingAllWp ? 'Syncing to WP...' : 'Sync All to WordPress'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleOpenAddModal('template_1')}
            className="min-h-[40px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Landing Page 1</span>
          </button>

          <button
            type="button"
            onClick={() => handleOpenAddModal('template_2')}
            className="min-h-[40px] px-4 py-2 bg-[#c30000] hover:bg-[#9e0000] text-white text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="ওয়েবসাইটের বিদ্যমান প্রোডাক্ট দিয়ে মাল্টি-ডিজাইন (যেমন ৫টি ড্রেস) ল্যান্ডিং পেজ ২ তৈরি করুন"
          >
            <Layers className="w-4 h-4" />
            <span>+ Create Landing Page 2</span>
          </button>

          <button
            type="button"
            onClick={() => handleOpenAddModal('template_3')}
            className="min-h-[40px] px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="ল্যান্ডিং পেজ ৩ তৈরি করুন — যেখানে কাস্টমার একসাথে একাধিক প্রোডাক্ট সিলেক্ট করে অর্ডার করতে পারবে"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>+ Create Landing Page 3 (Multi-Order)</span>
          </button>
        </div>
      </div>

      {/* ❄️ Storefront-Style Landing Page Winter Theme & Falling Snow Control Card */}
      {showLandingSnowControlCard && (
        <div className="bg-gradient-to-r from-sky-50 via-white to-blue-50/90 rounded-2xl p-4 sm:p-5 border-2 border-sky-400/70 shadow-2xs space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="space-y-1">
              <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                <span className="text-base leading-none">❄️</span>
                <span>
                  Landing Page Winter Theme &amp; Falling Snow Control (উইন্টার থিম, তুষারপাতের ঘনত্ব, গতি ও অটো-অফ টাইমার)
                </span>
              </p>
              <p className="text-[11px] text-slate-600">
                স্টোরফ্রন্টের মতোই আপনার সব ল্যান্ডিং পেজে ১-ক্লিকে{' '}
                <span className="font-bold text-sky-800">
                  কুল আইসি ব্লু ও স্নো হোয়াইট (Winter Theme)
                </span>{' '}
                এবং স্ক্রিনের ওপর{' '}
                <span className="font-bold text-cyan-800">
                  তুষারপাত অ্যানিমেশন (Falling Snow), তুষারকণার সংখ্যা, পড়ার গতি (Speed) এবং কত সেকেন্ড পর অটো বন্ধ হবে
                </span>{' '}
                তা নিয়ন্ত্রণ করুন।
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  const nextWinter = !globalLandingWinterTheme;
                  updateBusiness({
                    landingWinterThemeEnabled: nextWinter,
                    ...(nextWinter ? { landingSnowfallEnabled: true } : {})
                  });
                  showToast(
                    nextWinter
                      ? '❄️ সব ল্যান্ডিং পেজে Winter Theme (Cool Blues & Snowy Whites) চালু (ON) করা হয়েছে!'
                      : 'সব ল্যান্ডিং পেজের Winter Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                    nextWinter ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  globalLandingWinterTheme
                    ? 'bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white ring-2 ring-sky-400/40'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {globalLandingWinterTheme
                    ? '❄️ Winter Theme: চালু (ON)'
                    : '❄️ Winter Theme: বন্ধ (OFF)'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const nextSnow = !globalLandingSnowEnabled;
                  updateBusiness({ landingSnowfallEnabled: nextSnow });
                  showToast(
                    nextSnow
                      ? '🌨️ ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow Overlay) চালু (ON) করা হয়েছে!'
                      : 'ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow Overlay) বন্ধ (OFF) করা হয়েছে।',
                    nextSnow ? 'success' : 'info'
                  );
                }}
                className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-2xs ${
                  globalLandingSnowEnabled
                    ? 'bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-700 hover:to-sky-700 text-white ring-2 ring-cyan-400/40'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {globalLandingSnowEnabled
                    ? '🌨️ Falling Snow: চালু (ON)'
                    : '🌨️ Falling Snow: বন্ধ (OFF)'}
                </span>
              </button>
            </div>
          </div>

          <div className="pt-3 border-t border-sky-200/80 grid grid-cols-1 lg:grid-cols-3 gap-3.5">
            {/* 1. Snowfall Intensity Slider */}
            <div className="bg-white/90 rounded-xl p-3.5 border border-sky-200/90 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                  <span>🌨️ Snowfall Intensity (তুষারপাতের ঘনত্ব)</span>
                </label>
                <span className="px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-900 border border-sky-300 font-mono text-[11px] font-extrabold">
                  {landingSnowfallIntensity}% ({Math.max(6, Math.min(80, Math.round((landingSnowfallIntensity / 100) * 68)))} কণা)
                </span>
              </div>

              <input
                type="range"
                min={10}
                max={100}
                step={5}
                value={landingSnowfallIntensity}
                onChange={e => {
                  const nextVal = Number(e.target.value) || 50;
                  updateBusiness({
                    landingSnowfallEnabled: true,
                    landingSnowfallIntensity: nextVal
                  });
                }}
                className="w-full h-2 bg-sky-100 rounded-lg appearance-none cursor-pointer accent-sky-600"
              />

              <div className="flex flex-wrap items-center justify-between gap-1.5">
                {[
                  { val: 25, label: 'হালকা (25%)' },
                  { val: 50, label: 'মাঝারি (50%)' },
                  { val: 85, label: 'ঘন তুষারপাত (85%)' }
                ].map(preset => (
                  <button
                    key={preset.val}
                    type="button"
                    onClick={() => {
                      updateBusiness({
                        landingSnowfallEnabled: true,
                        landingSnowfallIntensity: preset.val
                      });
                      showToast(`ল্যান্ডিং পেজ তুষারপাতের ঘনত্ব "${preset.label}" সেট করা হয়েছে!`, 'info');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                      landingSnowfallIntensity === preset.val
                        ? 'bg-sky-600 text-white border-sky-600'
                        : 'bg-sky-50/70 text-sky-900 border-sky-200 hover:bg-sky-100'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-500">
                স্লাইডার বাড়ালে তুষারকণার সংখ্যা (Particle Count) এবং অ্যানিমেশন স্পিড বাড়বে।
              </p>
            </div>

            {/* 2. Snow Falling Speed Slider */}
            <div className="bg-white/90 rounded-xl p-3.5 border border-sky-200/90 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                  <span>💨 তুষার পড়ার গতি (Falling Speed)</span>
                </label>
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-100 text-cyan-900 border border-cyan-300 font-mono text-[11px] font-extrabold">
                  {landingSnowfallSpeed}%{' '}
                  {landingSnowfallSpeed < 75
                    ? '(ধীর)'
                    : landingSnowfallSpeed > 130
                    ? '(দ্রুত)'
                    : '(স্বাভাবিক)'}
                </span>
              </div>

              <input
                type="range"
                min={30}
                max={200}
                step={10}
                value={landingSnowfallSpeed}
                onChange={e => {
                  const nextSpd = Number(e.target.value) || 100;
                  updateBusiness({
                    landingSnowfallEnabled: true,
                    landingSnowfallSpeed: nextSpd
                  });
                }}
                className="w-full h-2 bg-cyan-100 rounded-lg appearance-none cursor-pointer accent-cyan-600"
              />

              <div className="flex flex-wrap items-center justify-between gap-1.5">
                {[
                  { val: 50, label: 'ধীর (Slow)' },
                  { val: 100, label: 'স্বাভাবিক (Normal)' },
                  { val: 160, label: 'দ্রুত (Fast)' }
                ].map(spPreset => (
                  <button
                    key={spPreset.val}
                    type="button"
                    onClick={() => {
                      updateBusiness({
                        landingSnowfallEnabled: true,
                        landingSnowfallSpeed: spPreset.val
                      });
                      showToast(`ল্যান্ডিং পেজ তুষার পড়ার গতি "${spPreset.label}" সেট করা হয়েছে!`, 'info');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                      landingSnowfallSpeed === spPreset.val
                        ? 'bg-cyan-600 text-white border-cyan-600'
                        : 'bg-cyan-50/70 text-cyan-900 border-cyan-200 hover:bg-cyan-100'
                    }`}
                  >
                    {spPreset.label}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-500">
                তুষারকণা কত দ্রুত বা ধীরে স্ক্রিনের ওপর থেকে নিচে পড়বে তা নির্ধারণ করুন।
              </p>
            </div>

            {/* 3. Auto-Off Timer */}
            <div className="bg-white/90 rounded-xl p-3.5 border border-sky-200/90 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-sky-700 shrink-0" />
                  <span>অটো-অফ টাইমার (কত সেকেন্ড পরে বন্ধ হবে)</span>
                </label>
                <span
                  className={`px-2.5 py-0.5 rounded-full font-mono text-[11px] font-extrabold border ${
                    landingSnowfallAutoOffSec > 0
                      ? 'bg-amber-100 text-amber-900 border-amber-300'
                      : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                  }`}
                >
                  {landingSnowfallAutoOffSec > 0
                    ? `${landingSnowfallAutoOffSec} সেকেন্ড পর বন্ধ`
                    : 'সবসময় চলবে (Always On)'}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { sec: 0, label: '♾️ সবসময় চলবে' },
                  { sec: 5, label: '৫ সেকেন্ড' },
                  { sec: 10, label: '১০ সেকেন্ড' },
                  { sec: 15, label: '১৫ সেকেন্ড' },
                  { sec: 30, label: '৩০ সেকেন্ড' },
                  { sec: 60, label: '৬০ সেকেন্ড' }
                ].map(timerOpt => (
                  <button
                    key={timerOpt.sec}
                    type="button"
                    onClick={() => {
                      updateBusiness({
                        landingSnowfallEnabled: true,
                        landingSnowfallAutoOffSec: timerOpt.sec
                      });
                      showToast(
                        timerOpt.sec === 0
                          ? 'ল্যান্ডিং পেজ তুষারপাত অ্যানিমেশন সবসময় চালু (Always On) রাখা হয়েছে!'
                          : `ল্যান্ডিং পেজ তুষারপাত অ্যানিমেশন ${timerOpt.sec} সেকেন্ড পর অটো বন্ধ হয়ে যাবে!`,
                        'success'
                      );
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                      landingSnowfallAutoOffSec === timerOpt.sec
                        ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {timerOpt.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 pt-0.5">
                <span className="text-[11px] font-bold text-slate-600 shrink-0">
                  কাস্টম সেকেন্ড:
                </span>
                <input
                  type="number"
                  min={0}
                  max={600}
                  step={1}
                  value={landingSnowfallAutoOffSec}
                  onChange={e => {
                    const nextSec = Math.max(0, Number(e.target.value) || 0);
                    updateBusiness({
                      landingSnowfallEnabled: true,
                      landingSnowfallAutoOffSec: nextSec
                    });
                  }}
                  className="w-20 min-h-[32px] px-2.5 py-1 bg-white border border-sky-300 focus:border-sky-600 rounded-lg font-mono text-xs font-extrabold text-slate-900 outline-hidden"
                />
                <span className="text-[10px] text-slate-500">(0 = অটো বন্ধ হবে না)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 🎉 Live Preview Overlay for Testing Celebration in Admin Panel */}
      <OrderCelebrationOverlay
        active={isAdminTestCelebrationActive}
        seed={adminTestCelebrationSeed}
        styleMode={globalLandingConfettiStyle}
        showCenterBadge={globalLandingConfettiBadgeEnabled}
        orderNo="LP-1024"
      />

      {/* 🎉 Landing Page Order Confirmation Luxury Celebration Control Card (ON/OFF + 4 Styles + Badge + Live Test) */}
      {showLandingCelebrationCard && (
        <div className="bg-gradient-to-r from-amber-50/90 via-white to-rose-50/80 rounded-2xl p-4 sm:p-5 border-2 border-amber-300 shadow-2xs space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-amber-600 to-rose-600 text-white text-[10px] font-extrabold uppercase tracking-wider">
                  🎉 Landing Page Order Celebration (60fps Physics)
                </span>
                <span
                  className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                    globalLandingConfettiEnabled
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  Status: {globalLandingConfettiEnabled ? 'ACTIVE (ON)' : 'DISABLED (OFF)'}
                </span>
              </div>
              <p className="text-sm font-extrabold text-slate-900">
                অর্ডার কনফার্ম হলে প্রিমিয়াম সেলিব্রেশন (Landing Page Order Celebration Engine)
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                কাস্টমার যেকোনো ল্যান্ডিং পেজে অর্ডার কনফার্ম করার সাথে সাথে স্ক্রিনে ২.৫ সেকেন্ডের একটি প্রিমিয়াম 60fps ফিজিক্স সেলিব্রেশন অ্যানিমেশন দেখাবে এবং স্বয়ংক্রিয়ভাবে বন্ধ হয়ে যাবে।
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  const nextState = !globalLandingConfettiEnabled;
                  updateBusiness({ landingOrderConfettiEnabled: nextState });
                  if (nextState) {
                    triggerAdminTestCelebration();
                  } else {
                    setIsAdminTestCelebrationActive(false);
                  }
                  showToast(
                    nextState
                      ? '🎉 সব ল্যান্ডিং পেজে অর্ডার সেলিব্রেশন চালু (ON) করা হয়েছে!'
                      : 'সব ল্যান্ডিং পেজে অর্ডার সেলিব্রেশন বন্ধ (OFF) করা হয়েছে।',
                    nextState ? 'success' : 'info'
                  );
                }}
                className={`min-h-[38px] px-4 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-2 shadow-2xs ${
                  globalLandingConfettiEnabled
                    ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-white hover:from-amber-600 hover:to-rose-700'
                    : 'bg-white text-slate-800 border border-slate-300 hover:bg-slate-100'
                }`}
              >
                <span>
                  {globalLandingConfettiEnabled
                    ? '🎉 সেলিব্রেশন: ON (বন্ধ করতে ক্লিক করুন)'
                    : '🎉 সেলিব্রেশন: OFF (চালু করতে ক্লিক করুন)'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const nextBadge = !globalLandingConfettiBadgeEnabled;
                  updateBusiness({ landingOrderCelebrationBadgeEnabled: nextBadge });
                  setTimeout(() => triggerAdminTestCelebration(), 30);
                }}
                className={`min-h-[38px] px-3.5 py-2 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                  globalLandingConfettiBadgeEnabled
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                    : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                }`}
              >
                🏅 মাঝখানের গোল্ডেন ব্যাজ: {globalLandingConfettiBadgeEnabled ? 'ON' : 'OFF'}
              </button>

              <button
                type="button"
                onClick={() => triggerAdminTestCelebration()}
                className="min-h-[38px] px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 text-xs font-extrabold transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
              >
                <span>✨ লাইভ টেস্ট দেখুন</span>
              </button>
            </div>
          </div>

          {/* 6 Luxury Celebration Style Selector Cards */}
          <div className="bg-white/95 rounded-xl p-3.5 border border-amber-200/80 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-extrabold text-slate-800">
                🎨 ল্যান্ডিং পেজের সেলিব্রেশন স্টাইল বেছে নিন (যেকোনো স্টাইলে ক্লিক করলে সাথে সাথে লাইভ প্রিভিউ দেখাবে):
              </span>
              <span className="text-[11px] font-bold text-amber-700">
                বর্তমান স্টাইল:{' '}
                {globalLandingConfettiStyle === 'dual_cannon_badge'
                  ? '🎊 ডাবল পার্টি ক্যানন'
                  : globalLandingConfettiStyle === 'royal_fireworks'
                    ? '🎆 রয়্যাল আতশবাজি'
                    : globalLandingConfettiStyle === 'luxury_gold_fountain'
                      ? '✨ ২৪-ক্যারেট গোল্ড ফাউন্টেন'
                      : globalLandingConfettiStyle === 'ramadan_noor_lanterns'
                        ? '🌙 রমজান নূর ও ফানুস'
                        : globalLandingConfettiStyle === 'eid_mubarak_royal'
                          ? '🕌 ঈদ মোবারক রয়্যাল উৎসব'
                          : '🎈 উৎসবমুখর বেলুন ও হার্টস'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {(
                [
                  {
                    id: 'dual_cannon_badge' as OrderCelebrationStyle,
                    title: '🎊 ১. ডাবল পার্টি ক্যানন',
                    desc: 'দুই কোণা থেকে 3D রিবন, তারা ও গোল্ডেন ফয়েল বিস্ফোরণ'
                  },
                  {
                    id: 'royal_fireworks' as OrderCelebrationStyle,
                    title: '🎆 ২. রয়্যাল আতশবাজি',
                    desc: 'আকাশে একাধিক রঙিন আতশবাজি ও ঝিকিমিকি গোল্ডেন স্পার্ক'
                  },
                  {
                    id: 'luxury_gold_fountain' as OrderCelebrationStyle,
                    title: '✨ ৩. ২৪-ক্যারেট গোল্ড ফাউন্টেন',
                    desc: 'নিচ থেকে ভিআইপি সোনালী ও পান্না ঝর্ণা এবং ডায়মন্ড ডাস্ট'
                  },
                  {
                    id: 'festive_balloons' as OrderCelebrationStyle,
                    title: '🎈 ৪. উৎসবমুখর বেলুন ও হার্টস',
                    desc: 'রঙিন গ্লসি বেলুন ও হার্টস ভেসে ওঠা + আনন্দময় কনফেটি'
                  },
                  {
                    id: 'ramadan_noor_lanterns' as OrderCelebrationStyle,
                    title: '🌙 ৫. রমজান নূর ও ফানুস',
                    desc: 'সোনালী বাঁকা চাঁদ, আরবি ফানুস ভেসে ওঠা ও পান্না-নূর স্টারবার্স্ট'
                  },
                  {
                    id: 'eid_mubarak_royal' as OrderCelebrationStyle,
                    title: '🕌 ৬. ঈদ মোবারক রয়্যাল উৎসব',
                    desc: 'ঈদের রয়্যাল আতশবাজি, সোনালী চাঁদ-তারা ও ডাবল ফেস্টিভ ক্যানন'
                  }
                ] as const
              ).map(opt => {
                const isSelected = globalLandingConfettiStyle === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      updateBusiness({
                        landingOrderConfettiEnabled: true,
                        landingOrderConfettiStyle: opt.id
                      });
                      setTimeout(() => triggerAdminTestCelebration(), 30);
                    }}
                    className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-br from-amber-50 via-white to-rose-50 border-amber-500 ring-2 ring-amber-400/40 shadow-2xs'
                        : 'bg-slate-50/80 border-slate-200 hover:bg-white hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1.5 mb-1">
                      <span className="text-xs font-extrabold text-slate-900">{opt.title}</span>
                      {isSelected && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-500 text-white text-[9px] font-extrabold">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-600 leading-snug">{opt.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Landing Page Products Grid */}
      {landingProducts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto">
            <Rocket className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No Landing Page Products Yet</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Create your first single-product landing page to get a dedicated ad link with a built-in direct order form.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => handleOpenAddModal('template_1')}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Landing Page 1 (Single Product)</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenAddModal('template_2')}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-[#c30000] hover:bg-[#9e0000] text-white text-xs font-extrabold rounded-xl cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>Create Landing Page 2 (Multi-Product Showcase)</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenAddModal('template_3')}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Create Landing Page 3 (Multiple Product Order)</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {landingProducts.map(product => {
            const lpPath = buildLandingPagePath(product);
            const fullUrl =
              typeof window !== 'undefined' ? `${window.location.origin}${lpPath}` : lpPath;
            const isCopied = copiedId === product.id;
            const stock = Object.values(product.stockByOutlet).reduce((s, q) => s + (q || 0), 0);

            // Count orders for this landing page product from unified onlineOrders
            const productOrders = onlineOrders.filter(o =>
              o.items?.some(it => it.productId === product.id)
            );
            const productRevenue = productOrders
              .filter(o => o.orderStatus !== 'cancelled')
              .reduce((s, o) => s + o.grandTotal, 0);

            return (
              <div
                key={product.id}
                className="bg-white rounded-2xl border border-slate-200/90 hover:border-emerald-300 shadow-2xs p-4 sm:p-5 flex flex-col justify-between gap-4 transition-all"
              >
                <div className="space-y-3.5">
                  {/* Product Top Info */}
                  <div className="flex items-start gap-3.5">
                    <div className="w-20 h-20 rounded-2xl bg-slate-50 border border-slate-200 overflow-hidden shrink-0">
                      <ProductThumbnail product={product} imgClassName="p-1.5" />
                    </div>

                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {product.landingTemplate === 'template_3' ? (
                          <span className="px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-extrabold inline-flex items-center gap-1">
                            <ShoppingBag className="w-3 h-3" />
                            <span>
                              Landing Page 3 • Multi-Product Order (
                              {product.landingShowcaseItems?.length || 5}টি প্রোডাক্ট একসাথে অর্ডার)
                            </span>
                          </span>
                        ) : product.landingTemplate === 'template_2' ? (
                          <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-extrabold inline-flex items-center gap-1">
                            <Layers className="w-3 h-3" />
                            <span>
                              Landing Page 2 • Multi-Product (
                              {product.landingShowcaseItems?.length || 5}টি ড্রেস)
                            </span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                            Landing Page 1 (Single Product)
                          </span>
                        )}
                        {product.freeDeliveryOnLanding && (
                          <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold">
                            Free Delivery
                          </span>
                        )}
                        <span className="text-[11px] font-mono text-slate-500 font-semibold">
                          SKU: {product.sku}
                        </span>
                        {product.wpProductId && product.wpProductId > 0 ? (
                          <span className="px-2 py-0.5 rounded-md bg-sky-50 text-sky-800 border border-sky-200 font-mono text-[10px] font-bold">
                            WP ID: #{product.wpProductId}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-mono text-[10px] font-medium">
                            WP Auto-Match by SKU
                          </span>
                        )}
                      </div>

                      <h3 className="text-sm sm:text-base font-bold text-slate-900 line-clamp-2">
                        {product.nameBn}
                      </h3>

                      <div className="flex flex-wrap items-baseline gap-2 pt-0.5">
                        <span className="font-mono font-extrabold text-base text-emerald-700">
                          ৳{product.retailPrice}
                        </span>
                        {product.regularPrice && product.regularPrice > product.retailPrice && (
                          <span className="font-mono text-xs text-slate-400 line-through">
                            ৳{product.regularPrice}
                          </span>
                        )}
                        <span className="text-xs text-slate-400">•</span>
                        <span className="text-xs font-medium text-slate-600">
                          Stock: <strong className="font-mono">{stock}</strong>
                        </span>
                        {product.variants && product.variants.length > 0 && (
                          <>
                            <span className="text-xs text-slate-400">•</span>
                            <span className="text-xs font-semibold text-emerald-700">
                              {product.variants.length} Variations
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Variations Pills Preview with Variation SKU, WP Variation ID & 1-Click Out of Stock Toggle */}
                  {product.variants && product.variants.length > 0 && (
                    <div className="space-y-1 pt-1">
                      <span className="text-[10px] font-bold text-slate-500 block">
                        সাইজ/ভ্যারিয়েশন (যেকোনো ভ্যারিয়েশনে ক্লিক করে স্টক আউট বা স্টকে আছে করুন):
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {product.variants.map((v, vIdx) => {
                          const effSku = v.sku || buildVariantSkuCode(product.sku, v.label, vIdx);
                          const isVarOut = Boolean(v.outOfStock);
                          return (
                            <button
                              key={v.id}
                              type="button"
                              onClick={() => {
                                const nextVariants = (product.variants || []).map((item, i) =>
                                  i === vIdx ? { ...item, outOfStock: !item.outOfStock } : item
                                );
                                updateProduct(product.id, { variants: nextVariants });
                                showToast(
                                  !isVarOut
                                    ? `"${v.label}" ভ্যারিয়েশনটি ল্যান্ডিং পেজে স্টক আউট করা হয়েছে`
                                    : `"${v.label}" ভ্যারিয়েশনটি পুনরায় স্টকে চালু করা হয়েছে`,
                                  !isVarOut ? 'info' : 'success'
                                );
                              }}
                              title={
                                isVarOut
                                  ? 'এই ভ্যারিয়েশনটি বর্তমানে স্টক আউট আছে — ক্লিক করে স্টকে আনুন'
                                  : 'ক্লিক করে এই ভ্যারিয়েশনটি ম্যানুয়ালি স্টক আউট করুন'
                              }
                              className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                                isVarOut
                                  ? 'bg-rose-50 border-rose-300 text-rose-700 line-through opacity-85 hover:bg-rose-100'
                                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-emerald-400 hover:bg-emerald-50/40'
                              }`}
                            >
                              <span>{v.label}:</span>
                              <strong className={`font-mono ${isVarOut ? 'text-rose-700' : 'text-emerald-700'}`}>
                                ৳{v.retailPrice}
                              </strong>
                              <span
                                className={`px-1.5 py-0.2 rounded font-mono text-[10px] ${
                                  isVarOut
                                    ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                    : 'bg-sky-50 text-sky-800 border border-sky-200/80'
                                }`}
                              >
                                {effSku}
                              </span>
                              {v.wpVariationId && v.wpVariationId > 0 && (
                                <span className="px-1 py-0.2 rounded bg-emerald-100 text-emerald-800 font-mono font-bold text-[9px]">
                                  #{v.wpVariationId}
                                </span>
                              )}
                              {isVarOut && (
                                <span className="px-1.5 py-0.2 rounded bg-rose-600 text-white font-bold text-[9px] no-underline">
                                  স্টক শেষ
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Shareable Landing Page Link Box */}
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/90 flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                        Dedicated Ad Landing Link
                      </span>
                      <p className="text-xs font-mono font-semibold text-emerald-800 truncate mt-0.5">
                        {fullUrl}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleCopyLandingUrl(product)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 border transition-colors cursor-pointer ${
                          isCopied
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Link</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => onPreviewLandingProduct(product)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Open Page</span>
                      </button>
                    </div>
                  </div>

                  {/* Quick 1-Click Toggles for Product Stock Status, Top Animated Heading, Call Button, WhatsApp Button & Customer Reviews */}
                  <div className="flex flex-wrap items-center gap-2 pt-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        const nextOut = !product.isOutOfStock;
                        updateProduct(product.id, { isOutOfStock: nextOut });
                        showToast(
                          nextOut
                            ? `"${product.nameBn}" ল্যান্ডিং পেজে স্টক আউট (Out of Stock) করা হয়েছে`
                            : `"${product.nameBn}" পুনরায় ইন-স্টক (In Stock) করা হয়েছে`,
                          nextOut ? 'info' : 'success'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.isOutOfStock
                          ? 'bg-rose-600 text-white border-rose-600 hover:bg-rose-700'
                          : 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                      }`}
                      title="পুরো ল্যান্ডিং পেজ প্রোডাক্টটি ১-ক্লিকে স্টক আউট বা স্টকে আছে করুন"
                    >
                      <span>
                        {product.isOutOfStock
                          ? '🚫 স্টক শেষ (চালু করুন)'
                          : '✓ স্টকে আছে (আউট করুন)'}
                      </span>
                    </button>

                    {(product.landingTemplate === 'template_2' ||
                      product.landingTemplate === 'template_3') && (
                      <button
                        type="button"
                        onClick={() => {
                          const nextVal = !Boolean(product.landingShowcaseMobileTwoCols);
                          updateProduct(product.id, { landingShowcaseMobileTwoCols: nextVal });
                          showToast(
                            nextVal
                              ? `"${product.nameBn}"-এ মোবাইলে ১ লাইনে ২টি করে প্রোডাক্ট (2 কলাম) চালু (ON) করা হয়েছে!`
                              : `"${product.nameBn}"-এ মোবাইলে ১ লাইনে ১টি করে প্রোডাক্ট (1 কলাম) সেট (OFF) করা হয়েছে!`,
                            nextVal ? 'success' : 'info'
                          );
                        }}
                        className={`px-2.5 py-1 rounded-lg border text-[11px] font-extrabold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                          product.landingShowcaseMobileTwoCols
                            ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                            : 'bg-rose-50 text-rose-900 border-rose-300 hover:bg-rose-100'
                        }`}
                        title="মোবাইলে ১ লাইনে ২টি প্রোডাক্ট (ON) নাকি ১টি প্রোডাক্ট (OFF) দেখাবে তা পরিবর্তন করুন"
                      >
                        <Layers className="w-3 h-3" />
                        <span>
                          📱 মোবাইলে ২টি করে প্রোডাক্ট:{' '}
                          {product.landingShowcaseMobileTwoCols ? 'ON (২টি/লাইন)' : 'OFF (১টি/লাইন)'}
                        </span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        const isCurrOn =
                          product.landingFreeDeliveryByQtyEnabled !== undefined
                            ? Boolean(product.landingFreeDeliveryByQtyEnabled)
                            : Boolean(
                                currentBusiness.landingFreeDeliveryByQtyEnabled ??
                                  currentBusiness.freeDeliveryByQtyEnabled
                              );
                        const currMin = Number(
                          product.landingFreeDeliveryMinQty ||
                            currentBusiness.landingFreeDeliveryMinQty ||
                            currentBusiness.freeDeliveryMinQty ||
                            2
                        );
                        if (!isCurrOn) {
                          updateProduct(product.id, {
                            landingFreeDeliveryByQtyEnabled: true,
                            landingFreeDeliveryMinQty: 2
                          });
                          showToast(
                            `"${product.nameBn}" ল্যান্ডিং পেজে "২ পিস কিনলে ডেলিভারি ফ্রি" চালু হয়েছে!`,
                            'success'
                          );
                        } else if (currMin === 2) {
                          updateProduct(product.id, {
                            landingFreeDeliveryByQtyEnabled: true,
                            landingFreeDeliveryMinQty: 3
                          });
                          showToast(
                            `"${product.nameBn}" ল্যান্ডিং পেজে "৩ পিস কিনলে ডেলিভারি ফ্রি" সেট করা হয়েছে!`,
                            'success'
                          );
                        } else {
                          updateProduct(product.id, {
                            landingFreeDeliveryByQtyEnabled: false
                          });
                          showToast(
                            `"${product.nameBn}" ল্যান্ডিং পেজে পিস হিসেবে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে`,
                            'info'
                          );
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        (product.landingFreeDeliveryByQtyEnabled !== undefined
                          ? Boolean(product.landingFreeDeliveryByQtyEnabled)
                          : Boolean(
                              currentBusiness.landingFreeDeliveryByQtyEnabled ??
                                currentBusiness.freeDeliveryByQtyEnabled
                            ))
                          ? 'bg-amber-50 text-amber-950 border-amber-400 hover:bg-amber-100'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="১-ক্লিকে এই ল্যান্ডিং পেজে ২ পিস বা ৩ পিস কিনলে ডেলিভারি ফ্রি অফার চালু/পরিবর্তন/বন্ধ করুন"
                    >
                      <span>
                        {(product.landingFreeDeliveryByQtyEnabled !== undefined
                          ? Boolean(product.landingFreeDeliveryByQtyEnabled)
                          : Boolean(
                              currentBusiness.landingFreeDeliveryByQtyEnabled ??
                                currentBusiness.freeDeliveryByQtyEnabled
                            ))
                          ? `🚚 ${
                              product.landingFreeDeliveryMinQty ||
                              currentBusiness.landingFreeDeliveryMinQty ||
                              currentBusiness.freeDeliveryMinQty ||
                              2
                            } পিসে ফ্রি ডেলিভারি: ON`
                          : '🚚 ২/৩ পিসে ফ্রি ডেলিভারি: OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingTopHeadingEnabled === false;
                        updateProduct(product.id, { landingTopHeadingEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'প্রোডাক্ট ছবির শুরুতে অ্যানিমেশন হেডিং চালু (ON) করা হয়েছে'
                            : 'প্রোডাক্ট ছবির শুরুতে হেডিং বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingTopHeadingEnabled !== false
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="প্রোডাক্ট ছবির শুরুতে হেডিং চালু বা বন্ধ করুন"
                    >
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>টপ হেডিং: {product.landingTopHeadingEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    {product.landingTopHeadingEnabled !== false && (
                      <button
                        type="button"
                        onClick={() => {
                          const nextVal = product.landingTopHeadingAnimation === false;
                          updateProduct(product.id, { landingTopHeadingAnimation: nextVal });
                          showToast(
                            nextVal
                              ? 'হেডিং অ্যানিমেশন চালু (ON) করা হয়েছে'
                              : 'হেডিং অ্যানিমেশন বন্ধ (OFF) করা হয়েছে',
                            'info'
                          );
                        }}
                        className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                          product.landingTopHeadingAnimation !== false
                            ? 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100'
                            : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                        }`}
                        title="হেডিংয়ের অ্যানিমেশন ইফেক্ট চালু বা বন্ধ করুন"
                      >
                        <span>অ্যানিমেশন: {product.landingTopHeadingAnimation !== false ? 'ON' : 'OFF'}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingTopPriceBannerEnabled === false;
                        updateProduct(product.id, { landingTopPriceBannerEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'শুরুতে পূর্বের মূল্য ও আজকের অফার মূল্য অ্যানিমেশন ব্যানার চালু (ON) করা হয়েছে'
                            : 'শুরুতে পূর্বের মূল্য ও আজকের অফার মূল্য অ্যানিমেশন ব্যানার বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingTopPriceBannerEnabled !== false
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="শুরুতে পূর্বের মূল্য ও আজকের অফার মূল্য অ্যানিমেশন ব্যানার ON/OFF করুন"
                    >
                      <Flame className="w-3 h-3 text-rose-600" />
                      <span>
                        টপ প্রাইস ব্যানার:{' '}
                        {product.landingTopPriceBannerEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const cur =
                          product.landingPromoBannerEnabled !== undefined
                            ? product.landingPromoBannerEnabled
                            : Boolean(product.landingPromoBannerImage);
                        const nextVal = !cur;
                        updateProduct(product.id, { landingPromoBannerEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'ব্যানার ১ (শুরুতে) চালু (ON) করা হয়েছে'
                            : 'ব্যানার ১ (শুরুতে) বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        (product.landingPromoBannerEnabled ?? Boolean(product.landingPromoBannerImage))
                          ? 'bg-teal-50 text-teal-900 border-teal-300 hover:bg-teal-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ল্যান্ডিং পেজের শুরুতে ব্যানার ১ (Banner 1) ON/OFF করুন"
                    >
                      <ImageIcon className="w-3 h-3 text-teal-600" />
                      <span>
                        ব্যানার ১:{' '}
                        {(product.landingPromoBannerEnabled ?? Boolean(product.landingPromoBannerImage))
                          ? 'ON'
                          : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const cur =
                          product.landingPromoBanner2Enabled !== undefined
                            ? product.landingPromoBanner2Enabled
                            : Boolean(product.landingPromoBanner2Image);
                        const nextVal = !cur;
                        updateProduct(product.id, { landingPromoBanner2Enabled: nextVal });
                        showToast(
                          nextVal
                            ? 'ব্যানার ২ (ভিডিও সেকশনের উপরে) চালু (ON) করা হয়েছে'
                            : 'ব্যানার ২ (ভিডিও সেকশনের উপরে) বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        (product.landingPromoBanner2Enabled ?? Boolean(product.landingPromoBanner2Image))
                          ? 'bg-cyan-50 text-cyan-900 border-cyan-300 hover:bg-cyan-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ভিডিও সেকশনের উপরে ব্যানার ২ (Banner 2) ON/OFF করুন"
                    >
                      <ImageIcon className="w-3 h-3 text-cyan-600" />
                      <span>
                        ব্যানার ২:{' '}
                        {(product.landingPromoBanner2Enabled ?? Boolean(product.landingPromoBanner2Image))
                          ? 'ON'
                          : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingCountdownEnabled === false;
                        updateProduct(product.id, { landingCountdownEnabled: nextVal });
                        showToast(
                          nextVal
                            ? `হিরো কাউন্টডাউন টাইমার (${product.landingCountdownHours || 9} ঘণ্টা) চালু (ON) করা হয়েছে`
                            : 'হিরো কাউন্টডাউন টাইমার বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingCountdownEnabled !== false
                          ? 'bg-rose-50 text-rose-900 border-rose-300 hover:bg-rose-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ল্যান্ডিং পেজে অফার কাউন্টডাউন টাইমার চালু বা বন্ধ করুন"
                    >
                      <Clock className="w-3 h-3 text-rose-600" />
                      <span>
                        কাউন্টডাউন ({product.landingCountdownHours || 9}h):{' '}
                        {product.landingCountdownEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingLiveViewersEnabled === false;
                        updateProduct(product.id, { landingLiveViewersEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'লাইভ ভিউয়ার কাউন্টার (12-48) চালু (ON) করা হয়েছে'
                            : 'লাইভ ভিউয়ার কাউন্টার বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingLiveViewersEnabled !== false
                          ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="প্রোডাক্ট ল্যান্ডিং পেজে 'People currently viewing this product' কাউন্টার চালু বা বন্ধ করুন"
                    >
                      <Eye className="w-3 h-3 text-amber-700" />
                      <span>
                        লাইভ ভিউয়ার (12-48):{' '}
                        {product.landingLiveViewersEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingScarcityEnabled === false;
                        updateProduct(product.id, { landingScarcityEnabled: nextVal });
                        showToast(
                          nextVal
                            ? `সীমিত স্টক ও প্রচুর চাহিদা অ্যালার্ট (${product.landingScarcityCount || 10} টি বাকি) চালু (ON) করা হয়েছে`
                            : 'সীমিত স্টক ও প্রচুর চাহিদা অ্যালার্ট বন্ধ (OFF) করা হয়েছে',
                          nextVal ? 'success' : 'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingScarcityEnabled !== false
                          ? 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ল্যান্ডিং পেজে 'অফার মূল্যে আর মাত্র 10 টি বাকি আছে! / প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে / সীমিত স্টক' অ্যালার্ট ON বা OFF করুন"
                    >
                      <Flame className="w-3 h-3 text-rose-600" />
                      <span>
                        সীমিত স্টক ({product.landingScarcityCount || 10} টি):{' '}
                        {product.landingScarcityEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingTopHeaderEnabled === false;
                        updateProduct(product.id, { landingTopHeaderEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'ল্যান্ডিং পেজের টপ হেডার বার (লোগো ও ফোন নম্বর) চালু (ON) করা হয়েছে'
                            : 'ল্যান্ডিং পেজের টপ হেডার বার (লোগো ও ফোন নম্বর) বন্ধ (OFF) করা হয়েছে',
                          nextVal ? 'success' : 'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingTopHeaderEnabled !== false
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ল্যান্ডিং পেজের একদম উপরের হেডার বার (লোগো ও ফোন নম্বর বার) ON বা OFF করুন"
                    >
                      <PhoneCall className="w-3 h-3 text-emerald-600" />
                      <span>
                        টপ হেডার (লোগো ও ফোন): {product.landingTopHeaderEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingShowCallButton === false;
                        updateProduct(product.id, { landingShowCallButton: nextVal });
                        showToast(
                          nextVal
                            ? 'Landing Page Call বাটন চালু করা হয়েছে'
                            : 'Landing Page Call বাটন বন্ধ করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingShowCallButton !== false
                          ? 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Click to Enable / Disable Top Call Button on this Landing Page"
                    >
                      <PhoneCall className="w-3 h-3" />
                      <span>Call বাটন: {product.landingShowCallButton !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingShowWhatsappButton === false;
                        updateProduct(product.id, { landingShowWhatsappButton: nextVal });
                        showToast(
                          nextVal
                            ? 'Landing Page WhatsApp বাটন চালু করা হয়েছে'
                            : 'Landing Page WhatsApp বাটন বন্ধ করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingShowWhatsappButton !== false
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Click to Enable / Disable Top WhatsApp Button on this Landing Page"
                    >
                      <MessageCircle className="w-3 h-3" />
                      <span>WhatsApp বাটন: {product.landingShowWhatsappButton !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingFeaturesEnabled === false;
                        updateProduct(product.id, { landingFeaturesEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস সেকশন চালু (ON) করা হয়েছে'
                            : 'ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস সেকশন বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingFeaturesEnabled !== false
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস সেকশন ON/OFF করুন"
                    >
                      <BadgeCheck className="w-3 h-3 text-emerald-600" />
                      <span>ডিটেইলস সেকশন: {product.landingFeaturesEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingTrustSectionEnabled === false;
                        updateProduct(product.id, { landingTrustSectionEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'গ্যারান্টি ও বিশ্বস্ত শপিং সেকশন চালু (ON) করা হয়েছে'
                            : 'গ্যারান্টি ও বিশ্বস্ত শপিং সেকশন বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingTrustSectionEnabled !== false
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন সেকশন ON/OFF করুন"
                    >
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      <span>গ্যারান্টি টপিক: {product.landingTrustSectionEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingVideoEnabled === false;
                        updateProduct(product.id, { landingVideoEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'প্রোডাক্ট ভিডিও / রিলস সেকশন চালু (ON) করা হয়েছে'
                            : 'প্রোডাক্ট ভিডিও / রিলস সেকশন বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingVideoEnabled !== false
                          ? 'bg-rose-50 text-rose-900 border-rose-300 hover:bg-rose-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="প্রোডাক্ট ভিডিও / ইউটিউব বা রিলস ভিডিও সেকশন ON/OFF করুন"
                    >
                      <Play className="w-3 h-3 text-rose-600" />
                      <span>ভিডিও সেকশন: {product.landingVideoEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingSizeChartEnabled === false;
                        updateProduct(product.id, { landingSizeChartEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'সাইজ চার্ট সেকশন চালু (ON) করা হয়েছে'
                            : 'সাইজ চার্ট সেকশন বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingSizeChartEnabled !== false
                          ? 'bg-indigo-50 text-indigo-900 border-indigo-300 hover:bg-indigo-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ভ্যারিয়েশনের উপরের 'সাইজ চার্ট দেখুন' পপ-আপ বাটন ON/OFF করুন"
                    >
                      <Ruler className="w-3 h-3 text-indigo-600" />
                      <span>পপ-আপ চার্ট: {product.landingSizeChartEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingBodySizeChartEnabled === false;
                        updateProduct(product.id, { landingBodySizeChartEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'পেজের বডিতে ফুল সাইজ চার্ট টেবিল চালু (ON) করা হয়েছে'
                            : 'পেজের বডিতে ফুল সাইজ চার্ট টেবিল বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingBodySizeChartEnabled !== false
                          ? 'bg-violet-50 text-violet-900 border-violet-300 hover:bg-violet-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ডেসক্রিপশনের নিচে বডির ভেতর ফুল সাইজ চার্ট সেকশন ON/OFF করুন"
                    >
                      <Ruler className="w-3 h-3 text-violet-600" />
                      <span>বডি ফুল চার্ট: {product.landingBodySizeChartEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingSpinWheelEnabled === false;
                        updateProduct(product.id, { landingSpinWheelEnabled: nextVal });
                        if (nextVal && currentBusiness.landingSpinWheelEnabled === false) {
                          updateBusiness({ landingSpinWheelEnabled: true });
                        }
                        showToast(
                          nextVal
                            ? 'এই ল্যান্ডিং পেজে স্পিন দ্য হুইল চালু (ON) করা হয়েছে'
                            : 'এই ল্যান্ডিং পেজে স্পিন দ্য হুইল বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingSpinWheelEnabled !== false && globalLandingSpinEnabled
                          ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="এই ল্যান্ডিং পেজে স্পিন দ্য হুইল (Spin the Wheel) অটো পপ-আপ ON/OFF করুন"
                    >
                      <Gift className="w-3 h-3 text-amber-600" />
                      <span>
                        স্পিন হুইল:{' '}
                        {product.landingSpinWheelEnabled !== false && globalLandingSpinEnabled
                          ? 'ON'
                          : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingSocialProofEnabled === false;
                        updateProduct(product.id, { landingSocialProofEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ চালু (ON) করা হয়েছে'
                            : 'রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingSocialProofEnabled !== false
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ (Live Order Social Proof) ON/OFF করুন"
                    >
                      <Bell className="w-3 h-3 text-emerald-600" />
                      <span>অর্ডার পপ-আপ: {product.landingSocialProofEnabled !== false ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = !product.landingReviewsEnabled;
                        updateProduct(product.id, { landingReviewsEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'কাস্টমার রিভিউ সেকশন চালু করা হয়েছে'
                            : 'কাস্টমার রিভিউ সেকশন বন্ধ করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingReviewsEnabled
                          ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Click to Enable / Disable Customer Reviews on this Landing Page"
                    >
                      <Star className="w-3 h-3" />
                      <span>কাস্টমার রিভিউ: {product.landingReviewsEnabled ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingFooterWarningEnabled === false;
                        updateProduct(product.id, { landingFooterWarningEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'ফুটার ফেক অর্ডার সতর্কবার্তা চালু (ON) করা হয়েছে'
                            : 'ফুটার ফেক অর্ডার সতর্কবার্তা বন্ধ (OFF) করা হয়েছে',
                          'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingFooterWarningEnabled !== false
                          ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ল্যান্ডিং পেজ ফুটারে ফেক অর্ডার না করার অনুরোধ বার্তা ON/OFF করুন"
                    >
                      <AlertTriangle className="w-3 h-3 text-amber-600" />
                      <span>
                        ফেক অর্ডার নোটিশ: {product.landingFooterWarningEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextVal = product.landingFloatingBtnPriceEnabled === false;
                        updateProduct(product.id, { landingFloatingBtnPriceEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'মোবাইল ফ্লোটিং বাটনে মোট প্রাইস — অর্ডার কনফার্ম করুন (৳1,010) চালু (ON) করা হয়েছে'
                            : 'মোবাইল ফ্লোটিং বাটনে প্রাইস বন্ধ (OFF) করা হয়েছে',
                          nextVal ? 'success' : 'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        product.landingFloatingBtnPriceEnabled !== false
                          ? 'bg-rose-50 text-rose-900 border-rose-300 hover:bg-rose-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="মোবাইল ভিউতে নিচের ফ্লোটিং 'অর্ডার কনফার্ম করুন' বাটনের ভেতর মোট প্রাইস (যেমন: ৳1,010) ON/OFF করুন"
                    >
                      <ShoppingBag className="w-3 h-3 text-rose-600" />
                      <span>
                        ফ্লোটিং বাটন প্রাইস: {product.landingFloatingBtnPriceEnabled !== false ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const animList: Array<{ id: LandingFloatingBtnAnimation; label: string }> = [
                          { id: 'jump', label: 'জাম্প বাউন্স (Default)' },
                          { id: 'login_shine', label: 'লগইন বাটন শাইন' },
                          { id: 'cart_beam', label: 'কার্ট বাটন বর্ডার বিম' },
                          { id: 'combo_beam', label: 'প্রিমিয়াম কম্বো (বিম + শাইন)' },
                          { id: 'glow_pulse', label: 'রিং পালস গ্লো' },
                          { id: 'none', label: 'অ্যানিমেশন বন্ধ' }
                        ];
                        const cur = product.landingFloatingBtnAnimation || 'jump';
                        const curIdx = animList.findIndex(a => a.id === cur);
                        const next = animList[(curIdx + 1) % animList.length];
                        updateProduct(product.id, { landingFloatingBtnAnimation: next.id });
                        showToast(
                          `ফ্লোটিং অর্ডার বাটন অ্যানিমেশন: "${next.label}" সেট করা হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-50 via-rose-50 to-emerald-50 text-slate-900 border-amber-300 hover:border-rose-400 transition-colors cursor-pointer"
                      title="ফ্লোটিং অর্ডার কনফার্ম বাটনের অ্যানিমেশন পরিবর্তন করুন (জাম্প বাউন্স / লগইন শাইন / কার্ট বর্ডার বিম / প্রিমিয়াম কম্বো / রিং পালস গ্লো / বন্ধ)"
                    >
                      <Sparkles className="w-3 h-3 text-amber-600" />
                      <span>
                        ফ্লোটিং অ্যানিমেশন:{' '}
                        {(product.landingFloatingBtnAnimation || 'jump') === 'jump'
                          ? 'জাম্প বাউন্স'
                          : product.landingFloatingBtnAnimation === 'login_shine'
                          ? 'লগইন শাইন'
                          : product.landingFloatingBtnAnimation === 'cart_beam'
                          ? 'কার্ট বর্ডার বিম'
                          : product.landingFloatingBtnAnimation === 'combo_beam'
                          ? 'প্রিমিয়াম কম্বো'
                          : product.landingFloatingBtnAnimation === 'glow_pulse'
                          ? 'রিং পালস গ্লো'
                          : 'বন্ধ'}
                      </span>
                    </button>

                    {/* 1-Click Variation Switcher Design Cycle */}
                    <button
                      type="button"
                      onClick={() => {
                        const curStyle: LandingVariantDesign =
                          product.landingVariantStyle ||
                          currentBusiness.landingVariantStyle ||
                          'classic_radio_list';
                        const curIdx = LANDING_VARIANT_DESIGN_OPTIONS.findIndex(
                          o => o.id === curStyle
                        );
                        const nextOpt =
                          LANDING_VARIANT_DESIGN_OPTIONS[
                            (curIdx + 1) % LANDING_VARIANT_DESIGN_OPTIONS.length
                          ];
                        updateProduct(product.id, { landingVariantStyle: nextOpt.id });
                        updateBusiness({ landingVariantStyle: nextOpt.id });
                        showToast(
                          `ভ্যারিয়েশন বাটন ডিজাইন: "${nextOpt.label}" সেট করা হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-950 border-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer"
                      title="ল্যান্ডিং পেজের ভ্যারিয়েশন / সাইজ সিলেক্টর ডিজাইন পরিবর্তন করুন (৬টি মোবাইল রেসপনসিভ ডিজাইন)"
                    >
                      <Layers className="w-3 h-3 text-emerald-600" />
                      <span>
                        ভ্যারিয়েশন ডিজাইন:{' '}
                        {(
                          LANDING_VARIANT_DESIGN_OPTIONS.find(
                            o =>
                              o.id ===
                              (product.landingVariantStyle ||
                                currentBusiness.landingVariantStyle ||
                                'classic_radio_list')
                          ) || LANDING_VARIANT_DESIGN_OPTIONS[0]
                        ).shortLabel}
                      </span>
                    </button>

                    {/* 1-Click Variation Price ON/OFF Toggle */}
                    <button
                      type="button"
                      onClick={() => {
                        const curShow =
                          product.landingVariantShowPrice ??
                          currentBusiness.landingVariantShowPrice ??
                          false;
                        const nextVal = !curShow;
                        updateProduct(product.id, { landingVariantShowPrice: nextVal });
                        updateBusiness({ landingVariantShowPrice: nextVal });
                        showToast(
                          nextVal
                            ? 'ভ্যারিয়েশন বাটনের ভেতর প্রাইস দেখানো চালু (ON) করা হয়েছে'
                            : 'ভ্যারিয়েশন বাটনের ভেতর প্রাইস বন্ধ (OFF) করা হয়েছে',
                          nextVal ? 'success' : 'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        (product.landingVariantShowPrice ??
                          currentBusiness.landingVariantShowPrice ??
                          false)
                          ? 'bg-cyan-50 text-cyan-900 border-cyan-300 hover:bg-cyan-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="ভ্যারিয়েশন বাটনের ভেতর দাম (Price) দেখানো ON/OFF করুন"
                    >
                      <span>
                        ভ্যারিয়েশন প্রাইস:{' '}
                        {(product.landingVariantShowPrice ??
                          currentBusiness.landingVariantShowPrice ??
                          false)
                          ? 'ON'
                          : 'OFF'}
                      </span>
                    </button>

                    {/* 1-Click Product Image % Discount Badge ON/OFF Toggle */}
                    <button
                      type="button"
                      onClick={() => {
                        const curOn =
                          product.landingImageBadgeEnabled ??
                          currentBusiness.landingImageBadgeEnabled ??
                          true;
                        const nextVal = !curOn;
                        updateProduct(product.id, { landingImageBadgeEnabled: nextVal });
                        updateBusiness({ landingImageBadgeEnabled: nextVal });
                        showToast(
                          nextVal
                            ? 'প্রোডাক্ট ছবির উপরে "% ছাড়" ব্যাজ চালু (ON) করা হয়েছে'
                            : 'প্রোডাক্ট ছবির উপরে "% ছাড়" ব্যাজ বন্ধ (OFF) করা হয়েছে',
                          nextVal ? 'success' : 'info'
                        );
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                        (product.landingImageBadgeEnabled ??
                          currentBusiness.landingImageBadgeEnabled ??
                          true)
                          ? 'bg-rose-50 text-rose-900 border-rose-300 hover:bg-rose-100'
                          : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="প্রোডাক্ট ছবির উপরের '% ছাড়' ব্যাজ ON/OFF করুন"
                    >
                      <span>
                        ছবির % ছাড় ব্যাজ:{' '}
                        {(product.landingImageBadgeEnabled ??
                          currentBusiness.landingImageBadgeEnabled ??
                          true)
                          ? 'ON'
                          : 'OFF'}
                      </span>
                    </button>

                    {/* 1-Click Product Image % Discount Badge Design Switcher */}
                    <button
                      type="button"
                      onClick={() => {
                        const curStyle: LandingImageBadgeDesign =
                          product.landingImageBadgeStyle ||
                          currentBusiness.landingImageBadgeStyle ||
                          'classic_red';
                        const curIdx = LANDING_IMAGE_BADGE_DESIGN_OPTIONS.findIndex(
                          o => o.id === curStyle
                        );
                        const nextOpt =
                          LANDING_IMAGE_BADGE_DESIGN_OPTIONS[
                            (curIdx + 1) % LANDING_IMAGE_BADGE_DESIGN_OPTIONS.length
                          ];
                        updateProduct(product.id, {
                          landingImageBadgeEnabled: true,
                          landingImageBadgeStyle: nextOpt.id
                        });
                        updateBusiness({
                          landingImageBadgeEnabled: true,
                          landingImageBadgeStyle: nextOpt.id
                        });
                        showToast(
                          `ছবির % ছাড় ব্যাজ ডিজাইন: "${nextOpt.label}" সেট করা হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-2.5 py-1 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1.5 bg-amber-50 text-amber-950 border-amber-300 hover:bg-amber-100 transition-colors cursor-pointer"
                      title="প্রোডাক্ট ছবির উপরের '% ছাড়' ব্যাজের ডিজাইন পরিবর্তন করুন (৬টি ডিজাইন)"
                    >
                      <Sparkles className="w-3 h-3 text-amber-600" />
                      <span>
                        ছাড় ব্যাজ ডিজাইন:{' '}
                        {(
                          LANDING_IMAGE_BADGE_DESIGN_OPTIONS.find(
                            o =>
                              o.id ===
                              (product.landingImageBadgeStyle ||
                                currentBusiness.landingImageBadgeStyle ||
                                'classic_red')
                          ) || LANDING_IMAGE_BADGE_DESIGN_OPTIONS[0]
                        ).shortLabel}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Bottom Metrics & WordPress Sync / Edit / Delete Controls */}
                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-3 text-slate-600">
                    <span className="inline-flex items-center gap-1 font-medium">
                      <ShoppingBag className="w-3.5 h-3.5 text-emerald-600" />
                      Orders: <strong className="font-mono text-slate-900">{productOrders.length}</strong>
                    </span>
                    <span className="text-slate-300">|</span>
                    <span className="font-medium">
                      Sales: <strong className="font-mono text-emerald-700">{formatCurrency(productRevenue)}</strong>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={syncingProductId === product.id}
                      onClick={() => handleSyncLandingProductToWordPress(product)}
                      className="px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 font-semibold inline-flex items-center gap-1 cursor-pointer transition-colors disabled:opacity-60"
                      title="Create or Sync this Landing Page Product & Variations in WordPress"
                    >
                      <Link2 className="w-3.5 h-3.5" />
                      <span>{syncingProductId === product.id ? 'Syncing...' : 'WP Sync'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(product)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold inline-flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        deleteProduct(product.id);
                        showToast('Landing page product deleted', 'info');
                      }}
                      className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200/60 cursor-pointer transition-colors"
                      title="Delete Landing Page"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* CREATE / EDIT LANDING PAGE PRODUCT MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div
            onClick={() => setShowModal(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
          />

          <div className="relative w-full max-w-3xl bg-white rounded-2xl border border-slate-200 shadow-xl z-10 overflow-hidden my-8 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {editingProduct ? 'Edit Landing Page Product' : 'Create New Landing Page Product'}
                </h2>
                <p className="text-xs text-slate-500">
                  This product will be hidden from the main home page and accessible via its dedicated landing link.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSaveLandingProduct} className="p-5 overflow-y-auto space-y-5 text-xs">
              {/* 0. TEMPLATE SELECTOR: Template 1 (Existing) vs Template 2 (Landing Page 2) vs Template 3 (Landing Page 3 - Multiple Product Order) */}
              <div className="p-4 rounded-2xl bg-slate-50 border-2 border-slate-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>ল্যান্ডিং পেজ টেমপ্লেট নির্বাচন করুন (Choose Landing Page Template):</span>
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Template 1 ও Template 2 সম্পূর্ণ অপরিবর্তিত থাকবে। এক অর্ডারে একসাথে একাধিক প্রোডাক্ট অর্ডার করার জন্য <strong>Landing Page 3</strong> সিলেক্ট করুন।
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormLandingTemplate('template_1')}
                    className={`p-3.5 rounded-xl border-2 text-left transition-all cursor-pointer flex items-start gap-3 ${
                      formLandingTemplate === 'template_1'
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                        formLandingTemplate === 'template_1'
                          ? 'border-emerald-600 bg-emerald-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {formLandingTemplate === 'template_1' && <Check className="w-3 h-3" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                          Landing Page 1
                        </span>
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                          Single Product
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                        বর্তমান সিঙ্গেল-প্রোডাক্ট ল্যান্ডিং পেজ ডিজাইন (১০০% অপরিবর্তিত)।
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setFormLandingTemplate('template_2');
                      if (formShowcaseItems.length === 0 && websiteProducts.length > 0) {
                        handleQuickSelectFiveWebsiteProducts();
                      }
                    }}
                    className={`p-3.5 rounded-xl border-2 text-left transition-all cursor-pointer flex items-start gap-3 ${
                      formLandingTemplate === 'template_2'
                        ? 'border-[#dc2626] bg-rose-50/70 shadow-2xs'
                        : 'border-slate-200 bg-white hover:border-rose-200'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                        formLandingTemplate === 'template_2'
                          ? 'border-[#dc2626] bg-[#dc2626] text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {formLandingTemplate === 'template_2' && <Check className="w-3 h-3" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                          Landing Page 2
                        </span>
                        <span className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-extrabold">
                          Showcase (1-Select)
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                        একাধিক ড্রেস শোকেস এবং কাস্টমার যেকোনো ১টি ড্রেস ও সাইজ বেছে অর্ডার করবে (১০০% অপরিবর্তিত)।
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setFormLandingTemplate('template_3');
                      if (formShowcaseItems.length === 0 && websiteProducts.length > 0) {
                        handleQuickSelectFiveWebsiteProducts();
                      }
                    }}
                    className={`p-3.5 rounded-xl border-2 text-left transition-all cursor-pointer flex items-start gap-3 ${
                      formLandingTemplate === 'template_3'
                        ? 'border-indigo-600 bg-indigo-50/70 shadow-2xs'
                        : 'border-slate-200 bg-white hover:border-indigo-200'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                        formLandingTemplate === 'template_3'
                          ? 'border-indigo-600 bg-indigo-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {formLandingTemplate === 'template_3' && <Check className="w-3 h-3" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                          Landing Page 3
                        </span>
                        <span className="px-2 py-0.5 rounded bg-indigo-600 text-white text-[10px] font-extrabold">
                          Multi-Product Order
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                        কাস্টমার একই ল্যান্ডিং পেজে টিক (✓) দিয়ে একসাথে একাধিক প্রোডাক্ট, কালার/সাইজ ও পরিমাণ সিলেক্ট করে অর্ডার করতে পারবে!
                      </p>
                    </div>
                  </button>
                </div>

                {/* LANDING PAGE 2 & LANDING PAGE 3 MULTI-PRODUCT CONFIGURER (Powered directly by existing website products) */}
                {(formLandingTemplate === 'template_2' || formLandingTemplate === 'template_3') && (
                  <div className="mt-3 p-4 rounded-xl bg-white border-2 border-rose-200 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-rose-100">
                      <div>
                        <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                          <ShoppingBag className="w-4 h-4 text-[#dc2626]" />
                          <span>
                            ওয়েবসাইটের প্রোডাক্ট লিস্ট থেকে মাল্টিপল প্রোডাক্ট সিলেক্ট করুন (Selected:{' '}
                            <strong className="text-[#dc2626]">{formShowcaseItems.length}টি ড্রেস</strong>)
                          </span>
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          সিলেক্ট করা প্রতিটি প্রোডাক্টের ছবি, নাম, বিবরণ, রেগুলার প্রাইস, সেল প্রাইস এবং সাইজ/ভ্যারিয়েশন ওয়েবসাইট থেকে স্বয়ংক্রিয়ভাবে চলে আসবে।
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          onClick={handleQuickSelectFiveWebsiteProducts}
                          className="px-3 py-1.5 rounded-lg bg-[#dc2626] hover:bg-[#b91c1c] text-white text-[11px] font-extrabold cursor-pointer transition-colors"
                        >
                          ⚡ ১-ক্লিকে ৫টি ড্রেস সিলেক্ট করুন
                        </button>
                        {formShowcaseItems.length > 0 && (
                          <button
                            type="button"
                            onClick={() => setFormShowcaseItems([])}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold cursor-pointer"
                          >
                            সব আনসিলেক্ট
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Section Heading Customization */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          মাল্টি-ডিজাইন শোকেস সেকশন শিরোনাম (Section Title):
                        </label>
                        <input
                          type="text"
                          value={formShowcaseTitle}
                          onChange={e => setFormShowcaseTitle(e.target.value)}
                          placeholder="আমাদের এক্সক্লুসিভ কালেকশন — পছন্দের ডিজাইনটি বেছে নিন"
                          className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          শোকেস সাব-টাইটেল (Section Subtitle):
                        </label>
                        <input
                          type="text"
                          value={formShowcaseSubtitle}
                          onChange={e => setFormShowcaseSubtitle(e.target.value)}
                          placeholder="প্রতিটি ড্রেস ১০০% প্রিমিয়াম ফেব্রিক ও নিখুঁত ফিনিশিংয়ের নিশ্চয়তা"
                          className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-800"
                        />
                      </div>
                    </div>

                    {/* Mobile 2-Column vs 1-Column Product Layout Toggle for Template 2 */}
                    <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200/90 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="block text-[11px] font-extrabold text-slate-900">
                          📱 মোবাইলে প্রোডাক্ট কার্ড লেআউট (১ লাইনে ২টি প্রোডাক্ট vs ১টি প্রোডাক্ট):
                        </span>
                        <span className="block text-[10px] text-slate-600">
                          ON করলে মোবাইলে পাশাপাশি ১ লাইনে ২টি করে প্রোডাক্ট (২ লাইনে ৪টি) দেখাবে, আর OFF করলে ১ লাইনে ১টি করে বড় প্রোডাক্ট কার্ড দেখাবে
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setFormShowcaseMobileTwoCols(prev => !prev)}
                        className={`px-3.5 py-1.5 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                          formShowcaseMobileTwoCols
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        মোবাইলে ২টি করে প্রোডাক্ট: {formShowcaseMobileTwoCols ? 'ON (১ লাইনে ২টি)' : 'OFF (১ লাইনে ১টি)'}
                      </button>
                    </div>

                    {/* "সাইজ পছন্দ করুন →" Button ON/OFF & Custom Text inside Template 2 Builder */}
                    <div className="p-3 rounded-xl bg-rose-50/50 border border-rose-200/80 space-y-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <span className="block text-[11px] font-extrabold text-slate-900">
                            প্রোডাক্ট ছবির নিচে &ldquo;{formShowcaseSelectBtnText || 'সাইজ পছন্দ করুন'} &rarr;&rdquo; বাটন (ON / OFF ও টেক্সট এডিট):
                          </span>
                          <span className="block text-[10px] text-slate-500">
                            প্রতিটি প্রোডাক্ট কার্ডের ছবির বাম নিচে যে বাটনটি দেখা যায় সেটি চালু/বন্ধ বা লেখা পরিবর্তন করুন
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setFormShowcaseSelectBtnEnabled(prev => !prev)}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                            formShowcaseSelectBtnEnabled
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-slate-200 text-slate-700 border-slate-300'
                          }`}
                        >
                          বাটন: {formShowcaseSelectBtnEnabled ? 'ON (চালু আছে)' : 'OFF (বন্ধ আছে)'}
                        </button>
                      </div>

                      {formShowcaseSelectBtnEnabled && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center pt-1">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-700 mb-1">
                              বাটনের লেখা (Button Text):
                            </label>
                            <input
                              type="text"
                              value={formShowcaseSelectBtnText}
                              onChange={e => setFormShowcaseSelectBtnText(e.target.value)}
                              placeholder="সাইজ পছন্দ করুন"
                              className="w-full min-h-[34px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900"
                            />
                          </div>
                          <div>
                            <span className="block text-[10px] font-bold text-slate-600 mb-1">
                              ১-ক্লিক প্রিসেট:
                            </span>
                            <div className="flex flex-wrap gap-1">
                              {[
                                'সাইজ পছন্দ করুন',
                                'পছন্দের সাইজ নিন',
                                'অর্ডার করতে ক্লিক করুন',
                                'ডিজাইন সিলেক্ট করুন'
                              ].map(preset => (
                                <button
                                  key={preset}
                                  type="button"
                                  onClick={() => setFormShowcaseSelectBtnText(preset)}
                                  className={`px-2 py-1 rounded-md text-[10px] font-bold border cursor-pointer transition-colors ${
                                    formShowcaseSelectBtnText === preset
                                      ? 'bg-[#dc2626] text-white border-[#dc2626]'
                                      : 'bg-white text-slate-700 border-slate-300 hover:border-rose-300'
                                  }`}
                                >
                                  {preset}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Search & Select Existing Website Products */}
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <label className="font-bold text-slate-800 text-[11px]">
                          ১. আমাদের ওয়েবসাইটের প্রোডাক্ট লিস্ট ({websiteProducts.length}টি প্রোডাক্ট) — টিক দিয়ে সিলেক্ট করুন:
                        </label>
                        <div className="relative w-full sm:w-64">
                          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="text"
                            value={showcaseProductSearch}
                            onChange={e => setShowcaseProductSearch(e.target.value)}
                            placeholder="প্রোডাক্টের নাম বা SKU খুঁজুন..."
                            className="w-full pl-8 pr-2.5 py-1 rounded-lg border border-slate-300 text-[11px] text-slate-900"
                          />
                        </div>
                      </div>

                      <div className="max-h-48 overflow-y-auto rounded-xl border border-slate-200 divide-y divide-slate-100 bg-slate-50/60">
                        {filteredWebsiteProducts.map(siteProd => {
                          const isSelected = formShowcaseItems.some(
                            it => it.productId === siteProd.id
                          );
                          const regPrice =
                            siteProd.regularPrice && siteProd.regularPrice > siteProd.retailPrice
                              ? siteProd.regularPrice
                              : Math.round(siteProd.retailPrice * 1.3);
                          return (
                            <label
                              key={siteProd.id}
                              className={`flex items-center justify-between gap-3 p-2.5 cursor-pointer transition-colors ${
                                isSelected ? 'bg-rose-50/90' : 'hover:bg-white'
                              }`}
                            >
                              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() => handleToggleShowcaseProduct(siteProd)}
                                  className="w-4 h-4 accent-[#dc2626] rounded cursor-pointer shrink-0"
                                />
                                <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 overflow-hidden shrink-0">
                                  <ProductThumbnail product={siteProd} imgClassName="p-0.5" />
                                </div>
                                <div className="min-w-0 flex-1">
                                  <p className="text-xs font-extrabold text-slate-900 truncate">
                                    {siteProd.nameBn}
                                  </p>
                                  <p className="text-[10px] text-slate-500 font-medium truncate">
                                    SKU: {siteProd.sku} • সাইজ/ভ্যারিয়েশন:{' '}
                                    {siteProd.variants && siteProd.variants.length > 0
                                      ? siteProd.variants.map(v => v.label).join(', ')
                                      : siteProd.unit}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right shrink-0 font-mono">
                                <span className="text-[10px] text-slate-400 line-through mr-1">
                                  ৳{regPrice}
                                </span>
                                <span className="text-xs font-extrabold text-[#dc2626]">
                                  ৳{siteProd.retailPrice}
                                </span>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Optional Per-Product Custom Highlight Badge, Fabric Subtitle & Color Tag */}
                    {formShowcaseItems.length > 0 && (
                      <div className="space-y-2.5 pt-2 border-t border-slate-200">
                        <label className="block font-extrabold text-slate-900 text-xs">
                          ২. সিলেক্ট করা প্রতিটি প্রোডাক্টের অপশনাল হাইলাইট ব্যাজ, ফেব্রিক সাবটাইটেল ও কালার ট্যাগ কাস্টমাইজ করুন:
                        </label>
                        <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                          {formShowcaseItems.map((item, idx) => {
                            const matchedProd = products.find(p => p.id === item.productId);
                            if (!matchedProd) return null;
                            const regPrice =
                              matchedProd.regularPrice &&
                              matchedProd.regularPrice > matchedProd.retailPrice
                                ? matchedProd.regularPrice
                                : Math.round(matchedProd.retailPrice * 1.3);
                            return (
                              <div
                                key={item.productId}
                                className="p-3 rounded-xl bg-rose-50/35 border border-rose-200/80 space-y-2.5"
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-2.5 min-w-0">
                                    <span className="w-5 h-5 rounded-full bg-[#dc2626] text-white font-mono text-[10px] font-extrabold flex items-center justify-center shrink-0">
                                      {idx + 1}
                                    </span>
                                    <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 overflow-hidden shrink-0">
                                      <ProductThumbnail product={matchedProd} imgClassName="p-0.5" />
                                    </div>
                                    <div className="min-w-0">
                                      <p className="text-xs font-extrabold text-slate-900 truncate">
                                        {matchedProd.nameBn}
                                      </p>
                                      <p className="text-[10px] text-slate-500 font-mono">
                                        রেগুলার: ৳{regPrice} | অফার প্রাইস: ৳{matchedProd.retailPrice} | সাইজ:{' '}
                                        {matchedProd.variants?.length || 1}টি
                                      </p>
                                    </div>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => handleToggleShowcaseProduct(matchedProd)}
                                    className="p-1 rounded-lg text-rose-600 hover:bg-rose-100 cursor-pointer shrink-0"
                                    title="এই প্রোডাক্টটি সরান"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                                      হাইলাইট ব্যাজ (Highlight Badge):
                                    </label>
                                    <input
                                      type="text"
                                      value={item.badgeText ?? ''}
                                      onChange={e =>
                                        handleUpdateShowcaseItemField(
                                          item.productId,
                                          'badgeText',
                                          e.target.value
                                        )
                                      }
                                      placeholder="যেমন: টপ সেলিং 🔥"
                                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-[11px] font-bold text-slate-900"
                                    />
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {SHOWCASE_BADGE_PRESETS.map(preset => (
                                        <button
                                          key={preset}
                                          type="button"
                                          onClick={() =>
                                            handleUpdateShowcaseItemField(
                                              item.productId,
                                              'badgeText',
                                              preset
                                            )
                                          }
                                          className="px-1.5 py-0.5 rounded bg-white hover:bg-rose-50 border border-slate-200 text-[9px] font-bold text-slate-700 cursor-pointer"
                                        >
                                          {preset}
                                        </button>
                                      ))}
                                    </div>
                                  </div>

                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                                      ফেব্রিক / সাবটাইটেল (Fabric/Subtitle):
                                    </label>
                                    <input
                                      type="text"
                                      value={item.fabricSubtitle ?? ''}
                                      onChange={e =>
                                        handleUpdateShowcaseItemField(
                                          item.productId,
                                          'fabricSubtitle',
                                          e.target.value
                                        )
                                      }
                                      placeholder="যেমন: প্রিমিয়াম চায়না মাইক্রো ভেলভেট"
                                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-[11px] font-semibold text-slate-900"
                                    />
                                  </div>

                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                                      কালার ট্যাগ (Color Tag):
                                    </label>
                                    <input
                                      type="text"
                                      value={item.colorTag ?? ''}
                                      onChange={e =>
                                        handleUpdateShowcaseItemField(
                                          item.productId,
                                          'colorTag',
                                          e.target.value
                                        )
                                      }
                                      placeholder="যেমন: রয়্যাল মেরুন"
                                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-[11px] font-semibold text-slate-900"
                                    />
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* 1. Product Name & Dedicated URL Slug */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Product Name (Bangla / Main Title) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formNameBn}
                    onChange={e => setFormNameBn(e.target.value)}
                    placeholder="যেমন: প্রিমিয়াম রোস্টেড মাখানা (Fox Nuts)"
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-slate-300 focus:border-emerald-600 outline-hidden text-slate-900 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Product Name (English / Subtitle)
                  </label>
                  <input
                    type="text"
                    value={formNameEn}
                    onChange={e => {
                      setFormNameEn(e.target.value);
                      if (!editingProduct && !formLandingSlug) {
                        setFormLandingSlug(slugifyLandingText(e.target.value));
                      }
                    }}
                    placeholder="e.g. Premium Roasted Makhana"
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-slate-300 focus:border-emerald-600 outline-hidden text-slate-900"
                  />
                </div>
              </div>

              {/* NEW: Top Animated Heading Before Product Image (ON/OFF + Animation ON/OFF + Presets) */}
              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>
                        প্রোডাক্ট ছবির শুরুতে অ্যানিমেশন হেডিং (Top Animated Heading Before Image)
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      ল্যান্ডিং পেজের একদম শুরুতে প্রোডাক্ট ছবির আগে আকর্ষণীয় হেডিং এবং অ্যানিমেশন ON/OFF করুন।
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 font-bold text-slate-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formTopHeadingEnabled}
                        onChange={e => setFormTopHeadingEnabled(e.target.checked)}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                      <span>হেডিং: {formTopHeadingEnabled ? 'ON (চালু)' : 'OFF (বন্ধ)'}</span>
                    </label>

                    {formTopHeadingEnabled && (
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 font-bold text-slate-800 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formTopHeadingAnimation}
                          onChange={e => setFormTopHeadingAnimation(e.target.checked)}
                          className="w-4 h-4 accent-rose-600 cursor-pointer"
                        />
                        <span>অ্যানিমেশন: {formTopHeadingAnimation ? 'ON' : 'OFF'}</span>
                      </label>
                    )}
                  </div>
                </div>

                {formTopHeadingEnabled && (
                  <div className="space-y-3 pt-2 border-t border-emerald-200/70">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Main Heading Input */}
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <label className="font-bold text-slate-700">
                            মূল হেডিং টেক্সট (ফাঁকা রাখলে প্রোডাক্টের নাম দিয়ে অটো তৈরি হবে):
                          </label>
                        </div>
                        <input
                          type="text"
                          value={formTopHeadingText}
                          onChange={e => setFormTopHeadingText(e.target.value)}
                          placeholder={`${
                            formNameBn.trim() || 'প্রিমিয়াম প্রোডাক্ট'
                          } — আজকের স্পেশাল অফারে অর্ডার করুন!`}
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-slate-900 font-bold"
                        />
                        <div className="flex flex-wrap items-center gap-1 mt-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              setFormTopHeadingText(
                                `${
                                  formNameBn.trim() || '১০০% অরিজিনাল প্রোডাক্ট'
                                } — আজকের স্পেশাল অফারে অর্ডার করুন!`
                              )
                            }
                            className="px-2 py-0.5 rounded bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer"
                          >
                            প্রোডাক্টের নাম + স্পেশাল অফার
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setFormTopHeadingText(
                                'স্পেশাল মেগা অফার! স্টক শেষ হওয়ার আগেই অর্ডার কনফার্ম করুন'
                              )
                            }
                            className="px-2 py-0.5 rounded bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer"
                          >
                            স্টক শেষ হওয়ার আগেই অর্ডার করুন
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormTopHeadingText('')}
                            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-semibold cursor-pointer"
                          >
                            অটো ডিফল্ট
                          </button>
                        </div>
                      </div>

                      {/* Subtext / Offer Pill Input */}
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <label className="font-bold text-slate-700">
                            উপরের ছোট অফার ব্যাজ (ফাঁকা রাখলে হাইড থাকবে):
                          </label>
                        </div>
                        <input
                          type="text"
                          value={formTopHeadingSubtext}
                          onChange={e => setFormTopHeadingSubtext(e.target.value)}
                          placeholder="যেমন: সীমিত সময়ের মেগা অফার • বিশেষ ছাড় চলছে!"
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-slate-900 font-medium"
                        />
                        <div className="flex flex-wrap items-center gap-1 mt-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              setFormTopHeadingSubtext('সীমিত সময়ের মেগা অফার • বিশেষ ছাড় চলছে!')
                            }
                            className="px-2 py-0.5 rounded bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer"
                          >
                            সীমিত সময়ের মেগা অফার
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setFormTopHeadingSubtext('১০০% অরিজিনাল ও ক্যাশ অন ডেলিভারি গ্যারান্টি')
                            }
                            className="px-2 py-0.5 rounded bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer"
                          >
                            ক্যাশ অন ডেলিভারি গ্যারান্টি
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormTopHeadingSubtext('')}
                            className="px-2 py-0.5 rounded bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-semibold cursor-pointer"
                          >
                            ছোট ব্যাজ হাইড করুন
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Color Theme & Animation Style Selectors */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          হেডিং কালার ডিজাইন (Color Theme):
                        </label>
                        <div className="grid grid-cols-2 gap-1.5">
                          {(
                            [
                              { id: 'emerald', label: 'সিম্পল গ্রিন (Clean Green)' },
                              { id: 'crimson', label: 'সিম্পল রেড (Clean Red)' },
                              { id: 'midnight', label: 'সিম্পল ডার্ক (Clean Slate)' },
                              { id: 'light', label: 'মিনিমাল হোয়াইট (Pure White)' }
                            ] as const
                          ).map(th => (
                            <button
                              key={th.id}
                              type="button"
                              onClick={() => setFormTopHeadingTheme(th.id)}
                              className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-bold cursor-pointer transition-all ${
                                formTopHeadingTheme === th.id
                                  ? 'bg-emerald-600 text-white border-emerald-600'
                                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              {th.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          অ্যানিমেশন স্টাইল (Animation Effect):
                        </label>
                        <div className="grid grid-cols-3 gap-1.5">
                          {(
                            [
                              { id: 'shimmer', label: 'শিমার পালস' },
                              { id: 'bounce', label: 'ফ্লোটিং ওয়েভ' },
                              { id: 'glow', label: 'গ্লোয়িং জুম' }
                            ] as const
                          ).map(st => (
                            <button
                              key={st.id}
                              type="button"
                              onClick={() => {
                                setFormTopHeadingAnimation(true);
                                setFormTopHeadingAnimStyle(st.id);
                              }}
                              className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-bold cursor-pointer transition-all ${
                                formTopHeadingAnimation && formTopHeadingAnimStyle === st.id
                                  ? 'bg-amber-600 text-white border-amber-600'
                                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              {st.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* NEW: Elementor-Style Top Animated Regular & Offer Price Banner (পূর্বের মূল্য X / আজকের অফার মূল্য — মাত্র ৯৯০ টাকা) */}
              <div className="p-4 rounded-xl bg-amber-50/40 border border-amber-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Flame className="w-4 h-4 text-rose-600" />
                      <span>
                        শুরুতে রেগুলার ও অফার প্রাইস অ্যানিমেশন ব্যানার (Elementor Style Price Cross-Out — ON/OFF)
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      “পূর্বের মূল্য — 1800 টাকা” (লাল X ক্রস অ্যানিমেশন) এবং “আজকের অফার মূল্য — মাত্র 990 টাকা” (ইংলিশ প্রাইস ও প্রাইসের চারপাশে সবুজ সার্কেল অ্যানিমেশন) চালু/বন্ধ ও টেক্সট এডিট করুন।
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 font-bold text-slate-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formTopPriceBannerEnabled}
                        onChange={e => setFormTopPriceBannerEnabled(e.target.checked)}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                      <span>প্রাইস ব্যানার: {formTopPriceBannerEnabled ? 'ON (চালু)' : 'OFF (বন্ধ)'}</span>
                    </label>

                    {formTopPriceBannerEnabled && (
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 font-bold text-slate-800 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formTopPriceAnimationEnabled}
                          onChange={e => setFormTopPriceAnimationEnabled(e.target.checked)}
                          className="w-4 h-4 accent-rose-600 cursor-pointer"
                        />
                        <span>অ্যানিমেশন: {formTopPriceAnimationEnabled ? 'ON' : 'OFF'}</span>
                      </label>
                    )}
                  </div>
                </div>

                {formTopPriceBannerEnabled && (
                  <div className="pt-2 border-t border-amber-200/70 space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          রেগুলার প্রাইস টেক্সট (যেমন: পূর্বের মূল্য —):
                        </label>
                        <input
                          type="text"
                          value={formTopRegularPriceLabel}
                          onChange={e => setFormTopRegularPriceLabel(e.target.value)}
                          placeholder="পূর্বের মূল্য —"
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-900 outline-hidden"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          অফার প্রাইস টেক্সট (যেমন: আজকের অফার মূল্য —):
                        </label>
                        <input
                          type="text"
                          value={formTopOfferPriceLabel}
                          onChange={e => setFormTopOfferPriceLabel(e.target.value)}
                          placeholder="আজকের অফার মূল্য —"
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-900 outline-hidden"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          টাকার আগের শব্দ (যেমন: মাত্র):
                        </label>
                        <input
                          type="text"
                          value={formTopOfferPricePrefix}
                          onChange={e => setFormTopOfferPricePrefix(e.target.value)}
                          placeholder="মাত্র"
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-bold text-slate-900 outline-hidden"
                        />
                      </div>
                    </div>

                    {/* Color Theme & Price Highlight Animation Style Selectors (Just like Top Hero Text Banner) */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-1">
                      <div className="sm:col-span-7">
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          প্রাইস ব্যানার কালার ডিজাইন (Color Theme):
                        </label>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                          {(
                            [
                              { id: 'emerald', label: 'সিম্পল গ্রিন (Clean Green)' },
                              { id: 'crimson', label: 'প্রিমিয়াম রেড (Crimson Red)' },
                              { id: 'midnight', label: 'রয়েল ডার্ক গোল্ড (Dark Gold)' },
                              { id: 'amber', label: 'গোল্ডেন অফার (Warm Gold)' },
                              { id: 'light', label: 'মিনিমাল হোয়াইট (Pure White)' }
                            ] as const
                          ).map(th => (
                            <button
                              key={th.id}
                              type="button"
                              onClick={() => setFormTopPriceBannerTheme(th.id)}
                              className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-bold cursor-pointer transition-all ${
                                formTopPriceBannerTheme === th.id
                                  ? 'bg-emerald-600 text-white border-emerald-600'
                                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              {th.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="sm:col-span-5">
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          প্রাইস হাইলাইট অ্যানিমেশন স্টাইল (Price Animation):
                        </label>
                        <div className="grid grid-cols-3 gap-1.5">
                          {(
                            [
                              { id: 'circle', label: 'সার্কেল মার্ক' },
                              { id: 'underline', label: 'ডাবল আন্ডারলাইন' },
                              { id: 'burst', label: 'হাইলাইট বক্স' }
                            ] as const
                          ).map(st => (
                            <button
                              key={st.id}
                              type="button"
                              onClick={() => {
                                setFormTopPriceAnimationEnabled(true);
                                setFormTopPriceHighlightStyle(st.id);
                              }}
                              className={`px-2 py-1.5 rounded-lg border text-[11px] font-bold cursor-pointer transition-all ${
                                formTopPriceAnimationEnabled && formTopPriceHighlightStyle === st.id
                                  ? 'bg-amber-600 text-white border-amber-600'
                                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              {st.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Top Price Animation Speed Selector (Slow / Normal / Fast / Ultra Fast) */}
                    {formTopPriceAnimationEnabled && (
                      <div className="pt-2 border-t border-amber-200/60">
                        <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                          টপ প্রাইস অ্যানিমেশন স্পিড (Animation Speed — স্লো / ফাস্ট):
                        </label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {(
                            [
                              { id: 'slow', label: 'স্লো (Slow — ৬.৫ সে.)' },
                              { id: 'normal', label: 'নরমাল (Normal — ৪.৪ সে.)' },
                              { id: 'fast', label: 'ফাস্ট (Fast — ২.৪ সে.)' },
                              { id: 'ultra_fast', label: 'সুপার ফাস্ট (১.৫ সে.)' }
                            ] as const
                          ).map(sp => (
                            <button
                              key={sp.id}
                              type="button"
                              onClick={() => {
                                setFormTopPriceAnimationEnabled(true);
                                setFormTopPriceAnimationSpeed(sp.id);
                              }}
                              className={`px-2.5 py-2 rounded-lg border text-[11px] font-extrabold cursor-pointer transition-all ${
                                formTopPriceAnimationSpeed === sp.id
                                  ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                  : 'bg-white hover:bg-rose-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              {sp.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* BANNER 1: Top Promotional Banner / Image Upload Section at Start of Landing Page (ON/OFF System) */}
              <div className="p-4 rounded-xl bg-teal-50/50 border border-teal-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4 text-teal-600" />
                      <span>
                        ব্যানার ১ — ল্যান্ডিং পেজের শুরুতে ইমেজ আপলোড সেকশন (Banner 1 — ON/OFF)
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      ল্যান্ডিং পেজের একদম শুরুতে যেকোনো কাস্টম অফার ব্যানার বা প্রমোশনাল ছবি আপলোড করুন এবং ১-ক্লিকে ON বা OFF রাখুন।
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setFormPromoBannerEnabled(prev => !prev)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      formPromoBannerEnabled
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {formPromoBannerEnabled ? 'ব্যানার ১ চালু আছে (ON)' : 'ব্যানার ১ বন্ধ আছে (OFF)'}
                  </button>
                </div>

                <div className="pt-2 border-t border-teal-200/70 space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      ref={promoBannerInputRef}
                      type="file"
                      accept="image/*"
                      onChange={async e => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        setIsUploadingImage(true);
                        try {
                          const dataUrl = await processUploadedProductImage(file, 1200);
                          setFormPromoBannerImage(dataUrl);
                          setFormPromoBannerEnabled(true);
                          showToast('ব্যানার ১ ছবি যুক্ত ও চালু (ON) হয়েছে!', 'success');
                        } catch {
                          showToast('ব্যানার ১ ছবি প্রসেস করা যায়নি', 'error');
                        } finally {
                          setIsUploadingImage(false);
                          e.target.value = '';
                        }
                      }}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={isUploadingImage}
                      onClick={() => promoBannerInputRef.current?.click()}
                      className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>ব্যানার ১ ইমেজ আপলোড করুন</span>
                    </button>

                    <input
                      type="text"
                      value={formPromoBannerImage}
                      onChange={e => {
                        const val = e.target.value;
                        setFormPromoBannerImage(val);
                        if (val.trim()) setFormPromoBannerEnabled(true);
                      }}
                      placeholder="অথবা সরাসরি ব্যানার ১ ছবির লিংক দিন (https://...)"
                      className="flex-1 min-w-[210px] min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-900 outline-hidden"
                    />

                    {formPromoBannerImage && (
                      <button
                        type="button"
                        onClick={() => {
                          setFormPromoBannerImage('');
                          setFormPromoBannerEnabled(false);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs cursor-pointer"
                      >
                        ব্যানার ১ মুছুন
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      ব্যানার ১-এর উপরের টেক্সট / ক্যাপশন (ঐচ্ছিক):
                    </label>
                    <input
                      type="text"
                      value={formPromoBannerTitle}
                      onChange={e => setFormPromoBannerTitle(e.target.value)}
                      placeholder="যেমন: ধামাকা ঈদ অফার চলছে! (ফাঁকা রাখলে শুধু ব্যানার ১ ছবি দেখাবে)"
                      className="w-full min-h-[36px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold outline-hidden"
                    />
                  </div>

                  {formPromoBannerImage && (
                    <div className="p-2.5 rounded-xl bg-white border border-teal-200 space-y-1.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-teal-900">
                          ব্যানার ১ প্রিভিউ ({formPromoBannerEnabled ? 'ON - চালু' : 'OFF - বন্ধ'}):
                        </span>
                      </div>
                      <img
                        src={formPromoBannerImage}
                        alt="Banner 1 Preview"
                        className="w-full max-h-40 object-contain rounded-lg bg-slate-50"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* NEW: Animated Evergreen Offer Countdown Timer Settings (Default 9 Hours, Auto-Restart at 0) */}
              <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-rose-600" />
                      <span>
                        অফার কাউন্টডাউন টাইমার (Animated Evergreen Countdown — ০ হলে অটো নতুন করে শুরু হবে)
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      যেমন ৯ ঘণ্টা সেট করলে ৯ ঘণ্টা থেকে কমতে থাকবে এবং ০ হয়ে গেলে অটোমেটিক আবার নতুন করে ৯ ঘণ্টা থেকে শুরু হবে।
                    </p>
                  </div>

                  <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 font-bold text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formCountdownEnabled}
                      onChange={e => setFormCountdownEnabled(e.target.checked)}
                      className="w-4 h-4 accent-rose-600 cursor-pointer"
                    />
                    <span>কাউন্টডাউন: {formCountdownEnabled ? 'ON (চালু)' : 'OFF (বন্ধ)'}</span>
                  </label>
                </div>

                {formCountdownEnabled && (
                  <div className="space-y-3 pt-2 border-t border-rose-200/70">
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                      {/* Countdown Hours Input + Quick Presets */}
                      <div className="sm:col-span-5">
                        <label className="block font-bold text-slate-700 mb-1">
                          কাউন্টডাউন সময় (ঘণ্টা / Hours):
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min={1}
                            max={720}
                            value={formCountdownHours}
                            onChange={e =>
                              setFormCountdownHours(Math.max(1, parseInt(e.target.value, 10) || 9))
                            }
                            className="w-24 min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white focus:border-rose-600 outline-hidden text-slate-900 font-mono font-bold"
                          />
                          <div className="flex flex-wrap items-center gap-1">
                            {[3, 6, 9, 12, 24].map(hr => (
                              <button
                                key={hr}
                                type="button"
                                onClick={() => setFormCountdownHours(hr)}
                                className={`px-2 py-1 rounded-lg border text-[10px] font-bold cursor-pointer transition-all ${
                                  formCountdownHours === hr
                                    ? 'bg-rose-600 text-white border-rose-600'
                                    : 'bg-white hover:bg-rose-50 text-slate-700 border-slate-200'
                                }`}
                              >
                                {hr} ঘণ্টা
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Countdown Title Text */}
                      <div className="sm:col-span-4">
                        <label className="block font-bold text-slate-700 mb-1">
                          কাউন্টডাউন হেডিং টেক্সট:
                        </label>
                        <input
                          type="text"
                          value={formCountdownTitle}
                          onChange={e => setFormCountdownTitle(e.target.value)}
                          placeholder="স্পেশাল অফার শেষ হতে বাকি:"
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white focus:border-rose-600 outline-hidden text-slate-900 font-bold"
                        />
                      </div>

                      {/* Countdown Position Selector */}
                      <div className="sm:col-span-3">
                        <label className="block font-bold text-slate-700 mb-1">
                          কোথায় দেখাবে (Position):
                        </label>
                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            type="button"
                            onClick={() => setFormCountdownPosition('hero_info')}
                            className={`px-2 py-1.5 rounded-lg border text-[10px] font-bold cursor-pointer ${
                              formCountdownPosition === 'hero_info'
                                ? 'bg-rose-600 text-white border-rose-600'
                                : 'bg-white text-slate-700 border-slate-200'
                            }`}
                          >
                            হিরো টেক্সটে
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormCountdownPosition('top_heading')}
                            className={`px-2 py-1.5 rounded-lg border text-[10px] font-bold cursor-pointer ${
                              formCountdownPosition === 'top_heading'
                                ? 'bg-rose-600 text-white border-rose-600'
                                : 'bg-white text-slate-700 border-slate-200'
                            }`}
                          >
                            টপ হেডিংয়ে
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Scarcity Stock & High-Demand Marketing Urgency Banner (ON/OFF + Stock Left Count) */}
              <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <label className="block font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                      <Flame className="w-4 h-4 text-rose-600" />
                      <span>
                        সীমিত স্টক ও প্রচুর চাহিদা অ্যালার্ট (অফার মূল্যে আর মাত্র {formScarcityCount} টি বাকি আছে!)
                      </span>
                    </label>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      হিরো সেকশনে পরিমাণ (Quantity)-এর পাশে ও নিচে অ্যানিমেটেড &ldquo;প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে • সীমিত স্টক&rdquo; বার দেখাবে
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormScarcityEnabled(v => !v)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-extrabold transition-colors cursor-pointer ${
                      formScarcityEnabled
                        ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                        : 'bg-white text-slate-500 border-slate-300'
                    }`}
                  >
                    {formScarcityEnabled ? 'চালু আছে (ON)' : 'বন্ধ আছে (OFF)'}
                  </button>
                </div>

                {formScarcityEnabled && (
                  <div className="pt-2 border-t border-rose-200/70 flex flex-wrap items-center justify-between gap-3">
                    <div className="space-y-1">
                      <span className="text-[11px] font-bold text-slate-700 block">
                        অফার মূল্যে আর কয়টি বাকি আছে দেখাতে চান?
                      </span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {[5, 7, 10, 12, 15, 20].map(cnt => (
                          <button
                            key={cnt}
                            type="button"
                            onClick={() => setFormScarcityCount(cnt)}
                            className={`px-2.5 py-1 rounded-lg border text-xs font-extrabold transition-all cursor-pointer ${
                              formScarcityCount === cnt
                                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                : 'bg-white text-slate-700 border-slate-200 hover:border-rose-300'
                            }`}
                          >
                            {cnt} টি বাকি
                          </button>
                        ))}
                        <input
                          type="number"
                          min={1}
                          max={999}
                          value={formScarcityCount}
                          onChange={e => setFormScarcityCount(Math.max(1, Number(e.target.value) || 10))}
                          className="w-20 px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-none focus:border-rose-500"
                          title="কাস্টম সংখ্যা লিখুন"
                        />
                      </div>
                    </div>

                    {/* Mini Live Preview inside Modal */}
                    <div className="bg-white/90 border border-rose-200 rounded-xl p-2.5 min-w-[230px] flex-1 max-w-sm space-y-1.5 shadow-2xs">
                      <div className="inline-flex items-center gap-1 text-[11px] font-extrabold text-[#c30000] bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200">
                        <span>🔥 অফার মূল্যে আর মাত্র {formScarcityCount} টি বাকি আছে!</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] font-bold">
                        <span className="text-rose-700">🔥 প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে</span>
                        <span className="text-[#c30000] font-extrabold">সীমিত স্টক</span>
                      </div>
                      <div className="w-full h-1.5 bg-rose-100 rounded-full overflow-hidden">
                        <div className="w-[82%] h-full bg-gradient-to-r from-[#c30000] via-orange-500 to-amber-500 rounded-full" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Top Trust Badge Text (Editable per product) */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="block font-bold text-slate-800 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Top Highlight Badge Text (প্রোডাক্ট নামের উপরের ব্যাজ টেক্সট)</span>
                  </label>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setFormBadgeText('১০০% প্রিমিয়াম ও অরিজিনাল প্রোডাক্ট')}
                      className="px-2 py-0.5 rounded-md bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer"
                    >
                      ১০০% প্রিমিয়াম ও অরিজিনাল
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormBadgeText('১০০% এক্সপোর্ট কোয়ালিটি ও আরামদায়ক ফেব্রিক')}
                      className="px-2 py-0.5 rounded-md bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer"
                    >
                      এক্সপোর্ট কোয়ালিটি ড্রেস
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormBadgeText('')}
                      className="px-2 py-0.5 rounded-md bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-semibold cursor-pointer"
                    >
                      Hide Badge (ফাঁকা রাখুন)
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  value={formBadgeText}
                  onChange={e => setFormBadgeText(e.target.value)}
                  placeholder="যেমন: ১০০% প্রিমিয়াম ও অরিজিনাল প্রোডাক্ট (ফাঁকা রাখলে দেখাবে না)"
                  className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-slate-900 font-medium"
                />
              </div>

              {/* Dedicated URL Slug, Parent SKU & WordPress Product ID */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200/80">
                <div className="sm:col-span-5">
                  <label className="block font-bold text-emerald-950 mb-1">
                    Landing Page Custom URL Slug
                  </label>
                  <div className="flex items-center rounded-xl border border-emerald-300 bg-white overflow-hidden">
                    <span className="px-2.5 py-2 bg-emerald-100/70 text-emerald-800 font-mono text-[11px] font-bold border-r border-emerald-200">
                      /landing/
                    </span>
                    <input
                      type="text"
                      value={formLandingSlug}
                      onChange={e => setFormLandingSlug(slugifyLandingText(e.target.value))}
                      placeholder="makhana"
                      className="w-full min-h-[38px] px-2.5 py-1.5 font-mono font-bold text-emerald-900 outline-hidden"
                    />
                  </div>
                </div>

                <div className="sm:col-span-4">
                  <label className="block font-bold text-emerald-950 mb-1">
                    Product Code / SKU (WP Match)
                  </label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={e => setFormSku(e.target.value)}
                    placeholder="LP-MAKHANA-01"
                    className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-emerald-300 bg-white font-mono font-bold text-slate-900 outline-hidden"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block font-bold text-sky-900 mb-1">
                    WordPress Product ID
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formWpProductId}
                    onChange={e => setFormWpProductId(e.target.value)}
                    placeholder="Auto / e.g. 124"
                    className="w-full min-h-[38px] px-3 py-1.5 rounded-xl border border-sky-300 bg-white font-mono font-bold text-sky-950 outline-hidden"
                    title="WordPress WooCommerce Parent Product ID (ফাঁকা রাখলে SKU বা নাম দিয়ে অটো-ম্যাচ/তৈরি হবে)"
                  />
                </div>
              </div>

              {/* 2. Pricing & Stock */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Regular Price (৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={formRegularPrice}
                    onChange={e => setFormRegularPrice(Number(e.target.value))}
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-emerald-800 mb-1">
                    Offer / Sale Price (৳) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formDiscountPrice}
                    onChange={e => setFormDiscountPrice(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl border-2 border-emerald-500 bg-emerald-50/30 font-mono font-extrabold text-emerald-900 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Cost / Purchase (৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={formPurchasePrice}
                    onChange={e => setFormPurchasePrice(Number(e.target.value))}
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-slate-300 font-mono text-slate-900 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Available Stock</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      value={formInitialStock}
                      onChange={e => setFormInitialStock(Number(e.target.value))}
                      className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={() => setFormIsOutOfStock(!formIsOutOfStock)}
                      className={`shrink-0 min-h-[40px] px-3 py-2 rounded-xl border text-xs font-extrabold transition-all cursor-pointer ${
                        formIsOutOfStock
                          ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                      }`}
                      title="ম্যানুয়ালি ল্যান্ডিং পেজে স্টক আউট বা ইন-স্টক করুন"
                    >
                      {formIsOutOfStock ? '🚫 স্টক শেষ' : '✓ স্টকে আছে'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Free Delivery Toggle for this Landing Page */}
              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                <div className="flex items-center gap-2.5">
                  <Truck className="w-4 h-4 text-emerald-600" />
                  <div>
                    <span className="font-bold text-slate-800 block">
                      Free Delivery Offer on this Landing Page
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Enable if you want ৳0 delivery charge specifically for this product landing page
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={formFreeDelivery}
                  onChange={e => setFormFreeDelivery(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 cursor-pointer"
                />
              </label>

              {/* 3. Product Image & Gallery Upload */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="font-bold text-slate-800">
                    Product Photo & Gallery Images
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      ref={mainImageInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleMainImageUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={isUploadingImage}
                      onClick={() => mainImageInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Main Photo</span>
                    </button>

                    <input
                      ref={galleryImageInputRef}
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleGalleryImageUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={isUploadingImage}
                      onClick={() => galleryImageInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Gallery Photos</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={formImage}
                    onChange={e => setFormImage(e.target.value)}
                    placeholder="Or paste direct image URL (https://...)"
                    className="flex-1 min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-800 outline-hidden"
                  />
                </div>

                {/* Preview Uploaded Main & Gallery Photos */}
                {(formImage || formGalleryImages.length > 0) && (
                  <div className="flex flex-wrap items-center gap-2.5 pt-1">
                    {formImage && (
                      <div className="relative w-16 h-16 rounded-xl border-2 border-emerald-600 overflow-hidden bg-white">
                        <img src={formImage} alt="Main" className="w-full h-full object-cover" />
                        <span className="absolute bottom-0 inset-x-0 bg-emerald-600 text-white text-[9px] text-center font-bold">
                          Main
                        </span>
                      </div>
                    )}
                    {formGalleryImages.map((gUrl, idx) => (
                      <div
                        key={idx}
                        className="relative w-16 h-16 rounded-xl border border-slate-300 overflow-hidden bg-white group"
                      >
                        <img src={gUrl} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() =>
                            setFormGalleryImages(prev => prev.filter((_, i) => i !== idx))
                          }
                          className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[10px] cursor-pointer"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add Gallery URL Input */}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newGalleryUrl}
                    onChange={e => setNewGalleryUrl(e.target.value)}
                    placeholder="Add extra gallery image URL..."
                    className="flex-1 min-h-[36px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-800 outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (newGalleryUrl.trim()) {
                        setFormGalleryImages(prev => [...prev, newGalleryUrl.trim()]);
                        setNewGalleryUrl('');
                      }
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold cursor-pointer"
                  >
                    Add URL
                  </button>
                </div>

                {/* Product Image % Discount Badge (ON/OFF + 6 Designs) */}
                <div className="bg-white p-3.5 rounded-xl border border-rose-200 space-y-2.5 mt-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <label className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-rose-600" />
                        <span>প্রোডাক্ট ছবির উপরের "% ছাড়" ব্যাজ (ON/OFF ও ৬টি ডিজাইন):</span>
                      </label>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        প্রোডাক্ট ছবির বাম কোণায় যে "% ছাড়" ব্যাজ থাকে সেটি ON/OFF করুন অথবা পছন্দের ডিজাইন বেছে নিন।
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormImageBadgeEnabled(!formImageBadgeEnabled)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                        formImageBadgeEnabled
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                          : 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200'
                      }`}
                    >
                      ছবির % ছাড় ব্যাজ: {formImageBadgeEnabled ? 'ON ✓' : 'OFF (লুকানো)'}
                    </button>
                  </div>

                  {formImageBadgeEnabled && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                      {LANDING_IMAGE_BADGE_DESIGN_OPTIONS.map(opt => {
                        const isSel = formImageBadgeStyle === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setFormImageBadgeStyle(opt.id)}
                            className={`p-2.5 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                              isSel
                                ? 'bg-rose-50/90 border-rose-600 shadow-2xs'
                                : 'bg-slate-50/60 hover:bg-white border-slate-200 hover:border-rose-300'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1.5">
                              <span
                                className={`text-xs font-extrabold ${
                                  isSel ? 'text-rose-950' : 'text-slate-800'
                                }`}
                              >
                                {opt.label}
                              </span>
                              {isSel && (
                                <span className="px-1.5 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold shrink-0">
                                  অ্যাক্টিভ ✓
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 leading-snug">
                              {opt.desc}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* 4. Variations Builder (Weight Packs / Sizes / Custom) */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-emerald-600" />
                      <span>Product Variations / Packs (Optional)</span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Customers can select their preferred pack/size directly on the landing page.
                    </p>
                  </div>

                  {/* Quick 1-Click Presets */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleApplyPreset('makhana_packs')}
                      className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-bold cursor-pointer"
                    >
                      + 250g / 500g / 1kg Packs
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyPreset('cloth_sizes')}
                      className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold cursor-pointer"
                    >
                      + M / L / XL / XXL
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyPreset('baby_years')}
                      className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold cursor-pointer"
                    >
                      + Baby Years
                    </button>
                  </div>
                </div>

                {/* Editable Variation Section Heading */}
                <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between gap-1.5">
                    <label className="text-[11px] font-bold text-slate-700">
                      Variation Selector Heading (সাইজ / বয়স সিলেক্ট করার টাইটেল):
                    </label>
                    <div className="flex flex-wrap items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setFormVariantTitle('পছন্দের সাইজ / বয়স নির্বাচন করুন:')}
                        className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold cursor-pointer"
                      >
                        পছন্দের সাইজ / বয়স নির্বাচন করুন:
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormVariantTitle('পছন্দের সাইজ নির্বাচন করুন:')}
                        className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-semibold cursor-pointer"
                      >
                        পছন্দের সাইজ নির্বাচন করুন:
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormVariantTitle('পছন্দের প্যাক / ভ্যারিয়েশন সিলেক্ট করুন:')}
                        className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-semibold cursor-pointer"
                      >
                        পছন্দের প্যাক সিলেক্ট করুন:
                      </button>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={formVariantTitle}
                    onChange={e => setFormVariantTitle(e.target.value)}
                    placeholder="পছন্দের সাইজ / বয়স নির্বাচন করুন:"
                    className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 focus:border-emerald-600 outline-hidden text-slate-900 font-semibold"
                  />
                </div>

                {/* Mobile-Responsive Variation Switcher Design Selector (6 Styles + Price ON/OFF) */}
                <div className="bg-white p-3.5 rounded-xl border border-emerald-200 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <label className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        <span>ভ্যারিয়েশন সুইচার ডিজাইন (Mobile Responsive Variation Design):</span>
                      </label>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        মোবাইল ভিজিটরদের জন্য ৮টি প্রিমিয়াম ও টাচ-ফ্রেন্ডলি সাইজ/ভ্যারিয়েশন সিলেক্টর ডিজাইন।
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormVariantShowPrice(!formVariantShowPrice)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                        formVariantShowPrice
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                          : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      বাটনে প্রাইস দেখান: {formVariantShowPrice ? 'ON ✓' : 'OFF (Default)'}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {LANDING_VARIANT_DESIGN_OPTIONS.map(opt => {
                      const isSel = formVariantStyle === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setFormVariantStyle(opt.id)}
                          className={`p-2.5 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                            isSel
                              ? 'bg-emerald-50/90 border-emerald-600 shadow-2xs'
                              : 'bg-slate-50/60 hover:bg-white border-slate-200 hover:border-emerald-300'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1.5">
                            <span
                              className={`text-xs font-extrabold ${
                                isSel ? 'text-emerald-950' : 'text-slate-800'
                              }`}
                            >
                              {opt.label}
                            </span>
                            {isSel && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold shrink-0">
                                অ্যাক্টিভ ✓
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-500 leading-snug">
                            {opt.desc}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Add Custom Variation Row (with Variation SKU & WP Variation ID) */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end pt-1">
                  <div className="sm:col-span-3">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Variation / Size Name
                    </label>
                    <input
                      type="text"
                      value={newVarLabel}
                      onChange={e => {
                        const val = e.target.value;
                        setNewVarLabel(val);
                        if (val.trim()) {
                          setNewVarSku(buildVariantSkuCode(formSku || 'LP', val, formVariants.length));
                        } else {
                          setNewVarSku('');
                        }
                      }}
                      placeholder="e.g. Size XL / 500g"
                      className="w-full min-h-[38px] px-2.5 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-900 outline-hidden"
                    />
                  </div>
                  <div className="sm:col-span-3">
                    <label className="block text-[11px] font-semibold text-sky-800 mb-1">
                      Variation SKU (WP Match)
                    </label>
                    <input
                      type="text"
                      value={newVarSku}
                      onChange={e => setNewVarSku(e.target.value)}
                      placeholder={buildVariantSkuCode(formSku || 'LP', newVarLabel || 'XL', formVariants.length)}
                      className="w-full min-h-[38px] px-2.5 py-1.5 rounded-xl border border-sky-300 bg-sky-50/40 font-mono text-slate-900 outline-hidden"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-sky-800 mb-1">
                      WP Var ID (Opt)
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={newVarWpVariationId}
                      onChange={e => setNewVarWpVariationId(e.target.value)}
                      placeholder="Auto"
                      className="w-full min-h-[38px] px-2 py-1.5 rounded-xl border border-sky-200 bg-white font-mono text-slate-900 outline-hidden"
                    />
                  </div>
                  <div className="sm:col-span-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Reg (৳)
                    </label>
                    <input
                      type="number"
                      value={newVarRegularPrice}
                      onChange={e => setNewVarRegularPrice(e.target.value)}
                      placeholder="550"
                      className="w-full min-h-[38px] px-2 py-1.5 rounded-xl border border-slate-300 bg-white font-mono text-slate-900 outline-hidden"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-emerald-800 mb-1">
                      Offer (৳)
                    </label>
                    <input
                      type="number"
                      value={newVarRetailPrice}
                      onChange={e => setNewVarRetailPrice(e.target.value)}
                      placeholder="450"
                      className="w-full min-h-[38px] px-2 py-1.5 rounded-xl border border-emerald-400 bg-white font-mono font-bold text-emerald-900 outline-hidden"
                    />
                  </div>
                  <div className="sm:col-span-1">
                    <button
                      type="button"
                      onClick={handleAddVariant}
                      className="w-full min-h-[38px] px-2 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
                    >
                      + Add
                    </button>
                  </div>
                </div>

                {/* Existing Variations List with Editable Variation SKU & WP Variation ID */}
                {formVariants.length > 0 && (
                  <div className="space-y-1.5 pt-2">
                    <div className="flex flex-wrap items-center justify-between gap-2 px-2 py-1.5 rounded-lg bg-sky-50 border border-sky-200/80 text-[11px]">
                      <span className="font-bold text-sky-900">
                        WordPress Variation Mapping: প্রতিটি ভ্যারিয়েশনের আলাদা SKU ও WP Variation ID সাপোর্ট করবে
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setFormVariants(prev =>
                            prev.map((v, i) => ({
                              ...v,
                              sku: buildVariantSkuCode(formSku || 'LP', v.label, i)
                            }))
                          );
                          showToast('All variation SKUs auto-generated from Product SKU!', 'info');
                        }}
                        className="px-2.5 py-0.5 rounded bg-sky-600 hover:bg-sky-700 text-white font-bold text-[10px] cursor-pointer"
                      >
                        Auto-Generate Variation SKUs
                      </button>
                    </div>

                    {formVariants.map((v, idx) => (
                      <div
                        key={v.id}
                        className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center p-2.5 rounded-xl bg-white border border-slate-200"
                      >
                        <div className="sm:col-span-3">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <label className="block text-[9px] font-bold text-slate-400 uppercase">
                              Variation Name & Photo
                            </label>
                            <button
                              type="button"
                              onClick={() =>
                                setFormVariants(prev =>
                                  prev.map((item, i) =>
                                    i === idx
                                      ? {
                                          ...item,
                                          type: item.type === 'color' ? 'size' : 'color'
                                        }
                                      : item
                                  )
                                )
                              }
                              className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold border cursor-pointer transition-colors ${
                                v.type === 'color'
                                  ? 'bg-rose-50 text-rose-700 border-rose-300'
                                  : 'bg-emerald-50 text-emerald-700 border-emerald-300'
                              }`}
                              title="ক্লিক করে সাইজ (Size) বা কালার (Color) টাইপ পরিবর্তন করুন"
                            >
                              {v.type === 'color' ? '🎨 কালার' : '📏 সাইজ'}
                            </button>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <div className="relative shrink-0">
                              <label
                                title={
                                  v.imageUrl
                                    ? 'কালার/ভ্যারিয়েশনের ছবি পরিবর্তন করতে ক্লিক করুন'
                                    : 'এই কালার/ভ্যারিয়েশনের ড্রেসের ছবি আপলোড করুন (কাস্টমার কালার সিলেক্ট করলে এই ছবি দেখাবে)'
                                }
                                className={`w-7 h-7 rounded-lg border flex items-center justify-center overflow-hidden cursor-pointer transition-all ${
                                  v.imageUrl
                                    ? 'border-rose-500 bg-white shadow-2xs'
                                    : 'border-dashed border-slate-300 hover:border-rose-400 bg-slate-50 text-slate-500 hover:text-rose-600'
                                }`}
                              >
                                <input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={async e => {
                                    const file = e.target.files?.[0];
                                    if (!file) return;
                                    try {
                                      const compressed = await processUploadedProductImage(file, 1000, 0.9);
                                      setFormVariants(prev =>
                                        prev.map((item, i) =>
                                          i === idx ? { ...item, imageUrl: compressed } : item
                                        )
                                      );
                                      showToast(
                                        `"${v.label}"-এর ছবি যুক্ত হয়েছে! কাস্টমার এটি সিলেক্ট করলে মেইন ছবি বদলে যাবে।`,
                                        'success'
                                      );
                                    } catch (err: any) {
                                      showToast(err?.message || 'ছবি আপলোড ব্যর্থ হয়েছে', 'error');
                                    } finally {
                                      e.target.value = '';
                                    }
                                  }}
                                />
                                {v.imageUrl ? (
                                  <img
                                    src={v.imageUrl}
                                    alt={v.label}
                                    className="w-full h-full object-cover"
                                  />
                                ) : (
                                  <span className="text-[9px] font-extrabold leading-none">📷</span>
                                )}
                              </label>
                              {v.imageUrl && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setFormVariants(prev =>
                                      prev.map((item, i) =>
                                        i === idx ? { ...item, imageUrl: undefined } : item
                                      )
                                    )
                                  }
                                  title="ছবি সরান"
                                  className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-rose-600 text-white text-[9px] font-black flex items-center justify-center cursor-pointer"
                                >
                                  ×
                                </button>
                              )}
                            </div>
                            <input
                              type="text"
                              value={v.label}
                              onChange={e => {
                                const val = e.target.value;
                                setFormVariants(prev =>
                                  prev.map((item, i) =>
                                    i === idx ? { ...item, label: val } : item
                                  )
                                );
                              }}
                              className="w-full px-2.5 py-1 rounded-lg border border-slate-200 font-bold text-xs text-slate-900"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label className="block text-[9px] font-bold text-sky-700 uppercase">
                            Variation SKU
                          </label>
                          <input
                            type="text"
                            value={v.sku ?? buildVariantSkuCode(formSku || 'LP', v.label, idx)}
                            onChange={e => {
                              const val = e.target.value;
                              setFormVariants(prev =>
                                prev.map((item, i) =>
                                  i === idx ? { ...item, sku: val } : item
                                )
                              );
                            }}
                            placeholder={buildVariantSkuCode(formSku || 'LP', v.label, idx)}
                            className="w-full px-2 py-1 rounded-lg border border-sky-300 bg-sky-50/50 font-mono text-xs text-sky-950"
                            title="WordPress Variation SKU"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[9px] font-bold text-sky-700 uppercase">
                            WP Variation ID
                          </label>
                          <input
                            type="number"
                            min={0}
                            value={v.wpVariationId || ''}
                            onChange={e => {
                              const parsed = parseInt(e.target.value, 10);
                              setFormVariants(prev =>
                                prev.map((item, i) =>
                                  i === idx
                                    ? {
                                        ...item,
                                        wpVariationId:
                                          !Number.isNaN(parsed) && parsed > 0 ? parsed : undefined
                                      }
                                    : item
                                )
                              );
                            }}
                            placeholder="Auto"
                            className="w-full px-2 py-1 rounded-lg border border-sky-200 font-mono text-xs text-slate-800"
                            title="WordPress Variation ID (ঐচ্ছিক - অটো সিঙ্ক বা ম্যানুয়ালি দিন)"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[9px] font-bold text-slate-400 uppercase">
                            Regular (৳)
                          </label>
                          <input
                            type="number"
                            value={v.regularPrice ?? v.retailPrice}
                            onChange={e => {
                              const val = Number(e.target.value) || 0;
                              setFormVariants(prev =>
                                prev.map((item, i) =>
                                  i === idx ? { ...item, regularPrice: val } : item
                                )
                              );
                            }}
                            className="w-full px-2 py-1 rounded-lg border border-slate-200 font-mono text-xs text-slate-700"
                          />
                        </div>

                        <div className="sm:col-span-2 flex items-end gap-1.5">
                          <div className="flex-1">
                            <label className="block text-[9px] font-bold text-emerald-700 uppercase">
                              Offer (৳)
                            </label>
                            <input
                              type="number"
                              value={v.retailPrice}
                              onChange={e => {
                                const val = Number(e.target.value) || 0;
                                setFormVariants(prev =>
                                  prev.map((item, i) =>
                                    i === idx
                                      ? { ...item, retailPrice: val, discountPrice: val }
                                      : item
                                  )
                                );
                              }}
                              className="w-full px-2 py-1 rounded-lg border border-emerald-300 font-mono font-bold text-xs text-emerald-800"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              setFormVariants(prev =>
                                prev.map((item, i) =>
                                  i === idx ? { ...item, outOfStock: !item.outOfStock } : item
                                )
                              )
                            }
                            className={`px-2 py-1 rounded-lg border text-[10px] font-extrabold transition-all cursor-pointer shrink-0 ${
                              v.outOfStock
                                ? 'bg-rose-600 text-white border-rose-600'
                                : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                            }`}
                            title="এই ভ্যারিয়েশনটি ল্যান্ডিং পেজে স্টক আউট বা ইন-স্টক করুন"
                          >
                            {v.outOfStock ? '🚫 স্টক শেষ' : '✓ স্টকে আছে'}
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setFormVariants(prev => prev.filter((_, i) => i !== idx))
                            }
                            className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer"
                            title="Remove Variation"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 5. Product Features, Fabric Details & Trust Topics (ON/OFF + Text Customization) */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
                {/* Part A: প্রিমিয়াম কোয়ালিটি গ্যারান্টি + ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস + টপিক লিস্ট */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                        <BadgeCheck className="w-4 h-4 text-emerald-600" />
                        <span>ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস সেকশন (ON/OFF ও টেক্সট পরিবর্তন)</span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        “প্রিমিয়াম কোয়ালিটি গ্যারান্টি”, “ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:” এবং নিচের পয়েন্টগুলো চালু/বন্ধ ও এডিট করুন।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setFormFeaturesEnabled(prev => !prev)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        formFeaturesEnabled
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-100 text-slate-600 border-slate-300'
                      }`}
                    >
                      {formFeaturesEnabled ? 'সেকশন চালু (ON)' : 'সেকশন বন্ধ (OFF)'}
                    </button>
                  </div>

                  {formFeaturesEnabled && (
                    <div className="space-y-3 pt-1">
                      {/* 1. প্রিমিয়াম কোয়ালিটি গ্যারান্টি Badge ON/OFF + Text */}
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/80 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formFeaturesBadgeEnabled}
                              onChange={e => setFormFeaturesBadgeEnabled(e.target.checked)}
                              className="w-4 h-4 accent-emerald-600 cursor-pointer"
                            />
                            <span>উপরের ছোট ব্যাজ/ট্যাগ লাইন দেখান (যেমন: প্রিমিয়াম কোয়ালিটি গ্যারান্টি)</span>
                          </label>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-600">
                            {formFeaturesBadgeEnabled ? 'ON' : 'OFF'}
                          </span>
                        </div>
                        {formFeaturesBadgeEnabled && (
                          <input
                            type="text"
                            value={formFeaturesBadgeText}
                            onChange={e => setFormFeaturesBadgeText(e.target.value)}
                            placeholder="প্রিমিয়াম কোয়ালিটি গ্যারান্টি"
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-slate-900 font-semibold text-xs"
                          />
                        )}
                      </div>

                      {/* 2. ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস: Heading ON/OFF + Text */}
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/80 space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formHighlightsTitleEnabled}
                              onChange={e => setFormHighlightsTitleEnabled(e.target.checked)}
                              className="w-4 h-4 accent-emerald-600 cursor-pointer"
                            />
                            <span>সেকশন শিরোনাম দেখান (যেমন: ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:)</span>
                          </label>
                          <div className="flex flex-wrap items-center gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                setFormHighlightsTitleEnabled(true);
                                setFormHighlightsTitle('ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:');
                              }}
                              className="px-2 py-0.5 rounded bg-white text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer hover:bg-slate-100"
                            >
                              ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setFormHighlightsTitleEnabled(true);
                                setFormHighlightsTitle('পণ্যের বিশেষত্ব ও বিবরণ:');
                              }}
                              className="px-2 py-0.5 rounded bg-white text-slate-700 border border-slate-200 text-[10px] font-semibold cursor-pointer hover:bg-slate-100"
                            >
                              পণ্যের বিশেষত্ব ও বিবরণ:
                            </button>
                          </div>
                        </div>
                        {formHighlightsTitleEnabled && (
                          <input
                            type="text"
                            value={formHighlightsTitle}
                            onChange={e => setFormHighlightsTitle(e.target.value)}
                            placeholder="ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:"
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-slate-900 font-bold text-xs"
                          />
                        )}
                      </div>

                      {/* 3. Topics / Bullet Points below ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস */}
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <label className="block font-bold text-slate-800 text-xs">
                            নিচের পয়েন্ট / টপিকগুলো (চাইলে সরাসরি এডিট, ডিলিট বা নতুন পয়েন্ট যোগ করুন):
                          </label>
                        </div>

                        {/* Interactive Topic Row List */}
                        {(() => {
                          const topicLines = formDescription
                            .split(/\n+/)
                            .map(s => s.trim())
                            .filter(Boolean);

                          return (
                            <div className="space-y-2">
                              {topicLines.length > 0 && (
                                <div className="space-y-1.5">
                                  {topicLines.map((line, idx) => (
                                    <div key={idx} className="flex items-center gap-2">
                                      <span className="w-5 h-5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold flex items-center justify-center shrink-0">
                                        {idx + 1}
                                      </span>
                                      <input
                                        type="text"
                                        value={line}
                                        onChange={e => {
                                          const updated = [...topicLines];
                                          updated[idx] = e.target.value;
                                          setFormDescription(updated.join('\n'));
                                        }}
                                        className="flex-1 min-h-[34px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-xs text-slate-900"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const updated = topicLines.filter((_, i) => i !== idx);
                                          setFormDescription(updated.join('\n'));
                                        }}
                                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                                        title="এই পয়েন্টটি মুছে ফেলুন"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Add new single topic point */}
                              <div className="flex items-center gap-2 pt-1">
                                <input
                                  type="text"
                                  value={newFeatureTopicText}
                                  onChange={e => setNewFeatureTopicText(e.target.value)}
                                  onKeyDown={e => {
                                    if (e.key === 'Enter' && newFeatureTopicText.trim()) {
                                      e.preventDefault();
                                      const next = [...topicLines, newFeatureTopicText.trim()].join('\n');
                                      setFormDescription(next);
                                      setNewFeatureTopicText('');
                                    }
                                  }}
                                  placeholder="নতুন পয়েন্ট লিখুন (যেমন: ১০০% কালার গ্যারান্টি)..."
                                  className="flex-1 min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-xs text-slate-900"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (!newFeatureTopicText.trim()) return;
                                    const next = [...topicLines, newFeatureTopicText.trim()].join('\n');
                                    setFormDescription(next);
                                    setNewFeatureTopicText('');
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs inline-flex items-center gap-1 shrink-0 cursor-pointer"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                  <span>পয়েন্ট যোগ করুন</span>
                                </button>
                              </div>

                              {/* Optional multi-line textarea for bulk paste */}
                              <details className="pt-1">
                                <summary className="text-[11px] font-semibold text-slate-500 cursor-pointer hover:text-slate-700">
                                  একসাথে সব পয়েন্ট টেক্সটবক্সে এডিট করুন (প্রতি লাইনে ১টি পয়েন্ট)
                                </summary>
                                <textarea
                                  rows={3}
                                  value={formDescription}
                                  onChange={e => setFormDescription(e.target.value)}
                                  placeholder="১০০% প্রিমিয়াম কটন ফেব্রিক — গরমে অত্যন্ত আরামদায়ক&#10;কালার ও সেলাইয়ের ১০০% গ্যারান্টি&#10;পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধের সুবিধা"
                                  className="mt-1.5 w-full p-2.5 rounded-lg border border-slate-300 bg-white focus:border-emerald-600 outline-hidden text-xs text-slate-900 leading-relaxed"
                                />
                              </details>
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                  )}
                </div>

                {/* Part B: নিচের গ্যারান্টি ও ট্রাস্ট টপিকস (কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?) */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>নিচের গ্যারান্টি টপিক সেকশন (ON/OFF ও টেক্সট পরিবর্তন)</span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        “কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?” এবং এর নিচের ৪টি গ্যারান্টি টপিক চালু/বন্ধ ও টেক্সট পরিবর্তন করুন।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setFormTrustSectionEnabled(prev => !prev)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        formTrustSectionEnabled
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-100 text-slate-600 border-slate-300'
                      }`}
                    >
                      {formTrustSectionEnabled ? 'সেকশন চালু (ON)' : 'সেকশন বন্ধ (OFF)'}
                    </button>
                  </div>

                  {formTrustSectionEnabled && (
                    <div className="space-y-3 pt-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/80 space-y-1.5">
                          <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formTrustBadgeEnabled}
                              onChange={e => setFormTrustBadgeEnabled(e.target.checked)}
                              className="w-3.5 h-3.5 accent-emerald-600 cursor-pointer"
                            />
                            <span>উপরের ছোট ব্যাজ টেক্সট (ON/OFF):</span>
                          </label>
                          {formTrustBadgeEnabled && (
                            <input
                              type="text"
                              value={formTrustBadgeText}
                              onChange={e => setFormTrustBadgeText(e.target.value)}
                              placeholder="১০০% বিশ্বস্ত ও নিরাপদ শপিং"
                              className="w-full min-h-[34px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-900 outline-hidden"
                            />
                          )}
                        </div>

                        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/80 space-y-1.5">
                          <label className="block font-bold text-slate-800 text-xs">
                            সেকশন শিরোনাম (Heading):
                          </label>
                          <input
                            type="text"
                            value={formTrustTitle}
                            onChange={e => setFormTrustTitle(e.target.value)}
                            placeholder="কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?"
                            className="w-full min-h-[34px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900 outline-hidden"
                          />
                        </div>
                      </div>

                      {/* Individual Guarantee Topic Items (ON/OFF + Title + Subtitle) */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-800">
                            গ্যারান্টি টপিক তালিকা (প্রতিটি টপিক আলাদাভাবে ON/OFF ও টেক্সট পরিবর্তন করা যাবে):
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                setFormTrustItems(prev => [
                                  ...prev,
                                  {
                                    id: `trust_${Date.now()}`,
                                    title: 'নতুন গ্যারান্টি টপিক',
                                    description: 'এখানে বিস্তারিত বিবরণ লিখুন',
                                    enabled: true
                                  }
                                ])
                              }
                              className="px-2 py-1 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer hover:bg-emerald-100"
                            >
                              <Plus className="w-3 h-3" />
                              <span>নতুন টপিক</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setFormTrustItems(DEFAULT_LANDING_TRUST_ITEMS.map(item => ({ ...item })))
                              }
                              className="px-2 py-1 rounded bg-slate-100 text-slate-600 border border-slate-200 text-[10px] font-semibold cursor-pointer hover:bg-slate-200"
                            >
                              ডিফল্ট রিসেট
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {formTrustItems.map((item, idx) => (
                            <div
                              key={item.id || idx}
                              className={`p-2.5 rounded-xl border space-y-2 transition-colors ${
                                item.enabled !== false
                                  ? 'bg-slate-50/70 border-slate-200'
                                  : 'bg-slate-100/60 border-slate-200 opacity-60'
                              }`}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <label className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-800 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={item.enabled !== false}
                                    onChange={e => {
                                      const checked = e.target.checked;
                                      setFormTrustItems(prev =>
                                        prev.map((t, i) => (i === idx ? { ...t, enabled: checked } : t))
                                      );
                                    }}
                                    className="w-3.5 h-3.5 accent-emerald-600 cursor-pointer"
                                  />
                                  <span>টপিক #{idx + 1} ({item.enabled !== false ? 'ON' : 'OFF'})</span>
                                </label>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setFormTrustItems(prev => prev.filter((_, i) => i !== idx))
                                  }
                                  className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                                  title="মুছে ফেলুন"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>

                              <input
                                type="text"
                                value={item.title}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormTrustItems(prev =>
                                    prev.map((t, i) => (i === idx ? { ...t, title: val } : t))
                                  );
                                }}
                                placeholder="শিরোনাম (যেমন: হাতে পেয়ে পেমেন্ট)"
                                className="w-full min-h-[32px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900 outline-hidden"
                              />
                              <input
                                type="text"
                                value={item.description}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormTrustItems(prev =>
                                    prev.map((t, i) => (i === idx ? { ...t, description: val } : t))
                                  );
                                }}
                                placeholder="বিবরণ (যেমন: পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধের সুবিধা)"
                                className="w-full min-h-[32px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-[11px] text-slate-700 outline-hidden"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* BANNER 2: Custom Promotional Banner / Image Upload Right Before Video Section (ON/OFF System) */}
                <div className="p-3.5 rounded-xl bg-cyan-50/40 border border-cyan-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-cyan-100">
                    <div>
                      <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                        <ImageIcon className="w-4 h-4 text-cyan-600" />
                        <span>
                          ব্যানার ২ — ভিডিও সেকশনের ঠিক উপরে / আগে ইমেজ আপলোড (Banner 2 — ON/OFF)
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        প্রোডাক্ট ভিডিও সেকশনের ঠিক উপরে (আগে) দ্বিতীয় কাস্টম ব্যানার বা ছবি যুক্ত করুন এবং ১-ক্লিকে ON বা OFF রাখুন।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setFormPromoBanner2Enabled(prev => !prev)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        formPromoBanner2Enabled
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white text-slate-600 border-slate-300'
                      }`}
                    >
                      {formPromoBanner2Enabled ? 'ব্যানার ২ চালু (ON)' : 'ব্যানার ২ বন্ধ (OFF)'}
                    </button>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        ref={promoBanner2InputRef}
                        type="file"
                        accept="image/*"
                        onChange={async e => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setIsUploadingImage(true);
                          try {
                            const dataUrl = await processUploadedProductImage(file, 1200);
                            setFormPromoBanner2Image(dataUrl);
                            setFormPromoBanner2Enabled(true);
                            showToast('ব্যানার ২ (ভিডিও সেকশনের উপরে) ছবি যুক্ত ও চালু (ON) হয়েছে!', 'success');
                          } catch {
                            showToast('ব্যানার ২ ছবি প্রসেস করা যায়নি', 'error');
                          } finally {
                            setIsUploadingImage(false);
                            e.target.value = '';
                          }
                        }}
                        className="hidden"
                      />
                      <button
                        type="button"
                        disabled={isUploadingImage}
                        onClick={() => promoBanner2InputRef.current?.click()}
                        className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>ব্যানার ২ ইমেজ আপলোড করুন</span>
                      </button>

                      <input
                        type="text"
                        value={formPromoBanner2Image}
                        onChange={e => {
                          const val = e.target.value;
                          setFormPromoBanner2Image(val);
                          if (val.trim()) setFormPromoBanner2Enabled(true);
                        }}
                        placeholder="অথবা সরাসরি ব্যানার ২ ছবির লিংক দিন (https://...)"
                        className="flex-1 min-w-[210px] min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-900 outline-hidden"
                      />

                      {formPromoBanner2Image && (
                        <button
                          type="button"
                          onClick={() => {
                            setFormPromoBanner2Image('');
                            setFormPromoBanner2Enabled(false);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs cursor-pointer"
                        >
                          ব্যানার ২ মুছুন
                        </button>
                      )}
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        ব্যানার ২-এর উপরের টেক্সট / ক্যাপশন (ঐচ্ছিক):
                      </label>
                      <input
                        type="text"
                        value={formPromoBanner2Title}
                        onChange={e => setFormPromoBanner2Title(e.target.value)}
                        placeholder="যেমন: নিচের ভিডিওতে আমাদের অরিজিনাল ড্রেসের কোয়ালিটি দেখুন (ফাঁকা রাখলে শুধু ছবি দেখাবে)"
                        className="w-full min-h-[36px] px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold outline-hidden"
                      />
                    </div>

                    {formPromoBanner2Image && (
                      <div className="p-2.5 rounded-xl bg-white border border-cyan-200 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-cyan-900">
                            ব্যানার ২ প্রিভিউ ({formPromoBanner2Enabled ? 'ON - চালু' : 'OFF - বন্ধ'}):
                          </span>
                        </div>
                        <img
                          src={formPromoBanner2Image}
                          alt="Banner 2 Preview"
                          className="w-full max-h-40 object-contain rounded-lg bg-slate-50"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Part C: ১. প্রোডাক্ট ভিডিও / ইউটিউব বা রিলস ভিডিও সেকশন (ON/OFF + Video URL + Heading) */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                        <Play className="w-4 h-4 text-rose-600" />
                        <span>প্রোডাক্ট ভিডিও / ইউটিউব বা রিলস ভিডিও সেকশন (ON/OFF ও ভিডিও লিংক)</span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        YouTube ভিডিও, YouTube Shorts, Facebook Reels অথবা সরাসরি MP4 ভিডিও লিংক দিন এবং চাইলে সেকশনটি ON/OFF করুন।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setFormVideoEnabled(prev => !prev)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        formVideoEnabled
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-100 text-slate-600 border-slate-300'
                      }`}
                    >
                      {formVideoEnabled ? 'ভিডিও সেকশন চালু (ON)' : 'ভিডিও সেকশন বন্ধ (OFF)'}
                    </button>
                  </div>

                  {formVideoEnabled && (
                    <div className="space-y-3 pt-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block font-bold text-slate-800 text-xs mb-1">
                            ভিডিও সেকশন শিরোনাম (Title):
                          </label>
                          <input
                            type="text"
                            value={formVideoTitle}
                            onChange={e => setFormVideoTitle(e.target.value)}
                            placeholder="প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:"
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900 outline-hidden"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-800 text-xs mb-1">
                            উপরের ছোট ব্যাজ টেক্সট (Subtitle Badge):
                          </label>
                          <input
                            type="text"
                            value={formVideoSubtitle}
                            onChange={e => setFormVideoSubtitle(e.target.value)}
                            placeholder="১০০% অরিজিনাল প্রোডাক্টের রিয়েল ভিডিও শোকেস"
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-900 outline-hidden"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-800 text-xs mb-1">
                          YouTube / YouTube Shorts / Facebook Reels / MP4 ভিডিও লিংক:
                        </label>
                        <input
                          type="text"
                          value={formVideoUrl}
                          onChange={e => setFormVideoUrl(e.target.value)}
                          placeholder="যেমন: https://www.youtube.com/watch?v=... বা https://www.youtube.com/shorts/... বা https://www.facebook.com/reel/..."
                          className="w-full min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-xs text-slate-900 outline-hidden focus:border-emerald-600"
                        />
                        <p className="text-[11px] text-slate-500 mt-1">
                          লিংক ফাঁকা রাখলে প্রোডাক্টের গ্যালারি ছবিগুলো দিয়ে অটোমেটিক একটি সুন্দর রিলস শোকেস প্লেয়ার দেখাবে।
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Part D: ২. সাইজ চার্ট ও মাপজোখ গাইড (পপ-আপ বাটন + বডির ভেতরে ফুল চার্ট আলাদা ON/OFF + Editable Table) */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                        <Ruler className="w-4 h-4 text-indigo-600" />
                        <span>সাইজ চার্ট ও মাপজোখ গাইড (পপ-আপ বাটন ও বডি ফুল চার্ট আলাদা ON/OFF)</span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        ভ্যারিয়েশনের উপরের "সাইজ চার্ট দেখুন" পপ-আপ বাটন এবং ডেসক্রিপশনের নিচে বডির ভেতরে ফুল সাইজ চার্ট টেবিল আলাদাভাবে ON/OFF করুন।
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setFormSizeChartEnabled(prev => !prev)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          formSizeChartEnabled
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-slate-100 text-slate-600 border-slate-300'
                        }`}
                      >
                        {formSizeChartEnabled ? 'পপ-আপ চার্ট বাটন: ON' : 'পপ-আপ চার্ট বাটন: OFF'}
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormBodySizeChartEnabled(prev => !prev)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          formBodySizeChartEnabled
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-slate-100 text-slate-600 border-slate-300'
                        }`}
                      >
                        {formBodySizeChartEnabled ? 'বডি ফুল চার্ট: ON' : 'বডি ফুল চার্ট: OFF'}
                      </button>
                    </div>
                  </div>

                  {(formSizeChartEnabled || formBodySizeChartEnabled) && (
                    <div className="space-y-3 pt-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block font-bold text-slate-800 text-xs mb-1">
                            সাইজ চার্ট শিরোনাম (Title):
                          </label>
                          <input
                            type="text"
                            value={formSizeChartTitle}
                            onChange={e => setFormSizeChartTitle(e.target.value)}
                            placeholder="সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):"
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900 outline-hidden"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-800 text-xs mb-1">
                            সাব-টাইটেল (Subtitle):
                          </label>
                          <input
                            type="text"
                            value={formSizeChartSubtitle}
                            onChange={e => setFormSizeChartSubtitle(e.target.value)}
                            placeholder="সঠিক সাইজ নির্বাচন করতে নিচের মাপগুলো দেখে নিন"
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs text-slate-900 outline-hidden"
                          />
                        </div>
                      </div>

                      {/* 1-Click Size Chart Presets */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[11px] font-bold text-slate-600 mr-1">
                          ১-ক্লিক রেডি সাইজ চার্ট:
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setFormSizeChartHeaders([
                              'বয়স / সাইজ',
                              'বডি / চেস্ট (ইঞ্চি)',
                              'লম্বা / দৈর্ঘ্য (ইঞ্চি)'
                            ]);
                            setFormSizeChartRows(DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r })));
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 text-[11px] font-bold cursor-pointer"
                        >
                          বেবি / বাচ্চাদের ড্রেস (১-১০ বছর)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setFormSizeChartHeaders([
                              'সাইজ (Size)',
                              'বডি / চেস্ট (ইঞ্চি)',
                              'লম্বা / দৈর্ঘ্য (ইঞ্চি)'
                            ]);
                            setFormSizeChartRows([
                              { id: 'ad_1', size: 'M (Medium)', chest: '৩৮ - ৪০ ইঞ্চি', length: '২৭ ইঞ্চি' },
                              { id: 'ad_2', size: 'L (Large)', chest: '৪০ - ৪২ ইঞ্চি', length: '২৮ ইঞ্চি' },
                              { id: 'ad_3', size: 'XL (Extra Large)', chest: '৪২ - ৪৪ ইঞ্চি', length: '২৯ ইঞ্চি' },
                              { id: 'ad_4', size: 'XXL (Double XL)', chest: '৪৪ - ৪৬ ইঞ্চি', length: '৩০ ইঞ্চি' }
                            ]);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 text-[11px] font-bold cursor-pointer"
                        >
                          বড়দের ড্রেস / পাঞ্জাবি / টি-শার্ট (M - XXL)
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setFormSizeChartRows(prev => [
                              ...prev,
                              {
                                id: `sz_${Date.now()}`,
                                size: 'নতুন সাইজ',
                                chest: '২৬ ইঞ্চি',
                                length: '২২ ইঞ্চি'
                              }
                            ])
                          }
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>নতুন সারি যোগ করুন</span>
                        </button>
                      </div>

                      {/* Table Column Headers */}
                      <div className="grid grid-cols-3 gap-2 p-2 rounded-lg bg-emerald-50/70 border border-emerald-200">
                        {[0, 1, 2].map(colIdx => (
                          <input
                            key={colIdx}
                            type="text"
                            value={formSizeChartHeaders[colIdx] || ''}
                            onChange={e => {
                              const val = e.target.value;
                              setFormSizeChartHeaders(prev => {
                                const next: [string, string, string] = [...prev];
                                next[colIdx] = val;
                                return next;
                              });
                            }}
                            placeholder={`কলাম ${colIdx + 1}`}
                            className="w-full px-2.5 py-1 rounded bg-white border border-emerald-300 text-xs font-extrabold text-emerald-950 outline-hidden"
                          />
                        ))}
                      </div>

                      {/* Table Rows Editor */}
                      <div className="space-y-1.5">
                        {formSizeChartRows.map((row, rIdx) => (
                          <div key={row.id || rIdx} className="grid grid-cols-12 gap-2 items-center">
                            <div className="col-span-4">
                              <input
                                type="text"
                                value={row.size}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormSizeChartRows(prev =>
                                    prev.map((item, i) => (i === rIdx ? { ...item, size: val } : item))
                                  );
                                }}
                                placeholder="সাইজ / বয়স"
                                className="w-full px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900 outline-hidden"
                              />
                            </div>
                            <div className="col-span-4">
                              <input
                                type="text"
                                value={row.chest}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormSizeChartRows(prev =>
                                    prev.map((item, i) => (i === rIdx ? { ...item, chest: val } : item))
                                  );
                                }}
                                placeholder="বডি / চেস্ট"
                                className="w-full px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs text-slate-800 outline-hidden"
                              />
                            </div>
                            <div className="col-span-3">
                              <input
                                type="text"
                                value={row.length}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormSizeChartRows(prev =>
                                    prev.map((item, i) => (i === rIdx ? { ...item, length: val } : item))
                                  );
                                }}
                                placeholder="লম্বা"
                                className="w-full px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs text-slate-800 outline-hidden"
                              />
                            </div>
                            <div className="col-span-1 flex justify-end">
                              <button
                                type="button"
                                onClick={() =>
                                  setFormSizeChartRows(prev => prev.filter((_, i) => i !== rIdx))
                                }
                                className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                                title="সারি মুছুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Optional Size Chart Image Upload */}
                      <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[11px] font-semibold text-slate-600">
                          চাইলে সাইজ চার্টের ছবিও আপলোড করতে পারেন (ঐচ্ছিক):
                        </span>
                        <div className="flex items-center gap-2">
                          <input
                            ref={sizeChartImageInputRef}
                            type="file"
                            accept="image/*"
                            onChange={async e => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              setIsUploadingImage(true);
                              try {
                                const dataUrl = await processUploadedProductImage(file);
                                setFormSizeChartImage(dataUrl);
                                showToast('সাইজ চার্ট ছবি যুক্ত হয়েছে!', 'success');
                              } catch {
                                showToast('ছবি প্রসেস করা যায়নি', 'error');
                              } finally {
                                setIsUploadingImage(false);
                                e.target.value = '';
                              }
                            }}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => sizeChartImageInputRef.current?.click()}
                            className="px-3 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>সাইজ চার্ট ছবি আপলোড</span>
                          </button>
                          {formSizeChartImage && (
                            <button
                              type="button"
                              onClick={() => setFormSizeChartImage('')}
                              className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                            >
                              ছবি মুছুন
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Part E: ৩. রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ (Live Order Social Proof — ON/OFF + Custom Buyers) */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                        <Bell className="w-4 h-4 text-emerald-600" />
                        <span>
                          রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ (Live Order Social Proof — ON/OFF)
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        বাংলাদেশের ৫৬+ জেলা ও এলাকার ভেরিফাইড ক্রেতাদের নাম স্মার্ট রোটেশনে দেখাবে (একেক কাস্টমার ও প্রতিবার ভিজিটে নতুন নাম দেখাবে)।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setFormSocialProofEnabled(prev => !prev)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        formSocialProofEnabled
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-100 text-slate-600 border-slate-300'
                      }`}
                    >
                      {formSocialProofEnabled ? 'অর্ডার পপ-আপ চালু (ON)' : 'অর্ডার পপ-আপ বন্ধ (OFF)'}
                    </button>
                  </div>

                  {formSocialProofEnabled && (
                    <div className="space-y-3 pt-1">
                      {/* Time Gap / Speed Control between notifications */}
                      <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200/80 space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <label className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-emerald-600" />
                            <span>
                              অর্ডার নোটিফিকেশন আসার সময়ের গ্যাপ (Time Gap / Speed — কত সেকেন্ড পর পর দেখাবে):
                            </span>
                          </label>
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              min={2}
                              max={300}
                              value={formSocialProofIntervalSec}
                              onChange={e =>
                                setFormSocialProofIntervalSec(
                                  Math.max(2, Math.min(300, Number(e.target.value) || 16))
                                )
                              }
                              className="w-20 min-h-[32px] px-2.5 py-1 rounded-lg border border-emerald-300 bg-white font-mono font-extrabold text-xs text-slate-900 text-center"
                            />
                            <span className="text-[11px] font-bold text-slate-600">সেকেন্ড গ্যাপ</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5">
                          {[
                            { sec: 5, label: 'ফাস্ট (৫ সে. গ্যাপ)' },
                            { sec: 10, label: 'মিডিয়াম (১০ সে. গ্যাপ)' },
                            { sec: 16, label: 'স্ট্যান্ডার্ড (১৬ সে. গ্যাপ)' },
                            { sec: 25, label: 'গ্যাপ দিয়ে (২৫ সে. গ্যাপ)' },
                            { sec: 40, label: 'স্লো (৪০ সে. গ্যাপ)' },
                            { sec: 60, label: '১ মিনিট পর পর (৬০ সে.)' }
                          ].map(opt => (
                            <button
                              key={opt.sec}
                              type="button"
                              onClick={() => setFormSocialProofIntervalSec(opt.sec)}
                              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition-all cursor-pointer ${
                                formSocialProofIntervalSec === opt.sec
                                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                  : 'bg-white hover:bg-emerald-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              {opt.label}
                            </button>
                          ))}
                        </div>
                        <p className="text-[11px] text-slate-500">
                          টিপস: প্রতিটি নোটিফিকেশন ৪.৫ সেকেন্ড স্ক্রিনে থাকবে এবং এরপর আপনার সিলেক্ট করা সেকেন্ড গ্যাপ দিয়ে পরবর্তী নোটিফিকেশন আসবে।
                        </p>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-800 text-xs mb-1">
                          কাস্টম ক্রেতার নাম ও ঠিকানা (ঐচ্ছিক — ফাঁকা রাখলে অটোমেটিক সারা বাংলাদেশের ৫৬+ এলাকার ভিন্ন ভিন্ন ক্রেতার নাম র‍্যান্ডমলি দেখাবে):
                        </label>
                        <textarea
                          rows={3}
                          value={formSocialProofCustomText}
                          onChange={e => setFormSocialProofCustomText(e.target.value)}
                          placeholder={`তানিয়া আক্তার | উত্তরা, ঢাকা | ৩ মিনিট আগে\nফারহানা ইসলাম | ধানমন্ডি, ঢাকা | ৭ মিনিট আগে\nরাকিবুল হাসান | চট্টগ্রাম | ১২ মিনিট আগে`}
                          className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-xs text-slate-900 outline-hidden focus:border-emerald-600"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Live Viewers Urgency Counter (12-48 Randomized — ON/OFF) */}
                <div className="p-3.5 rounded-xl bg-white border border-amber-200 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formLiveViewersEnabled}
                        onChange={e => setFormLiveViewersEnabled(e.target.checked)}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
                        <Eye className="w-4 h-4 text-amber-600" />
                        <span>
                          লাইভ ভিউয়ার কাউন্টার ("People currently viewing this product" — ON/OFF)
                        </span>
                      </span>
                    </label>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                        formLiveViewersEnabled
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {formLiveViewersEnabled ? 'ACTIVE (12–48 Viewers)' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    চালু থাকলে প্রোডাক্ট ল্যান্ডিং পেজে ১২ থেকে ৪৮ জনের একটি র‍্যান্ডম লাইভ ভিউয়ার কাউন্টার দেখাবে।
                  </p>
                </div>
              </div>

              {/* 6. Top Header Bar (Logo + Phone Number Bar) & Call / WhatsApp Buttons Settings (Enable / Disable + Custom Numbers) */}
              <div className="p-4 rounded-xl bg-blue-50/40 border border-blue-200/80 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-blue-200/60">
                  <div>
                    <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                      <PhoneCall className="w-4 h-4 text-blue-600" />
                      <span>টপ হেডার বার (লোগো ও ফোন নম্বর বার) এবং Call / WhatsApp সেটিংস (ON / OFF)</span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      টপ হেডার চালু (ON) থাকলে উপরে লোগো ও ফোন নম্বর বার দেখাবে, আর বন্ধ (OFF) করলে পুরো টপ হেডার বার হাইড থাকবে।
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setFormTopHeaderEnabled(prev => !prev)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      formTopHeaderEnabled
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-600 border-slate-300'
                    }`}
                  >
                    {formTopHeaderEnabled
                      ? 'টপ হেডার বার চালু (ON)'
                      : 'টপ হেডার বার বন্ধ (OFF)'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Call Button Toggle & Number */}
                  <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-2.5">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="font-bold text-slate-800 flex items-center gap-1.5">
                        <PhoneCall className="w-3.5 h-3.5 text-blue-600" />
                        <span>উপরে Call বাটন দেখান (Enable Call)</span>
                      </span>
                      <input
                        type="checkbox"
                        checked={formShowCallBtn}
                        onChange={e => setFormShowCallBtn(e.target.checked)}
                        className="w-4 h-4 accent-blue-600 cursor-pointer"
                      />
                    </label>
                    {formShowCallBtn && (
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          কল করার মোবাইল নম্বর:
                        </label>
                        <input
                          type="tel"
                          value={formCallPhone}
                          onChange={e => setFormCallPhone(e.target.value)}
                          placeholder={currentBusiness.callOrderPhone || currentBusiness.phone || '017XXXXXXXX'}
                          className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 outline-hidden"
                        />
                      </div>
                    )}
                  </div>

                  {/* WhatsApp Button Toggle & Number */}
                  <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-2.5">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="font-bold text-slate-800 flex items-center gap-1.5">
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                        <span>উপরে WhatsApp বাটন দেখান (Enable WhatsApp)</span>
                      </span>
                      <input
                        type="checkbox"
                        checked={formShowWhatsappBtn}
                        onChange={e => setFormShowWhatsappBtn(e.target.checked)}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                    </label>
                    {formShowWhatsappBtn && (
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          WhatsApp নম্বর:
                        </label>
                        <input
                          type="tel"
                          value={formWhatsappPhone}
                          onChange={e => setFormWhatsappPhone(e.target.value)}
                          placeholder={currentBusiness.whatsappOrderPhone || currentBusiness.phone || '017XXXXXXXX'}
                          className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 outline-hidden"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* 7. Customer Reviews Section (Optional — Enable / Disable + Screenshot / Written Reviews) */}
              <div className="p-4 rounded-xl bg-amber-50/40 border border-amber-200/80 space-y-3">
                <label className="flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    <div>
                      <span className="font-bold text-slate-900 block">
                        কাস্টমার রিভিউ সেকশন দেখান (Enable Customer Reviews on Landing Page)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        চালু করলে ল্যান্ডিং পেজে কাস্টমার রিভিউ দেখাবে, বন্ধ রাখলে সম্পূর্ণ হাইড থাকবে।
                      </span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formReviewsEnabled}
                    onChange={e => setFormReviewsEnabled(e.target.checked)}
                    className="w-4 h-4 accent-amber-600 cursor-pointer"
                  />
                </label>

                {formReviewsEnabled && (
                  <div className="pt-2 border-t border-amber-200/70 space-y-3">
                    {/* Slider vs Grid Mode Toggle */}
                    <div className="p-3 rounded-xl bg-white border border-amber-200 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-bold text-slate-900 block text-xs">
                          🎠 রিভিউ স্লাইডার ভিউ (Review Slider / Carousel Mode)
                        </span>
                        <span className="text-[11px] text-slate-500">
                          চালু রাখলে কম জায়গায় অনেকগুলো রিভিউ স্লাইডার আকারে ঘুরবে (সোয়াইপ ও অটো-প্লে সহ)। অফ করলে গ্রিড আকারে নিচে নিচে দেখাবে।
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setFormReviewsSliderEnabled(prev => !prev)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer shrink-0 ${
                          formReviewsSliderEnabled
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                        }`}
                      >
                        {formReviewsSliderEnabled ? '🎠 স্লাইডার: ON' : 'গ্রিড ভিউ (Slider OFF)'}
                      </button>
                    </div>

                    {/* Review Section Heading */}
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        রিভিউ সেকশনের শিরোনাম (Section Title):
                      </label>
                      <input
                        type="text"
                        value={formReviewsTitle}
                        onChange={e => setFormReviewsTitle(e.target.value)}
                        placeholder="সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ"
                        className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-bold text-slate-900 outline-hidden"
                      />
                    </div>

                    {/* Option A: Upload Customer Review Screenshots */}
                    <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <span className="font-bold text-slate-800 block">
                            রিভিউ স্ক্রিনশট ছবি (Messenger / WhatsApp Review Screenshots)
                          </span>
                          <span className="text-[11px] text-slate-500">
                            চাইলে কাস্টমারদের মেসেজের স্ক্রিনশট বা ডেলিভারি ছবি আপলোড করতে পারেন
                          </span>
                        </div>
                        <div>
                          <input
                            ref={reviewImageInputRef}
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={handleReviewImageUpload}
                            className="hidden"
                          />
                          <button
                            type="button"
                            disabled={isUploadingImage}
                            onClick={() => reviewImageInputRef.current?.click()}
                            className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>স্ক্রিনশট আপলোড করুন</span>
                          </button>
                        </div>
                      </div>

                      {formReviewImages.length > 0 && (
                        <div className="flex flex-wrap items-center gap-2.5 pt-1">
                          {formReviewImages.map((imgUrl, idx) => (
                            <div
                              key={idx}
                              className="relative w-20 h-20 rounded-xl border border-amber-300 overflow-hidden bg-slate-50"
                            >
                              <img src={imgUrl} alt="" className="w-full h-full object-cover" />
                              <button
                                type="button"
                                onClick={() =>
                                  setFormReviewImages(prev => prev.filter((_, i) => i !== idx))
                                }
                                className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[10px] cursor-pointer"
                              >
                                ×
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Option B: Written Customer Reviews + Circular Profile Photo Upload */}
                    <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <span className="font-bold text-slate-800 block">
                            লিখিত কাস্টমার রিভিউ ও গোল প্রোফাইল ছবি ({formReviewItems.length}টি)
                          </span>
                          <span className="text-[11px] text-slate-500">
                            ক্রেতার নামের প্রথম অক্ষরের গোল বৃত্তে চাইলে ক্রেতার ছবি আপলোড করতে পারবেন (ছবি না দিলে নামের প্রথম অক্ষর দেখাবে)
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleLoadSampleReviews}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-bold cursor-pointer"
                        >
                          + ১-ক্লিকে ৬টি রেডি বাংলা রিভিউ লোড করুন
                        </button>
                      </div>

                      {/* Hidden file input for existing review avatar replacement */}
                      <input
                        ref={existingReviewAvatarInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleExistingReviewAvatarUpload}
                        className="hidden"
                      />

                      {/* Add New Written Review Row */}
                      <div className="p-2.5 rounded-xl bg-amber-50/50 border border-amber-200/70 space-y-2">
                        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
                          {/* Circular Profile Photo Picker for New Review */}
                          <div className="sm:col-span-3">
                            <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                              ক্রেতার গোল ছবি (ঐচ্ছিক)
                            </label>
                            <div className="flex items-center gap-2">
                              <div
                                onClick={() => newReviewAvatarInputRef.current?.click()}
                                className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-black text-xs flex items-center justify-center shrink-0 overflow-hidden border-2 border-emerald-200 shadow-xs cursor-pointer"
                                title="ছবি আপলোড করতে ক্লিক করুন"
                              >
                                {newReviewAvatar ? (
                                  <img
                                    src={newReviewAvatar}
                                    alt="Avatar"
                                    className="w-full h-full object-cover"
                                  />
                                ) : (
                                  (newReviewName || 'ক').trim().charAt(0)
                                )}
                              </div>
                              <input
                                ref={newReviewAvatarInputRef}
                                type="file"
                                accept="image/*"
                                onChange={handleNewReviewAvatarUpload}
                                className="hidden"
                              />
                              <button
                                type="button"
                                onClick={() => newReviewAvatarInputRef.current?.click()}
                                className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-[11px] font-bold cursor-pointer"
                              >
                                {newReviewAvatar ? 'ছবি পরিবর্তন' : '📷 ছবি দিন'}
                              </button>
                              {newReviewAvatar && (
                                <button
                                  type="button"
                                  onClick={() => setNewReviewAvatar('')}
                                  className="text-[10px] font-bold text-rose-600 hover:underline cursor-pointer"
                                >
                                  মুছুন
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="sm:col-span-3">
                            <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">
                              ক্রেতার নাম
                            </label>
                            <input
                              type="text"
                              value={newReviewName}
                              onChange={e => setNewReviewName(e.target.value)}
                              placeholder="যেমন: নুসরাত জাহান"
                              className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-900 outline-hidden"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">
                              ঠিকানা / পরিচয়
                            </label>
                            <input
                              type="text"
                              value={newReviewLocation}
                              onChange={e => setNewReviewLocation(e.target.value)}
                              placeholder="ধানমন্ডি, ঢাকা"
                              className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-900 outline-hidden"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">
                              রিভিউ কমেন্ট
                            </label>
                            <input
                              type="text"
                              value={newReviewComment}
                              onChange={e => setNewReviewComment(e.target.value)}
                              placeholder="প্রোডাক্টের মান খুবই চমৎকার..."
                              className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-900 outline-hidden"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <button
                              type="button"
                              onClick={handleAddWrittenReview}
                              className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer"
                            >
                              + Add Review
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Existing Written Reviews List with Circular Avatar Upload/Remove */}
                      {formReviewItems.length > 0 && (
                        <div className="space-y-1.5 pt-1">
                          {formReviewItems.map((rev, idx) => {
                            const isPending = rev.status === 'pending';
                            return (
                              <div
                                key={rev.id || idx}
                                className={`p-2.5 rounded-lg border flex items-start justify-between gap-2.5 ${
                                  isPending
                                    ? 'bg-amber-50/80 border-amber-300 border-dashed'
                                    : 'bg-slate-50 border-slate-200'
                                }`}
                              >
                                {/* Circular Reviewer Avatar Badge */}
                                <div className="flex flex-col items-center gap-1 shrink-0">
                                  <div
                                    onClick={() => {
                                      editingAvatarReviewIdxRef.current = idx;
                                      existingReviewAvatarInputRef.current?.click();
                                    }}
                                    className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-black text-sm flex items-center justify-center overflow-hidden border-2 border-white shadow-xs cursor-pointer"
                                    title="ক্রেতার গোল ছবি পরিবর্তন করতে ক্লিক করুন"
                                  >
                                    {rev.avatarUrl ? (
                                      <img
                                        src={rev.avatarUrl}
                                        alt={rev.customerName}
                                        className="w-full h-full object-cover"
                                      />
                                    ) : (
                                      (rev.customerName || 'ক').trim().charAt(0)
                                    )}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        editingAvatarReviewIdxRef.current = idx;
                                        existingReviewAvatarInputRef.current?.click();
                                      }}
                                      className="px-1.5 py-0.5 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-[9px] font-bold cursor-pointer"
                                    >
                                      📷 ছবি
                                    </button>
                                    {rev.avatarUrl && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setFormReviewItems(prev =>
                                            prev.map((item, i) =>
                                              i === idx ? { ...item, avatarUrl: undefined } : item
                                            )
                                          )
                                        }
                                        className="px-1 py-0.5 rounded bg-rose-50 hover:bg-rose-100 text-rose-600 text-[9px] font-bold cursor-pointer"
                                        title="গোল ছবি মুছে নামের প্রথম অক্ষর দেখান"
                                      >
                                        ×
                                      </button>
                                    )}
                                  </div>
                                </div>

                                <div className="min-w-0 flex-1">
                                  <div className="flex flex-wrap items-center gap-1.5">
                                    <span className="font-bold text-slate-900">{rev.customerName}</span>
                                    {rev.location && (
                                      <span className="text-[10px] text-emerald-700 font-semibold">
                                        · {rev.location}
                                      </span>
                                    )}
                                    <span
                                      className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                                        isPending
                                          ? 'bg-amber-200 text-amber-950'
                                          : 'bg-emerald-100 text-emerald-800'
                                      }`}
                                    >
                                      {isPending ? '⏳ পেন্ডিং' : '✓ প্রকাশিত'}
                                    </span>
                                  </div>
                                  <p className="text-slate-700 mt-0.5">{rev.comment}</p>
                                </div>
                                <div className="flex items-center gap-1 shrink-0">
                                  {isPending && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setFormReviewItems(prev =>
                                          prev.map((item, i) =>
                                            i === idx ? { ...item, status: 'approved' } : item
                                          )
                                        )
                                      }
                                      className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer"
                                      title="রিভিউ অ্যাপ্রুভ করুন"
                                    >
                                      ✓ Approve
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setFormReviewItems(prev => prev.filter((_, i) => i !== idx))
                                    }
                                    className="p-1 text-rose-500 hover:bg-rose-50 rounded cursor-pointer shrink-0"
                                    title="রিভিউ মুছুন"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* 8. Footer Anti-Fake Order Warning Notice Section (ON/OFF + Editable Multi-Line Text) */}
              <div className="p-4 rounded-xl bg-amber-50/40 border border-amber-200/90 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-900 block">
                        ফুটারে ফেক অর্ডার না করার অনুরোধ বার্তা (Anti-Fake Order Notice — ON/OFF ও টেক্সট এডিট)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        ল্যান্ডিং পেজের একদম নিচে ফেক অর্ডার সতর্কবার্তা চালু/বন্ধ করুন এবং চাইলে লেখা পরিবর্তন করুন।
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setFormFooterWarningEnabled(prev => !prev)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      formFooterWarningEnabled
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-600 border-slate-300'
                    }`}
                  >
                    {formFooterWarningEnabled ? 'নোটিশ চালু আছে (ON)' : 'নোটিশ বন্ধ আছে (OFF)'}
                  </button>
                </div>

                {formFooterWarningEnabled && (
                  <div className="pt-2 border-t border-amber-200/70 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="text-[11px] font-bold text-slate-700">
                        ফুটার সতর্কবার্তা টেক্সট (প্রতি লাইনে আলাদা বাক্য দিতে পারবেন):
                      </label>
                      <button
                        type="button"
                        onClick={() => setFormFooterWarningText(DEFAULT_FOOTER_WARNING_TEXT)}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 text-[10px] font-bold cursor-pointer"
                      >
                        ডিফল্ট টেক্সট রিসেট করুন
                      </button>
                    </div>
                    <textarea
                      rows={3}
                      value={formFooterWarningText}
                      onChange={e => setFormFooterWarningText(e.target.value)}
                      placeholder={DEFAULT_FOOTER_WARNING_TEXT}
                      className="w-full p-2.5 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-900 leading-relaxed outline-hidden focus:border-emerald-600"
                    />
                  </div>
                )}
              </div>

              {/* 9. Footer Developer Credit Section (ON/OFF + Editable Name & Link) */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <label className="flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-emerald-600" />
                    <div>
                      <span className="font-bold text-slate-900 block">
                        ফুটার ডেভেলপার ক্রেডিট অপারেশন (Landing Page & Website Footer Developer Credit)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        ফুটারে ডেভেলপার ক্রেডিট দেখানো ON / OFF করুন এবং ডেভেলপারের নাম ও লিংক পরিবর্তন করুন।
                      </span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formDevCreditEnabled}
                    onChange={e => setFormDevCreditEnabled(e.target.checked)}
                    className="w-4 h-4 accent-emerald-600 cursor-pointer"
                  />
                </label>

                {formDevCreditEnabled && (
                  <div className="pt-2 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        ডেভেলপারের নাম (Developer Name):
                      </label>
                      <input
                        type="text"
                        value={formDevCreditName}
                        onChange={e => setFormDevCreditName(e.target.value)}
                        placeholder="যেমন: Web Studio BD"
                        className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-bold text-slate-900 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        ডেভেলপার লিংক (Developer Link / URL):
                      </label>
                      <input
                        type="text"
                        value={formDevCreditLink}
                        onChange={e => setFormDevCreditLink(e.target.value)}
                        placeholder="https://yourwebsite.com"
                        className="w-full min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-slate-900 outline-hidden"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* 10. Separate Landing Page Spin the Wheel Section (ON/OFF + Quick Open Customize Modal) */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-50/70 via-white to-rose-50/60 border border-amber-200/90 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Gift className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-900 block">
                        ল্যান্ডিং পেজ স্পিন দ্য হুইল অফার (Separate Spin the Wheel — ON/OFF)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        এই ল্যান্ডিং পেজে ভিজিটর ঢুকলে কয়েক সেকেন্ড পর স্পিন হুইল দেখাবে এবং নাম ও মোবাইল নাম্বার দিয়ে স্পিন করলে অর্ডারে ছাড় যুক্ত হবে।
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setLandingSpinConfigDraft(landingSpinWheelConfig);
                        setLandingSpinAdminTab('settings');
                        setShowLandingSpinAdminModal(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 text-xs font-extrabold cursor-pointer"
                    >
                      ⚙️ অফার ও স্লাইস কাস্টমাইজ করুন
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormLandingSpinWheelEnabled(prev => !prev)}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        formLandingSpinWheelEnabled
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white text-slate-600 border-slate-300'
                      }`}
                    >
                      {formLandingSpinWheelEnabled ? 'স্পিন হুইল চালু (ON)' : 'স্পিন হুইল বন্ধ (OFF)'}
                    </button>
                  </div>
                </div>
              </div>

              {/* 11. Mobile Floating "অর্ডার কনফার্ম করুন" Button Total Price Display Toggle & Switchable Animation Styles */}
              <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-200/90 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-rose-600 shrink-0" />
                    <div>
                      <span className="font-bold text-slate-900 block">
                        মোবাইল ফ্লোটিং বাটন প্রাইস ও অ্যানিমেশন স্টাইল — "অর্ডার কনফার্ম করুন (৳1,010)"
                      </span>
                      <span className="text-[11px] text-slate-500">
                        চালু (ON) থাকলে নিচের ফ্লোটিং লাল বাটনের ভেতর ডেলিভারি চার্জসহ মোট দাম দেখাবে এবং আপনার পছন্দের অ্যানিমেশন স্টাইল চলবে।
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setFormFloatingBtnPriceEnabled(prev => !prev)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      formFloatingBtnPriceEnabled
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'bg-white text-slate-600 border-slate-300'
                    }`}
                  >
                    {formFloatingBtnPriceEnabled ? 'বাটন প্রাইস চালু (ON)' : 'বাটন প্রাইস বন্ধ (OFF)'}
                  </button>
                </div>

                {/* Switchable Animation Style Selector */}
                <div className="pt-2.5 border-t border-rose-200/70 space-y-2">
                  <label className="block text-xs font-extrabold text-slate-800">
                    ফ্লোটিং অর্ডার বাটনের অ্যানিমেশন স্টাইল নির্বাচন করুন (Switchable Button Animation):
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {(
                      [
                        {
                          id: 'jump' as LandingFloatingBtnAnimation,
                          title: '১. জাম্প বাউন্স (Default)',
                          desc: 'আগের ডিফল্ট স্মুথ জাম্প ও শ্যাডো পালস'
                        },
                        {
                          id: 'login_shine' as LandingFloatingBtnAnimation,
                          title: '২. লগইন বাটন শাইন (Login Style)',
                          desc: 'লগইন বাটনের মতো গ্লাস লাইট সুইপ ও গোল্ডেন গ্লো'
                        },
                        {
                          id: 'cart_beam' as LandingFloatingBtnAnimation,
                          title: '৩. কার্ট বর্ডার বিম (Cart Style)',
                          desc: 'কার্ট বাটনের মতো চারপাশের বর্ডারে ঘূর্ণায়মান লাইট বিম'
                        },
                        {
                          id: 'combo_beam' as LandingFloatingBtnAnimation,
                          title: '৪. প্রিমিয়াম কম্বো (বিম + শাইন + বাউন্স)',
                          desc: 'কার্ট বর্ডার বিম + লগইন শাইন + বাউন্স একসাথে'
                        },
                        {
                          id: 'glow_pulse' as LandingFloatingBtnAnimation,
                          title: '৫. রিং পালস গ্লো (Ring Ripple)',
                          desc: 'চারপাশে সফট লাল রিং পালস ও জুম ইফেক্ট'
                        },
                        {
                          id: 'none' as LandingFloatingBtnAnimation,
                          title: '৬. অ্যানিমেশন বন্ধ (Static)',
                          desc: 'কোনো চলমান অ্যানিমেশন ছাড়া সাধারণ বাটন'
                        }
                      ]
                    ).map(opt => {
                      const isSel = formFloatingBtnAnimation === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setFormFloatingBtnAnimation(opt.id)}
                          className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                            isSel
                              ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                              : 'bg-white text-slate-800 border-slate-200 hover:border-rose-400'
                          }`}
                        >
                          <div className="text-xs font-extrabold">{opt.title}</div>
                          <div
                            className={`text-[10px] mt-0.5 leading-snug ${
                              isSel ? 'text-rose-100' : 'text-slate-500'
                            }`}
                          >
                            {opt.desc}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Submit / Cancel Footer */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs cursor-pointer"
                >
                  {editingProduct ? 'Save Changes' : 'Create Landing Page'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================================================
          SEPARATE LANDING PAGE SPIN THE WHEEL CONTROL MODAL (Dashboard Global Control)
         ========================================================================== */}
      {showLandingSpinAdminModal && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in"
          onClick={() => setShowLandingSpinAdminModal(false)}
        >
          <div
            className="relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl bg-white text-slate-900 border border-slate-200 shadow-2xl overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-amber-50 via-white to-rose-50">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 font-bold">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                    ল্যান্ডিং পেজ স্পিন দ্য হুইল কন্ট্রোল প্যানেল (মেইন ওয়েবসাইট থেকে সম্পূর্ণ আলাদা)
                  </h3>
                  <p className="text-xs text-slate-500">
                    ল্যান্ডিং পেজের জন্য স্পিন হুইল ON/OFF, অফার স্লাইস, পপ-আপ সময় এবং কাস্টমার নাম্বার লিস্ট নিয়ন্ত্রণ করুন
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const next = !globalLandingSpinEnabled;
                    updateBusiness({ landingSpinWheelEnabled: next });
                    showToast(
                      next
                        ? 'ল্যান্ডিং পেজের স্পিন হুইল চালু (ON) করা হয়েছে'
                        : 'ল্যান্ডিং পেজের স্পিন হুইল বন্ধ (OFF) করা হয়েছে',
                      'info'
                    );
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer transition-colors ${
                    globalLandingSpinEnabled
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-200 text-slate-700 border-slate-300'
                  }`}
                >
                  {globalLandingSpinEnabled ? 'গ্লোবাল হুইল: চালু (ON)' : 'গ্লোবাল হুইল: বন্ধ (OFF)'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowLandingSpinAdminModal(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="px-5 pt-3 border-b border-slate-200 flex items-center justify-between gap-2 bg-slate-50/70">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setLandingSpinAdminTab('settings')}
                  className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-extrabold border-b-2 transition-colors cursor-pointer ${
                    landingSpinAdminTab === 'settings'
                      ? 'border-amber-600 text-amber-700 bg-white'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ⚙️ হুইল টেক্সট ও অফার সেটিংস
                </button>
                <button
                  type="button"
                  onClick={() => setLandingSpinAdminTab('leads')}
                  className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-extrabold border-b-2 transition-colors cursor-pointer ${
                    landingSpinAdminTab === 'leads'
                      ? 'border-amber-600 text-amber-700 bg-white'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  📋 ল্যান্ডিং পেজ স্পিন কাস্টমার লিস্ট ({storedLandingSpinLeads.length})
                </button>
              </div>
            </div>

            {landingSpinAdminTab === 'settings' ? (
              <div className="p-5 overflow-y-auto flex-1 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 bg-amber-50/50 border border-amber-200/80 rounded-2xl p-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      উপরের ব্যাজ টেক্সট (Badge Text):
                    </label>
                    <input
                      type="text"
                      value={landingSpinConfigDraft.badgeText}
                      onChange={e =>
                        setLandingSpinConfigDraft(prev => ({ ...prev, badgeText: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      প্রধান শিরোনাম (Main Title):
                    </label>
                    <input
                      type="text"
                      value={landingSpinConfigDraft.titleText}
                      onChange={e =>
                        setLandingSpinConfigDraft(prev => ({ ...prev, titleText: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      সাব-টাইটেল / বিবরণ (Subtitle Text):
                    </label>
                    <input
                      type="text"
                      value={landingSpinConfigDraft.subtitleText}
                      onChange={e =>
                        setLandingSpinConfigDraft(prev => ({ ...prev, subtitleText: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-semibold text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      ল্যান্ডিং পেজে ঢোকার কত সেকেন্ড পর অটো আসবে?
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={landingSpinConfigDraft.autoPopupDelaySec}
                      onChange={e =>
                        setLandingSpinConfigDraft(prev => ({
                          ...prev,
                          autoPopupDelaySec: Math.max(1, Number(e.target.value) || 4)
                        }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      একই কাস্টমারকে কত দিনে ১ বার দেখাবে?
                    </label>
                    <select
                      value={landingSpinConfigDraft.cooldownDays}
                      onChange={e =>
                        setLandingSpinConfigDraft(prev => ({
                          ...prev,
                          cooldownDays: Number(e.target.value) || 7
                        }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    >
                      <option value={1}>১ দিনে ১ বার (Daily Once)</option>
                      <option value={3}>৩ দিনে ১ বার</option>
                      <option value={7}>৭ দিনে ১ বার (Recommended)</option>
                      <option value={15}>১৫ দিনে ১ বার</option>
                      <option value={30}>৩০ দিনে ১ বার</option>
                    </select>
                  </div>
                </div>

                {/* Wheel Slices Editor */}
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-xs sm:text-sm font-extrabold text-slate-800">
                        🎡 ল্যান্ডিং পেজ স্পিন হুইলের স্লাইস / পুরস্কার সমূহ ({(landingSpinConfigDraft.slices || []).length} টি)
                      </h4>
                      <p className="text-[11px] text-slate-600 font-semibold mt-0.5">
                        🔓 আনলক ({(landingSpinConfigDraft.slices || []).filter(s => !s.locked).length}টি): কাস্টমার বারবার পাবে • 🔒 লক ({(landingSpinConfigDraft.slices || []).filter(s => s.locked).length}টি): চাকায় দেখাবে কিন্তু কেউ পাবে না
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setLandingSpinConfigDraft(prev => ({
                          ...prev,
                          slices: [
                            ...(prev.slices || []),
                            {
                              id: `lp_sw_${Date.now()}`,
                              shortLabel: '৳৫০ ছাড়',
                              label: '৳৫০ স্পেশাল ডিসকাউন্ট',
                              type: 'flat',
                              value: 50,
                              code: `LP${(prev.slices || []).length + 1}`,
                              color: '#059669',
                              locked: false
                            }
                          ]
                        }))
                      }
                      className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-extrabold cursor-pointer"
                    >
                      + নতুন অফার যোগ করুন
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {(landingSpinConfigDraft.slices || []).map((slice, idx) => (
                      <div
                        key={slice.id || idx}
                        className={`p-3 rounded-2xl border grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center ${
                          slice.locked
                            ? 'bg-rose-50/50 border-rose-200'
                            : 'bg-slate-50/70 border-slate-200'
                        }`}
                      >
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            চাকার লেখা (Short)
                          </label>
                          <input
                            type="text"
                            value={slice.shortLabel}
                            onChange={e => {
                              const val = e.target.value;
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, shortLabel: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            পূর্ণ অফার নাম
                          </label>
                          <input
                            type="text"
                            value={slice.label}
                            onChange={e => {
                              const val = e.target.value;
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, label: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            অফারের ধরন
                          </label>
                          <select
                            value={slice.type}
                            onChange={e => {
                              const val = e.target.value as SpinWheelSliceConfig['type'];
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, type: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-800"
                          >
                            <option value="flat">টাকা ছাড় (৳)</option>
                            <option value="percent">শতাংশ ছাড় (%)</option>
                            <option value="free_delivery">ফ্রি ডেলিভারি</option>
                          </select>
                        </div>
                        <div className="sm:col-span-1">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            মান
                          </label>
                          <input
                            type="number"
                            disabled={slice.type === 'free_delivery'}
                            value={slice.type === 'free_delivery' ? 0 : slice.value}
                            onChange={e => {
                              const val = Number(e.target.value) || 0;
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, value: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white disabled:bg-slate-100 text-xs font-bold text-slate-900"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            লক / আনলক স্ট্যাটাস
                          </label>
                          <button
                            type="button"
                            onClick={() =>
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, locked: !s.locked } : s
                                )
                              }))
                            }
                            className={`w-full px-2 py-1.5 rounded-lg text-[11px] font-extrabold border flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                              slice.locked
                                ? 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200'
                                : 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200'
                            }`}
                          >
                            <span>{slice.locked ? '🔒 লক (পাবে না)' : '🔓 আনলক (পাবে)'}</span>
                          </button>
                        </div>
                        <div className="sm:col-span-2 flex items-center justify-end gap-1.5 pt-3 sm:pt-4">
                          <input
                            type="text"
                            value={slice.code}
                            onChange={e => {
                              const val = e.target.value.toUpperCase();
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, code: val } : s
                                )
                              }));
                            }}
                            placeholder="CODE"
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono font-bold text-slate-900"
                          />
                          <input
                            type="color"
                            value={slice.color || '#059669'}
                            onChange={e => {
                              const val = e.target.value;
                              setLandingSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, color: val } : s
                                )
                              }));
                            }}
                            className="w-7 h-7 rounded cursor-pointer border border-slate-300 shrink-0"
                          />
                          {(landingSpinConfigDraft.slices || []).length > 2 && (
                            <button
                              type="button"
                              onClick={() =>
                                setLandingSpinConfigDraft(prev => ({
                                  ...prev,
                                  slices: (prev.slices || []).filter((_, i) => i !== idx)
                                }))
                              }
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setLandingSpinConfigDraft(DEFAULT_LANDING_SPIN_WHEEL_CONFIG)}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                  >
                    ডিফল্ট ৬টি পুরস্কার (৪ আনলক, ২ লক)
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveLandingSpinConfig}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-extrabold shadow-md cursor-pointer"
                  >
                    💾 সেটিংস সংরক্ষণ করুন
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <input
                    type="text"
                    value={landingSpinLeadSearch}
                    onChange={e => setLandingSpinLeadSearch(e.target.value)}
                    placeholder="নাম, মোবাইল নাম্বার বা কুপন দিয়ে খুঁজুন..."
                    className="flex-1 min-w-[200px] px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-extrabold">
                      মোট এন্ট্রি: {filteredLandingSpinLeads.length} জন
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (filteredLandingSpinLeads.length === 0) {
                          showToast('ডাউনলোড করার মতো কোনো ল্যান্ডিং পেজ স্পিন ডাটা নেই', 'error');
                          return;
                        }
                        exportToExcel(
                          'Landing_Page_Spin_Wheel_Leads',
                          'Landing_Spin_Leads',
                          ['ক্রমিক নং', 'কাস্টমারের নাম', 'মোবাইল নাম্বার', 'প্রাপ্ত পুরস্কার', 'কুপন কোড', 'তারিখ ও সময়'],
                          filteredLandingSpinLeads.map((l, idx) => [
                            idx + 1,
                            l.customerName || l.name || 'কাস্টমার',
                            l.customerPhone || l.phone || '',
                            l.rewardLabel || l.prizeLabel || '',
                            l.couponCode || l.prizeCode || '',
                            new Date(l.createdAt).toLocaleString('en-GB')
                          ])
                        );
                        showToast(
                          `ল্যান্ডিং পেজ স্পিন হুইলের ${filteredLandingSpinLeads.length} জন কাস্টমারের ডাটা Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>১-ক্লিক Excel ডাউনলোড</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (filteredLandingSpinLeads.length === 0) {
                          showToast('ডাউনলোড করার মতো কোনো ল্যান্ডিং পেজ স্পিন ডাটা নেই', 'error');
                          return;
                        }
                        exportToCsv(
                          'Landing_Page_Spin_Wheel_Google_Sheet',
                          ['SL', 'Customer_Name', 'Mobile_Number', 'Prize_Won', 'Coupon_Code', 'Created_At'],
                          filteredLandingSpinLeads.map((l, idx) => [
                            idx + 1,
                            l.customerName || l.name || 'কাস্টমার',
                            l.customerPhone || l.phone || '',
                            l.rewardLabel || l.prizeLabel || '',
                            l.couponCode || l.prizeCode || '',
                            new Date(l.createdAt).toLocaleString('en-GB')
                          ])
                        );
                        showToast(
                          `ল্যান্ডিং পেজ স্পিন হুইলের ${filteredLandingSpinLeads.length} জন কাস্টমারের ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড হয়েছে!`,
                          'success'
                        );
                      }}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Google Sheet (CSV)</span>
                    </button>
                  </div>
                </div>

                <div className="p-4 sm:p-5 overflow-y-auto flex-1">
                  {filteredLandingSpinLeads.length === 0 ? (
                    <div className="text-center py-12 space-y-2">
                      <Gift className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-sm font-bold text-slate-600">
                        এখনো কোনো ল্যান্ডিং পেজ ভিজিটর স্পিন করেননি
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-2xl border border-slate-200">
                      <table className="w-full text-left border-collapse text-xs sm:text-sm">
                        <thead>
                          <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                            <th className="py-3 px-3.5">কাস্টমারের নাম</th>
                            <th className="py-3 px-3.5">মোবাইল নাম্বার</th>
                            <th className="py-3 px-3.5">জেতা অফার / পুরস্কার</th>
                            <th className="py-3 px-3.5">কুপন</th>
                            <th className="py-3 px-3.5">তারিখ ও সময়</th>
                            <th className="py-3 px-3.5 text-right">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 bg-white">
                          {filteredLandingSpinLeads.map(lead => {
                            const dispName = lead.customerName || lead.name || 'কাস্টমার';
                            const dispPhone = lead.customerPhone || lead.phone || '';
                            const dispReward = lead.rewardLabel || lead.prizeLabel || '';
                            const dispCode = lead.couponCode || lead.prizeCode || '';
                            return (
                              <tr key={lead.id} className="hover:bg-slate-50/80 transition-colors">
                                <td className="py-3 px-3.5 font-bold text-slate-900">
                                  {dispName}
                                </td>
                                <td className="py-3 px-3.5">
                                  <div className="inline-flex items-center gap-1.5 font-mono font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                                    <span>{dispPhone}</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        navigator.clipboard?.writeText(dispPhone);
                                        showToast('মোবাইল নাম্বার কপি হয়েছে!', 'info');
                                      }}
                                      className="text-indigo-500 hover:text-indigo-800 cursor-pointer"
                                    >
                                      <Copy className="w-3 h-3" />
                                    </button>
                                  </div>
                                </td>
                                <td className="py-3 px-3.5">
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-extrabold">
                                    🎁 {dispReward}
                                  </span>
                                </td>
                                <td className="py-3 px-3.5 font-mono font-bold text-amber-700">
                                  {dispCode}
                                </td>
                                <td className="py-3 px-3.5 text-xs text-slate-500">
                                  {new Date(lead.createdAt).toLocaleString('bn-BD', {
                                    dateStyle: 'medium',
                                    timeStyle: 'short'
                                  })}
                                </td>
                                <td className="py-3 px-3.5 text-right">
                                  <div className="inline-flex items-center gap-1.5">
                                    <a
                                      href={`tel:${dispPhone}`}
                                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
                                    >
                                      কল
                                    </a>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteLandingSpinLead(lead.id)}
                                      className="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold cursor-pointer"
                                    >
                                      মুছুন
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
