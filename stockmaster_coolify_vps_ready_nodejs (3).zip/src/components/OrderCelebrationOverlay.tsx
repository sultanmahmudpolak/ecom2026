import React, { useEffect, useRef } from 'react';
import { OrderCelebrationStyle } from '../types';

interface OrderCelebrationOverlayProps {
  active: boolean;
  seed: number;
  styleMode?: OrderCelebrationStyle;
  showCenterBadge?: boolean;
  orderNo?: string;
}

interface CanvasParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  gravity: number;
  drag: number;
  color: string;
  secondaryColor?: string;
  size: number;
  shape: 'ribbon' | 'circle' | 'star' | 'heart' | 'diamond' | 'spark' | 'balloon' | 'crescent' | 'lantern';
  tilt: number;
  tiltSpeed: number;
  rotation: number;
  rotationSpeed: number;
  alpha: number;
  decay: number;
  delayFrames: number;
  wobble: number;
  wobbleSpeed: number;
  trail?: Array<{ x: number; y: number }>;
}

interface ShockwaveRing {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
  delayFrames: number;
}

const drawFourPointStar = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  rotation: number
) => {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation);
  ctx.beginPath();
  const inner = radius * 0.32;
  for (let i = 0; i < 8; i++) {
    const r = i % 2 === 0 ? radius : inner;
    const angle = (i * Math.PI) / 4;
    const px = Math.cos(angle) * r;
    const py = Math.sin(angle) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();
};

const drawHeartShape = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  rotation: number
) => {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation);
  const s = size * 0.65;
  ctx.beginPath();
  ctx.moveTo(0, s * 0.35);
  ctx.bezierCurveTo(-s, -s * 0.45, -s * 1.15, s * 0.6, 0, s * 1.35);
  ctx.bezierCurveTo(s * 1.15, s * 0.6, s, -s * 0.45, 0, s * 0.35);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
};

const drawBalloonShape = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  rotation: number
) => {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation * 0.25);

  // String tail
  ctx.beginPath();
  ctx.moveTo(0, size * 1.15);
  ctx.quadraticCurveTo(size * 0.25, size * 1.6, -size * 0.15, size * 2.1);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
  ctx.lineWidth = 1.3;
  ctx.stroke();

  // Balloon body
  ctx.beginPath();
  ctx.ellipse(0, 0, size * 0.85, size * 1.08, 0, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();

  // Knot at bottom
  ctx.beginPath();
  ctx.moveTo(-2.5, size * 1.08);
  ctx.lineTo(2.5, size * 1.08);
  ctx.lineTo(0, size * 1.18);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();

  // Glossy 3D highlight
  ctx.beginPath();
  ctx.ellipse(-size * 0.3, -size * 0.32, size * 0.18, size * 0.34, -0.35, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.48)';
  ctx.fill();

  ctx.restore();
};

const drawCrescentMoon = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  rotation: number
) => {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation);
  ctx.shadowColor = color;
  ctx.shadowBlur = 12;
  ctx.fillStyle = color;

  ctx.beginPath();
  ctx.arc(0, 0, size, 0.25 * Math.PI, 1.75 * Math.PI, false);
  ctx.arc(size * 0.38, -size * 0.12, size * 0.82, 1.68 * Math.PI, 0.32 * Math.PI, true);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
};

const drawFanoosLantern = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  rotation: number
) => {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rotation * 0.22);

  // Outer warm aura
  ctx.shadowColor = '#FBBF24';
  ctx.shadowBlur = 14;

  // Hanging top ring
  ctx.beginPath();
  ctx.arc(0, -size * 1.15, size * 0.2, 0, Math.PI * 2);
  ctx.strokeStyle = '#FDE047';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Dome cap
  ctx.beginPath();
  ctx.moveTo(-size * 0.55, -size * 0.55);
  ctx.quadraticCurveTo(0, -size * 1.05, size * 0.55, -size * 0.55);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();

  // Hexagonal lantern glass body
  ctx.beginPath();
  ctx.moveTo(-size * 0.52, -size * 0.52);
  ctx.lineTo(size * 0.52, -size * 0.52);
  ctx.lineTo(size * 0.68, 0);
  ctx.lineTo(size * 0.42, size * 0.68);
  ctx.lineTo(-size * 0.42, size * 0.68);
  ctx.lineTo(-size * 0.68, 0);
  ctx.closePath();
  ctx.fillStyle = '#FEF08A';
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.8;
  ctx.stroke();

  // Inner glowing flame core
  ctx.beginPath();
  ctx.ellipse(0, 0, size * 0.28, size * 0.42, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();

  // Lantern pedestal base & tassel
  ctx.beginPath();
  ctx.moveTo(-size * 0.48, size * 0.68);
  ctx.lineTo(size * 0.48, size * 0.68);
  ctx.lineTo(size * 0.3, size * 0.94);
  ctx.lineTo(-size * 0.3, size * 0.94);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();

  ctx.restore();
};

export const OrderCelebrationOverlay: React.FC<OrderCelebrationOverlayProps> = ({
  active,
  seed,
  styleMode = 'dual_cannon_badge',
  showCenterBadge = true,
  orderNo
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let width = window.innerWidth;
    let height = window.innerHeight;

    const updateSize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    updateSize();
    window.addEventListener('resize', updateSize);

    const particles: CanvasParticle[] = [];
    const rings: ShockwaveRing[] = [];

    const festiveColors = [
      '#10B981', // Emerald
      '#F59E0B', // Gold Amber
      '#F43F5E', // Crimson Rose
      '#0EA5E9', // Sky Cyan
      '#8B5CF6', // Royal Violet
      '#FACC15', // Sunshine Gold
      '#EC4899', // Magenta Pink
      '#34D399'  // Mint
    ];

    const goldLuxuryColors = [
      '#FDE047', // 24K Bright Gold
      '#F59E0B', // Royal Amber Gold
      '#FEF08A', // Champagne Gold
      '#10B981', // Rich Emerald
      '#34D399', // Emerald Glow
      '#FFFFFF', // Diamond White
      '#D97706'  // Bronze Gold
    ];

    // -------------------------------------------------------------------------
    // STYLE 1: DUAL SIDE PARTY CANNONS + CENTER POP (DEFAULT & MOST POPULAR)
    // -------------------------------------------------------------------------
    if (styleMode === 'dual_cannon_badge') {
      // Left & Right Bottom/Mid-Side Party Cannons blasting inward + upward
      const cannonCount = 65;
      for (let side = 0; side < 2; side++) {
        const startX = side === 0 ? width * 0.03 : width * 0.97;
        const startY = height * 0.78;
        for (let i = 0; i < cannonCount; i++) {
          const baseAngle = side === 0 ? -Math.PI * 0.34 : -Math.PI * 0.66;
          const spread = (Math.random() - 0.5) * 0.58;
          const angle = baseAngle + spread;
          const speed = 13 + Math.random() * 19;
          const shapeRoll = i % 9;
          const shape: CanvasParticle['shape'] =
            shapeRoll === 0 ? 'star' : shapeRoll === 3 ? 'circle' : shapeRoll === 6 ? 'diamond' : 'ribbon';

          particles.push({
            x: startX,
            y: startY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed - (2 + Math.random() * 4),
            gravity: 0.32 + Math.random() * 0.12,
            drag: 0.966,
            color: festiveColors[i % festiveColors.length],
            size: shape === 'star' ? 9 + Math.random() * 5 : 8 + Math.random() * 6,
            shape,
            tilt: Math.random() * Math.PI * 2,
            tiltSpeed: 0.14 + Math.random() * 0.18,
            rotation: Math.random() * Math.PI * 2,
            rotationSpeed: (Math.random() - 0.5) * 0.16,
            alpha: 1,
            decay: 0.0075 + Math.random() * 0.005,
            delayFrames: Math.floor(Math.random() * 8),
            wobble: Math.random() * 10,
            wobbleSpeed: 0.08 + Math.random() * 0.07
          });
        }
      }

      // Secondary Center Starlight Pop around the Badge
      const centerX = width * 0.5;
      const centerY = height * 0.42;
      rings.push(
        { x: centerX, y: centerY, radius: 10, maxRadius: 210, color: '#10B981', alpha: 0.75, delayFrames: 2 },
        { x: centerX, y: centerY, radius: 6, maxRadius: 160, color: '#FACC15', alpha: 0.85, delayFrames: 8 }
      );
      for (let i = 0; i < 42; i++) {
        const angle = (i / 42) * Math.PI * 2 + (Math.random() - 0.5) * 0.15;
        const speed = 5 + Math.random() * 11;
        particles.push({
          x: centerX,
          y: centerY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 2,
          gravity: 0.18,
          drag: 0.955,
          color: festiveColors[i % festiveColors.length],
          size: i % 2 === 0 ? 10 : 7,
          shape: i % 2 === 0 ? 'star' : 'ribbon',
          tilt: Math.random() * Math.PI,
          tiltSpeed: 0.2,
          rotation: Math.random() * Math.PI,
          rotationSpeed: 0.1,
          alpha: 1,
          decay: 0.011 + Math.random() * 0.006,
          delayFrames: 4,
          wobble: Math.random() * 6,
          wobbleSpeed: 0.09
        });
      }
    }

    // -------------------------------------------------------------------------
    // STYLE 2: ROYAL FIREWORKS & GOLDEN STARLIGHT
    // -------------------------------------------------------------------------
    else if (styleMode === 'royal_fireworks') {
      const burstPoints = [
        { x: width * 0.5, y: height * 0.32, delay: 0, color: '#FACC15' },
        { x: width * 0.24, y: height * 0.36, delay: 10, color: '#F43F5E' },
        { x: width * 0.76, y: height * 0.34, delay: 16, color: '#10B981' },
        { x: width * 0.36, y: height * 0.24, delay: 24, color: '#38BDF8' },
        { x: width * 0.65, y: height * 0.26, delay: 30, color: '#EC4899' }
      ];

      burstPoints.forEach((bp, bIdx) => {
        rings.push({
          x: bp.x,
          y: bp.y,
          radius: 4,
          maxRadius: 170 + (bIdx % 2) * 35,
          color: bp.color,
          alpha: 0.9,
          delayFrames: bp.delay
        });

        const sparksPerBurst = 44;
        for (let i = 0; i < sparksPerBurst; i++) {
          const angle = (i / sparksPerBurst) * Math.PI * 2 + (Math.random() - 0.5) * 0.08;
          const speed = 4 + Math.random() * 9.5;
          const pColor = i % 3 === 0 ? '#FEF08A' : i % 2 === 0 ? bp.color : festiveColors[(i + bIdx) % festiveColors.length];
          particles.push({
            x: bp.x,
            y: bp.y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            gravity: 0.12,
            drag: 0.962,
            color: pColor,
            size: i % 4 === 0 ? 9 : 4.5 + Math.random() * 2.5,
            shape: i % 4 === 0 ? 'star' : 'spark',
            tilt: 0,
            tiltSpeed: 0.15,
            rotation: Math.random() * Math.PI,
            rotationSpeed: 0.12,
            alpha: 1,
            decay: 0.012 + Math.random() * 0.007,
            delayFrames: bp.delay,
            wobble: 0,
            wobbleSpeed: 0,
            trail: []
          });
        }
      });
    }

    // -------------------------------------------------------------------------
    // STYLE 3: LUXURY 24K GOLD & EMERALD FOUNTAIN
    // -------------------------------------------------------------------------
    else if (styleMode === 'luxury_gold_fountain') {
      const origins = [
        { x: width * 0.5, y: height * 0.85 },
        { x: width * 0.22, y: height * 0.88 },
        { x: width * 0.78, y: height * 0.88 }
      ];
      rings.push({
        x: width * 0.5,
        y: height * 0.42,
        radius: 12,
        maxRadius: 230,
        color: '#FBBF24',
        alpha: 0.85,
        delayFrames: 2
      });

      origins.forEach((orig, oIdx) => {
        const count = oIdx === 0 ? 75 : 42;
        for (let i = 0; i < count; i++) {
          const angle = -Math.PI * 0.5 + (Math.random() - 0.5) * 0.72;
          const speed = (oIdx === 0 ? 15 : 13) + Math.random() * 15;
          const shape: CanvasParticle['shape'] =
            i % 4 === 0 ? 'star' : i % 3 === 0 ? 'diamond' : 'ribbon';
          particles.push({
            x: orig.x + (Math.random() - 0.5) * 30,
            y: orig.y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            gravity: 0.29 + Math.random() * 0.1,
            drag: 0.972,
            color: goldLuxuryColors[i % goldLuxuryColors.length],
            size: shape === 'star' ? 10 + Math.random() * 5 : 8 + Math.random() * 6,
            shape,
            tilt: Math.random() * Math.PI * 2,
            tiltSpeed: 0.16 + Math.random() * 0.16,
            rotation: Math.random() * Math.PI * 2,
            rotationSpeed: (Math.random() - 0.5) * 0.14,
            alpha: 1,
            decay: 0.007 + Math.random() * 0.005,
            delayFrames: Math.floor(Math.random() * 12),
            wobble: Math.random() * 8,
            wobbleSpeed: 0.07 + Math.random() * 0.05
          });
        }
      });
    }

    // -------------------------------------------------------------------------
    // STYLE 5: RAMADAN NOOR LANTERNS, CRESCENT MOONS & EMERALD STARLIGHT
    // -------------------------------------------------------------------------
    else if (styleMode === 'ramadan_noor_lanterns') {
      const ramadanColors = [
        '#FDE047', // 24K Noor Gold
        '#F59E0B', // Warm Fanoos Amber
        '#10B981', // Islamic Emerald
        '#34D399', // Mint Noor Glow
        '#FEF08A', // Starlight Cream
        '#14B8A6'  // Royal Teal
      ];

      // 1. Glowing Arabian Fanoos Lanterns gently floating up across the screen
      for (let i = 0; i < 20; i++) {
        particles.push({
          x: width * (0.06 + (i / 20) * 0.88) + (Math.random() - 0.5) * 25,
          y: height + 10 + Math.random() * 80,
          vx: (Math.random() - 0.5) * 1.1,
          vy: -(5.8 + Math.random() * 4.5),
          gravity: -0.015, // Continues floating upward like glowing sky lanterns
          drag: 0.996,
          color: i % 2 === 0 ? '#F59E0B' : '#10B981',
          size: 13 + Math.random() * 6,
          shape: 'lantern',
          tilt: 0,
          tiltSpeed: 0.04,
          rotation: (Math.random() - 0.5) * 0.25,
          rotationSpeed: (Math.random() - 0.5) * 0.015,
          alpha: 0.98,
          decay: 0.006 + Math.random() * 0.003,
          delayFrames: Math.floor(Math.random() * 14),
          wobble: Math.random() * 10,
          wobbleSpeed: 0.05 + Math.random() * 0.04
        });
      }

      // 2. Center Golden & Emerald Noor Aura Shockwaves
      const centerX = width * 0.5;
      const centerY = height * 0.4;
      rings.push(
        { x: centerX, y: centerY, radius: 10, maxRadius: 230, color: '#FACC15', alpha: 0.85, delayFrames: 1 },
        { x: centerX, y: centerY, radius: 6, maxRadius: 175, color: '#10B981', alpha: 0.8, delayFrames: 9 }
      );

      // 3. Crescent Moons, 4-Point Noor Stars & Golden Sparkles bursting outward
      for (let i = 0; i < 88; i++) {
        const angle = (i / 88) * Math.PI * 2 + (Math.random() - 0.5) * 0.18;
        const speed = 5.5 + Math.random() * 13.5;
        const shape: CanvasParticle['shape'] =
          i % 5 === 0 ? 'crescent' : i % 2 === 0 ? 'star' : i % 3 === 0 ? 'diamond' : 'ribbon';
        particles.push({
          x: centerX + (Math.random() - 0.5) * 40,
          y: centerY + (Math.random() - 0.5) * 30,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 2.8,
          gravity: 0.2,
          drag: 0.965,
          color: shape === 'crescent' ? '#FDE047' : ramadanColors[i % ramadanColors.length],
          size: shape === 'crescent' ? 12 + Math.random() * 5 : shape === 'star' ? 9 + Math.random() * 5 : 7 + Math.random() * 4,
          shape,
          tilt: Math.random() * Math.PI * 2,
          tiltSpeed: 0.14 + Math.random() * 0.12,
          rotation: (Math.random() - 0.5) * 0.6,
          rotationSpeed: (Math.random() - 0.5) * 0.08,
          alpha: 1,
          decay: 0.0075 + Math.random() * 0.0045,
          delayFrames: Math.floor(Math.random() * 8),
          wobble: Math.random() * 8,
          wobbleSpeed: 0.07
        });
      }
    }

    // -------------------------------------------------------------------------
    // STYLE 6: EID MUBARAK ROYAL FIREWORKS, CRESCENT MOONS & FESTIVE CANNONS
    // -------------------------------------------------------------------------
    else if (styleMode === 'eid_mubarak_royal') {
      const eidRoyalColors = [
        '#FDE047', // Eid Gold
        '#EC4899', // Festive Rose Magenta
        '#8B5CF6', // Royal Violet
        '#10B981', // Emerald Joy
        '#F59E0B', // Amber Gold
        '#38BDF8', // Sky Turquoise
        '#F43F5E'  // Ruby Red
      ];

      // 1. Multi-Burst Eid Sky Fireworks with Crescent Moons & Luminous Sparks
      const eidBursts = [
        { x: width * 0.5, y: height * 0.28, delay: 0, color: '#FDE047' },
        { x: width * 0.22, y: height * 0.34, delay: 8, color: '#EC4899' },
        { x: width * 0.78, y: height * 0.32, delay: 14, color: '#10B981' },
        { x: width * 0.35, y: height * 0.22, delay: 22, color: '#8B5CF6' },
        { x: width * 0.66, y: height * 0.24, delay: 28, color: '#F59E0B' }
      ];

      eidBursts.forEach((bp, bIdx) => {
        rings.push({
          x: bp.x,
          y: bp.y,
          radius: 5,
          maxRadius: 180 + (bIdx % 2) * 35,
          color: bp.color,
          alpha: 0.92,
          delayFrames: bp.delay
        });

        const count = 32;
        for (let i = 0; i < count; i++) {
          const angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.1;
          const speed = 4.5 + Math.random() * 10;
          const shape: CanvasParticle['shape'] =
            i % 7 === 0 ? 'crescent' : i % 3 === 0 ? 'star' : 'spark';
          particles.push({
            x: bp.x,
            y: bp.y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            gravity: 0.13,
            drag: 0.962,
            color: shape === 'crescent' ? '#FDE047' : eidRoyalColors[(i + bIdx) % eidRoyalColors.length],
            size: shape === 'crescent' ? 11 + Math.random() * 4 : shape === 'star' ? 9 : 4.5 + Math.random() * 2.5,
            shape,
            tilt: 0,
            tiltSpeed: 0.14,
            rotation: (Math.random() - 0.5) * 0.6,
            rotationSpeed: (Math.random() - 0.5) * 0.08,
            alpha: 1,
            decay: 0.011 + Math.random() * 0.006,
            delayFrames: bp.delay,
            wobble: 0,
            wobbleSpeed: 0,
            trail: shape === 'spark' ? [] : undefined
          });
        }
      });

      // 2. Dual Side Eid Celebration Cannons with Lanterns, Crescents & Ribbons
      for (let side = 0; side < 2; side++) {
        const startX = side === 0 ? width * 0.04 : width * 0.96;
        const startY = height * 0.8;
        for (let i = 0; i < 40; i++) {
          const baseAngle = side === 0 ? -Math.PI * 0.35 : -Math.PI * 0.65;
          const angle = baseAngle + (Math.random() - 0.5) * 0.55;
          const speed = 13 + Math.random() * 17;
          const shape: CanvasParticle['shape'] =
            i % 8 === 0 ? 'lantern' : i % 6 === 0 ? 'crescent' : i % 3 === 0 ? 'star' : 'ribbon';
          particles.push({
            x: startX,
            y: startY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed - 3,
            gravity: 0.3,
            drag: 0.968,
            color: eidRoyalColors[i % eidRoyalColors.length],
            size: shape === 'lantern' ? 12 : shape === 'crescent' ? 11 : 8 + Math.random() * 5,
            shape,
            tilt: Math.random() * Math.PI * 2,
            tiltSpeed: 0.15,
            rotation: (Math.random() - 0.5) * 0.5,
            rotationSpeed: (Math.random() - 0.5) * 0.1,
            alpha: 1,
            decay: 0.0075 + Math.random() * 0.004,
            delayFrames: Math.floor(Math.random() * 10),
            wobble: Math.random() * 8,
            wobbleSpeed: 0.08
          });
        }
      }
    }

    // -------------------------------------------------------------------------
    // STYLE 4: FESTIVE BALLOONS, HEARTS & STAR SHOWER
    // -------------------------------------------------------------------------
    else {
      // Rising glossy 3D balloons across the screen
      for (let i = 0; i < 24; i++) {
        particles.push({
          x: width * (0.08 + (i / 24) * 0.84) + (Math.random() - 0.5) * 30,
          y: height + 20 + Math.random() * 90,
          vx: (Math.random() - 0.5) * 1.4,
          vy: -(6.5 + Math.random() * 5.2),
          gravity: -0.02, // Continues floating up
          drag: 0.995,
          color: festiveColors[i % festiveColors.length],
          size: 15 + Math.random() * 7,
          shape: 'balloon',
          tilt: 0,
          tiltSpeed: 0.05,
          rotation: (Math.random() - 0.5) * 0.3,
          rotationSpeed: (Math.random() - 0.5) * 0.02,
          alpha: 0.96,
          decay: 0.0065 + Math.random() * 0.004,
          delayFrames: Math.floor(Math.random() * 14),
          wobble: Math.random() * 10,
          wobbleSpeed: 0.06 + Math.random() * 0.04
        });
      }

      // Festive Hearts, Stars & Confetti bursting from Center
      for (let i = 0; i < 95; i++) {
        const angle = (i / 95) * Math.PI * 2 + (Math.random() - 0.5) * 0.2;
        const speed = 6 + Math.random() * 14;
        const shape: CanvasParticle['shape'] =
          i % 3 === 0 ? 'heart' : i % 4 === 0 ? 'star' : 'ribbon';
        particles.push({
          x: width * 0.5 + (Math.random() - 0.5) * 60,
          y: height * 0.42 + (Math.random() - 0.5) * 40,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 3.5,
          gravity: 0.24,
          drag: 0.964,
          color: festiveColors[i % festiveColors.length],
          size: shape === 'heart' ? 11 + Math.random() * 5 : 9 + Math.random() * 5,
          shape,
          tilt: Math.random() * Math.PI * 2,
          tiltSpeed: 0.15 + Math.random() * 0.14,
          rotation: Math.random() * Math.PI * 2,
          rotationSpeed: (Math.random() - 0.5) * 0.12,
          alpha: 1,
          decay: 0.008 + Math.random() * 0.005,
          delayFrames: Math.floor(Math.random() * 8),
          wobble: Math.random() * 8,
          wobbleSpeed: 0.08
        });
      }
    }

    let frameId = 0;
    let frameCount = 0;

    const renderFrame = () => {
      frameCount++;
      ctx.clearRect(0, 0, width, height);

      // 1. Render Shockwave Rings
      for (let rIdx = 0; rIdx < rings.length; rIdx++) {
        const ring = rings[rIdx];
        if (frameCount < ring.delayFrames || ring.alpha <= 0.01) continue;
        ring.radius += (ring.maxRadius - ring.radius) * 0.11;
        ring.alpha *= 0.92;

        ctx.save();
        ctx.beginPath();
        ctx.arc(ring.x, ring.y, ring.radius, 0, Math.PI * 2);
        ctx.strokeStyle = ring.color;
        ctx.globalAlpha = Math.max(0, ring.alpha);
        ctx.lineWidth = 3.5 * ring.alpha;
        ctx.shadowColor = ring.color;
        ctx.shadowBlur = 14;
        ctx.stroke();
        ctx.restore();
      }

      // 2. Render Physics Particles
      let aliveCount = 0;
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        if (frameCount < p.delayFrames) {
          aliveCount++;
          continue;
        }
        if (p.alpha <= 0.02) continue;
        aliveCount++;

        if (p.trail) {
          p.trail.push({ x: p.x, y: p.y });
          if (p.trail.length > 5) p.trail.shift();
        }

        p.vx *= p.drag;
        p.vy = p.vy * p.drag + p.gravity;
        p.wobble += p.wobbleSpeed;
        p.x += p.vx + Math.sin(p.wobble) * 0.9;
        p.y += p.vy;
        p.tilt += p.tiltSpeed;
        p.rotation += p.rotationSpeed;

        // Smooth fade out in the second half of the animation
        if (frameCount > p.delayFrames + 42) {
          p.alpha -= p.decay * 1.45;
        } else {
          p.alpha -= p.decay * 0.35;
        }

        const clampedAlpha = Math.max(0, Math.min(1, p.alpha));
        ctx.save();
        ctx.globalAlpha = clampedAlpha;
        ctx.fillStyle = p.color;

        if (p.shape === 'spark' && p.trail && p.trail.length > 1) {
          // Luminous firework spark with glowing tail
          ctx.beginPath();
          ctx.moveTo(p.trail[0].x, p.trail[0].y);
          for (let t = 1; t < p.trail.length; t++) {
            ctx.lineTo(p.trail[t].x, p.trail[t].y);
          }
          ctx.lineTo(p.x, p.y);
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.size * 0.65;
          ctx.lineCap = 'round';
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 10;
          ctx.stroke();

          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.55, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === 'star') {
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 8;
          drawFourPointStar(ctx, p.x, p.y, p.size, p.rotation);
        } else if (p.shape === 'crescent') {
          drawCrescentMoon(ctx, p.x, p.y, p.size, p.color, p.rotation);
        } else if (p.shape === 'lantern') {
          drawFanoosLantern(ctx, p.x, p.y, p.size, p.color, p.rotation);
        } else if (p.shape === 'heart') {
          drawHeartShape(ctx, p.x, p.y, p.size, p.rotation);
        } else if (p.shape === 'balloon') {
          drawBalloonShape(ctx, p.x, p.y, p.size, p.color, p.rotation);
        } else if (p.shape === 'circle') {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.55, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === 'diamond') {
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          const scaleX = Math.cos(p.tilt);
          ctx.scale(scaleX, 1);
          ctx.beginPath();
          ctx.moveTo(0, -p.size * 0.8);
          ctx.lineTo(p.size * 0.55, 0);
          ctx.lineTo(0, p.size * 0.8);
          ctx.lineTo(-p.size * 0.55, 0);
          ctx.closePath();
          ctx.fill();
        } else {
          // 3D Fluttering Metallic Ribbon
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          const flipScale = Math.cos(p.tilt);
          ctx.scale(flipScale, 1);
          ctx.fillRect(-p.size * 0.5, -p.size * 0.85, p.size, p.size * 1.7);
        }

        ctx.restore();
      }

      if (aliveCount > 0 && frameCount < 165) {
        frameId = window.requestAnimationFrame(renderFrame);
      }
    };

    frameId = window.requestAnimationFrame(renderFrame);

    return () => {
      window.cancelAnimationFrame(frameId);
      window.removeEventListener('resize', updateSize);
    };
  }, [active, seed, styleMode]);

  if (!active) return null;

  const isRamadanStyle = styleMode === 'ramadan_noor_lanterns';
  const isEidStyle = styleMode === 'eid_mubarak_royal';

  return (
    <div
      key={`celebration_overlay_${seed}_${styleMode}`}
      className="fixed inset-0 z-[130] pointer-events-none overflow-hidden flex items-center justify-center"
      aria-hidden="true"
    >
      {/* 60fps High-DPI Physics Celebration Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Center Luxury Floating Celebration Badge (Auto-Pops & Dissolves in ~2.2s) */}
      {showCenterBadge && (
        <div className="relative z-10 px-4 animate-order-celebration-badge-pop">
          <div
            className={`relative backdrop-blur-md text-white px-6 py-4 sm:px-8 sm:py-5 rounded-3xl border-2 flex flex-col items-center text-center gap-2 max-w-xs sm:max-w-sm mx-auto ${
              isRamadanStyle
                ? 'bg-emerald-950/92 border-amber-300/90 shadow-[0_20px_65px_rgba(16,185,129,0.55),0_0_45px_rgba(250,204,21,0.45)]'
                : isEidStyle
                  ? 'bg-purple-950/92 border-amber-300/90 shadow-[0_20px_65px_rgba(236,72,153,0.5),0_0_45px_rgba(250,204,21,0.45)]'
                  : 'bg-slate-950/90 border-amber-400/80 shadow-[0_20px_60px_rgba(16,185,129,0.45),0_0_40px_rgba(250,204,21,0.35)]'
            }`}
          >
            {/* Golden & Emerald/Royal Glowing Aura Ring */}
            <div className="relative flex items-center justify-center">
              <span
                className={`absolute w-16 h-16 rounded-full animate-ping ${
                  isEidStyle ? 'bg-pink-500/35' : 'bg-emerald-500/35'
                }`}
              />
              <div
                className={`relative w-14 h-14 rounded-2xl p-0.5 shadow-lg flex items-center justify-center ${
                  isRamadanStyle
                    ? 'bg-gradient-to-br from-amber-300 via-amber-500 to-emerald-600 shadow-amber-500/40'
                    : isEidStyle
                      ? 'bg-gradient-to-br from-amber-300 via-pink-500 to-purple-700 shadow-pink-500/40'
                      : 'bg-gradient-to-br from-amber-400 via-emerald-500 to-emerald-700 shadow-emerald-500/40'
                }`}
              >
                <div className="w-full h-full rounded-[14px] bg-slate-950/25 flex items-center justify-center">
                  <svg
                    className="w-8 h-8 text-white drop-shadow"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M20 6 9 17l-5-5" className="animate-order-check-draw" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="space-y-0.5">
              <div className="inline-flex items-center gap-1.5 text-amber-300 text-xs sm:text-sm font-extrabold tracking-wide">
                <span>{isRamadanStyle ? '🌙' : isEidStyle ? '🕌' : '🎉'}</span>
                <span>
                  {isRamadanStyle
                    ? 'আলহামদুলিল্লাহ! অর্ডার সফল হয়েছে'
                    : isEidStyle
                      ? 'ঈদ মোবারক! অর্ডার সফল হয়েছে'
                      : 'অভিনন্দন! অর্ডার সফল হয়েছে'}
                </span>
                <span>{isRamadanStyle ? '🏮' : isEidStyle ? '✨' : '✨'}</span>
              </div>
              <p className="text-sm sm:text-base font-extrabold text-white leading-snug">
                {isRamadanStyle
                  ? 'মাহে রমজানের বরকতময় শুভেচ্ছা ও ধন্যবাদ!'
                  : isEidStyle
                    ? 'ঈদের খুশি ছড়িয়ে পড়ুক! আপনার অর্ডার গৃহীত হয়েছে'
                    : 'আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে!'}
              </p>
              {orderNo && (
                <p className="text-[11px] sm:text-xs font-mono font-bold text-emerald-300 pt-0.5">
                  অর্ডার নম্বর: #{orderNo}
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
