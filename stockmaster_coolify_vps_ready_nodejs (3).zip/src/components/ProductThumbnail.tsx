import React, { useState, useEffect, useRef } from 'react';
import { Product } from '../types';
import { processUploadedProductImage, getProductImageUrl } from '../utils/imageUploader';

export { processUploadedProductImage, getProductImageUrl };

interface ProductThumbnailProps {
  product: Product;
  className?: string;
  imgClassName?: string;
  eager?: boolean;
}

/**
 * Renders the product's uploaded photo (Base64 or URL) with IntersectionObserver lazy loading,
 * automatic 440x440 WebP thumbnail selection for grids/lists (and 1080x1080 HD WebP when eager=true
 * on Product Details / Zoom), shimmer skeleton placeholder while decoding, and Zero-Broken-Image fallback artwork.
 */
export const ProductThumbnail: React.FC<ProductThumbnailProps> = ({
  product,
  className = 'w-full h-full',
  imgClassName = 'p-2.5',
  eager = false
}) => {
  const isDataUri = Boolean(product.image && product.image.trim().startsWith('data:'));
  const containerRef = useRef<HTMLDivElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [imgError, setImgError] = useState(false);
  const [fallbackToHd, setFallbackToHd] = useState(false);
  const [isLoaded, setIsLoaded] = useState<boolean>(() => isDataUri || eager);
  const [isInView, setIsInView] = useState<boolean>(() => {
    if (eager || isDataUri) return true;
    if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') {
      return true;
    }
    return false;
  });

  const resolvedSrc = product.image
    ? getProductImageUrl(product.image, eager || fallbackToHd)
    : '';

  useEffect(() => {
    setImgError(false);
    setFallbackToHd(false);
    if (isDataUri || eager) {
      setIsLoaded(true);
      setIsInView(true);
    } else if (imgRef.current && imgRef.current.complete && imgRef.current.naturalWidth > 0) {
      setIsLoaded(true);
    } else {
      setIsLoaded(false);
    }
  }, [product.id, product.image, isDataUri, eager]);

  useEffect(() => {
    if (isInView || eager || isDataUri) return;
    const node = containerRef.current;
    if (!node || typeof IntersectionObserver === 'undefined') {
      setIsInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      entries => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            setIsInView(true);
            observer.disconnect();
            break;
          }
        }
      },
      {
        root: null,
        rootMargin: '250px 0px',
        threshold: 0.01
      }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [isInView, eager, isDataUri, product.id, product.image]);

  if (resolvedSrc && !imgError) {
    return (
      <div
        ref={containerRef}
        className={`${className} bg-white flex items-center justify-center overflow-hidden relative`}
      >
        {!isLoaded && (
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-r from-slate-100 via-slate-200/70 to-slate-100 animate-pulse"
          />
        )}
        {isInView && (
          <img
            ref={imgRef}
            key={`${product.id}_${resolvedSrc.slice(-48)}`}
            src={resolvedSrc}
            alt={product.nameBn}
            loading={eager || isDataUri ? 'eager' : 'lazy'}
            fetchPriority={eager ? 'high' : 'low'}
            decoding="async"
            referrerPolicy="no-referrer"
            onLoad={() => setIsLoaded(true)}
            onError={() => {
              if (!fallbackToHd && product.image && resolvedSrc !== product.image.trim()) {
                setFallbackToHd(true);
              } else {
                setImgError(true);
              }
            }}
            className={`w-full h-full object-contain ${imgClassName} transition-all duration-300 group-hover:scale-105 ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />
        )}
      </div>
    );
  }

  const cat = product.categoryId;
  const sku = (product.sku || '').toUpperCase();
  const nameLower = `${product.nameBn} ${product.nameEn}`.toLowerCase();

  // Baby Girls Party Frock / Baby Dress
  if (
    sku.includes('BABY-DRESS') ||
    nameLower.includes('ফ্রক') ||
    nameLower.includes('frock') ||
    (nameLower.includes('বেবি গার্লস') || nameLower.includes('baby girls'))
  ) {
    const isCoral = sku.includes('02') || sku.includes('05');
    const dressTop = isCoral ? '#EC4899' : '#DB2777';
    const dressSkirt = isCoral ? '#F472B6' : '#F43F5E';
    return (
      <div className={`${className} bg-gradient-to-b from-[#FDF2F8] to-[#FCE7F3]/60 flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="145" rx="46" ry="6" fill="#BE185D" opacity="0.14" />
          {/* Puff Sleeves */}
          <circle cx="52" cy="44" r="12" fill="#FBCFE8" stroke={dressTop} strokeWidth="2" />
          <circle cx="108" cy="44" r="12" fill="#FBCFE8" stroke={dressTop} strokeWidth="2" />
          {/* Bodice */}
          <path d="M56 32 L104 32 L98 68 L62 68 Z" fill={dressTop} />
          {/* Flared Party Skirt */}
          <path d="M60 66 L100 66 L126 132 L34 132 Z" fill={dressSkirt} />
          <path d="M34 132 Q80 140 126 132" stroke="#FDE047" strokeWidth="4" fill="none" />
          {/* Golden Waist Ribbon & Bow */}
          <rect x="60" y="63" width="40" height="7" rx="3" fill="#FDE047" />
          <circle cx="80" cy="66.5" r="5" fill="#F59E0B" />
          {/* Sparkle Dots */}
          <circle cx="64" cy="96" r="2.5" fill="#FFFBEB" />
          <circle cx="96" cy="94" r="2.5" fill="#FFFBEB" />
          <circle cx="80" cy="108" r="3" fill="#FFFBEB" />
          <rect x="48" y="114" width="64" height="15" rx="4" fill="#FFFFFF" opacity="0.92" />
          <text x="80" y="124.5" textAnchor="middle" fill="#9D174D" fontSize="8" fontWeight="800">
            BABY PARTY DRESS
          </text>
        </svg>
      </div>
    );
  }

  // Baby Boys / Kids Combo Set & Romper
  if (
    sku.includes('BABY-BOYS') ||
    sku.includes('BABY-ROMPER') ||
    sku.includes('BABY-PANJABI') ||
    nameLower.includes('বেবি বয়েজ') ||
    nameLower.includes('কিডস')
  ) {
    const topColor = sku.includes('PANJABI') ? '#047857' : '#0284C7';
    return (
      <div className={`${className} bg-gradient-to-b from-[#F0F9FF] to-[#E0F2FE]/60 flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="145" rx="42" ry="6" fill={topColor} opacity="0.14" />
          {/* Kids Top */}
          <path d="M52 28 L32 50 L42 60 L54 48 L54 90 L106 90 L106 48 L118 60 L128 50 L108 28 Z" fill={topColor} />
          <circle cx="80" cy="58" r="10" fill="#FDE047" />
          {/* Kids Shorts / Bottom */}
          <path d="M56 90 L104 90 L108 132 L84 132 L80 108 L76 132 L52 132 Z" fill="#1E293B" />
          <rect x="48" y="114" width="64" height="15" rx="4" fill="#FFFFFF" opacity="0.94" />
          <text x="80" y="124.5" textAnchor="middle" fill={topColor} fontSize="8" fontWeight="800">
            KIDS WEAR SET
          </text>
        </svg>
      </div>
    );
  }

  // Men's Panjabi & Kurta
  if (sku.includes('PANJABI') || nameLower.includes('পাঞ্জাবি') || nameLower.includes('panjabi')) {
    const isNavy = sku.includes('02') || nameLower.includes('navy') || nameLower.includes('নেভি');
    const mainColor = isNavy ? '#1E3A8A' : '#881337';
    const trimColor = '#D97706';
    return (
      <div className={`${className} bg-gradient-to-b from-[#FAF8F5] to-[#F3EDE2] flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="146" rx="42" ry="6" fill={mainColor} opacity="0.14" />
          <path d="M52 34 L24 72 L36 82 L54 54 Z" fill={mainColor} />
          <path d="M108 34 L136 72 L124 82 L106 54 Z" fill={mainColor} />
          <path d="M50 30 L110 30 L116 136 L44 136 Z" rx="6" fill={mainColor} />
          <rect x="66" y="22" width="28" height="10" rx="4" fill={trimColor} />
          <rect x="74" y="32" width="12" height="44" rx="3" fill="#FEF3C7" stroke={trimColor} strokeWidth="2" />
          <circle cx="80" cy="42" r="2" fill={mainColor} />
          <circle cx="80" cy="52" r="2" fill={mainColor} />
          <circle cx="80" cy="62" r="2" fill={mainColor} />
          <rect x="52" y="104" width="56" height="18" rx="4" fill="#FFFFFF" opacity="0.92" />
          <text x="80" y="116" textAnchor="middle" fill={mainColor} fontSize="8.5" fontWeight="800">
            ROYAL PANJABI
          </text>
        </svg>
      </div>
    );
  }

  // Category 2: Polo T-Shirt, Casual Shirt & Hoodies
  if (cat === 'cat_02' || sku.includes('POLO') || sku.includes('SHIRT') || nameLower.includes('শার্ট') || nameLower.includes('shirt')) {
    const isShirt = sku.includes('SHIRT') || nameLower.includes('চেক') || nameLower.includes('check');
    const shirtColor = isShirt ? '#0F766E' : '#1E293B';
    return (
      <div className={`${className} bg-gradient-to-b from-[#F8FAFC] to-[#EEF2F6] flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="144" rx="44" ry="6" fill={shirtColor} opacity="0.14" />
          {/* T-Shirt / Polo Silhouette */}
          <path
            d="M52 32 L30 56 L42 68 L54 54 L54 132 L106 132 L106 54 L118 68 L130 56 L108 32 Z"
            fill={shirtColor}
          />
          {/* Collar */}
          <path d="M64 30 L80 44 L96 30 L88 26 L72 26 Z" fill="#F59E0B" />
          {/* Placket / Buttons */}
          <rect x="77" y="42" width="6" height="26" rx="2" fill="#FFFFFF" opacity="0.85" />
          {/* Chest Emblem */}
          <circle cx="93" cy="60" r="5" fill="#F59E0B" />
          <rect x="54" y="102" width="52" height="18" rx="4" fill="#FFFFFF" opacity="0.92" />
          <text x="80" y="114" textAnchor="middle" fill={shirtColor} fontSize="8.5" fontWeight="800">
            {isShirt ? 'CASUAL SHIRT' : 'EXPORT POLO'}
          </text>
        </svg>
      </div>
    );
  }

  // Category 3: Women's Saree, Kurti & Three-Piece
  if (cat === 'cat_03' || sku.includes('SAREE') || sku.includes('3PCS') || nameLower.includes('শাড়ি') || nameLower.includes('থ্রি-পিস')) {
    const isSaree = sku.includes('SAREE') || nameLower.includes('শাড়ি') || nameLower.includes('saree');
    const dressColor = isSaree ? '#BE185D' : '#7E22CE';
    return (
      <div className={`${className} bg-gradient-to-b from-[#FDF2F8] to-[#FCE7F3]/70 flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="144" rx="44" ry="6" fill={dressColor} opacity="0.15" />
          {/* Elegant Kurti / Saree Drape */}
          <path d="M58 28 L102 28 L120 134 L40 134 Z" fill={dressColor} />
          {/* Golden Zari Border */}
          <rect x="40" y="122" width="80" height="12" fill="#F59E0B" />
          <path d="M58 28 L92 134 L106 134 L74 28 Z" fill="#FBBF24" opacity="0.35" />
          {/* Neckline Embroidery */}
          <path d="M68 28 Q80 48 92 28" fill="none" stroke="#FDE68A" strokeWidth="3" />
          <rect x="48" y="92" width="64" height="18" rx="4" fill="#FFFFFF" opacity="0.94" />
          <text x="80" y="104" textAnchor="middle" fill={dressColor} fontSize="8.5" fontWeight="800">
            {isSaree ? 'JAMDANI SAREE' : 'LUXURY 3-PIECE'}
          </text>
        </svg>
      </div>
    );
  }

  // Category 4: Denim Jeans, Gabardine & Trousers
  if (cat === 'cat_04' || sku.includes('JEANS') || sku.includes('PANT') || nameLower.includes('জিন্স') || nameLower.includes('প্যান্ট')) {
    const isChino = nameLower.includes('চিনো') || nameLower.includes('chino') || nameLower.includes('গ্যাবার্ডিন');
    const pantColor = isChino ? '#92400E' : '#1D4ED8';
    return (
      <div className={`${className} bg-gradient-to-b from-[#F8FAFC] to-[#E0E7FF]/50 flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="144" rx="40" ry="6" fill={pantColor} opacity="0.15" />
          {/* Waistband */}
          <rect x="50" y="24" width="60" height="12" rx="3" fill="#1E293B" />
          {/* Trousers / Denim Legs */}
          <path d="M50 34 L110 34 L116 136 L86 136 L80 68 L74 136 L44 136 Z" fill={pantColor} />
          {/* Stitching */}
          <path d="M54 42 Q64 54 66 42" fill="none" stroke="#FBBF24" strokeWidth="2" />
          <path d="M106 42 Q96 54 94 42" fill="none" stroke="#FBBF24" strokeWidth="2" />
          <rect x="48" y="96" width="64" height="18" rx="4" fill="#FFFFFF" opacity="0.94" />
          <text x="80" y="108" textAnchor="middle" fill="#0F172A" fontSize="8.5" fontWeight="800">
            {isChino ? 'CHINO TROUSER' : 'DENIM JEANS'}
          </text>
        </svg>
      </div>
    );
  }

  // Category 5: Sneakers, Loafers & Footwear
  if (cat === 'cat_05' || sku.includes('SHOE') || nameLower.includes('জুতা') || nameLower.includes('স্নিকার্স')) {
    return (
      <div className={`${className} bg-gradient-to-b from-[#F8FAFC] to-[#F1F5F9] flex items-center justify-center p-3`}>
        <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
          <ellipse cx="80" cy="134" rx="52" ry="7" fill="#0F172A" opacity="0.14" />
          {/* Sneaker Upper */}
          <path
            d="M32 104 L38 62 L68 62 L94 84 L128 88 C134 90 136 98 134 106 L28 106 Z"
            fill="#0F172A"
          />
          {/* Accent Stripe */}
          <path d="M50 82 L98 96" stroke="#F97316" strokeWidth="6" strokeLinecap="round" />
          {/* White Midsole */}
          <rect x="26" y="104" width="110" height="14" rx="6" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="2" />
          <text x="80" y="50" textAnchor="middle" fill="#0F172A" fontSize="9.5" fontWeight="800">
            PREMIUM FOOTWEAR
          </text>
        </svg>
      </div>
    );
  }

  // Category 6 / Default: Luxury Watches, Bags & Fashion Accessories
  const isBag = sku.includes('BAG') || nameLower.includes('ব্যাগ') || nameLower.includes('bag');
  return (
    <div className={`${className} bg-gradient-to-b from-[#FFFBEB] to-[#FEF3C7]/50 flex items-center justify-center p-3`}>
      <svg viewBox="0 0 160 160" className="w-full h-full max-w-[135px] max-h-[135px] drop-shadow-xs transition-transform duration-300 group-hover:scale-105">
        <ellipse cx="80" cy="142" rx="42" ry="6" fill="#92400E" opacity="0.15" />
        {isBag ? (
          <g>
            <path d="M60 54 C60 30 100 30 100 54" fill="none" stroke="#78350F" strokeWidth="5" />
            <rect x="38" y="52" width="84" height="76" rx="12" fill="#92400E" />
            <path d="M38 64 L80 86 L122 64" fill="none" stroke="#FDE68A" strokeWidth="2.5" />
            <circle cx="80" cy="84" r="6" fill="#F59E0B" />
            <text x="80" y="114" textAnchor="middle" fill="#FEF3C7" fontSize="9" fontWeight="800">
              LUXURY BAG
            </text>
          </g>
        ) : (
          <g>
            {/* Watch Strap */}
            <rect x="66" y="20" width="28" height="120" rx="6" fill="#1E293B" />
            {/* Watch Case & Dial */}
            <circle cx="80" cy="80" r="34" fill="#F59E0B" />
            <circle cx="80" cy="80" r="28" fill="#0F172A" />
            <line x1="80" y1="80" x2="80" y2="62" stroke="#FBBF24" strokeWidth="3" strokeLinecap="round" />
            <line x1="80" y1="80" x2="94" y2="80" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="80" cy="80" r="3" fill="#F59E0B" />
          </g>
        )}
      </svg>
    </div>
  );
};
