import React from 'react';

interface GlobalSkeletonLoaderProps {
  view?: string;
  variant?: 'erp' | 'landing' | 'storefront';
}

interface BootThemeMeta {
  theme: string;
  shopName: string;
  logoUrl: string;
  topBarEnabled: boolean;
  topBarText: string;
  preloaderEnabled: boolean;
  preloaderShimmerEnabled: boolean;
}

const stripDemoSvgUrl = (url?: string): string => {
  if (!url || typeof url !== 'string') return '';
  const clean = url.trim();
  if (clean.includes('FASHION%20MART') || clean.includes('FASHION MART')) return '';
  return clean;
};

const getActiveBootThemeMeta = (): BootThemeMeta => {
  const fallback: BootThemeMeta = {
    theme: 'emerald_default',
    shopName: 'কিডস অ্যান্ড ফ্যাশন মার্ট',
    logoUrl: '',
    topBarEnabled: true,
    topBarText: 'সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে পেমেন্ট করুন',
    preloaderEnabled: true,
    preloaderShimmerEnabled: true
  };

  if (typeof window === 'undefined') return fallback;

  try {
    let metaLogo = '';
    let metaTheme = '';
    let metaName = '';
    let metaTopBarEnabled: boolean | undefined;
    let metaTopBarText = '';
    let metaPreloaderEnabled: boolean | undefined;
    let metaShimmerEnabled: boolean | undefined;

    const rawMeta = window.localStorage.getItem('sm_boot_theme_meta_v1');
    if (rawMeta) {
      const parsed = JSON.parse(rawMeta);
      if (parsed && typeof parsed === 'object') {
        metaTheme = parsed.theme || '';
        metaName = parsed.shopName || '';
        metaLogo = stripDemoSvgUrl(parsed.logoUrl);
        metaTopBarEnabled = parsed.topBarEnabled !== false;
        metaTopBarText = parsed.topBarText || '';
        if (typeof parsed.preloaderEnabled === 'boolean') {
          metaPreloaderEnabled = parsed.preloaderEnabled;
        }
        if (typeof parsed.preloaderShimmerEnabled === 'boolean') {
          metaShimmerEnabled = parsed.preloaderShimmerEnabled;
        }
      }
    }

    const rawErp = window.localStorage.getItem('stockmaster_bd_persistent_erp_v2');
    if (rawErp) {
      const parsedErp = JSON.parse(rawErp);
      const biz = Array.isArray(parsedErp?.businesses) ? parsedErp.businesses[0] : null;
      if (biz) {
        const isWinter = Boolean(biz.winterThemeEnabled) || biz.storefrontTheme === 'winter_frost';
        const erpLogo = stripDemoSvgUrl(biz.logoUrl);
        const erpPreloader =
          typeof biz.preloaderEnabled === 'boolean'
            ? biz.preloaderEnabled
            : metaPreloaderEnabled ?? true;
        const erpShimmer =
          typeof biz.preloaderShimmerEnabled === 'boolean'
            ? biz.preloaderShimmerEnabled
            : metaShimmerEnabled ?? true;
        return {
          theme: isWinter ? 'winter_frost' : biz.storefrontTheme || metaTheme || fallback.theme,
          shopName: biz.name || metaName || fallback.shopName,
          logoUrl: erpLogo,
          topBarEnabled: biz.topAnnouncementEnabled !== false,
          topBarText: biz.topAnnouncementText || metaTopBarText || fallback.topBarText,
          preloaderEnabled: erpPreloader,
          preloaderShimmerEnabled: erpShimmer
        };
      }
    }

    if (metaTheme || metaName || metaLogo || metaPreloaderEnabled !== undefined || metaShimmerEnabled !== undefined) {
      return {
        theme: metaTheme || fallback.theme,
        shopName: metaName || fallback.shopName,
        logoUrl: metaLogo,
        topBarEnabled: metaTopBarEnabled ?? fallback.topBarEnabled,
        topBarText: metaTopBarText || fallback.topBarText,
        preloaderEnabled: metaPreloaderEnabled ?? fallback.preloaderEnabled,
        preloaderShimmerEnabled: metaShimmerEnabled ?? fallback.preloaderShimmerEnabled
      };
    }
  } catch {
    // Ignore storage read errors
  }

  return fallback;
};

export const GlobalSkeletonLoader: React.FC<GlobalSkeletonLoaderProps> = ({
  view = 'dashboard',
  variant = 'erp',
}) => {
  const bootMeta = getActiveBootThemeMeta();
  const effectiveLogo =
    bootMeta.logoUrl && bootMeta.logoUrl.trim() !== ''
      ? bootMeta.logoUrl
      : '';

  if (variant === 'landing' || variant === 'storefront') {
    const isPreloaderOff = bootMeta.preloaderEnabled === false;
    const isShimmerOn = bootMeta.preloaderShimmerEnabled !== false;

    if (isPreloaderOff && !isShimmerOn) {
      return <div className="min-h-screen bg-[#F8FAFC]" data-storefront-theme={bootMeta.theme} />;
    }

    const statusLabel =
      variant === 'landing' ? 'অফার পেজ লোড হচ্ছে...' : 'লোড হচ্ছে...';

    return (
      <div
        className={`min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-start ${
          isPreloaderOff ? 'pt-6 sm:pt-8' : 'pt-16 sm:pt-20'
        } px-4 sm:px-6 pb-12 antialiased`}
        data-storefront-theme={bootMeta.theme}
      >
        {!isPreloaderOff && (
          <div className="flex flex-col items-center justify-start gap-4 text-center max-w-sm w-full">
            {effectiveLogo ? (
              <img
                src={effectiveLogo}
                alt="Logo"
                className="h-16 sm:h-20 w-auto max-w-[240px] sm:max-w-[280px] object-contain drop-shadow-xs"
              />
            ) : null}
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-emerald-50 border border-emerald-200/90 text-emerald-900 text-xs sm:text-[13px] font-extrabold shadow-xs">
              <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full border-2 border-emerald-200 border-t-emerald-700 animate-spin shrink-0" />
              <span>{statusLabel}</span>
            </div>
          </div>
        )}

        {isShimmerOn && (
          <div
            className={`w-full max-w-[1140px] ${
              isPreloaderOff ? 'mt-2' : 'mt-8 sm:mt-10'
            } grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-5`}
          >
            {Array.from({ length: isPreloaderOff ? 8 : 4 }).map((_, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200/80 p-2.5 sm:p-3.5 shadow-2xs flex flex-col gap-2.5"
              >
                <div className="w-full aspect-square rounded-xl bg-slate-200/75 animate-pulse" />
                <div className="h-3.5 w-4/5 rounded-md bg-slate-200/80 animate-pulse" />
                <div className="h-3 w-3/5 rounded-md bg-slate-100 animate-pulse" />
                <div className="flex items-center justify-between pt-1">
                  <div className="h-4 w-16 rounded-md bg-emerald-100/80 animate-pulse" />
                  <div className="h-3.5 w-10 rounded-md bg-slate-100 animate-pulse" />
                </div>
                <div className="h-9 w-full rounded-xl bg-slate-200/75 animate-pulse mt-0.5" />
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  const isPosOrWholesale = view === 'pos' || view === 'wholesale';
  const isDashboardOrAnalytics =
    view === 'dashboard' ||
    view === 'reports' ||
    view === 'accounting' ||
    view === 'day_end';
  const isSettingsOrConfig =
    view === 'settings' ||
    view === 'facebook' ||
    view === 'gtm' ||
    view === 'wordpress' ||
    view === 'database';
  const isCardGridModule = view === 'landing_pages' || view === 'warehouses';

  return (
    <div
      className="space-y-6 pb-8 animate-in fade-in duration-200"
      role="status"
      aria-live="polite"
      aria-busy="true"
    >
      {/* Top Module Header Skeleton */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm">
        <div className="space-y-2.5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-200/80 animate-pulse shrink-0" />
            <div className="h-6 w-48 sm:w-64 bg-slate-200/80 rounded-lg animate-pulse" />
          </div>
          <div className="h-3.5 w-64 sm:w-80 bg-slate-100 rounded-md animate-pulse" />
        </div>
        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <div className="h-10 w-28 bg-slate-100 rounded-xl animate-pulse" />
          <div className="h-10 w-36 bg-slate-200/80 rounded-xl animate-pulse" />
        </div>
      </div>

      {/* POS / Wholesale Split Layout Skeleton */}
      {isPosOrWholesale && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row gap-3">
              <div className="h-11 flex-1 bg-slate-100 rounded-xl animate-pulse" />
              <div className="h-11 w-full sm:w-40 bg-slate-100 rounded-xl animate-pulse" />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div
                  key={idx}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-3"
                >
                  <div className="aspect-square w-full bg-slate-100 rounded-xl animate-pulse" />
                  <div className="h-4 w-3/4 bg-slate-200/80 rounded-md animate-pulse" />
                  <div className="flex items-center justify-between pt-1">
                    <div className="h-5 w-16 bg-slate-200/80 rounded-md animate-pulse" />
                    <div className="h-6 w-12 bg-slate-100 rounded-lg animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="h-5 w-36 bg-slate-200/80 rounded-lg animate-pulse" />
                <div className="h-6 w-20 bg-slate-100 rounded-lg animate-pulse" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="h-10 bg-slate-100 rounded-xl animate-pulse" />
                <div className="h-10 bg-slate-100 rounded-xl animate-pulse" />
              </div>
              <div className="space-y-3 py-2">
                {Array.from({ length: 3 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100"
                  >
                    <div className="space-y-2">
                      <div className="h-4 w-32 bg-slate-200/80 rounded animate-pulse" />
                      <div className="h-3 w-20 bg-slate-100 rounded animate-pulse" />
                    </div>
                    <div className="h-8 w-20 bg-slate-200/70 rounded-lg animate-pulse" />
                  </div>
                ))}
              </div>
              <div className="border-t border-slate-100 pt-4 space-y-2.5">
                <div className="flex justify-between">
                  <div className="h-4 w-24 bg-slate-100 rounded animate-pulse" />
                  <div className="h-4 w-16 bg-slate-200/80 rounded animate-pulse" />
                </div>
                <div className="flex justify-between">
                  <div className="h-5 w-28 bg-slate-200/80 rounded animate-pulse" />
                  <div className="h-5 w-24 bg-slate-200/80 rounded animate-pulse" />
                </div>
              </div>
              <div className="h-12 w-full bg-slate-200/80 rounded-xl animate-pulse" />
            </div>
          </div>
        </div>
      )}

      {/* Dashboard / Reports / Accounting / Day-End Skeleton */}
      {isDashboardOrAnalytics && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, idx) => (
              <div
                key={idx}
                className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="h-4 w-24 bg-slate-100 rounded-md animate-pulse" />
                  <div className="w-10 h-10 rounded-xl bg-slate-100 animate-pulse" />
                </div>
                <div className="h-7 w-32 bg-slate-200/80 rounded-lg animate-pulse" />
                <div className="h-3 w-20 bg-slate-100 rounded animate-pulse" />
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="h-5 w-44 bg-slate-200/80 rounded-lg animate-pulse" />
                <div className="h-8 w-28 bg-slate-100 rounded-lg animate-pulse" />
              </div>
              <div className="h-64 w-full bg-slate-50 border border-slate-100 rounded-xl p-4 flex items-end justify-between gap-3">
                {[45, 70, 55, 85, 60, 90, 65, 78].map((height, idx) => (
                  <div
                    key={idx}
                    className={`w-full bg-slate-200/70 rounded-t-lg animate-pulse ${
                      height > 80
                        ? 'h-48'
                        : height > 65
                        ? 'h-36'
                        : height > 50
                        ? 'h-28'
                        : 'h-20'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
              <div className="h-5 w-36 bg-slate-200/80 rounded-lg animate-pulse" />
              <div className="space-y-3 pt-2">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-slate-200/70 animate-pulse" />
                      <div className="space-y-1.5">
                        <div className="h-3.5 w-28 bg-slate-200/80 rounded animate-pulse" />
                        <div className="h-2.5 w-16 bg-slate-100 rounded animate-pulse" />
                      </div>
                    </div>
                    <div className="h-4 w-14 bg-slate-200/80 rounded animate-pulse" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {/* Settings / Facebook / GTM / WordPress / Database Configuration Skeleton */}
      {isSettingsOrConfig && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
              <div className="h-5 w-40 bg-slate-200/80 rounded-lg animate-pulse" />
              <div className="h-3.5 w-full bg-slate-100 rounded animate-pulse" />
              <div className="space-y-2 pt-2">
                {Array.from({ length: 4 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="h-11 w-full bg-slate-50 border border-slate-100 rounded-xl animate-pulse"
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-5">
              <div className="h-5 w-48 bg-slate-200/80 rounded-lg animate-pulse" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {Array.from({ length: 4 }).map((_, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="h-3.5 w-28 bg-slate-100 rounded animate-pulse" />
                    <div className="h-11 w-full bg-slate-50 border border-slate-100 rounded-xl animate-pulse" />
                  </div>
                ))}
              </div>
              <div className="space-y-2">
                <div className="h-3.5 w-36 bg-slate-100 rounded animate-pulse" />
                <div className="h-24 w-full bg-slate-50 border border-slate-100 rounded-xl animate-pulse" />
              </div>
              <div className="flex justify-end pt-2">
                <div className="h-10 w-36 bg-slate-200/80 rounded-xl animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Card Grid Modules (Landing Pages / Warehouses) */}
      {isCardGridModule && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div
              key={idx}
              className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl bg-slate-100 animate-pulse shrink-0" />
                <div className="space-y-2 flex-1">
                  <div className="h-4 w-3/4 bg-slate-200/80 rounded animate-pulse" />
                  <div className="h-3 w-1/2 bg-slate-100 rounded animate-pulse" />
                </div>
              </div>
              <div className="h-20 w-full bg-slate-50 border border-slate-100 rounded-xl animate-pulse" />
              <div className="flex items-center justify-between pt-1">
                <div className="h-8 w-24 bg-slate-100 rounded-lg animate-pulse" />
                <div className="h-8 w-24 bg-slate-200/80 rounded-lg animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Standard Data Table / List Module Skeleton (Orders, Inventory, Customers, Purchases, Returns, etc.) */}
      {!isPosOrWholesale &&
        !isDashboardOrAnalytics &&
        !isSettingsOrConfig &&
        !isCardGridModule && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, idx) => (
                <div
                  key={idx}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-2"
                >
                  <div className="h-3.5 w-24 bg-slate-100 rounded animate-pulse" />
                  <div className="h-6 w-20 bg-slate-200/80 rounded-lg animate-pulse" />
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="h-10 w-full sm:w-72 bg-slate-100 rounded-xl animate-pulse" />
                <div className="flex items-center gap-2">
                  <div className="h-10 w-28 bg-slate-100 rounded-xl animate-pulse" />
                  <div className="h-10 w-28 bg-slate-100 rounded-xl animate-pulse" />
                </div>
              </div>
              <div className="divide-y divide-slate-100">
                {Array.from({ length: 6 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-11 h-11 rounded-xl bg-slate-100 animate-pulse shrink-0" />
                      <div className="space-y-2">
                        <div className="h-4 w-40 sm:w-52 bg-slate-200/80 rounded animate-pulse" />
                        <div className="h-3 w-28 sm:w-36 bg-slate-100 rounded animate-pulse" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-4">
                      <div className="h-6 w-20 bg-slate-100 rounded-lg animate-pulse" />
                      <div className="h-5 w-24 bg-slate-200/80 rounded animate-pulse" />
                      <div className="h-8 w-20 bg-slate-100 rounded-lg animate-pulse" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
    </div>
  );
};
