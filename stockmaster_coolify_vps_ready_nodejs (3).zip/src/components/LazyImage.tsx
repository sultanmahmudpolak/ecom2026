import React, { useState, useEffect, useRef } from 'react';

interface LazyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  wrapperClassName?: string;
  skeletonClassName?: string;
  eager?: boolean;
  rootMargin?: string;
  onImageError?: () => void;
  fallback?: React.ReactNode;
}

/**
 * IntersectionObserver-based Lazy Image component for faster mobile initial page load.
 * Defers downloading off-screen banner & gallery images until they approach the viewport,
 * while rendering a clean shimmer skeleton placeholder until the image finishes decoding.
 * Immediately renders Base64 (data:) and eager images so they never stay blank/white.
 */
export const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  className = '',
  wrapperClassName = 'relative w-full overflow-hidden',
  skeletonClassName = 'min-h-[120px]',
  eager = false,
  rootMargin = '280px 0px',
  onImageError,
  fallback,
  ...rest
}) => {
  const isDataUri = Boolean(src && src.trim().startsWith('data:'));
  const containerRef = useRef<HTMLDivElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [isInView, setIsInView] = useState<boolean>(() => {
    if (eager || isDataUri) return true;
    if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') {
      return true;
    }
    return false;
  });
  const [isLoaded, setIsLoaded] = useState<boolean>(() => isDataUri || eager);
  const [hasError, setHasError] = useState<boolean>(false);

  useEffect(() => {
    setHasError(false);
    if (isDataUri || eager) {
      setIsLoaded(true);
      setIsInView(true);
    } else if (imgRef.current && imgRef.current.complete && imgRef.current.naturalWidth > 0) {
      setIsLoaded(true);
    } else {
      setIsLoaded(false);
    }
  }, [src, isDataUri, eager]);

  useEffect(() => {
    if (isInView || eager || isDataUri) return;
    const node = containerRef.current;
    if (!node || typeof IntersectionObserver === 'undefined') {
      setIsInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      entries => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            setIsInView(true);
            observer.disconnect();
            break;
          }
        }
      },
      {
        root: null,
        rootMargin,
        threshold: 0.01
      }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [isInView, eager, isDataUri, rootMargin, src]);

  if (!src || src.trim() === '' || hasError) {
    return (
      <div ref={containerRef} className={wrapperClassName}>
        {fallback || null}
      </div>
    );
  }

  return (
    <div ref={containerRef} className={wrapperClassName}>
      {!isLoaded && !hasError && (
        <div
          aria-hidden="true"
          className={`w-full bg-gradient-to-r from-slate-100 via-slate-200/75 to-slate-100 animate-pulse ${
            isInView ? 'absolute inset-0 z-0' : skeletonClassName
          }`}
        />
      )}

      {isInView && !hasError && (
        <img
          ref={imgRef}
          src={src}
          alt={alt}
          loading={eager || isDataUri ? 'eager' : 'lazy'}
          fetchPriority={eager ? 'high' : 'low'}
          decoding="async"
          referrerPolicy="no-referrer"
          onLoad={() => setIsLoaded(true)}
          onError={() => {
            setHasError(true);
            setIsLoaded(true);
            if (onImageError) onImageError();
          }}
          className={`${className} transition-opacity duration-300 ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          {...rest}
        />
      )}
    </div>
  );
};
