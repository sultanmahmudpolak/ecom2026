import React, { useState, useMemo, useEffect } from 'react';
import { useApp, normalizeBdPhone } from '../context/AppContext';
import { SpinWheelConfig, SpinWheelLead, SpinWheelSliceConfig } from '../types';
import {
  DEFAULT_SPIN_WHEEL_CONFIG,
  DEFAULT_SPIN_WHEEL_SLICES,
  DEFAULT_LANDING_SPIN_WHEEL_CONFIG,
  DEFAULT_LANDING_SPIN_WHEEL_SLICES
} from '../utils/landingConstants';
import { exportToCsv, exportToExcel } from '../config/api';
import {
  Gift,
  Sparkles,
  PhoneCall,
  Search,
  Copy,
  Trash2,
  Download,
  RotateCcw,
  CheckCircle2,
  ShieldCheck,
  ArrowRight,
  Lock,
  Unlock,
  Globe,
  Rocket,
  Users,
  ShoppingBag,
  MessageCircle,
  Plus,
  Save
} from 'lucide-react';

interface UnifiedSpinLeadItem {
  id: string;
  customerName: string;
  customerPhone: string;
  rewardLabel: string;
  couponCode: string;
  source: 'website' | 'landing';
  dateKey: string;
  createdAt: string;
  usedOrderNo?: string;
  orderGrandTotal?: number;
}

export const SpinWheelAdminView: React.FC = () => {
  const {
    currentBusiness,
    updateBusiness,
    products,
    updateProduct,
    onlineOrders,
    formatCurrency,
    showToast,
    confirmDelete
  } = useApp();

  const [activeTab, setActiveTab] = useState<'leads' | 'website_settings' | 'landing_settings'>(
    'leads'
  );
  const [leadSearch, setLeadSearch] = useState('');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'website' | 'landing'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'ordered' | 'pending'>('all');

  // ============================================================================
  // 1. WEBSITE SPIN WHEEL CONFIG & DRAFT
  // ============================================================================
  const websiteSpinConfig = useMemo<Required<SpinWheelConfig>>(() => {
    const cfg = currentBusiness.spinWheelConfig || {};
    const rawSlices =
      Array.isArray(cfg.slices) && cfg.slices.length >= 2
        ? cfg.slices
        : DEFAULT_SPIN_WHEEL_SLICES;
    const hasExplicitLockState = rawSlices.some(s => typeof s.locked === 'boolean');
    const validSlices = hasExplicitLockState
      ? rawSlices
      : rawSlices.map((s, idx) => ({
          ...s,
          locked:
            s.id === 'sw_100' ||
            s.id === 'sw_5pct' ||
            (!['sw_50', 'sw_free_del', 'sw_30', 'sw_20'].includes(s.id) &&
              (idx === 3 || idx === 4))
        }));
    return {
      badgeText: cfg.badgeText?.trim() || DEFAULT_SPIN_WHEEL_CONFIG.badgeText,
      titleText: cfg.titleText?.trim() || DEFAULT_SPIN_WHEEL_CONFIG.titleText,
      subtitleText: cfg.subtitleText?.trim() || DEFAULT_SPIN_WHEEL_CONFIG.subtitleText,
      claimButtonText: cfg.claimButtonText?.trim() || DEFAULT_SPIN_WHEEL_CONFIG.claimButtonText,
      autoPopupDelaySec:
        typeof cfg.autoPopupDelaySec === 'number' && cfg.autoPopupDelaySec >= 1
          ? cfg.autoPopupDelaySec
          : DEFAULT_SPIN_WHEEL_CONFIG.autoPopupDelaySec,
      cooldownDays:
        typeof cfg.cooldownDays === 'number' && cfg.cooldownDays >= 1
          ? cfg.cooldownDays
          : DEFAULT_SPIN_WHEEL_CONFIG.cooldownDays,
      slices: validSlices
    };
  }, [currentBusiness.spinWheelConfig]);

  const [webDraft, setWebDraft] = useState<Required<SpinWheelConfig>>(websiteSpinConfig);
  useEffect(() => {
    setWebDraft(websiteSpinConfig);
  }, [websiteSpinConfig]);

  // ============================================================================
  // 2. LANDING PAGE SPIN WHEEL CONFIG & DRAFT
  // ============================================================================
  const landingSpinConfig = useMemo<Required<SpinWheelConfig>>(() => {
    const cfg = currentBusiness.landingSpinWheelConfig || {};
    const rawSlices =
      Array.isArray(cfg.slices) && cfg.slices.length >= 2
        ? cfg.slices
        : DEFAULT_LANDING_SPIN_WHEEL_SLICES;
    const hasExplicitLockState = rawSlices.some(s => typeof s.locked === 'boolean');
    const validSlices = hasExplicitLockState
      ? rawSlices
      : rawSlices.map((s, idx) => ({
          ...s,
          locked:
            s.id === 'lp_sw_4' ||
            s.id === 'lp_sw_5' ||
            (!['lp_sw_1', 'lp_sw_2', 'lp_sw_3', 'lp_sw_6'].includes(s.id) &&
              (idx === 3 || idx === 4))
        }));
    return {
      badgeText:
        cfg.badgeText?.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.badgeText ||
        'স্পেশাল লাকি ডিসকাউন্ট হুইল',
      titleText:
        cfg.titleText?.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.titleText ||
        'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
      subtitleText:
        cfg.subtitleText?.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.subtitleText ||
        'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
      claimButtonText:
        cfg.claimButtonText?.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.claimButtonText ||
        'অফারটি গ্রহণ করে অর্ডার করুন',
      autoPopupDelaySec:
        typeof cfg.autoPopupDelaySec === 'number' && cfg.autoPopupDelaySec >= 1
          ? cfg.autoPopupDelaySec
          : DEFAULT_LANDING_SPIN_WHEEL_CONFIG.autoPopupDelaySec || 4,
      cooldownDays:
        typeof cfg.cooldownDays === 'number' && cfg.cooldownDays >= 1
          ? cfg.cooldownDays
          : DEFAULT_LANDING_SPIN_WHEEL_CONFIG.cooldownDays || 7,
      slices: validSlices
    };
  }, [currentBusiness.landingSpinWheelConfig]);

  const [lpDraft, setLpDraft] = useState<Required<SpinWheelConfig>>(landingSpinConfig);
  useEffect(() => {
    setLpDraft(landingSpinConfig);
  }, [landingSpinConfig]);

  // ============================================================================
  // 3. UNIFIED SPIN LEADS (WEBSITE + LANDING PAGE) WITH ORDER MATCHING
  // ============================================================================
  const unifiedLeads = useMemo<UnifiedSpinLeadItem[]>(() => {
    const deletedSet = new Set(currentBusiness.deletedSpinLeadIds || []);
    const byId = new Map<string, UnifiedSpinLeadItem>();

    const ingestLead = (raw: SpinWheelLead, defaultSource: 'website' | 'landing') => {
      if (!raw || !raw.id || deletedSet.has(raw.id)) return;
      const name = (raw.customerName || raw.name || 'কাস্টমার').trim();
      const phone = normalizeBdPhone(raw.customerPhone || raw.phone || '');
      const rewardLabel = (raw.rewardLabel || raw.prizeLabel || 'স্পিন অফার').trim();
      const couponCode = (raw.couponCode || raw.prizeCode || '').trim();
      const source: 'website' | 'landing' =
        raw.source ||
        (String(raw.id).startsWith('lp_') || rewardLabel.includes('Landing:')
          ? 'landing'
          : defaultSource);
      const createdAt = raw.createdAt || new Date().toISOString();
      const dateKey = raw.spinDateKey || raw.dateKey || createdAt.slice(0, 10);

      const leadMs = new Date(createdAt).getTime();
      const matchedOrder = onlineOrders.find(o => {
        if (o.orderStatus === 'cancelled') return false;
        if (!phone || normalizeBdPhone(o.customerPhone) !== phone) return false;
        const hasSpinNote = Boolean(
          o.notes &&
            (o.notes.includes('স্পিন') ||
              (couponCode && o.notes.toUpperCase().includes(couponCode.toUpperCase())))
        );
        if (!hasSpinNote) return false;
        if (!Number.isNaN(leadMs)) {
          const ordMs = new Date(o.createdAt).getTime();
          if (!Number.isNaN(ordMs) && ordMs + 10000 < leadMs) return false;
        }
        return true;
      });

      byId.set(raw.id, {
        id: raw.id,
        customerName: name,
        customerPhone: phone || raw.customerPhone || raw.phone || '',
        rewardLabel,
        couponCode,
        source,
        dateKey,
        createdAt,
        usedOrderNo: matchedOrder?.orderNo,
        orderGrandTotal: matchedOrder?.grandTotal
      });
    };

    (currentBusiness.spinWheelLeads || []).forEach(l => ingestLead(l, 'website'));
    (currentBusiness.landingSpinWheelLeads || []).forEach(l => ingestLead(l, 'landing'));

    if (typeof window !== 'undefined') {
      try {
        const rawWeb = window.localStorage.getItem('stockmaster_spin_wheel_leads_v1');
        if (rawWeb) {
          const parsed = JSON.parse(rawWeb);
          if (Array.isArray(parsed)) parsed.forEach(l => ingestLead(l, 'website'));
        }
      } catch {
        // ignore
      }
      try {
        const rawLp = window.localStorage.getItem('lp_spin_wheel_leads_v1');
        if (rawLp) {
          const parsed = JSON.parse(rawLp);
          if (Array.isArray(parsed)) parsed.forEach(l => ingestLead(l, 'landing'));
        }
      } catch {
        // ignore
      }
    }

    return Array.from(byId.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [
    currentBusiness.spinWheelLeads,
    currentBusiness.landingSpinWheelLeads,
    currentBusiness.deletedSpinLeadIds,
    onlineOrders
  ]);

  const filteredLeads = useMemo(() => {
    const q = leadSearch.trim().toLowerCase();
    return unifiedLeads.filter(lead => {
      if (sourceFilter !== 'all' && lead.source !== sourceFilter) return false;
      if (statusFilter === 'ordered' && !lead.usedOrderNo) return false;
      if (statusFilter === 'pending' && lead.usedOrderNo) return false;
      if (!q) return true;
      return (
        lead.customerName.toLowerCase().includes(q) ||
        lead.customerPhone.toLowerCase().includes(q) ||
        lead.rewardLabel.toLowerCase().includes(q) ||
        lead.couponCode.toLowerCase().includes(q) ||
        (lead.usedOrderNo && lead.usedOrderNo.toLowerCase().includes(q))
      );
    });
  }, [unifiedLeads, leadSearch, sourceFilter, statusFilter]);

  const totalWebsiteLeads = useMemo(
    () => unifiedLeads.filter(l => l.source === 'website').length,
    [unifiedLeads]
  );
  const totalLandingLeads = useMemo(
    () => unifiedLeads.filter(l => l.source === 'landing').length,
    [unifiedLeads]
  );
  const totalConvertedLeads = useMemo(
    () => unifiedLeads.filter(l => Boolean(l.usedOrderNo)).length,
    [unifiedLeads]
  );

  // ============================================================================
  // ACTIONS: SAVE SETTINGS, DELETE LEAD, EXPORT CSV, RESET TEST LOCK
  // ============================================================================
  const handleSaveWebsiteSpinSettings = () => {
    const cleanedSlices = webDraft.slices
      .map((s, idx) => ({
        id: s.id || `sw_custom_${idx}_${Date.now()}`,
        label: s.label.trim() || `পুরস্কার #${idx + 1}`,
        shortLabel: s.shortLabel.trim() || s.label.trim() || `ছাড় #${idx + 1}`,
        type: s.type,
        value:
          s.type === 'free_delivery' || s.type === 'none'
            ? 0
            : Math.max(0, Number(s.value) || 0),
        color: s.color || '#e11d48',
        code:
          s.type === 'none'
            ? 'TRYAGAIN'
            : (s.code || `SPIN${idx + 1}`).trim().toUpperCase(),
        locked: Boolean(s.locked)
      }))
      .filter(Boolean);

    if (cleanedSlices.length < 2) {
      showToast('স্পিন হুইলে কমপক্ষে ২টি পুরস্কার স্লাইস থাকতে হবে।', 'error');
      return;
    }

    if (cleanedSlices.every(s => s.locked)) {
      showToast(
        'সবগুলো অফার লক রাখা যাবে না! কমপক্ষে ১টি অফার আনলক রাখুন যাতে কাস্টমার জিততে পারে।',
        'error'
      );
      return;
    }

    const updatedConfig: SpinWheelConfig = {
      badgeText: webDraft.badgeText.trim() || DEFAULT_SPIN_WHEEL_CONFIG.badgeText,
      titleText: webDraft.titleText.trim() || DEFAULT_SPIN_WHEEL_CONFIG.titleText,
      subtitleText: webDraft.subtitleText.trim() || DEFAULT_SPIN_WHEEL_CONFIG.subtitleText,
      claimButtonText: webDraft.claimButtonText.trim() || DEFAULT_SPIN_WHEEL_CONFIG.claimButtonText,
      autoPopupDelaySec: Math.max(1, Math.min(60, Number(webDraft.autoPopupDelaySec) || 4)),
      cooldownDays: Math.max(1, Number(webDraft.cooldownDays) || 7),
      slices: cleanedSlices
    };

    updateBusiness({
      spinWheelConfig: updatedConfig
    });
    showToast('ওয়েবসাইট স্পিন হুইল সেটিংস ও পুরস্কার ডাটাবেসে সংরক্ষিত হয়েছে!', 'success');
  };

  const handleSaveLandingSpinSettings = () => {
    const cleanedSlices = lpDraft.slices
      .map((s, idx) => ({
        id: s.id || `lp_sw_${idx + 1}`,
        shortLabel: s.shortLabel.trim() || s.label.trim() || `অফার ${idx + 1}`,
        label: s.label.trim() || s.shortLabel.trim() || `অফার ${idx + 1}`,
        type: s.type,
        value:
          s.type === 'free_delivery' || s.type === 'none'
            ? 0
            : Math.max(0, Number(s.value) || 0),
        color: s.color || '#059669',
        code: (s.code || `LP${idx + 1}`).trim().toUpperCase(),
        locked: Boolean(s.locked)
      }))
      .filter(Boolean);

    if (cleanedSlices.length < 2) {
      showToast('ল্যান্ডিং পেজ হুইলে কমপক্ষে ২টি অফার স্লাইস থাকতে হবে।', 'error');
      return;
    }

    if (cleanedSlices.every(s => s.locked)) {
      showToast(
        'সবগুলো অফার লক রাখা যাবে না! কমপক্ষে ১টি অফার আনলক রাখুন যাতে কাস্টমার জিততে পারে।',
        'error'
      );
      return;
    }

    const updatedConfig: SpinWheelConfig = {
      badgeText:
        lpDraft.badgeText.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.badgeText ||
        'স্পেশাল লাকি ডিসকাউন্ট হুইল',
      titleText:
        lpDraft.titleText.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.titleText ||
        'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
      subtitleText:
        lpDraft.subtitleText.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.subtitleText ||
        'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
      claimButtonText:
        lpDraft.claimButtonText.trim() ||
        DEFAULT_LANDING_SPIN_WHEEL_CONFIG.claimButtonText ||
        'অফারটি গ্রহণ করে অর্ডার করুন',
      autoPopupDelaySec: Math.max(1, Math.min(60, Number(lpDraft.autoPopupDelaySec) || 4)),
      cooldownDays: Math.max(1, Number(lpDraft.cooldownDays) || 7),
      slices: cleanedSlices
    };

    updateBusiness({
      landingSpinWheelConfig: updatedConfig
    });
    showToast('ল্যান্ডিং পেজ স্পিন হুইল সেটিংস ও পুরস্কার ডাটাবেসে সংরক্ষিত হয়েছে!', 'success');
  };

  const handleDeleteLead = (leadId: string) => {
    const allCurrentLeads = [
      ...(currentBusiness.spinWheelLeads || []),
      ...(currentBusiness.landingSpinWheelLeads || [])
    ];
    const targetLead = allCurrentLeads.find(l => l?.id === leadId);
    confirmDelete({
      title: 'স্পিন কাস্টমার ডাটা মুছে ফেলতে চান?',
      itemName: targetLead
        ? `${targetLead.customerName || targetLead.name || 'Customer'} (${targetLead.customerPhone || targetLead.phone || ''})`
        : undefined,
      message: 'এই কাস্টমারের স্পিন হুইল কুপন ও নাম্বার স্থায়ীভাবে মুছে ফেলা হবে।',
      confirmLabel: 'হ্যাঁ, ডিলিট করুন',
      onConfirm: () => {
        const nextWebLeads = (currentBusiness.spinWheelLeads || []).filter(l => l.id !== leadId);
        const nextLpLeads = (currentBusiness.landingSpinWheelLeads || []).filter(
          l => l.id !== leadId
        );
        const nextDeletedIds = Array.from(
          new Set([...(currentBusiness.deletedSpinLeadIds || []), leadId])
        );

        try {
          const rawWeb = window.localStorage.getItem('stockmaster_spin_wheel_leads_v1');
          if (rawWeb) {
            const parsed = JSON.parse(rawWeb);
            if (Array.isArray(parsed)) {
              window.localStorage.setItem(
                'stockmaster_spin_wheel_leads_v1',
                JSON.stringify(parsed.filter(l => l?.id !== leadId))
              );
            }
          }
          const rawLp = window.localStorage.getItem('lp_spin_wheel_leads_v1');
          if (rawLp) {
            const parsed = JSON.parse(rawLp);
            if (Array.isArray(parsed)) {
              window.localStorage.setItem(
                'lp_spin_wheel_leads_v1',
                JSON.stringify(parsed.filter(l => l?.id !== leadId))
              );
            }
          }
        } catch {
          // ignore
        }

        updateBusiness({
          spinWheelLeads: nextWebLeads,
          landingSpinWheelLeads: nextLpLeads,
          deletedSpinLeadIds: nextDeletedIds
        });
        showToast('স্পিন কাস্টমার ডাটা মুছে ফেলা হয়েছে।', 'info');
      }
    });
  };

  const handleResetDeviceSpinLocks = () => {
    try {
      window.localStorage.removeItem('stockmaster_spin_daily_lock_v1');
      window.localStorage.removeItem('stockmaster_spin_reward_v1');
      window.localStorage.removeItem('stockmaster_spin_popup_state_v2');
      window.localStorage.removeItem('lp_spin_daily_lock_v1');
      window.localStorage.removeItem('lp_spin_reward_v1');
      window.localStorage.removeItem('lp_spin_popup_state_v1');
    } catch {
      // ignore
    }
    showToast(
      'এই ডিভাইসের ওয়েবসাইট ও ল্যান্ডিং পেজ স্পিন লক রিসেট হয়েছে! এখন আবার নতুন করে স্পিন টেস্ট করতে পারবেন।',
      'success'
    );
  };

  const handleExportExcel = () => {
    const targetList = filteredLeads.length > 0 ? filteredLeads : unifiedLeads;
    if (targetList.length === 0) {
      showToast('ডাউনলোড করার মতো কোনো স্পিন কাস্টমার ডাটা নেই।', 'error');
      return;
    }
    exportToExcel(
      'Spin_Wheel_Marketing_Customer_Leads',
      'Spin_Wheel_Leads',
      [
        'ক্রমিক নং',
        'কাস্টমারের নাম',
        'মোবাইল নাম্বার',
        'কোথা থেকে স্পিন করেছেন',
        'জেতা অফার / পুরস্কার',
        'কুপন কোড',
        'অর্ডার স্ট্যাটাস',
        'তারিখ ও সময়'
      ],
      targetList.map((l, idx) => [
        idx + 1,
        l.customerName || 'কাস্টমার',
        l.customerPhone || '',
        l.source === 'landing' ? 'ল্যান্ডিং পেজ (Landing Page)' : 'মেইন ওয়েবসাইট (Main Website)',
        l.rewardLabel || '',
        l.couponCode || '',
        l.usedOrderNo ? `অর্ডার সম্পন্ন (#${l.usedOrderNo})` : 'এখনো অর্ডার করেননি (Pending Lead)',
        new Date(l.createdAt).toLocaleString('en-GB')
      ])
    );
    showToast(
      `স্পিন হুইলের ${targetList.length} জন কাস্টমারের ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
      'success'
    );
  };

  const handleExportCsv = () => {
    const targetList = filteredLeads.length > 0 ? filteredLeads : unifiedLeads;
    if (targetList.length === 0) {
      showToast('এক্সপোর্ট করার মতো কোনো ডাটা নেই।', 'error');
      return;
    }
    exportToCsv(
      'Spin_Wheel_Google_Sheet_Leads',
      [
        'SL',
        'Customer Name',
        'Phone Number',
        'Source',
        'Prize Won',
        'Coupon Code',
        'Order Status',
        'Date & Time'
      ],
      targetList.map((l, idx) => [
        idx + 1,
        l.customerName || 'কাস্টমার',
        l.customerPhone || '',
        l.source === 'landing' ? 'Landing Page' : 'Main Website',
        l.rewardLabel || '',
        l.couponCode || '',
        l.usedOrderNo ? `Ordered (#${l.usedOrderNo})` : 'Not Ordered Yet',
        new Date(l.createdAt).toLocaleString('en-GB')
      ])
    );
    showToast(
      `স্পিন হুইলের ${targetList.length} জন কাস্টমারের ডাটা Google Sheet / CSV ফাইলে ডাউনলোড হয়েছে!`,
      'success'
    );
  };

  const landingProducts = useMemo(
    () => products.filter(p => Boolean(p.isLandingPageProduct)),
    [products]
  );

  // Reusable Wheel & Button Live Preview Card
  const renderLiveWheelPreview = (config: Required<SpinWheelConfig>, label: string) => {
    const slices = config.slices || [];
    const unlockedCount = slices.filter(s => !s.locked).length;
    const lockedCount = slices.filter(s => s.locked).length;
    return (
      <div className="rounded-3xl bg-gradient-to-b from-[#FFFDF9] via-[#FFF7ED] to-[#FDF2F8] border-2 border-amber-300 p-5 shadow-lg text-center space-y-3.5">
        <div className="flex items-center justify-between gap-2 text-[11px] font-extrabold text-amber-900 bg-amber-100/80 border border-amber-300 rounded-xl px-3 py-1.5">
          <span>👁️ লাইভ প্রিভিউ: {label}</span>
          <span>
            🔓 {unlockedCount}টি পাবে • 🔒 {lockedCount}টি লক
          </span>
        </div>

        <div className="space-y-1.5">
          <div className="flex justify-center pb-0.5">
            <div className="spin-badge-focus-wrapper">
              <span className="relative z-10 inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full spin-badge-focus-inner btn-premium-shine text-white text-xs font-extrabold tracking-wide shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-yellow-200 animate-spin shrink-0 relative z-10" />
                <span className="relative z-10 drop-shadow-xs">{config.badgeText}</span>
                <Gift className="w-3.5 h-3.5 text-amber-200 animate-bounce shrink-0 relative z-10" />
              </span>
            </div>
          </div>
          <h4 className="text-base sm:text-lg font-black text-slate-900 leading-snug pt-0.5">
            {config.titleText}
          </h4>
          <p className="text-xs text-slate-600 font-semibold leading-relaxed">
            {config.subtitleText}
          </p>
        </div>

        {/* Animated Wheel Preview */}
        <div className="relative w-56 h-56 mx-auto my-2 flex items-center justify-center">
          <div className="pointer-events-none absolute -inset-2 rounded-full bg-gradient-to-r from-rose-500/20 via-amber-400/25 to-violet-500/20 blur-xl animate-pulse" />
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center">
            <div className="w-3.5 h-3.5 rounded-full bg-amber-400 border-2 border-white shadow-sm -mb-1.5 z-10" />
            <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[24px] border-t-[#e11d48]" />
          </div>

          <div className="w-full h-full rounded-full p-2.5 bg-gradient-to-tr from-amber-500 via-yellow-300 to-rose-500 shadow-lg border-4 border-white relative flex items-center justify-center">
            {Array.from({ length: 16 }).map((_, dotIdx) => (
              <div
                key={dotIdx}
                className="absolute inset-1 pointer-events-none flex justify-center items-start"
                style={{ transform: `rotate(${dotIdx * 22.5}deg)` }}
              >
                <span
                  className={`w-2 h-2 rounded-full border border-white/80 ${
                    dotIdx % 2 === 0
                      ? 'bg-yellow-200 animate-wheel-led-even'
                      : 'bg-rose-500 animate-wheel-led-odd'
                  }`}
                />
              </div>
            ))}

            <div
              className="w-full h-full rounded-full border-4 border-white relative overflow-hidden"
              style={{
                background: `conic-gradient(${slices
                  .map((s, idx) => {
                    const deg = 360 / Math.max(1, slices.length);
                    return `${s.color} ${idx * deg}deg ${(idx + 1) * deg}deg`;
                  })
                  .join(', ')})`
              }}
            >
              {slices.map((s, idx) => {
                const deg = 360 / Math.max(1, slices.length);
                const centerAngle = idx * deg + deg / 2;
                return (
                  <div
                    key={s.id || idx}
                    className="absolute inset-0 flex justify-center items-start pt-3.5 pointer-events-none"
                    style={{ transform: `rotate(${centerAngle}deg)` }}
                  >
                    <span className="px-2 py-0.5 rounded-full bg-white/95 text-slate-900 border border-amber-300 font-extrabold text-[10px] shadow-2xs max-w-[82px] truncate">
                      {s.shortLabel}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="absolute z-10 w-13 h-13 rounded-full bg-gradient-to-br from-white via-amber-50 to-amber-200 text-[#c30000] border-4 border-amber-400 flex flex-col items-center justify-center shadow-md animate-spin-hub-pulse">
              <Gift className="w-3.5 h-3.5 text-[#e11d48] -mb-0.5" />
              <span className="text-[9px] font-black">SPIN</span>
            </div>
          </div>
        </div>

        {/* Colorful Spin Button Preview Matching Screenshot */}
        <div className="space-y-2 pt-1">
          <div className="relative w-full py-3 px-5 rounded-2xl animate-spin-colorful-btn text-white font-extrabold text-sm sm:text-base shadow-lg border border-white/30 overflow-hidden flex items-center justify-center gap-3">
            <span className="pointer-events-none absolute inset-y-0 w-20 bg-gradient-to-r from-transparent via-white/35 to-transparent animate-spin-btn-shimmer" />
            <Sparkles className="w-4 h-4 text-yellow-200 shrink-0 animate-pulse relative z-10" />
            <span className="relative z-10">স্পিন করুন</span>
            <span className="relative z-10 w-7 h-7 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-sm shrink-0">
              <ArrowRight className="w-3.5 h-3.5 stroke-[2.75]" />
            </span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-slate-600">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>আপনার নাম ও ফোন নম্বর পুরস্কার যাচাই করতে ব্যবহার করা হবে।</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-2xs flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-rose-50 to-amber-50 border border-amber-200 text-rose-700 text-xs font-extrabold">
            <Gift className="w-3.5 h-3.5 text-rose-600" />
            <span>স্পিন দ্য হুইল ক্যাম্পেইন ও কাস্টমার ডাটাবেস</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            স্পিন হুইল সেটিংস ও কাস্টমার নাম্বার তালিকা
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
            ওয়েবসাইট এবং ল্যান্ডিং পেজের স্পিন হুইল নিয়ন্ত্রণ করুন (৬টি অফারের মধ্যে ৪টি আনলক ও ২টি লক অফার) এবং স্পিন থেকে পাওয়া সকল কাস্টমারের নাম ও মোবাইল নাম্বার এক জায়গায় দেখুন। সকল ডাটা স্বয়ংক্রিয়ভাবে মূল ডাটাবেসে সংরক্ষিত থাকে।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              const nextVal = currentBusiness.spinWheelEnabled === false;
              updateBusiness({ spinWheelEnabled: nextVal });
              showToast(
                nextVal
                  ? 'ওয়েবসাইট স্পিন হুইল চালু (ON) করা হয়েছে!'
                  : 'ওয়েবসাইট স্পিন হুইল বন্ধ (OFF) করা হয়েছে!',
                nextVal ? 'success' : 'info'
              );
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold border flex items-center gap-1.5 cursor-pointer transition-colors ${
              currentBusiness.spinWheelEnabled !== false
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>
              ওয়েবসাইট স্পিন: {currentBusiness.spinWheelEnabled !== false ? 'চালু (ON)' : 'বন্ধ (OFF)'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              const nextVal = currentBusiness.landingSpinWheelEnabled === false;
              updateBusiness({ landingSpinWheelEnabled: nextVal });
              showToast(
                nextVal
                  ? 'ল্যান্ডিং পেজ স্পিন হুইল চালু (ON) করা হয়েছে!'
                  : 'ল্যান্ডিং পেজ স্পিন হুইল বন্ধ (OFF) করা হয়েছে!',
                nextVal ? 'success' : 'info'
              );
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold border flex items-center gap-1.5 cursor-pointer transition-colors ${
              currentBusiness.landingSpinWheelEnabled !== false
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
            }`}
          >
            <Rocket className="w-3.5 h-3.5" />
            <span>
              ল্যান্ডিং স্পিন: {currentBusiness.landingSpinWheelEnabled !== false ? 'চালু (ON)' : 'বন্ধ (OFF)'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleExportExcel}
            className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            title="স্পিন হুইলের সকল কাস্টমারের ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড করুন"
          >
            <Download className="w-3.5 h-3.5" />
            <span>১-ক্লিক Excel ডাউনলোড ({unifiedLeads.length})</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            title="স্পিন হুইলের সকল কাস্টমারের ডাটা Google Sheet / CSV ফাইলে ডাউনলোড করুন"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Google Sheet (CSV)</span>
          </button>

          <button
            type="button"
            onClick={handleResetDeviceSpinLocks}
            className="px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-colors"
            title="এই ডিভাইসে আবার স্পিন টেস্ট করার জন্য লক রিসেট করুন"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>টেস্ট লক রিসেট</span>
          </button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">মোট স্পিন কাস্টমার</p>
            <p className="text-xl sm:text-2xl font-black text-slate-900 font-mono">
              {unifiedLeads.length} জন
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center shrink-0">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">ওয়েবসাইট স্পিন</p>
            <p className="text-xl sm:text-2xl font-black text-indigo-700 font-mono">
              {totalWebsiteLeads} জন
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center shrink-0">
            <Rocket className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">ল্যান্ডিং পেজ স্পিন</p>
            <p className="text-xl sm:text-2xl font-black text-amber-700 font-mono">
              {totalLandingLeads} জন
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center shrink-0">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">অর্ডার সম্পন্ন করেছেন</p>
            <p className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">
              {totalConvertedLeads} জন
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-2 shadow-2xs flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setActiveTab('leads')}
          className={`flex-1 min-w-[180px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-all ${
            activeTab === 'leads'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <PhoneCall className="w-4 h-4" />
          <span>📋 স্পিন কাস্টমার ডাটা ও নাম্বার ({unifiedLeads.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('website_settings')}
          className={`flex-1 min-w-[180px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-all ${
            activeTab === 'website_settings'
              ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white shadow-sm'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>🌐 ওয়েবসাইট স্পিন সেটিংস (৪ আনলক, ২ লক)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('landing_settings')}
          className={`flex-1 min-w-[180px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-all ${
            activeTab === 'landing_settings'
              ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-sm'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Rocket className="w-4 h-4" />
          <span>🚀 ল্যান্ডিং পেজ স্পিন সেটিংস (৪ আনলক, ২ লক)</span>
        </button>
      </div>

      {/* TAB 1: UNIFIED SPIN CUSTOMER LEADS TABLE */}
      {activeTab === 'leads' && (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs overflow-hidden">
          <div className="p-4 sm:p-5 bg-slate-50/70 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={leadSearch}
                onChange={e => setLeadSearch(e.target.value)}
                placeholder="কাস্টমারের নাম, মোবাইল নাম্বার, পুরস্কার বা কুপন কোড দিয়ে খুঁজুন..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-300 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:border-emerald-600"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={sourceFilter}
                onChange={e => setSourceFilter(e.target.value as 'all' | 'website' | 'landing')}
                className="px-3 py-2.5 rounded-xl bg-white border border-slate-300 text-xs font-extrabold text-slate-800"
              >
                <option value="all">সব সোর্স ({unifiedLeads.length})</option>
                <option value="website">শুধু ওয়েবসাইট ({totalWebsiteLeads})</option>
                <option value="landing">শুধু ল্যান্ডিং পেজ ({totalLandingLeads})</option>
              </select>

              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value as 'all' | 'ordered' | 'pending')}
                className="px-3 py-2.5 rounded-xl bg-white border border-slate-300 text-xs font-extrabold text-slate-800"
              >
                <option value="all">সব কাস্টমার</option>
                <option value="ordered">অর্ডার করেছেন ({totalConvertedLeads})</option>
                <option value="pending">
                  এখনো অর্ডার করেননি ({unifiedLeads.length - totalConvertedLeads})
                </option>
              </select>

              <button
                type="button"
                onClick={handleExportExcel}
                className="px-3.5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title="স্পিন কাস্টমারদের ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3.5 h-3.5" />
                <span>১-ক্লিক Excel ডাউনলোড</span>
              </button>

              <button
                type="button"
                onClick={handleExportCsv}
                className="px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title="স্পিন কাস্টমারদের ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Google Sheet (CSV)</span>
              </button>
            </div>
          </div>

          {filteredLeads.length === 0 ? (
            <div className="p-12 text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
                <Gift className="w-7 h-7" />
              </div>
              <h3 className="text-base font-extrabold text-slate-800">
                এখনো কোনো স্পিন কাস্টমার ডাটা পাওয়া যায়নি
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                যখনই কোনো ভিজিটর ওয়েবসাইট বা ল্যান্ডিং পেজে নাম ও মোবাইল নাম্বার দিয়ে স্পিন করবেন, সাথে সাথে সেই তথ্য এখানে এবং মূল ডাটাবেসে জমা হয়ে যাবে।
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-100/90 text-slate-700 font-extrabold border-b border-slate-200">
                    <th className="py-3.5 px-4">কাস্টমারের নাম</th>
                    <th className="py-3.5 px-4">মোবাইল নাম্বার</th>
                    <th className="py-3.5 px-4">কোথা থেকে স্পিন করেছেন</th>
                    <th className="py-3.5 px-4">জেতা অফার ও কুপন</th>
                    <th className="py-3.5 px-4">অর্ডার স্ট্যাটাস</th>
                    <th className="py-3.5 px-4">তারিখ ও সময়</th>
                    <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {filteredLeads.map(lead => {
                    const waPhone = lead.customerPhone.startsWith('0')
                      ? `88${lead.customerPhone}`
                      : lead.customerPhone;
                    const waMessage = encodeURIComponent(
                      `আসসালামু আলাইকুম ${lead.customerName}, আপনি আমাদের স্পিন হুইলে "${lead.rewardLabel}" (কুপন: ${lead.couponCode}) জিতেছেন! আপনার অফারটি ব্যবহার করে অর্ডার করতে চাইলে জানান।`
                    );
                    return (
                      <tr key={lead.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-extrabold text-slate-900">
                          {lead.customerName}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="inline-flex items-center gap-1.5 font-mono font-extrabold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                            <span>{lead.customerPhone}</span>
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard?.writeText(lead.customerPhone);
                                showToast('মোবাইল নাম্বার কপি হয়েছে!', 'info');
                              }}
                              className="text-indigo-500 hover:text-indigo-800 cursor-pointer"
                              title="নাম্বার কপি করুন"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          {lead.source === 'landing' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-extrabold">
                              <Rocket className="w-3 h-3" /> ল্যান্ডিং পেজ
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-sky-50 text-sky-800 border border-sky-200 text-[11px] font-extrabold">
                              <Globe className="w-3 h-3" /> মূল ওয়েবসাইট
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 text-xs font-extrabold">
                              🎁 {lead.rewardLabel}
                            </span>
                            {lead.couponCode && (
                              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-mono text-[11px] font-bold">
                                {lead.couponCode}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          {lead.usedOrderNo ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-extrabold">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>
                                অর্ডার #{lead.usedOrderNo}{' '}
                                {lead.orderGrandTotal
                                  ? `(${formatCurrency(lead.orderGrandTotal)})`
                                  : ''}
                              </span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-[11px] font-bold">
                              এখনো অর্ডার করেননি
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-500">
                          {new Date(lead.createdAt).toLocaleString('bn-BD', {
                            dateStyle: 'medium',
                            timeStyle: 'short'
                          })}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <a
                              href={`tel:${lead.customerPhone}`}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold inline-flex items-center gap-1"
                              title="সরাসরি কল করুন"
                            >
                              <PhoneCall className="w-3 h-3" />
                              <span>কল</span>
                            </a>
                            <a
                              href={`https://wa.me/${waPhone}?text=${waMessage}`}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold inline-flex items-center gap-1"
                              title="হোয়াটসঅ্যাপে মেসেজ পাঠান"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>WA</span>
                            </a>
                            <button
                              type="button"
                              onClick={() => handleDeleteLead(lead.id)}
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: WEBSITE SPIN WHEEL SETTINGS */}
      {activeTab === 'website_settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-2xs space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-rose-600" />
                  <span>মূল ওয়েবসাইট স্পিন হুইল সেটিংস</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  হুইলের লেখা এবং ৬টি অফার (৪টি আনলক ও ২টি লক) এখান থেকে কাস্টমাইজ করুন
                </p>
              </div>
              <button
                type="button"
                onClick={handleSaveWebsiteSpinSettings}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-extrabold flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>সেটিংস সংরক্ষণ করুন</span>
              </button>
            </div>

            {/* Texts & Timing */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 bg-amber-50/50 border border-amber-200/80 rounded-2xl p-4 text-xs">
              <div>
                <label className="block font-extrabold text-slate-700 mb-1">
                  উপরের ব্যাজ টেক্সট:
                </label>
                <input
                  type="text"
                  value={webDraft.badgeText}
                  onChange={e => setWebDraft(prev => ({ ...prev, badgeText: e.target.value }))}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="block font-extrabold text-slate-700 mb-1">
                  কত সেকেন্ড পর অটো ভেসে উঠবে?
                </label>
                <select
                  value={webDraft.autoPopupDelaySec}
                  onChange={e =>
                    setWebDraft(prev => ({
                      ...prev,
                      autoPopupDelaySec: Number(e.target.value) || 4
                    }))
                  }
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                >
                  <option value={2}>২ সেকেন্ড পর</option>
                  <option value={4}>৪ সেকেন্ড পর (প্রস্তাবিত)</option>
                  <option value={6}>৬ সেকেন্ড পর</option>
                  <option value={10}>১০ সেকেন্ড পর</option>
                </select>
              </div>
              <div>
                <label className="block font-extrabold text-slate-700 mb-1">
                  পুনরায় পপআপ বিরতি (কাস্টমার দেখবে না):
                </label>
                <select
                  value={webDraft.cooldownDays}
                  onChange={e =>
                    setWebDraft(prev => ({
                      ...prev,
                      cooldownDays: Number(e.target.value) || 7
                    }))
                  }
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                >
                  <option value={7}>৭ দিন পর</option>
                  <option value={3}>৩ দিন পর</option>
                  <option value={1}>১ দিন পর</option>
                  <option value={15}>১৫ দিন পর</option>
                </select>
              </div>
              <div className="sm:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-extrabold text-slate-700 mb-1">
                    মূল শিরোনাম (Title):
                  </label>
                  <input
                    type="text"
                    value={webDraft.titleText}
                    onChange={e => setWebDraft(prev => ({ ...prev, titleText: e.target.value }))}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-extrabold text-slate-700 mb-1">
                    সাব-টাইটেল (Subtitle):
                  </label>
                  <input
                    type="text"
                    value={webDraft.subtitleText}
                    onChange={e =>
                      setWebDraft(prev => ({ ...prev, subtitleText: e.target.value }))
                    }
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-semibold text-slate-800"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-extrabold text-slate-700 mb-1">
                    পুরস্কার গ্রহণের বাটন টেক্সট (Claim Button Text):
                  </label>
                  <input
                    type="text"
                    value={webDraft.claimButtonText}
                    onChange={e =>
                      setWebDraft(prev => ({ ...prev, claimButtonText: e.target.value }))
                    }
                    placeholder="অফারটি গ্রহণ করে অর্ডার করুন"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-rose-700"
                  />
                </div>
              </div>
            </div>

            {/* 6 Offers Slice Editor (4 Unlocked + 2 Locked) */}
            <div className="space-y-3 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    🎡 হুইলের অফার স্লাইস সমূহ ({webDraft.slices.length}টি):
                  </h3>
                  <p className="text-[11px] font-semibold text-slate-600 mt-0.5">
                    🔓 আনলক ({webDraft.slices.filter(s => !s.locked).length}টি): কাস্টমার বারবার পাবে • 🔒 লক ({webDraft.slices.filter(s => s.locked).length}টি): চাকায় লেখা থাকবে কিন্তু কেউ পাবে না
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setWebDraft(prev => ({
                        ...prev,
                        slices: DEFAULT_SPIN_WHEEL_SLICES.map(s => ({ ...s }))
                      }))
                    }
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                  >
                    ডিফল্ট ৬টি (৪ আনলক, ২ লক)
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setWebDraft(prev => ({
                        ...prev,
                        slices: [
                          ...prev.slices,
                          {
                            id: `sw_${Date.now()}`,
                            shortLabel: '৳৪০ ছাড়',
                            label: '৳৪০ স্পেশাল ছাড়',
                            type: 'flat',
                            value: 40,
                            color: '#e11d48',
                            code: 'SPIN40',
                            locked: false
                          }
                        ]
                      }))
                    }
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> নতুন স্লাইস
                  </button>
                </div>
              </div>

              <div className="space-y-2.5">
                {webDraft.slices.map((slice, sIdx) => (
                  <div
                    key={slice.id || sIdx}
                    className={`p-3 rounded-2xl border grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center ${
                      slice.locked
                        ? 'bg-rose-50/50 border-rose-200'
                        : 'bg-slate-50/70 border-slate-200'
                    }`}
                  >
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        চাকার ছোট লেখা
                      </label>
                      <input
                        type="text"
                        value={slice.shortLabel}
                        onChange={e => {
                          const val = e.target.value;
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, shortLabel: val } : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-extrabold text-slate-900"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        পুরস্কারের পূর্ণ নাম
                      </label>
                      <input
                        type="text"
                        value={slice.label}
                        onChange={e => {
                          const val = e.target.value;
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, label: val } : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        ছাড়ের ধরন
                      </label>
                      <select
                        value={slice.type}
                        onChange={e => {
                          const nextType = e.target.value as SpinWheelSliceConfig['type'];
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx
                                ? {
                                    ...it,
                                    type: nextType,
                                    value:
                                      nextType === 'free_delivery' || nextType === 'none'
                                        ? 0
                                        : it.value || 20
                                  }
                                : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-800"
                      >
                        <option value="flat">টাকা ছাড় (৳)</option>
                        <option value="percent">শতাংশ ছাড় (%)</option>
                        <option value="free_delivery">ফ্রি ডেলিভারি</option>
                      </select>
                    </div>
                    <div className="sm:col-span-1">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        মান
                      </label>
                      <input
                        type="number"
                        min={0}
                        disabled={slice.type === 'free_delivery' || slice.type === 'none'}
                        value={slice.value}
                        onChange={e => {
                          const val = Number(e.target.value) || 0;
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, value: val } : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold disabled:bg-slate-100"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        লক / আনলক স্ট্যাটাস
                      </label>
                      <button
                        type="button"
                        onClick={() =>
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, locked: !it.locked } : it
                            )
                          }))
                        }
                        className={`w-full px-2.5 py-2 rounded-lg text-[11px] font-extrabold border flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                          slice.locked
                            ? 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200'
                            : 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200'
                        }`}
                      >
                        {slice.locked ? (
                          <>
                            <Lock className="w-3 h-3" />
                            <span>লক (পাবে না)</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="w-3 h-3" />
                            <span>আনলক (পাবে)</span>
                          </>
                        )}
                      </button>
                    </div>
                    <div className="sm:col-span-2 flex items-end gap-1.5 pt-3 sm:pt-4">
                      <input
                        type="text"
                        value={slice.code}
                        onChange={e => {
                          const val = e.target.value.toUpperCase();
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, code: val } : it
                            )
                          }));
                        }}
                        placeholder="CODE"
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold uppercase"
                      />
                      <input
                        type="color"
                        value={slice.color}
                        onChange={e => {
                          const val = e.target.value;
                          setWebDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, color: val } : it
                            )
                          }));
                        }}
                        className="w-8 h-8 rounded cursor-pointer border border-slate-300 shrink-0"
                      />
                      {webDraft.slices.length > 2 && (
                        <button
                          type="button"
                          onClick={() =>
                            setWebDraft(prev => ({
                              ...prev,
                              slices: prev.slices.filter((_, i) => i !== sIdx)
                            }))
                          }
                          className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-4">
            {renderLiveWheelPreview(webDraft, 'মূল ওয়েবসাইট স্পিন')}
          </div>
        </div>
      )}

      {/* TAB 3: LANDING PAGE SPIN WHEEL SETTINGS */}
      {activeTab === 'landing_settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-2xs space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
                  <Rocket className="w-5 h-5 text-indigo-600" />
                  <span>ল্যান্ডিং পেজ স্পিন হুইল সেটিংস</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  সকল ল্যান্ডিং পেজের জন্য স্পিন হুইলের লেখা এবং ৬টি অফার (৪টি আনলক ও ২টি লক) কাস্টমাইজ করুন
                </p>
              </div>
              <button
                type="button"
                onClick={handleSaveLandingSpinSettings}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs sm:text-sm font-extrabold flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>সেটিংস সংরক্ষণ করুন</span>
              </button>
            </div>

            {/* Per-Landing Product Quick Toggles */}
            {landingProducts.length > 0 && (
              <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-200/80 space-y-2.5">
                <p className="text-xs font-extrabold text-indigo-950">
                  ল্যান্ডিং পেজ প্রোডাক্ট অনুযায়ী স্পিন হুইল ON / OFF:
                </p>
                <div className="flex flex-wrap gap-2">
                  {landingProducts.map(lp => {
                    const isOn = lp.landingSpinWheelEnabled !== false;
                    return (
                      <button
                        key={lp.id}
                        type="button"
                        onClick={() => {
                          updateProduct(lp.id, { landingSpinWheelEnabled: !isOn });
                          showToast(
                            !isOn
                              ? `"${lp.nameBn}" ল্যান্ডিং পেজে স্পিন চালু করা হয়েছে`
                              : `"${lp.nameBn}" ল্যান্ডিং পেজে স্পিন বন্ধ করা হয়েছে`,
                            'info'
                          );
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 cursor-pointer transition-colors ${
                          isOn
                            ? 'bg-white text-emerald-800 border-emerald-300 shadow-2xs'
                            : 'bg-slate-100 text-slate-500 border-slate-300'
                        }`}
                      >
                        <span>{lp.nameBn}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                            isOn
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          {isOn ? 'ON' : 'OFF'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Texts & Timing */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 bg-amber-50/50 border border-amber-200/80 rounded-2xl p-4 text-xs">
              <div>
                <label className="block font-extrabold text-slate-700 mb-1">
                  উপরের ব্যাজ টেক্সট:
                </label>
                <input
                  type="text"
                  value={lpDraft.badgeText}
                  onChange={e => setLpDraft(prev => ({ ...prev, badgeText: e.target.value }))}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="block font-extrabold text-slate-700 mb-1">
                  কত সেকেন্ড পর অটো ভেসে উঠবে?
                </label>
                <select
                  value={lpDraft.autoPopupDelaySec}
                  onChange={e =>
                    setLpDraft(prev => ({
                      ...prev,
                      autoPopupDelaySec: Number(e.target.value) || 4
                    }))
                  }
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                >
                  <option value={2}>২ সেকেন্ড পর</option>
                  <option value={4}>৪ সেকেন্ড পর (প্রস্তাবিত)</option>
                  <option value={6}>৬ সেকেন্ড পর</option>
                  <option value={10}>১০ সেকেন্ড পর</option>
                </select>
              </div>
              <div>
                <label className="block font-extrabold text-slate-700 mb-1">
                  পুনরায় পপআপ বিরতি (কাস্টমার দেখবে না):
                </label>
                <select
                  value={lpDraft.cooldownDays}
                  onChange={e =>
                    setLpDraft(prev => ({
                      ...prev,
                      cooldownDays: Number(e.target.value) || 7
                    }))
                  }
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                >
                  <option value={7}>৭ দিন পর</option>
                  <option value={3}>৩ দিন পর</option>
                  <option value={1}>১ দিন পর</option>
                  <option value={15}>১৫ দিন পর</option>
                </select>
              </div>
              <div className="sm:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-extrabold text-slate-700 mb-1">
                    মূল শিরোনাম (Title):
                  </label>
                  <input
                    type="text"
                    value={lpDraft.titleText}
                    onChange={e => setLpDraft(prev => ({ ...prev, titleText: e.target.value }))}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-extrabold text-slate-700 mb-1">
                    সাব-টাইটেল (Subtitle):
                  </label>
                  <input
                    type="text"
                    value={lpDraft.subtitleText}
                    onChange={e =>
                      setLpDraft(prev => ({ ...prev, subtitleText: e.target.value }))
                    }
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-semibold text-slate-800"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-extrabold text-slate-700 mb-1">
                    পুরস্কার গ্রহণের বাটন টেক্সট (Claim Button Text):
                  </label>
                  <input
                    type="text"
                    value={lpDraft.claimButtonText}
                    onChange={e =>
                      setLpDraft(prev => ({ ...prev, claimButtonText: e.target.value }))
                    }
                    placeholder="অফারটি গ্রহণ করে অর্ডার করুন"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-extrabold text-rose-700"
                  />
                </div>
              </div>
            </div>

            {/* 6 Offers Slice Editor (4 Unlocked + 2 Locked) */}
            <div className="space-y-3 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">
                    🎡 ল্যান্ডিং পেজ হুইলের অফার স্লাইস সমূহ ({lpDraft.slices.length}টি):
                  </h3>
                  <p className="text-[11px] font-semibold text-slate-600 mt-0.5">
                    🔓 আনলক ({lpDraft.slices.filter(s => !s.locked).length}টি): কাস্টমার বারবার পাবে • 🔒 লক ({lpDraft.slices.filter(s => s.locked).length}টি): চাকায় লেখা থাকবে কিন্তু কেউ পাবে না
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setLpDraft(prev => ({
                        ...prev,
                        slices: DEFAULT_LANDING_SPIN_WHEEL_SLICES.map(s => ({ ...s }))
                      }))
                    }
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                  >
                    ডিফল্ট ৬টি (৪ আনলক, ২ লক)
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setLpDraft(prev => ({
                        ...prev,
                        slices: [
                          ...prev.slices,
                          {
                            id: `lp_sw_${Date.now()}`,
                            shortLabel: '৳৪০ ছাড়',
                            label: '৳৪০ স্পেশাল ডিসকাউন্ট',
                            type: 'flat',
                            value: 40,
                            color: '#059669',
                            code: 'LP40',
                            locked: false
                          }
                        ]
                      }))
                    }
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> নতুন স্লাইস
                  </button>
                </div>
              </div>

              <div className="space-y-2.5">
                {lpDraft.slices.map((slice, sIdx) => (
                  <div
                    key={slice.id || sIdx}
                    className={`p-3 rounded-2xl border grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center ${
                      slice.locked
                        ? 'bg-rose-50/50 border-rose-200'
                        : 'bg-slate-50/70 border-slate-200'
                    }`}
                  >
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        চাকার ছোট লেখা
                      </label>
                      <input
                        type="text"
                        value={slice.shortLabel}
                        onChange={e => {
                          const val = e.target.value;
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, shortLabel: val } : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-extrabold text-slate-900"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        পুরস্কারের পূর্ণ নাম
                      </label>
                      <input
                        type="text"
                        value={slice.label}
                        onChange={e => {
                          const val = e.target.value;
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, label: val } : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-800"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        ছাড়ের ধরন
                      </label>
                      <select
                        value={slice.type}
                        onChange={e => {
                          const nextType = e.target.value as SpinWheelSliceConfig['type'];
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx
                                ? {
                                    ...it,
                                    type: nextType,
                                    value:
                                      nextType === 'free_delivery' || nextType === 'none'
                                        ? 0
                                        : it.value || 20
                                  }
                                : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-800"
                      >
                        <option value="flat">টাকা ছাড় (৳)</option>
                        <option value="percent">শতাংশ ছাড় (%)</option>
                        <option value="free_delivery">ফ্রি ডেলিভারি</option>
                      </select>
                    </div>
                    <div className="sm:col-span-1">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        মান
                      </label>
                      <input
                        type="number"
                        min={0}
                        disabled={slice.type === 'free_delivery' || slice.type === 'none'}
                        value={slice.value}
                        onChange={e => {
                          const val = Number(e.target.value) || 0;
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, value: val } : it
                            )
                          }));
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold disabled:bg-slate-100"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                        লক / আনলক স্ট্যাটাস
                      </label>
                      <button
                        type="button"
                        onClick={() =>
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, locked: !it.locked } : it
                            )
                          }))
                        }
                        className={`w-full px-2.5 py-2 rounded-lg text-[11px] font-extrabold border flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                          slice.locked
                            ? 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200'
                            : 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200'
                        }`}
                      >
                        {slice.locked ? (
                          <>
                            <Lock className="w-3 h-3" />
                            <span>লক (পাবে না)</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="w-3 h-3" />
                            <span>আনলক (পাবে)</span>
                          </>
                        )}
                      </button>
                    </div>
                    <div className="sm:col-span-2 flex items-end gap-1.5 pt-3 sm:pt-4">
                      <input
                        type="text"
                        value={slice.code}
                        onChange={e => {
                          const val = e.target.value.toUpperCase();
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, code: val } : it
                            )
                          }));
                        }}
                        placeholder="CODE"
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold uppercase"
                      />
                      <input
                        type="color"
                        value={slice.color}
                        onChange={e => {
                          const val = e.target.value;
                          setLpDraft(prev => ({
                            ...prev,
                            slices: prev.slices.map((it, i) =>
                              i === sIdx ? { ...it, color: val } : it
                            )
                          }));
                        }}
                        className="w-8 h-8 rounded cursor-pointer border border-slate-300 shrink-0"
                      />
                      {lpDraft.slices.length > 2 && (
                        <button
                          type="button"
                          onClick={() =>
                            setLpDraft(prev => ({
                              ...prev,
                              slices: prev.slices.filter((_, i) => i !== sIdx)
                            }))
                          }
                          className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-4">
            {renderLiveWheelPreview(lpDraft, 'ল্যান্ডিং পেজ স্পিন')}
          </div>
        </div>
      )}
    </div>
  );
};
