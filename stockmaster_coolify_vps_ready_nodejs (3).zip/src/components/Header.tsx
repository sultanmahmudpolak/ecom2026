import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useApp, normalizeBdPhone } from '../context/AppContext';
import { APP_VERSION } from '../config/version';
import {
  Search,
  Menu,
  Check,
  ChevronDown,
  LogOut,
  ShieldCheck,
  X,
  ShoppingBag,
  AlertTriangle,
  ExternalLink,
  Boxes,
  Sun,
  Moon,
  Phone,
  MapPin,
  User as UserIcon,
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  Truck,
  Package,
  MessageCircle,
  ArrowRight,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import { UserRole, OnlineOrder, OnlineOrderStatus } from '../types';

interface HeaderProps {
  onOpenMobileMenu: () => void;
  isDesktopSidebarOpen?: boolean;
  onToggleDesktopSidebar?: () => void;
  onNavigate: (view: string) => void;
  onOpenStorefront?: () => void;
  adminTheme?: 'light' | 'dark';
  onSetAdminTheme?: (theme: 'light' | 'dark') => void;
}

interface SearchedCustomerSummary {
  phoneKey: string;
  displayPhone: string;
  name: string;
  address: string;
  area: string;
  customerId?: string;
  totalOrders: number;
  deliveredCount: number;
  cancelledCount: number;
  pendingOrProcessingCount: number;
  incompleteCount: number;
  totalSpent: number;
  currentDue: number;
  orders: OnlineOrder[];
}

// Convert Bangla digits (০-৯) to English digits (0-9) so mobile/order search works in both keyboards
const normalizeSearchDigits = (input: string): string => {
  const banglaDigits: Record<string, string> = {
    '০': '0',
    '১': '1',
    '২': '2',
    '৩': '3',
    '৪': '4',
    '৫': '5',
    '৬': '6',
    '৭': '7',
    '৮': '8',
    '৯': '9'
  };
  return input.replace(/[০-৯]/g, d => banglaDigits[d] || d);
};

export const Header: React.FC<HeaderProps> = ({
  onOpenMobileMenu,
  isDesktopSidebarOpen = true,
  onToggleDesktopSidebar,
  onNavigate,
  onOpenStorefront,
  adminTheme = 'light',
  onSetAdminTheme
}) => {
  const {
    language,
    setLanguage,
    currentBusiness,
    users,
    currentUser,
    quickLogin,
    logout,
    globalSearch,
    setGlobalSearch,
    onlineOrders,
    updateOnlineOrderStatus,
    incompleteOrders,
    customers,
    products,
    formatCurrency,
    formatDate
  } = useApp();

  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [activeCustomerModal, setActiveCustomerModal] = useState<{
    customer: SearchedCustomerSummary;
    highlightedOrderId?: string;
  } | null>(null);

  const desktopSearchRef = useRef<HTMLDivElement>(null);
  const mobileSearchRef = useRef<HTMLDivElement>(null);

  // Close search dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      const inDesktop = desktopSearchRef.current?.contains(target);
      const inMobile = mobileSearchRef.current?.contains(target);
      if (!inDesktop && !inMobile) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const pendingOrdersCount = onlineOrders.filter(
    o => o.orderStatus === 'pending'
  ).length;

  const abandonedCount = incompleteOrders.filter(
    inc => inc.status === 'abandoned' || inc.status === 'contacted'
  ).length;

  const roleLabels: Record<UserRole, string> = {
    developer: 'System Developer',
    super_admin: 'Super Admin (Owner)',
    store_manager: 'Store Manager',
    cashier: 'Order Executive',
    distribution_mgr: 'Fulfilment Manager',
    sales_rep: 'Sales Executive'
  };

  const statusBadgeConfig: Record<
    OnlineOrderStatus,
    { labelBn: string; className: string }
  > = {
    pending: {
      labelBn: 'Pending',
      className: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-800'
    },
    confirmed: {
      labelBn: 'Confirmed',
      className: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-950/70 dark:text-blue-300 dark:border-blue-800'
    },
    packaging: {
      labelBn: 'Packaging',
      className: 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-950/70 dark:text-indigo-300 dark:border-indigo-800'
    },
    dispatched: {
      labelBn: 'Dispatched',
      className: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/70 dark:text-purple-300 dark:border-purple-800'
    },
    delivered: {
      labelBn: 'Delivered',
      className: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-800'
    },
    cancelled: {
      labelBn: 'Cancelled',
      className: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-800'
    }
  };

  // Build unified customer map by normalized phone across customers + onlineOrders + incompleteOrders
  const customerSummaryByPhone = useMemo(() => {
    const map = new Map<string, SearchedCustomerSummary>();

    customers.forEach(c => {
      const key = normalizeBdPhone(c.phone || '') || c.id;
      map.set(key, {
        phoneKey: key,
        displayPhone: c.phone || '',
        name: c.name || 'অজ্ঞাত কাস্টমার',
        address: c.address || '',
        area: c.route || '',
        customerId: c.id,
        totalOrders: 0,
        deliveredCount: 0,
        cancelledCount: 0,
        pendingOrProcessingCount: 0,
        incompleteCount: 0,
        totalSpent: 0,
        currentDue: c.currentDue || 0,
        orders: []
      });
    });

    onlineOrders.forEach(o => {
      const key = normalizeBdPhone(o.customerPhone || '') || `order_${o.id}`;
      let entry = map.get(key);
      if (!entry) {
        entry = {
          phoneKey: key,
          displayPhone: o.customerPhone || '',
          name: o.customerName || 'অনলাইন কাস্টমার',
          address: o.deliveryAddress || '',
          area: o.deliveryArea || '',
          customerId: o.customerId,
          totalOrders: 0,
          deliveredCount: 0,
          cancelledCount: 0,
          pendingOrProcessingCount: 0,
          incompleteCount: 0,
          totalSpent: 0,
          currentDue: 0,
          orders: []
        };
        map.set(key, entry);
      } else {
        if (!entry.address && o.deliveryAddress) entry.address = o.deliveryAddress;
        if (!entry.area && o.deliveryArea) entry.area = o.deliveryArea;
        if ((!entry.name || entry.name === 'অজ্ঞাত কাস্টমার') && o.customerName) {
          entry.name = o.customerName;
        }
      }

      entry.totalOrders += 1;
      entry.orders.push(o);
      if (o.orderStatus === 'delivered') {
        entry.deliveredCount += 1;
        entry.totalSpent += o.grandTotal || 0;
      } else if (o.orderStatus === 'cancelled') {
        entry.cancelledCount += 1;
      } else {
        entry.pendingOrProcessingCount += 1;
        entry.totalSpent += o.grandTotal || 0;
      }
    });

    incompleteOrders.forEach(inc => {
      const key = normalizeBdPhone(inc.customerPhone || '');
      if (!key) return;
      let entry = map.get(key);
      if (!entry) {
        entry = {
          phoneKey: key,
          displayPhone: inc.customerPhone || '',
          name: inc.customerName || 'অসম্পূর্ণ অর্ডার কাস্টমার',
          address: inc.deliveryAddress || '',
          area: inc.deliveryArea || '',
          totalOrders: 0,
          deliveredCount: 0,
          cancelledCount: 0,
          pendingOrProcessingCount: 0,
          incompleteCount: 1,
          totalSpent: 0,
          currentDue: 0,
          orders: []
        };
        map.set(key, entry);
      } else {
        entry.incompleteCount += 1;
        if (!entry.address && inc.deliveryAddress) entry.address = inc.deliveryAddress;
      }
    });

    return map;
  }, [customers, onlineOrders, incompleteOrders]);

  // Compute live search results for Orders, Customers, Incomplete Orders, and Products
  const searchResults = useMemo(() => {
    const rawQuery = normalizeSearchDigits(globalSearch).trim();
    if (!rawQuery) {
      return {
        orders: [],
        customers: [],
        incomplete: [],
        products: [],
        totalCount: 0
      };
    }

    const qLower = rawQuery.toLowerCase().replace(/^#/, '');
    const qDigits = rawQuery.replace(/\D/g, '');

    // 1. Match Online Orders (by Order No, Invoice No, Customer Phone, Customer Name, Address, or Courier Tracking)
    const matchedOrders = onlineOrders
      .filter(o => {
        const orderNoLower = (o.orderNo || '').toLowerCase();
        const invoiceLower = (o.invoiceNo || '').toLowerCase();
        const phoneNorm = normalizeBdPhone(o.customerPhone || '');
        const phoneRaw = normalizeSearchDigits(o.customerPhone || '');
        const nameLower = (o.customerName || '').toLowerCase();
        const addrLower = (o.deliveryAddress || '').toLowerCase();
        const trackingLower = (o.courierTrackingCode || o.courierConsignmentId || '').toLowerCase();

        if (orderNoLower.includes(qLower) || invoiceLower.includes(qLower)) return true;
        if (qDigits.length >= 3 && (phoneNorm.includes(qDigits) || phoneRaw.includes(qDigits) || orderNoLower.replace(/\D/g, '').includes(qDigits))) {
          return true;
        }
        if (nameLower.includes(qLower) || addrLower.includes(qLower)) return true;
        if (trackingLower && trackingLower.includes(qLower)) return true;
        return false;
      })
      .slice(0, 8);

    // 2. Match Customers (including any customer whose order matched or whose phone/name matched)
    const matchedOrderPhones = new Set(
      matchedOrders.map(o => normalizeBdPhone(o.customerPhone || '')).filter(Boolean)
    );

    const matchedCustomers = Array.from(customerSummaryByPhone.values())
      .filter(c => {
        if (matchedOrderPhones.has(c.phoneKey)) return true;
        const phoneRaw = normalizeSearchDigits(c.displayPhone || '');
        if (qDigits.length >= 3 && (c.phoneKey.includes(qDigits) || phoneRaw.includes(qDigits))) {
          return true;
        }
        if (
          c.name.toLowerCase().includes(qLower) ||
          c.address.toLowerCase().includes(qLower)
        ) {
          return true;
        }
        return false;
      })
      .slice(0, 6);

    // 3. Match Incomplete Orders
    const matchedIncomplete = incompleteOrders
      .filter(inc => {
        const phoneNorm = normalizeBdPhone(inc.customerPhone || '');
        const phoneRaw = normalizeSearchDigits(inc.customerPhone || '');
        if (qDigits.length >= 3 && (phoneNorm.includes(qDigits) || phoneRaw.includes(qDigits))) {
          return true;
        }
        return (
          (inc.customerName || '').toLowerCase().includes(qLower) ||
          (inc.deliveryAddress || '').toLowerCase().includes(qLower)
        );
      })
      .slice(0, 4);

    // 4. Match Products (by SKU, Name Bn, Name En)
    const matchedProducts = products
      .filter(p => {
        return (
          (p.sku || '').toLowerCase().includes(qLower) ||
          (p.nameBn || '').toLowerCase().includes(qLower) ||
          (p.nameEn || '').toLowerCase().includes(qLower)
        );
      })
      .slice(0, 4);

    return {
      orders: matchedOrders,
      customers: matchedCustomers,
      incomplete: matchedIncomplete,
      products: matchedProducts,
      totalCount:
        matchedOrders.length +
        matchedCustomers.length +
        matchedIncomplete.length +
        matchedProducts.length
    };
  }, [globalSearch, onlineOrders, customerSummaryByPhone, incompleteOrders, products]);

  // Keep activeCustomerModal live when order status changes
  const liveModalData = useMemo(() => {
    if (!activeCustomerModal) return null;
    const latest =
      customerSummaryByPhone.get(activeCustomerModal.customer.phoneKey) ||
      activeCustomerModal.customer;
    return {
      customer: latest,
      highlightedOrderId: activeCustomerModal.highlightedOrderId
    };
  }, [activeCustomerModal, customerSummaryByPhone]);

  const handleOpenOrdersTab = (tab: 'orders' | 'incomplete', searchPrefill?: string) => {
    try {
      sessionStorage.setItem('sm_orders_initial_tab', tab);
      if (typeof searchPrefill === 'string') {
        sessionStorage.setItem('sm_orders_search_prefill', searchPrefill);
      }
    } catch {
      // ignore storage errors
    }
    setIsSearchOpen(false);
    setShowMobileSearch(false);
    onNavigate('online_orders');
  };

  const handleOpenCustomerDetailsModal = (
    customerSummary: SearchedCustomerSummary,
    highlightedOrderId?: string
  ) => {
    setActiveCustomerModal({
      customer: customerSummary,
      highlightedOrderId
    });
    setIsSearchOpen(false);
  };

  const handleOpenOrderCustomerModal = (order: OnlineOrder) => {
    const key = normalizeBdPhone(order.customerPhone || '') || `order_${order.id}`;
    const summary = customerSummaryByPhone.get(key) || {
      phoneKey: key,
      displayPhone: order.customerPhone || '',
      name: order.customerName || 'অনলাইন কাস্টমার',
      address: order.deliveryAddress || '',
      area: order.deliveryArea || '',
      customerId: order.customerId,
      totalOrders: 1,
      deliveredCount: order.orderStatus === 'delivered' ? 1 : 0,
      cancelledCount: order.orderStatus === 'cancelled' ? 1 : 0,
      pendingOrProcessingCount:
        order.orderStatus !== 'delivered' && order.orderStatus !== 'cancelled' ? 1 : 0,
      incompleteCount: 0,
      totalSpent: order.grandTotal || 0,
      currentDue: 0,
      orders: [order]
    };
    handleOpenCustomerDetailsModal(summary, order.id);
  };

  const renderSearchDropdownContent = () => {
    const trimmed = globalSearch.trim();
    if (!trimmed) return null;

    if (searchResults.totalCount === 0) {
      return (
        <div className="p-5 text-center space-y-1.5">
          <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
            No orders or customers found for "{trimmed}"
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            Search by mobile number (e.g., 017...) or order number (e.g., ORD-1001).
          </p>
        </div>
      );
    }

    return (
      <div className="max-h-[78vh] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
        {/* Search Results Summary Header */}
        <div className="sticky top-0 z-10 px-4 py-2.5 bg-slate-50/95 dark:bg-slate-800/95 backdrop-blur-xs border-b border-slate-200/80 dark:border-slate-700 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-extrabold text-slate-800 dark:text-slate-100">
            <Search className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>
              Search Results: <span className="text-emerald-600 dark:text-emerald-400 font-mono">{searchResults.totalCount}</span> records found
            </span>
          </div>
          <button
            type="button"
            onClick={() => setIsSearchOpen(false)}
            className="px-2 py-1 rounded-lg text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-700 cursor-pointer"
          >
            Close ✕
          </button>
        </div>

        {/* 1. Matched Customers Summary */}
        {searchResults.customers.length > 0 && (
          <div className="p-3 sm:p-3.5 space-y-2">
            <div className="px-2.5 py-1.5 flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-lg">
              <span>Customer Records ({searchResults.customers.length})</span>
              <span>Click to view full history</span>
            </div>
            {searchResults.customers.map(cust => (
              <div
                key={cust.phoneKey}
                onClick={() => handleOpenCustomerDetailsModal(cust)}
                className="p-3 rounded-xl hover:bg-emerald-50/40 dark:hover:bg-slate-800/80 border border-slate-200/80 dark:border-slate-800 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                      <UserIcon className="w-4 h-4 text-emerald-600 shrink-0" />
                      {cust.name}
                    </span>
                    <span className="px-2 py-0.5 text-xs font-mono font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-md">
                      📞 {cust.displayPhone}
                    </span>
                  </div>
                  {cust.address && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                      <span className="line-clamp-1">{cust.address}</span>
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                  <span className="px-2.5 py-1 text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-md">
                    Orders: {cust.totalOrders}
                  </span>
                  {cust.deliveredCount > 0 && (
                    <span className="px-2.5 py-1 text-[11px] font-bold bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 rounded-md">
                      Delivered: {cust.deliveredCount}
                    </span>
                  )}
                  {cust.cancelledCount > 0 && (
                    <span className="px-2.5 py-1 text-[11px] font-bold bg-rose-100 dark:bg-rose-950/70 text-rose-800 dark:text-rose-300 rounded-md">
                      Cancelled: {cust.cancelledCount}
                    </span>
                  )}
                  <span className="inline-flex items-center gap-1 px-3 py-1 text-xs font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-2xs">
                    <span>Details</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 2. Matched Online Orders */}
        {searchResults.orders.length > 0 && (
          <div className="p-3 sm:p-3.5 space-y-2">
            <div className="px-2.5 py-1.5 flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 bg-indigo-50/80 dark:bg-indigo-950/40 rounded-lg">
              <span>Orders ({searchResults.orders.length})</span>
              <span>Order & Customer Info</span>
            </div>
            {searchResults.orders.map(order => {
              const badge = statusBadgeConfig[order.orderStatus] || statusBadgeConfig.pending;
              return (
                <div
                  key={order.id}
                  onClick={() => handleOpenOrderCustomerModal(order)}
                  className="p-3 rounded-xl hover:bg-indigo-50/30 dark:hover:bg-slate-800/80 border border-slate-200/80 dark:border-slate-800 transition-all cursor-pointer space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-extrabold text-xs sm:text-sm text-indigo-700 dark:text-indigo-300">
                        #{order.orderNo}
                      </span>
                      <span className={`px-2 py-0.5 text-[11px] font-bold border rounded-md ${badge.className}`}>
                        {badge.labelBn}
                      </span>
                    </div>
                    <span className="font-mono font-extrabold text-xs sm:text-sm text-emerald-700 dark:text-emerald-400">
                      {formatCurrency(order.grandTotal)}
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-extrabold text-slate-900 dark:text-white">
                        {order.customerName}
                      </span>
                      <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                        📞 {order.customerPhone}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {formatDate(order.createdAt)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1">
                      📦 {order.items.map(i => `${i.productName} (${i.quantity})`).join(', ')}
                    </p>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenOrdersTab('orders', order.orderNo);
                      }}
                      className="shrink-0 px-2.5 py-1 text-[11px] font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 rounded-lg cursor-pointer"
                    >
                      View in Orders →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* 3. Matched Incomplete Orders */}
        {searchResults.incomplete.length > 0 && (
          <div className="p-2.5 space-y-1.5">
            <div className="px-2 py-1 text-[10px] font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-300 bg-amber-50/80 dark:bg-amber-950/40 rounded-lg">
              Incomplete Orders ({searchResults.incomplete.length})
            </div>
            {searchResults.incomplete.map(inc => (
              <div
                key={inc.id}
                onClick={() => handleOpenOrdersTab('incomplete', inc.customerPhone)}
                className="p-2.5 rounded-xl hover:bg-amber-50/50 dark:hover:bg-slate-800 border border-amber-200/70 dark:border-slate-800 transition-all cursor-pointer flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {inc.customerName || 'Unnamed Lead'} ·{' '}
                    <span className="font-mono text-amber-700 dark:text-amber-400">
                      {inc.customerPhone}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {inc.deliveryAddress || 'No address provided'}
                  </p>
                </div>
                <span className="px-2 py-1 text-[10px] font-bold bg-amber-100 text-amber-800 rounded-lg shrink-0">
                  Open Lead →
                </span>
              </div>
            ))}
          </div>
        )}

        {/* 4. Matched Products */}
        {searchResults.products.length > 0 && (
          <div className="p-2.5 space-y-1.5">
            <div className="px-2 py-1 text-[10px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-lg">
              Products & Stock ({searchResults.products.length})
            </div>
            {searchResults.products.map(prod => (
              <div
                key={prod.id}
                onClick={() => {
                  setIsSearchOpen(false);
                  setShowMobileSearch(false);
                  onNavigate('inventory');
                }}
                className="p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all cursor-pointer flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {prod.nameBn}
                  </p>
                  <p className="text-[10px] font-mono text-slate-500">
                    SKU: {prod.sku} · Stock: {Object.values(prod.stockByOutlet || {}).reduce((a, b) => a + b, 0)} {prod.unit}
                  </p>
                </div>
                <span className="font-mono font-bold text-xs text-emerald-700 dark:text-emerald-400 shrink-0">
                  {formatCurrency(prod.retailPrice)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <header
        className={`sticky top-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs transition-all duration-200 ${
          isDesktopSidebarOpen ? 'lg:pl-64' : 'lg:pl-0'
        }`}
      >
        <div className="flex items-center justify-between gap-2 sm:gap-3 px-3 sm:px-5 lg:px-6 h-15">
          
          {/* Left: Mobile Drawer Trigger, Desktop Sidebar 1-Click Hide/Open & Store Identity */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            <button
              onClick={onOpenMobileMenu}
              className="lg:hidden min-h-[38px] min-w-[38px] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            {onToggleDesktopSidebar && (
              <button
                type="button"
                onClick={onToggleDesktopSidebar}
                title={isDesktopSidebarOpen ? 'Hide Sidebar Menu' : 'Open Sidebar Menu'}
                className={`hidden lg:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shrink-0 whitespace-nowrap ${
                  isDesktopSidebarOpen
                    ? 'bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border-slate-200 hover:border-indigo-200 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 dark:border-slate-700'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-600 shadow-xs'
                }`}
                aria-label={isDesktopSidebarOpen ? 'Hide sidebar menu' : 'Open sidebar menu'}
              >
                {isDesktopSidebarOpen ? (
                  <>
                    <PanelLeftClose className="w-4 h-4 shrink-0" />
                    <span>Hide Menu</span>
                  </>
                ) : (
                  <>
                    <PanelLeftOpen className="w-4 h-4 shrink-0" />
                    <span>Open Menu</span>
                  </>
                )}
              </button>
            )}

            <div
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2 cursor-pointer group shrink-0"
            >
              {currentBusiness.logoUrl ? (
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-white dark:bg-slate-800 border border-emerald-200 dark:border-slate-700 p-0.5 flex items-center justify-center shadow-2xs shrink-0 overflow-hidden">
                  <img
                    src={currentBusiness.logoUrl}
                    alt={currentBusiness.nameEn || currentBusiness.name}
                    className="w-full h-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold text-sm shadow-2xs shrink-0">
                  <ShoppingBag className="w-4 h-4" />
                </div>
              )}
              <div className="hidden xl:block leading-tight min-w-0 max-w-[160px] 2xl:max-w-[220px]">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm tracking-tight text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors block truncate">
                    {currentBusiness.nameEn || currentBusiness.name}
                  </span>
                  <span className="hidden 2xl:inline text-[10px] font-mono font-bold text-emerald-700 dark:text-emerald-300 shrink-0">
                    · {APP_VERSION}
                  </span>
                </div>
                <p className="text-[10px] font-medium text-indigo-600 dark:text-slate-400 hidden 2xl:block truncate">
                  Admin Control Panel
                </p>
              </div>
            </div>
          </div>

          {/* Center: Clean Solid Global Search Input + Wide Instant Results Dropdown (Desktop) */}
          <div
            ref={desktopSearchRef}
            className="hidden md:flex items-center flex-1 min-w-[180px] max-w-xl mx-2 lg:mx-3 relative z-10"
          >
            <div className="relative w-full">
              <Search className="w-4 h-4 text-indigo-600 dark:text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={globalSearch}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setGlobalSearch(e.target.value);
                  setIsSearchOpen(true);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && globalSearch.trim()) {
                    if (searchResults.customers.length === 1 && searchResults.orders.length === 0) {
                      handleOpenCustomerDetailsModal(searchResults.customers[0]);
                    } else if (searchResults.orders.length > 0) {
                      handleOpenOrderCustomerModal(searchResults.orders[0]);
                    } else if (searchResults.customers.length > 0) {
                      handleOpenCustomerDetailsModal(searchResults.customers[0]);
                    }
                  }
                }}
                placeholder="Search by Order No (ORD-...), Mobile (017...), or Customer Name..."
                className="w-full pl-10 pr-9 py-2 min-h-[40px] text-xs sm:text-sm font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-50 focus:bg-white dark:focus:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:border-indigo-600 dark:focus:border-emerald-500 focus:ring-2 focus:ring-indigo-500/20 rounded-xl shadow-2xs transition-all text-slate-900 dark:text-slate-100 placeholder:text-slate-500 dark:placeholder:text-slate-400 outline-hidden"
              />
              {globalSearch && (
                <button
                  type="button"
                  onClick={() => {
                    setGlobalSearch('');
                    setIsSearchOpen(false);
                  }}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer p-1"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Wide Instant Search Results Dropdown (Desktop) */}
            {isSearchOpen && globalSearch.trim() !== '' && (
              <div className="absolute left-0 lg:left-1/2 lg:-translate-x-1/2 top-full mt-2 w-[92vw] md:w-[580px] lg:w-[680px] xl:w-[760px] max-w-[calc(100vw-2rem)] bg-white dark:bg-slate-900 border-2 border-indigo-200/90 dark:border-slate-700 rounded-2xl shadow-[0_24px_60px_-15px_rgba(15,23,42,0.35)] z-50 overflow-hidden">
                {renderSearchDropdownContent()}
              </div>
            )}
          </div>

          {/* Right Zone: E-Commerce Quick Actions, Theme Switcher, User Profile */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">

            {/* Mobile Search Toggle */}
            <button
              type="button"
              onClick={() => setShowMobileSearch(!showMobileSearch)}
              className="md:hidden min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer"
              aria-label="Toggle search"
            >
              {showMobileSearch ? <X className="w-4 h-4" /> : <Search className="w-4 h-4" />}
            </button>

            {/* Colorful Quick Online Orders Button */}
            <button
              type="button"
              onClick={() => handleOpenOrdersTab('orders')}
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 xl:px-3 py-1.5 min-h-[36px] text-xs font-extrabold text-emerald-900 dark:text-emerald-200 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800/80 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              title="Pending Online Orders"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Orders</span>
              <span
                className={`px-1.5 py-0.5 text-[10px] font-mono font-bold rounded-md tabular-nums ${
                  pendingOrdersCount > 0
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-200/70 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300'
                }`}
              >
                {pendingOrdersCount}
              </span>
            </button>

            {/* Colorful Quick Incomplete Orders Button */}
            <button
              type="button"
              onClick={() => handleOpenOrdersTab('incomplete')}
              className="hidden 2xl:inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] text-xs font-extrabold text-amber-900 dark:text-amber-200 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 border border-amber-200 dark:border-amber-800/80 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              title="View Incomplete Orders"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>Incomplete</span>
              <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-amber-500 text-white rounded-md tabular-nums">
                {abandonedCount}
              </span>
            </button>

            {/* Colorful Quick Products Button */}
            <button
              type="button"
              onClick={() => onNavigate('inventory')}
              className="hidden 2xl:inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] text-xs font-extrabold text-indigo-900 dark:text-indigo-200 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 border border-indigo-200 dark:border-indigo-800/80 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
            >
              <Boxes className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Products</span>
            </button>

            {/* Light / Dark Mode Segmented Switcher */}
            {onSetAdminTheme && (
              <div
                className="flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                title="Switch Dashboard Theme (Light / Dark Mode)"
              >
                <button
                  type="button"
                  onClick={() => onSetAdminTheme('light')}
                  className={`px-2 py-1 min-h-[28px] text-[11px] font-extrabold rounded-lg flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                    adminTheme === 'light'
                      ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden xl:inline">Light</span>
                </button>
                <button
                  type="button"
                  onClick={() => onSetAdminTheme('dark')}
                  className={`px-2 py-1 min-h-[28px] text-[11px] font-extrabold rounded-lg flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                    adminTheme === 'dark'
                      ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden xl:inline">Dark</span>
                </button>
              </div>
            )}

            {/* Direct Top-Bar Logout Button */}
            <button
              onClick={logout}
              className="flex items-center gap-1.5 px-2.5 py-1.5 min-h-[36px] text-xs font-semibold text-rose-700 dark:text-rose-300 bg-rose-50/80 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200/80 dark:border-rose-800/70 rounded-xl transition-colors cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>

          </div>
        </div>

        {/* Expandable Mobile Search Bar (< md) */}
        {showMobileSearch && (
          <div ref={mobileSearchRef} className="md:hidden px-3 pb-2.5 pt-1 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 relative">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                autoFocus
                value={globalSearch}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setGlobalSearch(e.target.value);
                  setIsSearchOpen(true);
                }}
                placeholder="Search by Order No (ORD-...), Customer Mobile or Name..."
                className="w-full pl-9 pr-8 py-2 min-h-[38px] text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-emerald-600 focus:bg-white dark:focus:bg-slate-800 rounded-xl text-slate-900 dark:text-slate-100 outline-hidden"
              />
              {globalSearch && (
                <button
                  type="button"
                  onClick={() => {
                    setGlobalSearch('');
                    setIsSearchOpen(false);
                  }}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {isSearchOpen && globalSearch.trim() !== '' && (
              <div className="mt-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xl overflow-hidden">
                {renderSearchDropdownContent()}
              </div>
            )}
          </div>
        )}
      </header>

      {/* Customer & Order Full Details Modal (Opened from Top Search Bar) */}
      {liveModalData && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-page-rise">
            {/* Modal Header */}
            <div className="px-4 sm:px-6 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm sm:text-base font-extrabold truncate">
                    {liveModalData.customer.name}
                  </h3>
                  <span className="px-2.5 py-0.5 text-xs font-mono font-extrabold bg-white/20 rounded-lg">
                    📞 {liveModalData.customer.displayPhone}
                  </span>
                </div>
                <p className="text-[11px] text-emerald-100 mt-0.5 truncate">
                  {liveModalData.customer.address || 'No address provided'}
                  {liveModalData.customer.area ? ` (${liveModalData.customer.area})` : ''}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveCustomerModal(null)}
                className="w-8 h-8 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center text-white cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
              {/* Customer KPI Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                  <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400">Total Orders</p>
                  <p className="text-lg font-extrabold text-slate-900 dark:text-white mt-0.5">
                    {liveModalData.customer.totalOrders}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/70">
                  <p className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400">Delivered</p>
                  <p className="text-lg font-extrabold text-emerald-800 dark:text-emerald-300 mt-0.5">
                    {liveModalData.customer.deliveredCount}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/70">
                  <p className="text-[10px] font-bold text-rose-700 dark:text-rose-400">Cancelled</p>
                  <p className="text-lg font-extrabold text-rose-800 dark:text-rose-300 mt-0.5">
                    {liveModalData.customer.cancelledCount}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/70">
                  <p className="text-[10px] font-bold text-indigo-700 dark:text-indigo-400">Total Value</p>
                  <p className="text-base font-mono font-extrabold text-indigo-800 dark:text-indigo-300 mt-0.5">
                    {formatCurrency(liveModalData.customer.totalSpent)}
                  </p>
                </div>
              </div>

              {/* Quick Contact & Navigation Bar */}
              <div className="flex items-center justify-between gap-2 flex-wrap p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
                <div className="flex items-center gap-2 flex-wrap">
                  <a
                    href={`tel:${liveModalData.customer.displayPhone}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Customer</span>
                  </a>
                  <a
                    href={`https://wa.me/88${normalizeBdPhone(liveModalData.customer.displayPhone)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-800 dark:text-emerald-200 bg-emerald-100 dark:bg-emerald-950/80 hover:bg-emerald-200 rounded-xl"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      const phone = liveModalData.customer.displayPhone;
                      setActiveCustomerModal(null);
                      handleOpenOrdersTab('orders', phone);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 border border-indigo-200 dark:border-indigo-800 rounded-xl cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Filter in Orders</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setGlobalSearch(liveModalData.customer.displayPhone);
                      setActiveCustomerModal(null);
                      onNavigate('online_customers');
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer"
                  >
                    <UserIcon className="w-3.5 h-3.5" />
                    <span>Customer Profile</span>
                  </button>
                </div>
              </div>

              {/* Customer's Complete Order History */}
              <div className="space-y-3">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span>All Orders for this Customer ({liveModalData.customer.orders.length})</span>
                </h4>

                {liveModalData.customer.orders.length === 0 ? (
                  <div className="p-6 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-xs text-slate-500">
                    No completed online orders found for this customer.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {liveModalData.customer.orders.map(order => {
                      const isHighlighted = liveModalData.highlightedOrderId === order.id;
                      const badge = statusBadgeConfig[order.orderStatus] || statusBadgeConfig.pending;
                      return (
                        <div
                          key={order.id}
                          className={`p-4 rounded-xl border transition-all space-y-3 ${
                            isHighlighted
                              ? 'border-emerald-500 bg-emerald-50/30 dark:bg-emerald-950/20 shadow-sm'
                              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-mono font-extrabold text-sm text-indigo-700 dark:text-indigo-300">
                                #{order.orderNo}
                              </span>
                              <span className={`px-2.5 py-0.5 text-[11px] font-bold border rounded-md ${badge.className}`}>
                                {badge.labelBn}
                              </span>
                              <span className="text-[11px] text-slate-400">
                                {formatDate(order.createdAt)}
                              </span>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-mono font-extrabold text-emerald-700 dark:text-emerald-400">
                                Total: {formatCurrency(order.grandTotal)}
                              </span>
                              <span className="block text-[10px] text-slate-400">
                                Delivery Charge: {formatCurrency(order.deliveryCharge)} · {order.paymentMethod.toUpperCase()}
                              </span>
                            </div>
                          </div>

                          {/* Ordered Products */}
                          <div className="space-y-1.5">
                            {order.items.map((item, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-800/60 px-3 py-1.5 rounded-lg"
                              >
                                <div className="min-w-0">
                                  <span className="font-bold text-slate-800 dark:text-slate-200">
                                    {item.productName}
                                  </span>
                                </div>
                                <div className="font-mono text-xs shrink-0 text-slate-700 dark:text-slate-300">
                                  {formatCurrency(item.unitPrice)} × {item.quantity} ={' '}
                                  <span className="font-bold">
                                    {formatCurrency(item.unitPrice * item.quantity)}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Address & Quick Status Change */}
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 text-xs">
                            <p className="text-[11px] text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span>
                                <strong>Address:</strong> {order.deliveryAddress} ({order.deliveryArea})
                              </span>
                            </p>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <span className="text-[11px] font-bold text-slate-500">Status:</span>
                              <select
                                value={order.orderStatus}
                                onChange={(e) =>
                                  updateOnlineOrderStatus(order.id, e.target.value as OnlineOrderStatus)
                                }
                                className="px-2.5 py-1 text-xs font-bold bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white cursor-pointer"
                              >
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="packaging">Packaging</option>
                                <option value="dispatched">Dispatched</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

