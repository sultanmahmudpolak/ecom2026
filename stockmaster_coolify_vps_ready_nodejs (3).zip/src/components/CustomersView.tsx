import React, { useState, useMemo, useEffect } from 'react';
import { useApp, normalizeBdPhone } from '../context/AppContext';
import { Customer, PaymentMethod, OnlineOrder, OnlineOrderStatus, Sale, SaleItem } from '../types';
import { exportToCsv, exportToExcel } from '../config/api';
import { 
  Plus, 
  Search, 
  MessageSquare, 
  Wallet, 
  FileText, 
  X, 
  Copy,
  Download,
  Printer,
  CheckCircle2,
  ArrowDownLeft,
  ArrowUpRight,
  ShoppingBag,
  Edit3,
  KeyRound,
  UserCheck,
  MapPin,
  Phone,
  Clock,
  Package,
  Truck,
  XCircle,
  MessageCircle,
  History
} from 'lucide-react';

interface CustomersViewProps {
  initialFilter?: 'all' | 'online' | 'wholesale' | 'retail' | 'due_only';
}

interface UnifiedCustomerOrderRecord {
  id: string;
  orderNo: string;
  invoiceNo: string;
  sourceType: 'online' | 'pos_or_wholesale';
  channelLabelBn: string;
  channelLabelEn: string;
  createdAt: string;
  items: SaleItem[];
  subtotal: number;
  deliveryCharge: number;
  discountAmount: number;
  grandTotal: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethodLabel: string;
  paymentStatus: 'paid' | 'unpaid' | 'partial';
  statusCategory: 'Pending' | 'Processing' | 'Delivered' | 'Cancelled';
  statusLabelBn: string;
  rawOnlineOrder?: OnlineOrder;
  rawSale?: Sale;
  deliveryAddress?: string;
  deliveryArea?: string;
  notes?: string;
}

export const CustomersView: React.FC<CustomersViewProps> = ({ initialFilter = 'all' }) => {
  const { 
    t, 
    language, 
    customers, 
    customerLedger,
    onlineOrders,
    updateOnlineOrderStatus,
    sales,
    currentBusiness, 
    addCustomer, 
    updateCustomer,
    collectCustomerDue, 
    formatCurrency, 
    formatDate,
    globalSearch,
    showToast 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'online' | 'wholesale' | 'retail' | 'due_only'>(initialFilter);

  useEffect(() => {
    setTypeFilter(initialFilter);
  }, [initialFilter]);
  
  // Modals (store ID or reference, always resolve live customer from state)
  const [showAddModal, setShowAddModal] = useState(false);
  const [collectingCustomer, setCollectingCustomer] = useState<Customer | null>(null);
  const [smsCustomer, setSmsCustomer] = useState<Customer | null>(null);
  const [statementCustomer, setStatementCustomer] = useState<Customer | null>(null);
  const [onlineOrdersModalCustomer, setOnlineOrdersModalCustomer] = useState<Customer | null>(null);
  const [orderHistoryFilter, setOrderHistoryFilter] = useState<'all' | 'pending' | 'processing' | 'delivered' | 'cancelled' | 'pos'>('all');
  const [orderHistorySearch, setOrderHistorySearch] = useState('');
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Edit Customer / Password Reset Form State
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [editRoute, setEditRoute] = useState('');
  const [editType, setEditType] = useState<'retail' | 'wholesale' | 'online'>('online');
  const [editPassword, setEditPassword] = useState('');
  const [editCreditLimit, setEditCreditLimit] = useState<number>(0);

  // Always resolve the live customer object so balances & ledgers update immediately
  const liveCollectingCustomer = useMemo(
    () => (collectingCustomer ? customers.find(c => c.id === collectingCustomer.id) || collectingCustomer : null),
    [customers, collectingCustomer]
  );

  const liveStatementCustomer = useMemo(
    () => (statementCustomer ? customers.find(c => c.id === statementCustomer.id) || statementCustomer : null),
    [customers, statementCustomer]
  );

  const liveOnlineOrdersCustomer = useMemo(
    () => (onlineOrdersModalCustomer ? customers.find(c => c.id === onlineOrdersModalCustomer.id) || onlineOrdersModalCustomer : null),
    [customers, onlineOrdersModalCustomer]
  );

  // Due Collection Form
  const [collectAmount, setCollectAmount] = useState<number>(0);
  const [collectMethod, setCollectMethod] = useState<PaymentMethod>('cash');
  const [collectNote, setCollectNote] = useState('বকেয়া আদায় রশিদ');

  // Add Customer Form
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('01');
  const [address, setAddress] = useState('');
  const [route, setRoute] = useState('');
  const [customerType, setCustomerType] = useState<'retail' | 'wholesale' | 'online'>(
    initialFilter === 'online' ? 'online' : 'wholesale'
  );
  const [password, setPassword] = useState('');
  const [creditLimit, setCreditLimit] = useState<number>(50000);
  const [openingDue, setOpeningDue] = useState<number>(0);

  // Helper to get all online orders for a given customer (by customerId or normalized phone)
  const getCustomerOnlineOrders = (cust: Customer): OnlineOrder[] => {
    const custNorm = normalizeBdPhone(cust.phone);
    return onlineOrders.filter(o => {
      if (o.customerId && o.customerId === cust.id) return true;
      const ordNorm = normalizeBdPhone(o.customerPhone);
      return (
        custNorm.length >= 10 &&
        ordNorm.length >= 10 &&
        (ordNorm === custNorm || ordNorm.endsWith(custNorm) || custNorm.endsWith(ordNorm))
      );
    });
  };

  // Helper to get direct POS / Wholesale sales invoices for a given customer (excluding those already in onlineOrders)
  const getCustomerDirectSales = (cust: Customer, existingOnlineOrders: OnlineOrder[]): Sale[] => {
    const onlineInvoiceSet = new Set(existingOnlineOrders.map(o => o.invoiceNo));
    const custNorm = normalizeBdPhone(cust.phone);
    return sales.filter(s => {
      if (onlineInvoiceSet.has(s.invoiceNo)) return false;
      if (s.customerId && s.customerId === cust.id) return true;
      const saleNorm = normalizeBdPhone(s.customerPhone || '');
      return (
        custNorm.length >= 10 &&
        saleNorm.length >= 10 &&
        (saleNorm === custNorm || saleNorm.endsWith(custNorm) || custNorm.endsWith(saleNorm))
      );
    });
  };

  // Build unified order history list (Online Orders + POS/Wholesale Sales) for a customer
  const getCustomerAllOrderHistory = (cust: Customer): UnifiedCustomerOrderRecord[] => {
    const custOnline = getCustomerOnlineOrders(cust);
    const custSales = getCustomerDirectSales(cust, custOnline);

    const onlineRecords: UnifiedCustomerOrderRecord[] = custOnline.map(ord => {
      let statusCategory: UnifiedCustomerOrderRecord['statusCategory'] = 'Pending';
      if (ord.orderStatus === 'delivered') statusCategory = 'Delivered';
      else if (ord.orderStatus === 'cancelled') statusCategory = 'Cancelled';
      else if (
        ord.orderStatus === 'confirmed' ||
        ord.orderStatus === 'packaging' ||
        ord.orderStatus === 'dispatched'
      ) {
        statusCategory = 'Processing';
      }

      const statusLabelMap: Record<OnlineOrderStatus, string> = {
        pending: 'অপেক্ষমাণ (Pending)',
        confirmed: 'প্রসেসিং · নিশ্চিতকৃত (Confirmed)',
        packaging: 'প্রসেসিং · প্যাকেজিং চলছে (Packing)',
        dispatched: 'প্রসেসিং · ডেলিভারির পথে (On Way)',
        delivered: 'ডেলিভারি সম্পন্ন (Delivered)',
        cancelled: 'বাতিলকৃত (Cancelled)'
      };

      const channelLabelBn =
        ord.orderSource === 'landing_page'
          ? 'ল্যান্ডিং পেজ অর্ডার'
          : ord.orderSource === 'incomplete_recovery'
          ? 'রিকভারড অনলাইন অর্ডার'
          : 'ই-কমার্স স্টোরফ্রন্ট';
      const channelLabelEn =
        ord.orderSource === 'landing_page'
          ? 'Landing Page Order'
          : ord.orderSource === 'incomplete_recovery'
          ? 'Recovered Order'
          : 'Online Storefront';

      return {
        id: `online_${ord.id}`,
        orderNo: ord.orderNo,
        invoiceNo: ord.invoiceNo,
        sourceType: 'online',
        channelLabelBn,
        channelLabelEn,
        createdAt: ord.createdAt,
        items: ord.items || [],
        subtotal: ord.subtotal || 0,
        deliveryCharge: ord.deliveryCharge || 0,
        discountAmount: ord.discountAmount || 0,
        grandTotal: ord.grandTotal || 0,
        paidAmount: ord.paymentStatus === 'paid' ? ord.grandTotal : 0,
        dueAmount: ord.paymentStatus === 'paid' ? 0 : ord.grandTotal,
        paymentMethodLabel: ord.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : ord.paymentMethod.toUpperCase(),
        paymentStatus: ord.paymentStatus,
        statusCategory,
        statusLabelBn: statusLabelMap[ord.orderStatus] || ord.orderStatus,
        rawOnlineOrder: ord,
        deliveryAddress: ord.deliveryAddress,
        deliveryArea: ord.deliveryArea,
        notes: ord.notes
      };
    });

    const saleRecords: UnifiedCustomerOrderRecord[] = custSales.map(s => {
      let statusCategory: UnifiedCustomerOrderRecord['statusCategory'] = 'Delivered';
      if (s.status === 'returned') statusCategory = 'Cancelled';
      else if (s.status === 'hold') statusCategory = 'Pending';
      else if (s.status === 'dispatched') statusCategory = 'Processing';

      const channelLabelBn =
        s.channel === 'wholesale_distribution'
          ? 'পাইকারি চালান (Wholesale)'
          : s.channel === 'online_ecommerce'
          ? 'অনলাইন ইনভয়েস'
          : 'শপ পিওএস বিক্রয় (POS)';
      const channelLabelEn =
        s.channel === 'wholesale_distribution'
          ? 'Wholesale Challan'
          : s.channel === 'online_ecommerce'
          ? 'Online Invoice'
          : 'Retail POS Sale';

      const paymentMethods =
        s.paymentSplits && s.paymentSplits.length > 0
          ? s.paymentSplits.map(p => p.method.toUpperCase()).join(' + ')
          : 'CASH';

      return {
        id: `sale_${s.id}`,
        orderNo: s.invoiceNo,
        invoiceNo: s.invoiceNo,
        sourceType: 'pos_or_wholesale',
        channelLabelBn,
        channelLabelEn,
        createdAt: s.createdAt,
        items: s.items || [],
        subtotal: s.subtotal || 0,
        deliveryCharge: 0,
        discountAmount: s.discountAmount || 0,
        grandTotal: s.grandTotal || 0,
        paidAmount: s.paidAmount || 0,
        dueAmount: s.dueAmount || 0,
        paymentMethodLabel: paymentMethods,
        paymentStatus: s.dueAmount <= 0 ? 'paid' : s.paidAmount > 0 ? 'partial' : 'unpaid',
        statusCategory,
        statusLabelBn:
          s.status === 'returned'
            ? 'রিটার্নকৃত (Returned)'
            : s.status === 'dispatched'
            ? 'ডেলিভারিতে (Dispatched)'
            : 'সম্পন্ন ইনভয়েস (Completed)',
        rawSale: s,
        deliveryAddress: cust.address,
        deliveryArea: cust.route,
        notes: s.notes
      };
    });

    return [...onlineRecords, ...saleRecords].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  };

  // Online Customers count & stats
  const onlineCustomersList = useMemo(
    () => customers.filter(c => c.customerType === 'online' || c.isOnlineCustomer),
    [customers]
  );

  const onlineStats = useMemo(() => {
    const totalOnlineCusts = onlineCustomersList.length;
    const withPasswordCount = onlineCustomersList.filter(c => Boolean(c.password)).length;
    const totalOrdersCount = onlineOrders.length;
    const totalOrderValue = onlineOrders
      .filter(o => o.orderStatus !== 'cancelled')
      .reduce((sum, o) => sum + (o.grandTotal || 0), 0);
    return { totalOnlineCusts, withPasswordCount, totalOrdersCount, totalOrderValue };
  }, [onlineCustomersList, onlineOrders]);

  // Filtered Customers
  const filteredCustomers = useMemo(() => {
    const q = (searchQuery.trim() || globalSearch.trim()).toLowerCase().replace(/^#/, '');
    const qNormPhone = normalizeBdPhone(q);
    return customers.filter(c => {
      const custNormPhone = normalizeBdPhone(c.phone);
      const hasMatchingOrder = q
        ? onlineOrders.some(
            o =>
              (o.orderNo.toLowerCase().includes(q) || o.invoiceNo.toLowerCase().includes(q)) &&
              (o.customerId === c.id || (custNormPhone.length >= 10 && normalizeBdPhone(o.customerPhone) === custNormPhone))
          )
        : false;

      const matchQ =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        (qNormPhone.length >= 3 && custNormPhone.includes(qNormPhone)) ||
        (c.address && c.address.toLowerCase().includes(q)) ||
        (c.route && c.route.toLowerCase().includes(q)) ||
        hasMatchingOrder;
      
      let matchType = true;
      if (typeFilter === 'online') matchType = c.customerType === 'online' || Boolean(c.isOnlineCustomer);
      else if (typeFilter === 'wholesale') matchType = c.customerType === 'wholesale';
      else if (typeFilter === 'retail') matchType = c.customerType === 'retail' && !c.isOnlineCustomer;
      else if (typeFilter === 'due_only') matchType = c.currentDue > 0;

      return matchQ && matchType;
    });
  }, [customers, searchQuery, globalSearch, onlineOrders, typeFilter]);

  const CUSTOMERS_PER_PAGE = 50;
  const [customerPage, setCustomerPage] = useState<number>(1);

  useEffect(() => {
    setCustomerPage(1);
  }, [searchQuery, globalSearch, typeFilter]);

  const totalCustomerPages = Math.max(1, Math.ceil(filteredCustomers.length / CUSTOMERS_PER_PAGE));
  const safeCustomerPage = Math.min(customerPage, totalCustomerPages);
  const paginatedCustomers = useMemo(() => {
    const start = (safeCustomerPage - 1) * CUSTOMERS_PER_PAGE;
    return filteredCustomers.slice(start, start + CUSTOMERS_PER_PAGE);
  }, [filteredCustomers, safeCustomerPage]);

  const ledgerCountByCustId = useMemo(() => {
    const map: Record<string, number> = {};
    for (const e of customerLedger) {
      if (e.customerId) {
        map[e.customerId] = (map[e.customerId] || 0) + 1;
      }
    }
    return map;
  }, [customerLedger]);

  const totalDuesAll = useMemo(() => {
    return customers.reduce((sum, c) => sum + (c.currentDue || 0), 0);
  }, [customers]);

  // Statement Entries for the selected customer
  const statementEntries = useMemo(() => {
    if (!liveStatementCustomer) return [];
    return customerLedger.filter(entry => entry.customerId === liveStatementCustomer.id);
  }, [customerLedger, liveStatementCustomer]);

  const statementTotals = useMemo(() => {
    const totalDebit = statementEntries.reduce((sum, e) => sum + (e.debit || 0), 0);
    const totalCredit = statementEntries.reduce((sum, e) => sum + (e.credit || 0), 0);
    return { totalDebit, totalCredit };
  }, [statementEntries]);

  const selectedCustomerAllOrders = useMemo(() => {
    if (!liveOnlineOrdersCustomer) return [];
    return getCustomerAllOrderHistory(liveOnlineOrdersCustomer);
  }, [liveOnlineOrdersCustomer, onlineOrders, sales]);

  const filteredCustomerOrderHistory = useMemo(() => {
    return selectedCustomerAllOrders.filter(rec => {
      if (orderHistoryFilter === 'pending' && rec.statusCategory !== 'Pending') return false;
      if (orderHistoryFilter === 'processing' && rec.statusCategory !== 'Processing') return false;
      if (orderHistoryFilter === 'delivered' && rec.statusCategory !== 'Delivered') return false;
      if (orderHistoryFilter === 'cancelled' && rec.statusCategory !== 'Cancelled') return false;
      if (orderHistoryFilter === 'pos' && rec.sourceType !== 'pos_or_wholesale') return false;

      if (orderHistorySearch.trim()) {
        const q = orderHistorySearch.toLowerCase().trim();
        const matchesOrderNo = rec.orderNo.toLowerCase().includes(q);
        const matchesInvoice = rec.invoiceNo.toLowerCase().includes(q);
        const matchesItems = rec.items.some(it => it.productName.toLowerCase().includes(q));
        return matchesOrderNo || matchesInvoice || matchesItems;
      }
      return true;
    });
  }, [selectedCustomerAllOrders, orderHistoryFilter, orderHistorySearch]);

  const selectedCustomerOrderMetrics = useMemo(() => {
    const totalCount = selectedCustomerAllOrders.length;
    const deliveredCount = selectedCustomerAllOrders.filter(r => r.statusCategory === 'Delivered').length;
    const activeCount = selectedCustomerAllOrders.filter(
      r => r.statusCategory === 'Pending' || r.statusCategory === 'Processing'
    ).length;
    const cancelledCount = selectedCustomerAllOrders.filter(r => r.statusCategory === 'Cancelled').length;
    const lifetimeValue = selectedCustomerAllOrders
      .filter(r => r.statusCategory !== 'Cancelled')
      .reduce((sum, r) => sum + (r.grandTotal || 0), 0);

    return { totalCount, deliveredCount, activeCount, cancelledCount, lifetimeValue };
  }, [selectedCustomerAllOrders]);

  // Handle Due Collection Submit
  const handleCollectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveCollectingCustomer || collectAmount <= 0) return;
    const targetCust = liveCollectingCustomer;
    await collectCustomerDue(targetCust.id, collectAmount, collectMethod, collectNote);
    setCollectingCustomer(null);
    setCollectAmount(0);
    setStatementCustomer(targetCust);
  };

  // Handle Add Customer Submit
  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) {
      showToast(language === 'bn' ? 'নাম ও মোবাইল নম্বর আবশ্যক' : 'Name and mobile number required', 'error');
      return;
    }
    await addCustomer({
      businessId: currentBusiness.id,
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      route: route.trim() || (customerType === 'online' ? 'হোম ডেলিভারি (অনলাইন)' : ''),
      customerType,
      isOnlineCustomer: customerType === 'online',
      password: password.trim() || undefined,
      creditLimit: customerType === 'online' ? 0 : creditLimit,
      currentDue: customerType === 'online' ? 0 : openingDue
    });
    setShowAddModal(false);
    setName('');
    setPhone('01');
    setAddress('');
    setRoute('');
    setPassword('');
    setOpeningDue(0);
  };

  const openEditCustomerModal = (cust: Customer) => {
    setEditingCustomer(cust);
    setEditName(cust.name);
    setEditPhone(cust.phone);
    setEditAddress(cust.address || '');
    setEditRoute(cust.route || '');
    setEditType(cust.customerType);
    setEditPassword(cust.password || '');
    setEditCreditLimit(cust.creditLimit || 0);
  };

  const handleEditCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer) return;
    if (!editName.trim() || !editPhone.trim()) {
      showToast('নাম এবং মোবাইল নম্বর আবশ্যক', 'error');
      return;
    }
    await updateCustomer(editingCustomer.id, {
      name: editName.trim(),
      phone: editPhone.trim(),
      address: editAddress.trim(),
      route: editRoute.trim(),
      customerType: editType,
      isOnlineCustomer: editType === 'online' || editingCustomer.isOnlineCustomer,
      password: editPassword.trim() || undefined,
      creditLimit: editCreditLimit
    });
    showToast(
      language === 'bn'
        ? `গ্রাহক "${editName.trim()}" এর তথ্য ও পাসওয়ার্ড ডাটাবেজে আপডেট হয়েছে`
        : 'Customer profile updated in database',
      'success'
    );
    setEditingCustomer(null);
  };

  // Generate Bangla SMS Reminder Text
  const getSmsText = (c: Customer) => {
    return `প্রিয় গ্রাহক ${c.name}, ${currentBusiness.name} থেকে বিনীতভাবে জানানো যাচ্ছে যে আপনার বর্তমান বাকী বকেয়ার পরিমাণ ৳${c.currentDue}। সুবিধাজনক সময়ে ক্যাশ অথবা বিকাশ মার্চেন্টে (${currentBusiness.phone}) পরিশোধের জন্য অনুরোধ করা হলো। ধন্যবাদ!`;
  };

  const copySmsText = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast(t.smsCopied, 'info');
  };

  const handleExportStatementCsv = () => {
    if (!liveStatementCustomer) return;
    exportToCsv(
      `Customer_Statement_${liveStatementCustomer.id}`,
      ['Date', 'Reference_No', 'Type', 'Description', 'Debit_BDT', 'Credit_Paid_BDT', 'Balance_After_BDT', 'Recorded_By'],
      statementEntries.map(e => [
        formatDate(e.createdAt),
        e.referenceNo,
        e.entryType,
        e.description,
        e.debit,
        e.credit,
        e.balanceAfter,
        e.createdBy
      ])
    );
  };

  const entryTypeBadge = (type: string) => {
    switch (type) {
      case 'PAYMENT_COLLECTION':
        return {
          label: language === 'bn' ? 'বকেয়া আদায় জমা' : 'Payment Received',
          className: 'text-teal-700 font-bold'
        };
      case 'SALE_INVOICE':
        return {
          label: language === 'bn' ? 'বিক্রয় ইনভয়েস' : 'Sale Invoice',
          className: 'text-slate-800 font-semibold'
        };
      case 'SALES_RETURN_CREDIT':
        return {
          label: language === 'bn' ? 'বিক্রয় ফেরত ক্রেডিট' : 'Return Credit Note',
          className: 'text-amber-700 font-semibold'
        };
      default:
        return {
          label: language === 'bn' ? 'প্রারম্ভিক বকেয়া' : 'Opening Balance',
          className: 'text-slate-600 font-medium'
        };
    }
  };

  const orderStatusBadge = (status: OnlineOrder['orderStatus']) => {
    switch (status) {
      case 'delivered':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'cancelled':
        return 'bg-rose-50 text-rose-800 border-rose-200';
      case 'dispatched':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      default:
        return 'bg-amber-50 text-amber-800 border-amber-200';
    }
  };

  const orderStatusLabelBn: Record<OnlineOrder['orderStatus'], string> = {
    pending: 'অর্ডার গৃহীত (Pending)',
    confirmed: 'কনফার্মড (Confirmed)',
    packaging: 'প্যাকেজিং চলছে',
    dispatched: 'ডেলিভারির পথে',
    delivered: 'ডেলিভারি সম্পন্ন',
    cancelled: 'বাতিল (Cancelled)'
  };

  return (
    <div className="space-y-5">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            {typeFilter === 'online'
              ? language === 'bn'
                ? 'অনলাইন কাস্টমার ডিরেক্টরি ও অর্ডার ডাটাবেজ (Online Customers)'
                : 'Online Customers & Account Database'
              : t.customers}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {typeFilter === 'online'
              ? language === 'bn'
                ? `সকল স্টোরফ্রন্ট সাইনআপ একাউন্ট এবং অনলাইন অর্ডারের কাস্টমার ডাটাবেজে সংরক্ষিত · মোট অনলাইন কাস্টমার: ${onlineStats.totalOnlineCusts} জন`
                : `All storefront customer accounts & online order profiles saved in database · Total: ${onlineStats.totalOnlineCusts}`
              : language === 'bn'
              ? `সর্বমোট বকেয়া পাওনা: ${formatCurrency(totalDuesAll)} · মোট গ্রাহক সংখ্যা: ${customers.length} জন (অনলাইন: ${onlineStats.totalOnlineCusts} জন)`
              : `Total Outstanding Due: ${formatCurrency(totalDuesAll)} · Registered: ${customers.length}`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              const target = filteredCustomers.length > 0 ? filteredCustomers : customers;
              if (target.length === 0) {
                showToast('ডাউনলোড করার মতো কোনো কাস্টমার ডাটা নেই', 'error');
                return;
              }
              exportToExcel(
                'Customer_Directory_Marketing_Data',
                'Customers_List',
                [
                  'ক্রমিক নং',
                  'গ্রাহকের নাম',
                  'মোবাইল নাম্বার',
                  'ঠিকানা',
                  'রুট / এলাকা',
                  'গ্রাহকের ধরন',
                  'মোট অর্ডার সংখ্যা',
                  'মোট অর্ডারের মূল্য (৳)',
                  'বর্তমান বকেয়া (৳)'
                ],
                target.map((c, idx) => {
                  const allOrders = getCustomerAllOrderHistory(c);
                  const spent = allOrders
                    .filter(o => o.statusCategory !== 'Cancelled')
                    .reduce((s, o) => s + (o.grandTotal || 0), 0);
                  return [
                    idx + 1,
                    c.name,
                    c.phone,
                    c.address || '',
                    c.route || '',
                    c.customerType === 'online' || c.isOnlineCustomer
                      ? 'অনলাইন কাস্টমার'
                      : c.customerType === 'wholesale'
                      ? 'পাইকারি ডিলার'
                      : 'খুচরা কাস্টমার',
                    allOrders.length,
                    spent,
                    c.currentDue || 0
                  ];
                })
              );
              showToast(
                `${target.length} জন কাস্টমারের ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
                'success'
              );
            }}
            className="min-h-[40px] px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="কাস্টমার লিস্ট ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড করুন"
          >
            <Download className="w-4 h-4" />
            <span>১-ক্লিক Excel ডাউনলোড ({filteredCustomers.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const target = filteredCustomers.length > 0 ? filteredCustomers : customers;
              if (target.length === 0) {
                showToast('ডাউনলোড করার মতো কোনো কাস্টমার ডাটা নেই', 'error');
                return;
              }
              exportToCsv(
                'Customer_Directory_Google_Sheet',
                [
                  'SL',
                  'Customer_Name',
                  'Mobile_Number',
                  'Address',
                  'Area_Route',
                  'Customer_Type',
                  'Total_Orders',
                  'Total_Spent_BDT',
                  'Current_Due_BDT'
                ],
                target.map((c, idx) => {
                  const allOrders = getCustomerAllOrderHistory(c);
                  const spent = allOrders
                    .filter(o => o.statusCategory !== 'Cancelled')
                    .reduce((s, o) => s + (o.grandTotal || 0), 0);
                  return [
                    idx + 1,
                    c.name,
                    c.phone,
                    c.address || '',
                    c.route || '',
                    c.customerType === 'online' || c.isOnlineCustomer
                      ? 'Online Customer'
                      : c.customerType === 'wholesale'
                      ? 'Wholesale Dealer'
                      : 'Retail Customer',
                    allOrders.length,
                    spent,
                    c.currentDue || 0
                  ];
                })
              );
              showToast(
                `${target.length} জন কাস্টমারের ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড হয়েছে!`,
                'success'
              );
            }}
            className="min-h-[40px] px-3 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="কাস্টমার লিস্ট Google Sheet (CSV) ফাইলে ডাউনলোড করুন"
          >
            <Download className="w-4 h-4 text-blue-600" />
            <span>Google Sheet (CSV)</span>
          </button>

          <button
            onClick={() => {
              setCustomerType(typeFilter === 'online' ? 'online' : 'wholesale');
              setShowAddModal(true);
            }}
            className="min-h-[40px] px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>
              {typeFilter === 'online'
                ? language === 'bn'
                  ? '+ নতুন অনলাইন কাস্টমার যোগ করুন'
                  : '+ New Online Customer'
                : t.newCustomer}
            </span>
          </button>
        </div>
      </div>

      {/* Online Customers KPI Cards (Shown when Online Customers tab is active or always visible at top) */}
      {typeFilter === 'online' && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-2xs">
            <span className="text-[11px] font-semibold text-slate-500 block">
              মোট অনলাইন কাস্টমার
            </span>
            <p className="text-lg font-extrabold font-mono text-emerald-800 mt-0.5">
              {onlineStats.totalOnlineCusts} জন
            </p>
            <span className="text-[10px] text-emerald-700 font-medium">
              ডাটাবেজে সংরক্ষিত (Online Accounts)
            </span>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-blue-200 shadow-2xs">
            <span className="text-[11px] font-semibold text-slate-500 block">
              লগইন পাসওয়ার্ড সক্রিয় একাউন্ট
            </span>
            <p className="text-lg font-extrabold font-mono text-blue-800 mt-0.5">
              {onlineStats.withPasswordCount} জন
            </p>
            <span className="text-[10px] text-blue-700 font-medium">
              স্টোরফ্রন্টে লগইন ও অর্ডার হিস্ট্রি যুক্ত
            </span>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-2xs">
            <span className="text-[11px] font-semibold text-slate-500 block">
              মোট অনলাইন অর্ডার সংখ্যা
            </span>
            <p className="text-lg font-extrabold font-mono text-amber-800 mt-0.5">
              {onlineStats.totalOrdersCount} টি অর্ডার
            </p>
            <span className="text-[10px] text-amber-700 font-medium">
              ই-কমার্স স্টোরফ্রন্ট থেকে প্রাপ্ত
            </span>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-[11px] font-semibold text-slate-500 block">
              সর্বমোট অনলাইন অর্ডার মূল্য
            </span>
            <p className="text-lg font-extrabold font-mono text-slate-900 mt-0.5 tabular-nums">
              {formatCurrency(onlineStats.totalOrderValue)}
            </p>
            <span className="text-[10px] text-slate-500 font-medium">
              বাতিল ব্যতীত নিট অনলাইন অর্ডার
            </span>
          </div>
        </div>
      )}

      {/* Filter Tabs & Search */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg w-full md:w-auto overflow-x-auto">
          <button
            onClick={() => setTypeFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              typeFilter === 'all' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {language === 'bn' ? `সকল গ্রাহক (${customers.length})` : `All Customers (${customers.length})`}
          </button>
          <button
            onClick={() => setTypeFilter('online')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer ${
              typeFilter === 'online'
                ? 'bg-emerald-700 text-white font-bold shadow-xs'
                : 'text-emerald-800 hover:bg-emerald-50 font-semibold'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>
              {language === 'bn'
                ? `অনলাইন কাস্টমার (${onlineStats.totalOnlineCusts})`
                : `Online Customers (${onlineStats.totalOnlineCusts})`}
            </span>
          </button>
          <button
            onClick={() => setTypeFilter('due_only')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              typeFilter === 'due_only' ? 'bg-white text-rose-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {language === 'bn' ? 'বকেয়া বাকি তালিকা' : 'Due Customers Only'}
          </button>
          <button
            onClick={() => setTypeFilter('wholesale')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              typeFilter === 'wholesale' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {language === 'bn' ? 'পাইকারি ডিলার' : 'Wholesale Dealers'}
          </button>
          <button
            onClick={() => setTypeFilter('retail')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
              typeFilter === 'retail' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {language === 'bn' ? 'খুচরা কাস্টমার' : 'Retail Customers'}
          </button>
        </div>

        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'bn' ? 'গ্রাহকের নাম, ফোন বা ঠিকানা খুঁজুন...' : 'Search by name, phone or address...'}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-hidden text-slate-900"
          />
        </div>
      </div>

      {/* Customer Directory Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px]">
              <tr>
                <th className="px-4 py-3">{language === 'bn' ? 'গ্রাহকের নাম ও একাউন্ট' : 'Customer & Account'}</th>
                <th className="px-4 py-3">{language === 'bn' ? 'মোবাইল নম্বর' : 'Mobile Number'}</th>
                <th className="px-4 py-3">{language === 'bn' ? 'ডেলিভারি ঠিকানা ও রুট' : 'Delivery Address'}</th>
                <th className="px-4 py-3">{language === 'bn' ? 'গ্রাহকের ধরন' : 'Type'}</th>
                <th className="px-4 py-3 text-right">
                  {language === 'bn' ? 'অনলাইন অর্ডার / লেনদেন' : 'Online Orders'}
                </th>
                <th className="px-4 py-3 text-right">{language === 'bn' ? 'বর্তমান মোট বকেয়া' : 'Current Due'}</th>
                <th className="px-4 py-3 text-center">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-slate-400">
                    {language === 'bn'
                      ? 'কোনো গ্রাহক খুঁজে পাওয়া যায়নি।'
                      : 'No matching customers found.'}
                  </td>
                </tr>
              ) : (
                paginatedCustomers.map((cust) => {
                  const hasDue = cust.currentDue > 0;
                  const isOnline = cust.customerType === 'online' || Boolean(cust.isOnlineCustomer);
                  const custAllOrders = getCustomerAllOrderHistory(cust);
                  const totalOrdersSpent = custAllOrders
                    .filter(o => o.statusCategory !== 'Cancelled')
                    .reduce((s, o) => s + (o.grandTotal || 0), 0);
                  const custEntryCount = ledgerCountByCustId[cust.id] || 0;

                  return (
                    <tr key={cust.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="font-bold text-slate-900">{cust.name}</p>
                          {cust.password && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                              <UserCheck className="w-3 h-3 text-emerald-600" />
                              <span>একাউন্ট সক্রিয়</span>
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 mt-0.5">
                          {language === 'bn'
                            ? `আইডি: ${cust.id} · নিবন্ধন: ${cust.createdAt}`
                            : `ID: ${cust.id} · Joined: ${cust.createdAt}`}
                        </p>
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                        {cust.phone}
                      </td>
                      <td className="px-4 py-3 text-slate-600">
                        <p className="truncate max-w-xs font-medium text-slate-800">
                          {cust.address || '—'}
                        </p>
                        {cust.route && (
                          <p className="text-[10px] text-teal-700 font-medium">
                            {language === 'bn' ? `রুট: ${cust.route}` : `Route: ${cust.route}`}
                          </p>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {isOnline ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold">
                            <ShoppingBag className="w-3 h-3 text-emerald-600" />
                            <span>{language === 'bn' ? 'অনলাইন কাস্টমার' : 'Online Customer'}</span>
                          </span>
                        ) : cust.customerType === 'wholesale' ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-[11px] font-bold">
                            {language === 'bn' ? 'পাইকারি ডিলার' : 'Wholesale Dealer'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold">
                            {language === 'bn' ? 'খুচরা গ্রাহক' : 'Retail Shopper'}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        {custAllOrders.length > 0 || isOnline ? (
                          <button
                            type="button"
                            onClick={() => {
                              setOrderHistoryFilter('all');
                              setOrderHistorySearch('');
                              setOnlineOrdersModalCustomer(cust);
                            }}
                            className="text-right group cursor-pointer"
                            title={language === 'bn' ? 'অর্ডার হিস্ট্রি দেখতে ক্লিক করুন' : 'Click to view order history'}
                          >
                            <span className="font-mono font-bold text-emerald-800 group-hover:underline">
                              {custAllOrders.length} টি অর্ডার
                            </span>
                            <p className="text-[10px] font-mono text-slate-500">
                              মোট: {formatCurrency(totalOrdersSpent)}
                            </p>
                          </button>
                        ) : (
                          <div>
                            <span className="font-mono text-slate-600">
                              {custEntryCount} টি লেনদেন
                            </span>
                            <p className="text-[10px] font-mono text-slate-400">
                              লিমিট: {formatCurrency(cust.creditLimit)}
                            </p>
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold tabular-nums text-sm">
                        <span className={hasDue ? 'text-rose-700' : 'text-teal-700'}>
                          {formatCurrency(cust.currentDue)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setOrderHistoryFilter('all');
                              setOrderHistorySearch('');
                              setOnlineOrdersModalCustomer(cust);
                            }}
                            className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors ${
                              custAllOrders.length > 0
                                ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-2xs'
                                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'
                            }`}
                            title={language === 'bn' ? 'গ্রাহকের সকল পূর্ববর্তী অর্ডার হিস্ট্রি দেখুন' : 'View Order History'}
                          >
                            <History className="w-3.5 h-3.5" />
                            <span>
                              {language === 'bn'
                                ? `অর্ডার হিস্ট্রি (${custAllOrders.length})`
                                : `View Order History (${custAllOrders.length})`}
                            </span>
                          </button>

                          <button
                            onClick={() => openEditCustomerModal(cust)}
                            className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 border border-slate-200 rounded-md cursor-pointer transition-colors"
                            title={language === 'bn' ? 'কাস্টমার তথ্য ও পাসওয়ার্ড এডিট করুন' : 'Edit Customer / Password'}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          {hasDue && (
                            <>
                              <button
                                onClick={() => {
                                  setCollectingCustomer(cust);
                                  setCollectAmount(cust.currentDue);
                                  setCollectNote('বকেয়া আদায় রশিদ');
                                }}
                                className="px-2.5 py-1 bg-teal-700 hover:bg-teal-800 text-white rounded-md text-xs font-semibold cursor-pointer transition-colors"
                              >
                                {language === 'bn' ? 'বকেয়া কালেকশন' : 'Collect Due'}
                              </button>
                              <button
                                onClick={() => setSmsCustomer(cust)}
                                className="p-1.5 text-slate-600 hover:text-teal-700 hover:bg-teal-50 rounded-md cursor-pointer"
                                title={language === 'bn' ? 'এসএমএস তাগাদা বার্তা' : 'SMS Reminder'}
                              >
                                <MessageSquare className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => setStatementCustomer(cust)}
                            className="px-2.5 py-1 text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-md text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                            title={language === 'bn' ? 'গ্রাহক খতিয়ান বিবরণী দেখুন' : 'View Customer Statement'}
                          >
                            <FileText className="w-3.5 h-3.5 text-teal-700" />
                            <span>{language === 'bn' ? 'লেজার' : 'Ledger'}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {filteredCustomers.length > CUSTOMERS_PER_PAGE && (
          <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <p className="text-slate-600 font-semibold">
              মোট <span className="font-mono font-bold text-slate-900">{filteredCustomers.length}</span> জন গ্রাহকের মধ্যে{' '}
              <span className="font-mono font-bold text-emerald-700">
                {(safeCustomerPage - 1) * CUSTOMERS_PER_PAGE + 1}–
                {Math.min(safeCustomerPage * CUSTOMERS_PER_PAGE, filteredCustomers.length)}
              </span>{' '}
              দেখানো হচ্ছে (প্রতি পেজে ৫০ জন গ্রাহক)
            </p>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={safeCustomerPage <= 1}
                onClick={() => setCustomerPage(p => Math.max(1, p - 1))}
                className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold disabled:opacity-40 cursor-pointer"
              >
                ← আগের পেজ
              </button>
              <span className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-mono font-bold">
                পেজ {safeCustomerPage} / {totalCustomerPages}
              </span>
              <button
                type="button"
                disabled={safeCustomerPage >= totalCustomerPages}
                onClick={() => setCustomerPage(p => Math.min(totalCustomerPages, p + 1))}
                className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold disabled:opacity-40 cursor-pointer"
              >
                পরের পেজ →
              </button>
            </div>
          </div>
        )}
      </div>

      {/* View Order History Modal (Fetches & Displays All Previous Online + POS/Wholesale Orders for Customer Support) */}
      {liveOnlineOrdersCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full p-4 sm:p-6 border border-slate-200 text-xs space-y-4 my-auto">
            {/* Modal Top Header & Staff Support Quick Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3.5 border-b border-slate-200">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-white font-extrabold text-base flex items-center justify-center shrink-0 shadow-xs">
                  {liveOnlineOrdersCustomer.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                      {language === 'bn'
                        ? `${liveOnlineOrdersCustomer.name} — অর্ডার হিস্ট্রি (Order History)`
                        : `${liveOnlineOrdersCustomer.name} — Customer Order History`}
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                      {liveOnlineOrdersCustomer.customerType === 'wholesale'
                        ? 'পাইকারি ডিলার'
                        : liveOnlineOrdersCustomer.customerType === 'online' ||
                          liveOnlineOrdersCustomer.isOnlineCustomer
                        ? 'অনলাইন কাস্টমার'
                        : 'খুচরা কাস্টমার'}
                    </span>
                  </div>
                  <p className="text-slate-600 mt-0.5 font-mono font-bold">
                    মোবাইল: {liveOnlineOrdersCustomer.phone} · আইডি: {liveOnlineOrdersCustomer.id}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <a
                  href={`tel:${liveOnlineOrdersCustomer.phone}`}
                  className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold inline-flex items-center gap-1 cursor-pointer transition-colors"
                  title="সরাসরি কল করুন"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'কল করুন' : 'Call'}</span>
                </a>

                <a
                  href={`https://wa.me/${
                    liveOnlineOrdersCustomer.phone.startsWith('88')
                      ? liveOnlineOrdersCustomer.phone
                      : `88${normalizeBdPhone(liveOnlineOrdersCustomer.phone)}`
                  }?text=${encodeURIComponent(
                    `আসসালামু আলাইকুম ${liveOnlineOrdersCustomer.name}, আমাদের "${currentBusiness.name}" সাপোর্ট টিম থেকে যোগাযোগ করছি।`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold inline-flex items-center gap-1 cursor-pointer transition-colors"
                  title="WhatsApp-এ মেসেজ দিন"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>

                {selectedCustomerAllOrders.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      exportToCsv(
                        `Order_History_${liveOnlineOrdersCustomer.phone}`,
                        [
                          'Order_No',
                          'Invoice_No',
                          'Channel',
                          'Date',
                          'Status',
                          'Items',
                          'Grand_Total_BDT',
                          'Payment_Status',
                          'Delivery_Address'
                        ],
                        selectedCustomerAllOrders.map(r => [
                          r.orderNo,
                          r.invoiceNo,
                          r.channelLabelEn,
                          formatDate(r.createdAt),
                          r.statusCategory,
                          r.items.map(i => `${i.productName} x${i.quantity}`).join('; '),
                          r.grandTotal,
                          r.paymentStatus,
                          r.deliveryAddress || ''
                        ])
                      );
                    }}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg font-bold inline-flex items-center gap-1 cursor-pointer"
                    title="অর্ডার হিস্ট্রি CSV ডাউনলোড"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>CSV</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    const target = liveOnlineOrdersCustomer;
                    setOnlineOrdersModalCustomer(null);
                    openEditCustomerModal(target);
                  }}
                  className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 rounded-lg font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'প্রোফাইল এডিট' : 'Edit Profile'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setOnlineOrdersModalCustomer(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Customer Profile & Order Summary KPI Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-semibold text-slate-500 block">
                  {language === 'bn' ? 'মোট অর্ডার সংখ্যা' : 'Total Orders Placed'}
                </span>
                <p className="text-base sm:text-lg font-extrabold font-mono text-slate-900 mt-0.5">
                  {selectedCustomerOrderMetrics.totalCount} টি
                </p>
                <span className="text-[10px] text-slate-500">
                  {language === 'bn' ? 'অনলাইন ও শপ ইনভয়েস' : 'Online & POS combined'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
                <span className="text-[10px] font-semibold text-emerald-800 block">
                  {language === 'bn' ? 'ডেলিভারি / সম্পন্ন অর্ডার' : 'Delivered / Completed'}
                </span>
                <p className="text-base sm:text-lg font-extrabold font-mono text-emerald-800 mt-0.5">
                  {selectedCustomerOrderMetrics.deliveredCount} টি
                </p>
                <span className="text-[10px] text-emerald-700">
                  {language === 'bn' ? 'সফলভাবে ডেলিভারিকৃত' : 'Successfully fulfilled'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200">
                <span className="text-[10px] font-semibold text-amber-800 block">
                  {language === 'bn' ? 'চলমান অর্ডার (Pending/Processing)' : 'Active / Processing'}
                </span>
                <p className="text-base sm:text-lg font-extrabold font-mono text-amber-800 mt-0.5">
                  {selectedCustomerOrderMetrics.activeCount} টি
                </p>
                <span className="text-[10px] text-amber-700">
                  {language === 'bn'
                    ? `বাতিল: ${selectedCustomerOrderMetrics.cancelledCount} টি`
                    : `Cancelled: ${selectedCustomerOrderMetrics.cancelledCount}`}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200">
                <span className="text-[10px] font-semibold text-blue-800 block">
                  {language === 'bn' ? 'সর্বমোট অর্ডার মূল্য (Lifetime)' : 'Total Order Value'}
                </span>
                <p className="text-base sm:text-lg font-extrabold font-mono text-blue-900 mt-0.5 tabular-nums">
                  {formatCurrency(selectedCustomerOrderMetrics.lifetimeValue)}
                </p>
                <span className="text-[10px] text-blue-700">
                  {language === 'bn'
                    ? `বর্তমান বকেয়া: ${formatCurrency(liveOnlineOrdersCustomer.currentDue)}`
                    : `Current Due: ${formatCurrency(liveOnlineOrdersCustomer.currentDue)}`}
                </span>
              </div>
            </div>

            {/* Customer Contact & Saved Delivery Info Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-slate-50/90 px-3.5 py-2.5 rounded-xl border border-slate-200/80 text-[11px]">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
                <div className="truncate">
                  <span className="text-slate-400 font-semibold">সংরক্ষিত ডেলিভারি ঠিকানা: </span>
                  <span className="font-bold text-slate-800">
                    {liveOnlineOrdersCustomer.address || 'ঠিকানা দেওয়া হয়নি'}
                  </span>
                </div>
              </div>
              <div className="flex items-center sm:justify-end gap-2">
                <KeyRound className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                <span className="text-slate-500 font-medium">
                  স্টোরফ্রন্ট লগইন:{' '}
                  <strong className="text-emerald-800">
                    {liveOnlineOrdersCustomer.password
                      ? `পাসওয়ার্ড সক্রিয় (${liveOnlineOrdersCustomer.password})`
                      : 'গেস্ট প্রোফাইল (পাসওয়ার্ড সেট নেই)'}
                  </strong>
                </span>
              </div>
            </div>

            {/* Filter Tabs & Search inside Order History Modal */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
              <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                {[
                  { id: 'all', bn: `সব অর্ডার (${selectedCustomerAllOrders.length})`, en: `All (${selectedCustomerAllOrders.length})` },
                  { id: 'pending', bn: 'অপেক্ষমাণ (Pending)', en: 'Pending' },
                  { id: 'processing', bn: 'প্রসেসিং (Processing)', en: 'Processing' },
                  { id: 'delivered', bn: 'সম্পন্ন (Delivered)', en: 'Delivered' },
                  { id: 'cancelled', bn: 'বাতিল (Cancelled)', en: 'Cancelled' },
                  { id: 'pos', bn: 'শপ / পাইকারি ইনভয়েস', en: 'POS / Wholesale' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setOrderHistoryFilter(tab.id as typeof orderHistoryFilter)}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap cursor-pointer transition-colors ${
                      orderHistoryFilter === tab.id
                        ? 'bg-emerald-700 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {language === 'bn' ? tab.bn : tab.en}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={orderHistorySearch}
                  onChange={e => setOrderHistorySearch(e.target.value)}
                  placeholder={
                    language === 'bn'
                      ? 'অর্ডার নং বা পণ্যের নাম খুঁজুন...'
                      : 'Search order # or product...'
                  }
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs outline-hidden"
                />
              </div>
            </div>

            {/* Detailed Previous Orders List */}
            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {filteredCustomerOrderHistory.length === 0 ? (
                <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl space-y-1">
                  <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="font-bold text-slate-600">
                    {language === 'bn'
                      ? 'এই ফিল্টারে কোনো পূর্ববর্তী অর্ডার পাওয়া যায়নি।'
                      : 'No previous orders found for this customer.'}
                  </p>
                </div>
              ) : (
                filteredCustomerOrderHistory.map(rec => {
                  const badgeStyle =
                    rec.statusCategory === 'Delivered'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : rec.statusCategory === 'Cancelled'
                      ? 'bg-rose-100 text-rose-800 border-rose-300'
                      : rec.statusCategory === 'Processing'
                      ? 'bg-blue-100 text-blue-800 border-blue-300'
                      : 'bg-amber-100 text-amber-800 border-amber-300';

                  const StatusIcon =
                    rec.statusCategory === 'Delivered'
                      ? CheckCircle2
                      : rec.statusCategory === 'Cancelled'
                      ? XCircle
                      : rec.statusCategory === 'Processing'
                      ? Truck
                      : Clock;

                  return (
                    <div
                      key={rec.id}
                      className="p-3.5 rounded-xl border border-slate-200/90 bg-white hover:border-emerald-300 transition-colors space-y-2.5 shadow-2xs"
                    >
                      {/* Order Card Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono font-extrabold text-emerald-800 text-xs sm:text-sm">
                            #{rec.orderNo}
                          </span>
                          {rec.invoiceNo !== rec.orderNo && (
                            <span className="text-[11px] font-mono text-slate-500">
                              (ইনভয়েস: {rec.invoiceNo})
                            </span>
                          )}
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-bold">
                            {language === 'bn' ? rec.channelLabelBn : rec.channelLabelEn}
                          </span>
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[10px] font-extrabold border ${badgeStyle}`}
                          >
                            <StatusIcon className="w-3 h-3 shrink-0" />
                            <span>{rec.statusLabelBn}</span>
                          </span>
                        </div>

                        <div className="flex items-center gap-2.5">
                          {/* Quick Status Update Dropdown for Online Orders */}
                          {rec.rawOnlineOrder && (
                            <select
                              value={rec.rawOnlineOrder.orderStatus}
                              onChange={e =>
                                updateOnlineOrderStatus(
                                  rec.rawOnlineOrder!.id,
                                  e.target.value as OnlineOrderStatus
                                )
                              }
                              aria-label="Update customer order status"
                              className="px-2 py-1 rounded-lg border border-slate-300 bg-slate-50 hover:bg-white text-[11px] font-bold text-slate-800 cursor-pointer outline-hidden"
                            >
                              <option value="pending">অপেক্ষমাণ (Pending)</option>
                              <option value="confirmed">নিশ্চিতকৃত (Confirmed)</option>
                              <option value="packaging">প্যাকেজিং (Packaging)</option>
                              <option value="dispatched">ডেলিভারিতে (Dispatched)</option>
                              <option value="delivered">ডেলিভারি সম্পন্ন (Delivered)</option>
                              <option value="cancelled">বাতিল (Cancelled)</option>
                            </select>
                          )}

                          <div className="text-right">
                            <span className="font-mono font-extrabold text-sm text-slate-900 tabular-nums">
                              {formatCurrency(rec.grandTotal)}
                            </span>
                            <span className="block text-[10px] text-slate-400 font-mono">
                              {formatDate(rec.createdAt)}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Itemized Products Breakdown */}
                      <div className="bg-slate-50/80 rounded-lg border border-slate-200/70 p-2.5 space-y-1">
                        <div className="flex justify-between text-[10px] font-bold text-slate-500 border-b border-slate-200/70 pb-1">
                          <span>অর্ডারকৃত পণ্যের বিবরণ ({rec.items.length} টি আইটেম)</span>
                          <span>পরিমাণ × দর = মোট</span>
                        </div>
                        {rec.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between gap-2 text-[11px] py-0.5"
                          >
                            <div className="min-w-0">
                              <span className="font-bold text-slate-800">{item.productName}</span>
                              {item.variantLabel && !item.productName.includes(item.variantLabel) && (
                                <span className="ml-1.5 px-1.5 py-0.2 rounded bg-white border border-slate-200 text-[10px] text-slate-600">
                                  {item.variantLabel}
                                </span>
                              )}
                            </div>
                            <span className="font-mono tabular-nums text-slate-700 shrink-0">
                              {item.quantity} × {formatCurrency(item.unitPrice)} ={' '}
                              <strong className="text-slate-900">{formatCurrency(item.total)}</strong>
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Order Footer: Payment, Delivery Fee & Delivery Address */}
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] pt-0.5 text-slate-600">
                        <div className="flex flex-wrap items-center gap-2">
                          <span>
                            পেমেন্ট: <strong className="text-slate-800">{rec.paymentMethodLabel}</strong>
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              rec.paymentStatus === 'paid'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border border-amber-200'
                            }`}
                          >
                            {rec.paymentStatus === 'paid' ? 'পরিশোধিত (Paid)' : 'ক্যাশ অন ডেলিভারি / বকেয়া'}
                          </span>
                          {rec.deliveryCharge > 0 && (
                            <span className="font-mono text-slate-500">
                              ডেলিভারি: {formatCurrency(rec.deliveryCharge)}
                            </span>
                          )}
                          {rec.discountAmount > 0 && (
                            <span className="font-mono text-emerald-700 font-bold">
                              ছাড়: -{formatCurrency(rec.discountAmount)}
                            </span>
                          )}
                        </div>

                        {rec.deliveryAddress && (
                          <div className="text-slate-600 truncate max-w-sm">
                            <span className="text-slate-400 font-semibold">ঠিকানা: </span>
                            <span className="font-medium text-slate-800">
                              {rec.deliveryAddress}
                              {rec.deliveryArea ? ` (${rec.deliveryArea})` : ''}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => {
                  const target = liveOnlineOrdersCustomer;
                  setOnlineOrdersModalCustomer(null);
                  setStatementCustomer(target);
                }}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl inline-flex items-center gap-1.5 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-teal-700" />
                <span>{language === 'bn' ? 'পেমেন্ট লেজার / খতিয়ান দেখুন' : 'View Financial Ledger'}</span>
              </button>

              <button
                type="button"
                onClick={() => setOnlineOrdersModalCustomer(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl cursor-pointer"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Edit Customer & Password Reset Modal */}
      {editingCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 border border-slate-200 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Edit3 className="w-4 h-4 text-blue-700" />
                <span>গ্রাহকের তথ্য ও পাসওয়ার্ড আপডেট</span>
              </h3>
              <button
                onClick={() => setEditingCustomer(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditCustomerSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">গ্রাহকের নাম *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">মোবাইল নম্বর *</label>
                <input
                  type="text"
                  required
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">গ্রাহকের ধরন</label>
                  <select
                    value={editType}
                    onChange={(e) => setEditType(e.target.value as 'retail' | 'wholesale' | 'online')}
                    className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="online">অনলাইন কাস্টমার (Online)</option>
                    <option value="wholesale">পাইকারি ডিলার (Wholesale)</option>
                    <option value="retail">খুচরা ক্রেতা (Retail)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
                    <span>লগইন পাসওয়ার্ড</span>
                  </label>
                  <input
                    type="text"
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    placeholder="নতুন পাসওয়ার্ড সেট করুন"
                    className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">ডেলিভারি ঠিকানা</label>
                <input
                  type="text"
                  value={editAddress}
                  onChange={(e) => setEditAddress(e.target.value)}
                  className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 mt-4">
                <button
                  type="button"
                  onClick={() => setEditingCustomer(null)}
                  className="min-h-[40px] px-4 py-2 border border-slate-300 rounded-xl text-slate-600 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="min-h-[40px] px-5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl cursor-pointer"
                >
                  ডাটাবেজে আপডেট করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Collect Due Modal */}
      {liveCollectingCustomer && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 border border-slate-200 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h3 className="text-sm font-bold text-slate-900">
                {language === 'bn'
                  ? 'গ্রাহকের বকেয়া টাকা কালেকশন ভাউচার'
                  : 'Customer Due Collection Voucher'}
              </h3>
              <button
                onClick={() => setCollectingCustomer(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 mb-4 space-y-1">
              <p className="text-slate-600">
                {language === 'bn' ? 'গ্রাহকের নাম:' : 'Customer:'}{' '}
                <span className="font-bold text-slate-900">{liveCollectingCustomer.name}</span>
              </p>
              <p className="text-slate-600">
                {language === 'bn' ? 'বর্তমান মোট বকেয়া:' : 'Current Outstanding Due:'}{' '}
                <span className="font-bold text-rose-700 font-mono text-sm tabular-nums">
                  {formatCurrency(liveCollectingCustomer.currentDue)}
                </span>
              </p>
            </div>

            <form onSubmit={handleCollectSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  {language === 'bn' ? 'আদায়কৃত টাকার পরিমাণ (৳) *' : 'Collected Amount (৳) *'}
                </label>
                <input
                  type="number"
                  min="1"
                  max={liveCollectingCustomer.currentDue}
                  step="any"
                  required
                  value={collectAmount}
                  onChange={(e) => setCollectAmount(parseFloat(e.target.value) || 0)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-sm text-slate-900"
                />
                <p className="text-[11px] text-teal-700 font-medium mt-1">
                  {language === 'bn'
                    ? `জমা দেওয়ার পর অবশিষ্ট বকেয়া থাকবে: ${formatCurrency(Math.max(0, liveCollectingCustomer.currentDue - collectAmount))}`
                    : `Remaining due after payment: ${formatCurrency(Math.max(0, liveCollectingCustomer.currentDue - collectAmount))}`}
                </p>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  {language === 'bn' ? 'টাকা গ্রহণের মাধ্যম:' : 'Payment Method:'}
                </label>
                <select
                  value={collectMethod}
                  onChange={(e) => setCollectMethod(e.target.value as PaymentMethod)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-medium"
                >
                  <option value="cash">{language === 'bn' ? 'নগদ ক্যাশ (স্টোর ক্যাশ ড্রয়ার)' : 'Cash (Store Cash Drawer)'}</option>
                  <option value="bkash">{language === 'bn' ? 'বিকাশ মার্চেন্ট' : 'bKash Merchant'}</option>
                  <option value="nagad">{language === 'bn' ? 'নগদ মার্চেন্ট ওয়ালেট' : 'Nagad Merchant'}</option>
                  <option value="bank">{language === 'bn' ? 'ব্যাংক একাউন্ট ট্রান্সফার' : 'Bank Account Transfer'}</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  {language === 'bn' ? 'রশিদ বা রেফারেন্স নোট' : 'Receipt / Reference Note'}
                </label>
                <input
                  type="text"
                  value={collectNote}
                  onChange={(e) => setCollectNote(e.target.value)}
                  placeholder={language === 'bn' ? 'উদা: বকেয়া আদায় রশিদ / চেক নং' : 'e.g. Due collection receipt'}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 mt-4">
                <button
                  type="button"
                  onClick={() => setCollectingCustomer(null)}
                  className="px-3.5 py-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{language === 'bn' ? 'কালেকশন ও লেজারে যুক্ত করুন' : 'Confirm & Add to Ledger'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SMS Reminder Generator Modal */}
      {smsCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 border border-slate-200 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-teal-700" />
                <span>{language === 'bn' ? 'বকেয়া তাগাদা এসএমএস বার্তা' : 'Due Reminder SMS'}</span>
              </h3>
              <button onClick={() => setSmsCustomer(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-3 space-y-2">
              <p className="text-slate-500 text-[11px]">
                {language === 'bn' ? 'প্রাপক:' : 'Recipient:'}{' '}
                <span className="font-semibold text-slate-900">{smsCustomer.name} ({smsCustomer.phone})</span>
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[11px] text-slate-800 leading-relaxed select-all">
                {getSmsText(smsCustomer)}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 mt-4">
              <button
                type="button"
                onClick={() => setSmsCustomer(null)}
                className="px-3 py-1.5 border rounded-lg text-slate-600"
              >
                {language === 'bn' ? 'বন্ধ' : 'Close'}
              </button>
              <button
                type="button"
                onClick={() => copySmsText(getSmsText(smsCustomer))}
                className="px-4 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-lg flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'বার্তা কপি করুন' : 'Copy SMS'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Statement / Full Ledger Modal (Includes Sales, Opening Balance, Due Collections & Returns) */}
      {liveStatementCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6 border border-slate-200 text-xs print-area">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  {language === 'bn'
                    ? 'গ্রাহক খতিয়ান বিবরণী (Customer Statement & Payment Ledger)'
                    : 'Customer Account Statement & Payment History'}
                </h3>
                <p className="text-slate-600 mt-0.5 font-medium">
                  {liveStatementCustomer.name} · <span className="font-mono">{liveStatementCustomer.phone}</span>
                  {liveStatementCustomer.address ? ` · ${liveStatementCustomer.address}` : ''}
                </p>
              </div>

              <div className="flex items-center gap-2 no-print">
                {liveStatementCustomer.currentDue > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setCollectingCustomer(liveStatementCustomer);
                      setCollectAmount(liveStatementCustomer.currentDue);
                      setCollectNote('বকেয়া আদায় রশিদ');
                    }}
                    className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white rounded-lg font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Wallet className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? '+ বকেয়া জমা নিন' : '+ Collect Due'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleExportStatementCsv}
                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatementCustomer(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Summary KPI Cards inside Statement */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[11px] text-slate-500">
                  {language === 'bn' ? 'মোট ডেবিট (সর্বমোট বিল ও ওপেনিং):' : 'Total Debit (Billed + Opening):'}
                </span>
                <p className="text-base font-bold font-mono text-slate-900 mt-0.5 tabular-nums">
                  {formatCurrency(statementTotals.totalDebit)}
                </p>
              </div>

              <div className="p-3 bg-teal-50/60 rounded-lg border border-teal-200">
                <span className="text-[11px] text-teal-800 font-medium">
                  {language === 'bn' ? 'মোট ক্রেডিট (নগদ ও বকেয়া আদায় জমা):' : 'Total Credit (Paid & Due Collected):'}
                </span>
                <p className="text-base font-bold font-mono text-teal-700 mt-0.5 tabular-nums">
                  {formatCurrency(statementTotals.totalCredit)}
                </p>
              </div>

              <div className="p-3 bg-rose-50/60 rounded-lg border border-rose-200">
                <span className="text-[11px] text-rose-800 font-medium">
                  {language === 'bn' ? 'বর্তমান নিট অবশিষ্ট বকেয়া:' : 'Current Net Outstanding Due:'}
                </span>
                <p className="text-base font-bold font-mono text-rose-700 mt-0.5 tabular-nums">
                  {formatCurrency(liveStatementCustomer.currentDue)}
                </p>
              </div>
            </div>

            {/* Ledger History Table */}
            <div className="my-3 max-h-80 overflow-y-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 text-slate-700 font-semibold text-[11px] sticky top-0 border-b border-slate-200">
                  <tr>
                    <th className="p-2.5">{language === 'bn' ? 'তারিখ' : 'Date'}</th>
                    <th className="p-2.5">{language === 'bn' ? 'ভাউচার / রশিদ নং' : 'Voucher / Ref No'}</th>
                    <th className="p-2.5">{language === 'bn' ? 'লেনদেনের বিবরণ ও মাধ্যম' : 'Transaction Details'}</th>
                    <th className="p-2.5 text-right">{language === 'bn' ? 'ডেবিট (ক্রয়/বিল)' : 'Debit (Billed)'}</th>
                    <th className="p-2.5 text-right">{language === 'bn' ? 'ক্রেডিট (পরিশোধ/জমা)' : 'Credit (Paid)'}</th>
                    <th className="p-2.5 text-right">{language === 'bn' ? 'অবশিষ্ট বকেয়া' : 'Running Balance'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {statementEntries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">
                        {language === 'bn'
                          ? 'এই গ্রাহকের কোনো খতিয়ান লেনদেন পাওয়া যায়নি।'
                          : 'No ledger transactions found for this customer.'}
                      </td>
                    </tr>
                  ) : (
                    statementEntries.map((entry) => {
                      const badge = entryTypeBadge(entry.entryType);
                      const isPayment = entry.entryType === 'PAYMENT_COLLECTION';
                      return (
                        <tr
                          key={entry.id}
                          className={isPayment ? 'bg-teal-50/40 hover:bg-teal-50/80' : 'hover:bg-slate-50'}
                        >
                          <td className="p-2.5 font-mono text-slate-600 whitespace-nowrap tabular-nums">
                            {formatDate(entry.createdAt)}
                          </td>
                          <td className="p-2.5 font-mono font-bold text-slate-900 whitespace-nowrap">
                            {entry.referenceNo}
                          </td>
                          <td className="p-2.5">
                            <div className="flex items-center gap-1.5">
                              {isPayment ? (
                                <ArrowDownLeft className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                              ) : (
                                <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              )}
                              <span className={badge.className}>{badge.label}</span>
                            </div>
                            <p className="text-[11px] text-slate-600 mt-0.5">{entry.description}</p>
                            <p className="text-[10px] text-slate-400">
                              {language === 'bn' ? `এন্ট্রি: ${entry.createdBy}` : `By: ${entry.createdBy}`}
                            </p>
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums font-semibold text-slate-900">
                            {entry.debit > 0 ? formatCurrency(entry.debit) : '—'}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums font-bold text-teal-700">
                            {entry.credit > 0 ? formatCurrency(entry.credit) : '—'}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums font-bold text-rose-700">
                            {formatCurrency(entry.balanceAfter)}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-200">
              <span className="font-bold text-slate-900">
                {language === 'bn' ? 'মোট বর্তমান বকেয়া (Current Balance):' : 'Total Current Due Balance:'}
              </span>
              <span className="font-mono text-base font-bold text-rose-700 tabular-nums">
                {formatCurrency(liveStatementCustomer.currentDue)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Add New Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 border border-slate-200 text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">
              {language === 'bn' ? 'নতুন গ্রাহক / অনলাইন কাস্টমার নিবন্ধন' : 'Register New Customer / Dealer'}
            </h3>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  {language === 'bn' ? 'গ্রাহক / দোকানের নাম *' : 'Customer / Store Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={language === 'bn' ? 'গ্রাহকের নাম লিখুন' : 'e.g. Customer Name'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  {language === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}
                </label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="017XXXXXXXX"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    {language === 'bn' ? 'গ্রাহকের ধরন' : 'Customer Type'}
                  </label>
                  <select
                    value={customerType}
                    onChange={(e) => setCustomerType(e.target.value as 'retail' | 'wholesale' | 'online')}
                    className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="online">{language === 'bn' ? 'অনলাইন কাস্টমার (Online)' : 'Online Customer'}</option>
                    <option value="wholesale">{language === 'bn' ? 'পাইকারি ডিলার' : 'Wholesale Dealer'}</option>
                    <option value="retail">{language === 'bn' ? 'খুচরা ক্রেতা' : 'Retail Customer'}</option>
                  </select>
                </div>

                {customerType === 'online' ? (
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {language === 'bn' ? 'লগইন পাসওয়ার্ড (ঐচ্ছিক)' : 'Login Password'}
                    </label>
                    <input
                      type="text"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="কমপক্ষে ৪ অক্ষর"
                      className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {language === 'bn' ? 'বাকী সীমা (৳)' : 'Credit Limit (৳)'}
                    </label>
                    <input
                      type="number"
                      value={creditLimit}
                      onChange={(e) => setCreditLimit(parseFloat(e.target.value) || 0)}
                      className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                    />
                  </div>
                )}
              </div>

              {customerType !== 'online' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {language === 'bn' ? 'প্রারম্ভিক বকেয়া (৳)' : 'Opening Due (৳)'}
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={openingDue}
                      onChange={(e) => setOpeningDue(parseFloat(e.target.value) || 0)}
                      className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {language === 'bn' ? 'ডেলিভারি রুট / বাজার' : 'Delivery Route / Area'}
                    </label>
                    <input
                      type="text"
                      value={route}
                      onChange={(e) => setRoute(e.target.value)}
                      placeholder={language === 'bn' ? 'উদা: মিরপুর ১০ রুট' : 'e.g. Mirpur 10 Route'}
                      className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {language === 'bn' ? 'ডেলিভারি ঠিকানা' : 'Address'}
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder={language === 'bn' ? 'বাসা নং, রোড নং, এলাকা ও জেলা' : 'House, Road, Area'}
                  className="w-full min-h-[40px] p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 mt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="min-h-[40px] px-4 py-2 border border-slate-300 rounded-xl text-slate-600 cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="min-h-[40px] px-5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'ডাটাবেজে সংরক্ষণ করুন' : 'Save Customer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
