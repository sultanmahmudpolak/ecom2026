import React, { useState, useEffect, useMemo } from 'react';
import { useApp, normalizeBdPhone } from '../context/AppContext';
import { OnlineOrder, OnlineOrderStatus, IncompleteOrderStatus, SaleItem } from '../types';
import {
  ShoppingBag,
  Search,
  Truck,
  CheckCircle2,
  Clock,
  Package,
  XCircle,
  Printer,
  Phone,
  MapPin,
  ExternalLink,
  CreditCard,
  Eye,
  X,
  Settings2,
  Upload,
  Save,
  Trash2,
  AlertTriangle,
  MessageCircle,
  PlusCircle,
  Sparkles,
  Repeat,
  Send,
  RefreshCw,
  ShieldCheck,
  Download,
  FileText,
  Tag,
  Layers,
  Edit2,
  Lock,
  Unlock,
  Plus,
  Minus,
  UserCheck,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { exportToCsv, exportToExcel } from '../config/api';
import { processUploadedProductImage } from './ProductThumbnail';
import {
  bookSteadfastOrder,
  bookPathaoOrder,
  checkCustomerFraudAndRatio,
  computeOwnStoreCustomerRecord
} from '../utils/courierService';
import { SmartInvoiceSlipModal } from './SmartInvoiceSlipModal';

interface OnlineOrdersViewProps {
  onOpenStorefront?: () => void;
  onNavigate?: (view: string) => void;
}

const toBnDigits = (num: number | string): string =>
  String(num).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[Number(d)]);

export const getCleanCustomerNote = (rawNotes?: string): string => {
  if (!rawNotes) return '';
  return rawNotes
    .replace(
      /\[(?:ডাইরেক্ট বাই অর্ডার|Landing Page:|ফ্রি ডেলিভারি অফার:|স্পিন দ্য হুইল পুরস্কার:|স্পিন হুইল অফার:)[^\]]*\]/gi,
      ''
    )
    .split('|')
    .map(part => part.trim())
    .filter(Boolean)
    .join(' | ')
    .trim();
};

const formatRelativeTimeAgoBn = (isoString?: string, nowMs: number = Date.now()): string => {
  if (!isoString) return '—';
  const date = new Date(isoString);
  const timeMs = date.getTime();
  if (Number.isNaN(timeMs)) return '—';

  const diffMs = Math.max(0, nowMs - timeMs);
  const totalSeconds = Math.floor(diffMs / 1000);

  if (totalSeconds < 60) {
    return 'এইমাত্র';
  }

  const totalMinutes = Math.floor(totalSeconds / 60);
  if (totalMinutes < 60) {
    return `${toBnDigits(totalMinutes)} মিনিট আগে`;
  }

  const totalHours = Math.floor(totalMinutes / 60);
  const remMinutes = totalMinutes % 60;
  if (totalHours < 24) {
    return remMinutes > 0
      ? `${toBnDigits(totalHours)} ঘণ্টা ${toBnDigits(remMinutes)} মিনিট আগে`
      : `${toBnDigits(totalHours)} ঘণ্টা আগে`;
  }

  const totalDays = Math.floor(totalHours / 24);
  const remHours = totalHours % 24;
  if (totalDays < 30) {
    return remHours > 0
      ? `${toBnDigits(totalDays)} দিন ${toBnDigits(remHours)} ঘণ্টা আগে`
      : `${toBnDigits(totalDays)} দিন আগে`;
  }

  const totalMonths = Math.floor(totalDays / 30);
  const remDays = totalDays % 30;
  return remDays > 0
    ? `${toBnDigits(totalMonths)} মাস ${toBnDigits(remDays)} দিন আগে`
    : `${toBnDigits(totalMonths)} মাস আগে`;
};

export const OnlineOrdersView: React.FC<OnlineOrdersViewProps> = ({
  onOpenStorefront,
  onNavigate
}) => {
  const {
    language,
    currentUser,
    products,
    onlineOrders,
    updateOnlineOrderStatus,
    updateOnlineOrder,
    incompleteOrders,
    updateIncompleteOrderStatus,
    deleteIncompleteOrder,
    convertIncompleteToOrder,
    formatCurrency,
    formatDate,
    currentBusiness,
    updateBusiness,
    globalSearch,
    showToast
  } = useApp();

  const [activeMainTab, setActiveMainTab] = useState<'orders' | 'incomplete'>(() => {
    try {
      const saved = sessionStorage.getItem('sm_orders_initial_tab');
      if (saved === 'incomplete' || saved === 'orders') {
        sessionStorage.removeItem('sm_orders_initial_tab');
        return saved;
      }
    } catch {
      // ignore storage errors
    }
    return 'orders';
  });
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [incompleteFilter, setIncompleteFilter] = useState<'all' | IncompleteOrderStatus>('abandoned');
  const [searchTerm, setSearchTerm] = useState<string>(() => {
    try {
      const prefill = sessionStorage.getItem('sm_orders_search_prefill');
      if (prefill) {
        sessionStorage.removeItem('sm_orders_search_prefill');
        return prefill;
      }
    } catch {
      // ignore storage errors
    }
    return '';
  });
  const [selectedOrder, setSelectedOrder] = useState<OnlineOrder | null>(null);
  const [bulkPrintOrders, setBulkPrintOrders] = useState<OnlineOrder[]>([]);
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);
  const [editingDiscountOrderId, setEditingDiscountOrderId] = useState<string | null>(null);
  const [inlineDiscountInput, setInlineDiscountInput] = useState<string>('0');
  const [invoiceModalInitialMode, setInvoiceModalInitialMode] = useState<
    'invoice' | 'slip' | 'customize'
  >('invoice');
  const [showGlobalInvoiceCustomizer, setShowGlobalInvoiceCustomizer] = useState<boolean>(false);
  const canCustomizeInvoice =
    currentUser?.role === 'developer' || currentUser?.role === 'super_admin';
  const isOrderEditEnabled = currentBusiness.orderEditEnabled !== false;

  // Complete Order Edit & Modification Modal State (Address, Products/Size, Name & Alternative Phone)
  const [editingOrder, setEditingOrder] = useState<OnlineOrder | null>(null);
  const [editCustomerName, setEditCustomerName] = useState<string>('');
  const [editCustomerPhone, setEditCustomerPhone] = useState<string>('');
  const [editAlternativePhone, setEditAlternativePhone] = useState<string>('');
  const [editDeliveryArea, setEditDeliveryArea] = useState<string>('');
  const [editDeliveryAddress, setEditDeliveryAddress] = useState<string>('');
  const [editDeliveryCharge, setEditDeliveryCharge] = useState<string>('60');
  const [editDiscountAmount, setEditDiscountAmount] = useState<string>('0');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editItems, setEditItems] = useState<SaleItem[]>([]);
  const [addProductSearch, setAddProductSearch] = useState<string>('');
  const [selectedNewProductId, setSelectedNewProductId] = useState<string>('');
  const [selectedNewVariantId, setSelectedNewVariantId] = useState<string>('');
  const [newProductQty, setNewProductQty] = useState<number>(1);

  const [convertingId, setConvertingId] = useState<string | null>(null);
  const [showStoreConfig, setShowStoreConfig] = useState<boolean>(false);
  const [deliveryChargeInput, setDeliveryChargeInput] = useState<string>(
    String(currentBusiness.ecommerceDeliveryCharge ?? 60)
  );
  const [freeMinInput, setFreeMinInput] = useState<string>(
    String(currentBusiness.freeDeliveryMinOrder ?? 1000)
  );
  const [bookingCourierKey, setBookingCourierKey] = useState<string | null>(null);
  const [checkingFraudOrderId, setCheckingFraudOrderId] = useState<string | null>(null);
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  const [showMarketingExport, setShowMarketingExport] = useState<boolean>(false);

  // WhatsApp Message Template Customization & Blank Mode State
  const DEFAULT_WHATSAPP_ORDER_TEMPLATE =
    'আসসালামু আলাইকুম {name}, "{shop}" থেকে আপনার #{order_no} নম্বর অর্ডারটি পেয়েছি (মোট বিল: ৳{total})। আপনার কোনো তথ্য বা সাইজ পরিবর্তন থাকলে জানাতে পারেন। ধন্যবাদ!';
  const DEFAULT_WHATSAPP_ABANDONED_TEMPLATE =
    'আসসালামু আলাইকুম {name}, আপনি আমাদের "{shop}" থেকে ({items}) অর্ডার করার চেষ্টা করেছিলেন (মোট বিল: ৳{total})। আপনার অর্ডারটি কি কনফার্ম করে দেবো?';

  const [showWhatsAppSettingsModal, setShowWhatsAppSettingsModal] = useState<boolean>(false);
  const [waModalTab, setWaModalTab] = useState<'order' | 'abandoned'>('order');
  const [waOrderBlankDraft, setWaOrderBlankDraft] = useState<boolean>(
    Boolean(currentBusiness.whatsappOrderMessageBlank)
  );
  const [waOrderTemplateDraft, setWaOrderTemplateDraft] = useState<string>(
    currentBusiness.whatsappOrderTemplate !== undefined
      ? currentBusiness.whatsappOrderTemplate
      : DEFAULT_WHATSAPP_ORDER_TEMPLATE
  );
  const [waAbandonedBlankDraft, setWaAbandonedBlankDraft] = useState<boolean>(
    Boolean(currentBusiness.whatsappAbandonedMessageBlank)
  );
  const [waAbandonedTemplateDraft, setWaAbandonedTemplateDraft] = useState<string>(
    currentBusiness.whatsappAbandonedTemplate !== undefined
      ? currentBusiness.whatsappAbandonedTemplate
      : DEFAULT_WHATSAPP_ABANDONED_TEMPLATE
  );

  const handleOpenWhatsAppSettings = (initialTab: 'order' | 'abandoned' = 'order') => {
    setWaModalTab(initialTab);
    setWaOrderBlankDraft(Boolean(currentBusiness.whatsappOrderMessageBlank));
    setWaOrderTemplateDraft(
      currentBusiness.whatsappOrderTemplate !== undefined
        ? currentBusiness.whatsappOrderTemplate
        : DEFAULT_WHATSAPP_ORDER_TEMPLATE
    );
    setWaAbandonedBlankDraft(Boolean(currentBusiness.whatsappAbandonedMessageBlank));
    setWaAbandonedTemplateDraft(
      currentBusiness.whatsappAbandonedTemplate !== undefined
        ? currentBusiness.whatsappAbandonedTemplate
        : DEFAULT_WHATSAPP_ABANDONED_TEMPLATE
    );
    setShowWhatsAppSettingsModal(true);
  };

  const formatWaPhone = (rawPhone: string): string => {
    const digits = (rawPhone || '').replace(/\D/g, '');
    if (!digits) return '';
    return digits.startsWith('88') ? digits : `88${digits}`;
  };

  const getOrderWhatsAppUrl = (order: OnlineOrder): string => {
    const waPhone = formatWaPhone(order.customerPhone);
    const isBlank =
      Boolean(currentBusiness.whatsappOrderMessageBlank) ||
      (currentBusiness.whatsappOrderTemplate !== undefined &&
        currentBusiness.whatsappOrderTemplate.trim() === '');

    if (isBlank) {
      return `https://wa.me/${waPhone}`;
    }

    const template =
      currentBusiness.whatsappOrderTemplate !== undefined
        ? currentBusiness.whatsappOrderTemplate
        : DEFAULT_WHATSAPP_ORDER_TEMPLATE;

    const itemsStr = (order.items || [])
      .map(
        i =>
          `${i.productName}${i.variantLabel ? ` (${i.variantLabel})` : ''}${
            i.quantity > 1 ? ` x${i.quantity}` : ''
          }`
      )
      .join(', ');

    const finalMsg = template
      .replace(/\{name\}|\{customer_name\}/g, order.customerName || 'গ্রাহক')
      .replace(/\{shop\}|\{shop_name\}/g, currentBusiness.name || '')
      .replace(/\{order_no\}/g, order.orderNo || '')
      .replace(/\{invoice_no\}/g, order.invoiceNo || '')
      .replace(/\{total\}|\{total_bill\}/g, String(order.grandTotal ?? 0))
      .replace(/\{items\}|\{products\}/g, itemsStr)
      .replace(/\{address\}/g, order.deliveryAddress || '')
      .replace(/\{phone\}/g, order.customerPhone || '')
      .trim();

    if (!finalMsg) {
      return `https://wa.me/${waPhone}`;
    }

    return `https://wa.me/${waPhone}?text=${encodeURIComponent(finalMsg)}`;
  };

  const getIncompleteWhatsAppUrl = (inc: (typeof incompleteOrders)[number]): string => {
    const waPhone = formatWaPhone(inc.customerPhone);
    const isBlank =
      Boolean(currentBusiness.whatsappAbandonedMessageBlank) ||
      (currentBusiness.whatsappAbandonedTemplate !== undefined &&
        currentBusiness.whatsappAbandonedTemplate.trim() === '');

    if (isBlank) {
      return `https://wa.me/${waPhone}`;
    }

    const template =
      currentBusiness.whatsappAbandonedTemplate !== undefined
        ? currentBusiness.whatsappAbandonedTemplate
        : DEFAULT_WHATSAPP_ABANDONED_TEMPLATE;

    const itemsStr = (inc.items || [])
      .map(
        i =>
          `${i.productName}${i.variantLabel ? ` (${i.variantLabel})` : ''}${
            i.quantity > 1 ? ` x${i.quantity}` : ''
          }`
      )
      .join(', ');

    const finalMsg = template
      .replace(/\{name\}|\{customer_name\}/g, inc.customerName || 'ভাইয়া/আপু')
      .replace(/\{shop\}|\{shop_name\}/g, currentBusiness.name || '')
      .replace(/\{total\}|\{total_bill\}/g, String(inc.grandTotal ?? 0))
      .replace(/\{items\}|\{products\}/g, itemsStr)
      .replace(/\{address\}/g, inc.deliveryAddress || '')
      .replace(/\{phone\}/g, inc.customerPhone || '')
      .trim();

    if (!finalMsg) {
      return `https://wa.me/${waPhone}`;
    }

    return `https://wa.me/${waPhone}?text=${encodeURIComponent(finalMsg)}`;
  };

  const handleOpenOrderEditModal = (order: OnlineOrder) => {
    if (!isOrderEditEnabled) {
      showToast(
        '🔒 অর্ডার এডিট সিস্টেম বর্তমানে ডেভেলপার/অ্যাডমিন অ্যাকাউন্ট থেকে বন্ধ (OFF) করে রাখা হয়েছে! স্টোর ম্যানেজার বা অন্য কারো জন্য অর্ডার পরিবর্তন অনুমোদিত নয়।',
        'error'
      );
      return;
    }
    setEditingOrder(order);
    setEditCustomerName(order.customerName || '');
    setEditCustomerPhone(order.customerPhone || '');
    setEditAlternativePhone(order.alternativePhone || '');
    setEditDeliveryArea(order.deliveryArea || 'ঢাকার ভিতরে (Inside Dhaka)');
    setEditDeliveryAddress(order.deliveryAddress || '');
    setEditDeliveryCharge(String(order.deliveryCharge ?? 60));
    setEditDiscountAmount(String(order.discountAmount ?? 0));
    setEditNotes(getCleanCustomerNote(order.notes));
    setEditItems(
      (order.items || []).map(it => ({
        ...it,
        quantity: Math.max(1, Number(it.quantity) || 1),
        unitPrice: Number(it.unitPrice) || 0,
        total: (Number(it.unitPrice) || 0) * Math.max(1, Number(it.quantity) || 1)
      }))
    );
    setAddProductSearch('');
    const firstProd = products[0];
    setSelectedNewProductId(firstProd?.id || '');
    setSelectedNewVariantId(firstProd?.variants?.[0]?.id || '');
    setNewProductQty(1);
  };

  const editModalFilteredProducts = useMemo(() => {
    const q = addProductSearch.trim().toLowerCase();
    if (!q) return products;
    return products.filter(
      p =>
        (p.nameBn || '').toLowerCase().includes(q) ||
        (p.nameEn || '').toLowerCase().includes(q) ||
        (p.sku || '').toLowerCase().includes(q)
    );
  }, [products, addProductSearch]);

  const selectedProductToAdd = useMemo(
    () =>
      products.find(p => p.id === selectedNewProductId) ||
      editModalFilteredProducts[0] ||
      null,
    [products, selectedNewProductId, editModalFilteredProducts]
  );

  const editCalculatedSubtotal = useMemo(
    () =>
      editItems.reduce(
        (sum, item) => sum + (Number(item.unitPrice) || 0) * Math.max(1, Number(item.quantity) || 1),
        0
      ),
    [editItems]
  );

  const editCalculatedDelivery = Math.max(0, Math.round(Number(editDeliveryCharge) || 0));
  const editCalculatedDiscount = Math.max(0, Math.round(Number(editDiscountAmount) || 0));
  const editCalculatedGrandTotal = Math.max(
    0,
    editCalculatedSubtotal + editCalculatedDelivery - editCalculatedDiscount
  );

  const handleAddProductToEditOrder = () => {
    if (!selectedProductToAdd) {
      showToast('অর্ডারে যোগ করার জন্য একটি প্রোডাক্ট সিলেক্ট করুন', 'error');
      return;
    }
    const chosenVariant =
      selectedProductToAdd.variants && selectedProductToAdd.variants.length > 0
        ? selectedProductToAdd.variants.find(v => v.id === selectedNewVariantId) ||
          selectedProductToAdd.variants[0]
        : undefined;

    const unitPrice = chosenVariant
      ? Number(
          chosenVariant.discountPrice && chosenVariant.discountPrice > 0
            ? chosenVariant.discountPrice
            : chosenVariant.retailPrice
        ) || selectedProductToAdd.retailPrice
      : Number(
          selectedProductToAdd.discountPrice && selectedProductToAdd.discountPrice > 0
            ? selectedProductToAdd.discountPrice
            : selectedProductToAdd.retailPrice
        ) || 0;

    const safeQty = Math.max(1, Math.round(Number(newProductQty) || 1));
    const variantLabel = chosenVariant?.label || '';
    const variantId = chosenVariant?.id || undefined;
    const variantSku = chosenVariant?.sku || selectedProductToAdd.sku;

    setEditItems(prev => {
      const existingIdx = prev.findIndex(
        it =>
          it.productId === selectedProductToAdd.id &&
          (it.variantLabel || '') === (variantLabel || '')
      );
      if (existingIdx !== -1) {
        const updated = [...prev];
        const cur = updated[existingIdx];
        const nextQty = (Number(cur.quantity) || 1) + safeQty;
        updated[existingIdx] = {
          ...cur,
          quantity: nextQty,
          unitPrice,
          total: unitPrice * nextQty
        };
        return updated;
      }

      const newItem: SaleItem = {
        productId: selectedProductToAdd.id,
        productName: selectedProductToAdd.nameBn || selectedProductToAdd.nameEn,
        productNameClean: selectedProductToAdd.nameBn || selectedProductToAdd.nameEn,
        image: selectedProductToAdd.image,
        sku: selectedProductToAdd.sku,
        parentSku: selectedProductToAdd.sku,
        variantSku,
        variantId,
        variantLabel: variantLabel || undefined,
        unit: selectedProductToAdd.unit || 'পিস',
        quantity: safeQty,
        unitPrice,
        costPrice: chosenVariant?.purchasePrice ?? selectedProductToAdd.purchasePrice ?? 0,
        discount: 0,
        total: unitPrice * safeQty
      };
      return [...prev, newItem];
    });

    setNewProductQty(1);
    showToast(
      `✅ "${selectedProductToAdd.nameBn}${variantLabel ? ` (${variantLabel})` : ''}" অর্ডারে যুক্ত হয়েছে!`,
      'success'
    );
  };

  const handleSaveOrderEdits = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;
    if (!isOrderEditEnabled) {
      showToast('🔒 অর্ডার এডিট সিস্টেম বর্তমানে বন্ধ (OFF) আছে!', 'error');
      return;
    }
    const cleanPhone = editCustomerPhone.trim();
    if (!cleanPhone) {
      showToast('কাস্টমারের মূল মোবাইল নাম্বার খালি রাখা যাবে না', 'error');
      return;
    }
    if (editItems.length === 0) {
      showToast('অর্ডারে অন্তত ১টি প্রোডাক্ট থাকতে হবে', 'error');
      return;
    }

    const changeParts: string[] = [];
    if (editCustomerName.trim() !== (editingOrder.customerName || '')) {
      changeParts.push(`নাম পরিবর্তন (${editCustomerName.trim()})`);
    }
    if (cleanPhone !== (editingOrder.customerPhone || '')) {
      changeParts.push(`নাম্বার পরিবর্তন (${cleanPhone})`);
    }
    if (editAlternativePhone.trim() !== (editingOrder.alternativePhone || '')) {
      changeParts.push(
        editAlternativePhone.trim()
          ? `বিকল্প নাম্বার যোগ (${editAlternativePhone.trim()})`
          : 'বিকল্প নাম্বার রিমুভ'
      );
    }
    if (
      editDeliveryAddress.trim() !== (editingOrder.deliveryAddress || '') ||
      editDeliveryArea.trim() !== (editingOrder.deliveryArea || '')
    ) {
      changeParts.push('ডেলিভারি ঠিকানা/এরিয়া পরিবর্তন');
    }
    const oldItemsKey = (editingOrder.items || [])
      .map(i => `${i.productId}:${i.variantLabel || ''}:${i.quantity}:${i.unitPrice}`)
      .join('|');
    const newItemsKey = editItems
      .map(i => `${i.productId}:${i.variantLabel || ''}:${i.quantity}:${i.unitPrice}`)
      .join('|');
    if (oldItemsKey !== newItemsKey) {
      changeParts.push(`প্রোডাক্ট/সাইজ আপডেট (${editItems.length} টি পণ্য)`);
    }
    if (editCalculatedGrandTotal !== editingOrder.grandTotal) {
      changeParts.push(`মোট বিল ৳${editingOrder.grandTotal} → ৳${editCalculatedGrandTotal}`);
    }

    const summaryText =
      changeParts.length > 0 ? changeParts.join(', ') : 'অর্ডার তথ্য আপডেট করা হয়েছে';

    const nextHistory = [
      ...(editingOrder.editHistory || []),
      {
        editedAt: new Date().toISOString(),
        editedBy: `${currentUser?.name || 'Admin'} (${currentUser?.role || 'admin'})`,
        summary: summaryText
      }
    ];

    updateOnlineOrder(editingOrder.id, {
      customerName: editCustomerName.trim() || 'অনলাইন ক্রেতা',
      customerPhone: cleanPhone,
      alternativePhone: editAlternativePhone.trim() || undefined,
      deliveryArea: editDeliveryArea.trim() || 'ঢাকার ভিতরে (Inside Dhaka)',
      deliveryAddress: editDeliveryAddress.trim(),
      items: editItems.map(it => ({
        ...it,
        quantity: Math.max(1, Number(it.quantity) || 1),
        unitPrice: Number(it.unitPrice) || 0,
        total: (Number(it.unitPrice) || 0) * Math.max(1, Number(it.quantity) || 1)
      })),
      subtotal: editCalculatedSubtotal,
      deliveryCharge: editCalculatedDelivery,
      discountAmount: editCalculatedDiscount,
      grandTotal: editCalculatedGrandTotal,
      notes: editNotes.trim() || undefined,
      editHistory: nextHistory
    });

    setEditingOrder(null);
    showToast(
      `✅ অর্ডার #${editingOrder.orderNo} সফলভাবে আপডেট হয়েছে! (${summaryText})`,
      'success'
    );
  };

  const handleApplyInlineSpecialDiscount = (order: OnlineOrder, rawAmount: number) => {
    const safeDiscount = Math.max(0, Math.round(Number(rawAmount) || 0));
    const newGrandTotal = Math.max(
      0,
      Number(order.subtotal || 0) + Number(order.deliveryCharge || 0) - safeDiscount
    );
    updateOnlineOrder(order.id, {
      discountAmount: safeDiscount,
      grandTotal: newGrandTotal
    });
    setEditingDiscountOrderId(null);
    showToast(
      safeDiscount > 0
        ? `অর্ডার #${order.orderNo}-এ ৳${safeDiscount} স্পেশাল ডিসকাউন্ট যোগ করা হয়েছে! নতুন বিল: ৳${newGrandTotal}`
        : `অর্ডার #${order.orderNo}-এর স্পেশাল ডিসকাউন্ট রিমুভ করা হয়েছে`,
      'success'
    );
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      setNowTick(Date.now());
    }, 30000);
    return () => window.clearInterval(timer);
  }, []);

  const handleQuickCourierSend = async (
    order: OnlineOrder,
    provider: 'steadfast' | 'pathao'
  ) => {
    setBookingCourierKey(`${order.id}_${provider}`);
    try {
      const res =
        provider === 'steadfast'
          ? await bookSteadfastOrder(order, currentBusiness)
          : await bookPathaoOrder(order, currentBusiness);

      if (res.ok) {
        updateOnlineOrder(order.id, {
          courierProvider: provider,
          courierConsignmentId: res.consignmentId || '',
          courierTrackingCode: res.trackingCode || res.consignmentId || '',
          courierStatus: res.status || 'in_review',
          courierBookedAt: new Date().toISOString(),
          orderStatus: 'dispatched'
        });
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setBookingCourierKey(null);
    }
  };

  const handleQuickFraudCheck = async (order: OnlineOrder) => {
    setCheckingFraudOrderId(order.id);
    try {
      const res = await checkCustomerFraudAndRatio(
        order.customerPhone,
        currentBusiness,
        onlineOrders,
        incompleteOrders
      );
      updateOnlineOrder(order.id, {
        fraudCheckSummary: {
          totalParcels: res.combinedTotalParcels,
          deliveredParcels: res.combinedDelivered,
          cancelledParcels: res.combinedCancelled,
          successRatio: res.combinedSuccessRatio,
          riskLevel: res.riskLevel,
          checkedAt: res.checkedAt
        }
      });
      showToast(
        `${order.customerPhone}: ডেলিভারি রেশিও ${res.combinedSuccessRatio}% (মোট: ${res.combinedDelivered}/${res.combinedTotalParcels}) — ${res.verdictBn}`,
        res.riskLevel === 'high_risk' ? 'error' : 'success'
      );
    } finally {
      setCheckingFraudOrderId(null);
    }
  };

  const handleSaveQuickDeliveryConfig = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      ecommerceDeliveryCharge: Math.max(0, Number(deliveryChargeInput) || 0),
      freeDeliveryMinOrder: Math.max(0, Number(freeMinInput) || 0)
    });
    setShowStoreConfig(false);
    showToast(
      language === 'bn'
        ? 'ই-কমার্স ডেলিভারি চার্জ ও লোগো সেটিংস আপডেট হয়েছে!'
        : 'Delivery charge & logo settings updated!'
    );
  };

  const handleQuickLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processUploadedProductImage(file, 420);
      updateBusiness({ logoUrl: dataUrl });
      showToast(language === 'bn' ? 'স্টোর লোগো আপলোড সম্পন্ন হয়েছে!' : 'Store logo uploaded!');
    } catch {
      showToast(language === 'bn' ? 'লোগো আপলোড ব্যর্থ হয়েছে' : 'Logo upload failed', 'error');
    } finally {
      e.target.value = '';
    }
  };

  const effectiveSearchTerm = (searchTerm.trim() || globalSearch.trim()).toLowerCase().replace(/^#/, '');

  const filteredOrders = useMemo(() => {
    return onlineOrders.filter(o => {
      if (statusFilter === 'processing') {
        if (
          o.orderStatus !== 'confirmed' &&
          o.orderStatus !== 'packaging' &&
          o.orderStatus !== 'dispatched'
        ) {
          return false;
        }
      } else if (statusFilter !== 'all' && o.orderStatus !== statusFilter) {
        return false;
      }
      if (effectiveSearchTerm) {
        const q = effectiveSearchTerm;
        return (
          o.orderNo.toLowerCase().includes(q) ||
          o.invoiceNo.toLowerCase().includes(q) ||
          o.customerName.toLowerCase().includes(q) ||
          o.customerPhone.includes(q) ||
          normalizeBdPhone(o.customerPhone).includes(normalizeBdPhone(q)) ||
          o.deliveryAddress.toLowerCase().includes(q) ||
          o.deliveryArea.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [onlineOrders, statusFilter, effectiveSearchTerm]);

  const filteredIncompleteOrders = useMemo(() => {
    return incompleteOrders.filter(inc => {
      if (incompleteFilter !== 'all' && inc.status !== incompleteFilter) return false;
      if (effectiveSearchTerm) {
        const q = effectiveSearchTerm;
        return (
          inc.customerName.toLowerCase().includes(q) ||
          inc.customerPhone.includes(q) ||
          normalizeBdPhone(inc.customerPhone).includes(normalizeBdPhone(q)) ||
          inc.deliveryAddress.toLowerCase().includes(q) ||
          inc.items.some(i => i.productName.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [incompleteOrders, incompleteFilter, effectiveSearchTerm]);

  const ORDERS_PER_PAGE = 50;
  const [orderPage, setOrderPage] = useState<number>(1);
  const [incompletePage, setIncompletePage] = useState<number>(1);

  useEffect(() => {
    setOrderPage(1);
  }, [statusFilter, effectiveSearchTerm]);

  useEffect(() => {
    setIncompletePage(1);
  }, [incompleteFilter, effectiveSearchTerm]);

  const totalOrderPages = Math.max(1, Math.ceil(filteredOrders.length / ORDERS_PER_PAGE));
  const safeOrderPage = Math.min(orderPage, totalOrderPages);
  const paginatedOrders = useMemo(() => {
    const start = (safeOrderPage - 1) * ORDERS_PER_PAGE;
    return filteredOrders.slice(start, start + ORDERS_PER_PAGE);
  }, [filteredOrders, safeOrderPage]);

  const totalIncompletePages = Math.max(
    1,
    Math.ceil(filteredIncompleteOrders.length / ORDERS_PER_PAGE)
  );
  const safeIncompletePage = Math.min(incompletePage, totalIncompletePages);
  const paginatedIncompleteOrders = useMemo(() => {
    const start = (safeIncompletePage - 1) * ORDERS_PER_PAGE;
    return filteredIncompleteOrders.slice(start, start + ORDERS_PER_PAGE);
  }, [filteredIncompleteOrders, safeIncompletePage]);

  // Duplicate / Fake Order & Repeat Customer Detection Map by normalized 11-digit phone
  const phoneOrderHistoryMap = useMemo(() => {
    const todayDateStr = new Date().toISOString().split('T')[0];
    const map: Record<
      string,
      {
        totalOrders: number;
        todayOrders: number;
        cancelledOrders: number;
        incompleteCount: number;
      }
    > = {};

    onlineOrders.forEach(o => {
      const key = normalizeBdPhone(o.customerPhone || '');
      if (!key) return;
      if (!map[key]) {
        map[key] = { totalOrders: 0, todayOrders: 0, cancelledOrders: 0, incompleteCount: 0 };
      }
      map[key].totalOrders += 1;
      if ((o.createdAt || '').startsWith(todayDateStr)) {
        map[key].todayOrders += 1;
      }
      if (o.orderStatus === 'cancelled') {
        map[key].cancelledOrders += 1;
      }
    });

    incompleteOrders.forEach(inc => {
      const key = normalizeBdPhone(inc.customerPhone || '');
      if (!key) return;
      if (!map[key]) {
        map[key] = { totalOrders: 0, todayOrders: 0, cancelledOrders: 0, incompleteCount: 0 };
      }
      map[key].incompleteCount += 1;
    });

    return map;
  }, [onlineOrders, incompleteOrders]);

  const metrics = useMemo(() => {
    const pendingOnlyCount = onlineOrders.filter(o => o.orderStatus === 'pending').length;
    const processingCount = onlineOrders.filter(
      o =>
        o.orderStatus === 'confirmed' ||
        o.orderStatus === 'packaging' ||
        o.orderStatus === 'dispatched'
    ).length;
    const deliveredCount = onlineOrders.filter(o => o.orderStatus === 'delivered').length;
    const cancelledCount = onlineOrders.filter(o => o.orderStatus === 'cancelled').length;

    const pendingCount = onlineOrders.filter(
      o => o.orderStatus === 'pending'
    ).length;
    const activeDeliveryCount = onlineOrders.filter(
      o => o.orderStatus === 'packaging' || o.orderStatus === 'dispatched'
    ).length;
    const deliveredOrders = onlineOrders.filter(o => o.orderStatus !== 'cancelled');
    const totalWebRevenue = deliveredOrders.reduce((s, o) => s + o.grandTotal, 0);

    const abandonedLeads = incompleteOrders.filter(
      inc => inc.status === 'abandoned'
    );
    const abandonedCount = abandonedLeads.length;
    const abandonedValue = abandonedLeads.reduce((s, inc) => s + inc.grandTotal, 0);
    const contactedCount = incompleteOrders.filter(inc => inc.status === 'contacted').length;
    const convertedCount = incompleteOrders.filter(inc => inc.status === 'converted').length;
    const ignoredCount = incompleteOrders.filter(inc => inc.status === 'ignored').length;

    return {
      totalOrders: onlineOrders.length,
      pendingOnlyCount,
      processingCount,
      deliveredCount,
      cancelledCount,
      pendingCount,
      activeDeliveryCount,
      totalWebRevenue,
      abandonedCount,
      abandonedValue,
      contactedCount,
      convertedCount,
      ignoredCount
    };
  }, [onlineOrders, incompleteOrders]);

  const handleConvertToRealOrder = async (id: string) => {
    setConvertingId(id);
    try {
      const order = await convertIncompleteToOrder(id);
      if (order) {
        setActiveMainTab('orders');
      }
    } catch {
      showToast('অর্ডার কনফার্ম করতে ইন্টারনেট সংযোগ চেক করুন', 'error');
    } finally {
      setConvertingId(null);
    }
  };

  const statusLabels: Record<
    OnlineOrderStatus,
    {
      bn: string;
      en: string;
      badgeLabel: 'Pending' | 'Processing' | 'Delivered' | 'Cancelled';
      badgeBn: string;
      subStageBn?: string;
      subStageEn?: string;
      badgeClass: string;
      dotClass: string;
      colorClass: string;
      IconComponent: React.ComponentType<{ className?: string }>;
    }
  > = {
    pending: {
      bn: 'অপেক্ষমাণ (Pending)',
      en: 'Pending',
      badgeLabel: 'Pending',
      badgeBn: 'অপেক্ষমাণ',
      badgeClass: 'bg-amber-100 text-amber-800 border-amber-300 shadow-2xs',
      dotClass: 'bg-amber-500 animate-pulse',
      colorClass: 'text-amber-900 bg-amber-50/90 border-amber-200 hover:border-amber-300',
      IconComponent: Clock
    },
    confirmed: {
      bn: 'নিশ্চিতকৃত (Confirmed)',
      en: 'Processing · Confirmed',
      badgeLabel: 'Processing',
      badgeBn: 'প্রসেসিং',
      subStageBn: 'নিশ্চিতকৃত',
      subStageEn: 'Confirmed',
      badgeClass: 'bg-blue-100 text-blue-800 border-blue-300 shadow-2xs',
      dotClass: 'bg-blue-600 animate-pulse',
      colorClass: 'text-blue-900 bg-blue-50/90 border-blue-200 hover:border-blue-300',
      IconComponent: Package
    },
    packaging: {
      bn: 'প্যাকেজিং চলছে (Packing)',
      en: 'Processing · Packing',
      badgeLabel: 'Processing',
      badgeBn: 'প্রসেসিং',
      subStageBn: 'প্যাকেজিং',
      subStageEn: 'Packing',
      badgeClass: 'bg-blue-100 text-blue-800 border-blue-300 shadow-2xs',
      dotClass: 'bg-blue-600 animate-pulse',
      colorClass: 'text-blue-900 bg-blue-50/90 border-blue-200 hover:border-blue-300',
      IconComponent: Package
    },
    dispatched: {
      bn: 'ডেলিভারিতে আছে (On Way)',
      en: 'Processing · On Way',
      badgeLabel: 'Processing',
      badgeBn: 'প্রসেসিং',
      subStageBn: 'ডেলিভারিতে',
      subStageEn: 'On Way',
      badgeClass: 'bg-blue-100 text-blue-800 border-blue-300 shadow-2xs',
      dotClass: 'bg-blue-600 animate-pulse',
      colorClass: 'text-blue-900 bg-blue-50/90 border-blue-200 hover:border-blue-300',
      IconComponent: Truck
    },
    delivered: {
      bn: 'ডেলিভারি সম্পন্ন (Delivered)',
      en: 'Delivered',
      badgeLabel: 'Delivered',
      badgeBn: 'ডেলিভারি সম্পন্ন',
      badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300 shadow-2xs',
      dotClass: 'bg-emerald-600',
      colorClass: 'text-emerald-900 bg-emerald-50/90 border-emerald-200 hover:border-emerald-300',
      IconComponent: CheckCircle2
    },
    cancelled: {
      bn: 'বাতিলকৃত (Cancelled)',
      en: 'Cancelled',
      badgeLabel: 'Cancelled',
      badgeBn: 'বাতিলকৃত',
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 shadow-2xs',
      dotClass: 'bg-rose-600',
      colorClass: 'text-rose-900 bg-rose-50/90 border-rose-200 hover:border-rose-300',
      IconComponent: XCircle
    }
  };

  const incompleteStatusLabels: Record<
    IncompleteOrderStatus,
    { bn: string; en: string; colorClass: string }
  > = {
    abandoned: {
      bn: 'কল করা বাকি (Abandoned)',
      en: 'Abandoned / Call Needed',
      colorClass: 'text-rose-800 bg-rose-50 border-rose-200'
    },
    contacted: {
      bn: 'কথা হয়েছে (Contacted)',
      en: 'Contacted',
      colorClass: 'text-amber-800 bg-amber-50 border-amber-200'
    },
    converted: {
      bn: 'অর্ডার সম্পন্ন (Recovered)',
      en: 'Converted to Order',
      colorClass: 'text-emerald-800 bg-emerald-50 border-emerald-200'
    },
    ignored: {
      bn: 'বাতিল / অপ্রয়োজনীয় (Ignored)',
      en: 'Ignored',
      colorClass: 'text-slate-600 bg-slate-100 border-slate-200'
    }
  };

  return (
    <div className="space-y-6">
      {/* 5 KPI Summary Cards (Mobile-friendly responsive grid) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-4">
        <div
          onClick={() => setActiveMainTab('orders')}
          className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-5 cursor-pointer hover:border-blue-300 transition-colors shadow-2xs"
        >
          <p className="text-[11px] sm:text-xs font-medium text-slate-500">
            {language === 'bn' ? 'মোট অনলাইন অর্ডার' : 'Total Online Orders'}
          </p>
          <p className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {metrics.totalOrders}
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 sm:mt-1">
            {language === 'bn' ? 'ইআরপি ইনভয়েস সংযুক্ত' : 'Synced with ERP sales'}
          </p>
        </div>

        <div
          onClick={() => {
            setActiveMainTab('orders');
            setStatusFilter('pending');
          }}
          className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-5 cursor-pointer hover:border-amber-300 transition-colors shadow-2xs"
        >
          <p className="text-[11px] sm:text-xs font-medium text-slate-500">
            {language === 'bn' ? 'নতুন / অপেক্ষমাণ অর্ডার' : 'Pending Confirmation'}
          </p>
          <p className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-amber-700 mt-1">
            {metrics.pendingCount}
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 sm:mt-1">
            {language === 'bn' ? 'দ্রুত কনফার্ম ও প্যাক করুন' : 'Awaiting store dispatch'}
          </p>
        </div>

        {/* Highlighted KPI Card: Incomplete / Abandoned Checkouts */}
        <div
          onClick={() => {
            setActiveMainTab('incomplete');
            setIncompleteFilter('abandoned');
          }}
          className={`rounded-2xl border-2 p-3 sm:p-5 cursor-pointer transition-all shadow-2xs ${
            metrics.abandonedCount > 0
              ? 'bg-rose-50/70 border-rose-300 hover:border-rose-400'
              : 'bg-white border-slate-200/90 hover:border-rose-300'
          }`}
        >
          <div className="flex items-center justify-between gap-1">
            <p className="text-[11px] sm:text-xs font-bold text-rose-800">
              {language === 'bn' ? 'অসম্পূর্ণ অর্ডার' : 'Abandoned Checkouts'}
            </p>
            {metrics.abandonedCount > 0 && (
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
            )}
          </div>
          <p className="text-xl sm:text-2xl font-extrabold font-mono tabular-nums text-rose-700 mt-1">
            {metrics.abandonedCount}
          </p>
          <p className="text-[10px] sm:text-[11px] text-rose-700/80 font-semibold mt-0.5 sm:mt-1 truncate">
            {language === 'bn'
              ? `সম্ভাব্য সেল: ${formatCurrency(metrics.abandonedValue)}`
              : `Recoverable: ${formatCurrency(metrics.abandonedValue)}`}
          </p>
        </div>

        <div
          onClick={() => setActiveMainTab('orders')}
          className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-5 cursor-pointer hover:border-blue-300 transition-colors shadow-2xs"
        >
          <p className="text-[11px] sm:text-xs font-medium text-slate-500">
            {language === 'bn' ? 'ডেলিভারিতে চলমান' : 'Packing & On the Way'}
          </p>
          <p className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-blue-700 mt-1">
            {metrics.activeDeliveryCount}
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 sm:mt-1">
            {language === 'bn' ? 'রাইডার হোম ডেলিভারি' : 'Active rider deliveries'}
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-5 col-span-2 sm:col-span-1 lg:col-span-1 shadow-2xs">
          <p className="text-[11px] sm:text-xs font-medium text-slate-500">
            {language === 'bn' ? 'মোট অনলাইন বিক্রয় (BDT)' : 'Total Online Sales'}
          </p>
          <p className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-emerald-800 mt-1">
            {formatCurrency(metrics.totalWebRevenue)}
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 sm:mt-1">
            {language === 'bn' ? 'বাতিল অর্ডার ব্যতীত' : 'Excluding cancelled orders'}
          </p>
        </div>
      </div>

      {/* Primary Tab Switcher + 1-Click Marketing Data Download Bar (Excel & Google Sheet) */}
      <div className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-200/90 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveMainTab('orders')}
              className={`px-3 sm:px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeMainTab === 'orders'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span className="truncate">
                {language === 'bn' ? 'সম্পূর্ণ অর্ডার' : 'Completed Orders'} ({onlineOrders.length})
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveMainTab('incomplete')}
              className={`px-3 sm:px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${
                activeMainTab === 'incomplete'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span className="truncate">
                {language === 'bn'
                  ? 'অসম্পূর্ণ অর্ডার'
                  : 'Abandoned'}
              </span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-mono font-extrabold ${
                  activeMainTab === 'incomplete'
                    ? 'bg-white text-rose-700'
                    : 'bg-rose-600 text-white'
                }`}
              >
                {metrics.abandonedCount}
              </span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* WhatsApp Message Edit / Blank Mode Button */}
            <button
              type="button"
              onClick={() =>
                handleOpenWhatsAppSettings(activeMainTab === 'incomplete' ? 'abandoned' : 'order')
              }
              className="px-3 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-300 transition-all cursor-pointer shadow-2xs"
              title="অর্ডার ও অসম্পূর্ণ অর্ডারের WhatsApp মেসেজ নিজের মতো এডিট করুন অথবা সম্পূর্ণ ফাঁকা (Blank) রাখুন"
            >
              <MessageCircle className="w-3.5 h-3.5 text-teal-700 shrink-0" />
              <span>WhatsApp মেসেজ এডিট</span>
              <span
                className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                  currentBusiness.whatsappOrderMessageBlank ||
                  (currentBusiness.whatsappOrderTemplate !== undefined &&
                    currentBusiness.whatsappOrderTemplate.trim() === '')
                    ? 'bg-amber-500 text-white'
                    : 'bg-teal-600 text-white'
                }`}
              >
                {currentBusiness.whatsappOrderMessageBlank ||
                (currentBusiness.whatsappOrderTemplate !== undefined &&
                  currentBusiness.whatsappOrderTemplate.trim() === '')
                  ? 'ফাঁকা (Blank)'
                  : 'চালু'}
              </span>
            </button>

            {canCustomizeInvoice && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setInvoiceModalInitialMode('customize');
                    setShowGlobalInvoiceCustomizer(true);
                  }}
                  className="px-3 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 transition-all cursor-pointer"
                  title="ইনভয়েস ও ডেলিভারি স্লিপের লেখা, লোগো, ডোমেইন ও সাইজ টেমপ্লেট কাস্টমাইজ করুন (শুধুমাত্র অ্যাডমিন ও ডেভেলপার)"
                >
                  <Settings2 className="w-3.5 h-3.5 text-blue-700" />
                  <span>ইনভয়েস কাস্টমাইজ</span>
                </button>

                {/* Developer / Super Admin 1-Click Master ON/OFF Lock Control for Order Edit System */}
                <button
                  type="button"
                  onClick={() => {
                    const nextVal = !isOrderEditEnabled;
                    updateBusiness({ orderEditEnabled: nextVal });
                    showToast(
                      nextVal
                        ? '✅ অর্ডার এডিট সিস্টেম চালু (ON) করা হয়েছে — এখন অর্ডারের ঠিকানা, প্রোডাক্ট, সাইজ ও নাম্বার পরিবর্তন করা যাবে।'
                        : '🔒 অর্ডার এডিট সিস্টেম বন্ধ (OFF) করা হয়েছে — স্টোর ম্যানেজার বা অন্য কেউ আর অর্ডার এডিট করতে পারবে না!',
                      nextVal ? 'success' : 'info'
                    );
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    isOrderEditEnabled
                      ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-rose-50 hover:bg-rose-100 text-rose-800 border-rose-300'
                  }`}
                  title="ডেভেলপার / অ্যাডমিন কন্ট্রোল: এটি বন্ধ (OFF) করলে স্টোর ম্যানেজার বা অন্য কেউ অর্ডারের ঠিকানা, প্রোডাক্ট বা নাম এডিট করতে পারবে না"
                >
                  {isOrderEditEnabled ? (
                    <Unlock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  )}
                  <span>এডিট:</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase ${
                      isOrderEditEnabled
                        ? 'bg-emerald-600 text-white'
                        : 'bg-rose-600 text-white'
                    }`}
                  >
                    {isOrderEditEnabled ? 'ON' : 'OFF'}
                  </span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* 1-Click Excel & Google Sheet Download Bar for Marketing (Strictly Developer & Admin Only) */}
        {canCustomizeInvoice && (
          <div className="pt-2 border-t border-slate-100">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200/80">
              <button
                type="button"
                onClick={() => setShowMarketingExport(prev => !prev)}
                className="text-xs font-extrabold text-emerald-950 flex items-center justify-between gap-2 w-full sm:w-auto cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>মার্কেটিং কাস্টমার ডাটা ডাউনলোড (Excel / CSV)</span>
                </span>
                <span className="sm:hidden text-[10px] font-bold text-emerald-800 px-2 py-0.5 bg-emerald-100 rounded-md">
                  {showMarketingExport ? 'হাইড ▲' : 'ডাউনলোড দেখুন ▼'}
                </span>
              </button>

              <div className={`${showMarketingExport ? 'flex' : 'hidden sm:flex'} flex-wrap items-center gap-1.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-emerald-200/60`}>
              {/* 1. Completed Orders Download (Excel & Google Sheet CSV) */}
              <button
                type="button"
                onClick={() => {
                  const target = filteredOrders.length > 0 ? filteredOrders : onlineOrders;
                  if (target.length === 0) {
                    showToast('ডাউনলোড করার মতো কোনো অর্ডারের ডাটা নেই', 'error');
                    return;
                  }
                  exportToExcel(
                    'Completed_Orders_Customer_Data',
                    'Completed_Orders',
                    [
                      'ক্রমিক নং',
                      'অর্ডার নং',
                      'ইনভয়েস নং',
                      'কাস্টমারের নাম',
                      'মোবাইল নাম্বার',
                      'ডেলিভারি এরিয়া',
                      'পূর্ণ ঠিকানা',
                      'অর্ডারকৃত পণ্য ও ভ্যারিয়েশন',
                      'সাবটোটাল (৳)',
                      'ডেলিভারি চার্জ (৳)',
                      'ছাড় (৳)',
                      'মোট বিল (৳)',
                      'অর্ডার স্ট্যাটাস',
                      'কুরিয়ার ট্র্যাকিং',
                      'তারিখ'
                    ],
                    target.map((o, idx) => [
                      idx + 1,
                      o.orderNo,
                      o.invoiceNo,
                      o.customerName,
                      o.customerPhone,
                      o.deliveryArea,
                      o.deliveryAddress,
                      (o.items || [])
                        .map(
                          it =>
                            `${it.productName}${it.variantLabel ? ` (${it.variantLabel})` : ''} x${it.quantity}`
                        )
                        .join(', '),
                      o.subtotal,
                      o.deliveryCharge,
                      o.discountAmount || 0,
                      o.grandTotal,
                      statusLabels[o.orderStatus]?.bn || o.orderStatus,
                      o.courierTrackingCode
                        ? `${o.courierProvider || ''} (${o.courierTrackingCode})`
                        : 'বুকিং হয়নি',
                      formatDate(o.createdAt)
                    ])
                  );
                  showToast(
                    `${target.length} টি অর্ডারের কাস্টমার ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
                    'success'
                  );
                }}
                className="px-3 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                title="যারা অর্ডার করেছে তাদের সকল ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3.5 h-3.5" />
                <span>অর্ডার ডাটা Excel ({onlineOrders.length})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const target = filteredOrders.length > 0 ? filteredOrders : onlineOrders;
                  if (target.length === 0) {
                    showToast('ডাউনলোড করার মতো কোনো অর্ডারের ডাটা নেই', 'error');
                    return;
                  }
                  exportToCsv(
                    'Completed_Orders_Google_Sheet',
                    [
                      'SL',
                      'Order_No',
                      'Invoice_No',
                      'Customer_Name',
                      'Mobile_Number',
                      'Delivery_Area',
                      'Full_Address',
                      'Ordered_Products',
                      'Subtotal_BDT',
                      'Delivery_Charge_BDT',
                      'Discount_BDT',
                      'Grand_Total_BDT',
                      'Order_Status',
                      'Courier_Tracking',
                      'Date'
                    ],
                    target.map((o, idx) => [
                      idx + 1,
                      o.orderNo,
                      o.invoiceNo,
                      o.customerName,
                      o.customerPhone,
                      o.deliveryArea,
                      o.deliveryAddress,
                      (o.items || [])
                        .map(
                          it =>
                            `${it.productName}${it.variantLabel ? ` (${it.variantLabel})` : ''} x${it.quantity}`
                        )
                        .join(', '),
                      o.subtotal,
                      o.deliveryCharge,
                      o.discountAmount || 0,
                      o.grandTotal,
                      statusLabels[o.orderStatus]?.en || o.orderStatus,
                      o.courierTrackingCode || '',
                      formatDate(o.createdAt)
                    ])
                  );
                  showToast(
                    `${target.length} টি অর্ডারের কাস্টমার ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড হয়েছে!`,
                    'success'
                  );
                }}
                className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-blue-50 text-blue-800 border border-blue-300 text-xs font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
                title="অর্ডারকৃত কাস্টমারদের ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3 h-3" />
                <span>অর্ডার Sheet (CSV)</span>
              </button>

              {/* 2. Incomplete / Abandoned Orders Download (Excel & Google Sheet CSV) */}
              <button
                type="button"
                onClick={() => {
                  const target =
                    filteredIncompleteOrders.length > 0 ? filteredIncompleteOrders : incompleteOrders;
                  if (target.length === 0) {
                    showToast('ডাউনলোড করার মতো কোনো অসম্পূর্ণ অর্ডার (Incomplete) ডাটা নেই', 'error');
                    return;
                  }
                  exportToExcel(
                    'Incomplete_Orders_Marketing_Data',
                    'Incomplete_Orders',
                    [
                      'ক্রমিক নং',
                      'কাস্টমারের নাম',
                      'মোবাইল নাম্বার',
                      'পছন্দের পণ্যসমূহ (Cart Items)',
                      'ডেলিভারি এরিয়া',
                      'ঠিকানা',
                      'সম্ভাব্য বিল (৳)',
                      'স্ট্যাটাস',
                      'তারিখ ও সময়'
                    ],
                    target.map((inc, idx) => [
                      idx + 1,
                      inc.customerName || 'নাম লেখেনি',
                      inc.customerPhone,
                      (inc.items || [])
                        .map(
                          it =>
                            `${it.productName}${it.variantLabel ? ` (${it.variantLabel})` : ''} x${it.quantity}`
                        )
                        .join(', '),
                      inc.deliveryArea || '',
                      inc.deliveryAddress || 'ঠিকানা লেখার আগেই বের হয়ে গেছে',
                      inc.grandTotal,
                      incompleteStatusLabels[inc.status]?.bn || inc.status,
                      `${formatDate(inc.updatedAt)} ${new Date(inc.updatedAt).toLocaleTimeString('bn-BD')}`
                    ])
                  );
                  showToast(
                    `${target.length} টি অসম্পূর্ণ অর্ডার (Incomplete)-এর ডাটা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
                    'success'
                  );
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                title="অসম্পূর্ণ অর্ডার (Incomplete)-এ যত কাস্টমার ডাটা আছে তা ১-ক্লিকে Excel (.xls) ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3.5 h-3.5" />
                <span>অসম্পূর্ণ অর্ডার Excel ({incompleteOrders.length})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const target =
                    filteredIncompleteOrders.length > 0 ? filteredIncompleteOrders : incompleteOrders;
                  if (target.length === 0) {
                    showToast('ডাউনলোড করার মতো কোনো অসম্পূর্ণ অর্ডার (Incomplete) ডাটা নেই', 'error');
                    return;
                  }
                  exportToCsv(
                    'Incomplete_Orders_Google_Sheet',
                    [
                      'SL',
                      'Customer_Name',
                      'Mobile_Number',
                      'Cart_Items',
                      'Delivery_Area',
                      'Address',
                      'Probable_Bill_BDT',
                      'Status',
                      'Date_Time'
                    ],
                    target.map((inc, idx) => [
                      idx + 1,
                      inc.customerName || 'Not Provided',
                      inc.customerPhone,
                      (inc.items || [])
                        .map(
                          it =>
                            `${it.productName}${it.variantLabel ? ` (${it.variantLabel})` : ''} x${it.quantity}`
                        )
                        .join(', '),
                      inc.deliveryArea || '',
                      inc.deliveryAddress || '',
                      inc.grandTotal,
                      incompleteStatusLabels[inc.status]?.en || inc.status,
                      new Date(inc.updatedAt).toLocaleString('en-GB')
                    ])
                  );
                  showToast(
                    `${target.length} টি অসম্পূর্ণ অর্ডারের ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড হয়েছে!`,
                    'success'
                  );
                }}
                className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-rose-800 border border-rose-300 text-xs font-extrabold flex items-center gap-1 cursor-pointer transition-colors"
                title="অসম্পূর্ণ অর্ডারের ডাটা Google Sheet (CSV) ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3 h-3" />
                <span>অসম্পূর্ণ Sheet (CSV)</span>
              </button>

              {/* 3. All Combined Marketing Leads (Orders + Incomplete + Spin Wheel) 1-Click Excel */}
              <button
                type="button"
                onClick={() => {
                  const spinLeads = [
                    ...(currentBusiness.spinWheelLeads || []),
                    ...(currentBusiness.landingSpinWheelLeads || [])
                  ];
                  const combinedRows: (string | number)[][] = [];
                  let sl = 1;

                  onlineOrders.forEach(o => {
                    combinedRows.push([
                      sl++,
                      o.customerName || 'কাস্টমার',
                      o.customerPhone,
                      'অর্ডারকৃত কাস্টমার (Completed Order)',
                      o.deliveryAddress || o.deliveryArea || '',
                      (o.items || []).map(i => i.productName).join(', '),
                      o.grandTotal,
                      formatDate(o.createdAt)
                    ]);
                  });

                  incompleteOrders.forEach(inc => {
                    combinedRows.push([
                      sl++,
                      inc.customerName || 'নাম লেখেনি',
                      inc.customerPhone,
                      'অসম্পূর্ণ অর্ডার (Incomplete Checkout)',
                      inc.deliveryAddress || inc.deliveryArea || '',
                      (inc.items || []).map(i => i.productName).join(', '),
                      inc.grandTotal,
                      formatDate(inc.updatedAt)
                    ]);
                  });

                  spinLeads.forEach(sp => {
                    combinedRows.push([
                      sl++,
                      sp.customerName || sp.name || 'কাস্টমার',
                      sp.customerPhone || sp.phone || '',
                      sp.source === 'landing'
                        ? 'ল্যান্ডিং পেজ স্পিন হুইল (Spin Wheel)'
                        : 'ওয়েবসাইট স্পিন হুইল (Spin Wheel)',
                      '',
                      `পুরস্কার: ${sp.rewardLabel || sp.prizeLabel || ''} (${sp.couponCode || sp.prizeCode || ''})`,
                      0,
                      formatDate(sp.createdAt)
                    ]);
                  });

                  if (combinedRows.length === 0) {
                    showToast('ডাউনলোড করার মতো কোনো মার্কেটিং ডাটা পাওয়া যায়নি', 'error');
                    return;
                  }

                  exportToExcel(
                    'All_Marketing_Customer_Leads_Master_Sheet',
                    'All_Marketing_Leads',
                    [
                      'ক্রমিক নং',
                      'কাস্টমারের নাম',
                      'মোবাইল নাম্বার',
                      'ডাটা সোর্স (অর্ডার / অসম্পূর্ণ / স্পিন হুইল)',
                      'ঠিকানা / এরিয়া',
                      'পণ্য বা জেতা অফার',
                      'বিল / মূল্য (৳)',
                      'তারিখ'
                    ],
                    combinedRows
                  );
                  showToast(
                    `সর্বমোট ${combinedRows.length} টি মার্কেটিং ডাটা (অর্ডার + অসম্পূর্ণ + স্পিন হুইল) একসাথে Excel (.xls) ফাইলে ডাউনলোড হয়েছে!`,
                    'success'
                  );
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                title="অর্ডার + অসম্পূর্ণ অর্ডার + স্পিন হুইল — সব কাস্টমারের নাম্বার ও ডাটা ১-ক্লিকে এক ফাইলে ডাউনলোড করুন"
              >
                <Download className="w-3.5 h-3.5" />
                <span>সব মার্কেটিং ডাটা একসাথে (All Excel)</span>
              </button>
            </div>
          </div>
        </div>
        )}
      </div>

      {activeMainTab === 'orders' ? (
        <>
          {/* Filter & Search Bar for Completed Orders */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-4 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
              {[
                {
                  id: 'all',
                  bn: `সব অর্ডার (${metrics.totalOrders})`,
                  en: `All Orders (${metrics.totalOrders})`,
                  dot: 'bg-slate-400'
                },
                {
                  id: 'pending',
                  bn: `অপেক্ষমাণ · Pending (${metrics.pendingOnlyCount})`,
                  en: `Pending (${metrics.pendingOnlyCount})`,
                  dot: 'bg-amber-500'
                },
                {
                  id: 'processing',
                  bn: `প্রসেসিং · Processing (${metrics.processingCount})`,
                  en: `Processing (${metrics.processingCount})`,
                  dot: 'bg-blue-600'
                },
                {
                  id: 'delivered',
                  bn: `সম্পন্ন · Delivered (${metrics.deliveredCount})`,
                  en: `Delivered (${metrics.deliveredCount})`,
                  dot: 'bg-emerald-600'
                },
                {
                  id: 'cancelled',
                  bn: `বাতিল · Cancelled (${metrics.cancelledCount})`,
                  en: `Cancelled (${metrics.cancelledCount})`,
                  dot: 'bg-rose-600'
                },
                { id: 'confirmed', bn: 'নিশ্চিতকৃত', en: 'Confirmed' },
                { id: 'packaging', bn: 'প্যাকেজিং', en: 'Packing' },
                { id: 'dispatched', bn: 'ডেলিভারিতে', en: 'On Way' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5 cursor-pointer ${
                    statusFilter === tab.id
                      ? 'bg-blue-700 text-white'
                      : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.dot && (
                    <span
                      className={`w-2 h-2 rounded-full shrink-0 ${
                        statusFilter === tab.id ? 'bg-white' : tab.dot
                      }`}
                    />
                  )}
                  <span>{language === 'bn' ? tab.bn : tab.en}</span>
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
              {paginatedOrders.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    const targetOrders =
                      selectedOrderIds.length > 0
                        ? filteredOrders.filter((o) => selectedOrderIds.includes(o.id))
                        : paginatedOrders;
                    if (targetOrders.length === 0) return;
                    setBulkPrintOrders(targetOrders);
                    setSelectedOrder(targetOrders[0]);
                    setInvoiceModalInitialMode('slip');
                  }}
                  className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  title="নির্বাচিত সব অর্ডার অথবা বর্তমান পেজের সব অর্ডারের শিপিং স্লিপ একসাথে প্রিন্ট বা PDF ডাউনলোড করুন"
                >
                  <Layers className="w-3.5 h-3.5 text-amber-300" />
                  <span>
                    {selectedOrderIds.length > 0
                      ? `বাল্ক শিপিং প্রিন্ট (${selectedOrderIds.length} টি)`
                      : `বাল্ক শিপিং প্রিন্ট (${paginatedOrders.length} টি)`}
                  </span>
                </button>
              )}

              <div className="relative flex-1 lg:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder={
                    language === 'bn'
                      ? 'অর্ডার নং, নাম বা মোবাইল নম্বর খুঁজুন...'
                      : 'Search order #, customer, phone...'
                  }
                  className="w-full min-h-[38px] pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-xl outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Bulk Print Action Banner when orders are checked */}
          {selectedOrderIds.length > 0 && (
            <div className="bg-blue-950 text-white rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-sm border border-blue-800">
              <div className="flex items-center gap-2.5">
                <span className="px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-mono font-extrabold text-xs">
                  {selectedOrderIds.length} টি অর্ডার সিলেক্ট করা হয়েছে
                </span>
                <span className="text-xs text-blue-100 font-medium">
                  স্টিকার প্রিন্টার (4×6&quot; / 3×4&quot;) বা রেগুলার প্রিন্টারে এক ক্লিকে সবগুলো প্রিন্ট বা মাল্টি-পেজ PDF ডাউনলোড করুন
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const chosen = filteredOrders.filter((o) => selectedOrderIds.includes(o.id));
                    if (chosen.length === 0) return;
                    setBulkPrintOrders(chosen);
                    setSelectedOrder(chosen[0]);
                    setInvoiceModalInitialMode('slip');
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>বাল্ক শিপিং স্লিপ প্রিন্ট / PDF ({selectedOrderIds.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const chosen = filteredOrders.filter((o) => selectedOrderIds.includes(o.id));
                    if (chosen.length === 0) return;
                    setBulkPrintOrders(chosen);
                    setSelectedOrder(chosen[0]);
                    setInvoiceModalInitialMode('invoice');
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>বাল্ক ইনভয়েস প্রিন্ট / PDF ({selectedOrderIds.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedOrderIds([])}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
                >
                  সিলেকশন মুছুন
                </button>
              </div>
            </div>
          )}

          {/* Orders Table */}
          <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden">
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase">
                    <th className="py-3.5 pl-4 pr-2 w-9">
                      <input
                        type="checkbox"
                        checked={
                          paginatedOrders.length > 0 &&
                          paginatedOrders.every((o) => selectedOrderIds.includes(o.id))
                        }
                        onChange={(e) => {
                          if (e.target.checked) {
                            const pageIds = paginatedOrders.map((o) => o.id);
                            setSelectedOrderIds((prev) =>
                              Array.from(new Set([...prev, ...pageIds]))
                            );
                          } else {
                            const pageIdSet = new Set(paginatedOrders.map((o) => o.id));
                            setSelectedOrderIds((prev) => prev.filter((id) => !pageIdSet.has(id)));
                          }
                        }}
                        aria-label="Select all orders on this page"
                        className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                      />
                    </th>
                    <th className="py-3.5 px-4">অর্ডার ও তারিখ</th>
                    <th className="py-3.5 px-4">গ্রাহক ও মোবাইল</th>
                    <th className="py-3.5 px-4">ডেলিভারি এলাকা ও স্লট</th>
                    <th className="py-3.5 px-4 text-right">সর্বমোট বিল ও ডিসকাউন্ট</th>
                    <th className="py-3.5 px-4">পেমেন্ট মাধ্যম</th>
                    <th className="py-3.5 px-4">বর্তমান স্ট্যাটাস (Status Badge)</th>
                    <th className="py-3.5 px-4 text-right">অ্যাকশন / আপডেট</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredOrders.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-500">
                        {language === 'bn'
                          ? 'কোনো অনলাইন অর্ডার পাওয়া যায়নি'
                          : 'No online orders found'}
                      </td>
                    </tr>
                  ) : (
                    paginatedOrders.map((order) => {
                      const stInfo = statusLabels[order.orderStatus];
                      const StatusIcon = stInfo.IconComponent;
                      const phoneKey = normalizeBdPhone(order.customerPhone || '');
                      const phoneHist = phoneKey ? phoneOrderHistoryMap[phoneKey] : undefined;
                      const isDuplicateToday = (phoneHist?.todayOrders || 0) >= 2;
                      const isRepeatCustomer = (phoneHist?.totalOrders || 0) >= 2;
                      const isChecked = selectedOrderIds.includes(order.id);

                      return (
                        <tr
                          key={order.id}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            isChecked ? 'bg-blue-50/40' : ''
                          }`}
                        >
                          <td className="py-3.5 pl-4 pr-2 align-top">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedOrderIds((prev) => [...prev, order.id]);
                                } else {
                                  setSelectedOrderIds((prev) =>
                                    prev.filter((id) => id !== order.id)
                                  );
                                }
                              }}
                              aria-label={`Select order ${order.orderNo}`}
                              className="w-4 h-4 mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                            />
                          </td>
                          <td className="py-3.5 px-4 align-top">
                            <p className="font-mono font-bold text-slate-900">#{order.orderNo}</p>
                            <p className="text-[11px] font-mono text-slate-500">{order.invoiceNo}</p>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {formatDate(order.createdAt)}
                            </p>
                          </td>

                          <td className="py-3.5 px-4 align-top">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <p className="font-semibold text-slate-900">{order.customerName}</p>
                              {order.editHistory && order.editHistory.length > 0 && (
                                <span
                                  className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-extrabold"
                                  title={`সর্বশেষ পরিবর্তন: ${order.editHistory[order.editHistory.length - 1].summary} (${order.editHistory[order.editHistory.length - 1].editedBy})`}
                                >
                                  <Edit2 className="w-2.5 h-2.5" />
                                  <span>এডিটেড</span>
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                              <p className="font-mono text-slate-700 font-semibold">{order.customerPhone}</p>
                              {isDuplicateToday ? (
                                <span
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold"
                                  title="একই নাম্বার থেকে আজ একাধিক অর্ডার এসেছে — ডুপ্লিকেট বা ফেক অর্ডার হতে পারে"
                                >
                                  <AlertTriangle className="w-3 h-3 shrink-0" />
                                  <span>Duplicate ({phoneHist?.todayOrders} Orders)</span>
                                </span>
                              ) : isRepeatCustomer ? (
                                <span
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold"
                                  title="এই কাস্টমারের নাম্বার থেকে একাধিকবার অর্ডার হয়েছে"
                                >
                                  <Repeat className="w-3 h-3 shrink-0" />
                                  <span>Repeat Customer · {phoneHist?.totalOrders} Orders</span>
                                </span>
                              ) : null}
                            </div>
                            {order.alternativePhone && (
                              <div className="mt-1">
                                <a
                                  href={`tel:${order.alternativePhone}`}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-[11px] font-mono font-bold"
                                  title="কাস্টমারের বিকল্প (২য়) মোবাইল নাম্বার — কল করতে ক্লিক করুন"
                                >
                                  <Phone className="w-2.5 h-2.5 text-teal-700 shrink-0" />
                                  <span>বিকল্প: {order.alternativePhone}</span>
                                </a>
                              </div>
                            )}
                            {/* Desktop Quick Call & WhatsApp + Message Edit Trigger */}
                            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                              <a
                                href={`tel:${order.customerPhone}`}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-2xs transition-colors"
                                title="সরাসরি কাস্টমারকে কল করুন"
                              >
                                <Phone className="w-3 h-3" />
                                <span>কল</span>
                              </a>
                              <a
                                href={getOrderWhatsAppUrl(order)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-[11px] shadow-2xs transition-colors"
                                title={
                                  currentBusiness.whatsappOrderMessageBlank ||
                                  (currentBusiness.whatsappOrderTemplate !== undefined &&
                                    currentBusiness.whatsappOrderTemplate.trim() === '')
                                    ? 'WhatsApp-এ ফাঁকা চ্যাট ওপেন করুন'
                                    : 'WhatsApp-এ কাস্টমারকে মেসেজ পাঠান'
                                }
                              >
                                <MessageCircle className="w-3 h-3" />
                                <span>WhatsApp</span>
                              </a>
                              <button
                                type="button"
                                onClick={() => handleOpenWhatsAppSettings('order')}
                                className="p-1 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 cursor-pointer transition-colors"
                                title="WhatsApp মেসেজ এডিট করুন বা ফাঁকা (Blank) রাখুন"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                            </div>
                            <div className="mt-1.5 space-y-1">
                              {order.items.map((it, idx) => (
                                <div
                                  key={idx}
                                  className="text-[11px] text-slate-700 bg-slate-50 border border-slate-200/80 rounded-lg px-2 py-1 flex items-center justify-between gap-1.5"
                                >
                                  <span className="font-semibold truncate max-w-[160px]">
                                    {it.productName}
                                    {it.variantLabel ? (
                                      <span className="ml-1 px-1.5 py-0.2 rounded bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-extrabold">
                                        {it.variantLabel}
                                      </span>
                                    ) : null}
                                  </span>
                                  <span className="font-mono font-bold text-slate-800 shrink-0">
                                    ×{it.quantity}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </td>

                          <td className="py-3.5 px-4 align-top max-w-xs">
                            <p className="font-semibold text-slate-800">{order.deliveryArea}</p>
                            <p className="text-slate-600 line-clamp-2 mt-0.5">{order.deliveryAddress}</p>
                            <p className="text-[11px] text-emerald-800 font-medium mt-0.5">
                              {order.deliverySlot}
                            </p>
                            {getCleanCustomerNote(order.notes) && (
                              <div className="mt-1.5 p-2 rounded-xl bg-amber-50 border border-amber-300/90 text-amber-950 shadow-2xs">
                                <p className="text-[10px] font-extrabold text-amber-800 flex items-center gap-1">
                                  <FileText className="w-3 h-3 text-amber-600 shrink-0" />
                                  <span>কাস্টমারের অর্ডার নোট:</span>
                                </p>
                                <p className="text-[11px] font-bold text-slate-900 mt-0.5 leading-snug whitespace-pre-wrap">
                                  {getCleanCustomerNote(order.notes)}
                                </p>
                              </div>
                            )}
                          </td>

                          <td className="py-3.5 px-4 align-top text-right font-mono tabular-nums">
                            <p className="font-bold text-slate-900 text-sm">
                              {formatCurrency(order.grandTotal)}
                            </p>
                            <p className="text-[11px] text-slate-500">
                              ডেলিভারি: {order.deliveryCharge === 0 ? 'ফ্রি' : formatCurrency(order.deliveryCharge)}
                            </p>
                            {(order.discountAmount || 0) > 0 && (
                              <p className="text-[11px] font-bold text-emerald-700 mt-0.5">
                                স্পেশাল ছাড়: -{formatCurrency(order.discountAmount || 0)}
                              </p>
                            )}
                            {editingDiscountOrderId === order.id ? (
                              <div className="mt-1.5 p-2 rounded-xl bg-emerald-50 border border-emerald-300 flex flex-col items-end gap-1.5 font-sans">
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] font-extrabold text-emerald-900">৳</span>
                                  <input
                                    type="number"
                                    min="0"
                                    value={inlineDiscountInput}
                                    onChange={(e) => setInlineDiscountInput(e.target.value)}
                                    className="w-20 px-2 py-1 text-xs font-mono font-bold bg-white border border-emerald-300 rounded-lg text-right outline-hidden focus:border-emerald-600"
                                    placeholder="0"
                                  />
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleApplyInlineSpecialDiscount(
                                        order,
                                        Number(inlineDiscountInput || 0)
                                      )
                                    }
                                    className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold cursor-pointer"
                                  >
                                    সেভ
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingDiscountOrderId(null)}
                                    className="px-1.5 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] font-bold cursor-pointer"
                                  >
                                    ✕
                                  </button>
                                </div>
                                <div className="flex flex-wrap justify-end gap-1">
                                  {[50, 100, 150, 200].map((preset) => (
                                    <button
                                      key={preset}
                                      type="button"
                                      onClick={() => handleApplyInlineSpecialDiscount(order, preset)}
                                      className="px-1.5 py-0.5 rounded bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[10px] font-bold cursor-pointer"
                                    >
                                      ৳{preset}
                                    </button>
                                  ))}
                                  {(order.discountAmount || 0) > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => handleApplyInlineSpecialDiscount(order, 0)}
                                      className="px-1.5 py-0.5 rounded bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-bold cursor-pointer"
                                    >
                                      রিমুভ
                                    </button>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingDiscountOrderId(order.id);
                                  setInlineDiscountInput(String(order.discountAmount || 0));
                                }}
                                className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[10px] font-sans font-extrabold cursor-pointer"
                                title="কাস্টমার অর্ডার করার পর ডিসকাউন্ট চাইলে এখান থেকে স্পেশাল ডিসকাউন্ট যোগ বা পরিবর্তন করুন"
                              >
                                <Tag className="w-2.5 h-2.5" />
                                <span>
                                  {(order.discountAmount || 0) > 0
                                    ? 'ছাড় পরিবর্তন'
                                    : '+ স্পেশাল ডিসকাউন্ট'}
                                </span>
                              </button>
                            )}
                          </td>

                          <td className="py-3.5 px-4 align-top">
                            <p className="font-semibold uppercase text-slate-800">
                              {order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod}
                            </p>
                            <button
                              type="button"
                              onClick={() =>
                                updateOnlineOrderStatus(
                                  order.id,
                                  order.orderStatus,
                                  order.paymentStatus === 'paid' ? 'unpaid' : 'paid'
                                )
                              }
                              className={`mt-1 text-[11px] font-semibold underline cursor-pointer ${
                                order.paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'
                              }`}
                            >
                              {order.paymentStatus === 'paid' ? 'পরিশোধিত (Paid)' : 'অপরিশোধিত (Mark Paid)'}
                            </button>
                          </td>

                          <td className="py-3.5 px-4 align-top">
                            <div className="flex flex-col items-start gap-1.5">
                              {/* Color-Coded Status Badge (Pending / Processing / Delivered / Cancelled) */}
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span
                                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-[11px] font-extrabold tracking-tight whitespace-nowrap ${stInfo.badgeClass}`}
                                >
                                  <span className={`w-2 h-2 rounded-full shrink-0 ${stInfo.dotClass}`} />
                                  <StatusIcon className="w-3.5 h-3.5 shrink-0" />
                                  <span>
                                    {language === 'bn'
                                      ? `${stInfo.badgeBn} (${stInfo.badgeLabel})`
                                      : stInfo.badgeLabel}
                                  </span>
                                </span>
                                {stInfo.subStageBn && (
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold whitespace-nowrap">
                                    {language === 'bn' ? stInfo.subStageBn : stInfo.subStageEn}
                                  </span>
                                )}
                              </div>

                              {/* Status Quick-Change Dropdown */}
                              <select
                                value={order.orderStatus}
                                onChange={(e) =>
                                  updateOnlineOrderStatus(order.id, e.target.value as OnlineOrderStatus)
                                }
                                aria-label="Change order status"
                                className={`px-2.5 py-1 rounded-lg border text-[11px] font-semibold outline-hidden cursor-pointer transition-colors ${stInfo.colorClass}`}
                              >
                                <option value="pending">অপেক্ষমাণ (Pending)</option>
                                <option value="confirmed">প্রসেসিং: নিশ্চিতকৃত (Confirmed)</option>
                                <option value="packaging">প্রসেসিং: প্যাকেজিং (Packaging)</option>
                                <option value="dispatched">প্রসেসিং: ডেলিভারিতে (Dispatched)</option>
                                <option value="delivered">ডেলিভারি সম্পন্ন (Delivered)</option>
                                <option value="cancelled">বাতিল (Cancelled)</option>
                              </select>
                            </div>
                          </td>

                          <td className="py-3.5 px-4 align-top text-right">
                            <div className="inline-flex flex-col items-end gap-1.5">
                              <div className="flex flex-wrap items-center justify-end gap-1.5">
                                {/* Order Edit Button (Address, Add Product, Size Change, Name & Alternative Phone) */}
                                <button
                                  type="button"
                                  onClick={() => handleOpenOrderEditModal(order)}
                                  className={`px-2.5 py-1 text-[11px] font-extrabold rounded-lg inline-flex items-center gap-1 border cursor-pointer transition-colors ${
                                    isOrderEditEnabled
                                      ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300 shadow-2xs'
                                      : 'bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-700 border-slate-300'
                                  }`}
                                  title={
                                    isOrderEditEnabled
                                      ? 'অর্ডার এডিট করুন: ডেলিভারি ঠিকানা পরিবর্তন, নতুন প্রোডাক্ট যোগ, সাইজ পরিবর্তন বা বিকল্প নাম্বার যোগ করুন'
                                      : '🔒 অর্ডার এডিট সিস্টেম ডেভেলপার/অ্যাডমিন কর্তৃক বন্ধ (OFF) করা আছে'
                                  }
                                >
                                  {isOrderEditEnabled ? (
                                    <Edit2 className="w-3 h-3 text-amber-700 shrink-0" />
                                  ) : (
                                    <Lock className="w-3 h-3 text-rose-600 shrink-0" />
                                  )}
                                  <span>
                                    {isOrderEditEnabled ? '✏️ অর্ডার এডিট' : '🔒 এডিট লকড'}
                                  </span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleQuickFraudCheck(order)}
                                  disabled={checkingFraudOrderId === order.id}
                                  className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[11px] font-bold rounded-lg inline-flex items-center gap-1 cursor-pointer"
                                  title="নিজস্ব স্টোর + Steadfast + Pathao ডেলিভারি রেশিও চেক"
                                >
                                  {checkingFraudOrderId === order.id ? (
                                    <RefreshCw className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <ShieldCheck className="w-3 h-3" />
                                  )}
                                  <span>
                                    {order.fraudCheckSummary
                                      ? `রেশিও: ${order.fraudCheckSummary.successRatio}%`
                                      : `স্টোর: ${
                                          computeOwnStoreCustomerRecord(
                                            order.customerPhone,
                                            onlineOrders,
                                            incompleteOrders
                                          ).successRatio
                                        }% · চেক`}
                                  </span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setBulkPrintOrders([]);
                                    setInvoiceModalInitialMode('invoice');
                                    setSelectedOrder(order);
                                  }}
                                  className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 text-[11px] font-extrabold rounded-lg inline-flex items-center gap-1 cursor-pointer"
                                  title="স্মার্ট ইনভয়েস দেখুন ও ১-ক্লিকে PDF ডাউনলোড বা প্রিন্ট করুন"
                                >
                                  <FileText className="w-3.5 h-3.5 text-blue-700" />
                                  <span>{language === 'bn' ? 'ইনভয়েস / PDF' : 'Invoice / PDF'}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setBulkPrintOrders([]);
                                    setInvoiceModalInitialMode('slip');
                                    setSelectedOrder(order);
                                  }}
                                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-[11px] font-bold rounded-lg inline-flex items-center gap-1 cursor-pointer"
                                  title="পার্সেল ডেলিভারি স্লিপ প্রিন্ট বা PDF ডাউনলোড করুন"
                                >
                                  <Printer className="w-3.5 h-3.5" />
                                  <span>{language === 'bn' ? 'ডেলিভারি স্লিপ' : 'Delivery Slip'}</span>
                                </button>
                              </div>

                              {order.courierConsignmentId ? (
                                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold">
                                  <Truck className="w-3 h-3" />
                                  <span>
                                    {order.courierProvider === 'pathao' ? 'Pathao' : 'Steadfast'} CID:{' '}
                                    {order.courierConsignmentId}
                                  </span>
                                </div>
                              ) : (
                                <div className="flex flex-wrap items-center justify-end gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleQuickCourierSend(order, 'steadfast')}
                                    disabled={bookingCourierKey !== null}
                                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                                  >
                                    {bookingCourierKey === `${order.id}_steadfast` ? (
                                      <RefreshCw className="w-3 h-3 animate-spin" />
                                    ) : (
                                      <Truck className="w-3 h-3" />
                                    )}
                                    <span>1-Click Steadfast</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => handleQuickCourierSend(order, 'pathao')}
                                    disabled={bookingCourierKey !== null}
                                    className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                                  >
                                    {bookingCourierKey === `${order.id}_pathao` ? (
                                      <RefreshCw className="w-3 h-3 animate-spin" />
                                    ) : (
                                      <Send className="w-3 h-3" />
                                    )}
                                    <span>1-Click Pathao</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile / Tablet Dedicated Cards View (100% Mobile Friendly) */}
            <div className="block lg:hidden divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <div className="py-12 px-4 text-center text-slate-500">
                  <Package className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                  <p className="font-bold text-slate-700">
                    {language === 'bn' ? 'কোনো অনলাইন অর্ডার পাওয়া যায়নি' : 'No online orders found'}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    ফিল্টারে পরিবর্তন করে আবার চেষ্টা করুন
                  </p>
                </div>
              ) : (
                paginatedOrders.map((order) => {
                  const stInfo = statusLabels[order.orderStatus];
                  const StatusIcon = stInfo.IconComponent;
                  const phoneKey = normalizeBdPhone(order.customerPhone || '');
                  const phoneHist = phoneKey ? phoneOrderHistoryMap[phoneKey] : undefined;
                  const isDuplicateToday = (phoneHist?.todayOrders || 0) >= 2;
                  const isRepeatCustomer = (phoneHist?.totalOrders || 0) >= 2;
                  const isChecked = selectedOrderIds.includes(order.id);
                  const orderWaUrl = getOrderWhatsAppUrl(order);

                  return (
                    <div
                      key={order.id}
                      className={`p-3.5 sm:p-4 transition-colors space-y-3 ${
                        isChecked ? 'bg-blue-50/50' : 'bg-white'
                      }`}
                    >
                      {/* Top Header: Checkbox + Order # + Time + Status Badge */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedOrderIds((prev) => [...prev, order.id]);
                              } else {
                                setSelectedOrderIds((prev) =>
                                  prev.filter((id) => id !== order.id)
                                );
                              }
                            }}
                            className="w-4.5 h-4.5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer shrink-0"
                          />
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-mono font-extrabold text-sm sm:text-base text-slate-900">
                                #{order.orderNo}
                              </span>
                              <span className="text-[10px] font-mono text-slate-500 px-1.5 py-0.5 bg-slate-100 rounded">
                                {order.invoiceNo}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                              <span className="font-medium text-slate-700">{formatRelativeTimeAgoBn(order.createdAt, nowTick)}</span>
                              <span className="text-slate-300">·</span>
                              <span className="text-[10px] text-slate-400">{formatDate(order.createdAt)}</span>
                            </span>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <div className="flex flex-col items-end gap-1 shrink-0">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-extrabold tracking-tight ${stInfo.badgeClass}`}
                          >
                            <span className={`w-2 h-2 rounded-full shrink-0 ${stInfo.dotClass}`} />
                            <StatusIcon className="w-3.5 h-3.5 shrink-0" />
                            <span>
                              {language === 'bn' ? stInfo.badgeBn : stInfo.badgeLabel}
                            </span>
                          </span>
                          {stInfo.subStageBn && (
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200">
                              {language === 'bn' ? stInfo.subStageBn : stInfo.subStageEn}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Customer Row + Direct Mobile Call & WhatsApp Buttons */}
                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-2">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-extrabold text-slate-900 text-sm">
                                {order.customerName}
                              </span>
                              {order.editHistory && order.editHistory.length > 0 && (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-extrabold">
                                  <Edit2 className="w-2.5 h-2.5" />
                                  <span>এডিটেড</span>
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                              <span className="font-mono font-bold text-slate-700 text-xs">
                                {order.customerPhone}
                              </span>
                              {isDuplicateToday ? (
                                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold">
                                  <AlertTriangle className="w-3 h-3 text-rose-600" />
                                  <span>ডুপ্লিকেট ({phoneHist?.todayOrders}টি অর্ডার)</span>
                                </span>
                              ) : isRepeatCustomer ? (
                                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold">
                                  <Repeat className="w-3 h-3 text-indigo-600" />
                                  <span>রিপিট কাস্টমার ({phoneHist?.totalOrders}টি)</span>
                                </span>
                              ) : null}
                            </div>
                          </div>

                          {/* Quick 1-Tap Call & WhatsApp for Mobile Admin */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            <a
                              href={`tel:${order.customerPhone}`}
                              className="min-h-[36px] px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs inline-flex items-center gap-1 shadow-2xs active:scale-95 transition-all"
                            >
                              <Phone className="w-3.5 h-3.5" />
                              <span>কল</span>
                            </a>
                            <a
                              href={orderWaUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="min-h-[36px] px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs inline-flex items-center gap-1 shadow-2xs active:scale-95 transition-all"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>WhatsApp</span>
                            </a>
                            <button
                              type="button"
                              onClick={() => handleOpenWhatsAppSettings('order')}
                              className="min-h-[36px] px-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-300 inline-flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                              title="WhatsApp মেসেজ এডিট বা ফাঁকা রাখুন"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {order.alternativePhone && (
                          <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between gap-2">
                            <span className="text-[11px] text-teal-900 font-medium">
                              বিকল্প নাম্বার: <span className="font-mono font-bold">{order.alternativePhone}</span>
                            </span>
                            <a
                              href={`tel:${order.alternativePhone}`}
                              className="px-2.5 py-1 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-[11px] font-extrabold inline-flex items-center gap-1"
                            >
                              <Phone className="w-3 h-3 text-teal-700" />
                              <span>২য় নাম্বারে কল</span>
                            </a>
                          </div>
                        )}
                      </div>

                      {/* Items Ordered List */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-500">
                          <span>অর্ডারকৃত পণ্যসমূহ ({order.items.reduce((s, it) => s + it.quantity, 0)} পিস)</span>
                        </div>
                        <div className="space-y-1">
                          {order.items.map((it, idx) => (
                            <div
                              key={idx}
                              className="p-2 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between gap-2 text-xs"
                            >
                              <div className="min-w-0 flex-1">
                                <p className="font-bold text-slate-900 truncate">
                                  {it.productName}
                                </p>
                                {it.variantLabel && (
                                  <span className="inline-block mt-0.5 px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-extrabold">
                                    {it.variantLabel}
                                  </span>
                                )}
                              </div>
                              <div className="text-right shrink-0 font-mono">
                                <span className="font-extrabold text-slate-800 text-xs">
                                  ×{it.quantity}
                                </span>
                                <span className="text-[11px] text-slate-500 ml-1.5">
                                  ৳{it.unitPrice * it.quantity}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Delivery Address & Notes */}
                      <div className="text-xs bg-amber-50/40 rounded-xl p-2.5 border border-amber-200/80 space-y-1.5">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900">
                          <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>{order.deliveryArea}</span>
                        </div>
                        <p className="text-slate-700 leading-snug pl-5 text-[11px]">
                          {order.deliveryAddress}
                        </p>
                        {order.deliverySlot && (
                          <p className="text-[11px] text-emerald-800 font-medium pl-5">
                            ⏰ {order.deliverySlot}
                          </p>
                        )}
                        {getCleanCustomerNote(order.notes) && (
                          <div className="mt-1.5 p-2.5 rounded-xl bg-amber-100/80 border border-amber-300 text-amber-950 space-y-0.5">
                            <p className="text-[10px] font-extrabold text-amber-800 flex items-center gap-1">
                              <FileText className="w-3 h-3 text-amber-700 shrink-0" />
                              <span>কাস্টমারের অর্ডার নোট:</span>
                            </p>
                            <p className="text-xs font-bold text-slate-900 leading-snug whitespace-pre-wrap">
                              {getCleanCustomerNote(order.notes)}
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Financials & Status Changer Row */}
                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-2.5">
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <div>
                            <span className="text-[10px] text-slate-500 block uppercase font-bold">সর্বমোট বিল</span>
                            <span className="text-base font-extrabold font-mono text-slate-950">
                              {formatCurrency(order.grandTotal)}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-[11px] text-slate-500 block">
                              ডেলিভারি: {order.deliveryCharge === 0 ? 'ফ্রি' : formatCurrency(order.deliveryCharge)}
                            </span>
                            {(order.discountAmount || 0) > 0 && (
                              <span className="text-[11px] font-bold text-emerald-700 block">
                                স্পেশাল ছাড়: -{formatCurrency(order.discountAmount || 0)}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Payment Status & Quick Mark Paid */}
                        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200/60">
                          <span className="text-[11px] font-bold text-slate-700 uppercase">
                            {order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              updateOnlineOrderStatus(
                                order.id,
                                order.orderStatus,
                                order.paymentStatus === 'paid' ? 'unpaid' : 'paid'
                              )
                            }
                            className={`text-xs font-bold px-2.5 py-1 rounded-lg border transition-colors cursor-pointer ${
                              order.paymentStatus === 'paid'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                : 'bg-amber-50 text-amber-800 border-amber-300'
                            }`}
                          >
                            {order.paymentStatus === 'paid' ? '✓ পরিশোধিত (Paid)' : '⭕ অপরিশোধিত (Mark Paid)'}
                          </button>
                        </div>

                        {/* Status Select Dropdown (Large & comfortable on mobile touch) */}
                        <div className="pt-2 border-t border-slate-200/60">
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">
                            স্ট্যাটাস পরিবর্তন করুন:
                          </label>
                          <select
                            value={order.orderStatus}
                            onChange={(e) =>
                              updateOnlineOrderStatus(order.id, e.target.value as OnlineOrderStatus)
                            }
                            className={`w-full min-h-[40px] px-3 py-2 rounded-xl border text-xs font-extrabold outline-hidden cursor-pointer transition-colors ${stInfo.colorClass}`}
                          >
                            <option value="pending">অপেক্ষমাণ (Pending)</option>
                            <option value="confirmed">প্রসেসিং: নিশ্চিতকৃত (Confirmed)</option>
                            <option value="packaging">প্রসেসিং: প্যাকেজিং (Packaging)</option>
                            <option value="dispatched">প্রসেসিং: ডেলিভারিতে (Dispatched)</option>
                            <option value="delivered">ডেলিভারি সম্পন্ন (Delivered)</option>
                            <option value="cancelled">বাতিল (Cancelled)</option>
                          </select>
                        </div>
                      </div>

                      {/* Mobile Action Buttons Bar (Comfortable 40px Touch Targets) */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        {/* 1. Order Edit Button */}
                        <button
                          type="button"
                          onClick={() => handleOpenOrderEditModal(order)}
                          className={`min-h-[40px] px-3 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                            isOrderEditEnabled
                              ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 border-amber-500 shadow-2xs'
                              : 'bg-slate-100 text-slate-400 border-slate-200'
                          }`}
                        >
                          {isOrderEditEnabled ? (
                            <Edit2 className="w-3.5 h-3.5 text-slate-950" />
                          ) : (
                            <Lock className="w-3.5 h-3.5 text-rose-600" />
                          )}
                          <span>{isOrderEditEnabled ? '✏️ অর্ডার এডিট' : '🔒 লকড'}</span>
                        </button>

                        {/* 2. Fraud / Delivery Ratio Check */}
                        <button
                          type="button"
                          onClick={() => handleQuickFraudCheck(order)}
                          disabled={checkingFraudOrderId === order.id}
                          className="min-h-[40px] px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          {checkingFraudOrderId === order.id ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <ShieldCheck className="w-3.5 h-3.5 text-indigo-700" />
                          )}
                          <span>
                            {order.fraudCheckSummary
                              ? `রেশিও ${order.fraudCheckSummary.successRatio}%`
                              : '🛡️ রেশিও চেক'}
                          </span>
                        </button>

                        {/* 3. Invoice / PDF Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setBulkPrintOrders([]);
                            setInvoiceModalInitialMode('invoice');
                            setSelectedOrder(order);
                          }}
                          className="min-h-[40px] px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5 text-blue-700" />
                          <span>ইনভয়েস / PDF</span>
                        </button>

                        {/* 4. Delivery Slip Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setBulkPrintOrders([]);
                            setInvoiceModalInitialMode('slip');
                            setSelectedOrder(order);
                          }}
                          className="min-h-[40px] px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5 text-slate-700" />
                          <span>ডেলিভারি স্লিপ</span>
                        </button>
                      </div>

                      {/* Courier Booking on Mobile */}
                      {order.courierConsignmentId ? (
                        <div className="w-full min-h-[38px] px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-center gap-1.5">
                          <Truck className="w-4 h-4 text-emerald-700" />
                          <span>
                            {order.courierProvider === 'pathao' ? 'Pathao' : 'Steadfast'} CID:{' '}
                            {order.courierConsignmentId}
                          </span>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => handleQuickCourierSend(order, 'steadfast')}
                            disabled={bookingCourierKey !== null}
                            className="min-h-[38px] px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                          >
                            {bookingCourierKey === `${order.id}_steadfast` ? (
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Truck className="w-3.5 h-3.5" />
                            )}
                            <span>1-Click Steadfast</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleQuickCourierSend(order, 'pathao')}
                            disabled={bookingCourierKey !== null}
                            className="min-h-[38px] px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                          >
                            {bookingCourierKey === `${order.id}_pathao` ? (
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Send className="w-3.5 h-3.5" />
                            )}
                            <span>1-Click Pathao</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {filteredOrders.length > ORDERS_PER_PAGE && (
              <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                <p className="text-slate-600 font-semibold">
                  মোট <span className="font-mono font-bold text-slate-900">{filteredOrders.length}</span> টি অর্ডারের মধ্যে{' '}
                  <span className="font-mono font-bold text-blue-700">
                    {(safeOrderPage - 1) * ORDERS_PER_PAGE + 1}–
                    {Math.min(safeOrderPage * ORDERS_PER_PAGE, filteredOrders.length)}
                  </span>{' '}
                  দেখানো হচ্ছে (প্রতি পেজে ৫০টি অর্ডার)
                </p>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={safeOrderPage <= 1}
                    onClick={() => setOrderPage(p => Math.max(1, p - 1))}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold disabled:opacity-40 cursor-pointer"
                  >
                    ← আগের পেজ
                  </button>
                  <span className="px-3 py-1.5 rounded-lg bg-blue-700 text-white font-mono font-bold">
                    পেজ {safeOrderPage} / {totalOrderPages}
                  </span>
                  <button
                    type="button"
                    disabled={safeOrderPage >= totalOrderPages}
                    onClick={() => setOrderPage(p => Math.min(totalOrderPages, p + 1))}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold disabled:opacity-40 cursor-pointer"
                  >
                    পরের পেজ →
                  </button>
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          {/* Filter & Search Bar for Incomplete / Abandoned Checkouts */}
          <div className="bg-white rounded-2xl border border-rose-200/90 p-4 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
              {[
                {
                  id: 'abandoned',
                  bn: `অসম্পূর্ণ অর্ডার (Abandoned) (${metrics.abandonedCount})`,
                  en: `Abandoned (${metrics.abandonedCount})`
                },
                {
                  id: 'contacted',
                  bn: `কথা হয়েছে (Contacted) (${metrics.contactedCount})`,
                  en: `Contacted (${metrics.contactedCount})`
                },
                {
                  id: 'converted',
                  bn: `অর্ডার সম্পন্ন (Recovered) (${metrics.convertedCount})`,
                  en: `Recovered (${metrics.convertedCount})`
                },
                {
                  id: 'ignored',
                  bn: `বাতিল (Ignored) (${metrics.ignoredCount})`,
                  en: `Ignored (${metrics.ignoredCount})`
                },
                {
                  id: 'all',
                  bn: `সব রেকর্ড (${incompleteOrders.length})`,
                  en: `All Records (${incompleteOrders.length})`
                }
              ].map(tab => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setIncompleteFilter(tab.id as 'all' | IncompleteOrderStatus)}
                  className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    incompleteFilter === tab.id
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {language === 'bn' ? tab.bn : tab.en}
                </button>
              ))}
            </div>

            <div className="relative w-full lg:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="নাম, মোবাইল নম্বর বা প্রোডাক্ট খুঁজুন..."
                className="w-full min-h-[38px] pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 focus:border-rose-500 focus:bg-white rounded-xl outline-hidden"
              />
            </div>
          </div>

          {/* Incomplete Orders / Abandoned Checkouts Table */}
          <div className="bg-white rounded-2xl border border-rose-200/90 overflow-hidden">
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-rose-50/60 border-b border-rose-200/80 text-[11px] font-bold text-slate-700 uppercase">
                    <th className="py-3.5 px-4">সময় ও ট্র্যাকিং</th>
                    <th className="py-3.5 px-4">কাস্টমারের নাম ও মোবাইল</th>
                    <th className="py-3.5 px-4">পছন্দের পণ্যসমূহ (Cart Items)</th>
                    <th className="py-3.5 px-4">ঠিকানা ও ডেলিভারি এরিয়া</th>
                    <th className="py-3.5 px-4 text-right">সম্ভাব্য বিল</th>
                    <th className="py-3.5 px-4">স্ট্যাটাস</th>
                    <th className="py-3.5 px-4 text-right">রিকভারি অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredIncompleteOrders.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-500 space-y-1">
                        <p className="font-bold text-slate-700">
                          কোনো অসম্পূর্ণ অর্ডার (Abandoned Checkout) পাওয়া যায়নি
                        </p>
                        <p className="text-[11px] text-slate-400">
                          কাস্টমার যখন চেকআউট ফর্মে ১১ ডিজিটের মোবাইল নম্বর লিখবে কিন্তু অর্ডার কনফার্ম না করে বের হয়ে যাবে, তখন তা এখানে সাথে সাথে জমা হবে।
                        </p>
                      </td>
                    </tr>
                  ) : (
                    paginatedIncompleteOrders.map(inc => {
                      const stInfo = incompleteStatusLabels[inc.status];
                      const incWaUrl = getIncompleteWhatsAppUrl(inc);
                      const phoneKey = normalizeBdPhone(inc.customerPhone || '');
                      const phoneHist = phoneKey ? phoneOrderHistoryMap[phoneKey] : undefined;
                      const existingOrderCount = phoneHist?.totalOrders || 0;

                      return (
                        <tr key={inc.id} className="hover:bg-rose-50/30 transition-colors">
                          <td className="py-3.5 px-4 align-top whitespace-nowrap">
                            <p className="font-semibold text-slate-800">
                              {formatDate(inc.updatedAt || inc.createdAt)}
                            </p>
                            <p className="text-[11px] font-mono text-slate-500">
                              {new Date(inc.updatedAt || inc.createdAt).toLocaleTimeString('bn-BD')}
                            </p>
                            <div className="mt-1">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 text-amber-900 border border-amber-300 text-[11px] font-extrabold shadow-2xs">
                                <Clock className="w-3 h-3 text-amber-700 shrink-0" />
                                <span>{formatRelativeTimeAgoBn(inc.updatedAt || inc.createdAt, nowTick)}</span>
                              </span>
                            </div>
                            {inc.fbLeadSent && (
                              <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>FB Pixel Lead Sent</span>
                              </span>
                            )}
                          </td>

                          <td className="py-3.5 px-4 align-top">
                            <p className="font-bold text-slate-900 text-sm">
                              {inc.customerName || 'নাম লেখেনি'}
                            </p>
                            <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                              <p className="font-mono font-extrabold text-rose-700 text-sm">
                                {inc.customerPhone}
                              </p>
                              {existingOrderCount > 0 && (
                                <span
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold"
                                  title="এই ফোন নাম্বার থেকে ইতিমধ্যে কনফার্মড অর্ডার আছে"
                                >
                                  <Repeat className="w-3 h-3 shrink-0" />
                                  <span>
                                    {existingOrderCount >= 2
                                      ? `Repeat Customer · ${existingOrderCount} Orders`
                                      : '1 Order Placed'}
                                  </span>
                                </span>
                              )}
                              {(phoneHist?.incompleteCount || 0) >= 2 && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100/80 text-amber-900 border border-amber-300 text-[10px] font-bold">
                                  {phoneHist?.incompleteCount} Leads
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                              <a
                                href={`tel:${inc.customerPhone}`}
                                onClick={() => {
                                  if (inc.status === 'abandoned') {
                                    updateIncompleteOrderStatus(inc.id, 'contacted');
                                  }
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px]"
                              >
                                <Phone className="w-3 h-3" />
                                <span>কল করুন</span>
                              </a>
                              <a
                                href={incWaUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={() => {
                                  if (inc.status === 'abandoned') {
                                    updateIncompleteOrderStatus(inc.id, 'contacted');
                                  }
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px]"
                              >
                                <MessageCircle className="w-3 h-3" />
                                <span>WhatsApp মেসেজ</span>
                              </a>
                              <button
                                type="button"
                                onClick={() => handleOpenWhatsAppSettings('abandoned')}
                                className="p-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 cursor-pointer"
                                title="WhatsApp মেসেজ এডিট বা ফাঁকা রাখুন"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                            </div>
                          </td>

                          <td className="py-3.5 px-4 align-top max-w-xs">
                            <div className="space-y-1">
                              {inc.items.map((item, idx) => (
                                <div
                                  key={idx}
                                  className="text-xs text-slate-800 flex items-center justify-between gap-2 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200/70"
                                >
                                  <span className="font-semibold truncate">{item.productName}</span>
                                  <span className="font-mono font-bold text-slate-700 shrink-0">
                                    {item.quantity} × ৳{item.unitPrice}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </td>

                          <td className="py-3.5 px-4 align-top max-w-xs">
                            <p className="font-semibold text-slate-800">{inc.deliveryArea}</p>
                            <p className="text-slate-600 mt-0.5">
                              {inc.deliveryAddress || (
                                <span className="text-slate-400 italic">ঠিকানা লেখার আগেই বের হয়ে গেছে</span>
                              )}
                            </p>
                            {getCleanCustomerNote(inc.notes) && (
                              <div className="mt-1.5 p-2 rounded-xl bg-amber-50 border border-amber-300/90 text-amber-950">
                                <p className="text-[10px] font-extrabold text-amber-800 flex items-center gap-1">
                                  <FileText className="w-3 h-3 text-amber-600 shrink-0" />
                                  <span>কাস্টমারের অর্ডার নোট:</span>
                                </p>
                                <p className="text-[11px] font-bold text-slate-900 mt-0.5 leading-snug whitespace-pre-wrap">
                                  {getCleanCustomerNote(inc.notes)}
                                </p>
                              </div>
                            )}
                          </td>

                          <td className="py-3.5 px-4 align-top text-right font-mono tabular-nums whitespace-nowrap">
                            <p className="font-extrabold text-slate-900 text-sm">
                              {formatCurrency(inc.grandTotal)}
                            </p>
                            <p className="text-[11px] text-slate-500">
                              ডেলিভারি: {inc.deliveryCharge === 0 ? 'ফ্রি' : formatCurrency(inc.deliveryCharge)}
                            </p>
                          </td>

                          <td className="py-3.5 px-4 align-top">
                            <select
                              value={inc.status}
                              onChange={e =>
                                updateIncompleteOrderStatus(
                                  inc.id,
                                  e.target.value as IncompleteOrderStatus
                                )
                              }
                              className={`px-2.5 py-1.5 rounded-lg border text-xs font-semibold outline-hidden cursor-pointer ${stInfo.colorClass}`}
                            >
                              <option value="abandoned">কল করা বাকি (Abandoned)</option>
                              <option value="contacted">কথা হয়েছে (Contacted)</option>
                              <option value="converted">অর্ডার সম্পন্ন (Recovered)</option>
                              <option value="ignored">বাতিল (Ignored)</option>
                            </select>
                            {inc.convertedOrderNo && (
                              <p className="text-[11px] font-mono font-bold text-emerald-700 mt-1">
                                অর্ডার: #{inc.convertedOrderNo}
                              </p>
                            )}
                          </td>

                          <td className="py-3.5 px-4 align-top text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1.5">
                              {inc.status !== 'converted' && (
                                <button
                                  type="button"
                                  disabled={convertingId === inc.id}
                                  onClick={() => handleConvertToRealOrder(inc.id)}
                                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg inline-flex items-center gap-1.5 cursor-pointer shadow-2xs disabled:opacity-50"
                                  title="ফোনে কথা বলে কনফার্ম হলে ১-ক্লিকে আসল অর্ডারে রূপান্তর করুন"
                                >
                                  <PlusCircle className="w-3.5 h-3.5" />
                                  <span>
                                    {convertingId === inc.id
                                      ? 'কনফার্ম হচ্ছে...'
                                      : '১-ক্লিকে অর্ডার কনফার্ম'}
                                  </span>
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => deleteIncompleteOrder(inc.id)}
                                className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-lg cursor-pointer"
                                title="অসম্পূর্ণ অর্ডারটি মুছুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile Dedicated Incomplete Orders Cards View (100% Mobile Friendly) */}
            <div className="block lg:hidden divide-y divide-rose-100">
              {filteredIncompleteOrders.length === 0 ? (
                <div className="py-12 px-4 text-center text-slate-500 space-y-1">
                  <p className="font-bold text-slate-700">
                    কোনো অসম্পূর্ণ অর্ডার (Abandoned Checkout) পাওয়া যায়নি
                  </p>
                  <p className="text-xs text-slate-400">
                    কাস্টমার যখন চেকআউটে ১১ ডিজিটের মোবাইল নম্বর লিখবে কিন্তু অর্ডার কনফার্ম না করে বের হয়ে যাবে, তখন তা এখানে সাথে সাথে জমা হবে।
                  </p>
                </div>
              ) : (
                paginatedIncompleteOrders.map((inc) => {
                  const stInfo = incompleteStatusLabels[inc.status];
                  const incWaUrl = getIncompleteWhatsAppUrl(inc);
                  const phoneKey = normalizeBdPhone(inc.customerPhone || '');
                  const phoneHist = phoneKey ? phoneOrderHistoryMap[phoneKey] : undefined;
                  const existingOrderCount = phoneHist?.totalOrders || 0;

                  return (
                    <div key={inc.id} className="p-3.5 sm:p-4 bg-white space-y-3">
                      {/* Top Row: Time Ago Badge + Conversion / Delete */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-900 border border-amber-300 text-xs font-extrabold shadow-2xs">
                              <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                              <span>{formatRelativeTimeAgoBn(inc.updatedAt || inc.createdAt, nowTick)}</span>
                            </span>
                            {inc.fbLeadSent && (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>FB Lead</span>
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-400 pl-0.5">
                            {formatDate(inc.updatedAt || inc.createdAt)} · {new Date(inc.updatedAt || inc.createdAt).toLocaleTimeString('bn-BD')}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => deleteIncompleteOrder(inc.id)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                            title="মুছুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Customer Contact Box with 1-Tap Call & WhatsApp */}
                      <div className="bg-rose-50/60 rounded-xl p-3 border border-rose-200/80 space-y-2.5">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div>
                            <span className="font-extrabold text-slate-900 text-sm block">
                              {inc.customerName || 'নাম লেখেনি'}
                            </span>
                            <span className="font-mono font-extrabold text-rose-700 text-xs sm:text-sm">
                              {inc.customerPhone}
                            </span>
                            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                              {existingOrderCount > 0 && (
                                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                                  <Repeat className="w-3 h-3 shrink-0" />
                                  <span>{existingOrderCount >= 2 ? `রিপিট (${existingOrderCount} অর্ডার)` : 'আগে ১টি অর্ডার করেছে'}</span>
                                </span>
                              )}
                              {(phoneHist?.incompleteCount || 0) >= 2 && (
                                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-amber-100/80 text-amber-900 border border-amber-300 text-[10px] font-bold">
                                  {phoneHist?.incompleteCount} বার ট্রাই করেছে
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Direct 1-Tap Call & WhatsApp */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            <a
                              href={`tel:${inc.customerPhone}`}
                              onClick={() => {
                                if (inc.status === 'abandoned') {
                                  updateIncompleteOrderStatus(inc.id, 'contacted');
                                }
                              }}
                              className="min-h-[38px] px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs inline-flex items-center gap-1.5 shadow-2xs active:scale-95 transition-all"
                            >
                              <Phone className="w-3.5 h-3.5" />
                              <span>কল করুন</span>
                            </a>
                            <a
                              href={incWaUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={() => {
                                if (inc.status === 'abandoned') {
                                  updateIncompleteOrderStatus(inc.id, 'contacted');
                                }
                              }}
                              className="min-h-[38px] px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs inline-flex items-center gap-1.5 shadow-2xs active:scale-95 transition-all"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>WhatsApp</span>
                            </a>
                            <button
                              type="button"
                              onClick={() => handleOpenWhatsAppSettings('abandoned')}
                              className="min-h-[38px] px-2.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 inline-flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                              title="WhatsApp মেসেজ এডিট বা ফাঁকা রাখুন"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Cart Items */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-bold text-slate-500">পছন্দের পণ্যসমূহ:</span>
                        <div className="space-y-1">
                          {inc.items.map((it, idx) => (
                            <div
                              key={idx}
                              className="p-2 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between gap-2 text-xs"
                            >
                              <div className="min-w-0 flex-1">
                                <p className="font-bold text-slate-900 truncate">
                                  {it.productName}
                                </p>
                                {it.variantLabel && (
                                  <span className="inline-block mt-0.5 px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-extrabold">
                                    {it.variantLabel}
                                  </span>
                                )}
                              </div>
                              <span className="font-mono font-extrabold text-slate-800 text-xs shrink-0">
                                {it.quantity} × ৳{it.unitPrice}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Address & Potential Bill */}
                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-2">
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <div>
                            <span className="text-[10px] text-slate-500 block uppercase font-bold">সম্ভাব্য বিল</span>
                            <span className="text-base font-extrabold font-mono text-rose-700">
                              {formatCurrency(inc.grandTotal)}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-[11px] text-slate-600 block font-bold">
                              {inc.deliveryArea}
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              ডেলিভারি: {inc.deliveryCharge === 0 ? 'ফ্রি' : formatCurrency(inc.deliveryCharge)}
                            </span>
                          </div>
                        </div>
                        {inc.deliveryAddress && (
                          <p className="text-[11px] text-slate-600 pt-1.5 border-t border-slate-200/60 leading-snug">
                            📍 {inc.deliveryAddress}
                          </p>
                        )}
                        {getCleanCustomerNote(inc.notes) && (
                          <div className="mt-1.5 p-2 rounded-xl bg-amber-50 border border-amber-300 text-amber-950">
                            <p className="text-[10px] font-extrabold text-amber-800 flex items-center gap-1">
                              <FileText className="w-3 h-3 text-amber-600 shrink-0" />
                              <span>কাস্টমারের অর্ডার নোট:</span>
                            </p>
                            <p className="text-[11px] font-bold text-slate-900 mt-0.5 leading-snug whitespace-pre-wrap">
                              {getCleanCustomerNote(inc.notes)}
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Status Selector + 1-Click Convert Button */}
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center gap-2">
                          <label className="text-[11px] font-bold text-slate-600 shrink-0">
                            স্ট্যাটাস:
                          </label>
                          <select
                            value={inc.status}
                            onChange={(e) =>
                              updateIncompleteOrderStatus(inc.id, e.target.value as IncompleteOrderStatus)
                            }
                            className={`flex-1 min-h-[38px] px-3 py-1.5 rounded-xl border text-xs font-bold outline-hidden cursor-pointer ${stInfo.colorClass}`}
                          >
                            <option value="abandoned">কল করা বাকি (Abandoned)</option>
                            <option value="contacted">কথা হয়েছে (Contacted)</option>
                            <option value="converted">অর্ডার সম্পন্ন (Recovered)</option>
                            <option value="ignored">বাতিল (Ignored)</option>
                          </select>
                        </div>

                        {inc.status !== 'converted' && (
                          <button
                            type="button"
                            disabled={convertingId === inc.id}
                            onClick={() => handleConvertToRealOrder(inc.id)}
                            className="w-full min-h-[42px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-all disabled:opacity-50"
                          >
                            <PlusCircle className="w-4 h-4" />
                            <span>
                              {convertingId === inc.id
                                ? 'কনফার্ম হচ্ছে...'
                                : '✅ ফোনে কথা হয়েছে? ১-ক্লিকে অর্ডার কনফার্ম করুন'}
                            </span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {filteredIncompleteOrders.length > ORDERS_PER_PAGE && (
              <div className="px-4 py-3 bg-rose-50/50 border-t border-rose-200/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                <p className="text-slate-600 font-semibold">
                  মোট <span className="font-mono font-bold text-slate-900">{filteredIncompleteOrders.length}</span> টি অসম্পূর্ণ অর্ডারের মধ্যে{' '}
                  <span className="font-mono font-bold text-rose-700">
                    {(safeIncompletePage - 1) * ORDERS_PER_PAGE + 1}–
                    {Math.min(safeIncompletePage * ORDERS_PER_PAGE, filteredIncompleteOrders.length)}
                  </span>{' '}
                  দেখানো হচ্ছে (প্রতি পেজে ৫০টি)
                </p>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={safeIncompletePage <= 1}
                    onClick={() => setIncompletePage(p => Math.max(1, p - 1))}
                    className="px-3 py-1.5 rounded-lg border border-rose-300 bg-white hover:bg-rose-50 text-rose-800 font-bold disabled:opacity-40 cursor-pointer"
                  >
                    ← আগের পেজ
                  </button>
                  <span className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-mono font-bold">
                    পেজ {safeIncompletePage} / {totalIncompletePages}
                  </span>
                  <button
                    type="button"
                    disabled={safeIncompletePage >= totalIncompletePages}
                    onClick={() => setIncompletePage(p => Math.min(totalIncompletePages, p + 1))}
                    className="px-3 py-1.5 rounded-lg border border-rose-300 bg-white hover:bg-rose-50 text-rose-800 font-bold disabled:opacity-40 cursor-pointer"
                  >
                    পরের পেজ →
                  </button>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {/* Complete Order Edit & Modification Modal (Address, New Product, Size Change, Name & Alternative Phone) */}
      {editingOrder && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto"
          onClick={() => setEditingOrder(null)}
        >
          <div
            className="bg-white rounded-2xl border border-slate-200 max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden my-auto"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-slate-900 via-[#0f172a] to-indigo-950 text-white px-4 sm:px-6 py-4 flex items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-300/40 text-amber-300 flex items-center justify-center shrink-0">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-sm sm:text-base font-extrabold text-white truncate">
                      ✏️ অর্ডার এডিট ও পরিবর্তন পপআপ — অর্ডার #{editingOrder.orderNo}
                    </h2>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-mono font-bold">
                      ইনভয়েস: {editingOrder.invoiceNo}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    ঠিকানা পরিবর্তন, একই ডেলিভারিতে নতুন প্রোডাক্ট যোগ, সাইজ বদলানো এবং নাম বা বিকল্প নাম্বার সংযোজন করুন
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setEditingOrder(null)}
                className="p-2 rounded-xl bg-white/10 hover:bg-rose-500/30 text-slate-200 hover:text-white transition-colors cursor-pointer shrink-0"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Form Body */}
            <form onSubmit={handleSaveOrderEdits} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
              {/* SECTION 1: Customer Name, Primary Phone & Alternative Phone */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-3.5">
                <div className="flex items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5">
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-blue-600" />
                    <span>১. কাস্টমারের নাম ও বিকল্প মোবাইল নাম্বার যোগ/পরিবর্তন</span>
                  </h3>
                  <span className="text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md">
                    ইনভয়েস ও কুরিয়ার স্লিপেও অটো আপডেট হবে
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      কাস্টমারের নাম (Customer Name) *
                    </label>
                    <input
                      type="text"
                      required
                      value={editCustomerName}
                      onChange={e => setEditCustomerName(e.target.value)}
                      placeholder="কাস্টমারের নাম লিখুন"
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-blue-600 rounded-xl text-slate-900 font-bold outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      মূল মোবাইল নাম্বার (Primary Phone) *
                    </label>
                    <input
                      type="text"
                      required
                      value={editCustomerPhone}
                      onChange={e => setEditCustomerPhone(e.target.value)}
                      placeholder="017XXXXXXXX"
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-blue-600 rounded-xl font-mono font-bold text-slate-900 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-teal-800 mb-1">
                      📞 বিকল্প নাম্বার যোগ (২য় মোবাইল নাম্বার)
                    </label>
                    <input
                      type="text"
                      value={editAlternativePhone}
                      onChange={e => setEditAlternativePhone(e.target.value)}
                      placeholder="যেমন: 018XXXXXXXX (ঐচ্ছিক)"
                      className="w-full px-3 py-2 bg-teal-50/60 border border-teal-300 focus:border-teal-600 rounded-xl font-mono font-bold text-slate-900 outline-hidden"
                    />
                    <p className="text-[10px] text-teal-700 mt-1 font-medium">
                      মূল নাম্বার বন্ধ থাকলে ডেলিভারিম্যান এই ২য় নাম্বারে কল দিতে পারবেন
                    </p>
                  </div>
                </div>
              </div>

              {/* SECTION 2: Delivery Address & Area Change */}
              <div className="p-4 rounded-2xl bg-amber-50/40 border border-amber-200/90 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/80 pb-2.5">
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-amber-600" />
                    <span>২. ডেলিভারি ঠিকানা ও এরিয়া পরিবর্তন (যেমন: অফিস থেকে বাসার ঠিকানা)</span>
                  </h3>

                  {/* 1-Click Delivery Zone Quick Switcher */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const fee =
                          currentBusiness.insideDhakaDeliveryCharge ??
                          currentBusiness.ecommerceDeliveryCharge ??
                          60;
                        setEditDeliveryArea('ঢাকার ভিতরে (Inside Dhaka)');
                        setEditDeliveryCharge(String(fee));
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                        editDeliveryArea.includes('ঢাকার ভিতরে')
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-400'
                      }`}
                    >
                      🏠 ঢাকার ভিতরে (৳
                      {currentBusiness.insideDhakaDeliveryCharge ??
                        currentBusiness.ecommerceDeliveryCharge ??
                        60}
                      )
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const fee = currentBusiness.outsideDhakaDeliveryCharge ?? 120;
                        setEditDeliveryArea('ঢাকার বাইরে (Outside Dhaka)');
                        setEditDeliveryCharge(String(fee));
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                        editDeliveryArea.includes('ঢাকার বাইরে')
                          ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-blue-400'
                      }`}
                    >
                      🚚 ঢাকার বাইরে (৳{currentBusiness.outsideDhakaDeliveryCharge ?? 120})
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditDeliveryCharge('0')}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all ${
                        Number(editDeliveryCharge) === 0
                          ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-amber-400'
                      }`}
                    >
                      🎁 ফ্রি ডেলিভারি (৳0)
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
                  <div className="sm:col-span-5">
                    <label className="block font-bold text-slate-700 mb-1">
                      ডেলিভারি জোন / এরিয়া *
                    </label>
                    <input
                      type="text"
                      value={editDeliveryArea}
                      onChange={e => setEditDeliveryArea(e.target.value)}
                      placeholder="ঢাকার ভিতরে / ঢাকার বাইরে"
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-amber-600 rounded-xl font-bold text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block font-bold text-slate-700 mb-1">
                      ডেলিভারি চার্জ (৳) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={editDeliveryCharge}
                      onChange={e => setEditDeliveryCharge(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-amber-600 rounded-xl font-mono font-extrabold text-slate-900 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-4">
                    <label className="block font-bold text-slate-700 mb-1">
                      অর্ডার নোট / ডেলিভারি নির্দেশনা
                    </label>
                    <input
                      type="text"
                      value={editNotes}
                      onChange={e => setEditNotes(e.target.value)}
                      placeholder="যেমন: বাসায় গিয়ে কল দেবেন"
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-amber-600 rounded-xl text-slate-900 font-semibold outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-12">
                    <label className="block font-bold text-slate-700 mb-1">
                      সম্পূর্ণ ডেলিভারি ঠিকানা (বাসা/অফিস, রোড, এলাকা, থানা ও জেলা) *
                    </label>
                    <textarea
                      rows={2}
                      required
                      value={editDeliveryAddress}
                      onChange={e => setEditDeliveryAddress(e.target.value)}
                      placeholder="কাস্টমারের নতুন বা পরিবর্তিত সম্পূর্ণ ঠিকানা এখানে লিখুন..."
                      className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-amber-600 rounded-xl text-slate-900 font-semibold outline-hidden resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 3: Products, Size/Variation Change & Add New Product in Same Order */}
              <div className="p-4 rounded-2xl bg-emerald-50/40 border border-emerald-200/90 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-200/80 pb-2.5">
                  <div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-2">
                      <ShoppingBag className="w-4 h-4 text-emerald-700" />
                      <span>
                        ৩. নতুন প্রোডাক্ট যোগ ও সাইজ পরিবর্তন (বর্তমান পণ্য: {editItems.length} টি)
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      একই ডেলিভারি চার্জে নতুন প্রোডাক্ট যোগ করুন অথবা বর্তমান প্রোডাক্টের সাইজ/পরিমাণ পরিবর্তন করুন
                    </p>
                  </div>
                </div>

                {/* Current Order Items List with Size Dropdown & Quantity Controls */}
                <div className="space-y-2.5">
                  {editItems.map((item, idx) => {
                    const matchedProduct =
                      products.find(p => p.id === item.productId) ||
                      products.find(
                        p =>
                          p.sku === item.sku ||
                          p.nameBn === item.productName ||
                          p.nameEn === item.productName
                      );
                    const availableVariants = matchedProduct?.variants || [];

                    return (
                      <div
                        key={`${item.productId}_${idx}`}
                        className="p-3 rounded-xl bg-white border border-slate-200 shadow-2xs flex flex-col lg:flex-row lg:items-center justify-between gap-3"
                      >
                        <div className="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                          <div className="w-11 h-11 rounded-lg bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                            {item.image || matchedProduct?.image ? (
                              <img
                                src={item.image || matchedProduct?.image}
                                alt={item.productName}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Package className="w-5 h-5 text-slate-400" />
                            )}
                          </div>

                          <div className="min-w-0 flex-1 space-y-1.5">
                            <p className="font-extrabold text-slate-900 text-xs sm:text-sm truncate">
                              {idx + 1}. {item.productName}
                            </p>

                            <div className="flex flex-wrap items-center gap-2">
                              {/* Size / Variant Dropdown if product has variants */}
                              {availableVariants.length > 0 && (
                                <div className="flex items-center gap-1">
                                  <span className="text-[11px] font-bold text-slate-600">
                                    সাইজ পরিবর্তন:
                                  </span>
                                  <select
                                    value={
                                      availableVariants.find(
                                        v =>
                                          v.id === item.variantId ||
                                          v.label === item.variantLabel
                                      )?.id || ''
                                    }
                                    onChange={e => {
                                      const vId = e.target.value;
                                      const chosenVar = availableVariants.find(v => v.id === vId);
                                      if (!chosenVar) return;
                                      const nextPrice =
                                        Number(
                                          chosenVar.discountPrice && chosenVar.discountPrice > 0
                                            ? chosenVar.discountPrice
                                            : chosenVar.retailPrice
                                        ) || item.unitPrice;
                                      setEditItems(prev =>
                                        prev.map((it, i) =>
                                          i === idx
                                            ? {
                                                ...it,
                                                variantId: chosenVar.id,
                                                variantLabel: chosenVar.label,
                                                variantSku: chosenVar.sku || it.sku,
                                                unitPrice: nextPrice,
                                                total: nextPrice * (Number(it.quantity) || 1)
                                              }
                                            : it
                                        )
                                      );
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-blue-50 border border-blue-300 text-blue-950 font-extrabold text-[11px] outline-hidden cursor-pointer"
                                  >
                                    <option value="">-- সাইজ সিলেক্ট করুন --</option>
                                    {availableVariants.map(v => {
                                      const vPrice =
                                        v.discountPrice && v.discountPrice > 0
                                          ? v.discountPrice
                                          : v.retailPrice;
                                      return (
                                        <option key={v.id} value={v.id}>
                                          {v.label} (৳{vPrice})
                                        </option>
                                      );
                                    })}
                                  </select>
                                </div>
                              )}

                              {/* Custom Size / Color Text Input */}
                              <div className="flex items-center gap-1">
                                <span className="text-[11px] font-semibold text-slate-500">
                                  সাইজ/রঙ টেক্সট:
                                </span>
                                <input
                                  type="text"
                                  value={item.variantLabel || ''}
                                  onChange={e => {
                                    const val = e.target.value;
                                    setEditItems(prev =>
                                      prev.map((it, i) =>
                                        i === idx ? { ...it, variantLabel: val } : it
                                      )
                                    );
                                  }}
                                  placeholder="যেমন: 5-6 Years / নীল"
                                  className="w-36 px-2 py-1 rounded-lg bg-slate-50 border border-slate-300 text-[11px] font-bold text-slate-900 outline-hidden focus:border-blue-600"
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Right Controls: Unit Price, Quantity -/+ & Remove */}
                        <div className="flex flex-wrap items-center justify-between lg:justify-end gap-2.5 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                          <div className="flex items-center gap-1">
                            <span className="text-[11px] text-slate-500 font-semibold">দর ৳:</span>
                            <input
                              type="number"
                              min="0"
                              value={item.unitPrice}
                              onChange={e => {
                                const nextPrice = Math.max(0, Number(e.target.value) || 0);
                                setEditItems(prev =>
                                  prev.map((it, i) =>
                                    i === idx
                                      ? {
                                          ...it,
                                          unitPrice: nextPrice,
                                          total: nextPrice * (Number(it.quantity) || 1)
                                        }
                                      : it
                                  )
                                );
                              }}
                              className="w-20 px-2 py-1 rounded-lg bg-slate-50 border border-slate-300 font-mono font-bold text-slate-900 text-right outline-hidden"
                            />
                          </div>

                          <div className="inline-flex items-center rounded-xl border border-slate-300 bg-slate-50 overflow-hidden">
                            <button
                              type="button"
                              onClick={() => {
                                setEditItems(prev =>
                                  prev.map((it, i) => {
                                    if (i !== idx) return it;
                                    const nextQty = Math.max(1, (Number(it.quantity) || 1) - 1);
                                    return {
                                      ...it,
                                      quantity: nextQty,
                                      total: (Number(it.unitPrice) || 0) * nextQty
                                    };
                                  })
                                );
                              }}
                              className="px-2.5 py-1.5 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                              title="পরিমাণ কমান"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-3 py-1 font-mono font-extrabold text-slate-900 bg-white border-x border-slate-200">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setEditItems(prev =>
                                  prev.map((it, i) => {
                                    if (i !== idx) return it;
                                    const nextQty = (Number(it.quantity) || 1) + 1;
                                    return {
                                      ...it,
                                      quantity: nextQty,
                                      total: (Number(it.unitPrice) || 0) * nextQty
                                    };
                                  })
                                );
                              }}
                              className="px-2.5 py-1.5 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                              title="পরিমাণ বাড়ান"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <span className="font-mono font-extrabold text-slate-900 min-w-[70px] text-right">
                            {formatCurrency((Number(item.unitPrice) || 0) * (Number(item.quantity) || 1))}
                          </span>

                          <button
                            type="button"
                            onClick={() => {
                              if (editItems.length <= 1) {
                                showToast(
                                  'অর্ডারে অন্তত ১টি প্রোডাক্ট থাকতে হবে! আগে নতুন প্রোডাক্ট যোগ করে তারপর এটি মুছুন।',
                                  'error'
                                );
                                return;
                              }
                              setEditItems(prev => prev.filter((_, i) => i !== idx));
                            }}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer"
                            title="এই প্রোডাক্টটি অর্ডার থেকে বাদ দিন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Add New Product to This Order Box */}
                <div className="p-3.5 rounded-xl bg-white border-2 border-dashed border-emerald-400/90 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-extrabold text-emerald-950 flex items-center gap-1.5">
                      <PlusCircle className="w-4 h-4 text-emerald-600" />
                      <span>➕ এই অর্ডারের সাথে নতুন আরেকটি প্রোডাক্ট যোগ করুন (একই ডেলিভারি চার্জে):</span>
                    </span>
                    <input
                      type="text"
                      value={addProductSearch}
                      onChange={e => {
                        const val = e.target.value;
                        setAddProductSearch(val);
                        const q = val.trim().toLowerCase();
                        const firstMatch = products.find(
                          p =>
                            (p.nameBn || '').toLowerCase().includes(q) ||
                            (p.nameEn || '').toLowerCase().includes(q) ||
                            (p.sku || '').toLowerCase().includes(q)
                        );
                        if (firstMatch) {
                          setSelectedNewProductId(firstMatch.id);
                          setSelectedNewVariantId(firstMatch.variants?.[0]?.id || '');
                        }
                      }}
                      placeholder="🔍 প্রোডাক্টের নাম বা কোড লিখে খুঁজুন..."
                      className="w-full sm:w-64 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-300 text-xs text-slate-900 outline-hidden focus:border-emerald-600"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                    <div className="sm:col-span-5">
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        প্রোডাক্ট সিলেক্ট করুন *
                      </label>
                      <select
                        value={selectedProductToAdd?.id || ''}
                        onChange={e => {
                          const pid = e.target.value;
                          setSelectedNewProductId(pid);
                          const prod = products.find(p => p.id === pid);
                          setSelectedNewVariantId(prod?.variants?.[0]?.id || '');
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-bold text-slate-900 outline-hidden focus:border-emerald-600 cursor-pointer"
                      >
                        {editModalFilteredProducts.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.nameBn} — ৳
                            {p.discountPrice && p.discountPrice > 0
                              ? p.discountPrice
                              : p.retailPrice}{' '}
                            ({p.sku})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        সাইজ / ভ্যারিয়েশন
                      </label>
                      {selectedProductToAdd?.variants && selectedProductToAdd.variants.length > 0 ? (
                        <select
                          value={selectedNewVariantId || selectedProductToAdd.variants[0].id}
                          onChange={e => setSelectedNewVariantId(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-blue-50 border border-blue-300 font-extrabold text-blue-950 outline-hidden cursor-pointer"
                        >
                          {selectedProductToAdd.variants.map(v => {
                            const vp =
                              v.discountPrice && v.discountPrice > 0
                                ? v.discountPrice
                                : v.retailPrice;
                            return (
                              <option key={v.id} value={v.id}>
                                {v.label} — ৳{vp}
                              </option>
                            );
                          })}
                        </select>
                      ) : (
                        <div className="px-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-slate-500 font-medium">
                          স্ট্যান্ডার্ড (একক সাইজ)
                        </div>
                      )}
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        পরিমাণ (Qty)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={newProductQty}
                        onChange={e => setNewProductQty(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-mono font-extrabold text-slate-900 text-center outline-hidden"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <button
                        type="button"
                        onClick={handleAddProductToEditOrder}
                        className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        <span>যোগ করুন</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 4: Special Discount & Live Bill Recalculation Summary */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-stretch">
                {/* Left: Special Discount Box */}
                <div className="md:col-span-6 p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-2.5 flex flex-col justify-between">
                  <div className="space-y-2">
                    <label className="block font-extrabold text-rose-950 flex items-center gap-1.5">
                      <Tag className="w-4 h-4 text-rose-600" />
                      <span>৪. স্পেশাল ডিসকাউন্ট / ছাড় (৳)</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        value={editDiscountAmount}
                        onChange={e => setEditDiscountAmount(e.target.value)}
                        placeholder="0"
                        className="w-32 px-3 py-2 bg-white border border-rose-300 focus:border-rose-600 rounded-xl font-mono font-extrabold text-sm text-slate-900 outline-hidden"
                      />
                      <div className="flex flex-wrap gap-1">
                        {[50, 100, 150, 200, 0].map(preset => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setEditDiscountAmount(String(preset))}
                            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-extrabold border cursor-pointer ${
                              Number(editDiscountAmount) === preset
                                ? 'bg-rose-600 text-white border-rose-600'
                                : 'bg-white text-rose-800 border-rose-200 hover:bg-rose-100'
                            }`}
                          >
                            {preset === 0 ? '৳0 (রিমুভ)' : `৳${preset}`}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Previous Edit History Log if any */}
                  {editingOrder.editHistory && editingOrder.editHistory.length > 0 && (
                    <div className="pt-2 border-t border-rose-200/60 space-y-1">
                      <p className="text-[10px] font-extrabold text-slate-600">
                        📜 পূর্ববর্তী এডিট রেকর্ড ({editingOrder.editHistory.length}):
                      </p>
                      <div className="max-h-16 overflow-y-auto space-y-1 pr-1">
                        {editingOrder.editHistory.slice(-3).map((h, i) => (
                          <p key={i} className="text-[10px] text-slate-600 bg-white/80 px-2 py-1 rounded border border-slate-200">
                            • {h.summary} — <span className="font-bold">{h.editedBy}</span>
                          </p>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Right: Live Automatic Bill Summary */}
                <div className="md:col-span-6 p-4 rounded-2xl bg-slate-900 text-white space-y-2 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-slate-300">
                      <span>প্রোডাক্ট সাবটোটাল ({editItems.reduce((s, i) => s + (Number(i.quantity) || 1), 0)} পিস):</span>
                      <span className="font-mono font-bold text-white">
                        {formatCurrency(editCalculatedSubtotal)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span>ডেলিভারি চার্জ ({editDeliveryArea.split(' ')[0] || 'ডেলিভারি'}):</span>
                      <span className="font-mono font-bold text-amber-300">
                        + {editCalculatedDelivery === 0 ? 'ফ্রি (৳0)' : formatCurrency(editCalculatedDelivery)}
                      </span>
                    </div>
                    {editCalculatedDiscount > 0 && (
                      <div className="flex items-center justify-between text-rose-300">
                        <span>স্পেশাল ডিসকাউন্ট:</span>
                        <span className="font-mono font-bold">
                          - {formatCurrency(editCalculatedDiscount)}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-2.5 border-t border-slate-700 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-extrabold text-emerald-300">
                        সর্বমোট নতুন বিল (Grand Total):
                      </p>
                      {editCalculatedGrandTotal !== editingOrder.grandTotal && (
                        <p className="text-[10px] text-slate-400 font-mono">
                          আগের বিল ছিল: {formatCurrency(editingOrder.grandTotal)}
                        </p>
                      )}
                    </div>
                    <p className="text-xl sm:text-2xl font-black font-mono text-emerald-400">
                      {formatCurrency(editCalculatedGrandTotal)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setEditingOrder(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-extrabold cursor-pointer"
                >
                  বাতিল করুন
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold flex items-center gap-2 shadow-md cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>✅ অর্ডার পরিবর্তন সেভ করুন (বিল: {formatCurrency(editCalculatedGrandTotal)})</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WhatsApp Message Template Customizer & Blank Mode Modal */}
      {showWhatsAppSettingsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full overflow-hidden shadow-2xl my-auto">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-teal-700 via-emerald-700 to-teal-800 px-4 sm:px-6 py-4 text-white flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold">
                    WhatsApp মেসেজ এডিট ও কন্ট্রোল সিস্টেম
                  </h3>
                  <p className="text-[11px] text-teal-100">
                    অর্ডারের WhatsApp বাটনে ক্লিক করলে কী মেসেজ যাবে তা নিজের মতো লিখুন অথবা সম্পূর্ণ ফাঁকা (Blank) রাখুন
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowWhatsAppSettingsModal(false)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tabs: Completed Order vs Incomplete/Abandoned Order */}
            <div className="px-4 sm:px-6 pt-3 bg-slate-50 border-b border-slate-200 flex items-center gap-2">
              <button
                type="button"
                onClick={() => setWaModalTab('order')}
                className={`px-3.5 py-2 rounded-t-xl text-xs font-extrabold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  waModalTab === 'order'
                    ? 'bg-white text-teal-800 border-teal-600 shadow-2xs'
                    : 'text-slate-600 border-transparent hover:text-slate-900'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>অর্ডার কনফার্ম মেসেজ (Completed Orders)</span>
              </button>
              <button
                type="button"
                onClick={() => setWaModalTab('abandoned')}
                className={`px-3.5 py-2 rounded-t-xl text-xs font-extrabold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  waModalTab === 'abandoned'
                    ? 'bg-white text-rose-700 border-rose-600 shadow-2xs'
                    : 'text-slate-600 border-transparent hover:text-slate-900'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>অসম্পূর্ণ অর্ডার মেসেজ (Incomplete)</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 space-y-4 max-h-[78vh] overflow-y-auto text-xs">
              {waModalTab === 'order' ? (
                <>
                  {/* Mode Selector: Custom Message vs Blank Message */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        setWaOrderBlankDraft(false);
                        if (!waOrderTemplateDraft.trim()) {
                          setWaOrderTemplateDraft(DEFAULT_WHATSAPP_ORDER_TEMPLATE);
                        }
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                        !waOrderBlankDraft && waOrderTemplateDraft.trim() !== ''
                          ? 'bg-teal-50/90 border-teal-500 ring-2 ring-teal-500/20'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full mt-0.5 flex items-center justify-center border shrink-0 ${
                          !waOrderBlankDraft && waOrderTemplateDraft.trim() !== ''
                            ? 'border-teal-600 bg-teal-600 text-white'
                            : 'border-slate-300'
                        }`}
                      >
                        {!waOrderBlankDraft && waOrderTemplateDraft.trim() !== '' && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </div>
                      <div>
                        <p className="font-extrabold text-slate-900">
                          ✍️ অটো মেসেজ চালু (এডিট করা যাবে)
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          WhatsApp বাটনে ক্লিক করলে আপনার লেখা মেসেজটি কাস্টমারের নাম ও বিলসহ অটো টাইপ হয়ে থাকবে।
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setWaOrderBlankDraft(true)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                        waOrderBlankDraft || waOrderTemplateDraft.trim() === ''
                          ? 'bg-amber-50/90 border-amber-500 ring-2 ring-amber-500/20'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full mt-0.5 flex items-center justify-center border shrink-0 ${
                          waOrderBlankDraft || waOrderTemplateDraft.trim() === ''
                            ? 'border-amber-600 bg-amber-600 text-white'
                            : 'border-slate-300'
                        }`}
                      >
                        {(waOrderBlankDraft || waOrderTemplateDraft.trim() === '') && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </div>
                      <div>
                        <p className="font-extrabold text-slate-900">
                          ⬜ মেসেজ সম্পূর্ণ ফাঁকা রাখুন (Blank)
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          কোনো ডেমো লেখা থাকবে না। ক্লিক করলে সরাসরি কাস্টমারের ইনবক্স ফাঁকা অবস্থায় ওপেন হবে।
                        </p>
                      </div>
                    </button>
                  </div>

                  {/* Template Editor Box */}
                  <div
                    className={`space-y-2.5 p-3.5 rounded-2xl border transition-all ${
                      waOrderBlankDraft
                        ? 'bg-slate-50 border-slate-200 opacity-75'
                        : 'bg-white border-teal-200'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="font-extrabold text-slate-800 flex items-center gap-1.5">
                        <Edit2 className="w-3.5 h-3.5 text-teal-600" />
                        <span>আপনার WhatsApp মেসেজ লিখুন বা পরিবর্তন করুন:</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setWaOrderTemplateDraft('');
                            setWaOrderBlankDraft(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold cursor-pointer"
                        >
                          🗑️ মুছে ফাঁকা করুন
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setWaOrderBlankDraft(false);
                            setWaOrderTemplateDraft(DEFAULT_WHATSAPP_ORDER_TEMPLATE);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[11px] font-extrabold cursor-pointer"
                        >
                          🔄 ডিফল্ট মেসেজ আনুন
                        </button>
                      </div>
                    </div>

                    <textarea
                      rows={4}
                      value={waOrderTemplateDraft}
                      onChange={e => {
                        setWaOrderTemplateDraft(e.target.value);
                        if (e.target.value.trim() !== '') {
                          setWaOrderBlankDraft(false);
                        }
                      }}
                      placeholder="এখানে আপনার পছন্দমতো মেসেজ লিখুন... অথবা খালি রাখলে কোনো মেসেজ যাবে না।"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-teal-600 outline-hidden text-xs sm:text-sm font-medium text-slate-900 leading-relaxed bg-white"
                    />

                    {/* Dynamic Placeholder Tag Buttons */}
                    <div className="space-y-1.5">
                      <p className="text-[11px] font-bold text-slate-500">
                        ট্যাগে ক্লিক করলে মেসেজে কাস্টমারের অটো তথ্য যুক্ত হবে:
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { label: '+ কাস্টমারের নাম', tag: '{name}' },
                          { label: '+ দোকানের নাম', tag: '{shop}' },
                          { label: '+ অর্ডার নাম্বার', tag: '{order_no}' },
                          { label: '+ মোট বিল', tag: '{total}' },
                          { label: '+ পণ্যের নাম ও সাইজ', tag: '{items}' },
                          { label: '+ ডেলিভারি ঠিকানা', tag: '{address}' }
                        ].map(item => (
                          <button
                            key={item.tag}
                            type="button"
                            onClick={() => {
                              setWaOrderBlankDraft(false);
                              setWaOrderTemplateDraft(prev => `${prev}${prev.endsWith(' ') || !prev ? '' : ' '}${item.tag}`);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 text-[11px] font-extrabold cursor-pointer transition-colors"
                          >
                            {item.label} <span className="font-mono text-[10px] text-teal-700">({item.tag})</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Live Preview */}
                  <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-extrabold text-emerald-900 flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5 text-emerald-700" />
                        <span>লাইভ প্রিভিউ (WhatsApp-এ যেমন দেখাবে):</span>
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                          waOrderBlankDraft || waOrderTemplateDraft.trim() === ''
                            ? 'bg-amber-200 text-amber-900'
                            : 'bg-emerald-200 text-emerald-900'
                        }`}
                      >
                        {waOrderBlankDraft || waOrderTemplateDraft.trim() === ''
                          ? 'ফাঁকা চ্যাট ওপেন হবে'
                          : 'অটো মেসেজ প্রিভিউ'}
                      </span>
                    </div>
                    {waOrderBlankDraft || waOrderTemplateDraft.trim() === '' ? (
                      <p className="text-xs font-bold text-amber-900 bg-white/90 px-3 py-2.5 rounded-xl border border-amber-200">
                        ✨ মেসেজ বক্স সম্পূর্ণ ফাঁকা থাকবে। WhatsApp বাটনে ক্লিক করলে সরাসরি কাস্টমারের চ্যাট ওপেন হবে, আপনি নিজের হাতে যা খুশি লিখতে বা ভয়েস দিতে পারবেন।
                      </p>
                    ) : (
                      <p className="text-xs text-slate-800 bg-white px-3 py-2.5 rounded-xl border border-emerald-200/80 leading-relaxed whitespace-pre-wrap">
                        {waOrderTemplateDraft
                          .replace(/\{name\}|\{customer_name\}/g, 'সাবরিনা সুলতানা নিপা')
                          .replace(/\{shop\}|\{shop_name\}/g, currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট')
                          .replace(/\{order_no\}/g, 'ORD-48291')
                          .replace(/\{invoice_no\}/g, 'INV-48291')
                          .replace(/\{total\}|\{total_bill\}/g, '1461')
                          .replace(/\{items\}|\{products\}/g, 'বেবি প্রিন্সেস ফ্রক (৫-৬ বছর) x1')
                          .replace(/\{address\}/g, 'মিরপুর ১০, ঢাকা')}
                      </p>
                    )}
                  </div>
                </>
              ) : (
                <>
                  {/* Abandoned / Incomplete Order WhatsApp Settings */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        setWaAbandonedBlankDraft(false);
                        if (!waAbandonedTemplateDraft.trim()) {
                          setWaAbandonedTemplateDraft(DEFAULT_WHATSAPP_ABANDONED_TEMPLATE);
                        }
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                        !waAbandonedBlankDraft && waAbandonedTemplateDraft.trim() !== ''
                          ? 'bg-rose-50/90 border-rose-500 ring-2 ring-rose-500/20'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full mt-0.5 flex items-center justify-center border shrink-0 ${
                          !waAbandonedBlankDraft && waAbandonedTemplateDraft.trim() !== ''
                            ? 'border-rose-600 bg-rose-600 text-white'
                            : 'border-slate-300'
                        }`}
                      >
                        {!waAbandonedBlankDraft && waAbandonedTemplateDraft.trim() !== '' && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </div>
                      <div>
                        <p className="font-extrabold text-slate-900">
                          ✍️ রিকভারি মেসেজ চালু (এডিট করা যাবে)
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          অসম্পূর্ণ অর্ডারের WhatsApp বাটনে ক্লিক করলে রিকভারি মেসেজ রেডি থাকবে।
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setWaAbandonedBlankDraft(true)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                        waAbandonedBlankDraft || waAbandonedTemplateDraft.trim() === ''
                          ? 'bg-amber-50/90 border-amber-500 ring-2 ring-amber-500/20'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full mt-0.5 flex items-center justify-center border shrink-0 ${
                          waAbandonedBlankDraft || waAbandonedTemplateDraft.trim() === ''
                            ? 'border-amber-600 bg-amber-600 text-white'
                            : 'border-slate-300'
                        }`}
                      >
                        {(waAbandonedBlankDraft || waAbandonedTemplateDraft.trim() === '') && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </div>
                      <div>
                        <p className="font-extrabold text-slate-900">
                          ⬜ মেসেজ সম্পূর্ণ ফাঁকা রাখুন (Blank)
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          কোনো ডেমো লেখা থাকবে না, সরাসরি কাস্টমারের ইনবক্স ফাঁকা অবস্থায় ওপেন হবে।
                        </p>
                      </div>
                    </button>
                  </div>

                  <div
                    className={`space-y-2.5 p-3.5 rounded-2xl border transition-all ${
                      waAbandonedBlankDraft
                        ? 'bg-slate-50 border-slate-200 opacity-75'
                        : 'bg-white border-rose-200'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="font-extrabold text-slate-800 flex items-center gap-1.5">
                        <Edit2 className="w-3.5 h-3.5 text-rose-600" />
                        <span>অসম্পূর্ণ অর্ডারের WhatsApp মেসেজ লিখুন:</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setWaAbandonedTemplateDraft('');
                            setWaAbandonedBlankDraft(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold cursor-pointer"
                        >
                          🗑️ মুছে ফাঁকা করুন
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setWaAbandonedBlankDraft(false);
                            setWaAbandonedTemplateDraft(DEFAULT_WHATSAPP_ABANDONED_TEMPLATE);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[11px] font-extrabold cursor-pointer"
                        >
                          🔄 ডিফল্ট মেসেজ আনুন
                        </button>
                      </div>
                    </div>

                    <textarea
                      rows={4}
                      value={waAbandonedTemplateDraft}
                      onChange={e => {
                        setWaAbandonedTemplateDraft(e.target.value);
                        if (e.target.value.trim() !== '') {
                          setWaAbandonedBlankDraft(false);
                        }
                      }}
                      placeholder="এখানে অসম্পূর্ণ অর্ডারের মেসেজ লিখুন... অথবা খালি রাখলে কোনো মেসেজ যাবে না।"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-rose-600 outline-hidden text-xs sm:text-sm font-medium text-slate-900 leading-relaxed bg-white"
                    />

                    <div className="space-y-1.5">
                      <p className="text-[11px] font-bold text-slate-500">
                        ট্যাগে ক্লিক করলে মেসেজে কাস্টমারের অটো তথ্য যুক্ত হবে:
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { label: '+ কাস্টমারের নাম', tag: '{name}' },
                          { label: '+ দোকানের নাম', tag: '{shop}' },
                          { label: '+ পণ্যের নাম ও সাইজ', tag: '{items}' },
                          { label: '+ সম্ভাব্য বিল', tag: '{total}' },
                          { label: '+ ঠিকানা', tag: '{address}' }
                        ].map(item => (
                          <button
                            key={item.tag}
                            type="button"
                            onClick={() => {
                              setWaAbandonedBlankDraft(false);
                              setWaAbandonedTemplateDraft(prev => `${prev}${prev.endsWith(' ') || !prev ? '' : ' '}${item.tag}`);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200 text-[11px] font-extrabold cursor-pointer transition-colors"
                          >
                            {item.label} <span className="font-mono text-[10px] text-rose-700">({item.tag})</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Live Preview */}
                  <div className="p-3.5 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-1.5">
                    <span className="text-[11px] font-extrabold text-rose-900 flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-rose-700" />
                      <span>লাইভ প্রিভিউ:</span>
                    </span>
                    {waAbandonedBlankDraft || waAbandonedTemplateDraft.trim() === '' ? (
                      <p className="text-xs font-bold text-amber-900 bg-white/90 px-3 py-2.5 rounded-xl border border-amber-200">
                        ✨ মেসেজ বক্স সম্পূর্ণ ফাঁকা থাকবে। ক্লিক করলে সরাসরি কাস্টমারের চ্যাট ওপেন হবে।
                      </p>
                    ) : (
                      <p className="text-xs text-slate-800 bg-white px-3 py-2.5 rounded-xl border border-rose-200/80 leading-relaxed whitespace-pre-wrap">
                        {waAbandonedTemplateDraft
                          .replace(/\{name\}|\{customer_name\}/g, 'সাবরিনা সুলতানা নিপা')
                          .replace(/\{shop\}|\{shop_name\}/g, currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট')
                          .replace(/\{total\}|\{total_bill\}/g, '1461')
                          .replace(/\{items\}|\{products\}/g, 'বেবি প্রিন্সেস ফ্রক (৫-৬ বছর)')
                          .replace(/\{address\}/g, 'মিরপুর ১০, ঢাকা')}
                      </p>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-4 sm:px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setShowWhatsAppSettingsModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-extrabold cursor-pointer"
              >
                বাতিল
              </button>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (waModalTab === 'order') {
                      updateBusiness({
                        whatsappOrderMessageBlank: true,
                        whatsappOrderTemplate: ''
                      });
                      showToast(
                        '✅ অর্ডারের WhatsApp মেসেজ "ফাঁকা (Blank)" করে সেভ করা হয়েছে! এখন ক্লিক করলে কোনো ডেমো মেসেজ ছাড়াই সরাসরি চ্যাট ওপেন হবে।',
                        'success'
                      );
                    } else {
                      updateBusiness({
                        whatsappAbandonedMessageBlank: true,
                        whatsappAbandonedTemplate: ''
                      });
                      showToast(
                        '✅ অসম্পূর্ণ অর্ডারের WhatsApp মেসেজ "ফাঁকা (Blank)" করে সেভ করা হয়েছে!',
                        'success'
                      );
                    }
                    setShowWhatsAppSettingsModal(false);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-extrabold cursor-pointer shadow-2xs"
                >
                  ⬜ ১-ক্লিকে ফাঁকা (Blank) সেভ করুন
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const finalOrderBlank =
                      waOrderBlankDraft || waOrderTemplateDraft.trim() === '';
                    const finalAbandonedBlank =
                      waAbandonedBlankDraft || waAbandonedTemplateDraft.trim() === '';
                    updateBusiness({
                      whatsappOrderMessageBlank: finalOrderBlank,
                      whatsappOrderTemplate: waOrderTemplateDraft,
                      whatsappAbandonedMessageBlank: finalAbandonedBlank,
                      whatsappAbandonedTemplate: waAbandonedTemplateDraft
                    });
                    setShowWhatsAppSettingsModal(false);
                    showToast(
                      finalOrderBlank
                        ? '✅ WhatsApp মেসেজ ফাঁকা (Blank) অবস্থায় সেভ হয়েছে!'
                        : '✅ আপনার কাস্টম WhatsApp মেসেজ সফলভাবে সেভ হয়েছে!',
                      'success'
                    );
                  }}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>✅ সেটিংস সেভ করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Smart Invoice, Delivery Slip & Customization Studio Modal */}
      {(selectedOrder || showGlobalInvoiceCustomizer) && (
        <SmartInvoiceSlipModal
          order={
            selectedOrder
              ? onlineOrders.find((o) => o.id === selectedOrder.id) || selectedOrder
              : null
          }
          bulkOrders={
            bulkPrintOrders.length > 0
              ? bulkPrintOrders.map(
                  (bo) => onlineOrders.find((o) => o.id === bo.id) || bo
                )
              : undefined
          }
          initialMode={invoiceModalInitialMode}
          business={currentBusiness}
          products={products}
          userRole={currentUser?.role}
          onUpdateBusiness={updateBusiness}
          onUpdateOrder={updateOnlineOrder}
          onClose={() => {
            setSelectedOrder(null);
            setBulkPrintOrders([]);
            setShowGlobalInvoiceCustomizer(false);
          }}
          formatCurrency={formatCurrency}
          formatDate={formatDate}
          showToast={showToast}
        />
      )}
    </div>
  );
};
