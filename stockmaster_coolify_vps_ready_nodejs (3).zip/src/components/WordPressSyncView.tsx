import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Globe,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Save,
  Send,
  Trash2,
  ShieldCheck,
  ExternalLink,
  Copy,
  Check,
  Sparkles,
  ShoppingBag,
  Link2,
  PackageCheck
} from 'lucide-react';
import {
  testWordPressConnection,
  syncOrderToWordPress,
  fetchWordPressProducts,
  syncSingleProductToWordPress,
  buildVariantSkuCode,
  getWordPressSyncLogs,
  clearWordPressSyncLogs,
  normalizeWpSiteUrl,
  WordPressSyncLogEntry,
  RemoteWooProduct
} from '../utils/wordpressOrderSync';
import { Product } from '../types';

export const WordPressSyncView: React.FC = () => {
  const {
    currentBusiness,
    updateBusiness,
    products,
    updateProduct,
    onlineOrders,
    showToast,
    formatCurrency,
    currentUser
  } = useApp();

  const [wpSyncEnabled, setWpSyncEnabled] = useState<boolean>(
    currentBusiness.wpSyncEnabled ?? true
  );
  const [wpSiteUrl, setWpSiteUrl] = useState<string>(currentBusiness.wpSiteUrl || '');
  const [wpConsumerKey, setWpConsumerKey] = useState<string>(currentBusiness.wpConsumerKey || '');
  const [wpConsumerSecret, setWpConsumerSecret] = useState<string>(
    currentBusiness.wpConsumerSecret || ''
  );
  const [wpDefaultOrderStatus, setWpDefaultOrderStatus] = useState<
    'processing' | 'pending' | 'on-hold' | 'completed'
  >(currentBusiness.wpDefaultOrderStatus || 'processing');
  const [wpSyncIncludeDeliveryFee, setWpSyncIncludeDeliveryFee] = useState<boolean>(
    currentBusiness.wpSyncIncludeDeliveryFee ?? true
  );

  const [isTestingConnection, setIsTestingConnection] = useState<boolean>(false);
  const [isSendingTestOrder, setIsSendingTestOrder] = useState<boolean>(false);
  const [syncingOrderId, setSyncingOrderId] = useState<string | null>(null);
  const [connectionResult, setConnectionResult] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);
  const [syncLogs, setSyncLogs] = useState<WordPressSyncLogEntry[]>(() => getWordPressSyncLogs());
  const [copiedEndpoint, setCopiedEndpoint] = useState<boolean>(false);

  // WordPress Product Matching & Auto-Linking States
  const [remoteWpProducts, setRemoteWpProducts] = useState<RemoteWooProduct[]>([]);
  const [isFetchingWpProducts, setIsFetchingWpProducts] = useState<boolean>(false);
  const [isSyncingAllProducts, setIsSyncingAllProducts] = useState<boolean>(false);
  const [syncingProductId, setSyncingProductId] = useState<string | null>(null);

  useEffect(() => {
    setWpSyncEnabled(currentBusiness.wpSyncEnabled ?? true);
    setWpSiteUrl(currentBusiness.wpSiteUrl || '');
    setWpConsumerKey(currentBusiness.wpConsumerKey || '');
    setWpConsumerSecret(currentBusiness.wpConsumerSecret || '');
    setWpDefaultOrderStatus(currentBusiness.wpDefaultOrderStatus || 'processing');
    setWpSyncIncludeDeliveryFee(currentBusiness.wpSyncIncludeDeliveryFee ?? true);
  }, [currentBusiness]);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl);
    setWpSiteUrl(cleanedUrl);

    updateBusiness({
      wpSyncEnabled,
      wpSiteUrl: cleanedUrl,
      wpConsumerKey: wpConsumerKey.trim(),
      wpConsumerSecret: wpConsumerSecret.trim(),
      wpDefaultOrderStatus,
      wpSyncIncludeDeliveryFee
    });

    showToast(
      'WordPress (WooCommerce) অটোমেটিক অর্ডার ও প্রোডাক্ট সিঙ্ক কনফিগারেশন সেভ হয়েছে!',
      'success'
    );
  };

  const handleTestConnection = async () => {
    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl);
    if (!cleanedUrl || !wpConsumerKey.trim() || !wpConsumerSecret.trim()) {
      showToast(
        'অনুগ্রহ করে প্রথমে WordPress Site URL, Consumer Key এবং Consumer Secret লিখুন',
        'error'
      );
      return;
    }

    setIsTestingConnection(true);
    setConnectionResult(null);
    try {
      const res = await testWordPressConnection({
        siteUrl: cleanedUrl,
        consumerKey: wpConsumerKey.trim(),
        consumerSecret: wpConsumerSecret.trim()
      });
      setConnectionResult(res);
      showToast(res.message, res.ok ? 'success' : 'error');
    } finally {
      setIsTestingConnection(false);
    }
  };

  const handleSendTestOrder = async () => {
    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl);
    if (!cleanedUrl || !wpConsumerKey.trim() || !wpConsumerSecret.trim()) {
      showToast(
        'টেস্ট অর্ডার পাঠাতে প্রথমে WordPress Site URL, Consumer Key এবং Consumer Secret পূরণ করুন',
        'error'
      );
      return;
    }

    const tempBiz = {
      ...currentBusiness,
      wpSyncEnabled: true,
      wpSiteUrl: cleanedUrl,
      wpConsumerKey: wpConsumerKey.trim(),
      wpConsumerSecret: wpConsumerSecret.trim(),
      wpDefaultOrderStatus,
      wpSyncIncludeDeliveryFee
    };

    const firstProd = products[0];
    const firstVar = firstProd?.variants?.[0];
    const prodPrice = firstVar ? firstVar.retailPrice : firstProd ? firstProd.retailPrice : 1650;
    const prodName = firstProd
      ? `${firstProd.nameBn}${firstVar ? ` (${firstVar.label})` : ''}`
      : 'প্রিমিয়াম এমব্রয়ডারি কটন পাঞ্জাবি (Size: L)';

    const sampleOrder = {
      id: `ord_test_${Date.now()}`,
      orderNo: `ORD-TEST-${Math.floor(1000 + Math.random() * 9000)}`,
      invoiceNo: `INV-WP-${Math.floor(1000 + Math.random() * 9000)}`,
      businessId: currentBusiness.id,
      outletId: 'outlet_01',
      customerName: 'টেস্ট কাস্টমার (ফ্রন্ট ওয়েবসাইট)',
      customerPhone: '01711223344',
      deliveryArea: 'হোম ডেলিভারি (ঢাকা)',
      deliveryAddress: 'ধানমন্ডি ২৭, ঢাকা - টেস্ট অর্ডার',
      deliverySlot: 'এক্সপ্রেস ডেলিভারি',
      items: [
        {
          productId: firstProd?.id || 'prod_01',
          productName: prodName,
          productNameClean: firstProd?.nameBn || 'প্রিমিয়াম এমব্রয়ডারি কটন পাঞ্জাবি',
          sku: firstVar?.sku || firstProd?.sku || 'PANJABI-01',
          wpProductId: firstProd?.wpProductId,
          wpVariationId: firstVar?.wpVariationId,
          variantId: firstVar?.id,
          variantLabel: firstVar?.label || 'L',
          unit: 'পিস',
          quantity: 1,
          unitPrice: prodPrice,
          costPrice: firstProd?.purchasePrice || 1100,
          discount: 0,
          total: prodPrice
        }
      ],
      subtotal: prodPrice,
      deliveryCharge: 60,
      discountAmount: 0,
      grandTotal: prodPrice + 60,
      paymentMethod: 'cod' as const,
      paymentStatus: 'unpaid' as const,
      orderStatus: 'pending' as const,
      notes: 'ফ্রন্ট ফ্যাশন ওয়েবসাইট থেকে স্বয়ংক্রিয়ভাবে প্রেরিত টেস্ট অর্ডার (প্রোডাক্টসহ)',
      createdAt: new Date().toISOString()
    };

    setIsSendingTestOrder(true);
    try {
      const res = await syncOrderToWordPress({
        business: tempBiz,
        order: sampleOrder,
        productsCatalog: products,
        forceSync: true
      });
      setSyncLogs(getWordPressSyncLogs());
      showToast(res.message, res.ok ? 'success' : 'error');
    } finally {
      setIsSendingTestOrder(false);
    }
  };

  const handleManualSyncExistingOrder = async (orderId: string) => {
    const targetOrder = onlineOrders.find(o => o.id === orderId);
    if (!targetOrder) return;

    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl || currentBusiness.wpSiteUrl);
    const ck = (wpConsumerKey || currentBusiness.wpConsumerKey || '').trim();
    const cs = (wpConsumerSecret || currentBusiness.wpConsumerSecret || '').trim();

    if (!cleanedUrl || !ck || !cs) {
      showToast('প্রথমে WordPress Site URL ও API Keys সেভ করুন', 'error');
      return;
    }

    setSyncingOrderId(orderId);
    try {
      const res = await syncOrderToWordPress({
        business: {
          ...currentBusiness,
          wpSyncEnabled: true,
          wpSiteUrl: cleanedUrl,
          wpConsumerKey: ck,
          wpConsumerSecret: cs,
          wpDefaultOrderStatus,
          wpSyncIncludeDeliveryFee
        },
        order: targetOrder,
        productsCatalog: products,
        forceSync: true
      });
      setSyncLogs(getWordPressSyncLogs());
      showToast(res.message, res.ok ? 'success' : 'error');
    } finally {
      setSyncingOrderId(null);
    }
  };

  // Fetch products from WordPress and auto-match by SKU or Name
  const handleFetchAndAutoMatchWpProducts = async () => {
    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl || currentBusiness.wpSiteUrl);
    const ck = (wpConsumerKey || currentBusiness.wpConsumerKey || '').trim();
    const cs = (wpConsumerSecret || currentBusiness.wpConsumerSecret || '').trim();

    if (!cleanedUrl || !ck || !cs) {
      showToast('প্রথমে WordPress Site URL, Consumer Key এবং Consumer Secret দিন', 'error');
      return;
    }

    setIsFetchingWpProducts(true);
    try {
      const res = await fetchWordPressProducts({
        siteUrl: cleanedUrl,
        consumerKey: ck,
        consumerSecret: cs
      });
      if (!res.ok) {
        showToast(res.message, 'error');
        return;
      }

      setRemoteWpProducts(res.products);
      let matchedCount = 0;

      for (const localProd of products) {
        const match =
          res.products.find(
            rp =>
              rp.sku &&
              localProd.sku &&
              rp.sku.trim().toLowerCase() === localProd.sku.trim().toLowerCase()
          ) ||
          res.products.find(
            rp =>
              rp.name.trim().toLowerCase() === localProd.nameBn.trim().toLowerCase() ||
              (localProd.nameEn &&
                rp.name.trim().toLowerCase() === localProd.nameEn.trim().toLowerCase())
          );

        if (match && match.id > 0 && localProd.wpProductId !== match.id) {
          await updateProduct(localProd.id, { wpProductId: match.id });
          matchedCount++;
        }
      }

      showToast(
        matchedCount > 0
          ? `WordPress থেকে ${res.products.length} টি প্রোডাক্ট লোড হয়েছে এবং ${matchedCount} টি প্রোডাক্ট অটো-ম্যাচ হয়েছে!`
          : `WordPress থেকে ${res.products.length} টি প্রোডাক্ট লোড হয়েছে! নিচে প্রোডাক্ট লিস্ট থেকে লিংক করতে পারেন।`,
        'success'
      );
    } finally {
      setIsFetchingWpProducts(false);
    }
  };

  // Sync or create a single product (+ its size variations & SKUs) on WordPress and save wpProductId + wpVariationId
  const handleSyncSingleProduct = async (prod: Product) => {
    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl || currentBusiness.wpSiteUrl);
    const ck = (wpConsumerKey || currentBusiness.wpConsumerKey || '').trim();
    const cs = (wpConsumerSecret || currentBusiness.wpConsumerSecret || '').trim();

    if (!cleanedUrl || !ck || !cs) {
      showToast('প্রথমে WordPress Site URL, Consumer Key এবং Consumer Secret দিন', 'error');
      return;
    }

    setSyncingProductId(prod.id);
    try {
      const res = await syncSingleProductToWordPress({
        siteUrl: cleanedUrl,
        consumerKey: ck,
        consumerSecret: cs,
        product: prod
      });
      if (res.ok && res.wpProductId) {
        const updatedVariants = Array.isArray(prod.variants)
          ? prod.variants.map((v, idx) => {
              const mapped = res.variantMappings?.find(vm => vm.id === v.id);
              return {
                ...v,
                sku: mapped?.sku || v.sku || buildVariantSkuCode(prod.sku, v.label, idx),
                wpVariationId: mapped?.wpVariationId || v.wpVariationId
              };
            })
          : undefined;
        await updateProduct(prod.id, {
          wpProductId: res.wpProductId,
          ...(updatedVariants ? { variants: updatedVariants } : {})
        });
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setSyncingProductId(null);
    }
  };

  // 1-Click Auto-Generate Variation SKUs for all products that have sizes/variations
  const handleGenerateAllVariantSkus = async () => {
    let updatedCount = 0;
    for (const prod of products) {
      if (Array.isArray(prod.variants) && prod.variants.length > 0) {
        const nextVars = prod.variants.map((v, idx) => ({
          ...v,
          sku: (v.sku || '').trim() || buildVariantSkuCode(prod.sku, v.label, idx)
        }));
        await updateProduct(prod.id, { variants: nextVars });
        updatedCount++;
      }
    }
    showToast(
      `${updatedCount} টি ভ্যারিয়েশন প্রোডাক্টের সব সাইজের জন্য অটো-SKU কোড জেনারেট ও সেভ হয়েছে!`,
      'success'
    );
  };

  // 1-Click Sync & Link All Local Products (+ Size Variations) to WordPress
  const handleSyncAllProductsToWp = async () => {
    const cleanedUrl = normalizeWpSiteUrl(wpSiteUrl || currentBusiness.wpSiteUrl);
    const ck = (wpConsumerKey || currentBusiness.wpConsumerKey || '').trim();
    const cs = (wpConsumerSecret || currentBusiness.wpConsumerSecret || '').trim();

    if (!cleanedUrl || !ck || !cs) {
      showToast('প্রথমে WordPress Site URL, Consumer Key এবং Consumer Secret দিন', 'error');
      return;
    }

    setIsSyncingAllProducts(true);
    let successCount = 0;
    try {
      for (const prod of products) {
        const res = await syncSingleProductToWordPress({
          siteUrl: cleanedUrl,
          consumerKey: ck,
          consumerSecret: cs,
          product: prod
        });
        if (res.ok && res.wpProductId) {
          const updatedVariants = Array.isArray(prod.variants)
            ? prod.variants.map((v, idx) => {
                const mapped = res.variantMappings?.find(vm => vm.id === v.id);
                return {
                  ...v,
                  sku: mapped?.sku || v.sku || buildVariantSkuCode(prod.sku, v.label, idx),
                  wpVariationId: mapped?.wpVariationId || v.wpVariationId
                };
              })
            : undefined;
          await updateProduct(prod.id, {
            wpProductId: res.wpProductId,
            ...(updatedVariants ? { variants: updatedVariants } : {})
          });
          successCount++;
        }
      }
      if (successCount > 0) {
        showToast(
          `${successCount} টি প্রোডাক্ট ও সাইজ ভ্যারিয়েশন সফলভাবে WordPress (WooCommerce)-এ ম্যাচ/তৈরি ও লিংক হয়েছে!`,
          'success'
        );
      } else {
        showToast('কোনো প্রোডাক্ট লিংক করা যায়নি। API পারমিশন চেক করুন।', 'error');
      }
    } finally {
      setIsSyncingAllProducts(false);
    }
  };

  const previewEndpoint = `${
    normalizeWpSiteUrl(wpSiteUrl) || 'https://your-wordpress-site.com'
  }/wp-json/wc/v3/orders`;

  const linkedProductsCount = products.filter(p => p.wpProductId && p.wpProductId > 0).length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white p-6 rounded-2xl shadow-md border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-sky-500/20 border border-sky-400/30 text-sky-300 text-[11px] font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>WordPress (WooCommerce REST API v3) রিয়েল-টাইম অর্ডার ও প্রোডাক্ট ব্রিজ</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              ফ্রন্ট ওয়েবসাইটের অর্ডার ও প্রোডাক্ট অটোমেটিক আপনার WordPress ওয়েবসাইটে যুক্ত করুন
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              কাস্টমার এই ফ্রন্ট ওয়েবসাইটে অর্ডার কনফার্ম করার সাথে সাথেই আপনার{' '}
              <strong className="text-white">WordPress (WooCommerce)</strong> ওয়েবসাইটের{' '}
              <code className="text-sky-300 font-mono">WooCommerce → Orders</code> সেকশনে{' '}
              <strong className="text-emerald-300">আসল WooCommerce Product (Line Items)</strong>, সাইজ/ভেরিয়েশন, কাস্টমারের নাম, মোবাইল নম্বর ও ঠিকানাসহ অর্ডার তৈরি হয়ে যাবে।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              disabled={isTestingConnection}
              onClick={handleTestConnection}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 disabled:opacity-60 text-white border border-white/20 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 text-sky-300 ${isTestingConnection ? 'animate-spin' : ''}`} />
              <span>{isTestingConnection ? 'চেক হচ্ছে...' : 'কানেকশন চেক করুন'}</span>
            </button>

            <button
              type="button"
              disabled={isSendingTestOrder}
              onClick={handleSendTestOrder}
              className="px-4 py-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-slate-950 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{isSendingTestOrder ? 'পাঠানো হচ্ছে...' : 'প্রোডাক্টসহ টেস্ট অর্ডার পাঠান'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Step-by-Step Guide: What is needed from WordPress */}
      <div className="bg-sky-50/70 rounded-2xl border border-sky-200 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-sky-700 shrink-0" />
          <h2 className="text-sm font-extrabold text-sky-950">
            WordPress অর্ডারে প্রোডাক্ট যুক্ত হওয়ার ৪-স্তরের স্মার্ট সিস্টেম:
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-white p-3.5 rounded-xl border border-sky-200/80 space-y-1">
            <span className="inline-block px-2 py-0.5 rounded bg-sky-100 text-sky-900 font-extrabold text-[11px]">
              ১. প্রোডাক্ট অটো-ম্যাচ (ID / SKU / Name)
            </span>
            <p className="text-slate-600 leading-relaxed pt-1">
              অর্ডার যাওয়ার সময় সিস্টেম প্রথমে <strong>WP Product ID</strong>, এরপর <strong>SKU কোড</strong> এবং <strong>পণ্যের নাম</strong> দিয়ে আপনার ওয়ার্ডপ্রেস সাইটের প্রোডাক্ট খুঁজে সরাসরি <code className="font-mono font-bold text-slate-900">line_items</code>-এ যুক্ত করে।
            </p>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-sky-200/80 space-y-1">
            <span className="inline-block px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-extrabold text-[11px]">
              ২. অটো প্রোডাক্ট তৈরি (Auto-Create)
            </span>
            <p className="text-slate-600 leading-relaxed pt-1">
              যদি কোনো পণ্য আপনার ওয়ার্ডপ্রেস সাইটে আগে থেকে না থাকে, তবে অর্ডার যাওয়ার সময় সিস্টেম স্বয়ংক্রিয়ভাবে ওয়ার্ডপ্রেসে পণ্যটি তৈরি করে সেই প্রোডাক্টটি অর্ডারে অ্যাসাইন করে দেয়!
            </p>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-sky-200/80 space-y-1">
            <span className="inline-block px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-extrabold text-[11px]">
              ৩. ১-ক্লিক প্রোডাক্ট ম্যাপিং টুল
            </span>
            <p className="text-slate-600 leading-relaxed pt-1">
              নিচের <strong>&ldquo;WordPress প্রোডাক্ট অটো-ম্যাচ ও লিংকিং&rdquo;</strong> সেকশন থেকে আপনি ১ ক্লিকে ওয়ার্ডপ্রেসের যেকোনো নির্দিষ্ট প্রোডাক্ট আইডি ম্যাপ করে দিতে পারবেন।
            </p>
          </div>
        </div>
      </div>

      {/* Main Configuration Form */}
      <form
        onSubmit={handleSaveSettings}
        className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-2xs space-y-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 border border-sky-200 flex items-center justify-center shrink-0">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                WordPress (WooCommerce) REST API কানেকশন সেটিংস
              </h2>
              <p className="text-xs text-slate-500">
                {currentUser.role === 'developer'
                  ? 'এই সেটিংস ডাটাবেজে ও cPanel-এ স্থায়ীভাবে সেভ থাকবে'
                  : 'এই সেটিংস আপনার ক্লাউড ডাটাবেজে স্থায়ীভাবে সেভ থাকবে'}
              </p>
            </div>
          </div>

          <label className="inline-flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-emerald-50 border border-emerald-200 cursor-pointer">
            <input
              type="checkbox"
              checked={wpSyncEnabled}
              onChange={(e) => setWpSyncEnabled(e.target.checked)}
              className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
            />
            <span className="text-xs font-extrabold text-emerald-950">
              অটোমেটিক WordPress অর্ডার সিঙ্ক চালু (Active)
            </span>
          </label>
        </div>

        {connectionResult && (
          <div
            className={`p-3.5 rounded-xl border flex items-start gap-2.5 text-xs ${
              connectionResult.ok
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            {connectionResult.ok ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            )}
            <div className="font-bold">{connectionResult.message}</div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="md:col-span-2">
            <label className="block font-extrabold text-slate-800 mb-1">
              ১. আপনার WordPress ওয়েবসাইটের URL (Site Address) *
            </label>
            <input
              type="text"
              value={wpSiteUrl}
              onChange={(e) => setWpSiteUrl(e.target.value)}
              placeholder="https://yourfashionwebsite.com"
              className="w-full min-h-[44px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
            />
            <div className="flex flex-wrap items-center justify-between gap-2 mt-1.5 text-[11px] text-slate-500">
              <span>
                টার্গেট REST API Endpoint:{' '}
                <code className="font-mono text-sky-800 bg-sky-50 px-1.5 py-0.5 rounded">
                  {previewEndpoint}
                </code>
              </span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(previewEndpoint);
                  setCopiedEndpoint(true);
                  setTimeout(() => setCopiedEndpoint(false), 2000);
                }}
                className="inline-flex items-center gap-1 text-sky-700 hover:underline font-bold cursor-pointer"
              >
                {copiedEndpoint ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copiedEndpoint ? 'কপি হয়েছে' : 'Endpoint কপি'}</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block font-extrabold text-slate-800 mb-1">
              ২. WooCommerce Consumer Key (<code className="text-sky-700">ck_...</code>) *
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={wpConsumerKey}
                onChange={(e) => setWpConsumerKey(e.target.value)}
                placeholder="ck_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                className="w-full min-h-[44px] pl-10 pr-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              WooCommerce → Settings → Advanced → REST API থেকে প্রাপ্ত Consumer key (Permission: Read/Write)
            </p>
          </div>

          <div>
            <label className="block font-extrabold text-slate-800 mb-1">
              ৩. WooCommerce Consumer Secret (<code className="text-sky-700">cs_...</code>) *
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="password"
                value={wpConsumerSecret}
                onChange={(e) => setWpConsumerSecret(e.target.value)}
                placeholder="cs_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                className="w-full min-h-[44px] pl-10 pr-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-mono text-slate-900 outline-hidden"
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              WooCommerce REST API থেকে প্রাপ্ত গোপন Consumer secret
            </p>
          </div>

          <div>
            <label className="block font-extrabold text-slate-800 mb-1">
              ৪. WordPress-এ নতুন অর্ডার কোন স্ট্যাটাসে তৈরি হবে?
            </label>
            <select
              value={wpDefaultOrderStatus}
              onChange={(e) => setWpDefaultOrderStatus(e.target.value as any)}
              className="w-full min-h-[44px] px-3.5 py-2 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-xl font-bold text-slate-900 outline-hidden"
            >
              <option value="processing">Processing (প্রসেসিং - ডিফল্ট ও রেকমেন্ডেড)</option>
              <option value="pending">Pending Payment (পেন্ডিং)</option>
              <option value="on-hold">On Hold (অন-হোল্ড)</option>
              <option value="completed">Completed (কমপ্লিটেড)</option>
            </select>
          </div>

          <div className="flex items-center pt-5">
            <label className="inline-flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 w-full cursor-pointer">
              <input
                type="checkbox"
                checked={wpSyncIncludeDeliveryFee}
                onChange={(e) => setWpSyncIncludeDeliveryFee(e.target.checked)}
                className="w-4 h-4 accent-sky-600 rounded cursor-pointer"
              />
              <div>
                <span className="font-bold text-slate-800 block">
                  ডেলিভারি চার্জ (Shipping Line) অর্ডারের সাথে যুক্ত করুন
                </span>
                <span className="text-[10px] text-slate-500 block">
                  অর্ডার বিলের ডেলিভারি চার্জ ওয়ার্ডপ্রেস অর্ডারের Shipping হিসেবে যোগ হবে
                </span>
              </div>
            </label>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <p className="text-[11px] text-slate-500">
            নোট: প্রতিটি অর্ডারের সাথে প্রোডাক্ট অটোমেটিক <code className="font-mono font-bold text-slate-800">line_items</code> হিসেবে যুক্ত হবে।
          </p>
          <button
            type="submit"
            className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs sm:text-sm rounded-xl inline-flex items-center gap-2 shadow-xs cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>WordPress কনফিগারেশন সেভ করুন</span>
          </button>
        </div>
      </form>

      {/* WordPress Product Auto-Match & Product ID Mapping Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <PackageCheck className="w-5 h-5 text-emerald-700" />
              <h2 className="text-base font-extrabold text-slate-900">
                WordPress প্রোডাক্ট অটো-ম্যাচিং ও আইডি লিংকিং ({linkedProductsCount}/{products.length} লিংকড)
              </h2>
            </div>
            <p className="text-xs text-slate-500">
              ওয়ার্ডপ্রেস অর্ডারে ১০০% সঠিক প্রোডাক্ট অ্যাসাইন করার জন্য নিচের বাটনে ক্লিক করে ওয়ার্ডপ্রেসের প্রোডাক্টের সাথে অটো-ম্যাচ করুন অথবা সরাসরি <strong>WP Product ID</strong> বসিয়ে দিন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleGenerateAllVariantSkus}
              className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>সব সাইজের অটো-SKU জেনারেট করুন</span>
            </button>

            <button
              type="button"
              disabled={isFetchingWpProducts}
              onClick={handleFetchAndAutoMatchWpProducts}
              className="px-3.5 py-2 bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-200 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isFetchingWpProducts ? 'animate-spin' : ''}`} />
              <span>
                {isFetchingWpProducts
                  ? 'লোড হচ্ছে...'
                  : 'WordPress থেকে প্রোডাক্ট লোড ও অটো-ম্যাচ করুন'}
              </span>
            </button>

            <button
              type="button"
              disabled={isSyncingAllProducts}
              onClick={handleSyncAllProductsToWp}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-60"
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>
                {isSyncingAllProducts
                  ? 'সিঙ্ক হচ্ছে...'
                  : 'সব প্রোডাক্ট ও সাইজ WordPress-এ সিঙ্ক করুন'}
              </span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <th className="py-2.5 px-3 font-extrabold">আমাদের ওয়েবসাইটের প্রোডাক্ট ও সাইজ ভ্যারিয়েশন SKU</th>
                <th className="py-2.5 px-3 font-extrabold">মূল SKU কোড</th>
                <th className="py-2.5 px-3 font-extrabold">মূল্য</th>
                <th className="py-2.5 px-3 font-extrabold">WordPress Product ID (ম্যাপ করুন)</th>
                <th className="py-2.5 px-3 font-extrabold text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {products.map((prod) => (
                <tr key={prod.id} className="hover:bg-slate-50/70 align-top">
                  <td className="py-2.5 px-3">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-bold text-slate-900">{prod.nameBn}</span>
                      {prod.isLandingPageProduct && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                          Landing Page
                        </span>
                      )}
                    </div>
                    {prod.variants && prod.variants.length > 0 && (
                      <div className="mt-2 space-y-1.5 bg-sky-50/60 p-2.5 rounded-xl border border-sky-200/80">
                        <div className="text-[10px] font-extrabold text-sky-900">
                          সাইজ ভ্যারিয়েশন SKU ও WordPress Variation ID (প্রয়োজনে এডিট করুন):
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {prod.variants.map((v, vIdx) => {
                            const effectiveVarSku =
                              v.sku || buildVariantSkuCode(prod.sku, v.label, vIdx);
                            return (
                              <div
                                key={v.id}
                                className="inline-flex flex-wrap items-center gap-1.5 bg-white px-2 py-1 rounded-lg border border-slate-200 text-[11px]"
                              >
                                <span className="font-extrabold text-slate-800">{v.label}:</span>
                                <input
                                  type="text"
                                  value={effectiveVarSku}
                                  onChange={(e) => {
                                    const newSku = e.target.value;
                                    const nextVars = (prod.variants || []).map(item =>
                                      item.id === v.id ? { ...item, sku: newSku } : item
                                    );
                                    updateProduct(prod.id, { variants: nextVars });
                                  }}
                                  placeholder="Var SKU"
                                  className="w-28 px-1.5 py-0.5 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded font-mono text-[10px] text-sky-900 outline-hidden"
                                  title="এই সাইজের WordPress Variation SKU"
                                />
                                <input
                                  type="number"
                                  min="0"
                                  value={v.wpVariationId || ''}
                                  onChange={(e) => {
                                    const parsed = parseInt(e.target.value, 10);
                                    const nextVars = (prod.variants || []).map(item =>
                                      item.id === v.id
                                        ? {
                                            ...item,
                                            wpVariationId:
                                              !Number.isNaN(parsed) && parsed > 0 ? parsed : undefined
                                          }
                                        : item
                                    );
                                    updateProduct(prod.id, { variants: nextVars });
                                  }}
                                  placeholder="Var ID (অটো)"
                                  className="w-20 px-1.5 py-0.5 bg-emerald-50/60 border border-emerald-300 focus:border-emerald-600 focus:bg-white rounded font-mono text-[10px] text-emerald-900 outline-hidden"
                                  title="WordPress Variation ID (ঐচ্ছিক - অটো সিঙ্ক বা ম্যানুয়ালি দিন)"
                                />
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-700">{prod.sku}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-emerald-700">
                    {formatCurrency(prod.retailPrice)}
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        value={prod.wpProductId || ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value, 10);
                          updateProduct(prod.id, {
                            wpProductId: !Number.isNaN(val) && val > 0 ? val : undefined
                          });
                        }}
                        placeholder="WP ID (অটো)"
                        className="w-28 px-2.5 py-1.5 bg-slate-50 border border-slate-300 focus:border-sky-600 focus:bg-white rounded-lg font-mono text-xs text-slate-900 outline-hidden"
                      />

                      {remoteWpProducts.length > 0 && (
                        <select
                          value={prod.wpProductId || ''}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10);
                            updateProduct(prod.id, {
                              wpProductId: !Number.isNaN(val) && val > 0 ? val : undefined
                            });
                          }}
                          className="max-w-[210px] px-2 py-1.5 bg-sky-50/70 border border-sky-200 rounded-lg text-[11px] font-medium text-slate-800 outline-hidden"
                        >
                          <option value="">-- WordPress প্রোডাক্ট বাছুন --</option>
                          {remoteWpProducts.map(rp => (
                            <option key={rp.id} value={rp.id}>
                              #{rp.id} - {rp.name} {rp.sku ? `(${rp.sku})` : ''}
                            </option>
                          ))}
                        </select>
                      )}

                      {prod.wpProductId && prod.wpProductId > 0 ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-mono font-bold text-[10px]">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>WP #{prod.wpProductId}</span>
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400">
                          অর্ডারের সময় অটো-ম্যাচ হবে
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      type="button"
                      disabled={syncingProductId === prod.id}
                      onClick={() => handleSyncSingleProduct(prod)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold text-[11px] inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Link2 className="w-3 h-3" />
                      <span>
                        {syncingProductId === prod.id ? 'লিংক হচ্ছে...' : 'WP-তে সাইজসহ লিংক'}
                      </span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Sync for Recent Storefront Orders + Live Sync Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Existing Online Orders Quick Push */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-3.5">
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-emerald-700" />
              <h3 className="text-sm font-extrabold text-slate-900">
                ওয়েবসাইটের অর্ডার ম্যানুয়ালি WordPress-এ পাঠান
              </h3>
            </div>
            <span className="text-[11px] font-bold text-slate-500">
              মোট {onlineOrders.length} টি অর্ডার
            </span>
          </div>

          <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
            {onlineOrders.slice(0, 12).map(ord => {
              const matchedLog = syncLogs.find(l => l.localOrderNo === ord.orderNo);
              return (
                <div
                  key={ord.id}
                  className="p-3 rounded-xl border border-slate-200/80 bg-slate-50/60 flex items-center justify-between gap-2 text-xs"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-extrabold text-emerald-800">
                        {ord.orderNo}
                      </span>
                      <span className="font-mono font-bold text-slate-900">
                        {formatCurrency(ord.grandTotal)}
                      </span>
                      {matchedLog?.status === 'success' && (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                          WP #{matchedLog.wpOrderId}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-600 truncate mt-0.5">
                      {ord.customerName} · {ord.customerPhone}
                    </p>
                  </div>

                  <button
                    type="button"
                    disabled={syncingOrderId === ord.id}
                    onClick={() => handleManualSyncExistingOrder(ord.id)}
                    className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold text-[11px] inline-flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    <Send className="w-3 h-3" />
                    <span>{syncingOrderId === ord.id ? 'যাচ্ছে...' : 'WP-তে পাঠান'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Sync History Logs */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-3.5">
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900">
                WordPress অর্ডার সিঙ্ক লগ (Live Sync Status)
              </h3>
              <p className="text-[11px] text-slate-500">
                ফ্রন্ট ওয়েবসাইট থেকে ওয়ার্ডপ্রেসে পাঠানো অর্ডারের রিয়েল-টাইম রিপোর্ট
              </p>
            </div>
            {syncLogs.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  clearWordPressSyncLogs();
                  setSyncLogs([]);
                }}
                className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-[11px] inline-flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>লগ পরিষ্কার</span>
              </button>
            )}
          </div>

          {syncLogs.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              এখনও কোনো অর্ডার সিঙ্ক লগ নেই। উপরের &ldquo;প্রোডাক্টসহ টেস্ট অর্ডার পাঠান&rdquo; বাটনে ক্লিক করে এখনই পরীক্ষা করুন।
            </div>
          ) : (
            <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
              {syncLogs.map(log => (
                <div
                  key={log.id}
                  className={`p-3 rounded-xl border text-xs flex flex-wrap items-center justify-between gap-2 ${
                    log.status === 'success'
                      ? 'bg-emerald-50/60 border-emerald-200'
                      : 'bg-rose-50/60 border-rose-200'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-extrabold text-slate-900">
                        {log.localOrderNo}
                      </span>
                      {log.wpOrderId && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white font-mono font-bold text-[10px] inline-flex items-center gap-1">
                          <span>WooCommerce Order #{log.wpOrderId}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </span>
                      )}
                      <span className="text-[11px] text-slate-500">
                        {log.customerName} ({log.customerPhone})
                      </span>
                    </div>
                    <p
                      className={`text-[11px] font-medium ${
                        log.status === 'success' ? 'text-emerald-800' : 'text-rose-700'
                      }`}
                    >
                      {log.message}
                    </p>
                  </div>

                  <span className="text-[10px] font-mono text-slate-400">
                    {new Date(log.syncedAt).toLocaleTimeString('bn-BD')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
