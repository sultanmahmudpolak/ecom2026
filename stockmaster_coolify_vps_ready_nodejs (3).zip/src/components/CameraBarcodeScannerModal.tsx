import React, { useEffect, useRef, useState } from 'react';
import { Product } from '../types';
import {
  Camera,
  X,
  RefreshCw,
  Flashlight,
  Barcode,
  CheckCircle2,
  AlertCircle,
  Volume2
} from 'lucide-react';

interface CameraBarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDetected: (barcodeOrSku: string) => void;
  products?: Product[];
  title?: string;
  continuousModeDefault?: boolean;
}

// Play a crisp supermarket POS laser beep using Web Audio API
const playPosScannerBeep = () => {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1850, ctx.currentTime);
    gain.gain.setValueAtTime(0.18, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.12);
  } catch {
    // Ignore audio context restriction
  }
};

export const CameraBarcodeScannerModal: React.FC<CameraBarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onDetected,
  products = [],
  title = 'মোবাইল ক্যামেরা বারকোড স্ক্যানার (Live Camera Barcode Scanner)',
  continuousModeDefault = false
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const lastScannedCodeRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraStatus, setCameraStatus] = useState<'starting' | 'active' | 'error'>('starting');
  const [cameraErrorMsg, setCameraErrorMsg] = useState<string>('');
  const [isNativeDetectorSupported, setIsNativeDetectorSupported] = useState<boolean>(true);
  const [torchSupported, setTorchSupported] = useState<boolean>(false);
  const [torchOn, setTorchOn] = useState<boolean>(false);
  const [continuousMode, setContinuousMode] = useState<boolean>(continuousModeDefault);
  const [lastScannedBanner, setLastScannedBanner] = useState<string>('');
  const [manualCode, setManualCode] = useState<string>('');

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        try {
          track.stop();
        } catch {
          // Ignore
        }
      });
      streamRef.current = null;
    }
  };

  const handleTriggerScan = (rawCode: string) => {
    const clean = rawCode.trim();
    if (!clean) return;

    playPosScannerBeep();
    const matchedProd = products.find(
      p => p.barcode === clean || p.sku.toLowerCase() === clean.toLowerCase()
    );
    setLastScannedBanner(
      matchedProd ? `স্ক্যান সফল: ${matchedProd.nameBn} (${clean})` : `বারকোড স্ক্যান হয়েছে: ${clean}`
    );
    onDetected(clean);

    if (!continuousMode) {
      stopCameraStream();
      onClose();
    }
  };

  useEffect(() => {
    if (!isOpen) {
      stopCameraStream();
      return;
    }

    let cancelled = false;
    let scanInterval: number | undefined;

    const startCameraAndDetector = async () => {
      setCameraStatus('starting');
      setCameraErrorMsg('');
      setTorchSupported(false);
      setTorchOn(false);
      stopCameraStream();

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraStatus('error');
        setCameraErrorMsg(
          'আপনার ব্রাউজারে ক্যামেরা পারমিশন পাওয়া যায়নি (HTTPS অথবা আধুনিক মোবাইল ব্রাউজার ব্যবহার করুন)। নিচে কুইক বারকোড বা ম্যানুয়াল ইনপুট ব্যবহার করতে পারেন।'
        );
        return;
      }

      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 }
          },
          audio: false
        });

        if (cancelled) {
          mediaStream.getTracks().forEach(t => t.stop());
          return;
        }

        streamRef.current = mediaStream;

        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          await videoRef.current.play().catch(() => {});
        }

        // Check if torch / flashlight is supported on mobile back camera
        const videoTrack = mediaStream.getVideoTracks()[0];
        if (videoTrack && typeof videoTrack.getCapabilities === 'function') {
          const caps = videoTrack.getCapabilities() as Record<string, unknown>;
          if (caps && caps.torch) {
            setTorchSupported(true);
          }
        }

        setCameraStatus('active');

        // Check for native HTML5 BarcodeDetector API (Chrome Android / Edge / WebView)
        const BarcodeDetectorClass = (window as unknown as { BarcodeDetector?: any }).BarcodeDetector;
        if (BarcodeDetectorClass) {
          setIsNativeDetectorSupported(true);
          let detector: any = null;
          try {
            detector = new BarcodeDetectorClass({
              formats: [
                'ean_13',
                'ean_8',
                'code_128',
                'code_39',
                'upc_a',
                'upc_e',
                'qr_code',
                'itf',
                'codabar'
              ]
            });
          } catch {
            detector = new BarcodeDetectorClass();
          }

          scanInterval = window.setInterval(async () => {
            if (cancelled || !videoRef.current || videoRef.current.readyState < 2 || !detector) {
              return;
            }
            try {
              const barcodes = await detector.detect(videoRef.current);
              if (Array.isArray(barcodes) && barcodes.length > 0) {
                const rawValue = String(barcodes[0]?.rawValue || '').trim();
                if (rawValue) {
                  const now = Date.now();
                  // Debounce duplicate scans of the same barcode within 1.8 seconds
                  if (
                    lastScannedCodeRef.current.code === rawValue &&
                    now - lastScannedCodeRef.current.time < 1800
                  ) {
                    return;
                  }
                  lastScannedCodeRef.current = { code: rawValue, time: now };
                  handleTriggerScan(rawValue);
                }
              }
            } catch {
              // Ignore frame detection error
            }
          }, 260);
        } else {
          setIsNativeDetectorSupported(false);
        }
      } catch (err: any) {
        if (!cancelled) {
          setCameraStatus('error');
          setCameraErrorMsg(
            err?.name === 'NotAllowedError'
              ? 'ক্যামেরা পারমিশন ব্লক করা আছে। অনুগ্রহ করে ব্রাউজারের অ্যাড্রেস বার থেকে Camera Allow করুন।'
              : 'ক্যামেরা চালু করা যায়নি। নিচে থেকে বারকোড সিলেক্ট বা টাইপ করুন।'
          );
        }
      }
    };

    startCameraAndDetector();

    return () => {
      cancelled = true;
      if (scanInterval) window.clearInterval(scanInterval);
      stopCameraStream();
    };
  }, [isOpen, facingMode, continuousMode]);

  const toggleTorch = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    if (!track) return;
    try {
      const next = !torchOn;
      await track.applyConstraints({
        advanced: [{ torch: next } as any]
      });
      setTorchOn(next);
    } catch {
      // Ignore if device rejects torch constraint
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-4">
        {/* Header */}
        <div className="px-4 py-3.5 bg-[#0f172a] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shrink-0">
              <Camera className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-xs sm:text-sm truncate">{title}</h3>
              <p className="text-[10px] text-slate-300">
                মোবাইল ক্যামেরার সামনে পণ্যের বারকোড ধরলে অটোমেটিক স্ক্যান হবে
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopCameraStream();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Camera Viewfinder */}
        <div className="p-4 space-y-3.5 text-xs">
          <div className="relative aspect-video w-full rounded-xl bg-slate-950 overflow-hidden border-2 border-slate-800 flex items-center justify-center">
            <video
              ref={videoRef}
              playsInline
              muted
              autoPlay
              className={`w-full h-full object-cover ${cameraStatus === 'active' ? 'block' : 'hidden'}`}
            />

            {/* Laser Targeting Reticle Overlay */}
            {cameraStatus === 'active' && (
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-6">
                <div className="w-full max-w-[260px] h-32 border-2 border-emerald-400/90 rounded-xl relative shadow-[0_0_0_9999px_rgba(2,6,23,0.45)]">
                  {/* Corner Brackets */}
                  <div className="absolute -top-0.5 -left-0.5 w-5 h-5 border-t-4 border-l-4 border-amber-400 rounded-tl-md" />
                  <div className="absolute -top-0.5 -right-0.5 w-5 h-5 border-t-4 border-r-4 border-amber-400 rounded-tr-md" />
                  <div className="absolute -bottom-0.5 -left-0.5 w-5 h-5 border-b-4 border-l-4 border-amber-400 rounded-bl-md" />
                  <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 border-b-4 border-r-4 border-amber-400 rounded-br-md" />

                  {/* Animated Laser Line */}
                  <div className="absolute left-2 right-2 top-1/2 h-0.5 bg-rose-500 shadow-[0_0_10px_#f43f5e] animate-pulse" />
                </div>
                <span className="mt-2.5 px-2.5 py-0.5 rounded bg-slate-950/80 text-emerald-300 text-[10px] font-semibold">
                  বক্সের ভেতরে বারকোড বা QR কোড ধরুন
                </span>
              </div>
            )}

            {cameraStatus === 'starting' && (
              <div className="text-center text-slate-300 p-6 space-y-2">
                <RefreshCw className="w-7 h-7 animate-spin text-emerald-400 mx-auto" />
                <p className="text-xs font-semibold">মোবাইল ক্যামেরা চালু হচ্ছে...</p>
                <p className="text-[11px] text-slate-400">ব্রাউজার পারমিশন চাইলে "Allow" ক্লিক করুন</p>
              </div>
            )}

            {cameraStatus === 'error' && (
              <div className="text-center text-rose-200 p-5 space-y-2 max-w-sm">
                <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
                <p className="text-xs font-bold text-white">ক্যামেরা সংযোগ পাওয়া যায়নি</p>
                <p className="text-[11px] text-slate-300 leading-relaxed">{cameraErrorMsg}</p>
              </div>
            )}

            {/* Floating Camera Controls (Switch Front/Back + Torch) */}
            {cameraStatus === 'active' && (
              <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5">
                {torchSupported && (
                  <button
                    type="button"
                    onClick={toggleTorch}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center gap-1 shadow-md cursor-pointer ${
                      torchOn
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-slate-900/85 text-white hover:bg-slate-900'
                    }`}
                  >
                    <Flashlight className="w-3.5 h-3.5" />
                    <span>ফ্ল্যাশ</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() =>
                    setFacingMode(prev => (prev === 'environment' ? 'user' : 'environment'))
                  }
                  className="px-2.5 py-1.5 rounded-lg bg-slate-900/85 hover:bg-slate-900 text-white text-[11px] font-bold flex items-center gap-1 shadow-md cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{facingMode === 'environment' ? 'ব্যাক ক্যামেরা' : 'ফ্রন্ট ক্যামেরা'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Continuous Mode & Audio Indicator */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
            <label className="flex items-center gap-2 font-semibold text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={continuousMode}
                onChange={(e) => setContinuousMode(e.target.checked)}
                className="rounded text-emerald-700"
              />
              <span>একটানা একাধিক পণ্য স্ক্যান মোড (Continuous Scan)</span>
            </label>

            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-semibold">
              <Volume2 className="w-3.5 h-3.5" />
              <span>বিপ সাউন্ড চালু</span>
            </span>
          </div>

          {/* Last Scanned Confirmation Banner */}
          {lastScannedBanner && (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="truncate">{lastScannedBanner}</span>
            </div>
          )}

          {!isNativeDetectorSupported && cameraStatus === 'active' && (
            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
              টিপস: মোবাইল অটো-বারকোড ডিটেকশনের জন্য Android Chrome বা Edge ব্রাউজার ব্যবহার করুন, অথবা নিচের তালিকা থেকে ১-ক্লিকে বারকোড স্ক্যান করুন।
            </div>
          )}

          {/* Manual Barcode Input Fallback */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!manualCode.trim()) return;
              handleTriggerScan(manualCode);
              setManualCode('');
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Barcode className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="অথবা বারকোড / SKU নম্বর লিখে এন্টার দিন..."
                className="w-full min-h-[38px] pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs outline-hidden focus:border-emerald-600 focus:bg-white"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer shrink-0"
            >
              যোগ করুন
            </button>
          </form>

          {/* Quick-Tap Barcode Simulator for Instant Testing */}
          {products.length > 0 && (
            <div className="space-y-1.5 pt-1 border-t border-slate-200">
              <p className="text-[11px] font-bold text-slate-600">
                ⚡ ওয়ান-ট্যাপ টেস্ট বারকোড স্ক্যান (পণ্য ক্লিক করলেই স্ক্যান হবে):
              </p>
              <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto pr-1">
                {products.slice(0, 8).map(p => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleTriggerScan(p.barcode || p.sku)}
                    className="p-2 rounded-lg border border-slate-200 hover:border-emerald-600 hover:bg-emerald-50/60 text-left transition-colors cursor-pointer flex items-center justify-between gap-1.5"
                  >
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 truncate text-[11px]">{p.nameBn}</p>
                      <p className="font-mono text-[10px] text-slate-500 truncate">
                        {p.barcode || p.sku}
                      </p>
                    </div>
                    <span className="font-mono font-bold text-[11px] text-emerald-800 shrink-0">
                      ৳{p.retailPrice}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
