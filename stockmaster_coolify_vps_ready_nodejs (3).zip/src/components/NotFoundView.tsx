import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { StorefrontThemeStyle } from '../types';
import { ShoppingBag, ArrowRight, Home } from 'lucide-react';

interface NotFoundViewProps {
  onGoToStorefront: (targetUrl?: string) => void;
}

export const NotFoundView: React.FC<NotFoundViewProps> = ({ onGoToStorefront }) => {
  const { currentBusiness } = useApp();

  const isWinterTheme =
    Boolean(currentBusiness.winterThemeEnabled) ||
    currentBusiness.storefrontTheme === 'winter_frost';
  const activeStorefrontTheme: StorefrontThemeStyle = isWinterTheme
    ? 'winter_frost'
    : currentBusiness.storefrontTheme || 'emerald_default';

  const shopName = currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট';
  const effectiveLogo =
    currentBusiness.logoUrl && currentBusiness.logoUrl.trim() !== ''
      ? currentBusiness.logoUrl
      : '';

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.title = `দুঃখিত, পৃষ্ঠাটি খুঁজে পাওয়া যায়নি (404) | ${shopName}`;
    }
  }, [shopName]);

  const topAnnouncementEnabled = currentBusiness.topAnnouncementEnabled !== false;
  const topAnnouncementText = (
    currentBusiness.topAnnouncementText ||
    'সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে পেমেন্ট করুন'
  ).trim();

  return (
    <div
      className="storefront-font-scale-scope min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col antialiased"
      data-storefront-theme={activeStorefrontTheme}
    >
      {/* Top Theme Announcement Bar */}
      {topAnnouncementEnabled && topAnnouncementText !== '' && (
        <div className="sf-theme-topbar bg-gradient-to-r from-[#064E3B] via-[#047857] to-[#065F46] text-white border-b border-white/15 py-1.5 px-3 sm:px-6 text-center text-xs sm:text-[13px] font-extrabold tracking-wide truncate select-none">
          {topAnnouncementText}
        </div>
      )}

      {/* Simple Store Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-slate-200/80">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
          {effectiveLogo ? (
            <button
              type="button"
              onClick={() => onGoToStorefront('/')}
              className="flex items-center gap-2.5 text-left cursor-pointer group min-w-0"
              title={shopName}
            >
              <img
                src={effectiveLogo}
                alt={shopName}
                className="h-9 sm:h-10 w-auto max-w-[180px] sm:max-w-[220px] object-contain transition-opacity group-hover:opacity-90"
              />
            </button>
          ) : (
            <div />
          )}

          <button
            type="button"
            onClick={() => onGoToStorefront('/')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100/90 border border-emerald-200/80 text-emerald-800 text-xs sm:text-[13px] font-extrabold transition-colors cursor-pointer"
          >
            <Home className="w-3.5 h-3.5 text-emerald-700" />
            <span>মূল শপে যান</span>
          </button>
        </div>
      </header>

      {/* Clean & Simple Centered 404 Card */}
      <main className="flex-1 flex items-center justify-center px-4 py-10 sm:py-16">
        <div className="max-w-2xl w-full bg-white rounded-2xl border border-emerald-300/90 shadow-xs px-6 py-10 sm:px-12 sm:py-14 text-center animate-page-rise">
          {/* Status Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-extrabold mb-3">
            <span>পেজ বা লিংকটি পাওয়া যায়নি · 404 Error</span>
          </div>

          {/* Large 404 Number */}
          <div className="text-5xl sm:text-6xl font-black text-emerald-700 tracking-tight leading-none mb-4 select-none">
            ৪০৪
          </div>

          {/* Heading */}
          <h1 className="text-xl sm:text-2xl md:text-[26px] font-extrabold text-slate-900 leading-snug mb-3">
            দুঃখিত, পৃষ্ঠাটি খুঁজে পাওয়া যায়নি
          </h1>

          {/* Subtitle */}
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-lg mx-auto mb-7">
            লিংকটি ভুল অথবা পৃষ্ঠাটি সরিয়ে নেওয়া হয়েছে। হোমপেজে ফিরে যান অথবা আমাদের সব পণ্য দেখুন।
          </p>

          {/* Single Clean Primary Button */}
          <div className="flex items-center justify-center">
            <button
              type="button"
              onClick={() => onGoToStorefront('/')}
              className="sf-theme-topbar btn-soft-404-shine btn-soft-404-glow inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl text-white font-extrabold text-sm sm:text-base border border-white/25 cursor-pointer transition-transform active:scale-[0.99]"
            >
              <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
              <span>মূল শপে ফিরে যান</span>
              <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
