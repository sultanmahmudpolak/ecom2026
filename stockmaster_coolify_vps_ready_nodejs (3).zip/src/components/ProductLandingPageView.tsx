import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp, normalizeBdPhone, isValidBdPhone11 } from '../context/AppContext';
import {
  Product,
  ProductVariant,
  OnlineOrder,
  SaleItem,
  LandingReviewItem,
  LandingTrustItem,
  LandingSizeChartRow,
  SpinWheelLead,
  SpinWheelSliceConfig,
  SpinWheelConfig,
  LandingFloatingBtnAnimation,
  LandingVariantDesign,
  LandingImageBadgeDesign,
  StockOutBadgeDesign,
  OrderCelebrationStyle,
  LandingShowcaseProductItem,
  DailyOrderLimitCheckResult
} from '../types';
import { OrderCelebrationOverlay } from './OrderCelebrationOverlay';

export const LANDING_VARIANT_DESIGN_OPTIONS: {
  id: LandingVariantDesign;
  label: string;
  shortLabel: string;
  desc: string;
}[] = [
  {
    id: 'classic_radio_list',
    label: '১. ক্লাসিক লিস্ট (বর্তমান ডিজাইন)',
    shortLabel: '১. ক্লাসিক লিস্ট',
    desc: 'একটির নিচে একটি ফুল-উইডথ রেডিও লিস্ট (ডিফল্ট)'
  },
  {
    id: 'mobile_grid_chips',
    label: '২. মোবাইল ২-কলাম স্মার্ট গ্রিড (Mobile Grid)',
    shortLabel: '২. মোবাইল গ্রিড',
    desc: 'মোবাইলে পাশাপাশি ২-৩টি বক্স আকারে সাইজ দেখাবে (স্ক্রল কম লাগে)'
  },
  {
    id: 'pill_capsules',
    label: '৩. মডার্ন ক্যাপসুল বাটন (Pill Capsules)',
    shortLabel: '৩. ক্যাপসুল বাটন',
    desc: 'স্মার্টফোনে এক আঙুলে দ্রুত সিলেক্ট করার জন্য রাউন্ড ক্যাপসুল বাটন'
  },
  {
    id: 'stacked_offer_cards',
    label: '৪. প্রিমিয়াম অফার কার্ড (Offer Cards)',
    shortLabel: '৪. অফার কার্ড',
    desc: 'প্রিমিয়াম বর্ডার ও ব্যাজসহ আকর্ষণীয় ভ্যারিয়েশন কার্ড ডিজাইন'
  },
  {
    id: 'royal_crimson_tabs',
    label: '৫. বোল্ড রেড-গোল্ড শপ স্টাইল (Crimson Box)',
    shortLabel: '৫. রেড-গোল্ড বক্স',
    desc: 'বাংলাদেশি হাই-কনভার্টিং শপের মতো গাঢ় লাল ও গোল্ডেন সিলেকশন বক্স'
  },
  {
    id: 'compact_segmented_bar',
    label: '৬. স্লিক কম্প্যাক্ট বাটন বার (Compact Touch)',
    shortLabel: '৬. কম্প্যাক্ট বার',
    desc: 'অ্যাপলের মতো স্লিক সেগমেন্টেড টাচ বার (মোবাইলে অত্যন্ত পরিপাটি)'
  },
  {
    id: 'royal_crimson_clean',
    label: '৭. রেড-গোল্ড ক্লিন বক্স (Selected লেখা ছাড়া)',
    shortLabel: '৭. রেড-গোল্ড ক্লিন',
    desc: '৫ নাম্বারের মতোই আকর্ষণীয় রেড-গোল্ড বক্স, কিন্তু উপরে Selected লেখা ছাড়া'
  },
  {
    id: 'royal_luxury_gift',
    label: '৮. স্পেশাল গিফট: রয়্যাল ডার্ক-গোল্ড ভিআইপি (Gift Edition 🎁)',
    shortLabel: '৮. রয়্যাল গিফট ভিআইপি 🎁',
    desc: 'ব্ল্যাক-এমেরাল্ড ও রয়্যাল গোল্ড কর্নার ব্যাজসহ প্রিমিয়াম বুটিক স্টাইল'
  },
  {
    id: 'lp2_red_measurement_grid',
    label: '৯. রেড মাপ বক্স — বুক ও লম্বা মাপসহ (LP-2 ডিফল্ট)',
    shortLabel: '৯. রেড মাপ বক্স (LP-2)',
    desc: 'উপরে লাল টিক চিহ্ন এবং নিচে বুক ও লম্বা সাইজ মাপসহ রেসপনসিভ কার্ড'
  }
];

export const LANDING_IMAGE_BADGE_DESIGN_OPTIONS: {
  id: LandingImageBadgeDesign;
  label: string;
  shortLabel: string;
  desc: string;
}[] = [
  {
    id: 'classic_red',
    label: '১. ক্লাসিক রেড ব্যাজ (বর্তমান ডিজাইন)',
    shortLabel: '১. ক্লাসিক রেড',
    desc: 'গাঢ় লাল বক্সে "% ছাড় (সাশ্রয় ৳...)" — ডিফল্ট ডিজাইন'
  },
  {
    id: 'crimson_gold',
    label: '২. রেড-গোল্ড ভিআইপি রিবন (Red-Gold VIP)',
    shortLabel: '২. রেড-গোল্ড রিবন',
    desc: 'গাঢ় লাল ও গোল্ডেন বর্ডারের প্রিমিয়াম ডিসকাউন্ট রিবন'
  },
  {
    id: 'circle_seal',
    label: '৩. রাউন্ড সার্কেল স্টিকার (Circle Sticker)',
    shortLabel: '৩. রাউন্ড স্টিকার',
    desc: 'ছবির কোণায় গোল স্টিকার আকারে বড় করে "% ছাড়" দেখাবে'
  },
  {
    id: 'royal_dark_gold',
    label: '৪. রয়্যাল ব্ল্যাক-গোল্ড লাক্সারি (Royal Dark Gold)',
    shortLabel: '৪. ব্ল্যাক-গোল্ড',
    desc: 'কালো ও সোনালি রঙের লাক্সারি বুটিক ডিসকাউন্ট ব্যাজ'
  },
  {
    id: 'emerald_flash',
    label: '৫. এমেরাল্ড ফ্ল্যাশ ক্যাপসুল (Emerald Flash)',
    shortLabel: '৫. এমেরাল্ড ক্যাপসুল',
    desc: 'সবুজ গ্রেডিয়েন্ট রাউন্ড ক্যাপসুল ডিসকাউন্ট ব্যাজ'
  },
  {
    id: 'minimal_percent',
    label: '৬. মিনিমাল শর্ট ব্যাজ — শুধু % ছাড় (Minimal %)',
    shortLabel: '৬. শুধু % ছাড়',
    desc: 'ছোট ও ক্লিন ব্যাজ (শুধু "-২০% ছাড়" লেখা থাকবে, ছবি বেশি দেখা যাবে)'
  }
];
import { ProductThumbnail, processUploadedProductImage } from './ProductThumbnail';
import { LazyImage } from './LazyImage';
import { ProductSeoHelmet } from './ProductSeoHelmet';
import {
  ShoppingBag,
  Search,
  Plus,
  Minus,
  Truck,
  CheckCircle2,
  PhoneCall,
  MapPin,
  ShieldCheck,
  ArrowDown,
  ArrowRight,
  ArrowLeft,
  Flame,
  MessageCircle,
  Sparkles,
  PackageCheck,
  Star,
  User,
  FileText,
  BadgeCheck,
  Award,
  RefreshCw,
  Clock,
  Play,
  Ruler,
  Bell,
  X,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  Image as ImageIcon,
  Upload,
  Eye,
  Gift,
  Copy,
  Trash2,
  Edit3,
  Check
} from 'lucide-react';
import {
  trackFacebookEvent,
  saveFbCustomerIdentity,
  getFbCustomerIdentity,
  captureAndPersistFbParams,
  ensureMetaFirstPartyIdentifiers,
  normalizeCustomerDataForMeta,
  extractLocationForMeta,
  generateMetaEventId,
  buildMetaProductCustomData
} from '../utils/facebookTracking';
import { syncOrderToWordPress, buildVariantSkuCode } from '../utils/wordpressOrderSync';

// Official Original WhatsApp Vector SVG Logo Component
const LandingWhatsAppOriginalIcon: React.FC<{ className?: string }> = ({
  className = 'w-4 h-4'
}) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    aria-hidden="true"
    className={className}
  >
    <path d="M12.031 2C6.508 2 2.023 6.485 2.023 12.007c0 1.766.461 3.49 1.337 5.01L2 22l5.122-1.343a9.975 9.975 0 0 0 4.906 1.292h.004c5.522 0 10.007-4.485 10.007-10.007 0-2.674-1.041-5.188-2.932-7.079A9.946 9.946 0 0 0 12.031 2Zm0 18.258h-.003a8.295 8.295 0 0 1-4.23-1.158l-.303-.18-3.146.825.84-3.066-.198-.314a8.275 8.275 0 0 1-1.278-4.426c0-4.576 3.723-8.299 8.321-8.299 2.222 0 4.311.866 5.882 2.437a8.266 8.266 0 0 1 2.435 5.884c0 4.577-3.724 8.297-8.32 8.297Zm4.552-6.212c-.249-.125-1.474-.728-1.703-.811-.228-.083-.394-.125-.56.125-.166.249-.644.81-.789.976-.145.166-.291.187-.54.062-.249-.125-1.052-.388-2.004-1.237-.741-.661-1.241-1.477-1.386-1.726-.145-.249-.015-.384.11-.508.112-.112.249-.291.374-.436.125-.145.166-.249.249-.415.083-.166.042-.312-.021-.436-.062-.125-.56-1.35-.768-1.848-.202-.485-.407-.419-.56-.427-.145-.007-.311-.009-.477-.009-.166 0-.436.062-.664.312-.228.249-.872.852-.872 2.077 0 1.225.893 2.409 1.017 2.575.125.166 1.757 2.683 4.257 3.762.595.257 1.059.41 1.421.525.597.19 1.14.163 1.569.099.479-.072 1.474-.603 1.682-1.184.208-.581.208-1.08.145-1.184-.062-.104-.228-.166-.477-.291Z" />
  </svg>
);

export const DEFAULT_LANDING_TRUST_ITEMS: LandingTrustItem[] = [
  {
    id: 'trust_1',
    title: '১০০% অরিজিনাল পণ্য',
    description: 'ছবির সাথে বাস্তবের শতভাগ মিল এবং প্রিমিয়াম কোয়ালিটির পূর্ণ নিশ্চয়তা।',
    enabled: true
  },
  {
    id: 'trust_2',
    title: 'হাতে পেয়ে মূল্য পরিশোধ',
    description: 'অগ্রিম ১ টাকাও দিতে হবে না। পণ্য হাতে পেয়ে দেখে ডেলিভারি ম্যানকে পেমেন্ট করুন।',
    enabled: true
  },
  {
    id: 'trust_3',
    title: 'সারা দেশে দ্রুত ডেলিভারি',
    description: 'ঢাকা ও ঢাকার বাইরে বাংলাদেশের যেকোনো প্রান্তে দ্রুততম হোম ডেলিভারি সুবিধা।',
    enabled: true
  },
  {
    id: 'trust_4',
    title: 'সহজ রিটার্ন ও এক্সচেঞ্জ',
    description: 'পণ্যে কোনো ত্রুটি থাকলে ডেলিভারি ম্যানের সামনেই চেক করে রিটার্ন করার সুবিধা।',
    enabled: true
  }
];

export const DEFAULT_LANDING_SIZE_CHART_HEADERS: [string, string, string] = [
  'সাইজ / বয়স',
  'বডি / চেস্ট (ইঞ্চি)',
  'লম্বা / দৈর্ঘ্য (ইঞ্চি)'
];

export const DEFAULT_FOOTER_WARNING_TEXT =
  '⚠️ দয়া করে ফেক অর্ডার করবেন না।\nমিথ্যা ও প্রতারণা আল্লাহর কাছে বড় গুনাহ।\nদায়িত্বশীল হয়ে অর্ডার করার অনুরোধ রইলো। 🤍';

export const DEFAULT_LANDING_SIZE_CHART_ROWS: LandingSizeChartRow[] = [
  { id: 'sz_1', size: '১ - ২ বছর (M)', chest: '২২ ইঞ্চি', length: '১৮ ইঞ্চি' },
  { id: 'sz_2', size: '৩ - ৪ বছর (L)', chest: '২৪ ইঞ্চি', length: '২০ ইঞ্চি' },
  { id: 'sz_3', size: '৫ - ৬ বছর (XL)', chest: '২৬ ইঞ্চি', length: '২২ ইঞ্চি' },
  { id: 'sz_4', size: '৭ - ৮ বছর (XXL)', chest: '২৮ ইঞ্চি', length: '২৪ ইঞ্চি' },
  { id: 'sz_5', size: '৯ - ১০ বছর (3XL)', chest: '৩০ ইঞ্চি', length: '২৬ ইঞ্চি' }
];

export const DEFAULT_LANDING_SHOE_SIZE_CHART_HEADERS: [string, string, string] = [
  'ইউরো সাইজ (EU)',
  'ইউকে সাইজ (UK)',
  'পায়ের মাপ (ইঞ্চি / সেমি)'
];

export const DEFAULT_LANDING_SHOE_SIZE_CHART_ROWS: LandingSizeChartRow[] = [
  { id: 'shoe_1', size: 'EU 39 / 40', chest: 'UK 6 - 6.5', length: '৯.৮ ইঞ্চি (25 cm)' },
  { id: 'shoe_2', size: 'EU 41', chest: 'UK 7', length: '১০.২ ইঞ্চি (26 cm)' },
  { id: 'shoe_3', size: 'EU 42', chest: 'UK 8', length: '১০.৪ ইঞ্চি (26.5 cm)' },
  { id: 'shoe_4', size: 'EU 43', chest: 'UK 9', length: '১০.৮ ইঞ্চি (27.5 cm)' },
  { id: 'shoe_5', size: 'EU 44', chest: 'UK 9.5 - 10', length: '১১.০ ইঞ্চি (28 cm)' }
];

export const DEFAULT_LANDING_SPIN_WHEEL_SLICES: SpinWheelSliceConfig[] = [
  {
    id: 'lp_sw_1',
    label: '৳৫০ ক্যাশ ডিসকাউন্ট',
    shortLabel: '৳৫০ ছাড়',
    type: 'flat',
    value: 50,
    code: 'LP50',
    color: '#059669',
    locked: false
  },
  {
    id: 'lp_sw_2',
    label: 'ফ্রি হোম ডেলিভারি',
    shortLabel: 'ফ্রি ডেলিভারি',
    type: 'free_delivery',
    value: 0,
    code: 'LPFREE',
    color: '#d97706',
    locked: false
  },
  {
    id: 'lp_sw_3',
    label: '৫% স্পেশাল ছাড়',
    shortLabel: '৫% ছাড়',
    type: 'percent',
    value: 5,
    code: 'LP5PCT',
    color: '#4f46e5',
    locked: false
  },
  {
    id: 'lp_sw_4',
    label: '৳১০০ মেগা ডিসকাউন্ট',
    shortLabel: '৳১০০ ছাড়',
    type: 'flat',
    value: 100,
    code: 'LP100',
    color: '#e11d48',
    locked: true
  },
  {
    id: 'lp_sw_5',
    label: '১০% ভিআইপি ছাড়',
    shortLabel: '১০% ছাড়',
    type: 'percent',
    value: 10,
    code: 'LP10PCT',
    color: '#0d9488',
    locked: true
  },
  {
    id: 'lp_sw_6',
    label: '৳৩০ ইনস্ট্যান্ট ছাড়',
    shortLabel: '৳৩০ ছাড়',
    type: 'flat',
    value: 30,
    code: 'LP30',
    color: '#7c3aed',
    locked: false
  }
];

export const DEFAULT_LANDING_SPIN_WHEEL_CONFIG: SpinWheelConfig = {
  badgeText: 'স্পেশাল লাকি ডিসকাউন্ট হুইল',
  titleText: 'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
  subtitleText: 'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
  claimButtonText: 'অফারটি গ্রহণ করে অর্ডার করুন',
  autoPopupDelaySec: 4,
  cooldownDays: 7,
  slices: DEFAULT_LANDING_SPIN_WHEEL_SLICES
};

export const DEFAULT_SOCIAL_PROOF_BUYERS: Array<{
  name: string;
  location: string;
  timeAgo: string;
}> = [
  { name: 'তানিয়া আক্তার', location: 'উত্তরা সেক্টর-৭, ঢাকা', timeAgo: 'এইমাত্র' },
  { name: 'ফারহানা ইসলাম মিম', location: 'ধানমন্ডি-১৫, ঢাকা', timeAgo: '১ মিনিট আগে' },
  { name: 'মোঃ রাকিবুল হাসান', location: 'আগ্রাবাদ, চট্টগ্রাম', timeAgo: '২ মিনিট আগে' },
  { name: 'সাদিয়া আফরিন', location: 'মিরপুর-১০, ঢাকা', timeAgo: '৩ মিনিট আগে' },
  { name: 'নুসরাত জাহান তন্বী', location: 'জিন্দাবাজার, সিলেট', timeAgo: '৪ মিনিট আগে' },
  { name: 'মাহমুদুল হাসান সোহেল', location: 'কান্দিরপাড়, কুমিল্লা', timeAgo: '৫ মিনিট আগে' },
  { name: 'জান্নাতুল ফেরদৌস ঐশী', location: 'গাজীপুর চৌরাস্তা', timeAgo: '৬ মিনিট আগে' },
  { name: 'শামীমা নাসরিন', location: 'সাহেব বাজার, রাজশাহী', timeAgo: '৭ মিনিট আগে' },
  { name: 'আরিফুল ইসলাম জয়', location: 'চাষাড়া, নারায়ণগঞ্জ', timeAgo: '৮ মিনিট আগে' },
  { name: 'তাসনিম জারিন', location: 'বনানী, ঢাকা', timeAgo: '৯ মিনিট আগে' },
  { name: 'মেহেদী হাসান রনি', location: 'সাতমাথা, বগুড়া', timeAgo: '১০ মিনিট আগে' },
  { name: 'রুবাইয়া সুলতানা', location: 'সোনাডাঙ্গা, খুলনা', timeAgo: '১১ মিনিট আগে' },
  { name: 'ফাহিম আহমেদ', location: 'আম্বরখানা, সিলেট', timeAgo: '১২ মিনিট আগে' },
  { name: 'সুমাইয়া আক্তার বর্ষা', location: 'মোহাম্মদপুর, ঢাকা', timeAgo: '১৩ মিনিট আগে' },
  { name: 'নাজমুল হুদা', location: 'জাহাজ কোম্পানি মোড়, রংপুর', timeAgo: '১৪ মিনিট আগে' },
  { name: 'শারমিন আক্তার নিপা', location: 'নাসিরাবাদ, চট্টগ্রাম', timeAgo: '১৫ মিনিট আগে' },
  { name: 'কাজী তানভীর আহমেদ', location: 'বসুন্ধরা আবাসিক এলাকা, ঢাকা', timeAgo: '১৬ মিনিট আগে' },
  { name: 'আফরোজা খানম', location: 'গাঙ্গিনারপাড়, ময়মনসিংহ', timeAgo: '১৭ মিনিট আগে' },
  { name: 'সাইফুল ইসলাম নয়ন', location: 'মাইজদী, নোয়াখালী', timeAgo: '১৮ মিনিট আগে' },
  { name: 'ইশরাত জাহান ইভা', location: 'বাড্ডা লিংক রোড, ঢাকা', timeAgo: '১৯ মিনিট আগে' },
  { name: 'মোঃ জাহিদুল ইসলাম', location: 'বরিশাল সদর', timeAgo: '২০ মিনিট আগে' },
  { name: 'মালিহা তাবাসসুম', location: 'খিলগাঁও তালতলা, ঢাকা', timeAgo: '২১ মিনিট আগে' },
  { name: 'রাশেদুল করিম', location: 'কক্সবাজার সদর', timeAgo: '২২ মিনিট আগে' },
  { name: 'হাবিবা আক্তার মিম', location: 'সাভার বাসস্ট্যান্ড, ঢাকা', timeAgo: '২৩ মিনিট আগে' },
  { name: 'আব্দুল্লাহ আল মামুন', location: 'যশোর সদর', timeAgo: '২৪ মিনিট আগে' },
  { name: 'নাবিলা ইসলাম', location: 'রামপুরা বনশ্রী, ঢাকা', timeAgo: '২৫ মিনিট আগে' },
  { name: 'তৌহিদুল ইসলাম', location: 'ফেনী সদর', timeAgo: '২৬ মিনিট আগে' },
  { name: 'মরিয়ম আক্তার জুঁই', location: 'টঙ্গী স্টেশন রোড, গাজীপুর', timeAgo: '২৭ মিনিট আগে' },
  { name: 'শাকিল মাহমুদ', location: 'টাঙ্গাইল সদর', timeAgo: '২৮ মিনিট আগে' },
  { name: 'লামিয়া রহমান', location: 'ওয়ারী, ঢাকা', timeAgo: '২৯ মিনিট আগে' },
  { name: 'ইমরান হোসেন', location: 'কুষ্টিয়া সদর', timeAgo: '৩০ মিনিট আগে' },
  { name: 'সাবরিনা সুলতানা', location: 'হালিশহর, চট্টগ্রাম', timeAgo: '৩১ মিনিট আগে' },
  { name: 'আশরাফুল আলম', location: 'দিনাজপুর সদর', timeAgo: '৩২ মিনিট আগে' },
  { name: 'ফাতেমা তুজ জোহরা', location: 'যাত্রাবাড়ী, ঢাকা', timeAgo: '৩৩ মিনিট আগে' },
  { name: 'সোহানুর রহমান', location: 'পাবনা সদর', timeAgo: '৩৪ মিনিট আগে' },
  { name: 'নাজনীন নাহার', location: 'ব্রাহ্মণবাড়িয়া সদর', timeAgo: '৩৫ মিনিট আগে' },
  { name: 'মোঃ তারেক আজিজ', location: 'মাধবদী, নরসিংদী', timeAgo: '৩৬ মিনিট আগে' },
  { name: 'রাবেয়া বসরী', location: 'ফরিদপুর সদর', timeAgo: '৩৭ মিনিট আগে' },
  { name: 'কামরুল হাসান', location: 'শ্রীমঙ্গল, মৌলভীবাজার', timeAgo: '৩৮ মিনিট আগে' },
  { name: 'জেসমিন আক্তার', location: 'চাঁদপুর সদর', timeAgo: '৩৯ মিনিট আগে' },
  { name: 'মাজহারুল ইসলাম', location: 'সিরাজগঞ্জ সদর', timeAgo: '৪০ মিনিট আগে' },
  { name: 'তাহমিনা আক্তার কেয়া', location: 'মিরপুর-১, ঢাকা', timeAgo: '৪১ মিনিট আগে' },
  { name: 'রফিকুল ইসলাম', location: 'ভৈরব, কিশোরগঞ্জ', timeAgo: '৪২ মিনিট আগে' },
  { name: 'সোহানা পারভীন', location: 'হবিগঞ্জ সদর', timeAgo: '৪৩ মিনিট আগে' },
  { name: 'মনিরুজ্জামান মনির', location: 'সৈয়দপুর, নীলফামারী', timeAgo: '৪৪ মিনিট আগে' },
  { name: 'আঁখি মনি', location: 'লক্ষ্মীপুর সদর', timeAgo: '৪৫ মিনিট আগে' },
  { name: 'শরীফুল ইসলাম', location: 'নওগাঁ সদর', timeAgo: '৪৬ মিনিট আগে' },
  { name: 'তাসনুভা আনান', location: 'নিকেতন, গুলশান, ঢাকা', timeAgo: '৪৭ মিনিট আগে' },
  { name: 'মোঃ আল-আমিন', location: 'সাতক্ষীরা সদর', timeAgo: '৪৮ মিনিট আগে' },
  { name: 'সানজিদা ইসলাম', location: 'মানিকগঞ্জ সদর', timeAgo: '৪৯ মিনিট আগে' },
  { name: 'হাসিবুল ইসলাম শান্ত', location: 'ঝিনাইদহ সদর', timeAgo: '৫০ মিনিট আগে' },
  { name: 'নূরজাহান বেগম', location: 'মুন্সীগঞ্জ সদর', timeAgo: '৫২ মিনিট আগে' },
  { name: 'জাকির হোসেন', location: 'পটুয়াখালী সদর', timeAgo: '৫৪ মিনিট আগে' },
  { name: 'হুমাইরা জান্নাত', location: 'নাটোর সদর', timeAgo: '৫৫ মিনিট আগে' },
  { name: 'রেজাউল করিম', location: 'জামালপুর সদর', timeAgo: '৫৭ মিনিট আগে' },
  { name: 'তানজিলা আক্তার', location: 'রাজবাড়ী সদর', timeAgo: '৫৯ মিনিট আগে' }
];

export const resolveLandingVideoEmbed = (
  rawUrl: string
): {
  type: 'youtube' | 'facebook' | 'direct_video' | 'none';
  embedUrl: string;
  isReel: boolean;
} => {
  const url = (rawUrl || '').trim();
  if (!url) return { type: 'none', embedUrl: '', isReel: false };

  // 1. YouTube (watch?v=, youtu.be/, shorts/, embed/)
  const ytShortsMatch = url.match(/youtube\.com\/shorts\/([a-zA-Z0-9_-]{6,})/i);
  if (ytShortsMatch && ytShortsMatch[1]) {
    return {
      type: 'youtube',
      embedUrl: `https://www.youtube.com/embed/${ytShortsMatch[1]}?rel=0&modestbranding=1`,
      isReel: true
    };
  }
  const ytMatch =
    url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{6,})/i);
  if (ytMatch && ytMatch[1]) {
    return {
      type: 'youtube',
      embedUrl: `https://www.youtube.com/embed/${ytMatch[1]}?rel=0&modestbranding=1`,
      isReel: false
    };
  }

  // 2. Facebook Video or Reel
  if (/facebook\.com|fb\.watch/i.test(url)) {
    const isReel = /\/reel\/|\/share\/r\//i.test(url);
    return {
      type: 'facebook',
      embedUrl: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(
        url
      )}&show_text=false&width=${isReel ? '360' : '560'}`,
      isReel
    };
  }

  // 3. Direct MP4 / WebM / OGG or other video URL (only allow safe http/https or relative paths)
  if (!/^https?:\/\//i.test(url) && !url.startsWith('/')) {
    return { type: 'none', embedUrl: '', isReel: false };
  }
  return {
    type: 'direct_video',
    embedUrl: url,
    isReel: false
  };
};

export const slugifyLandingText = (text: string): string =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

export const getProductLandingSlug = (product: Product): string => {
  if (product.landingSlug && product.landingSlug.trim() !== '') {
    return slugifyLandingText(product.landingSlug.trim());
  }
  const base = slugifyLandingText(product.nameEn || product.sku || product.id);
  return base || product.id.toLowerCase();
};

export const buildLandingPagePath = (product: Product): string =>
  `/landing/${getProductLandingSlug(product)}`;

export const findLandingProductFromUrl = (
  productsList: Product[],
  pathname: string,
  search: string
): Product | null => {
  if (!productsList || productsList.length === 0) return null;

  let rawSlug = '';
  const cleanPath = decodeURIComponent(pathname || '').replace(/\/+$/, '');
  if (cleanPath.toLowerCase().startsWith('/landing/')) {
    rawSlug = cleanPath.slice('/landing/'.length).trim();
  } else if (search) {
    const params = new URLSearchParams(search);
    rawSlug = (params.get('landing') || '').trim();
  }

  if (!rawSlug) return null;
  const lowerSlug = rawSlug.toLowerCase();

  return (
    productsList.find(p => {
      const pSlug = getProductLandingSlug(p).toLowerCase();
      return (
        pSlug === lowerSlug ||
        (p.landingSlug && p.landingSlug.toLowerCase() === lowerSlug) ||
        p.id.toLowerCase() === lowerSlug ||
        p.sku.toLowerCase() === lowerSlug
      );
    }) || null
  );
};

const toBanglaDigitsLpStatic = (val: number | string, pad = 2): string => {
  const str = String(val).padStart(pad, '0');
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/\d/g, d => bnDigits[Number(d)] || d);
};

interface LandingEvergreenCountdownDigitsProps {
  productId: string;
  countdownHours: number;
  cycleTotalSeconds: number;
  compact?: boolean;
}

const LandingEvergreenCountdownDigits = React.memo<LandingEvergreenCountdownDigitsProps>(
  ({ productId, countdownHours, cycleTotalSeconds, compact = false }) => {
    const [remainingSeconds, setRemainingSeconds] = useState<number>(cycleTotalSeconds);

    useEffect(() => {
      const storageKey = `lp_evergreen_timer_${productId}_${countdownHours}`;

      const getOrResetStartTime = (now: number): number => {
        try {
          const raw = window.localStorage.getItem(storageKey);
          const parsed = raw ? Number(raw) : NaN;
          if (!Number.isNaN(parsed) && parsed > 0 && parsed <= now) {
            const elapsed = Math.floor((now - parsed) / 1000);
            if (elapsed >= 0 && elapsed < cycleTotalSeconds) {
              return parsed;
            }
          }
          window.localStorage.setItem(storageKey, String(now));
          return now;
        } catch {
          return now;
        }
      };

      let startMs = getOrResetStartTime(Date.now());

      const tick = () => {
        if (typeof document !== 'undefined' && document.hidden) return;
        const now = Date.now();
        let elapsed = Math.floor((now - startMs) / 1000);
        if (elapsed >= cycleTotalSeconds || elapsed < 0) {
          startMs = now;
          try {
            window.localStorage.setItem(storageKey, String(now));
          } catch {}
          elapsed = 0;
        }
        setRemainingSeconds(Math.max(0, cycleTotalSeconds - elapsed));
      };

      tick();
      const intervalId = window.setInterval(tick, 1000);
      return () => window.clearInterval(intervalId);
    }, [productId, countdownHours, cycleTotalSeconds]);

    const cdHoursStr = String(Math.floor(remainingSeconds / 3600)).padStart(2, '0');
    const cdMinutesStr = String(Math.floor((remainingSeconds % 3600) / 60)).padStart(2, '0');
    const cdSecondsStr = String(remainingSeconds % 60).padStart(2, '0');

    if (compact) {
      const renderCompactCell = (str: string, textColorClass = 'text-white') => (
        <span
          translate="no"
          className={`notranslate inline-grid grid-cols-2 w-[24px] sm:w-[26px] h-[18px] sm:h-[20px] items-center justify-items-center font-mono text-sm sm:text-base font-extrabold leading-none tabular-nums select-none ${textColorClass}`}
        >
          <span className="w-[12px] sm:w-[13px] text-center">{str[0] || '0'}</span>
          <span className="w-[12px] sm:w-[13px] text-center">{str[1] || '0'}</span>
        </span>
      );

      return (
        <div
          translate="no"
          className="notranslate flex items-center gap-1.5 mx-auto sm:mx-0 shrink-0 select-none"
        >
          <div className="w-[46px] sm:w-[48px] h-[44px] sm:h-[46px] shrink-0 rounded-xl bg-gradient-to-b from-[#b91c1c] to-[#7f1d1d] text-white flex flex-col items-center justify-center shadow-2xs overflow-hidden">
            {renderCompactCell(cdHoursStr)}
            <span className="block text-[9px] font-bold text-rose-100 leading-none mt-0.5">ঘণ্টা</span>
          </div>
          <span className="w-2 text-center text-rose-700 font-extrabold text-sm shrink-0">:</span>
          <div className="w-[46px] sm:w-[48px] h-[44px] sm:h-[46px] shrink-0 rounded-xl bg-gradient-to-b from-[#b91c1c] to-[#7f1d1d] text-white flex flex-col items-center justify-center shadow-2xs overflow-hidden">
            {renderCompactCell(cdMinutesStr)}
            <span className="block text-[9px] font-bold text-rose-100 leading-none mt-0.5">মিনিট</span>
          </div>
          <span className="w-2 text-center text-rose-700 font-extrabold text-sm shrink-0">:</span>
          <div className="w-[46px] sm:w-[48px] h-[44px] sm:h-[46px] shrink-0 rounded-xl bg-gradient-to-b from-[#dc2626] to-[#991b1b] text-white flex flex-col items-center justify-center shadow-2xs ring-1 ring-amber-300/60 overflow-hidden">
            {renderCompactCell(cdSecondsStr, 'text-amber-200')}
            <span className="block text-[9px] font-bold text-amber-100 leading-none mt-0.5">সেকেন্ড</span>
          </div>
        </div>
      );
    }

    const renderStandardCell = (str: string, textColorClass = 'text-white') => (
      <span
        translate="no"
        className={`notranslate inline-grid grid-cols-2 w-[28px] sm:w-[32px] h-[20px] sm:h-[22px] items-center justify-items-center font-mono text-base sm:text-lg font-extrabold leading-none tabular-nums select-none ${textColorClass}`}
      >
        <span className="w-[14px] sm:w-[16px] text-center">{str[0] || '0'}</span>
        <span className="w-[14px] sm:w-[16px] text-center">{str[1] || '0'}</span>
      </span>
    );

    return (
      <div
        translate="no"
        className="notranslate flex items-center gap-1.5 mx-auto sm:mx-0 shrink-0 select-none"
      >
        <div className="w-[54px] sm:w-[58px] h-[50px] sm:h-[54px] shrink-0 rounded-xl bg-gradient-to-b from-[#b91c1c] to-[#7f1d1d] text-white flex flex-col items-center justify-center shadow-xs border border-rose-700/40 overflow-hidden">
          {renderStandardCell(cdHoursStr)}
          <span className="block text-[10px] font-bold text-rose-100 leading-none mt-1">ঘণ্টা</span>
        </div>

        <span className="w-2 text-center text-rose-700 font-extrabold text-base sm:text-lg shrink-0">
          :
        </span>

        <div className="w-[54px] sm:w-[58px] h-[50px] sm:h-[54px] shrink-0 rounded-xl bg-gradient-to-b from-[#b91c1c] to-[#7f1d1d] text-white flex flex-col items-center justify-center shadow-xs border border-rose-700/40 overflow-hidden">
          {renderStandardCell(cdMinutesStr)}
          <span className="block text-[10px] font-bold text-rose-100 leading-none mt-1">মিনিট</span>
        </div>

        <span className="w-2 text-center text-rose-700 font-extrabold text-base sm:text-lg shrink-0">
          :
        </span>

        <div className="w-[54px] sm:w-[58px] h-[50px] sm:h-[54px] shrink-0 rounded-xl bg-gradient-to-b from-[#dc2626] to-[#991b1b] text-white flex flex-col items-center justify-center shadow-xs border border-amber-300/60 overflow-hidden">
          {renderStandardCell(cdSecondsStr, 'text-amber-200')}
          <span className="block text-[10px] font-bold text-amber-100 leading-none mt-1">সেকেন্ড</span>
        </div>
      </div>
    );
  }
);

const LandingLiveViewerBadge = React.memo<{ productId: string }>(({ productId }) => {
  const [viewerCount, setViewerCount] = useState<number>(() => Math.floor(12 + Math.random() * 37));

  useEffect(() => {
    setViewerCount(Math.floor(12 + Math.random() * 37));
    const interval = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setViewerCount(prev => {
        const delta = Math.floor(Math.random() * 5) - 2;
        const next = prev + (delta === 0 ? 1 : delta);
        return Math.max(12, Math.min(48, next));
      });
    }, 4500);
    return () => window.clearInterval(interval);
  }, [productId]);

  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-50/90 border border-amber-200/80 text-slate-800 text-xs sm:text-[13px] font-semibold shadow-2xs">
      <span className="relative flex h-2 w-2 shrink-0">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600" />
      </span>
      <Eye className="w-3.5 h-3.5 text-amber-700 shrink-0" />
      <span>
        <strong className="font-mono font-extrabold text-rose-700 tabular-nums">
          {viewerCount}
        </strong>{' '}
        people currently viewing this product
      </span>
    </div>
  );
});

interface ProductLandingPageViewProps {
  product: Product;
  onBackToAdmin?: () => void;
  onOpenStorefront?: () => void;
}

export const ProductLandingPageView: React.FC<ProductLandingPageViewProps> = ({
  product,
  onBackToAdmin,
  onOpenStorefront
}) => {
  const {
    currentBusiness,
    updateBusiness,
    categories,
    products,
    updateProduct,
    onlineOrders,
    placeOnlineOrder,
    checkDailyOrderLimit,
    verifyDailyOrderLimitServer,
    upsertIncompleteOrder,
    registerOrUpdateOnlineCustomer,
    isAuthenticated,
    formatCurrency,
    showToast
  } = useApp();

  const [orderLimitPopupData, setOrderLimitPopupData] = useState<DailyOrderLimitCheckResult | null>(
    null
  );
  const [isEditingLimitPopupInline, setIsEditingLimitPopupInline] = useState(false);
  const [inlineLimitTitle, setInlineLimitTitle] = useState('');
  const [inlineLimitMessage, setInlineLimitMessage] = useState('');
  const [inlineLimitSameProdMaxCount, setInlineLimitSameProdMaxCount] = useState(2);
  const [inlineLimitMaxCount, setInlineLimitMaxCount] = useState(5);

  const isAdminViewing = Boolean(isAuthenticated || onBackToAdmin);

  // ============================================================================
  // LANDING PAGE 2 (MULTI-PRODUCT SHOWCASE) & LANDING PAGE 3 (MULTI-PRODUCT ORDER)
  // ============================================================================
  const isTemplate2 = product.landingTemplate === 'template_2';
  const isTemplate3 = product.landingTemplate === 'template_3';
  const isMultiShowcaseTemplate = isTemplate2 || isTemplate3;

  // Helpers for Dual Variations (Color + Size), Single Variation (Color only or Size only), or No Variations
  const getLpColorVariants = (p: Product): ProductVariant[] =>
    (p.variants || []).filter(v => v.type === 'color');

  const getLpSizeVariants = (p: Product): ProductVariant[] =>
    (p.variants || []).filter(v => v.type !== 'color');

  const hasLpDualVariants = (p: Product): boolean =>
    getLpColorVariants(p).length > 0 && getLpSizeVariants(p).length > 0;

  const combineLpColorAndSize = (
    p: Product,
    colorVar: ProductVariant,
    sizeVar: ProductVariant
  ): ProductVariant => ({
    ...sizeVar,
    id: `${colorVar.id}__${sizeVar.id}`,
    label: `কালার: ${colorVar.label} | সাইজ: ${sizeVar.label}`,
    sku: sizeVar.sku ? `${sizeVar.sku}-${colorVar.label}` : colorVar.sku || p.sku,
    retailPrice: sizeVar.retailPrice || colorVar.retailPrice || p.retailPrice,
    regularPrice: sizeVar.regularPrice ?? colorVar.regularPrice ?? p.regularPrice,
    discountPrice: sizeVar.discountPrice ?? colorVar.discountPrice ?? p.discountPrice,
    purchasePrice: sizeVar.purchasePrice || colorVar.purchasePrice || p.purchasePrice,
    outOfStock: Boolean(colorVar.outOfStock || sizeVar.outOfStock),
    imageUrl: colorVar.imageUrl || sizeVar.imageUrl
  });

  const showcaseEntries = useMemo(() => {
    if (!isMultiShowcaseTemplate) return [];
    const rawItems: LandingShowcaseProductItem[] = Array.isArray(product.landingShowcaseItems)
      ? product.landingShowcaseItems
      : [];
    const defaultBadges = [
      'টপ সেলিং 🔥',
      'বেস্ট চয়েস ⭐',
      'লিমিটেড অফার ⏳',
      'নতুন কালেকশন ✨',
      'ট্রেন্ডিং 🌸'
    ];
    const defaultFabrics = [
      'প্রিমিয়াম চায়না মাইক্রো ভেলভেট',
      'অরিজিনাল সুতি ও এমব্রয়ডারি',
      'সফট জর্জেট ও কারচুপি ওয়ার্ক',
      'প্রিমিয়াম লাক্সারি কটন',
      'ইম্পোর্টেড সফট সিল্ক'
    ];
    const defaultColors = [
      'রয়্যাল মেরুন',
      'ডিপ ব্ল্যাক',
      'এমেরাল্ড গ্রিন',
      'নেভি ব্লু',
      'রোজ পিঙ্ক'
    ];

    if (rawItems.length > 0) {
      const matched = rawItems
        .map((item, idx) => {
          const found = products.find(p => p.id === item.productId);
          if (!found) return null;
          return {
            item,
            product: found,
            badgeText: (item.badgeText || '').trim() || defaultBadges[idx % defaultBadges.length],
            fabricSubtitle:
              (item.fabricSubtitle || '').trim() || defaultFabrics[idx % defaultFabrics.length],
            colorTag: (item.colorTag || '').trim() || defaultColors[idx % defaultColors.length]
          };
        })
        .filter((entry): entry is NonNullable<typeof entry> => entry !== null);
      if (matched.length > 0) return matched;
    }

    // Fallback when no showcase items are saved yet: pull up to 5 existing website products
    const fallbackWebsiteProducts = products
      .filter(p => !p.isLandingPageProduct && p.id !== product.id)
      .slice(0, 5);
    return fallbackWebsiteProducts.map((found, idx) => ({
      item: {
        productId: found.id,
        badgeText: defaultBadges[idx % defaultBadges.length],
        fabricSubtitle: defaultFabrics[idx % defaultFabrics.length],
        colorTag: defaultColors[idx % defaultColors.length]
      },
      product: found,
      badgeText: defaultBadges[idx % defaultBadges.length],
      fabricSubtitle: defaultFabrics[idx % defaultFabrics.length],
      colorTag: defaultColors[idx % defaultColors.length]
    }));
  }, [isMultiShowcaseTemplate, product.landingShowcaseItems, product.id, products]);

  const [selectedShowcaseProductId, setSelectedShowcaseProductId] = useState<string>(() => {
    if (
      (product.landingTemplate === 'template_2' || product.landingTemplate === 'template_3') &&
      Array.isArray(product.landingShowcaseItems) &&
      product.landingShowcaseItems.length > 0
    ) {
      return product.landingShowcaseItems[0].productId;
    }
    return product.id;
  });

  useEffect(() => {
    if (!isTemplate2 || showcaseEntries.length === 0) return;
    if (!showcaseEntries.some(e => e.product.id === selectedShowcaseProductId)) {
      const firstProd = showcaseEntries[0].product;
      setSelectedShowcaseProductId(firstProd.id);
      const firstInStock = firstProd.variants?.find(v => !v.outOfStock);
      setSelectedVariantId(firstInStock?.id || firstProd.variants?.[0]?.id || '');
    }
  }, [isTemplate2, showcaseEntries, selectedShowcaseProductId]);

  const selectedShowcaseEntry = useMemo(() => {
    if (!isTemplate2 || showcaseEntries.length === 0) return null;
    return (
      showcaseEntries.find(e => e.product.id === selectedShowcaseProductId) || showcaseEntries[0]
    );
  }, [isTemplate2, showcaseEntries, selectedShowcaseProductId]);

  // For Landing Page 1, checkoutTargetProduct is always `product` (100% untouched).
  // For Landing Page 2, checkoutTargetProduct is the currently selected showcase website product.
  const checkoutTargetProduct: Product =
    isTemplate2 && selectedShowcaseEntry ? selectedShowcaseEntry.product : product;

  // Active Variant & Quantity (automatically picks first in-stock variation)
  const [selectedVariantId, setSelectedVariantId] = useState<string>(() => {
    const initialTarget =
      product.landingTemplate === 'template_2' &&
      Array.isArray(product.landingShowcaseItems) &&
      product.landingShowcaseItems.length > 0
        ? products.find(p => p.id === product.landingShowcaseItems![0].productId) || product
        : product;
    const sizeVars = getLpSizeVariants(initialTarget);
    const pool = sizeVars.length > 0 ? sizeVars : initialTarget.variants || [];
    const firstInStock = pool.find(v => !v.outOfStock);
    return firstInStock?.id || pool[0]?.id || '';
  });

  const [selectedColorId, setSelectedColorId] = useState<string>(() => {
    const initialTarget =
      product.landingTemplate === 'template_2' &&
      Array.isArray(product.landingShowcaseItems) &&
      product.landingShowcaseItems.length > 0
        ? products.find(p => p.id === product.landingShowcaseItems![0].productId) || product
        : product;
    const colorVars = getLpColorVariants(initialTarget);
    const firstInStockColor = colorVars.find(v => !v.outOfStock);
    return firstInStockColor?.id || colorVars[0]?.id || '';
  });

  // Landing Page 3 (Multi-Product Order) State: tracks which products are checked, their chosen size/color, and quantity
  const [lp3SelectionMap, setLp3SelectionMap] = useState<
    Record<string, { selected: boolean; variantId: string; colorId: string; quantity: number }>
  >({});

  useEffect(() => {
    if (!isTemplate3 || showcaseEntries.length === 0) return;
    setLp3SelectionMap(prev => {
      const next: Record<
        string,
        { selected: boolean; variantId: string; colorId: string; quantity: number }
      > = {};
      let hasAnySelected = false;
      showcaseEntries.forEach((entry, idx) => {
        const p = entry.product;
        const existing = prev[p.id];
        const sizeVars = getLpSizeVariants(p);
        const colorVars = getLpColorVariants(p);
        const sizePool = sizeVars.length > 0 ? sizeVars : p.variants || [];
        const defaultSizeId =
          sizePool.find(v => !v.outOfStock)?.id || sizePool[0]?.id || '';
        const defaultColorId =
          colorVars.find(v => !v.outOfStock)?.id || colorVars[0]?.id || '';
        const isSel = existing !== undefined ? existing.selected : idx === 0;
        if (isSel) hasAnySelected = true;
        next[p.id] = {
          selected: isSel,
          variantId:
            existing?.variantId && sizePool.some(v => v.id === existing.variantId && !v.outOfStock)
              ? existing.variantId
              : defaultSizeId,
          colorId:
            existing?.colorId && colorVars.some(v => v.id === existing.colorId && !v.outOfStock)
              ? existing.colorId
              : defaultColorId,
          quantity: existing?.quantity && existing.quantity >= 1 ? existing.quantity : 1
        };
      });
      if (!hasAnySelected && showcaseEntries[0]) {
        next[showcaseEntries[0].product.id].selected = true;
      }
      return next;
    });
  }, [isTemplate3, showcaseEntries]);

  const toggleLp3ProductSelection = (prodId: string, forceSelect?: boolean) => {
    setLp3SelectionMap(prev => {
      const cur = prev[prodId];
      if (!cur) return prev;
      const nextSelected = forceSelect !== undefined ? forceSelect : !cur.selected;
      return {
        ...prev,
        [prodId]: {
          ...cur,
          selected: nextSelected
        }
      };
    });
  };

  const updateLp3ProductConfig = (
    prodId: string,
    patch: Partial<{ selected: boolean; variantId: string; colorId: string; quantity: number }>
  ) => {
    setLp3SelectionMap(prev => {
      const cur = prev[prodId];
      if (!cur) return prev;
      return {
        ...prev,
        [prodId]: {
          ...cur,
          ...patch
        }
      };
    });
  };

  const lp3SelectedResolvedItems = useMemo(() => {
    if (!isTemplate3 || showcaseEntries.length === 0) return [];
    return showcaseEntries
      .filter(entry => lp3SelectionMap[entry.product.id]?.selected)
      .map(entry => {
        const itemProd = entry.product;
        const cfg = lp3SelectionMap[itemProd.id] || {
          selected: true,
          variantId: '',
          colorId: '',
          quantity: 1
        };
        const isDual = hasLpDualVariants(itemProd);
        const colorVars = getLpColorVariants(itemProd);
        const sizeVars = getLpSizeVariants(itemProd);
        let resolvedVariant: ProductVariant | undefined;

        if (isDual) {
          const cVar =
            colorVars.find(v => v.id === cfg.colorId && !v.outOfStock) ||
            colorVars.find(v => !v.outOfStock) ||
            colorVars[0];
          const sVar =
            sizeVars.find(v => v.id === cfg.variantId && !v.outOfStock) ||
            sizeVars.find(v => !v.outOfStock) ||
            sizeVars[0];
          if (cVar && sVar) {
            resolvedVariant = combineLpColorAndSize(itemProd, cVar, sVar);
          }
        } else if (itemProd.variants && itemProd.variants.length > 0) {
          resolvedVariant =
            itemProd.variants.find(v => v.id === cfg.variantId && !v.outOfStock) ||
            itemProd.variants.find(v => !v.outOfStock) ||
            itemProd.variants[0];
        }

        const uRetail = resolvedVariant ? resolvedVariant.retailPrice : itemProd.retailPrice;
        const rawReg = resolvedVariant?.regularPrice ?? itemProd.regularPrice ?? uRetail;
        const uRegular = rawReg > uRetail ? rawReg : uRetail;
        const qty = Math.max(1, cfg.quantity || 1);
        return {
          entry,
          product: itemProd,
          config: cfg,
          activeVariant: resolvedVariant,
          quantity: qty,
          unitRetailPrice: uRetail,
          unitRegularPrice: uRegular,
          lineTotal: uRetail * qty,
          lineSavings: Math.max(0, uRegular - uRetail) * qty
        };
      });
  }, [isTemplate3, showcaseEntries, lp3SelectionMap]);

  const [quantity, setQuantity] = useState<number>(1);
  const [activeGalleryIdx, setActiveGalleryIdx] = useState<number>(0);
  const [lpHoverZoom, setLpHoverZoom] = useState<{ active: boolean; x: number; y: number }>({
    active: false,
    x: 50,
    y: 50
  });
  const [lpLightboxOpen, setLpLightboxOpen] = useState<boolean>(false);
  const [lpLightboxScale, setLpLightboxScale] = useState<number>(1);
  const [lpLightboxPan, setLpLightboxPan] = useState<{ x: number; y: number }>({ x: 50, y: 50 });

  const isGlobalImageZoomEnabled = currentBusiness.productImageZoomEnabled !== false;
  const lpImageZoomStyle = currentBusiness.productImageZoomStyle || 'woocommerce_lightbox';
  const isLpHoverZoomAllowed =
    isGlobalImageZoomEnabled &&
    (lpImageZoomStyle === 'hover_and_lightbox' || lpImageZoomStyle === 'hover_only');
  const isLpLightboxAllowed =
    isGlobalImageZoomEnabled &&
    (lpImageZoomStyle === 'woocommerce_lightbox' || lpImageZoomStyle === 'hover_and_lightbox');
  const lpZoomStyleLabels: Record<
    'woocommerce_lightbox' | 'hover_and_lightbox' | 'hover_only',
    string
  > = {
    woocommerce_lightbox: 'উকমার্স লাইটবক্স',
    hover_and_lightbox: 'হোভার + লাইটবক্স',
    hover_only: 'শুধু হোভার'
  };

  // Sync default variant when product changes
  useEffect(() => {
    const target =
      product.landingTemplate === 'template_2' && showcaseEntries.length > 0
        ? showcaseEntries[0].product
        : product;
    if (product.landingTemplate === 'template_2' && showcaseEntries.length > 0) {
      setSelectedShowcaseProductId(showcaseEntries[0].product.id);
    }
    const sizeVars = getLpSizeVariants(target);
    const pool = sizeVars.length > 0 ? sizeVars : target.variants || [];
    const firstInStock = pool.find(v => !v.outOfStock);
    setSelectedVariantId(firstInStock?.id || pool[0]?.id || '');

    const colorVars = getLpColorVariants(target);
    const firstColor = colorVars.find(v => !v.outOfStock);
    setSelectedColorId(firstColor?.id || colorVars[0]?.id || '');

    setQuantity(1);
    setActiveGalleryIdx(0);
    setLpHoverZoom({ active: false, x: 50, y: 50 });
    setLpLightboxOpen(false);
    setLpLightboxScale(1);
    setLpLightboxPan({ x: 50, y: 50 });
  }, [product.id]);

  // If the currently selected variation is marked Out of Stock, auto-switch to first in-stock variation
  useEffect(() => {
    if (!checkoutTargetProduct.variants || checkoutTargetProduct.variants.length === 0) return;
    if (hasLpDualVariants(checkoutTargetProduct)) {
      const sizeVars = getLpSizeVariants(checkoutTargetProduct);
      const curSize = sizeVars.find(v => v.id === selectedVariantId);
      if (!curSize || curSize.outOfStock) {
        const firstSize = sizeVars.find(v => !v.outOfStock);
        if (firstSize && firstSize.id !== selectedVariantId) {
          setSelectedVariantId(firstSize.id);
        }
      }
      const colorVars = getLpColorVariants(checkoutTargetProduct);
      const curColor = colorVars.find(v => v.id === selectedColorId);
      if (!curColor || curColor.outOfStock) {
        const firstColor = colorVars.find(v => !v.outOfStock);
        if (firstColor && firstColor.id !== selectedColorId) {
          setSelectedColorId(firstColor.id);
        }
      }
      return;
    }
    const current = checkoutTargetProduct.variants.find(v => v.id === selectedVariantId);
    if (!current || current.outOfStock) {
      const firstInStock = checkoutTargetProduct.variants.find(v => !v.outOfStock);
      if (firstInStock && firstInStock.id !== selectedVariantId) {
        setSelectedVariantId(firstInStock.id);
      }
    }
  }, [checkoutTargetProduct.variants, selectedVariantId, selectedColorId]);

  const activeVariant: ProductVariant | undefined = useMemo(() => {
    if (!checkoutTargetProduct.variants || checkoutTargetProduct.variants.length === 0)
      return undefined;
    if (hasLpDualVariants(checkoutTargetProduct)) {
      const colorVars = getLpColorVariants(checkoutTargetProduct);
      const sizeVars = getLpSizeVariants(checkoutTargetProduct);
      const chosenColor =
        colorVars.find(v => v.id === selectedColorId && !v.outOfStock) ||
        colorVars.find(v => !v.outOfStock) ||
        colorVars[0];
      const chosenSize =
        sizeVars.find(v => v.id === selectedVariantId && !v.outOfStock) ||
        sizeVars.find(v => !v.outOfStock) ||
        sizeVars[0];
      if (chosenColor && chosenSize) {
        return combineLpColorAndSize(checkoutTargetProduct, chosenColor, chosenSize);
      }
    }
    const chosen = checkoutTargetProduct.variants.find(
      v => v.id === selectedVariantId && !v.outOfStock
    );
    if (chosen) return chosen;
    return (
      checkoutTargetProduct.variants.find(v => !v.outOfStock) || checkoutTargetProduct.variants[0]
    );
  }, [checkoutTargetProduct, selectedVariantId, selectedColorId]);

  // Checkout Form States
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('');
  const [selectedDeliveryZone, setSelectedDeliveryZone] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [orderNotes, setOrderNotes] = useState<string>('');
  const [errorField, setErrorField] = useState<'name' | 'phone' | 'address' | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [confirmedOrder, setConfirmedOrder] = useState<OnlineOrder | null>(null);

  // Pricing & Delivery Calculation
  const unitRetailPrice = activeVariant
    ? activeVariant.retailPrice
    : checkoutTargetProduct.retailPrice;
  const unitRegularPrice = useMemo(() => {
    const rawReg = activeVariant?.regularPrice ?? checkoutTargetProduct.regularPrice;
    if (rawReg && rawReg > unitRetailPrice) return rawReg;
    return unitRetailPrice;
  }, [activeVariant, checkoutTargetProduct.regularPrice, unitRetailPrice]);

  const unitSavings = Math.max(0, unitRegularPrice - unitRetailPrice);
  const discountPercent =
    unitRegularPrice > unitRetailPrice
      ? Math.round(((unitRegularPrice - unitRetailPrice) / unitRegularPrice) * 100)
      : 0;

  const effectiveOrderQuantity = useMemo(() => {
    if (isTemplate3 && lp3SelectedResolvedItems.length > 0) {
      return lp3SelectedResolvedItems.reduce((sum, it) => sum + it.quantity, 0);
    }
    return quantity;
  }, [isTemplate3, lp3SelectedResolvedItems, quantity]);

  const subtotal = useMemo(() => {
    if (isTemplate3 && lp3SelectedResolvedItems.length > 0) {
      return lp3SelectedResolvedItems.reduce((sum, it) => sum + it.lineTotal, 0);
    }
    return unitRetailPrice * quantity;
  }, [isTemplate3, lp3SelectedResolvedItems, unitRetailPrice, quantity]);

  const totalSavings = useMemo(() => {
    if (isTemplate3 && lp3SelectedResolvedItems.length > 0) {
      return lp3SelectedResolvedItems.reduce((sum, it) => sum + it.lineSavings, 0);
    }
    return unitSavings * quantity;
  }, [isTemplate3, lp3SelectedResolvedItems, unitSavings, quantity]);

  // ============================================================================
  // SEPARATE LANDING PAGE SPIN THE WHEEL (স্পিন দ্য হুইল) STATE & CONFIG
  // ============================================================================
  const globalLandingSpinEnabled = currentBusiness.landingSpinWheelEnabled !== false;
  const productLandingSpinEnabled = product.landingSpinWheelEnabled !== false;
  const spinWheelEnabled = globalLandingSpinEnabled && productLandingSpinEnabled;

  const spinWheelConfig: Required<SpinWheelConfig> = useMemo(() => {
    const raw = product.landingSpinWheelConfig || currentBusiness.landingSpinWheelConfig;
    const rawSlices =
      raw?.slices && Array.isArray(raw.slices) && raw.slices.length >= 2
        ? raw.slices
        : DEFAULT_LANDING_SPIN_WHEEL_SLICES;
    const hasExplicitLockState = rawSlices.some(s => typeof s.locked === 'boolean');
    const validSlices = hasExplicitLockState
      ? rawSlices
      : rawSlices.map((s, idx) => ({
          ...s,
          locked:
            s.id === 'lp_sw_4' ||
            s.id === 'lp_sw_5' ||
            (!['lp_sw_1', 'lp_sw_2', 'lp_sw_3', 'lp_sw_6'].includes(s.id) &&
              (idx === 3 || idx === 4))
        }));
    return {
      badgeText: raw?.badgeText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.badgeText || 'স্পেশাল লাকি ডিসকাউন্ট হুইল',
      titleText: raw?.titleText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.titleText || 'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
      subtitleText: raw?.subtitleText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.subtitleText || 'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
      claimButtonText: raw?.claimButtonText?.trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.claimButtonText || 'অফারটি গ্রহণ করে অর্ডার করুন',
      autoPopupDelaySec:
        typeof raw?.autoPopupDelaySec === 'number' && raw.autoPopupDelaySec >= 1
          ? raw.autoPopupDelaySec
          : DEFAULT_LANDING_SPIN_WHEEL_CONFIG.autoPopupDelaySec || 4,
      cooldownDays:
        typeof raw?.cooldownDays === 'number' && raw.cooldownDays >= 1
          ? raw.cooldownDays
          : DEFAULT_LANDING_SPIN_WHEEL_CONFIG.cooldownDays || 7,
      slices: validSlices
    };
  }, [product.landingSpinWheelConfig, currentBusiness.landingSpinWheelConfig]);

  const spinWheelSlices = spinWheelConfig.slices;

  const [showSpinModal, setShowSpinModal] = useState(false);
  const [showSpinAdminModal, setShowSpinAdminModal] = useState(false);
  const [spinAdminTab, setSpinAdminTab] = useState<'settings' | 'leads'>('settings');
  const [spinConfigDraft, setSpinConfigDraft] = useState<SpinWheelConfig>(spinWheelConfig);
  const [isSpinning, setIsSpinning] = useState(false);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [spinCustomerName, setSpinCustomerName] = useState('');
  const [spinCustomerPhone, setSpinCustomerPhone] = useState('');
  const [spinFormError, setSpinFormError] = useState('');
  const [spinLeadSearch, setSpinLeadSearch] = useState('');

  useEffect(() => {
    setSpinConfigDraft(spinWheelConfig);
  }, [spinWheelConfig]);

  const [dailySpinLock, setDailySpinLock] = useState<{
    dateKey: string;
    timestamp?: number;
    name: string;
    phone: string;
    reward: SpinWheelSliceConfig;
    used?: boolean;
    usedOrderNo?: string;
  } | null>(() => {
    try {
      const saved = window.localStorage.getItem('lp_spin_daily_lock_v1');
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      const todayKey = new Date().toISOString().slice(0, 10);
      const cooldownMs = (spinWheelConfig.cooldownDays || 7) * 24 * 60 * 60 * 1000;
      if (parsed && parsed.reward) {
        if (parsed.dateKey === todayKey) return parsed;
        if (parsed.timestamp && Date.now() - parsed.timestamp < cooldownMs) return parsed;
      }
      return null;
    } catch {
      return null;
    }
  });

  const [wonSpinSlice, setWonSpinSlice] = useState<SpinWheelSliceConfig | null>(() => {
    try {
      const savedLock = window.localStorage.getItem('lp_spin_daily_lock_v1');
      if (savedLock) {
        const parsedLock = JSON.parse(savedLock);
        const todayKey = new Date().toISOString().slice(0, 10);
        const cooldownMs = (spinWheelConfig.cooldownDays || 7) * 24 * 60 * 60 * 1000;
        if (
          parsedLock &&
          parsedLock.reward &&
          (parsedLock.dateKey === todayKey ||
            (parsedLock.timestamp && Date.now() - parsedLock.timestamp < cooldownMs))
        ) {
          return parsedLock.reward;
        }
      }
      const saved = window.localStorage.getItem('lp_spin_reward_v1');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [claimedSpinReward, setClaimedSpinReward] = useState<SpinWheelSliceConfig | null>(() => {
    try {
      const savedLock = window.localStorage.getItem('lp_spin_daily_lock_v1');
      if (savedLock) {
        const parsedLock = JSON.parse(savedLock);
        if (parsedLock?.used) {
          return null;
        }
      }
      const saved = window.localStorage.getItem('lp_spin_reward_v1');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Auto-popup timer on Landing Page (Separate from Storefront)
  useEffect(() => {
    if (!spinWheelEnabled || confirmedOrder) return;
    if (dailySpinLock || claimedSpinReward) return;

    const cooldownMs = (spinWheelConfig.cooldownDays || 7) * 24 * 60 * 60 * 1000;
    try {
      const rawPopupState = window.localStorage.getItem('lp_spin_popup_state_v1');
      if (rawPopupState) {
        const parsedState = JSON.parse(rawPopupState);
        if (parsedState?.lastShownAt && Date.now() - parsedState.lastShownAt < cooldownMs) {
          return;
        }
      }
    } catch {
      // ignore storage errors
    }

    const delayMs = Math.max(1, spinWheelConfig.autoPopupDelaySec || 4) * 1000;
    const timer = window.setTimeout(() => {
      setShowSpinModal(true);
      try {
        window.localStorage.setItem(
          'lp_spin_popup_state_v1',
          JSON.stringify({ lastShownAt: Date.now() })
        );
      } catch {
        // ignore
      }
    }, delayMs);

    return () => window.clearTimeout(timer);
  }, [
    spinWheelEnabled,
    confirmedOrder,
    dailySpinLock,
    claimedSpinReward,
    spinWheelConfig.cooldownDays,
    spinWheelConfig.autoPopupDelaySec
  ]);

  const storedSpinLeads = useMemo<SpinWheelLead[]>(() => {
    const deletedSet = new Set(currentBusiness.deletedSpinLeadIds || []);
    const businessLeads = Array.isArray(currentBusiness.landingSpinWheelLeads)
      ? currentBusiness.landingSpinWheelLeads
      : [];
    let localLeads: SpinWheelLead[] = [];
    try {
      const raw = window.localStorage.getItem('lp_spin_wheel_leads_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) localLeads = parsed;
      }
    } catch {
      // ignore
    }
    const mergedMap = new Map<string, SpinWheelLead>();
    [...businessLeads, ...localLeads].forEach(item => {
      if (item && item.id && !deletedSet.has(item.id)) mergedMap.set(item.id, item);
    });
    return Array.from(mergedMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [
    currentBusiness.landingSpinWheelLeads,
    currentBusiness.deletedSpinLeadIds,
    showSpinModal,
    showSpinAdminModal,
    dailySpinLock
  ]);

  const filteredSpinLeads = useMemo(() => {
    const q = spinLeadSearch.trim().toLowerCase();
    if (!q) return storedSpinLeads;
    return storedSpinLeads.filter(
      l =>
        (l.customerName || l.name || '').toLowerCase().includes(q) ||
        (l.customerPhone || l.phone || '').toLowerCase().includes(q) ||
        (l.rewardLabel || l.prizeLabel || '').toLowerCase().includes(q) ||
        (l.couponCode || l.prizeCode || '').toLowerCase().includes(q)
    );
  }, [storedSpinLeads, spinLeadSearch]);

  const handleCloseSpinModal = () => {
    if (isSpinning) return;
    setShowSpinModal(false);
    try {
      window.localStorage.setItem(
        'lp_spin_popup_state_v1',
        JSON.stringify({ lastShownAt: Date.now(), dismissed: true })
      );
    } catch {
      // ignore
    }
  };

  const handleSaveSpinConfigDraft = () => {
    const cleanedSlices = (spinConfigDraft.slices || [])
      .map((s, idx) => ({
        ...s,
        id: s.id || `lp_sw_${idx + 1}`,
        shortLabel: s.shortLabel.trim() || s.label.trim() || `অফার ${idx + 1}`,
        label: s.label.trim() || s.shortLabel.trim() || `অফার ${idx + 1}`,
        code: (s.code || `LP${idx + 1}`).trim().toUpperCase(),
        value: Number(s.value) || 0,
        locked: Boolean(s.locked)
      }))
      .filter(s => s.shortLabel !== '');

    if (cleanedSlices.length < 2) {
      showToast('হুইলে কমপক্ষে ২টি অফার স্লাইস থাকতে হবে', 'error');
      return;
    }

    if (cleanedSlices.every(s => s.locked)) {
      showToast('সবগুলো অফার লক রাখা যাবে না! কমপক্ষে ১টি অফার আনলক রাখুন যাতে কাস্টমার জিততে পারে।', 'error');
      return;
    }

    const updatedConfig: SpinWheelConfig = {
      ...spinConfigDraft,
      badgeText: (spinConfigDraft.badgeText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.badgeText,
      titleText: (spinConfigDraft.titleText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.titleText,
      subtitleText: (spinConfigDraft.subtitleText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.subtitleText,
      claimButtonText: (spinConfigDraft.claimButtonText || '').trim() || DEFAULT_LANDING_SPIN_WHEEL_CONFIG.claimButtonText || 'অফারটি গ্রহণ করে অর্ডার করুন',
      autoPopupDelaySec: Math.max(1, Number(spinConfigDraft.autoPopupDelaySec) || 4),
      cooldownDays: Math.max(1, Number(spinConfigDraft.cooldownDays) || 7),
      slices: cleanedSlices
    };

    updateBusiness({ landingSpinWheelConfig: updatedConfig });
    showToast('ল্যান্ডিং পেজের স্পিন হুইল সেটিংস সংরক্ষিত হয়েছে!', 'success');
  };

  const handleSpinTheWheel = () => {
    if (isSpinning) return;
    setSpinFormError('');

    const todayKey = new Date().toISOString().slice(0, 10);
    const cooldownDays = spinWheelConfig.cooldownDays || 7;
    const cooldownMs = cooldownDays * 24 * 60 * 60 * 1000;

    if (
      dailySpinLock &&
      (dailySpinLock.dateKey === todayKey ||
        (dailySpinLock.timestamp && Date.now() - dailySpinLock.timestamp < cooldownMs))
    ) {
      setWonSpinSlice(dailySpinLock.reward);
      if (dailySpinLock.used) {
        setClaimedSpinReward(null);
        setSpinFormError(
          `আপনি ইতিমধ্যে ১টি অর্ডারে এই স্পিন অফারটি (${dailySpinLock.reward.label}) ব্যবহার করেছেন! স্পিন অফার শুধুমাত্র ১টি অর্ডারেই প্রযোজ্য।`
        );
      } else {
        setClaimedSpinReward(dailySpinLock.reward);
        setSpinFormError(
          `আপনি ইতিমধ্যে স্পিন করে "${dailySpinLock.reward.label}" জিতেছেন! আপনার অফারটি ল্যান্ডিং পেজ অর্ডারে যুক্ত আছে।`
        );
      }
      return;
    }

    const cleanName = spinCustomerName.trim();
    const cleanPhone = normalizeBdPhone(spinCustomerPhone);

    if (!cleanName || cleanName.length < 2) {
      setSpinFormError('অনগ্রহ করে আপনার পূর্ণ নাম লিখুন');
      return;
    }

    if (!isValidBdPhone11(cleanPhone)) {
      setSpinFormError('সঠিক ১১ ডিজিটের মোবাইল নাম্বার দিন (যেমন: 017XXXXXXXX)');
      return;
    }

    const alreadySpunByPhone = storedSpinLeads.find(lead => {
      if (normalizeBdPhone(lead.customerPhone || lead.phone || '') !== cleanPhone) return false;
      if ((lead.spinDateKey || lead.dateKey) === todayKey) return true;
      const leadTime = new Date(lead.createdAt).getTime();
      return !Number.isNaN(leadTime) && Date.now() - leadTime < cooldownMs;
    });

    if (alreadySpunByPhone) {
      const leadSpunMs = new Date(alreadySpunByPhone.createdAt).getTime();
      const usedOrder = onlineOrders.find(o => {
        if (o.orderStatus === 'cancelled') return false;
        if (normalizeBdPhone(o.customerPhone) !== cleanPhone) return false;
        const hasSpinOffer =
          (o.discountAmount || 0) > 0 ||
          Boolean(o.deliveryArea && o.deliveryArea.includes('Spin Wheel')) ||
          Boolean(o.notes && o.notes.includes('স্পিন হুইল অফার'));
        if (!hasSpinOffer) return false;
        if (!Number.isNaN(leadSpunMs)) {
          const ordMs = new Date(o.createdAt).getTime();
          if (!Number.isNaN(ordMs) && ordMs + 5000 < leadSpunMs) return false;
        }
        return true;
      });
      if (usedOrder || dailySpinLock?.used) {
        setClaimedSpinReward(null);
        setSpinFormError(
          'এই মোবাইল নাম্বার দিয়ে জেতা স্পিন অফারটি ইতিমধ্যে ১টি অর্ডারে ব্যবহার করা হয়েছে! (স্পিন অফার শুধুমাত্র ১টি অর্ডারেই প্রযোজ্য)'
        );
      } else {
        setSpinFormError('এই মোবাইল নাম্বার দিয়ে ইতিমধ্যে স্পিন করা হয়েছে! আপনার অফারটি অর্ডারে প্রযোজ্য হবে।');
      }
      return;
    }

    const totalSlices = spinWheelSlices.length;
    if (totalSlices === 0) return;

    // Pick winning slice ONLY from unlocked slices (4 unlocked winnable offers; 2 locked teaser offers are never landed on)
    const unlockedWinnableIndices = spinWheelSlices
      .map((s, idx) => (!s.locked && s.type !== 'none' ? idx : -1))
      .filter(idx => idx !== -1);
    const unlockedAnyIndices = spinWheelSlices
      .map((s, idx) => (!s.locked ? idx : -1))
      .filter(idx => idx !== -1);
    const candidatePool =
      unlockedWinnableIndices.length > 0
        ? unlockedWinnableIndices
        : unlockedAnyIndices.length > 0
          ? unlockedAnyIndices
          : spinWheelSlices.map((_, i) => i);
    const targetIdx = candidatePool[Math.floor(Math.random() * candidatePool.length)];
    const sliceDeg = 360 / totalSlices;
    const targetSliceCenterDeg = targetIdx * sliceDeg + sliceDeg / 2;
    const extraSpins = 6 * 360;
    const currentMod = wheelRotation % 360;
    const nextRotation =
      wheelRotation + extraSpins + (360 - targetSliceCenterDeg - currentMod);

    setIsSpinning(true);
    setWheelRotation(nextRotation);

    // Sync customer to central database immediately
    saveFbCustomerIdentity({ name: cleanName, phone: cleanPhone }, currentBusiness);
    registerOrUpdateOnlineCustomer({
      name: cleanName,
      phone: cleanPhone,
      address: deliveryAddress.trim() || ''
    }).catch(() => {});

    window.setTimeout(() => {
      const won = spinWheelSlices[targetIdx];
      setIsSpinning(false);
      setWonSpinSlice(won);
      const nowIso = new Date().toISOString();

      const newLead: SpinWheelLead = {
        id: `lp_spin_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        name: cleanName,
        phone: cleanPhone,
        prizeId: won.id,
        prizeLabel: `${won.label} (Landing: ${product.nameBn})`,
        prizeCode: won.code,
        dateKey: todayKey,
        customerName: cleanName,
        customerPhone: cleanPhone,
        rewardLabel: `${won.label} (Landing: ${product.nameBn})`,
        rewardType: won.type,
        rewardValue: won.value,
        couponCode: won.code,
        spinDateKey: todayKey,
        source: 'landing',
        landingProductId: product.id,
        landingProductName: product.nameBn,
        createdAt: nowIso
      };

      const lockData = {
        dateKey: todayKey,
        timestamp: Date.now(),
        name: cleanName,
        phone: cleanPhone,
        reward: won
      };

      setDailySpinLock(lockData);
      setClaimedSpinReward(won);

      // Auto-fill Landing Page Checkout Form Name & Phone if empty
      setCustomerName(prev => (prev.trim() === '' ? cleanName : prev));
      setCustomerPhone(prev => (prev.trim() === '' ? cleanPhone : prev));

      try {
        window.localStorage.setItem('lp_spin_daily_lock_v1', JSON.stringify(lockData));
        window.localStorage.setItem('lp_spin_reward_v1', JSON.stringify(won));
        window.localStorage.setItem(
          'lp_spin_popup_state_v1',
          JSON.stringify({ lastShownAt: Date.now(), completed: true })
        );
        const existingRaw = window.localStorage.getItem('lp_spin_wheel_leads_v1');
        const existingArr: SpinWheelLead[] = existingRaw ? JSON.parse(existingRaw) : [];
        const updatedLeads = [newLead, ...existingArr.filter(l => l.id !== newLead.id)];
        window.localStorage.setItem('lp_spin_wheel_leads_v1', JSON.stringify(updatedLeads));

        const bizLeads = Array.isArray(currentBusiness.landingSpinWheelLeads)
          ? currentBusiness.landingSpinWheelLeads
          : [];
        updateBusiness({
          landingSpinWheelLeads: [newLead, ...bizLeads.filter(l => l.id !== newLead.id)]
        });
      } catch {
        // ignore storage errors
      }

      showToast(`অভিনন্দন ${cleanName}! আপনি জিতেছেন: ${won.label}`, 'success');
    }, 4200);
  };

  const handleClaimSpinReward = () => {
    if (!wonSpinSlice) return;
    if (dailySpinLock?.used) {
      setClaimedSpinReward(null);
      setShowSpinModal(false);
      showToast('আপনার স্পিন অফারটি ইতিমধ্যে ১টি অর্ডারে ব্যবহৃত হয়েছে!', 'info');
      return;
    }
    setClaimedSpinReward(wonSpinSlice);
    try {
      window.localStorage.setItem('lp_spin_reward_v1', JSON.stringify(wonSpinSlice));
    } catch {
      // ignore
    }
    setShowSpinModal(false);
    showToast(
      `কুপন "${wonSpinSlice.code}" (${wonSpinSlice.label}) অর্ডার ফর্মে যুক্ত হয়েছে!`,
      'success'
    );
    scrollToOrderForm();
  };

  const handleResetLandingSpinLockForAdmin = () => {
    setDailySpinLock(null);
    setWonSpinSlice(null);
    setClaimedSpinReward(null);
    setSpinFormError('');
    try {
      window.localStorage.removeItem('lp_spin_daily_lock_v1');
      window.localStorage.removeItem('lp_spin_reward_v1');
      window.localStorage.removeItem('lp_spin_popup_state_v1');
    } catch {
      // ignore
    }
    showToast('ল্যান্ডিং পেজের স্পিন হুইল লক ও পপআপ রিসেট হয়েছে! এখন আবার টেস্ট স্পিন করতে পারবেন।', 'info');
  };

  const handleDeleteSpinLead = (leadId: string) => {
    try {
      const targetLead = storedSpinLeads.find(l => l.id === leadId);
      const updated = storedSpinLeads.filter(l => l.id !== leadId);
      const nextDeletedIds = Array.from(
        new Set([...(currentBusiness.deletedSpinLeadIds || []), leadId])
      );
      window.localStorage.setItem('lp_spin_wheel_leads_v1', JSON.stringify(updated));
      updateBusiness({
        landingSpinWheelLeads: updated,
        deletedSpinLeadIds: nextDeletedIds
      });
      if (
        targetLead &&
        dailySpinLock &&
        normalizeBdPhone(dailySpinLock.phone) ===
          normalizeBdPhone(targetLead.customerPhone || targetLead.phone || '')
      ) {
        setDailySpinLock(null);
        setWonSpinSlice(null);
        setClaimedSpinReward(null);
        window.localStorage.removeItem('lp_spin_daily_lock_v1');
        window.localStorage.removeItem('lp_spin_reward_v1');
        window.localStorage.removeItem('lp_spin_popup_state_v1');
      }
      showToast('স্পিন হুইল এন্ট্রি মুছে ফেলা হয়েছে', 'info');
    } catch {
      // ignore
    }
  };

  // Automatically consume & clear Landing Page Spin Wheel reward if an order has already used it (1-Order Limit)
  useEffect(() => {
    if (!claimedSpinReward) return;
    if (dailySpinLock?.used) {
      setClaimedSpinReward(null);
      try {
        window.localStorage.removeItem('lp_spin_reward_v1');
      } catch {
        // ignore
      }
      return;
    }

    const spinPhone = normalizeBdPhone(dailySpinLock?.phone || customerPhone || '');
    const spunTimeMs = dailySpinLock?.timestamp || 0;

    const alreadyUsedOrder = onlineOrders.find(o => {
      if (o.orderStatus === 'cancelled') return false;
      const hasSpinNote = Boolean(o.notes && o.notes.includes('স্পিন হুইল অফার'));
      if (!hasSpinNote) return false;
      if (spinPhone && isValidBdPhone11(spinPhone)) {
        if (normalizeBdPhone(o.customerPhone) !== spinPhone) return false;
      }
      if (spunTimeMs > 0) {
        const orderTimeMs = new Date(o.createdAt).getTime();
        if (!Number.isNaN(orderTimeMs) && orderTimeMs + 5000 < spunTimeMs) return false;
      }
      return true;
    });

    if (alreadyUsedOrder) {
      setClaimedSpinReward(null);
      try {
        window.localStorage.removeItem('lp_spin_reward_v1');
      } catch {
        // ignore
      }
      if (dailySpinLock && !dailySpinLock.used) {
        const updatedLock = {
          ...dailySpinLock,
          used: true,
          usedOrderNo: alreadyUsedOrder.orderNo
        };
        setDailySpinLock(updatedLock);
        try {
          window.localStorage.setItem('lp_spin_daily_lock_v1', JSON.stringify(updatedLock));
        } catch {
          // ignore
        }
      }
    }
  }, [claimedSpinReward, dailySpinLock, customerPhone, onlineOrders]);

  // Calculate active Landing Page Spin the Wheel discount (Strictly 1 Order Only)
  const spinDiscountAmount = useMemo(() => {
    if (!spinWheelEnabled || !claimedSpinReward || dailySpinLock?.used) return 0;
    if (claimedSpinReward.type === 'flat') {
      return Math.min(subtotal, claimedSpinReward.value);
    }
    if (claimedSpinReward.type === 'percent') {
      return Math.round((subtotal * claimedSpinReward.value) / 100);
    }
    return 0;
  }, [spinWheelEnabled, claimedSpinReward, dailySpinLock?.used, subtotal]);

  const isSpinFreeDelivery = Boolean(
    spinWheelEnabled && !dailySpinLock?.used && claimedSpinReward?.type === 'free_delivery'
  );

  const rawInsideDhakaFee =
    currentBusiness.insideDhakaDeliveryCharge ?? currentBusiness.ecommerceDeliveryCharge ?? 60;
  const rawOutsideDhakaFee = currentBusiness.outsideDhakaDeliveryCharge ?? 120;

  // Offer #4: Half Delivery Charge (50% Delivery Discount Campaign)
  const isHalfDeliveryOfferEnabled = Boolean(currentBusiness.halfDeliveryOfferEnabled);
  const deliveryDiscountPct = Math.min(
    99,
    Math.max(10, Number(currentBusiness.deliveryDiscountPercent ?? 50))
  );
  const insideDhakaFee = isHalfDeliveryOfferEnabled
    ? Math.max(0, Math.round(rawInsideDhakaFee * (1 - deliveryDiscountPct / 100)))
    : rawInsideDhakaFee;
  const outsideDhakaFee = isHalfDeliveryOfferEnabled
    ? Math.max(0, Math.round(rawOutsideDhakaFee * (1 - deliveryDiscountPct / 100)))
    : rawOutsideDhakaFee;
  const selectedRawZoneFee =
    selectedDeliveryZone === 'outside_dhaka' ? rawOutsideDhakaFee : rawInsideDhakaFee;

  // Offer #7: Happy Hour / Flash Free Delivery Timer Window
  const [flashNowMs, setFlashNowMs] = useState<number>(() => Date.now());
  useEffect(() => {
    if (!currentBusiness.flashFreeDeliveryEnabled) return;
    const timer = window.setInterval(() => {
      setFlashNowMs(Date.now());
    }, 1000);
    return () => window.clearInterval(timer);
  }, [currentBusiness.flashFreeDeliveryEnabled]);

  const { isFlashFreeDeliveryActive, flashCountdownLabelBn } = useMemo(() => {
    if (!currentBusiness.flashFreeDeliveryEnabled) {
      return { isFlashFreeDeliveryActive: false, flashCountdownLabelBn: '' };
    }
    let remainingMs = 0;

    if (currentBusiness.flashFreeDeliveryScheduleEnabled) {
      const startStr = (currentBusiness.flashFreeDeliveryStartHour || '21:00').trim();
      const endStr = (currentBusiness.flashFreeDeliveryEndHour || '23:59').trim();
      const [startH = 21, startM = 0] = startStr.split(':').map(Number);
      const [endH = 23, endM = 59] = endStr.split(':').map(Number);
      const nowDate = new Date(flashNowMs);
      const curMins = nowDate.getHours() * 60 + nowDate.getMinutes();
      const startMins = startH * 60 + startM;
      const endMins = endH * 60 + endM;

      let inSchedule = false;
      let targetEndDate = new Date(flashNowMs);
      if (startMins <= endMins) {
        if (curMins >= startMins && curMins <= endMins) {
          inSchedule = true;
          targetEndDate.setHours(endH, endM, 59, 999);
        }
      } else {
        if (curMins >= startMins) {
          inSchedule = true;
          targetEndDate.setDate(targetEndDate.getDate() + 1);
          targetEndDate.setHours(endH, endM, 59, 999);
        } else if (curMins <= endMins) {
          inSchedule = true;
          targetEndDate.setHours(endH, endM, 59, 999);
        }
      }
      if (inSchedule) {
        remainingMs = Math.max(0, targetEndDate.getTime() - flashNowMs);
      }
    } else if (currentBusiness.flashFreeDeliveryEndTime) {
      const endTs = new Date(currentBusiness.flashFreeDeliveryEndTime).getTime();
      if (Number.isFinite(endTs) && endTs > flashNowMs) {
        remainingMs = endTs - flashNowMs;
      }
    }

    if (remainingMs <= 0) {
      return { isFlashFreeDeliveryActive: false, flashCountdownLabelBn: '' };
    }

    const totalSec = Math.floor(remainingMs / 1000);
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    const pad2 = (n: number) => toBanglaDigitsLpStatic(String(n).padStart(2, '0'));
    const label =
      hrs > 0
        ? `${pad2(hrs)} ঘণ্টা ${pad2(mins)} মিনিট ${pad2(secs)} সেকেন্ড`
        : `${pad2(mins)} মিনিট ${pad2(secs)} সেকেন্ড`;

    return {
      isFlashFreeDeliveryActive: true,
      flashCountdownLabelBn: label,
    };
  }, [
    currentBusiness.flashFreeDeliveryEnabled,
    currentBusiness.flashFreeDeliveryEndTime,
    currentBusiness.flashFreeDeliveryScheduleEnabled,
    currentBusiness.flashFreeDeliveryStartHour,
    currentBusiness.flashFreeDeliveryEndHour,
    flashNowMs,
  ]);

  // Offer #1: Minimum Order Amount Free Delivery + Live Progress Bar
  const isMinAmountFreeDeliveryEnabled = Boolean(currentBusiness.freeDeliveryByMinAmountEnabled);
  const freeDeliveryMinOrderAmt = Math.max(
    100,
    Number(currentBusiness.freeDeliveryMinOrder || 1500)
  );
  const isMinAmountFreeDeliveryUnlocked =
    isMinAmountFreeDeliveryEnabled && subtotal >= freeDeliveryMinOrderAmt;
  const remainingAmtForFreeDelivery = Math.max(0, freeDeliveryMinOrderAmt - subtotal);
  const minAmountProgressPct = isMinAmountFreeDeliveryEnabled
    ? Math.min(100, Math.round((subtotal / freeDeliveryMinOrderAmt) * 100))
    : 0;

  // Offer #6: Product-Specific Free Delivery Badge & Rule
  const isProductSpecificFreeDeliveryOnLp =
    currentBusiness.productSpecificFreeDeliveryEnabled !== false &&
    Boolean(
      checkoutTargetProduct.freeDelivery ||
        product.freeDelivery ||
        product.freeDeliveryOnLanding
    );

  // Smart Quantity-Based Free Delivery ("২ পিস বা ৩ পিস কিনলে ডেলিভারি ফ্রি")
  // Respects product-level override first, then global landing/website settings
  const isQtyFreeDeliveryEnabled =
    product.landingFreeDeliveryByQtyEnabled !== undefined
      ? Boolean(product.landingFreeDeliveryByQtyEnabled)
      : currentBusiness.landingFreeDeliveryByQtyEnabled !== undefined
      ? Boolean(currentBusiness.landingFreeDeliveryByQtyEnabled)
      : Boolean(currentBusiness.freeDeliveryByQtyEnabled);
  const freeDeliveryMinQty = Math.max(
    2,
    Number(
      product.landingFreeDeliveryMinQty ||
        currentBusiness.landingFreeDeliveryMinQty ||
        currentBusiness.freeDeliveryMinQty ||
        2
    )
  );
  const isQtyFreeDeliveryUnlocked =
    isQtyFreeDeliveryEnabled && effectiveOrderQuantity >= freeDeliveryMinQty;
  const remainingQtyForFreeDelivery = Math.max(0, freeDeliveryMinQty - effectiveOrderQuantity);

  const isFreeDelivery =
    Boolean(currentBusiness.freeDeliveryEnabled) ||
    isProductSpecificFreeDeliveryOnLp ||
    isSpinFreeDelivery ||
    isQtyFreeDeliveryUnlocked ||
    isMinAmountFreeDeliveryUnlocked ||
    isFlashFreeDeliveryActive;
  const deliveryCharge = isFreeDelivery
    ? 0
    : selectedDeliveryZone === 'outside_dhaka'
    ? outsideDhakaFee
    : insideDhakaFee;
  const grandTotal = Math.max(0, subtotal - spinDiscountAmount) + deliveryCharge;

  // Stock Out Badge Design Style (Shared with Storefront + 1-click switchable)
  const stockOutBadgeStyle: StockOutBadgeDesign =
    currentBusiness.stockOutBadgeStyle || 'center_glass';

  // Available Stock (respects manual product isOutOfStock and all-variations outOfStock)
  const availableStock = useMemo(() => {
    if (checkoutTargetProduct.isOutOfStock) return 0;
    if (
      Array.isArray(checkoutTargetProduct.variants) &&
      checkoutTargetProduct.variants.length > 0 &&
      checkoutTargetProduct.variants.every(v => Boolean(v.outOfStock))
    ) {
      return 0;
    }
    const branchStock = checkoutTargetProduct.stockByOutlet['outlet_01'] ?? 0;
    const totalStock = Object.values(checkoutTargetProduct.stockByOutlet).reduce(
      (s, q) => s + (q || 0),
      0
    );
    return Math.max(branchStock, totalStock);
  }, [
    checkoutTargetProduct.isOutOfStock,
    checkoutTargetProduct.variants,
    checkoutTargetProduct.stockByOutlet
  ]);

  // Gallery Images (Exclude empty strings & broken demo Unsplash URLs so product image never renders blank white)
  const galleryImages = useMemo(() => {
    const list = [
      product.image,
      ...(Array.isArray(product.galleryImages) ? product.galleryImages : []),
      ...(Array.isArray(product.variants) ? product.variants.map(v => v.imageUrl) : [])
    ].filter((u): u is string =>
      Boolean(
        u &&
          u.trim() !== '' &&
          !u.includes('images.unsplash.com/photo-1599599810769') &&
          !u.includes('images.unsplash.com/photo-1607623814075') &&
          !u.includes('images.unsplash.com/photo-1509440159596')
      )
    );
    return Array.from(new Set(list));
  }, [product.image, product.galleryImages, product.variants]);

  const safeLpGalleryIdx =
    galleryImages.length > 0 ? activeGalleryIdx % galleryImages.length : 0;

  // Description Bullet Points
  const highlightPoints = useMemo(() => {
    const raw = (product.description || '').trim();
    if (!raw) {
      return [
        '১০০% অরিজিনাল ও প্রিমিয়াম কোয়ালিটি পণ্যের নিশ্চয়তা',
        'সারা বাংলাদেশে দ্রুত হোম ডেলিভারি সুবিধা',
        'পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধের সুবিধা (Cash on Delivery)'
      ];
    }
    return raw
      .split(/\n+/)
      .map(line => line.replace(/^[•✓✔*-]\s*/, '').trim())
      .filter(Boolean);
  }, [product.description]);

  // Customizable Product-Specific Texts (Badge, Variation Heading, Optional Highlights Heading)
  const badgeText =
    product.landingBadgeText !== undefined
      ? product.landingBadgeText.trim()
      : '১০০% প্রিমিয়াম ও অরিজিনাল প্রোডাক্ট';

  const variantHeadingText =
    product.landingVariantTitle && product.landingVariantTitle.trim() !== ''
      ? product.landingVariantTitle.trim()
      : 'পছন্দের সাইজ / বয়স নির্বাচন করুন:';

  // Variation Switcher Design & Optional Price Display (Default: 'classic_radio_list' on LP-1, 'lp2_red_measurement_grid' on LP-2)
  const variantStyle: LandingVariantDesign = isTemplate2
    ? product.landingVariantStyle || 'lp2_red_measurement_grid'
    : product.landingVariantStyle ||
      currentBusiness.landingVariantStyle ||
      'classic_radio_list';
  const showVariantPrice: boolean =
    product.landingVariantShowPrice ??
    currentBusiness.landingVariantShowPrice ??
    false;
  const showVariantMeasurement: boolean =
    product.landingVariantShowMeasurement ??
    currentBusiness.landingVariantShowMeasurement ??
    true;
  const currentVariantStyleObj =
    LANDING_VARIANT_DESIGN_OPTIONS.find(o => o.id === variantStyle) ||
    LANDING_VARIANT_DESIGN_OPTIONS[0];

  // Landing Page 2 Showcase Card Bottom-Left Overlay Button ("সাইজ পছন্দ করুন →") ON/OFF & Editable Text + Mobile 2-Column Layout Toggle
  const showShowcaseSelectBtn: boolean = product.landingShowcaseSelectBtnEnabled !== false;
  const showcaseMobileTwoCols: boolean = Boolean(product.landingShowcaseMobileTwoCols);
  const showcaseSelectBtnText: string =
    product.landingShowcaseSelectBtnText && product.landingShowcaseSelectBtnText.trim() !== ''
      ? product.landingShowcaseSelectBtnText.trim()
      : 'সাইজ পছন্দ করুন';
  const [isEditingShowcaseSelectBtn, setIsEditingShowcaseSelectBtn] = useState<boolean>(false);
  const [draftShowcaseSelectBtnText, setDraftShowcaseSelectBtnText] = useState<string>(showcaseSelectBtnText);

  useEffect(() => {
    setDraftShowcaseSelectBtnText(showcaseSelectBtnText);
  }, [showcaseSelectBtnText]);

  // Product Image % Discount Badge (ON/OFF & 6 Design Styles)
  const showImageDiscountBadge: boolean =
    product.landingImageBadgeEnabled ??
    currentBusiness.landingImageBadgeEnabled ??
    true;
  const imageBadgeStyle: LandingImageBadgeDesign =
    product.landingImageBadgeStyle ||
    currentBusiness.landingImageBadgeStyle ||
    'classic_red';
  const currentImageBadgeStyleObj =
    LANDING_IMAGE_BADGE_DESIGN_OPTIONS.find(o => o.id === imageBadgeStyle) ||
    LANDING_IMAGE_BADGE_DESIGN_OPTIONS[0];

  // Product Details / Fabric & Features Section (ON/OFF + Editable Texts & Topics)
  const showFeaturesSection = product.landingFeaturesEnabled !== false;
  const showFeaturesBadge = product.landingFeaturesBadgeEnabled !== false;
  const featuresBadgeText =
    product.landingFeaturesBadgeText !== undefined
      ? product.landingFeaturesBadgeText.trim()
      : 'প্রিমিয়াম কোয়ালিটি গ্যারান্টি';
  const showFeaturesHeading = product.landingHighlightsTitleEnabled !== false;
  const highlightsHeadingText =
    product.landingHighlightsTitle !== undefined && product.landingHighlightsTitle.trim() !== ''
      ? product.landingHighlightsTitle.trim()
      : 'ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস:';

  // Trust & Guarantee Topics Section (ON/OFF + Editable Heading & Topics)
  const showTrustSection = product.landingTrustSectionEnabled !== false;
  const showTrustBadge = product.landingTrustBadgeEnabled !== false;
  const trustBadgeText =
    product.landingTrustBadgeText !== undefined
      ? product.landingTrustBadgeText.trim()
      : '১০০% বিশ্বস্ত ও নিরাপদ শপিং';
  const trustHeadingText =
    product.landingTrustTitle !== undefined && product.landingTrustTitle.trim() !== ''
      ? product.landingTrustTitle.trim()
      : 'কেন আমাদের থেকে নিশ্চিন্তে অর্ডার করবেন?';
  const activeTrustItems: LandingTrustItem[] = useMemo(() => {
    const rawList =
      Array.isArray(product.landingTrustItems) && product.landingTrustItems.length > 0
        ? product.landingTrustItems
        : DEFAULT_LANDING_TRUST_ITEMS;
    return rawList.filter(
      item =>
        item.enabled !== false &&
        ((item.title || '').trim() !== '' || (item.description || '').trim() !== '')
    );
  }, [product.landingTrustItems]);

  // Top Animated Heading Before Product Image (ON/OFF + Animation ON/OFF + Theme & Style)
  const showTopHeading = product.landingTopHeadingEnabled !== false;
  const isTopHeadingAnimated = product.landingTopHeadingAnimation !== false;
  const topHeadingTheme = product.landingTopHeadingTheme || 'emerald';
  const topHeadingAnimStyle = product.landingTopHeadingAnimStyle || 'shimmer';

  const topHeadingSubtext =
    product.landingTopHeadingSubtext !== undefined
      ? product.landingTopHeadingSubtext.trim()
      : discountPercent > 0
      ? `সীমিত সময়ের মেগা অফার • ${discountPercent}% বিশেষ ছাড় চলছে!`
      : '১০০% অরিজিনাল ও প্রিমিয়াম কোয়ালিটির নিশ্চয়তা';

  const topHeadingText =
    product.landingTopHeadingText && product.landingTopHeadingText.trim() !== ''
      ? product.landingTopHeadingText.trim()
      : `${product.nameBn} — আজকের স্পেশাল অফারে অর্ডার করুন!`;

  const topHeadingAnimClass = !isTopHeadingAnimated
    ? ''
    : topHeadingAnimStyle === 'bounce'
    ? 'animate-lp-heading-bounce'
    : '';

  const topHeadingThemeClasses =
    topHeadingTheme === 'crimson'
      ? {
          container: 'bg-rose-50/40 border-b border-rose-100/90',
          subtext: 'text-rose-700',
          dot: 'bg-rose-600',
          dotPing: 'bg-rose-400',
          title: 'text-[#991B1B]',
          underline: 'bg-rose-600'
        }
      : topHeadingTheme === 'midnight'
      ? {
          container: 'bg-slate-50/90 border-b border-slate-200/80',
          subtext: 'text-slate-600',
          dot: 'bg-slate-800',
          dotPing: 'bg-slate-400',
          title: 'text-slate-900',
          underline: 'bg-slate-800'
        }
      : topHeadingTheme === 'light'
      ? {
          container: 'bg-white border-b border-slate-100',
          subtext: 'text-emerald-700',
          dot: 'bg-emerald-600',
          dotPing: 'bg-emerald-400',
          title: 'text-slate-900',
          underline: 'bg-emerald-600'
        }
      : {
          container: 'bg-emerald-50/35 border-b border-emerald-100/80',
          subtext: 'text-emerald-700',
          dot: 'bg-emerald-600',
          dotPing: 'bg-emerald-400',
          title: 'text-emerald-950',
          underline: 'bg-emerald-600'
        };

  // Evergreen Looping Countdown Timer (Default 9 Hours -> counts down to 0 -> auto restarts from 9 Hours)
  const showCountdown = product.landingCountdownEnabled !== false;
  const countdownHours =
    product.landingCountdownHours && product.landingCountdownHours > 0
      ? product.landingCountdownHours
      : 9;
  const countdownTitle =
    product.landingCountdownTitle !== undefined && product.landingCountdownTitle.trim() !== ''
      ? product.landingCountdownTitle.trim()
      : 'স্পেশাল অফার শেষ হতে বাকি:';
  const countdownPosition = product.landingCountdownPosition || 'hero_info';

  const cycleTotalSeconds = Math.max(60, Math.round(countdownHours * 3600));
  const toBanglaDigits = toBanglaDigitsLpStatic;

  // Scarcity Stock & High-Demand Urgency Banner ("অফার মূল্যে আর মাত্র 10 টি বাকি আছে!" + "প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে" + "সীমিত স্টক")
  const showLandingScarcity = product.landingScarcityEnabled !== false;
  const scarcityLeftCount =
    product.landingScarcityCount && product.landingScarcityCount > 0
      ? product.landingScarcityCount
      : 10;
  const scarcityProgressPercent = Math.min(
    92,
    Math.max(68, 100 - scarcityLeftCount * 2)
  );

  // 1. Product Video / YouTube / Reels Section (ON/OFF + URL + Title)
  const showVideoSection = product.landingVideoEnabled !== false;
  const videoSectionTitle =
    product.landingVideoTitle !== undefined && product.landingVideoTitle.trim() !== ''
      ? product.landingVideoTitle.trim()
      : 'প্রোডাক্টটির লাইভ ভিডিও ও কোয়ালিটি দেখুন:';
  const videoSectionSubtitle =
    product.landingVideoSubtitle !== undefined
      ? product.landingVideoSubtitle.trim()
      : '১০০% অরিজিনাল প্রোডাক্টের রিয়েল ভিডিও শোকেস';
  const rawVideoUrl = (product.landingVideoUrl || '').trim();
  const videoEmbedInfo = useMemo(() => resolveLandingVideoEmbed(rawVideoUrl), [rawVideoUrl]);

  // Interactive Reel Slideshow state when no external video link is set yet
  const [isReelPlaying, setIsReelPlaying] = useState<boolean>(true);
  const [reelSlideIdx, setReelSlideIdx] = useState<number>(0);

  useEffect(() => {
    if (!showVideoSection || videoEmbedInfo.type !== 'none' || !isReelPlaying || Boolean(confirmedOrder)) return;
    if (galleryImages.length <= 1) return;
    const id = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setReelSlideIdx(prev => (prev + 1) % galleryImages.length);
    }, 2800);
    return () => window.clearInterval(id);
  }, [showVideoSection, videoEmbedInfo.type, isReelPlaying, galleryImages.length, confirmedOrder]);

  // 2. Size Chart / Measurement Guide Section & Popup Modal (Separate ON/OFF for Variation Popup vs Full Body Chart + Inline Editor)
  const showSizeChart = product.landingSizeChartEnabled !== false;
  const showBodySizeChart = product.landingBodySizeChartEnabled !== false;
  const sizeChartTitle =
    product.landingSizeChartTitle !== undefined && product.landingSizeChartTitle.trim() !== ''
      ? product.landingSizeChartTitle.trim()
      : 'সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):';
  const sizeChartSubtitle =
    product.landingSizeChartSubtitle !== undefined
      ? product.landingSizeChartSubtitle.trim()
      : 'সঠিক সাইজ নির্বাচন করতে নিচের মাপগুলো দেখে নিন';
  const sizeChartHeaders: [string, string, string] =
    Array.isArray(product.landingSizeChartHeaders) && product.landingSizeChartHeaders.length === 3
      ? product.landingSizeChartHeaders
      : DEFAULT_LANDING_SIZE_CHART_HEADERS;
  const sizeChartRows: LandingSizeChartRow[] = useMemo(() => {
    if (Array.isArray(product.landingSizeChartRows) && product.landingSizeChartRows.length > 0) {
      return product.landingSizeChartRows.filter(
        r => (r.size || '').trim() !== '' || (r.chest || '').trim() !== '' || (r.length || '').trim() !== ''
      );
    }
    return DEFAULT_LANDING_SIZE_CHART_ROWS;
  }, [product.landingSizeChartRows]);
  const sizeChartImage = (product.landingSizeChartImage || '').trim();
  const [showSizeChartModal, setShowSizeChartModal] = useState<boolean>(false);

  // Helper to resolve clean size measurement text (e.g., "বুক: ২২ ইঞ্চি, লম্বা: ১৮ ইঞ্চি" or 'বুক: ৩৮", লম্বা: ৪২"') without duplicate quotes
  const getVariantMeasurementText = (variantLabel: string, vIdx: number): string => {
    const matchedChartRow =
      sizeChartRows.find(r => {
        const rowSize = (r.size || '').trim().toLowerCase();
        return rowSize !== '' && variantLabel.toLowerCase().includes(rowSize);
      }) || sizeChartRows[vIdx];
    const formatMeasureVal = (val?: string) => {
      const trimmed = (val || '').trim();
      if (!trimmed) return '';
      return trimmed.includes('"') || trimmed.includes('ইঞ্চি') ? trimmed : `${trimmed}"`;
    };
    if (matchedChartRow && (matchedChartRow.chest || matchedChartRow.length)) {
      const parts: string[] = [];
      const chestStr = formatMeasureVal(matchedChartRow.chest);
      const lengthStr = formatMeasureVal(matchedChartRow.length);
      if (chestStr) parts.push(`বুক: ${chestStr}`);
      if (lengthStr) parts.push(`লম্বা: ${lengthStr}`);
      if (parts.length > 0) return parts.join(', ');
    }
    const defaultMeasurements = [
      'বুক: ৩৮", লম্বা: ৪২"',
      'বুক: ৪০", লম্বা: ৪৩"',
      'বুক: ৪২", লম্বা: ৪৪"',
      'বুক: ৪৪", লম্বা: ৪৫"'
    ];
    return defaultMeasurements[vIdx % defaultMeasurements.length];
  };

  // Inline Body Size Chart Admin Editor States (like Product Page inline description Size Chart)
  const [isEditingBodySizeChart, setIsEditingBodySizeChart] = useState<boolean>(false);
  const [draftBodyChartTitle, setDraftBodyChartTitle] = useState<string>(sizeChartTitle);
  const [draftBodyChartSubtitle, setDraftBodyChartSubtitle] = useState<string>(sizeChartSubtitle);
  const [draftBodyChartHeaders, setDraftBodyChartHeaders] = useState<[string, string, string]>(sizeChartHeaders);
  const [draftBodyChartRows, setDraftBodyChartRows] = useState<LandingSizeChartRow[]>(sizeChartRows);

  useEffect(() => {
    setDraftBodyChartTitle(sizeChartTitle);
    setDraftBodyChartSubtitle(sizeChartSubtitle);
    setDraftBodyChartHeaders(sizeChartHeaders);
    setDraftBodyChartRows(sizeChartRows);
  }, [product.id, sizeChartTitle, sizeChartSubtitle, sizeChartHeaders, sizeChartRows]);

  const handleSaveBodySizeChartDraft = () => {
    const cleanedRows = draftBodyChartRows.filter(
      r => r.size.trim() !== '' || r.chest.trim() !== '' || r.length.trim() !== ''
    );
    updateProduct(product.id, {
      landingSizeChartTitle: draftBodyChartTitle.trim() || 'সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):',
      landingSizeChartSubtitle: draftBodyChartSubtitle.trim(),
      landingSizeChartHeaders: [
        draftBodyChartHeaders[0].trim() || 'সাইজ / বয়স',
        draftBodyChartHeaders[1].trim() || 'বডি / চেস্ট (ইঞ্চি)',
        draftBodyChartHeaders[2].trim() || 'লম্বা / দৈর্ঘ্য (ইঞ্চি)'
      ],
      landingSizeChartRows: cleanedRows.length > 0 ? cleanedRows : DEFAULT_LANDING_SIZE_CHART_ROWS
    });
    setIsEditingBodySizeChart(false);
    showToast('ল্যান্ডিং পেজের সাইজ চার্ট সফলভাবে সেভ হয়েছে!', 'success');
  };

  const handleLoadBodySizeChartPreset = (presetType: 'clothing' | 'shoe') => {
    if (presetType === 'shoe') {
      const nextHeaders: [string, string, string] = [...DEFAULT_LANDING_SHOE_SIZE_CHART_HEADERS];
      const nextRows = DEFAULT_LANDING_SHOE_SIZE_CHART_ROWS.map(r => ({ ...r }));
      setDraftBodyChartTitle('জুতার সাইজ ও মাপজোখ গাইড (Shoe Size Chart):');
      setDraftBodyChartHeaders(nextHeaders);
      setDraftBodyChartRows(nextRows);
      updateProduct(product.id, {
        landingBodySizeChartEnabled: true,
        landingSizeChartTitle: 'জুতার সাইজ ও মাপজোখ গাইড (Shoe Size Chart):',
        landingSizeChartHeaders: nextHeaders,
        landingSizeChartRows: nextRows
      });
      showToast('জুতার সাইজ চার্ট প্রিসেট লোড হয়েছে!', 'success');
    } else {
      const nextHeaders: [string, string, string] = [...DEFAULT_LANDING_SIZE_CHART_HEADERS];
      const nextRows = DEFAULT_LANDING_SIZE_CHART_ROWS.map(r => ({ ...r }));
      setDraftBodyChartTitle('সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):');
      setDraftBodyChartHeaders(nextHeaders);
      setDraftBodyChartRows(nextRows);
      updateProduct(product.id, {
        landingBodySizeChartEnabled: true,
        landingSizeChartTitle: 'সাইজ চার্ট ও মাপজোখ গাইড (Size Chart):',
        landingSizeChartHeaders: nextHeaders,
        landingSizeChartRows: nextRows
      });
      showToast('পোশাকের সাইজ চার্ট প্রিসেট লোড হয়েছে!', 'success');
    }
  };

  // 3. Live Recent Order Notification Popup (Social Proof — ON/OFF + Configurable Time Gap + Smart Per-Visitor Shuffled & Persistent Rotation)
  const showSocialProof = product.landingSocialProofEnabled !== false;
  const socialProofGapSec =
    typeof product.landingSocialProofIntervalSec === 'number' &&
    product.landingSocialProofIntervalSec >= 2
      ? Math.min(300, Math.round(product.landingSocialProofIntervalSec))
      : 16;
  const socialProofBuyers = useMemo(() => {
    const customList = Array.isArray(product.landingSocialProofCustomEntries)
      ? product.landingSocialProofCustomEntries.map(s => s.trim()).filter(Boolean)
      : [];
    if (customList.length > 0) {
      return customList.map((line, idx) => {
        const parts = line.split('|').map(p => p.trim());
        return {
          name: parts[0] || 'ভেরিফাইড ক্রেতা',
          location: parts[1] || 'ঢাকা',
          timeAgo: parts[2] || `${toBanglaDigits((idx + 1) * 3, 1)} মিনিট আগে`
        };
      });
    }
    return DEFAULT_SOCIAL_PROOF_BUYERS;
  }, [product.landingSocialProofCustomEntries]);

  // Build or restore a per-visitor shuffled order + persistent cursor in localStorage so:
  // 1) Different visitors see different buyer names & locations across Bangladesh
  // 2) If the same visitor reloads or returns later, they immediately see a NEW name (never repeats from item #1)
  const [socialProofOrder, setSocialProofOrder] = useState<number[]>([]);
  const [socialProofCursor, setSocialProofCursor] = useState<number>(0);
  const [isSocialProofVisible, setIsSocialProofVisible] = useState<boolean>(false);
  const [isSocialProofDismissed, setIsSocialProofDismissed] = useState<boolean>(false);

  useEffect(() => {
    const total = socialProofBuyers.length;
    if (total === 0) return;

    const storageKey = `lp_sp_rotation_v2_${product.id}_${total}`;
    const createShuffledIndices = (len: number, avoidFirst?: number): number[] => {
      const arr = Array.from({ length: len }, (_, i) => i);
      for (let i = len - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
      if (avoidFirst !== undefined && len > 1 && arr[0] === avoidFirst) {
        const swapIdx = 1 + Math.floor(Math.random() * (len - 1));
        const tmp = arr[0];
        arr[0] = arr[swapIdx];
        arr[swapIdx] = tmp;
      }
      return arr;
    };

    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw) as { order?: number[]; cursor?: number };
        if (
          Array.isArray(parsed.order) &&
          parsed.order.length === total &&
          typeof parsed.cursor === 'number'
        ) {
          const nextCursor = parsed.cursor + 1;
          if (nextCursor < total) {
            setSocialProofOrder(parsed.order);
            setSocialProofCursor(nextCursor);
            window.localStorage.setItem(
              storageKey,
              JSON.stringify({ order: parsed.order, cursor: nextCursor })
            );
            return;
          } else {
            const lastSeenIdx = parsed.order[total - 1];
            const reshuffled = createShuffledIndices(total, lastSeenIdx);
            setSocialProofOrder(reshuffled);
            setSocialProofCursor(0);
            window.localStorage.setItem(
              storageKey,
              JSON.stringify({ order: reshuffled, cursor: 0 })
            );
            return;
          }
        }
      }

      const freshOrder = createShuffledIndices(total);
      setSocialProofOrder(freshOrder);
      setSocialProofCursor(0);
      window.localStorage.setItem(
        storageKey,
        JSON.stringify({ order: freshOrder, cursor: 0 })
      );
    } catch {
      setSocialProofOrder(createShuffledIndices(total));
      setSocialProofCursor(0);
    }
  }, [product.id, socialProofBuyers.length]);

  useEffect(() => {
    const total = socialProofBuyers.length;
    if (!showSocialProof || isSocialProofDismissed || confirmedOrder || total === 0) {
      setIsSocialProofVisible(false);
      return;
    }

    const storageKey = `lp_sp_rotation_v2_${product.id}_${total}`;
    const visibleDurationMs = 4500;
    const gapDurationMs = Math.max(2000, socialProofGapSec * 1000);
    let activeTimerId: number | undefined;
    let isCancelled = false;

    const scheduleShow = (delayMs: number, advanceCursor: boolean) => {
      activeTimerId = window.setTimeout(() => {
        if (isCancelled) return;
        if (advanceCursor) {
          setSocialProofCursor(prev => {
            const next = (prev + 1) % total;
            try {
              const raw = window.localStorage.getItem(storageKey);
              const parsed = raw ? JSON.parse(raw) : {};
              window.localStorage.setItem(
                storageKey,
                JSON.stringify({
                  order:
                    Array.isArray(parsed.order) && parsed.order.length === total
                      ? parsed.order
                      : socialProofOrder,
                  cursor: next
                })
              );
            } catch {}
            return next;
          });
        }
        setIsSocialProofVisible(true);

        // Hide after visibleDurationMs, then wait gapDurationMs before showing the next notification
        activeTimerId = window.setTimeout(() => {
          if (isCancelled) return;
          setIsSocialProofVisible(false);
          scheduleShow(gapDurationMs, true);
        }, visibleDurationMs);
      }, delayMs);
    };

    scheduleShow(3200, false);

    return () => {
      isCancelled = true;
      if (activeTimerId !== undefined) {
        window.clearTimeout(activeTimerId);
      }
    };
  }, [
    showSocialProof,
    isSocialProofDismissed,
    confirmedOrder,
    product.id,
    socialProofBuyers.length,
    socialProofOrder,
    socialProofGapSec
  ]);

  const resolvedBuyerIndex =
    socialProofOrder.length === socialProofBuyers.length
      ? socialProofOrder[socialProofCursor % Math.max(1, socialProofOrder.length)] ?? 0
      : socialProofCursor % Math.max(1, socialProofBuyers.length);

  const currentSocialProofBuyer =
    socialProofBuyers[resolvedBuyerIndex] || DEFAULT_SOCIAL_PROOF_BUYERS[0];

  // Smart Sticky Floating Button Visibility:
  // Show sticky bottom bar when customer is near the top, and automatically hide it
  // when the actual "অর্ডার কনফার্ম করুন" submit button in the form enters the viewport.
  const mainSubmitBtnRef = useRef<HTMLButtonElement | null>(null);
  const [isMainSubmitVisible, setIsMainSubmitVisible] = useState<boolean>(false);

  useEffect(() => {
    if (confirmedOrder) {
      setIsMainSubmitVisible(true);
      return;
    }

    const btnEl = mainSubmitBtnRef.current;
    if (!btnEl) return;

    let observer: IntersectionObserver | null = null;
    if (typeof IntersectionObserver !== 'undefined') {
      observer = new IntersectionObserver(
        entries => {
          const entry = entries[0];
          if (entry) {
            setIsMainSubmitVisible(entry.isIntersecting);
          }
        },
        {
          root: null,
          threshold: 0.05,
          rootMargin: '0px 0px 30px 0px'
        }
      );
      observer.observe(btnEl);
    }

    const handleScrollCheck = () => {
      if (!mainSubmitBtnRef.current) return;
      const rect = mainSubmitBtnRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      // Hide sticky bar if the real submit button is visible in the viewport or if user scrolled past it
      const inView = rect.top <= windowHeight - 15 && rect.bottom >= 0;
      setIsMainSubmitVisible(inView);
    };

    handleScrollCheck();
    window.addEventListener('scroll', handleScrollCheck, { passive: true });
    window.addEventListener('resize', handleScrollCheck, { passive: true });

    return () => {
      if (observer) observer.disconnect();
      window.removeEventListener('scroll', handleScrollCheck);
      window.removeEventListener('resize', handleScrollCheck);
    };
  }, [confirmedOrder, product.id]);

  // 1. Capture fbclid (_fbc) & _fbp on the very first millisecond and fire ViewContent on Landing Page Load
  const hasFiredViewRef = useRef<string>('');
  const hasFiredCheckoutRef = useRef<boolean>(false);
  const lastTrackedVariantRef = useRef<string>('');

  const categoryName = useMemo(() => {
    const catObj = categories.find(c => c.id === product.categoryId);
    return catObj ? catObj.nameBn : 'Landing Page Product';
  }, [categories, product.categoryId]);

  useEffect(() => {
    const pid = (currentBusiness.fbPixelId || '').trim();
    const gtmId = (currentBusiness.gtmContainerId || '').trim();
    const viewKey = `${product.id}_${pid}_${gtmId}`;
    if (hasFiredViewRef.current === viewKey) return;
    hasFiredViewRef.current = viewKey;
    hasFiredCheckoutRef.current = false;
    lastTrackedVariantRef.current = activeVariant?.id || 'default';

    // Immediately lock fbclid -> _fbc cookie & localStorage before PageView & ViewContent fire
    captureAndPersistFbParams();

    // 1. Fire PageView (Browser Pixel + Server CAPI with matching event_id) for accurate Facebook Ads Landing Page Views (LPV)
    const pageViewEventId = generateMetaEventId('PageView');
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'PageView',
      eventIdOverride: pageViewEventId
    }).catch(() => {});

    // 2. Fire ViewContent (Browser Pixel + Server CAPI with matching event_id) with full product details
    const viewContentEventId = generateMetaEventId('ViewContent');
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'ViewContent',
      eventIdOverride: viewContentEventId,
      customData: buildMetaProductCustomData({
        product,
        activeVariant,
        quantity,
        unitPrice: unitRetailPrice,
        totalValue: subtotal,
        categoryName,
        orderSource: 'landing_page'
      })
    }).catch(() => {});
  }, [product, activeVariant, quantity, unitRetailPrice, subtotal, currentBusiness, categoryName]);

  // Progressive Real-Time Customer Identity Sync & Bangladesh Normalization when typing in Landing Page Checkout form (debounced & validated)
  useEffect(() => {
    const cleanName = customerName.trim();
    const cleanPhone = customerPhone.trim();
    const cleanAddr = deliveryAddress.trim();
    if (!cleanName && !cleanPhone && !cleanAddr) return;

    const timer = window.setTimeout(() => {
      const normPhone = normalizeBdPhone(cleanPhone);
      const validPhone = isValidBdPhone11(normPhone) ? normPhone : undefined;
      const resolvedCity =
        selectedDeliveryZone === 'inside_dhaka'
          ? extractLocationForMeta(cleanAddr, 'dhaka').ct
          : extractLocationForMeta(cleanAddr).ct;
      saveFbCustomerIdentity(
        {
          name: cleanName || undefined,
          phone: validPhone,
          address: cleanAddr || undefined,
          city: resolvedCity || undefined
        },
        currentBusiness
      );
    }, 500);

    return () => window.clearTimeout(timer);
  }, [customerName, customerPhone, deliveryAddress, selectedDeliveryZone, currentBusiness]);

  // Helper: Fire AddToCart when customer chooses a Variation (Size/Pack/Age) or clicks CTA
  const triggerLandingAddToCart = (chosenVariant?: ProductVariant, chosenQty = quantity) => {
    const v = chosenVariant ?? activeVariant;
    const price = v ? v.retailPrice : product.retailPrice;
    const addToCartEventId = generateMetaEventId('AddToCart');
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'AddToCart',
      eventIdOverride: addToCartEventId,
      customData: buildMetaProductCustomData({
        product,
        activeVariant: v,
        quantity: chosenQty,
        unitPrice: price,
        totalValue: price * chosenQty,
        categoryName,
        orderSource: 'landing_page'
      })
    }).catch(() => {});
  };

  // Helper: Fire InitiateCheckout once when customer engages with the Checkout Form or clicks Order CTA
  const triggerLandingInitiateCheckout = () => {
    if (hasFiredCheckoutRef.current) return;
    hasFiredCheckoutRef.current = true;
    const resolvedCity =
      selectedDeliveryZone === 'inside_dhaka'
        ? extractLocationForMeta(deliveryAddress, 'dhaka').ct
        : extractLocationForMeta(deliveryAddress).ct;
    const initiateCheckoutEventId = generateMetaEventId('InitiateCheckout');
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'InitiateCheckout',
      eventIdOverride: initiateCheckoutEventId,
      customer: {
        name: customerName.trim() || undefined,
        phone: customerPhone.trim() || undefined,
        address: deliveryAddress.trim() || undefined,
        city: resolvedCity
      },
      customData: buildMetaProductCustomData({
        product,
        activeVariant,
        quantity,
        unitPrice: unitRetailPrice,
        totalValue: grandTotal,
        categoryName,
        orderSource: 'landing_page'
      })
    }).catch(() => {});
  };

  const handleSelectVariant = (variant: ProductVariant) => {
    if (variant.outOfStock) {
      showToast(
        `দুঃখিত, "${variant.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`,
        'error'
      );
      return;
    }
    if (hasLpDualVariants(checkoutTargetProduct) && variant.type === 'color') {
      setSelectedColorId(variant.id);
    } else {
      setSelectedVariantId(variant.id);
    }
    if (variant.imageUrl) {
      const matchedIdx = galleryImages.findIndex(img => img === variant.imageUrl);
      if (matchedIdx >= 0) {
        setActiveGalleryIdx(matchedIdx);
      }
    }
    if (lastTrackedVariantRef.current !== variant.id) {
      lastTrackedVariantRef.current = variant.id;
      triggerLandingAddToCart(variant, quantity);
    }
  };

  // Real-time Incomplete Order (Abandoned Checkout) Capture when customer types phone number
  const sessionKeyRef = useRef<string>(
    `lp_chk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
  );
  const firedLeadPhoneRef = useRef<string>('');
  const upsertIncompleteRef = useRef(upsertIncompleteOrder);
  upsertIncompleteRef.current = upsertIncompleteOrder;

  const captureLandingIncompleteLeadNow = () => {
    if (isSubmitting || confirmedOrder) return;

    const normPhone = normalizeBdPhone(customerPhone);
    if (!isValidBdPhone11(normPhone)) {
      return;
    }

    const incompleteItems: SaleItem[] =
      isTemplate3 && lp3SelectedResolvedItems.length > 0
        ? lp3SelectedResolvedItems.map(sel => {
            const p = sel.product;
            const v = sel.activeVariant;
            const uCost = v ? v.purchasePrice : p.avgCost ?? p.purchasePrice;
            const fName = v ? `${p.nameBn} (${v.label})` : p.nameBn;
            const rVarSku = v
              ? v.sku?.trim() || buildVariantSkuCode(p.sku, v.label)
              : undefined;
            return {
              productId: p.id,
              productName: fName,
              productNameClean: p.nameBn,
              sku: rVarSku || p.sku,
              parentSku: p.sku,
              variantSku: rVarSku,
              wpProductId: p.wpProductId,
              wpVariationId: v?.wpVariationId,
              variantId: v?.id,
              variantLabel: v?.label,
              unit: v ? v.label : p.unit,
              quantity: sel.quantity,
              unitPrice: sel.unitRetailPrice,
              costPrice: uCost,
              discount: 0,
              total: sel.lineTotal
            };
          })
        : (() => {
            const unitCost = activeVariant
              ? activeVariant.purchasePrice
              : checkoutTargetProduct.avgCost ?? checkoutTargetProduct.purchasePrice;
            const fullName = activeVariant
              ? `${checkoutTargetProduct.nameBn} (${activeVariant.label})`
              : checkoutTargetProduct.nameBn;

            const resolvedVarSku = activeVariant
              ? activeVariant.sku?.trim() ||
                buildVariantSkuCode(checkoutTargetProduct.sku, activeVariant.label)
              : undefined;

            return [
              {
                productId: checkoutTargetProduct.id,
                productName: fullName,
                productNameClean: checkoutTargetProduct.nameBn,
                sku: resolvedVarSku || checkoutTargetProduct.sku,
                parentSku: checkoutTargetProduct.sku,
                variantSku: resolvedVarSku,
                wpProductId: checkoutTargetProduct.wpProductId,
                wpVariationId: activeVariant?.wpVariationId,
                variantId: activeVariant?.id,
                variantLabel: activeVariant?.label,
                unit: activeVariant ? activeVariant.label : checkoutTargetProduct.unit,
                quantity,
                unitPrice: unitRetailPrice,
                costPrice: unitCost,
                discount: 0,
                total: subtotal
              }
            ];
          })();

    const areaLabel = isFreeDelivery
      ? 'ফ্রি ডেলিভারি (Free Delivery)'
      : selectedDeliveryZone === 'outside_dhaka'
      ? 'ঢাকার বাইরে (Outside Dhaka)'
      : 'ঢাকার ভিতরে (Inside Dhaka)';

    const { fbp, fbc, externalId } = ensureMetaFirstPartyIdentifiers();
    const resolvedLeadCity =
      selectedDeliveryZone === 'inside_dhaka'
        ? extractLocationForMeta(deliveryAddress.trim(), 'dhaka').ct
        : extractLocationForMeta(deliveryAddress.trim()).ct;
    const leadIdentity = {
      name: customerName.trim() || undefined,
      phone: normPhone,
      address: deliveryAddress.trim() || undefined,
      city: resolvedLeadCity || undefined,
      externalId,
      fbp,
      fbc
    };

    // Immediately lock customer phone & name into browser Pixel Advanced Matching & localStorage
    saveFbCustomerIdentity(leadIdentity, currentBusiness);

    if (normPhone.length === 11 && normPhone.startsWith('01') && firedLeadPhoneRef.current !== normPhone) {
      firedLeadPhoneRef.current = normPhone;
      triggerLandingInitiateCheckout();
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'Lead',
        customer: leadIdentity,
        customData: buildMetaProductCustomData({
          product,
          activeVariant,
          quantity,
          unitPrice: unitRetailPrice,
          totalValue: grandTotal,
          categoryName,
          orderSource: 'landing_page'
        })
      }).catch(() => {});
    }

    upsertIncompleteRef.current({
      sessionKey: sessionKeyRef.current,
      customerName: customerName.trim(),
      customerPhone: normPhone,
      deliveryArea: areaLabel,
      deliveryAddress: deliveryAddress.trim(),
      deliverySlot: 'এক্সপ্রেস হোম ডেলিভারি (Landing Page)',
      items: incompleteItems,
      subtotal,
      deliveryCharge,
      grandTotal,
      fbLeadSent: true,
      fbp,
      fbc,
      externalId,
      clientUserAgent: typeof navigator !== 'undefined' ? navigator.userAgent : undefined,
      eventSourceUrl: typeof window !== 'undefined' ? window.location.href : undefined,
      orderSource: 'landing_page',
      landingSlug: getProductLandingSlug(product),
      notes: orderNotes.trim() || undefined
    });
  };

  useEffect(() => {
    if (isSubmitting || confirmedOrder) return;
    const normPhone = normalizeBdPhone(customerPhone);
    if (!isValidBdPhone11(normPhone)) return;

    const timer = setTimeout(() => {
      captureLandingIncompleteLeadNow();
    }, 250);

    return () => clearTimeout(timer);
  }, [
    isSubmitting,
    confirmedOrder,
    customerName,
    customerPhone,
    deliveryAddress,
    selectedDeliveryZone,
    orderNotes,
    product.id,
    activeVariant?.id,
    quantity,
    unitRetailPrice,
    subtotal,
    deliveryCharge,
    grandTotal,
    isFreeDelivery
  ]);

  const scrollToOrderForm = () => {
    triggerLandingAddToCart(activeVariant, quantity);
    triggerLandingInitiateCheckout();
    const el = document.getElementById('landing-direct-order-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setTimeout(() => {
      const nameInput = document.getElementById('lp-input-name') as HTMLInputElement | null;
      const phoneInput = document.getElementById('lp-input-phone') as HTMLInputElement | null;
      const addrInput = document.getElementById('lp-input-address') as HTMLTextAreaElement | null;
      if (nameInput && !customerName.trim()) {
        nameInput.focus({ preventScroll: true });
      } else if (phoneInput && !isValidBdPhone11(customerPhone)) {
        phoneInput.focus({ preventScroll: true });
      } else if (addrInput && !deliveryAddress.trim()) {
        addrInput.focus({ preventScroll: true });
      }
    }, 450);
  };

  const alignLandingFieldInVisibleViewport = (
    el: HTMLElement,
    behavior: ScrollBehavior = 'smooth'
  ) => {
    const wrapper =
      (el.closest('[data-checkout-field]') as HTMLElement | null) ||
      el.parentElement ||
      el;
    const vv = typeof window !== 'undefined' ? window.visualViewport : null;
    const visibleHeight = vv ? vv.height : window.innerHeight;
    const vvOffsetTop = vv ? vv.offsetTop : 0;

    const rect = wrapper.getBoundingClientRect();
    const currentTopInVv = rect.top - vvOffsetTop;

    // Safe top margin so sticky header never covers the field label
    const minTopGap =
      visibleHeight < 360 ? Math.max(56, Math.round(visibleHeight * 0.2)) : 88;
    // Comfortable gap between the input (+ error message) and the top of the mobile keyboard
    const minBottomKeyboardGap = visibleHeight < 380 ? 64 : 96;

    // Place slightly above the center (38%) of the visible space above the keyboard
    const idealTop = Math.round((visibleHeight - rect.height) * 0.38);
    const maxAllowedTop = Math.max(
      minTopGap,
      visibleHeight - rect.height - minBottomKeyboardGap
    );
    const desiredTopInVv = Math.max(
      minTopGap,
      Math.min(idealTop, maxAllowedTop)
    );

    const deltaY = currentTopInVv - desiredTopInVv;
    if (Math.abs(deltaY) > 6) {
      window.scrollBy({ top: deltaY, behavior });
    }
  };

  const focusFieldWithError = (
    inputId: string,
    fieldKey: 'name' | 'phone' | 'address',
    msg: string
  ) => {
    setErrorField(fieldKey);
    showToast(msg, 'error');
    const el = document.getElementById(inputId) as
      | HTMLInputElement
      | HTMLTextAreaElement
      | null;
    if (!el) return;

    // On computer / desktop screens (>= 768px), keep the original smooth center scroll behavior
    const isMobileScreen = typeof window !== 'undefined' && window.innerWidth < 768;
    if (!isMobileScreen) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => el.focus({ preventScroll: true }), 250);
      return;
    }

    // Mobile only: Focus immediately inside user gesture without browser jump so mobile keyboard opens smoothly
    el.focus({ preventScroll: true });

    requestAnimationFrame(() => {
      alignLandingFieldInVisibleViewport(el, 'smooth');
    });

    const vv = typeof window !== 'undefined' ? window.visualViewport : null;
    const handleVvResize = () => alignLandingFieldInVisibleViewport(el, 'smooth');
    if (vv) {
      vv.addEventListener('resize', handleVvResize);
    }
    const t1 = window.setTimeout(
      () => alignLandingFieldInVisibleViewport(el, 'smooth'),
      180
    );
    const t2 = window.setTimeout(
      () => alignLandingFieldInVisibleViewport(el, 'smooth'),
      380
    );
    window.setTimeout(() => {
      if (vv) vv.removeEventListener('resize', handleVvResize);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    }, 650);
  };

  const handleConfirmOrder = async (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    if (isSubmitting) return;
    if (isTemplate3 && lp3SelectedResolvedItems.length === 0) {
      showToast('অনুগ্রহ করে অন্তত ১টি পছন্দের প্রোডাক্ট টিক (✓) দিয়ে সিলেক্ট করুন', 'error');
      const el = document.getElementById('landing-direct-order-section');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    if (!isTemplate3) {
      if (availableStock <= 0) {
        showToast('দুঃখিত, এই পণ্যটি বর্তমানে স্টকে নেই (স্টক শেষ)', 'error');
        return;
      }
      if (activeVariant?.outOfStock) {
        showToast(
          `দুঃখিত, "${activeVariant.label}" সাইজ/ভ্যারিয়েশনটি বর্তমানে স্টকে নেই (স্টক শেষ)!`,
          'error'
        );
        return;
      }
    }

    const cleanName = customerName.trim();
    const cleanPhone = customerPhone.trim();
    const normPhone = normalizeBdPhone(cleanPhone);
    const cleanAddress = deliveryAddress.trim();

    if (!cleanName) {
      focusFieldWithError('lp-input-name', 'name', 'অনুগ্রহ করে আপনার নাম লিখুন');
      return;
    }
    if (!isValidBdPhone11(normPhone)) {
      focusFieldWithError('lp-input-phone', 'phone', 'অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন (যেমন: 017XXXXXXXX)');
      return;
    }
    if (cleanPhone !== normPhone) {
      setCustomerPhone(normPhone);
    }
    if (!cleanAddress) {
      focusFieldWithError('lp-input-address', 'address', 'অনুগ্রহ করে আপনার সম্পূর্ণ ডেলিভারি ঠিকানা লিখুন');
      return;
    }

    setErrorField(null);

    const targetProductIdsForLimit =
      isTemplate3 && lp3SelectedResolvedItems.length > 0
        ? lp3SelectedResolvedItems.map(it => it.product.id)
        : [checkoutTargetProduct.id];

    // Check Daily Order Limit (Same Product Max 2 & Total Products Max 5 by Mobile Number & IP/Device) before placing order
    let limitResult = checkDailyOrderLimit(normPhone, targetProductIdsForLimit);
    if (!limitResult.blocked) {
      limitResult = await verifyDailyOrderLimitServer(normPhone, targetProductIdsForLimit);
    }
    if (limitResult.blocked) {
      setInlineLimitTitle(limitResult.title);
      setInlineLimitMessage(limitResult.message);
      setInlineLimitSameProdMaxCount(limitResult.sameProductMaxCount);
      setInlineLimitMaxCount(limitResult.maxCount);
      setIsEditingLimitPopupInline(false);
      setOrderLimitPopupData(limitResult);
      return;
    }

    setIsSubmitting(true);

    try {
      const orderItems: SaleItem[] =
        isTemplate3 && lp3SelectedResolvedItems.length > 0
          ? lp3SelectedResolvedItems.map(sel => {
              const p = sel.product;
              const v = sel.activeVariant;
              const uCost = v ? v.purchasePrice : p.avgCost ?? p.purchasePrice;
              const fName = v ? `${p.nameBn} (${v.label})` : p.nameBn;
              const rVarSku = v
                ? v.sku?.trim() || buildVariantSkuCode(p.sku, v.label)
                : undefined;
              return {
                productId: p.id,
                productName: fName,
                productNameClean: p.nameBn,
                sku: rVarSku || p.sku,
                parentSku: p.sku,
                variantSku: rVarSku,
                wpProductId: p.wpProductId,
                wpVariationId: v?.wpVariationId,
                variantId: v?.id,
                variantLabel: v?.label,
                unit: v ? v.label : p.unit,
                quantity: sel.quantity,
                unitPrice: sel.unitRetailPrice,
                costPrice: uCost,
                discount: 0,
                total: sel.lineTotal,
                batchNumber: p.batchNumber
              };
            })
          : (() => {
              const unitCost = activeVariant
                ? activeVariant.purchasePrice
                : checkoutTargetProduct.avgCost ?? checkoutTargetProduct.purchasePrice;
              const fullName = activeVariant
                ? `${checkoutTargetProduct.nameBn} (${activeVariant.label})`
                : checkoutTargetProduct.nameBn;

              const resolvedVarSku = activeVariant
                ? activeVariant.sku?.trim() ||
                  buildVariantSkuCode(checkoutTargetProduct.sku, activeVariant.label)
                : undefined;

              return [
                {
                  productId: checkoutTargetProduct.id,
                  productName: fullName,
                  productNameClean: checkoutTargetProduct.nameBn,
                  sku: resolvedVarSku || checkoutTargetProduct.sku,
                  parentSku: checkoutTargetProduct.sku,
                  variantSku: resolvedVarSku,
                  wpProductId: checkoutTargetProduct.wpProductId,
                  wpVariationId: activeVariant?.wpVariationId,
                  variantId: activeVariant?.id,
                  variantLabel: activeVariant?.label,
                  unit: activeVariant ? activeVariant.label : checkoutTargetProduct.unit,
                  quantity,
                  unitPrice: unitRetailPrice,
                  costPrice: unitCost,
                  discount: 0,
                  total: subtotal,
                  batchNumber: checkoutTargetProduct.batchNumber
                }
              ];
            })();

      const areaLabel = isFreeDelivery
        ? isSpinFreeDelivery
          ? 'ফ্রি ডেলিভারি (Spin Wheel Offer)'
          : isQtyFreeDeliveryUnlocked
          ? `ফ্রি ডেলিভারি (${freeDeliveryMinQty}+ পিস অফার)`
          : 'ফ্রি ডেলিভারি (Free Delivery)'
        : selectedDeliveryZone === 'outside_dhaka'
        ? 'ঢাকার বাইরে (Outside Dhaka)'
        : 'ঢাকার ভিতরে (Inside Dhaka)';

      const combinedOrderNotes = orderNotes.trim();

      const { fbp, fbc } = captureAndPersistFbParams();
      const storedFbIdentity = getFbCustomerIdentity();
      const resolvedCity =
        selectedDeliveryZone === 'inside_dhaka'
          ? extractLocationForMeta(cleanAddress, 'dhaka').ct
          : extractLocationForMeta(cleanAddress).ct;
      const preNormalized = normalizeCustomerDataForMeta({
        name: cleanName,
        phone: normPhone,
        address: cleanAddress,
        city: resolvedCity
      });

      const createdOrder = await placeOnlineOrder({
        businessId: currentBusiness.id,
        outletId: 'outlet_01',
        customerName: cleanName,
        customerPhone: normPhone,
        deliveryArea: areaLabel,
        deliveryAddress: cleanAddress,
        deliverySlot: 'এক্সপ্রেস হোম ডেলিভারি (Landing Page)',
        items: orderItems,
        subtotal,
        deliveryCharge,
        discountAmount: spinDiscountAmount,
        grandTotal,
        paymentMethod: 'cod',
        paymentStatus: 'unpaid',
        notes: combinedOrderNotes || undefined,
        orderSource: 'landing_page',
        landingSlug: getProductLandingSlug(product),
        fbp,
        fbc,
        fbExternalId: storedFbIdentity.externalId || preNormalized.ph || normPhone,
        clientUserAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
        eventSourceUrl: typeof window !== 'undefined' ? window.location.href : ''
      });

      // Clear any lingering storefront cart in localStorage to guarantee 100% strict single-item isolation
      try {
        window.localStorage.removeItem('stockmaster_dokanghor_cart_v3');
      } catch {
        // ignore
      }

      // Fire Facebook Pixel + CAPI + GTM Purchase Event with exact event_id stored in DB (`order_${createdOrder.orderNo}`)
      const purchaseEventId = createdOrder.fbEventId || generateMetaEventId('Purchase', createdOrder.orderNo);
      const purchaseCustomerIdentity = {
        name: cleanName,
        phone: preNormalized.ph || normPhone,
        email: storedFbIdentity.email || undefined,
        address: cleanAddress,
        city: resolvedCity || undefined,
        externalId: storedFbIdentity.externalId,
        fbp,
        fbc
      };
      saveFbCustomerIdentity(purchaseCustomerIdentity, currentBusiness);
      trackFacebookEvent({
        business: currentBusiness,
        eventName: 'Purchase',
        eventIdOverride: purchaseEventId,
        customer: purchaseCustomerIdentity,
        customData: buildMetaProductCustomData({
          product: checkoutTargetProduct,
          activeVariant,
          quantity,
          unitPrice: unitRetailPrice,
          totalValue: createdOrder.grandTotal,
          categoryName,
          orderId: createdOrder.orderNo,
          orderSource: 'landing_page'
        })
      }).catch(() => {});

      // Sync to WordPress if configured
      syncOrderToWordPress({
        business: currentBusiness,
        order: createdOrder,
        productsCatalog: products
      }).catch(() => {});

      // Consume Landing Page Spin Wheel reward immediately after 1 order so it never stays stuck on future orders
      if (spinWheelEnabled && claimedSpinReward) {
        setClaimedSpinReward(null);
        setDailySpinLock(prev => {
          const nextLock = prev
            ? { ...prev, used: true, usedOrderNo: createdOrder.orderNo }
            : {
                dateKey: new Date().toISOString().slice(0, 10),
                timestamp: Date.now(),
                name: cleanName,
                phone: normPhone,
                reward: claimedSpinReward,
                used: true,
                usedOrderNo: createdOrder.orderNo
              };
          try {
            window.localStorage.setItem('lp_spin_daily_lock_v1', JSON.stringify(nextLock));
          } catch {
            // ignore
          }
          return nextLock;
        });
        try {
          window.localStorage.removeItem('lp_spin_reward_v1');
        } catch {
          // ignore
        }
      }

      setConfirmedOrder(createdOrder);
      if (isLandingOrderConfettiEnabled) {
        triggerLandingOrderCelebration();
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch {
      showToast('অর্ডার সম্পন্ন করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Top Call & WhatsApp Buttons Visibility & Phone Resolution
  const showCallButton = product.landingShowCallButton !== false;
  const showWhatsappButton = product.landingShowWhatsappButton !== false;

  const supportPhone = (
    product.landingCallPhone ||
    currentBusiness.callOrderPhone ||
    currentBusiness.phone ||
    '01711234567'
  ).trim();
  const rawWaPhone = (
    product.landingWhatsappPhone ||
    currentBusiness.whatsappOrderPhone ||
    currentBusiness.phone ||
    '01711234567'
  ).replace(/\D/g, '');
  const formattedWaNumber = rawWaPhone.startsWith('880')
    ? rawWaPhone
    : rawWaPhone.startsWith('0')
    ? `88${rawWaPhone}`
    : `880${rawWaPhone}`;

  const prefilledWaOrderText = encodeURIComponent(
    `আসসালামু আলাইকুম, আমি আপনাদের "${product.nameBn}"${
      activeVariant ? ` (${activeVariant.label})` : ''
    } নিতে চাচ্ছি (মূল্য: ৳${unitRetailPrice})। বিস্তারিত জানাবেন কি?`
  );

  // Customer Reviews Data (Enabled by default unless explicitly turned OFF by Admin) + Slider Mode (ON by default)
  const reviewsEnabled = product.landingReviewsEnabled !== false;
  const reviewsSliderEnabled = product.landingReviewsSliderEnabled !== false;
  const reviewsHeading =
    product.landingReviewsTitle && product.landingReviewsTitle.trim() !== ''
      ? product.landingReviewsTitle.trim()
      : 'সন্তুষ্ট ক্রেতাদের মতামত ও রিভিউ';
  const reviewScreenshots = Array.isArray(product.landingReviewImages)
    ? product.landingReviewImages.filter(Boolean)
    : [];
  const reviewItems: LandingReviewItem[] = useMemo(() => {
    if (Array.isArray(product.landingReviewItems) && product.landingReviewItems.length > 0) {
      return product.landingReviewItems.filter(r => r.status !== 'pending');
    }
    if (reviewScreenshots.length > 0 && Array.isArray(product.landingReviewItems)) {
      return [];
    }
    return [
      {
        id: 'default_rev_1',
        customerName: 'নুসরাত জাহান তানিয়া',
        location: 'ধানমন্ডি, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'আলহামদুলিল্লাহ! ছবির চেয়েও বাস্তবে প্রোডাক্টের কোয়ালিটি ও ফিনিশিং অনেক বেশি সুন্দর। ডেলিভারিও খুব দ্রুত পেয়েছি।',
        status: 'approved'
      },
      {
        id: 'default_rev_2',
        customerName: 'ফারহানা ইসলাম মিম',
        location: 'চট্টগ্রাম · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'সাইজ এবং কোয়ালিটি একদম পারফেক্ট হয়েছে। হাতে পেয়ে দেখে পেমেন্ট করেছি, শতভাগ সন্তুষ্ট।',
        status: 'approved'
      },
      {
        id: 'default_rev_3',
        customerName: 'মোঃ তানভীর আহমেদ',
        location: 'উত্তরা, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          '১০০% অরিজিনাল ও প্রিমিয়াম প্রোডাক্ট। প্যাকেজিং এবং সার্ভিস দুটোই অসাধারণ লেগেছে।',
        status: 'approved'
      },
      {
        id: 'default_rev_4',
        customerName: 'সাদিয়া আফরিন রূপা',
        location: 'সিলেট · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'ফেব্রিকটা অনেক সফট এবং আরামদায়ক। রঙের গ্যারান্টি যেমন বলেছে ঠিক তেমনই পেয়েছি। সবাইকে নেওয়ার পরামর্শ দেবো।',
        status: 'approved'
      },
      {
        id: 'default_rev_5',
        customerName: 'মাহমুদুল হাসান রাকিব',
        location: 'রাজশাহী · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'বাসার সবার জন্য অর্ডার করেছিলাম, প্রত্যেকেই খুব পছন্দ করেছে। কুরিয়ার সার্ভিসও অনেক দ্রুত ডেলিভারি দিয়েছে।',
        status: 'approved'
      },
      {
        id: 'default_rev_6',
        customerName: 'তাসনিম জেরিন ইভা',
        location: 'মিরপুর, ঢাকা · ভেরিফাইড ক্রেতা',
        rating: 5,
        comment:
          'এই বাজেটে এত সুন্দর ও নিখুঁত সেলাইয়ের প্রোডাক্ট সত্যিই আশা করিনি। ইনশাআল্লাহ সামনে আরও অর্ডার করব।',
        status: 'approved'
      }
    ];
  }, [product.landingReviewItems, reviewScreenshots.length]);

  // Customer Review Slider & Inline Reviewer Circular Avatar Upload States
  const [activeReviewSlide, setActiveReviewSlide] = useState<number>(0);
  const [activeScreenshotSlide, setActiveScreenshotSlide] = useState<number>(0);
  const [isReviewSliderPaused, setIsReviewSliderPaused] = useState<boolean>(false);
  const [isEditingLiveReviews, setIsEditingLiveReviews] = useState<boolean>(false);
  const [liveNewRevName, setLiveNewRevName] = useState<string>('');
  const [liveNewRevLocation, setLiveNewRevLocation] = useState<string>('');
  const [liveNewRevComment, setLiveNewRevComment] = useState<string>('');
  const [liveNewRevAvatar, setLiveNewRevAvatar] = useState<string>('');
  const [isUploadingReviewAvatar, setIsUploadingReviewAvatar] = useState<boolean>(false);

  const liveReviewerAvatarInputRef = useRef<HTMLInputElement | null>(null);
  const liveNewReviewerAvatarInputRef = useRef<HTMLInputElement | null>(null);
  const liveScreenshotUploadInputRef = useRef<HTMLInputElement | null>(null);
  const targetAvatarReviewIdxRef = useRef<number | null>(null);
  const revTouchStartXRef = useRef<number | null>(null);
  const revTouchEndXRef = useRef<number | null>(null);
  const revMouseStartXRef = useRef<number | null>(null);
  const shotTouchStartXRef = useRef<number | null>(null);
  const shotTouchEndXRef = useRef<number | null>(null);
  const shotMouseStartXRef = useRef<number | null>(null);

  const safeReviewSlide =
    reviewItems.length > 0 ? activeReviewSlide % reviewItems.length : 0;
  const safeScreenshotSlide =
    reviewScreenshots.length > 0 ? activeScreenshotSlide % reviewScreenshots.length : 0;

  // Auto-advance Written Reviews Slider every 4.2s when Slider Mode is ON
  useEffect(() => {
    if (
      !reviewsEnabled ||
      !reviewsSliderEnabled ||
      isReviewSliderPaused ||
      isEditingLiveReviews ||
      reviewItems.length <= 1 ||
      Boolean(confirmedOrder)
    ) {
      return;
    }
    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setActiveReviewSlide(prev => (prev + 1) % reviewItems.length);
    }, 4200);
    return () => window.clearInterval(timer);
  }, [
    reviewsEnabled,
    reviewsSliderEnabled,
    isReviewSliderPaused,
    isEditingLiveReviews,
    reviewItems.length,
    confirmedOrder
  ]);

  // Auto-advance Review Screenshots Slider every 4.5s when Slider Mode is ON
  useEffect(() => {
    if (
      !reviewsEnabled ||
      !reviewsSliderEnabled ||
      isReviewSliderPaused ||
      isEditingLiveReviews ||
      reviewScreenshots.length <= 1 ||
      Boolean(confirmedOrder)
    ) {
      return;
    }
    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setActiveScreenshotSlide(prev => (prev + 1) % reviewScreenshots.length);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [
    reviewsEnabled,
    reviewsSliderEnabled,
    isReviewSliderPaused,
    isEditingLiveReviews,
    reviewScreenshots.length,
    confirmedOrder
  ]);

  const handlePrevReviewSlide = () => {
    if (reviewItems.length <= 1) return;
    setActiveReviewSlide(prev => (prev - 1 + reviewItems.length) % reviewItems.length);
  };

  const handleNextReviewSlide = () => {
    if (reviewItems.length <= 1) return;
    setActiveReviewSlide(prev => (prev + 1) % reviewItems.length);
  };

  const handleTriggerReviewerAvatarUpload = (idx: number) => {
    targetAvatarReviewIdxRef.current = idx;
    liveReviewerAvatarInputRef.current?.click();
  };

  const handleReviewerAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetIdx = targetAvatarReviewIdxRef.current;
    if (!file || targetIdx === null) return;
    setIsUploadingReviewAvatar(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      const baseList = reviewItems.map(item => ({ ...item }));
      if (baseList[targetIdx]) {
        baseList[targetIdx] = {
          ...baseList[targetIdx],
          avatarUrl: dataUrl
        };
        await updateProduct(product.id, {
          landingReviewItems: baseList,
          landingReviewsEnabled: true
        });
        showToast(
          `"${baseList[targetIdx].customerName}"-এর প্রোফাইল ছবি আপলোড হয়েছে!`,
          'success'
        );
      }
    } catch {
      showToast('প্রোফাইল ছবি প্রসেস করা যায়নি', 'error');
    } finally {
      setIsUploadingReviewAvatar(false);
      targetAvatarReviewIdxRef.current = null;
      e.target.value = '';
    }
  };

  const handleRemoveReviewerAvatar = async (idx: number) => {
    const baseList = reviewItems.map(item => ({ ...item }));
    if (!baseList[idx]) return;
    const revName = baseList[idx].customerName;
    baseList[idx] = {
      ...baseList[idx],
      avatarUrl: undefined
    };
    await updateProduct(product.id, {
      landingReviewItems: baseList
    });
    showToast(`"${revName}"-এর ছবি সরানো হয়েছে (নামের প্রথম অক্ষর দেখাবে)`, 'info');
  };

  const handleLiveNewReviewerAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingReviewAvatar(true);
    try {
      const dataUrl = await processUploadedProductImage(file, 320, 0.88);
      setLiveNewRevAvatar(dataUrl);
      showToast('ক্রেতার গোল প্রোফাইল ছবি যুক্ত হয়েছে!', 'success');
    } catch {
      showToast('ছবি আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingReviewAvatar(false);
      e.target.value = '';
    }
  };

  const handleLiveAddReview = async () => {
    const cleanName = liveNewRevName.trim();
    const cleanComment = liveNewRevComment.trim();
    if (!cleanName || !cleanComment) {
      showToast('অনুগ্রহ করে ক্রেতার নাম ও রিভিউ কমেন্ট লিখুন', 'error');
      return;
    }
    const newRev: LandingReviewItem = {
      id: `rev_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      customerName: cleanName,
      location: liveNewRevLocation.trim() || 'ভেরিফাইড ক্রেতা',
      rating: 5,
      comment: cleanComment,
      avatarUrl: liveNewRevAvatar || undefined,
      status: 'approved'
    };
    const nextList = [newRev, ...reviewItems.map(item => ({ ...item }))];
    await updateProduct(product.id, {
      landingReviewItems: nextList,
      landingReviewsEnabled: true
    });
    setLiveNewRevName('');
    setLiveNewRevLocation('');
    setLiveNewRevComment('');
    setLiveNewRevAvatar('');
    setActiveReviewSlide(0);
    showToast('নতুন কাস্টমার রিভিউ যুক্ত হয়েছে!', 'success');
  };

  const handleLiveScreenshotUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsUploadingReviewAvatar(true);
    try {
      const uploaded: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const dataUrl = await processUploadedProductImage(files[i]);
        uploaded.push(dataUrl);
      }
      await updateProduct(product.id, {
        landingReviewImages: [...reviewScreenshots, ...uploaded],
        landingReviewsEnabled: true
      });
      showToast(`${uploaded.length}টি রিভিউ স্ক্রিনশট আপলোড হয়েছে!`, 'success');
    } catch {
      showToast('রিভিউ স্ক্রিনশট আপলোড করা যায়নি', 'error');
    } finally {
      setIsUploadingReviewAvatar(false);
      e.target.value = '';
    }
  };

  // Elementor-Style Top Animated Regular & Offer Price Banner (ON/OFF + Animation ON/OFF + Speed + Color Theme + Highlight Style + Labels)
  const showTopPriceBanner = product.landingTopPriceBannerEnabled !== false;
  const isTopPriceAnimated = product.landingTopPriceAnimationEnabled !== false;
  const topPriceAnimationSpeed: 'slow' | 'normal' | 'fast' | 'ultra_fast' =
    product.landingTopPriceAnimationSpeed || 'normal';
  const topPriceBannerTheme = product.landingTopPriceBannerTheme || 'emerald';
  const topPriceHighlightStyle = product.landingTopPriceHighlightStyle || 'circle';
  const topRegularPriceLabel =
    product.landingTopRegularPriceLabel !== undefined && product.landingTopRegularPriceLabel.trim() !== ''
      ? product.landingTopRegularPriceLabel.trim()
      : 'পূর্বের মূল্য —';
  const topOfferPriceLabel =
    product.landingTopOfferPriceLabel !== undefined && product.landingTopOfferPriceLabel.trim() !== ''
      ? product.landingTopOfferPriceLabel.trim()
      : 'আজকের অফার মূল্য —';
  const topOfferPricePrefix =
    product.landingTopOfferPricePrefix !== undefined && product.landingTopOfferPricePrefix.trim() !== ''
      ? product.landingTopOfferPricePrefix.trim()
      : 'মাত্র';
  const bannerRegularPrice =
    unitRegularPrice > unitRetailPrice ? unitRegularPrice : Math.round(unitRetailPrice * 1.35);

  // ❄️ Landing Page Winter Theme (Cool Icy Blues & Snowy Whites) Resolution (ON/OFF per product or global)
  const globalLandingWinterTheme =
    currentBusiness.landingWinterThemeEnabled !== undefined
      ? Boolean(currentBusiness.landingWinterThemeEnabled)
      : false;
  const isLandingWinterTheme =
    product.landingWinterThemeEnabled !== undefined
      ? Boolean(product.landingWinterThemeEnabled)
      : globalLandingWinterTheme;

  const topPriceThemeClasses =
    topPriceBannerTheme === 'crimson'
      ? {
          outer: 'bg-gradient-to-b from-rose-50/80 via-white to-rose-50/40 border-b border-rose-100',
          card: 'bg-white/95 border border-rose-200/85 shadow-xs',
          regRow: 'text-slate-600',
          regPriceBox: 'bg-rose-50/70 border border-rose-200/70 text-slate-800',
          divider: 'from-transparent via-rose-200/90 to-transparent',
          offerLabel: 'text-[#881337]',
          offerPrefix: 'text-slate-900',
          offerPriceNum: 'text-[#dc2626]',
          offerPriceCurrency: 'text-slate-900',
          offerHighlightBg: 'bg-rose-50/55',
          strokeColor: '#16a34a',
          secondaryStrokeColor: '#dc2626',
          crossColor: '#ef1111',
          savingsPill: 'bg-rose-600 text-white border-rose-600'
        }
      : topPriceBannerTheme === 'midnight'
      ? {
          outer: 'bg-slate-900 border-b border-slate-800',
          card: 'bg-gradient-to-br from-slate-900 via-[#111c33] to-slate-900 border border-amber-400/30 shadow-md',
          regRow: 'text-slate-300',
          regPriceBox: 'bg-slate-800/90 border border-slate-700 text-slate-100',
          divider: 'from-transparent via-slate-700 to-transparent',
          offerLabel: 'text-white',
          offerPrefix: 'text-slate-100',
          offerPriceNum: 'text-amber-300',
          offerPriceCurrency: 'text-white',
          offerHighlightBg: 'bg-emerald-500/10',
          strokeColor: '#22c55e',
          secondaryStrokeColor: '#fbbf24',
          crossColor: '#ff3b3b',
          savingsPill: 'bg-amber-400 text-slate-950 border-amber-300'
        }
      : topPriceBannerTheme === 'amber'
      ? {
          outer: 'bg-gradient-to-b from-amber-50/85 via-white to-orange-50/40 border-b border-amber-200/70',
          card: 'bg-white/95 border border-amber-300/80 shadow-xs',
          regRow: 'text-slate-600',
          regPriceBox: 'bg-amber-50/70 border border-amber-200/75 text-slate-800',
          divider: 'from-transparent via-amber-200 to-transparent',
          offerLabel: 'text-slate-900',
          offerPrefix: 'text-slate-900',
          offerPriceNum: 'text-[#047857]',
          offerPriceCurrency: 'text-slate-900',
          offerHighlightBg: 'bg-amber-50/70',
          strokeColor: '#d97706',
          secondaryStrokeColor: '#16a34a',
          crossColor: '#ef1111',
          savingsPill: 'bg-amber-500 text-slate-950 border-amber-500'
        }
      : topPriceBannerTheme === 'light'
      ? {
          outer: 'bg-white border-b border-slate-100',
          card: 'bg-white border border-slate-200/80 shadow-2xs',
          regRow: 'text-[#4B5259]',
          regPriceBox: 'bg-slate-50 border border-slate-200/80 text-[#374151]',
          divider: 'from-transparent via-slate-200 to-transparent',
          offerLabel: 'text-[#090D16]',
          offerPrefix: 'text-[#090D16]',
          offerPriceNum: isLandingWinterTheme ? 'text-[#0284c7]' : 'text-[#0b7a3e]',
          offerPriceCurrency: 'text-[#090D16]',
          offerHighlightBg: 'bg-emerald-50/40',
          strokeColor: isLandingWinterTheme ? '#0284c7' : '#16a34a',
          secondaryStrokeColor: isLandingWinterTheme ? '#0ea5e9' : '#059669',
          crossColor: '#ef1111',
          savingsPill: 'bg-emerald-700 text-white border-emerald-700'
        }
      : {
          outer: 'bg-gradient-to-b from-emerald-50/70 via-white to-emerald-50/35 border-b border-emerald-100/90',
          card: 'bg-white/95 border border-emerald-200/85 shadow-xs',
          regRow: 'text-slate-600',
          regPriceBox: 'bg-slate-50/90 border border-slate-200/80 text-slate-800',
          divider: 'from-transparent via-emerald-200/90 to-transparent',
          offerLabel: 'text-emerald-950',
          offerPrefix: 'text-slate-900',
          offerPriceNum: isLandingWinterTheme ? 'text-[#0284c7]' : 'text-[#047857]',
          offerPriceCurrency: 'text-slate-900',
          offerHighlightBg: 'bg-emerald-50/55',
          strokeColor: isLandingWinterTheme ? '#0284c7' : '#16a34a',
          secondaryStrokeColor: isLandingWinterTheme ? '#0ea5e9' : '#059669',
          crossColor: '#ef1111',
          savingsPill: 'bg-emerald-700 text-white border-emerald-700'
        };

  // Banner 1 (Top of Landing Page): Custom Promotional Banner / Image Upload Section (ON/OFF + Image Upload)
  const promoBannerImage = (product.landingPromoBannerImage || '').trim();
  const showPromoBanner =
    product.landingPromoBannerEnabled !== undefined
      ? product.landingPromoBannerEnabled
      : Boolean(promoBannerImage);
  const promoBannerTitle = (product.landingPromoBannerTitle || '').trim();
  const promoBannerFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleDirectPromoBannerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processUploadedProductImage(file, 1200);
      await updateProduct(product.id, {
        landingPromoBannerImage: dataUrl,
        landingPromoBannerEnabled: true
      });
      showToast('ব্যানার ১ ছবি আপলোড ও চালু (ON) করা হয়েছে!', 'success');
    } catch {
      showToast('ব্যানার ১ ছবি আপলোড করা যায়নি', 'error');
    } finally {
      e.target.value = '';
    }
  };

  // Banner 2 (Right Before Video Section): Custom Promotional Banner / Image Upload Section (ON/OFF + Image Upload)
  const promoBanner2Image = (
    product.landingPromoBanner2Image ||
    (product.landingPromoBannerPosition === 'after_hero' ? product.landingPromoBannerImage : '') ||
    ''
  ).trim();
  const showPromoBanner2 =
    product.landingPromoBanner2Enabled !== undefined
      ? product.landingPromoBanner2Enabled
      : Boolean(promoBanner2Image);
  const promoBanner2Title = (product.landingPromoBanner2Title || '').trim();
  const promoBanner2FileInputRef = useRef<HTMLInputElement | null>(null);

  const handleDirectPromoBanner2Upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processUploadedProductImage(file, 1200);
      await updateProduct(product.id, {
        landingPromoBanner2Image: dataUrl,
        landingPromoBanner2Enabled: true
      });
      showToast('ব্যানার ২ (ভিডিওর উপরে) ছবি আপলোড ও চালু (ON) করা হয়েছে!', 'success');
    } catch {
      showToast('ব্যানার ২ ছবি আপলোড করা যায়নি', 'error');
    } finally {
      e.target.value = '';
    }
  };

  // Product Image Touch & Mouse Swipe Slider Handlers
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);
  const mouseStartXRef = useRef<number | null>(null);

  const handlePrevImage = () => {
    if (galleryImages.length <= 1) return;
    setActiveGalleryIdx(prev => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  const handleNextImage = () => {
    if (galleryImages.length <= 1) return;
    setActiveGalleryIdx(prev => (prev + 1) % galleryImages.length);
  };

  const handleImageTouchStart = (e: React.TouchEvent) => {
    touchEndXRef.current = null;
    touchStartXRef.current = e.targetTouches[0]?.clientX ?? null;
  };

  const handleImageTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.targetTouches[0]?.clientX ?? null;
  };

  const handleImageTouchEnd = () => {
    if (touchStartXRef.current === null || touchEndXRef.current === null) return;
    const distance = touchStartXRef.current - touchEndXRef.current;
    if (Math.abs(distance) > 30) {
      if (distance > 0) {
        handleNextImage();
      } else {
        handlePrevImage();
      }
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
  };

  const handleImageMouseDown = (e: React.MouseEvent) => {
    mouseStartXRef.current = e.clientX;
  };

  const handleImageMouseUp = (e: React.MouseEvent) => {
    if (mouseStartXRef.current === null) return;
    const distance = mouseStartXRef.current - e.clientX;
    if (Math.abs(distance) > 35) {
      if (distance > 0) {
        handleNextImage();
      } else {
        handlePrevImage();
      }
    } else if (isLpLightboxAllowed && Math.abs(distance) < 6) {
      setLpLightboxScale(1);
      setLpLightboxPan({ x: 50, y: 50 });
      setLpLightboxOpen(true);
    }
    mouseStartXRef.current = null;
  };

  const handleImageMouseMoveZoom = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isLpHoverZoomAllowed) return;
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100));
    setLpHoverZoom({ active: true, x, y });
  };

  // Live "People currently viewing this product" Counter (Randomized 12-48, ON/OFF per product)
  const showLiveViewers = product.landingLiveViewersEnabled !== false;

  // Footer Anti-Fake Order Warning Notice Resolution (ON/OFF + Editable Text)
  const showFooterWarning = product.landingFooterWarningEnabled !== false;
  const footerWarningText =
    product.landingFooterWarningText !== undefined && product.landingFooterWarningText.trim() !== ''
      ? product.landingFooterWarningText.trim()
      : DEFAULT_FOOTER_WARNING_TEXT;

  // Top Header Bar (Logo + Phone Number Bar) Toggle (ON by default)
  const showTopHeader = product.landingTopHeaderEnabled !== false;

  // Mobile Floating "অর্ডার কনফার্ম করুন" Button Total Price Toggle (ON by default so total price shows inside floating button)
  const showFloatingBtnPrice = product.landingFloatingBtnPriceEnabled !== false;
  const floatingBtnAnimation: LandingFloatingBtnAnimation =
    product.landingFloatingBtnAnimation || 'jump';

  const floatingAnimOptions: Array<{
    id: LandingFloatingBtnAnimation;
    label: string;
    shortLabel: string;
  }> = [
    { id: 'jump', label: 'জাম্প বাউন্স (Default Jump)', shortLabel: 'জাম্প বাউন্স' },
    { id: 'login_shine', label: 'লগইন বাটন শাইন (Login Shine & Glow)', shortLabel: 'লগইন শাইন' },
    { id: 'cart_beam', label: 'কার্ট বাটন বর্ডার বিম (Cart Border Light Beam)', shortLabel: 'কার্ট বর্ডার বিম' },
    { id: 'combo_beam', label: 'প্রিমিয়াম কম্বো (কার্ট বিম + লগইন শাইন + বাউন্স)', shortLabel: 'প্রিমিয়াম কম্বো' },
    { id: 'glow_pulse', label: 'রিং পালস গ্লো (Ring Ripple Glow)', shortLabel: 'রিং পালস গ্লো' },
    { id: 'none', label: 'অ্যানিমেশন বন্ধ (সাধারণ বাটন)', shortLabel: 'বন্ধ (Static)' }
  ];

  const currentFloatingAnimObj =
    floatingAnimOptions.find(o => o.id === floatingBtnAnimation) || floatingAnimOptions[0];

  // Footer Developer Credit Resolution (Supports both global Store Settings and per-Landing Page setting)
  const showDeveloperCredit =
    product.landingDeveloperCreditEnabled !== undefined
      ? product.landingDeveloperCreditEnabled
      : currentBusiness.developerCreditEnabled !== false;
  const developerCreditName = (
    product.landingDeveloperCreditName ||
    currentBusiness.developerCreditName ||
    'Web Studio BD'
  ).trim();
  const rawDeveloperCreditLink = (
    product.landingDeveloperCreditLink !== undefined
      ? product.landingDeveloperCreditLink
      : currentBusiness.developerCreditLink || ''
  ).trim();
  const normalizedDeveloperCreditLink =
    rawDeveloperCreditLink && !/^(javascript|data|vbscript):/i.test(rawDeveloperCreditLink)
      ? /^https?:\/\//i.test(rawDeveloperCreditLink)
        ? rawDeveloperCreditLink
        : `https://${rawDeveloperCreditLink}`
      : '';

  // ❄️ Falling Snow Animation Overlay & Storefront-Style Controls (ON/OFF, Intensity, Speed & Auto-Off Timer)
  const globalLandingSnowEnabled =
    currentBusiness.landingSnowfallEnabled !== undefined
      ? currentBusiness.landingSnowfallEnabled !== false
      : currentBusiness.winterSnowfallEnabled !== false;
  const isLandingSnowfallEnabled =
    product.landingSnowfallEnabled !== undefined
      ? product.landingSnowfallEnabled !== false
      : globalLandingSnowEnabled;
  const landingSnowfallIntensity = Math.max(
    10,
    Math.min(
      100,
      Number(
        currentBusiness.landingSnowfallIntensity ??
          currentBusiness.winterSnowfallIntensity ??
          50
      )
    )
  );
  const landingSnowfallSpeed = Math.max(
    30,
    Math.min(
      200,
      Number(
        currentBusiness.landingSnowfallSpeed ??
          currentBusiness.winterSnowfallSpeed ??
          100
      )
    )
  );
  const landingSnowfallAutoOffSec = Math.max(
    0,
    Number(
      currentBusiness.landingSnowfallAutoOffSec ??
        currentBusiness.winterSnowfallAutoOffSec ??
        0
    )
  );

  const [isSnowAutoStopped, setIsSnowAutoStopped] = useState(false);
  const [snowReplaySeed, setSnowReplaySeed] = useState(0);
  const [showSnowControlPanel, setShowSnowControlPanel] = useState(false);

  // ============================================================================
  // 🎉 LANDING PAGE ORDER SUCCESS LUXURY CELEBRATION (60FPS CANVAS PHYSICS)
  // ============================================================================
  const isLandingOrderConfettiEnabled =
    product.landingOrderConfettiEnabled !== undefined
      ? product.landingOrderConfettiEnabled !== false
      : currentBusiness.landingOrderConfettiEnabled !== undefined
        ? currentBusiness.landingOrderConfettiEnabled !== false
        : currentBusiness.storefrontOrderConfettiEnabled !== false;
  const landingCelebrationStyle: OrderCelebrationStyle =
    product.landingOrderConfettiStyle ||
    currentBusiness.landingOrderConfettiStyle ||
    currentBusiness.storefrontOrderConfettiStyle ||
    'dual_cannon_badge';
  const isLandingCelebrationBadgeOn =
    product.landingOrderCelebrationBadgeEnabled !== undefined
      ? product.landingOrderCelebrationBadgeEnabled !== false
      : currentBusiness.landingOrderCelebrationBadgeEnabled !== undefined
        ? currentBusiness.landingOrderCelebrationBadgeEnabled !== false
        : currentBusiness.storefrontOrderCelebrationBadgeEnabled !== false;

  const [isLpConfettiActive, setIsLpConfettiActive] = useState(false);
  const [lpConfettiSeed, setLpConfettiSeed] = useState(0);
  const lpConfettiTimerRef = useRef<number | null>(null);

  const triggerLandingOrderCelebration = () => {
    if (lpConfettiTimerRef.current) {
      window.clearTimeout(lpConfettiTimerRef.current);
    }
    setLpConfettiSeed(prev => prev + 1);
    setIsLpConfettiActive(true);
    lpConfettiTimerRef.current = window.setTimeout(() => {
      setIsLpConfettiActive(false);
      lpConfettiTimerRef.current = null;
    }, 2600);
  };

  useEffect(() => {
    return () => {
      if (lpConfettiTimerRef.current) {
        window.clearTimeout(lpConfettiTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!isLandingSnowfallEnabled || landingSnowfallAutoOffSec <= 0) {
      setIsSnowAutoStopped(false);
      return;
    }
    setIsSnowAutoStopped(false);
    const timer = window.setTimeout(() => {
      setIsSnowAutoStopped(true);
    }, landingSnowfallAutoOffSec * 1000);

    return () => window.clearTimeout(timer);
  }, [
    isLandingSnowfallEnabled,
    landingSnowfallAutoOffSec,
    landingSnowfallIntensity,
    landingSnowfallSpeed,
    snowReplaySeed
  ]);

  // Dynamic GPU-accelerated falling snow particle generator (identical to Storefront)
  const landingSnowParticles = useMemo(() => {
    const glyphs = ['❄', '❅', '❆'];
    const particleCount = Math.max(
      6,
      Math.min(80, Math.round((landingSnowfallIntensity / 100) * 68))
    );
    const speedMultiplier =
      (landingSnowfallSpeed / 100) * (0.65 + (landingSnowfallIntensity / 100) * 0.7);

    return Array.from({ length: particleCount }, (_, i) => {
      const seed = (i * 37 + 13) % 100;
      const seed2 = (i * 61 + 29) % 100;
      const isGlyph = i % 3 === 0;
      const leftPct = ((i * 100) / particleCount + (seed % 5) * 0.45) % 99;
      const sizePx = isGlyph ? 10 + (seed % 7) : 5 + (seed % 6);
      const baseDurationSec = 12 + (seed2 % 13);
      const durationSec = Number(
        Math.max(3.2, Math.min(36, baseDurationSec / Math.max(0.25, speedMultiplier))).toFixed(2)
      );
      const delaySec = -((i * 1.7 + (seed % 9)) % Math.max(6, Math.round(durationSec)));
      const driftMidPx = (i % 2 === 0 ? 1 : -1) * (12 + (seed % 22));
      const driftEndPx = (i % 2 === 0 ? -1 : 1) * (10 + (seed2 % 18));
      const opacity = isGlyph
        ? Number((0.48 + (seed % 35) * 0.01).toFixed(2))
        : Number((0.42 + (seed2 % 40) * 0.01).toFixed(2));
      const blurPx = i % 5 === 0 ? 0.8 : 0;
      const glyph = glyphs[i % glyphs.length];

      return {
        id: `lp_snow_${i}_${particleCount}`,
        isGlyph,
        glyph,
        leftPct: Number(leftPct.toFixed(2)),
        sizePx,
        durationSec,
        delaySec: Number(delaySec.toFixed(2)),
        driftMidPx,
        driftEndPx,
        opacity,
        blurPx
      };
    });
  }, [landingSnowfallIntensity, landingSnowfallSpeed]);

  return (
    <div
      className="landing-font-scale-scope min-h-screen w-full overflow-x-hidden bg-[#F3F6F4] text-slate-900 flex flex-col antialiased relative"
      data-storefront-theme={isLandingWinterTheme ? 'winter_frost' : undefined}
    >
      {/* Subtle Falling Snow Overlay (GPU-composited CSS 3D transforms; auto-paused during Order Confirmation for 60fps smoothness) */}
      {isLandingSnowfallEnabled && !isSnowAutoStopped && !confirmedOrder && (
        <div className="storefront-snowfall-overlay" aria-hidden="true">
          {landingSnowParticles.map(p => (
            <span
              key={p.id}
              className={`storefront-snow-particle ${
                p.isGlyph ? 'storefront-snow-glyph' : 'storefront-snow-orb'
              }`}
              style={
                {
                  left: `${p.leftPct}%`,
                  width: p.isGlyph ? undefined : `${p.sizePx}px`,
                  height: p.isGlyph ? undefined : `${p.sizePx}px`,
                  fontSize: p.isGlyph ? `${p.sizePx}px` : undefined,
                  animationDuration: `${p.durationSec}s`,
                  animationDelay: `${p.delaySec}s`,
                  '--snow-drift-mid': `${p.driftMidPx}px`,
                  '--snow-drift-end': `${p.driftEndPx}px`,
                  '--snow-opacity': String(p.opacity)
                } as React.CSSProperties
              }
            >
              {p.isGlyph ? p.glyph : null}
            </span>
          ))}
        </div>
      )}

      {/* 🎉 60fps High-DPI Canvas Order Celebration Physics Overlay + Center Luxury Pop Badge */}
      <OrderCelebrationOverlay
        active={isLpConfettiActive}
        seed={lpConfettiSeed}
        styleMode={landingCelebrationStyle}
        showCenterBadge={isLandingCelebrationBadgeOn}
        orderNo={confirmedOrder?.orderNo}
      />

      <ProductSeoHelmet
        business={currentBusiness}
        product={product}
        activeVariant={activeVariant}
        availableStock={availableStock}
      />

      {/* Admin Preview Bar (Visible when logged in as Admin or previewing from Admin Panel) */}
      {(isAuthenticated || onBackToAdmin) && (
        <div className="bg-slate-900 text-white px-3 sm:px-6 py-2 text-xs border-b border-slate-800">
          <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono text-[10px] font-bold shrink-0">
                LIVE LANDING PAGE
              </span>
              <span className="text-slate-300 font-mono text-[11px] truncate hidden sm:inline">
                {buildLandingPagePath(product)}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {/* Live 1-Click Toggle: Show/Hide Top Header Bar (Logo & Phone Number Bar) */}
              <button
                type="button"
                onClick={() => {
                  const next = !showTopHeader;
                  updateProduct(product.id, { landingTopHeaderEnabled: next });
                  showToast(
                    next
                      ? 'ল্যান্ডিং পেজের টপ হেডার বার (লোগো ও ফোন নম্বর) চালু (ON) করা হয়েছে'
                      : 'ল্যান্ডিং পেজের টপ হেডার বার (লোগো ও ফোন নম্বর) বন্ধ (OFF) করা হয়েছে',
                    next ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showTopHeader
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ল্যান্ডিং পেজের একদম উপরের হেডার বার (লোগো ও ফোন নম্বর বার) ON / OFF করুন"
              >
                <PhoneCall className="w-3 h-3" />
                <span>টপ হেডার (লোগো ও ফোন): {showTopHeader ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Top Heading Before Product Image */}
              <button
                type="button"
                onClick={() => {
                  const next = !showTopHeading;
                  updateProduct(product.id, { landingTopHeadingEnabled: next });
                  showToast(
                    next
                      ? 'প্রোডাক্ট ছবির উপরের হেডিং চালু (ON) করা হয়েছে'
                      : 'প্রোডাক্ট ছবির উপরের হেডিং বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showTopHeading
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="প্রোডাক্ট ছবির শুরুতে হেডিং ON / OFF করুন"
              >
                <Sparkles className="w-3 h-3" />
                <span>টপ হেডিং: {showTopHeading ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Global Product Image HD Zoom ON/OFF + Style Switcher */}
              <button
                type="button"
                onClick={() => {
                  const nextZoom = !isGlobalImageZoomEnabled;
                  updateBusiness({ productImageZoomEnabled: nextZoom });
                  showToast(
                    nextZoom
                      ? 'প্রোডাক্ট ছবি উকমার্স লাইটবক্স ও জুম গ্লোবালি চালু (ON) করা হয়েছে!'
                      : 'প্রোডাক্ট ছবি জুম গ্লোবালি বন্ধ (OFF) করা হয়েছে!',
                    nextZoom ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  isGlobalImageZoomEnabled
                    ? 'bg-indigo-500/25 text-indigo-200 border-indigo-400/50 hover:bg-indigo-500/35'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="গ্লোবাল প্রোডাক্ট ছবি উকমার্স লাইটবক্স ও জুম (ওয়েবসাইট ও ল্যান্ডিং পেজ) ON / OFF করুন"
              >
                <Search className="w-3 h-3 text-amber-300" />
                <span>ছবি জুম: {isGlobalImageZoomEnabled ? 'ON' : 'OFF'}</span>
              </button>

              {isGlobalImageZoomEnabled && (
                <button
                  type="button"
                  onClick={() => {
                    const styles: Array<
                      'woocommerce_lightbox' | 'hover_and_lightbox' | 'hover_only'
                    > = ['woocommerce_lightbox', 'hover_and_lightbox', 'hover_only'];
                    const nextStyle =
                      styles[(styles.indexOf(lpImageZoomStyle) + 1) % styles.length];
                    updateBusiness({ productImageZoomStyle: nextStyle });
                    showToast(
                      `ছবি জুম স্টাইল: "${lpZoomStyleLabels[nextStyle]}" সেট করা হয়েছে!`,
                      'success'
                    );
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-violet-500/25 hover:bg-violet-500/35 text-violet-200 border border-violet-400/50 font-bold text-[11px] transition-colors cursor-pointer"
                  title="ছবি জুমের স্টাইল পরিবর্তন করুন (উকমার্স লাইটবক্স / হোভার+লাইটবক্স / শুধু হোভার)"
                >
                  <span>স্টাইল: {lpZoomStyleLabels[lpImageZoomStyle]}</span>
                </button>
              )}

              {/* Live 1-Click Toggle: Show/Hide Elementor-Style Top Animated Regular & Offer Price Banner */}
              <button
                type="button"
                onClick={() => {
                  const next = !showTopPriceBanner;
                  updateProduct(product.id, { landingTopPriceBannerEnabled: next });
                  showToast(
                    next
                      ? 'শুরুতে পূর্বের মূল্য ও অফার মূল্য অ্যানিমেশন ব্যানার চালু (ON) করা হয়েছে'
                      : 'শুরুতে পূর্বের মূল্য ও অফার মূল্য অ্যানিমেশন ব্যানার বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showTopPriceBanner
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="শুরুতে পূর্বের মূল্য ও আজকের অফার মূল্য অ্যানিমেশন ব্যানার ON / OFF করুন"
              >
                <Flame className="w-3 h-3 text-rose-400" />
                <span>টপ প্রাইস ব্যানার: {showTopPriceBanner ? 'ON' : 'OFF'}</span>
              </button>

              {showTopPriceBanner && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      const themes: Array<'emerald' | 'crimson' | 'midnight' | 'amber' | 'light'> = [
                        'emerald',
                        'crimson',
                        'midnight',
                        'amber',
                        'light'
                      ];
                      const themeNames: Record<string, string> = {
                        emerald: 'সিম্পল গ্রিন (Clean Green)',
                        crimson: 'প্রিমিয়াম রেড (Crimson Red)',
                        midnight: 'রয়েল ডার্ক গোল্ড (Dark Gold)',
                        amber: 'গোল্ডেন অফার (Warm Gold)',
                        light: 'মিনিমাল হোয়াইট (Pure White)'
                      };
                      const nextTheme =
                        themes[(themes.indexOf(topPriceBannerTheme) + 1) % themes.length];
                      updateProduct(product.id, { landingTopPriceBannerTheme: nextTheme });
                      showToast(`প্রাইস ব্যানার কালার: ${themeNames[nextTheme]} সেট করা হয়েছে`, 'info');
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                    title="প্রাইস অ্যানিমেশন ব্যানারের কালার থিম পরিবর্তন করুন"
                  >
                    <span>প্রাইস কালার বদলান</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const styles: Array<'circle' | 'underline' | 'burst'> = [
                        'circle',
                        'underline',
                        'burst'
                      ];
                      const styleNames: Record<string, string> = {
                        circle: 'সার্কেল মার্ক অ্যানিমেশন',
                        underline: 'ডাবল আন্ডারলাইন অ্যানিমেশন',
                        burst: 'হাইলাইট বক্স ও সার্কেল'
                      };
                      const nextStyle =
                        styles[(styles.indexOf(topPriceHighlightStyle) + 1) % styles.length];
                      updateProduct(product.id, { landingTopPriceHighlightStyle: nextStyle });
                      showToast(`প্রাইস অ্যানিমেশন স্টাইল: ${styleNames[nextStyle]}`, 'info');
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                    title="প্রাইস হাইলাইট অ্যানিমেশন স্টাইল পরিবর্তন করুন"
                  >
                    <span>প্রাইস স্টাইল বদলান</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const speeds: Array<'slow' | 'normal' | 'fast' | 'ultra_fast'> = [
                        'normal',
                        'fast',
                        'ultra_fast',
                        'slow'
                      ];
                      const speedLabels: Record<string, string> = {
                        slow: 'স্লো (Slow)',
                        normal: 'নরমাল (Normal)',
                        fast: 'ফাস্ট (Fast)',
                        ultra_fast: 'সুপার ফাস্ট (Ultra Fast)'
                      };
                      const nextSpeed =
                        speeds[(speeds.indexOf(topPriceAnimationSpeed) + 1) % speeds.length];
                      updateProduct(product.id, {
                        landingTopPriceAnimationEnabled: true,
                        landingTopPriceAnimationSpeed: nextSpeed
                      });
                      showToast(
                        `টপ প্রাইস অ্যানিমেশন স্পিড: ${speedLabels[nextSpeed]} সেট করা হয়েছে!`,
                        'info'
                      );
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                    title="টপ প্রাইস ব্যানারের অ্যানিমেশন স্পিড (স্লো / নরমাল / ফাস্ট / সুপার ফাস্ট) পরিবর্তন করুন"
                  >
                    <span>
                      প্রাইস স্পিড:{' '}
                      {topPriceAnimationSpeed === 'slow'
                        ? 'স্লো'
                        : topPriceAnimationSpeed === 'fast'
                        ? 'ফাস্ট'
                        : topPriceAnimationSpeed === 'ultra_fast'
                        ? 'সুপার ফাস্ট'
                        : 'নরমাল'}
                    </span>
                  </button>
                </>
              )}

              {/* Live 1-Click Toggle & Direct Upload: Banner 1 (Top of Landing Page) */}
              <input
                ref={promoBannerFileInputRef}
                type="file"
                accept="image/*"
                onChange={handleDirectPromoBannerUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => {
                  const next = !showPromoBanner;
                  updateProduct(product.id, { landingPromoBannerEnabled: next });
                  showToast(
                    next
                      ? 'ব্যানার ১ (শুরুতে) চালু (ON) করা হয়েছে'
                      : 'ব্যানার ১ (শুরুতে) বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showPromoBanner
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ল্যান্ডিং পেজের শুরুতে ব্যানার ১ ON / OFF করুন"
              >
                <ImageIcon className="w-3 h-3 text-emerald-400" />
                <span>ব্যানার ১: {showPromoBanner ? 'ON' : 'OFF'}</span>
              </button>
              <button
                type="button"
                onClick={() => promoBannerFileInputRef.current?.click()}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 border border-emerald-500/40 transition-colors cursor-pointer"
                title="সরাসরি ব্যানার ১ ছবি আপলোড করুন"
              >
                <Upload className="w-3 h-3" />
                <span>{promoBannerImage ? 'ব্যানার ১ পরিবর্তন' : 'ব্যানার ১ আপলোড'}</span>
              </button>

              {/* Live 1-Click Toggle & Direct Upload: Banner 2 (Before Video Section) */}
              <input
                ref={promoBanner2FileInputRef}
                type="file"
                accept="image/*"
                onChange={handleDirectPromoBanner2Upload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => {
                  const next = !showPromoBanner2;
                  updateProduct(product.id, { landingPromoBanner2Enabled: next });
                  showToast(
                    next
                      ? 'ব্যানার ২ (ভিডিওর উপরে) চালু (ON) করা হয়েছে'
                      : 'ব্যানার ২ (ভিডিওর উপরে) বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showPromoBanner2
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/40 hover:bg-teal-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ভিডিও সেকশনের উপরে ব্যানার ২ ON / OFF করুন"
              >
                <ImageIcon className="w-3 h-3 text-teal-400" />
                <span>ব্যানার ২: {showPromoBanner2 ? 'ON' : 'OFF'}</span>
              </button>
              <button
                type="button"
                onClick={() => promoBanner2FileInputRef.current?.click()}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-teal-600/30 hover:bg-teal-600/50 text-teal-200 border border-teal-500/40 transition-colors cursor-pointer"
                title="সরাসরি ব্যানার ২ (ভিডিওর উপরে) ছবি আপলোড করুন"
              >
                <Upload className="w-3 h-3" />
                <span>{promoBanner2Image ? 'ব্যানার ২ পরিবর্তন' : 'ব্যানার ২ আপলোড'}</span>
              </button>

              {/* Live 1-Click Toggle: Turn Heading Animation ON / OFF */}
              {showTopHeading && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !isTopHeadingAnimated;
                      updateProduct(product.id, { landingTopHeadingAnimation: next });
                      showToast(
                        next
                          ? 'হেডিং অ্যানিমেশন চালু (ON) করা হয়েছে'
                          : 'হেডিং অ্যানিমেশন বন্ধ (OFF - স্থির) করা হয়েছে',
                        'info'
                      );
                    }}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                      isTopHeadingAnimated
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                    }`}
                    title="হেডিংয়ের অ্যানিমেশন ইফেক্ট ON / OFF করুন"
                  >
                    <Flame className="w-3 h-3" />
                    <span>অ্যানিমেশন: {isTopHeadingAnimated ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const themes: Array<'emerald' | 'crimson' | 'midnight' | 'light'> = [
                        'emerald',
                        'crimson',
                        'midnight',
                        'light'
                      ];
                      const nextTheme =
                        themes[(themes.indexOf(topHeadingTheme) + 1) % themes.length];
                      updateProduct(product.id, { landingTopHeadingTheme: nextTheme });
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                    title="হেডিংয়ের কালার ডিজাইন পরিবর্তন করুন"
                  >
                    <span>কালার বদলান</span>
                  </button>
                </>
              )}

              {/* Live 1-Click Toggle: Show/Hide Evergreen Countdown Timer */}
              <button
                type="button"
                onClick={() => {
                  const next = !showCountdown;
                  updateProduct(product.id, { landingCountdownEnabled: next });
                  showToast(
                    next
                      ? `হিরো কাউন্টডাউন টাইমার (${toBanglaDigits(countdownHours, 1)} ঘণ্টা) চালু (ON) করা হয়েছে`
                      : 'হিরো কাউন্টডাউন টাইমার বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showCountdown
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="অফার কাউন্টডাউন টাইমার ON / OFF করুন"
              >
                <Clock className="w-3 h-3" />
                <span>কাউন্টডাউন: {showCountdown ? `ON (${toBanglaDigits(countdownHours, 1)} ঘণ্টা)` : 'OFF'}</span>
              </button>

              {showCountdown && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      const hourOptions = [3, 6, 9, 12, 24];
                      const currentIdx = hourOptions.indexOf(countdownHours);
                      const nextHours = hourOptions[(currentIdx + 1) % hourOptions.length];
                      try {
                        window.localStorage.setItem(
                          `lp_evergreen_timer_${product.id}_${nextHours}`,
                          String(Date.now())
                        );
                      } catch {}
                      updateProduct(product.id, { landingCountdownHours: nextHours });
                      showToast(
                        `কাউন্টডাউন টাইমার ${toBanglaDigits(nextHours, 1)} ঘণ্টা সেট করা হয়েছে (০ হলে অটো রিস্টার্ট হবে)`,
                        'info'
                      );
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                    title="কাউন্টডাউন সময় পরিবর্তন করুন (৩ / ৬ / ৯ / ১২ / ২৪ ঘণ্টা)"
                  >
                    <span>সময়: {toBanglaDigits(countdownHours, 1)} ঘণ্টা বদলান</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const nextPos =
                        countdownPosition === 'hero_info' ? 'top_heading' : 'hero_info';
                      updateProduct(product.id, { landingCountdownPosition: nextPos });
                      showToast(
                        nextPos === 'top_heading'
                          ? 'কাউন্টডাউন টপ হেডিংয়ের নিচে সেট করা হয়েছে'
                          : 'কাউন্টডাউন হিরো প্রাইস ও টেক্সটের কাছে সেট করা হয়েছে',
                        'info'
                      );
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                    title="কাউন্টডাউন পজিশন পরিবর্তন করুন"
                  >
                    <span>
                      পজিশন: {countdownPosition === 'top_heading' ? 'টপ হেডিংয়ে' : 'হিরো টেক্সটে'}
                    </span>
                  </button>
                </>
              )}

              {/* Live 1-Click Toggle: Show/Hide Scarcity Stock & High-Demand Urgency Alert */}
              <button
                type="button"
                onClick={() => {
                  const next = !showLandingScarcity;
                  updateProduct(product.id, { landingScarcityEnabled: next });
                  showToast(
                    next
                      ? `সীমিত স্টক অ্যালার্ট ("অফার মূল্যে আর মাত্র ${scarcityLeftCount} টি বাকি আছে!") চালু (ON) করা হয়েছে`
                      : 'সীমিত স্টক ও চাহিদা অ্যালার্ট বন্ধ (OFF) করা হয়েছে',
                    next ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showLandingScarcity
                    ? 'bg-rose-500/25 text-rose-200 border-rose-400/50 hover:bg-rose-500/35'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="অফার মূল্যে আর মাত্র ১০ টি বাকি আছে / সীমিত স্টক অ্যালার্ট ১-ক্লিকে ON বা OFF করুন"
              >
                <Flame className="w-3 h-3 text-orange-400" />
                <span>সীমিত স্টক ({scarcityLeftCount} টি): {showLandingScarcity ? 'ON' : 'OFF'}</span>
              </button>

              {showLandingScarcity && (
                <button
                  type="button"
                  onClick={() => {
                    const options = [10, 7, 5, 12, 15];
                    const idx = options.indexOf(scarcityLeftCount);
                    const nextCount = options[(idx + 1) % options.length];
                    updateProduct(product.id, { landingScarcityCount: nextCount });
                    showToast(
                      `অফার মূল্যে আর মাত্র ${nextCount} টি বাকি আছে সেট করা হয়েছে!`,
                      'info'
                    );
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                  title="বাকি থাকা স্টকের সংখ্যা পরিবর্তন করুন (১০ / ৭ / ৫ / ১২ / ১৫ টি)"
                >
                  <span>বাকি: {scarcityLeftCount} টি বদলান</span>
                </button>
              )}

              {/* Live 1-Click Toggle: Show/Hide Product Details Section */}
              <button
                type="button"
                onClick={() => {
                  const next = !showFeaturesSection;
                  updateProduct(product.id, { landingFeaturesEnabled: next });
                  showToast(
                    next
                      ? 'প্রোডাক্ট ডিটেইলস ও বৈশিষ্ট্য সেকশন চালু (ON) করা হয়েছে'
                      : 'প্রোডাক্ট ডিটেইলস ও বৈশিষ্ট্য সেকশন বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showFeaturesSection
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ড্রেসের বিশেষত্ব ও ফেব্রিক ডিটেইলস সেকশন ON / OFF করুন"
              >
                <BadgeCheck className="w-3 h-3" />
                <span>ডিটেইলস সেকশন: {showFeaturesSection ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Trust & Guarantee Section */}
              <button
                type="button"
                onClick={() => {
                  const next = !showTrustSection;
                  updateProduct(product.id, { landingTrustSectionEnabled: next });
                  showToast(
                    next
                      ? 'গ্যারান্টি ও বিশ্বস্ততা টপিক সেকশন চালু (ON) করা হয়েছে'
                      : 'গ্যারান্টি ও বিশ্বস্ততা টপিক সেকশন বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showTrustSection
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/40 hover:bg-teal-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="গ্যারান্টি টপিক সেকশন ON / OFF করুন"
              >
                <ShieldCheck className="w-3 h-3" />
                <span>গ্যারান্টি টপিক: {showTrustSection ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Product Video / YouTube / Reels Section */}
              <button
                type="button"
                onClick={() => {
                  const next = !showVideoSection;
                  updateProduct(product.id, { landingVideoEnabled: next });
                  showToast(
                    next
                      ? 'প্রোডাক্ট ভিডিও / রিলস সেকশন চালু (ON) করা হয়েছে'
                      : 'প্রোডাক্ট ভিডিও / রিলস সেকশন বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showVideoSection
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="প্রোডাক্ট ভিডিও / ইউটিউব বা রিলস সেকশন ON / OFF করুন"
              >
                <Play className="w-3 h-3" />
                <span>ভিডিও সেকশন: {showVideoSection ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Variation Popup Size Chart Button */}
              <button
                type="button"
                onClick={() => {
                  const next = !showSizeChart;
                  updateProduct(product.id, { landingSizeChartEnabled: next });
                  showToast(
                    next
                      ? 'ভ্যারিয়েশনের উপরের সাইজ চার্ট বাটন চালু (ON) করা হয়েছে'
                      : 'ভ্যারিয়েশনের উপরের সাইজ চার্ট বাটন বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showSizeChart
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 hover:bg-indigo-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ভ্যারিয়েশনের উপরের 'সাইজ চার্ট দেখুন' পপ-আপ বাটন ON / OFF করুন"
              >
                <Ruler className="w-3 h-3" />
                <span>পপ-আপ চার্ট: {showSizeChart ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Full Body Size Chart Section near Description */}
              <button
                type="button"
                onClick={() => {
                  const next = !showBodySizeChart;
                  updateProduct(product.id, { landingBodySizeChartEnabled: next });
                  showToast(
                    next
                      ? 'পেজের বডিতে ফুল সাইজ চার্ট সেকশন চালু (ON) করা হয়েছে'
                      : 'পেজের বডিতে ফুল সাইজ চার্ট সেকশন বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showBodySizeChart
                    ? 'bg-violet-500/20 text-violet-300 border-violet-500/40 hover:bg-violet-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ডেসক্রিপশনের নিচে বডির ভেতর ফুল সাইজ চার্ট টেবিল ON / OFF করুন"
              >
                <Ruler className="w-3 h-3" />
                <span>বডি ফুল চার্ট: {showBodySizeChart ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Landing Page Spin the Wheel ON/OFF */}
              <button
                type="button"
                onClick={() => {
                  const next = !productLandingSpinEnabled;
                  updateProduct(product.id, { landingSpinWheelEnabled: next });
                  if (next && currentBusiness.landingSpinWheelEnabled === false) {
                    updateBusiness({ landingSpinWheelEnabled: true });
                  }
                  showToast(
                    next
                      ? 'এই ল্যান্ডিং পেজে স্পিন দ্য হুইল চালু (ON) করা হয়েছে'
                      : 'এই ল্যান্ডিং পেজে স্পিন দ্য হুইল বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  spinWheelEnabled
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="এই ল্যান্ডিং পেজে স্পিন দ্য হুইল (Spin the Wheel) অটো পপ-আপ ON / OFF করুন"
              >
                <Gift className="w-3 h-3" />
                <span>স্পিন হুইল: {spinWheelEnabled ? 'ON' : 'OFF'}</span>
              </button>

              {/* Open Landing Page Spin the Wheel Admin Customize & Leads Modal */}
              <button
                type="button"
                onClick={() => {
                  setSpinConfigDraft(spinWheelConfig);
                  setSpinAdminTab('settings');
                  setShowSpinAdminModal(true);
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-gradient-to-r from-amber-500/25 to-rose-500/25 text-amber-200 border border-amber-400/50 hover:from-amber-500/35 hover:to-rose-500/35 transition-colors cursor-pointer"
                title="ল্যান্ডিং পেজের স্পিন হুইল অফার কাস্টমাইজ ও কাস্টমার নাম্বার লিস্ট দেখুন"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>স্পিন হুইল সেটিংস ({storedSpinLeads.length})</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Live Recent Order Notification Popup */}
              <button
                type="button"
                onClick={() => {
                  const next = !showSocialProof;
                  setIsSocialProofDismissed(false);
                  updateProduct(product.id, { landingSocialProofEnabled: next });
                  showToast(
                    next
                      ? 'রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ চালু (ON) করা হয়েছে'
                      : 'রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showSocialProof
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="রিসেন্ট অর্ডার নোটিফিকেশন পপ-আপ (Live Order Social Proof) ON / OFF করুন"
              >
                <Bell className="w-3 h-3" />
                <span>অর্ডার পপ-আপ: {showSocialProof ? 'ON' : 'OFF'}</span>
              </button>

              {showSocialProof && (
                <button
                  type="button"
                  onClick={() => {
                    const gapOptions = [6, 12, 16, 25, 40, 60];
                    const idx = gapOptions.indexOf(socialProofGapSec);
                    const nextGap = gapOptions[(idx + 1) % gapOptions.length];
                    setIsSocialProofDismissed(false);
                    updateProduct(product.id, { landingSocialProofIntervalSec: nextGap });
                    showToast(
                      `অর্ডার নোটিফিকেশন টাইম গ্যাপ: প্রতি ${toBanglaDigits(nextGap, 1)} সেকেন্ড পর পর দেখাবে`,
                      'info'
                    );
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                  title="অর্ডার নোটিফিকেশন পপ-আপ কত সেকেন্ড গ্যাপ দিয়ে আসবে তা পরিবর্তন করুন (৬ / ১২ / ১৬ / ২৫ / ৪০ / ৬০ সেকেন্ড)"
                >
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>পপ-আপ গ্যাপ: {toBanglaDigits(socialProofGapSec, 1)} সে.</span>
                </button>
              )}

              {/* Live 1-Click Toggle: Show/Hide Customer Reviews Section */}
              <button
                type="button"
                onClick={() => {
                  const next = !reviewsEnabled;
                  updateProduct(product.id, { landingReviewsEnabled: next });
                  showToast(
                    next
                      ? 'কাস্টমার রিভিউ সেকশন চালু (ON) করা হয়েছে'
                      : 'কাস্টমার রিভিউ সেকশন বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  reviewsEnabled
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="কাস্টমার রিভিউ সেকশন ON / OFF করুন"
              >
                <Star className="w-3 h-3" />
                <span>রিভিউ: {reviewsEnabled ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Customer Reviews Slider vs Grid Mode */}
              {reviewsEnabled && (
                <button
                  type="button"
                  onClick={() => {
                    const next = !reviewsSliderEnabled;
                    updateProduct(product.id, { landingReviewsSliderEnabled: next });
                    showToast(
                      next
                        ? '🎠 কাস্টমার রিভিউ স্লাইডার মোড চালু (ON) করা হয়েছে (কম জায়গায় অনেক রিভিউ দেখাবে)!'
                        : '📋 কাস্টমার রিভিউ গ্রিড মোড সেট (OFF) করা হয়েছে!',
                      next ? 'success' : 'info'
                    );
                  }}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                    reviewsSliderEnabled
                      ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/50 hover:bg-emerald-500/35'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                  title="কাস্টমার রিভিউ স্লাইডার (ON) নাকি গ্রিড ভিউ (OFF) দেখাবে তা পরিবর্তন করুন"
                >
                  <span>🎠 রিভিউ স্লাইডার: {reviewsSliderEnabled ? 'ON' : 'OFF (গ্রিড)'}</span>
                </button>
              )}

              {/* Live 1-Click Toggle: Show/Hide Footer Anti-Fake Order Notice */}
              <button
                type="button"
                onClick={() => {
                  const next = !showFooterWarning;
                  updateProduct(product.id, { landingFooterWarningEnabled: next });
                  showToast(
                    next
                      ? 'ফুটার ফেক অর্ডার সতর্কবার্তা চালু (ON) করা হয়েছে'
                      : 'ফুটার ফেক অর্ডার সতর্কবার্তা বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showFooterWarning
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ফুটারে ফেক অর্ডার না করার অনুরোধ বার্তা ON / OFF করুন"
              >
                <AlertTriangle className="w-3 h-3" />
                <span>ফেক অর্ডার নোটিশ: {showFooterWarning ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Footer Developer Credit */}
              <button
                type="button"
                onClick={() => {
                  const next = !showDeveloperCredit;
                  updateProduct(product.id, { landingDeveloperCreditEnabled: next });
                  updateBusiness({ developerCreditEnabled: next });
                  showToast(
                    next
                      ? 'ফুটার ডেভেলপার ক্রেডিট চালু (ON) করা হয়েছে'
                      : 'ফুটার ডেভেলপার ক্রেডিট বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showDeveloperCredit
                    ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 hover:bg-sky-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ফুটারে ডেভেলপার ক্রেডিট ON / OFF করুন"
              >
                <span>ডেভেলপার ক্রেডিট: {showDeveloperCredit ? 'ON' : 'OFF'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const next = !showLiveViewers;
                  updateProduct(product.id, { landingLiveViewersEnabled: next });
                  showToast(
                    next
                      ? 'লাইভ ভিউয়ার কাউন্টার (12-48) চালু (ON) করা হয়েছে'
                      : 'লাইভ ভিউয়ার কাউন্টার বন্ধ (OFF) করা হয়েছে',
                    'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showLiveViewers
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="প্রোডাক্ট পেজে 'People currently viewing this product' কাউন্টার ON / OFF করুন"
              >
                <Eye className="w-3 h-3" />
                <span>লাইভ ভিউয়ার: {showLiveViewers ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Total Price inside Mobile Floating "অর্ডার কনফার্ম করুন" Button */}
              <button
                type="button"
                onClick={() => {
                  const next = !showFloatingBtnPrice;
                  updateProduct(product.id, { landingFloatingBtnPriceEnabled: next });
                  showToast(
                    next
                      ? `মোবাইল ফ্লোটিং বাটনে মোট প্রাইস — অর্ডার কনফার্ম করুন (${formatCurrency(grandTotal)}) চালু (ON) করা হয়েছে`
                      : 'মোবাইল ফ্লোটিং বাটনে প্রাইস বন্ধ (OFF) করা হয়েছে (শুধু "অর্ডার কনফার্ম করুন" দেখাবে)',
                    next ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showFloatingBtnPrice
                    ? 'bg-rose-500/25 text-rose-200 border-rose-400/50 hover:bg-rose-500/35'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="মোবাইল ভিউতে নিচের ফ্লোটিং 'অর্ডার কনফার্ম করুন' বাটনের ভেতর মোট প্রাইস (যেমন: ৳1,010) ON / OFF করুন"
              >
                <CheckCircle2 className="w-3 h-3 text-rose-300" />
                <span>ফ্লোটিং বাটন প্রাইস: {showFloatingBtnPrice ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Switcher: Cycle Floating "অর্ডার কনফার্ম করুন" Button Animation Style */}
              <button
                type="button"
                onClick={() => {
                  const curIdx = floatingAnimOptions.findIndex(o => o.id === floatingBtnAnimation);
                  const nextOpt =
                    floatingAnimOptions[(curIdx + 1) % floatingAnimOptions.length];
                  updateProduct(product.id, { landingFloatingBtnAnimation: nextOpt.id });
                  showToast(
                    `ফ্লোটিং অর্ডার বাটন অ্যানিমেশন: "${nextOpt.label}" সেট করা হয়েছে!`,
                    'success'
                  );
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-gradient-to-r from-amber-500/25 via-rose-500/25 to-emerald-500/25 text-amber-200 border border-amber-400/50 hover:from-amber-500/35 hover:to-emerald-500/35 transition-colors cursor-pointer"
                title="ফ্লোটিং 'অর্ডার কনফার্ম করুন' বাটনের অ্যানিমেশন স্টাইল পরিবর্তন করুন (জাম্প বাউন্স / লগইন বাটন শাইন / কার্ট বর্ডার বিম / প্রিমিয়াম কম্বো / রিং পালস গ্লো / বন্ধ)"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>ফ্লোটিং অ্যানিমেশন: {currentFloatingAnimObj.shortLabel}</span>
              </button>

              {/* Live 1-Click Switcher: Cycle Variation Switcher Design (6 Mobile-First Styles) */}
              <button
                type="button"
                onClick={() => {
                  const curIdx = LANDING_VARIANT_DESIGN_OPTIONS.findIndex(
                    o => o.id === variantStyle
                  );
                  const nextOpt =
                    LANDING_VARIANT_DESIGN_OPTIONS[
                      (curIdx + 1) % LANDING_VARIANT_DESIGN_OPTIONS.length
                    ];
                  updateProduct(product.id, { landingVariantStyle: nextOpt.id });
                  updateBusiness({ landingVariantStyle: nextOpt.id });
                  showToast(
                    `ভ্যারিয়েশন বাটন ডিজাইন: "${nextOpt.label}" সেট করা হয়েছে!`,
                    'success'
                  );
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-emerald-500/25 text-emerald-200 border border-emerald-400/50 hover:bg-emerald-500/35 transition-colors cursor-pointer"
                title="ল্যান্ডিং পেজের সাইজ / ভ্যারিয়েশন সিলেক্টর বাটনের ডিজাইন পরিবর্তন করুন (৬টি মোবাইল রেসপনসিভ ডিজাইন)"
              >
                <Sparkles className="w-3 h-3 text-emerald-300" />
                <span>ভ্যারিয়েশন ডিজাইন: {currentVariantStyleObj.shortLabel}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Price inside Variation Selector Buttons */}
              <button
                type="button"
                onClick={() => {
                  const next = !showVariantPrice;
                  updateProduct(product.id, { landingVariantShowPrice: next });
                  updateBusiness({ landingVariantShowPrice: next });
                  showToast(
                    next
                      ? 'ভ্যারিয়েশন বাটনের ভেতর প্রাইস দেখানো চালু (ON) করা হয়েছে'
                      : 'ভ্যারিয়েশন বাটনের ভেতর প্রাইস বন্ধ (OFF) করা হয়েছে',
                    next ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showVariantPrice
                    ? 'bg-cyan-500/25 text-cyan-200 border-cyan-400/50 hover:bg-cyan-500/35'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ভ্যারিয়েশন / সাইজ বাটনের ভেতর দাম (Price) দেখানো ON / OFF করুন"
              >
                <span>ভ্যারিয়েশন প্রাইস: {showVariantPrice ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide Size Measurement (বুক/লম্বা) inside Variation Selector Buttons */}
              <button
                type="button"
                onClick={() => {
                  const next = !showVariantMeasurement;
                  updateProduct(product.id, { landingVariantShowMeasurement: next });
                  updateBusiness({ landingVariantShowMeasurement: next });
                  showToast(
                    next
                      ? 'ভ্যারিয়েশন বাটনে সাইজ মাপ (বুক/লম্বা) দেখানো চালু (ON) হয়েছে'
                      : 'ভ্যারিয়েশন বাটনে সাইজ মাপ (বুক/লম্বা) বন্ধ (OFF) হয়েছে',
                    next ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showVariantMeasurement
                    ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/50 hover:bg-emerald-500/35'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ভ্যারিয়েশন / সাইজ বাটনের ভেতর সাইজ মাপ (বুক/লম্বা) দেখানো ON / OFF করুন"
              >
                <span>ভ্যারিয়েশন মাপ: {showVariantMeasurement ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Toggle: Show/Hide "সাইজ পছন্দ করুন" Button on LP-2 Showcase Cards & Mobile 2-Column Layout */}
              {isTemplate2 && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !showcaseMobileTwoCols;
                      updateProduct(product.id, { landingShowcaseMobileTwoCols: next });
                      showToast(
                        next
                          ? 'মোবাইলে ১ লাইনে ২টি করে প্রোডাক্ট (2 কলাম) চালু (ON) করা হয়েছে!'
                          : 'মোবাইলে ১ লাইনে ১টি করে প্রোডাক্ট (1 কলাম) সেট (OFF) করা হয়েছে!',
                        next ? 'success' : 'info'
                      );
                    }}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                      showcaseMobileTwoCols
                        ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/50 hover:bg-emerald-500/35'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                    title="মোবাইলে ১ লাইনে ২টি প্রোডাক্ট (ON) নাকি ১টি প্রোডাক্ট (OFF) দেখাবে তা পরিবর্তন করুন"
                  >
                    <span>
                      📱 মোবাইলে ২টি করে প্রোডাক্ট: {showcaseMobileTwoCols ? 'ON (২টি)' : 'OFF (১টি)'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !showShowcaseSelectBtn;
                      updateProduct(product.id, { landingShowcaseSelectBtnEnabled: next });
                      showToast(
                        next
                          ? `কার্ডের "${showcaseSelectBtnText}" বাটন চালু (ON) করা হয়েছে`
                          : `কার্ডের "${showcaseSelectBtnText}" বাটন বন্ধ (OFF) করা হয়েছে`,
                        next ? 'success' : 'info'
                      );
                    }}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                      showShowcaseSelectBtn
                        ? 'bg-rose-500/25 text-rose-200 border-rose-400/50 hover:bg-rose-500/35'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                    }`}
                    title='Landing Page 2-এর প্রোডাক্ট কার্ডের নিচে "সাইজ পছন্দ করুন" বাটন ON / OFF করুন'
                  >
                    <span>"{showcaseSelectBtnText}" বাটন: {showShowcaseSelectBtn ? 'ON' : 'OFF'}</span>
                  </button>
                </>
              )}

              {/* Live 1-Click Toggle: Show/Hide % Discount Badge on Product Image */}
              <button
                type="button"
                onClick={() => {
                  const next = !showImageDiscountBadge;
                  updateProduct(product.id, { landingImageBadgeEnabled: next });
                  updateBusiness({ landingImageBadgeEnabled: next });
                  showToast(
                    next
                      ? 'প্রোডাক্ট ছবির উপরে "% ছাড়" ব্যাজ চালু (ON) করা হয়েছে'
                      : 'প্রোডাক্ট ছবির উপরে "% ছাড়" ব্যাজ বন্ধ (OFF) করা হয়েছে',
                    next ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showImageDiscountBadge
                    ? 'bg-rose-500/25 text-rose-200 border-rose-400/50 hover:bg-rose-500/35'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="প্রোডাক্ট ছবির উপরের '% ছাড়' ব্যাজ ON / OFF করুন"
              >
                <span>ছবির % ছাড় ব্যাজ: {showImageDiscountBadge ? 'ON' : 'OFF'}</span>
              </button>

              {/* Live 1-Click Switcher: Cycle Product Image % Discount Badge Design */}
              <button
                type="button"
                onClick={() => {
                  const curIdx = LANDING_IMAGE_BADGE_DESIGN_OPTIONS.findIndex(
                    o => o.id === imageBadgeStyle
                  );
                  const nextOpt =
                    LANDING_IMAGE_BADGE_DESIGN_OPTIONS[
                      (curIdx + 1) % LANDING_IMAGE_BADGE_DESIGN_OPTIONS.length
                    ];
                  updateProduct(product.id, {
                    landingImageBadgeEnabled: true,
                    landingImageBadgeStyle: nextOpt.id
                  });
                  updateBusiness({
                    landingImageBadgeEnabled: true,
                    landingImageBadgeStyle: nextOpt.id
                  });
                  showToast(
                    `ছবির % ছাড় ব্যাজ ডিজাইন: "${nextOpt.label}" সেট করা হয়েছে!`,
                    'success'
                  );
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-amber-500/25 text-amber-200 border border-amber-400/50 hover:bg-amber-500/35 transition-colors cursor-pointer"
                title="প্রোডাক্ট ছবির উপরের '% ছাড়' ব্যাজের ডিজাইন পরিবর্তন করুন (৬টি ডিজাইন)"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>ছাড় ব্যাজ ডিজাইন: {currentImageBadgeStyleObj.shortLabel}</span>
              </button>

              {/* ❄️ Live 1-Click Winter Theme Toggle (Storefront-Style Cool Blues & Snowy Whites) */}
              <button
                type="button"
                onClick={() => {
                  const nextWinter = !isLandingWinterTheme;
                  updateProduct(product.id, {
                    landingWinterThemeEnabled: nextWinter,
                    ...(nextWinter ? { landingSnowfallEnabled: true } : {})
                  });
                  updateBusiness({
                    landingWinterThemeEnabled: nextWinter,
                    ...(nextWinter ? { landingSnowfallEnabled: true } : {})
                  });
                  showToast(
                    nextWinter
                      ? '❄️ ল্যান্ডিং পেজে Winter Theme (Cool Blues & Snowy Whites) চালু (ON) করা হয়েছে!'
                      : 'ল্যান্ডিং পেজের Winter Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                    nextWinter ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  isLandingWinterTheme
                    ? 'bg-gradient-to-r from-sky-600 to-blue-700 text-white border-sky-400 shadow-2xs'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ল্যান্ডিং পেজে স্টোরফ্রন্টের মতো ❄️ Winter Theme (Cool Icy Blues & Snowy Whites) ON / OFF করুন"
              >
                <span>❄️ Winter Theme: {isLandingWinterTheme ? 'ON' : 'OFF'}</span>
              </button>

              {/* 🌨️ Live 1-Click Falling Snow Toggle / Replay Button (Storefront-Style) */}
              <button
                type="button"
                onClick={() => {
                  if (isLandingSnowfallEnabled && isSnowAutoStopped) {
                    setIsSnowAutoStopped(false);
                    setSnowReplaySeed(prev => prev + 1);
                    showToast(
                      `🌨️ তুষারপাত অ্যানিমেশন আবার চালু হয়েছে (${landingSnowfallAutoOffSec} সেকেন্ড পর অটো বন্ধ হবে)!`,
                      'info'
                    );
                    return;
                  }
                  const nextSnow = !isLandingSnowfallEnabled;
                  updateProduct(product.id, { landingSnowfallEnabled: nextSnow });
                  updateBusiness({ landingSnowfallEnabled: nextSnow });
                  showToast(
                    nextSnow
                      ? '🌨️ ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow) চালু (ON) করা হয়েছে!'
                      : 'ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow) বন্ধ (OFF) করা হয়েছে।',
                    nextSnow ? 'success' : 'info'
                  );
                }}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  isLandingSnowfallEnabled
                    ? isSnowAutoStopped
                      ? 'bg-sky-500/25 text-sky-200 border-sky-400/50 hover:bg-sky-500/35'
                      : 'bg-cyan-500/30 text-cyan-200 border-cyan-400/60 hover:bg-cyan-500/40'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
                title="ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow) ON / OFF অথবা Replay করুন"
              >
                <span>
                  {isLandingSnowfallEnabled
                    ? isSnowAutoStopped
                      ? `🌨️ Snowfall: Auto-Stopped (${landingSnowfallAutoOffSec}s) · 🔄 Replay`
                      : `🌨️ Snowfall: ON (${landingSnowfallIntensity}%${
                          landingSnowfallAutoOffSec > 0 ? ` · ${landingSnowfallAutoOffSec}s` : ''
                        })`
                    : '🌨️ Snowfall: OFF'}
                </span>
              </button>

              {/* ❄️ Expandable Storefront-Style Falling Snow Control Panel Button */}
              <button
                type="button"
                onClick={() => setShowSnowControlPanel(prev => !prev)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-colors cursor-pointer ${
                  showSnowControlPanel
                    ? 'bg-sky-600 text-white border-sky-400 shadow-2xs'
                    : 'bg-sky-500/20 text-sky-200 border-sky-400/40 hover:bg-sky-500/30'
                }`}
                title="স্টোরফ্রন্টের মতো তুষারপাতের ঘনত্ব (Intensity), পড়ার গতি (Speed) এবং অটো-অফ টাইমার নিয়ন্ত্রণ করুন"
              >
                <span>❄️ স্নো কন্ট্রোল {showSnowControlPanel ? '▲' : '▼'}</span>
              </button>

              {/* 🎉 1-Click Landing Page Order Celebration ON / OFF + 4-Style Selector + Live Test */}
              <div className="inline-flex flex-wrap items-center gap-1 bg-slate-800/90 border border-slate-700 rounded-lg p-0.5">
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isLandingOrderConfettiEnabled;
                    updateProduct(product.id, { landingOrderConfettiEnabled: nextState });
                    updateBusiness({ landingOrderConfettiEnabled: nextState });
                    if (nextState) {
                      triggerLandingOrderCelebration();
                    } else {
                      setIsLpConfettiActive(false);
                    }
                    showToast(
                      nextState
                        ? '🎉 ল্যান্ডিং পেজে অর্ডার কনফার্মেশন সেলিব্রেশন চালু (ON) করা হয়েছে!'
                        : 'ল্যান্ডিং পেজে অর্ডার কনফার্মেশন সেলিব্রেশন বন্ধ (OFF) করা হয়েছে।',
                      nextState ? 'success' : 'info'
                    );
                  }}
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-bold text-[11px] transition-colors cursor-pointer ${
                    isLandingOrderConfettiEnabled
                      ? 'bg-amber-500/30 text-amber-200 border border-amber-400/50 hover:bg-amber-500/40'
                      : 'text-slate-400 hover:bg-slate-700'
                  }`}
                  title="ল্যান্ডিং পেজে অর্ডার কনফার্ম করার সাথে সাথে সেলিব্রেশন অ্যানিমেশন ON / OFF করুন"
                >
                  <span>🎉 Celebration: {isLandingOrderConfettiEnabled ? 'ON' : 'OFF'}</span>
                </button>
                <select
                  value={landingCelebrationStyle}
                  onChange={e => {
                    const nextStyle = e.target.value as OrderCelebrationStyle;
                    updateProduct(product.id, {
                      landingOrderConfettiEnabled: true,
                      landingOrderConfettiStyle: nextStyle
                    });
                    updateBusiness({
                      landingOrderConfettiEnabled: true,
                      landingOrderConfettiStyle: nextStyle
                    });
                    setTimeout(() => triggerLandingOrderCelebration(), 30);
                  }}
                  className="bg-slate-900 text-amber-200 border border-slate-700 rounded-md px-1.5 py-0.5 text-[10px] font-bold outline-hidden cursor-pointer"
                  title="সেলিব্রেশন স্টাইল সিলেক্ট করুন"
                >
                  <option value="dual_cannon_badge">🎊 ১. ডাবল পার্টি ক্যানন</option>
                  <option value="royal_fireworks">🎆 ২. রয়্যাল আতশবাজি</option>
                  <option value="luxury_gold_fountain">✨ ৩. ২৪-ক্যারেট গোল্ড ফাউন্টেন</option>
                  <option value="festive_balloons">🎈 ৪. উৎসবমুখর বেলুন ও হার্টস</option>
                  <option value="ramadan_noor_lanterns">🌙 ৫. রমজান নূর ও ফানুস (Ramadan)</option>
                  <option value="eid_mubarak_royal">🕌 ৬. ঈদ মোবারক রয়্যাল উৎসব (Eid)</option>
                </select>
                <button
                  type="button"
                  onClick={() => {
                    const nextBadge = !isLandingCelebrationBadgeOn;
                    updateProduct(product.id, { landingOrderCelebrationBadgeEnabled: nextBadge });
                    updateBusiness({ landingOrderCelebrationBadgeEnabled: nextBadge });
                    setTimeout(() => triggerLandingOrderCelebration(), 30);
                  }}
                  className={`px-1.5 py-0.5 rounded-md font-bold text-[10px] transition-colors cursor-pointer ${
                    isLandingCelebrationBadgeOn
                      ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/50'
                      : 'text-slate-400 hover:bg-slate-700'
                  }`}
                  title="স্ক্রিনের মাঝখানে লাক্সারি গোল্ডেন চেকমার্ক পপ-ব্যাজ ON / OFF করুন"
                >
                  🏅 ব্যাজ: {isLandingCelebrationBadgeOn ? 'ON' : 'OFF'}
                </button>
                <button
                  type="button"
                  onClick={() => triggerLandingOrderCelebration()}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white font-extrabold text-[10px] transition-colors cursor-pointer"
                  title="ল্যান্ডিং পেজে সেলিব্রেশন অ্যানিমেশনটি এখনই টেস্ট করে দেখুন"
                >
                  <span>✨ টেস্ট দেখুন</span>
                </button>
              </div>

              {onBackToAdmin && (
                <button
                  type="button"
                  onClick={onBackToAdmin}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Admin Landing Pages</span>
                </button>
              )}
            </div>
          </div>

          {/* ❄️ Storefront-Style Winter Theme & Falling Snow Full Control Card (Intensity, Falling Speed & Auto-Off Timer) */}
          {showSnowControlPanel && (
            <div className="max-w-5xl mx-auto mt-2.5 pt-2.5 border-t border-slate-800">
              <div className="bg-gradient-to-r from-sky-50 via-white to-blue-50/95 text-slate-900 rounded-xl p-3.5 sm:p-4 border-2 border-sky-400/80 shadow-md space-y-3.5">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
                  <div className="space-y-0.5">
                    <p className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                      <span className="text-base leading-none">❄️</span>
                      <span>
                        Landing Page Winter Theme &amp; Falling Snow Control (উইন্টার থিম, তুষারপাতের গতি ও অটো-অফ টাইমার)
                      </span>
                    </p>
                    <p className="text-[11px] text-slate-600">
                      স্টোরফ্রন্টের মতোই ১-ক্লিকে ল্যান্ডিং পেজে <span className="font-bold text-sky-800">কুল আইসি ব্লু ও স্নো হোয়াইট (Winter Theme)</span> এবং <span className="font-bold text-cyan-800">তুষারপাত অ্যানিমেশন (Falling Snow), তুষারকণার সংখ্যা, পড়ার গতি (Speed) এবং কত সেকেন্ড পর অটো বন্ধ হবে</span> তা নিয়ন্ত্রণ করুন।
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        const nextWinter = !isLandingWinterTheme;
                        updateProduct(product.id, {
                          landingWinterThemeEnabled: nextWinter,
                          ...(nextWinter ? { landingSnowfallEnabled: true } : {})
                        });
                        updateBusiness({
                          landingWinterThemeEnabled: nextWinter,
                          ...(nextWinter ? { landingSnowfallEnabled: true } : {})
                        });
                        showToast(
                          nextWinter
                            ? '❄️ ল্যান্ডিং পেজে Winter Theme (Cool Blues & Snowy Whites) চালু (ON) করা হয়েছে!'
                            : 'ল্যান্ডিং পেজের Winter Theme বন্ধ (OFF) করে ডিফল্ট থিমে ফিরিয়ে আনা হয়েছে।',
                          nextWinter ? 'success' : 'info'
                        );
                      }}
                      className={`min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                        isLandingWinterTheme
                          ? 'bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white ring-2 ring-sky-400/40'
                          : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>
                        {isLandingWinterTheme
                          ? '❄️ Winter Theme: চালু (ON)'
                          : '❄️ Winter Theme: বন্ধ (OFF)'}
                      </span>
                    </button>

                    {isLandingSnowfallEnabled && isSnowAutoStopped && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsSnowAutoStopped(false);
                          setSnowReplaySeed(prev => prev + 1);
                          showToast('🌨️ তুষারপাত অ্যানিমেশন আবার চালু (Replay) করা হয়েছে!', 'info');
                        }}
                        className="min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-extrabold bg-sky-100 hover:bg-sky-200 text-sky-900 border border-sky-300 flex items-center gap-1.5 cursor-pointer transition-all"
                      >
                        <span>🔄 Replay Snow ({landingSnowfallAutoOffSec}s)</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        const nextSnow = !isLandingSnowfallEnabled;
                        updateProduct(product.id, { landingSnowfallEnabled: nextSnow });
                        updateBusiness({ landingSnowfallEnabled: nextSnow });
                        showToast(
                          nextSnow
                            ? '🌨️ ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow Overlay) চালু (ON) করা হয়েছে!'
                            : 'ল্যান্ডিং পেজে তুষারপাত অ্যানিমেশন (Falling Snow Overlay) বন্ধ (OFF) করা হয়েছে।',
                          nextSnow ? 'success' : 'info'
                        );
                      }}
                      className={`min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-2xs ${
                        isLandingSnowfallEnabled
                          ? 'bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-700 hover:to-sky-700 text-white ring-2 ring-cyan-400/40'
                          : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>
                        {isLandingSnowfallEnabled
                          ? '🌨️ Falling Snow: চালু (ON)'
                          : '🌨️ Falling Snow: বন্ধ (OFF)'}
                      </span>
                    </button>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-sky-200/80 grid grid-cols-1 lg:grid-cols-3 gap-3">
                  {/* 1. Snowfall Intensity Slider */}
                  <div className="bg-white/95 rounded-xl p-3 border border-sky-200/90 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1">
                        <span>🌨️ Snowfall Intensity (ঘনত্ব)</span>
                      </label>
                      <span className="px-2 py-0.5 rounded-full bg-sky-100 text-sky-900 border border-sky-300 font-mono text-[11px] font-extrabold">
                        {landingSnowfallIntensity}% ({Math.max(6, Math.min(80, Math.round((landingSnowfallIntensity / 100) * 68)))} কণা)
                      </span>
                    </div>

                    <input
                      type="range"
                      min={10}
                      max={100}
                      step={5}
                      value={landingSnowfallIntensity}
                      onChange={e => {
                        const nextVal = Number(e.target.value) || 50;
                        updateProduct(product.id, { landingSnowfallEnabled: true });
                        updateBusiness({
                          landingSnowfallEnabled: true,
                          landingSnowfallIntensity: nextVal
                        });
                      }}
                      className="w-full h-2 bg-sky-100 rounded-lg appearance-none cursor-pointer accent-sky-600"
                    />

                    <div className="flex flex-wrap items-center justify-between gap-1.5">
                      {[
                        { val: 25, label: 'হালকা (25%)' },
                        { val: 50, label: 'মাঝারি (50%)' },
                        { val: 85, label: 'ঘন তুষারপাত (85%)' }
                      ].map(preset => (
                        <button
                          key={preset.val}
                          type="button"
                          onClick={() => {
                            updateProduct(product.id, { landingSnowfallEnabled: true });
                            updateBusiness({
                              landingSnowfallEnabled: true,
                              landingSnowfallIntensity: preset.val
                            });
                            showToast(`তুষারপাতের ঘনত্ব "${preset.label}" সেট করা হয়েছে!`, 'info');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                            landingSnowfallIntensity === preset.val
                              ? 'bg-sky-600 text-white border-sky-600'
                              : 'bg-sky-50/70 text-sky-900 border-sky-200 hover:bg-sky-100'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 2. Snow Falling Speed Slider */}
                  <div className="bg-white/95 rounded-xl p-3 border border-sky-200/90 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1">
                        <span>💨 তুষার পড়ার গতি (Falling Speed)</span>
                      </label>
                      <span className="px-2 py-0.5 rounded-full bg-cyan-100 text-cyan-900 border border-cyan-300 font-mono text-[11px] font-extrabold">
                        {landingSnowfallSpeed}%{' '}
                        {landingSnowfallSpeed < 75
                          ? '(ধীর)'
                          : landingSnowfallSpeed > 130
                          ? '(দ্রুত)'
                          : '(স্বাভাবিক)'}
                      </span>
                    </div>

                    <input
                      type="range"
                      min={30}
                      max={200}
                      step={10}
                      value={landingSnowfallSpeed}
                      onChange={e => {
                        const nextSpd = Number(e.target.value) || 100;
                        updateProduct(product.id, { landingSnowfallEnabled: true });
                        updateBusiness({
                          landingSnowfallEnabled: true,
                          landingSnowfallSpeed: nextSpd
                        });
                      }}
                      className="w-full h-2 bg-cyan-100 rounded-lg appearance-none cursor-pointer accent-cyan-600"
                    />

                    <div className="flex flex-wrap items-center justify-between gap-1.5">
                      {[
                        { val: 50, label: 'ধীর (Slow)' },
                        { val: 100, label: 'স্বাভাবিক (Normal)' },
                        { val: 160, label: 'দ্রুত (Fast)' }
                      ].map(spPreset => (
                        <button
                          key={spPreset.val}
                          type="button"
                          onClick={() => {
                            updateProduct(product.id, { landingSnowfallEnabled: true });
                            updateBusiness({
                              landingSnowfallEnabled: true,
                              landingSnowfallSpeed: spPreset.val
                            });
                            showToast(`তুষার পড়ার গতি "${spPreset.label}" সেট করা হয়েছে!`, 'info');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                            landingSnowfallSpeed === spPreset.val
                              ? 'bg-cyan-600 text-white border-cyan-600'
                              : 'bg-cyan-50/70 text-cyan-900 border-cyan-200 hover:bg-cyan-100'
                          }`}
                        >
                          {spPreset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 3. Auto-Off Timer */}
                  <div className="bg-white/95 rounded-xl p-3 border border-sky-200/90 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-extrabold text-slate-900 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-sky-700 shrink-0" />
                        <span>অটো-অফ টাইমার (কত সেকেন্ড পরে বন্ধ)</span>
                      </label>
                      <span
                        className={`px-2 py-0.5 rounded-full font-mono text-[11px] font-extrabold border ${
                          landingSnowfallAutoOffSec > 0
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                        }`}
                      >
                        {landingSnowfallAutoOffSec > 0
                          ? `${landingSnowfallAutoOffSec}s পর বন্ধ`
                          : 'সবসময় চলবে'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5">
                      {[
                        { sec: 0, label: '♾️ সবসময় চলবে' },
                        { sec: 5, label: '৫ সেকেন্ড' },
                        { sec: 10, label: '১০ সেকেন্ড' },
                        { sec: 15, label: '১৫ সেকেন্ড' },
                        { sec: 30, label: '৩০ সেকেন্ড' },
                        { sec: 60, label: '৬০ সেকেন্ড' }
                      ].map(timerOpt => (
                        <button
                          key={timerOpt.sec}
                          type="button"
                          onClick={() => {
                            setIsSnowAutoStopped(false);
                            setSnowReplaySeed(prev => prev + 1);
                            updateProduct(product.id, { landingSnowfallEnabled: true });
                            updateBusiness({
                              landingSnowfallEnabled: true,
                              landingSnowfallAutoOffSec: timerOpt.sec
                            });
                            showToast(
                              timerOpt.sec === 0
                                ? 'তুষারপাত অ্যানিমেশন সবসময় চালু (Always On) রাখা হয়েছে!'
                                : `তুষারপাত অ্যানিমেশন ${timerOpt.sec} সেকেন্ড পর অটো বন্ধ হয়ে যাবে!`,
                              'success'
                            );
                          }}
                          className={`px-2 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                            landingSnowfallAutoOffSec === timerOpt.sec
                              ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                              : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {timerOpt.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 pt-0.5">
                      <span className="text-[11px] font-bold text-slate-600 shrink-0">
                        কাস্টম সেকেন্ড:
                      </span>
                      <input
                        type="number"
                        min={0}
                        max={600}
                        step={1}
                        value={landingSnowfallAutoOffSec}
                        onChange={e => {
                          const nextSec = Math.max(0, Number(e.target.value) || 0);
                          setIsSnowAutoStopped(false);
                          setSnowReplaySeed(prev => prev + 1);
                          updateProduct(product.id, { landingSnowfallEnabled: true });
                          updateBusiness({
                            landingSnowfallEnabled: true,
                            landingSnowfallAutoOffSec: nextSec
                          });
                        }}
                        className="w-20 min-h-[30px] px-2 py-0.5 bg-white border border-sky-300 focus:border-sky-600 rounded-lg font-mono text-xs font-extrabold text-slate-900 outline-hidden"
                      />
                      <span className="text-[10px] text-slate-500">(0 = অটো বন্ধ হবে না)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* High-Converting Sticky Header (Logo + COD Assurance + Direct Call / Order Action — ON/OFF per Landing Page) */}
      {showTopHeader && (
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-emerald-900/10 shadow-xs">
          <div className="max-w-5xl mx-auto px-3.5 sm:px-6 py-2.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {currentBusiness.logoUrl && currentBusiness.logoUrl.trim() !== '' ? (
                <img
                  src={currentBusiness.logoUrl}
                  alt={currentBusiness.name}
                  className="h-8 sm:h-10 w-auto max-w-[160px] sm:max-w-[210px] object-contain"
                />
              ) : null}
              <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 border border-emerald-200/80 text-emerald-900 text-xs font-extrabold">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>১০০% ক্যাশ অন ডেলিভারি সুবিধা</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {showCallButton && (
                <a
                  href={`tel:${supportPhone.replace(/\s+/g, '')}`}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-900 border border-slate-200/90 font-extrabold text-xs sm:text-sm transition-colors"
                  title="সরাসরি কল করুন"
                >
                  <PhoneCall className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-700 shrink-0" />
                  <span className="font-mono tabular-nums">{supportPhone}</span>
                </a>
              )}
              <button
                type="button"
                onClick={scrollToOrderForm}
                className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#c30000] hover:bg-[#9e0000] text-white font-extrabold text-xs sm:text-sm shadow-2xs transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                <span>অর্ডার করুন</span>
              </button>
            </div>
          </div>
        </header>
      )}

      {/* Main Single-Column Funnel Container */}
      <main className="max-w-5xl w-full mx-auto px-3 sm:px-6 py-4 sm:py-7 space-y-5 sm:space-y-6 flex-1">
        {confirmedOrder ? (
          /* SIMPLE, CLEAN & 100% MOBILE-RESPONSIVE ORDER CONFIRMED VIEW */
          <div className="max-w-xl mx-auto py-2 sm:py-6 animate-page-rise">
            <div className="bg-white rounded-3xl border border-emerald-200 shadow-md overflow-hidden">
              {/* Clean Top Header */}
              <div className="bg-gradient-to-b from-emerald-50/80 to-white px-4 sm:px-7 pt-6 sm:pt-7 pb-4 text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-md shadow-emerald-600/20">
                  <CheckCircle2 className="w-9 h-9" />
                </div>

                <div className="space-y-1.5">
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                    আপনার অর্ডারের জন্য ধন্যবাদ!
                  </h2>
                  <p className="text-[15px] sm:text-base text-slate-600 leading-relaxed max-w-md mx-auto">
                    আপনার অর্ডার নম্বর{' '}
                    <span className="inline-block px-2.5 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 font-mono font-extrabold">
                      #{confirmedOrder.orderNo}
                    </span>{' '}
                    সফলভাবে গৃহীত হয়েছে। আমাদের প্রতিনিধি শীঘ্রই আপনাকে কল করে অর্ডারটি কনফার্ম করবেন।
                  </p>
                </div>
              </div>

              <div className="px-4 sm:px-7 pb-6 pt-2 space-y-4">
                {/* 1-Click WhatsApp Confirmation Button at TOP with Cart Border Beam + Login Shine Animation & 1-Line Mobile Layout */}
                {(() => {
                  const itemsSummary = confirmedOrder.items
                    .map(it => `• ${it.productName} × ${it.quantity} = ৳${it.total}`)
                    .join('\n');
                  const confirmWaText = [
                    `আসসালামু আলাইকুম, আমি ল্যান্ডিং পেজ থেকে একটি অর্ডার কনফার্ম করেছি:`,
                    `📦 অর্ডার নম্বর: #${confirmedOrder.orderNo}`,
                    `👤 নাম: ${confirmedOrder.customerName}`,
                    `📞 মোবাইল: ${confirmedOrder.customerPhone}`,
                    `🛍️ অর্ডারকৃত পণ্য:`,
                    itemsSummary,
                    `🚚 ডেলিভারি চার্জ: ${
                      confirmedOrder.deliveryCharge === 0
                        ? 'ফ্রি ডেলিভারি (৳০)'
                        : `৳${confirmedOrder.deliveryCharge}`
                    }`,
                    `💰 সর্বমোট বিল: ৳${confirmedOrder.grandTotal} (ক্যাশ অন ডেলিভারি)`,
                    `📍 ঠিকানা: ${confirmedOrder.deliveryAddress}`,
                    `অনুগ্রহ করে আমার অর্ডারটি দ্রুত কনফার্ম করবেন।`
                  ].join('\n');
                  const confirmWaHref = `https://wa.me/${formattedWaNumber}?text=${encodeURIComponent(
                    confirmWaText
                  )}`;

                  return (
                    <div className="p-3 sm:p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2 text-center">
                      <p className="text-[11px] sm:text-sm font-extrabold text-emerald-950 whitespace-nowrap overflow-hidden text-ellipsis">
                        ⚡ দ্রুত কনফার্মেশনের জন্য ১-ক্লিকে হোয়াটসঅ্যাপে অর্ডার মেসেজ পাঠিয়ে দিন
                      </p>
                      <div className="wa-confirm-beam-wrapper">
                        <a
                          href={confirmWaHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="relative z-10 w-full py-3 px-3 sm:px-4 bg-gradient-to-r from-[#1fa855] via-[#25D366] to-[#128C7E] hover:from-[#1b944a] hover:to-[#0f7a6e] text-white font-extrabold text-[13px] sm:text-base rounded-[12px] flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer btn-premium-shine"
                        >
                          <LandingWhatsAppOriginalIcon className="w-4 h-4 sm:w-5 sm:h-5 text-white shrink-0 animate-bounce" />
                          <span className="whitespace-nowrap">হোয়াটসঅ্যাপে অর্ডার কনফার্মেশন পাঠান</span>
                        </a>
                      </div>
                    </div>
                  );
                })()}

                {/* Simple, Clean & 100% Mobile-Responsive Order Summary Box */}
                <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/90 text-left space-y-3 text-[15px] sm:text-base">
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">ক্রেতার নাম:</span>
                    <span className="font-bold text-slate-900 text-right break-words">
                      {confirmedOrder.customerName}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 shrink-0">মোবাইল নম্বর:</span>
                    <span className="font-mono font-bold text-slate-900 text-right">
                      {confirmedOrder.customerPhone}
                    </span>
                  </div>

                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">ডেলিভারি ঠিকানা:</span>
                    <span className="font-bold text-slate-900 text-right break-words leading-snug">
                      {confirmedOrder.deliveryAddress}
                    </span>
                  </div>

                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">পেমেন্ট পদ্ধতি:</span>
                    <span className="font-bold text-emerald-700 text-right">
                      ক্যাশ অন ডেলিভারি
                    </span>
                  </div>

                  {/* Ordered Items & Delivery Breakdown */}
                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    {confirmedOrder.items.map((it, idx) => (
                      <div
                        key={idx}
                        className="flex items-start justify-between gap-3 font-bold text-slate-800"
                      >
                        <span className="break-words leading-snug">
                          {it.productName}{' '}
                          <span className="text-emerald-700 whitespace-nowrap">× {it.quantity}</span>
                        </span>
                        <span className="font-mono shrink-0">{formatCurrency(it.total)}</span>
                      </div>
                    ))}

                    {confirmedOrder.discountAmount > 0 && (
                      <div className="flex items-center justify-between gap-3 text-emerald-700 font-bold">
                        <span>ডিসকাউন্ট ছাড়:</span>
                        <span className="font-mono shrink-0">
                          - {formatCurrency(confirmedOrder.discountAmount)}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-3 text-slate-600">
                      <span>ডেলিভারি চার্জ:</span>
                      <span className="font-mono font-bold text-slate-800 shrink-0">
                        {confirmedOrder.deliveryCharge === 0
                          ? 'ফ্রি ডেলিভারি'
                          : formatCurrency(confirmedOrder.deliveryCharge)}
                      </span>
                    </div>
                  </div>

                  {/* Grand Total Row */}
                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3 text-base sm:text-lg font-extrabold text-emerald-700">
                    <span>সর্বমোট বিল:</span>
                    <span className="font-mono text-lg sm:text-xl shrink-0">
                      {formatCurrency(confirmedOrder.grandTotal)}
                    </span>
                  </div>
                </div>

                {/* Back to Landing Page Button */}
                <button
                  type="button"
                  onClick={() => setConfirmedOrder(null)}
                  className="w-full py-3 px-5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[15px] sm:text-base rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>ল্যান্ডিং পেজে ফিরে যান</span>
                </button>

                {/* Subtle Admin-Only Celebration Controls at Bottom */}
                {(isAuthenticated || onBackToAdmin) && (
                  <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const nextState = !isLandingOrderConfettiEnabled;
                        updateProduct(product.id, { landingOrderConfettiEnabled: nextState });
                        updateBusiness({ landingOrderConfettiEnabled: nextState });
                        if (nextState) {
                          triggerLandingOrderCelebration();
                        } else {
                          setIsLpConfettiActive(false);
                        }
                        showToast(
                          nextState
                            ? '🎉 ল্যান্ডিং পেজ অর্ডার সেলিব্রেশন চালু (ON) করা হয়েছে!'
                            : 'ল্যান্ডিং পেজ অর্ডার সেলিব্রেশন বন্ধ (OFF) করা হয়েছে।',
                          nextState ? 'success' : 'info'
                        );
                      }}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        isLandingOrderConfettiEnabled
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      <span>🎉 সেলিব্রেশন: {isLandingOrderConfettiEnabled ? 'ON' : 'OFF'}</span>
                    </button>
                    <select
                      value={landingCelebrationStyle}
                      onChange={e => {
                        const nextStyle = e.target.value as OrderCelebrationStyle;
                        updateProduct(product.id, {
                          landingOrderConfettiEnabled: true,
                          landingOrderConfettiStyle: nextStyle
                        });
                        updateBusiness({
                          landingOrderConfettiEnabled: true,
                          landingOrderConfettiStyle: nextStyle
                        });
                        setTimeout(() => triggerLandingOrderCelebration(), 30);
                      }}
                      className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-bold outline-hidden cursor-pointer"
                    >
                      <option value="dual_cannon_badge">🎊 ১. ডাবল পার্টি ক্যানন</option>
                      <option value="royal_fireworks">🎆 ২. রয়্যাল আতশবাজি</option>
                      <option value="luxury_gold_fountain">✨ ৩. গোল্ড ফাউন্টেন</option>
                      <option value="festive_balloons">🎈 ৪. বেলুন ও হার্টস</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => triggerLandingOrderCelebration()}
                      className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      ✨ প্রিভিউ
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* BANNER 1: TOP PROMOTIONAL BANNER / IMAGE SECTION AT START OF LANDING PAGE (ON/OFF + Direct Upload) */}
            {showPromoBanner && (
              promoBannerImage ? (
                <section className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                  {promoBannerTitle && (
                    <div className="px-4 py-2.5 bg-emerald-50/60 border-b border-emerald-100 text-center">
                      <p className="text-sm sm:text-base font-extrabold text-emerald-950">
                        {promoBannerTitle}
                      </p>
                    </div>
                  )}
                  <div
                    onClick={scrollToOrderForm}
                    role="button"
                    tabIndex={0}
                    onKeyDown={e => {
                      if (e.key === 'Enter' || e.key === ' ') scrollToOrderForm();
                    }}
                    className="relative w-full cursor-pointer group"
                  >
                    <LazyImage
                      src={promoBannerImage}
                      alt={promoBannerTitle || product.nameBn}
                      wrapperClassName="relative w-full overflow-hidden"
                      skeletonClassName="min-h-[160px] sm:min-h-[240px]"
                      className="w-full h-auto max-h-[460px] object-cover block"
                    />
                    {(isAuthenticated || onBackToAdmin) && (
                      <div
                        onClick={e => e.stopPropagation()}
                        className="absolute top-2.5 right-2.5 flex items-center gap-1.5 bg-slate-900/80 backdrop-blur-xs px-2.5 py-1.5 rounded-xl border border-white/15 text-white text-xs"
                      >
                        <button
                          type="button"
                          onClick={() => promoBannerFileInputRef.current?.click()}
                          className="font-bold text-emerald-300 hover:text-emerald-200 inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>ব্যানার ১ পরিবর্তন</span>
                        </button>
                        <span className="text-slate-500">|</span>
                        <button
                          type="button"
                          onClick={() => {
                            updateProduct(product.id, { landingPromoBannerEnabled: false });
                            showToast('ব্যানার ১ বন্ধ (OFF) করা হয়েছে', 'info');
                          }}
                          className="font-bold text-rose-300 hover:text-rose-200 cursor-pointer"
                        >
                          OFF করুন
                        </button>
                      </div>
                    )}
                  </div>
                </section>
              ) : (isAuthenticated || onBackToAdmin) ? (
                <section className="bg-white rounded-2xl border-2 border-dashed border-emerald-300 p-4 sm:p-5 text-center">
                  <div className="max-w-lg mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3 text-left">
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center shrink-0">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">
                          ব্যানার ১ (শুরুতে) — ছবি আপলোড করুন (Admin Only Preview)
                        </h3>
                        <p className="text-[11px] text-slate-500">
                          ব্যানার ১ আপলোড করলে কাস্টমাররা ল্যান্ডিং পেজের শুরুতে এই ছবিটি দেখতে পাবে (যেকোনো সময় ON/OFF করা যাবে)।
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => promoBannerFileInputRef.current?.click()}
                        className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>ব্যানার ১ আপলোড করুন</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          updateProduct(product.id, { landingPromoBannerEnabled: false });
                          showToast('ব্যানার ১ বন্ধ (OFF) করা হয়েছে', 'info');
                        }}
                        className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold cursor-pointer"
                      >
                        OFF
                      </button>
                    </div>
                  </div>
                </section>
              ) : null
            )}

            {/* SECTION 1: HERO PRODUCT SHOWCASE CARD (SIMPLE, CLEAN & STANDARD) */}
            <section className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
              {/* SIMPLE, CLEAN TOP HEADING BEFORE PRODUCT IMAGE (Can be turned ON/OFF & Animation ON/OFF) */}
              {showTopHeading && (
                <div
                  onClick={scrollToOrderForm}
                  role="button"
                  tabIndex={0}
                  onKeyDown={e => {
                    if (e.key === 'Enter' || e.key === ' ') scrollToOrderForm();
                  }}
                  className={`px-4 pt-4 pb-4 sm:px-8 sm:pt-6 sm:pb-5 text-center cursor-pointer transition-colors ${topHeadingThemeClasses.container}`}
                >
                  <div className={`max-w-3xl mx-auto flex flex-col items-center justify-center gap-1.5 ${topHeadingAnimClass}`}>
                    {topHeadingSubtext !== '' && (
                      <p
                        className={`inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-extrabold tracking-tight ${topHeadingThemeClasses.subtext}`}
                      >
                        <span className="relative flex h-2.5 w-2.5 shrink-0">
                          {isTopHeadingAnimated && (
                            <span
                              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${topHeadingThemeClasses.dotPing}`}
                            />
                          )}
                          <span
                            className={`relative inline-flex rounded-full h-2.5 w-2.5 ${topHeadingThemeClasses.dot}`}
                          />
                        </span>
                        <span>{topHeadingSubtext}</span>
                      </p>
                    )}

                    <h2
                      className={`text-lg sm:text-2xl md:text-[27px] font-extrabold leading-snug tracking-tight ${topHeadingThemeClasses.title}`}
                    >
                      {topHeadingText}
                    </h2>

                    <div
                      className={`h-1 w-16 sm:w-24 rounded-full mt-1 ${topHeadingThemeClasses.underline} ${
                        isTopHeadingAnimated ? 'animate-lp-heading-glow' : ''
                      }`}
                    />

                    {/* Optional Countdown Position: Inside Top Hero Heading */}
                    {showCountdown && countdownPosition === 'top_heading' && (
                      <div className="pt-2.5 w-full max-w-md mx-auto">
                        <div className="px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-rose-50 via-amber-50/80 to-rose-50 border border-rose-200/90 animate-countdown-glow flex flex-wrap items-center justify-between gap-2.5">
                          <div className="flex items-center gap-2 text-left">
                            <span className="relative flex h-6 w-6 rounded-lg bg-rose-600 text-white items-center justify-center shrink-0 shadow-2xs">
                              <Clock className="w-3.5 h-3.5 animate-pulse" />
                            </span>
                            <div>
                              <p className="text-xs sm:text-sm font-extrabold text-rose-950 leading-tight">
                                {countdownTitle}
                              </p>
                              <p className="text-[10px] font-bold text-rose-700">
                                সীমিত সময়ের ডিসকাউন্ট অফার
                              </p>
                            </div>
                          </div>

                          <LandingEvergreenCountdownDigits
                            productId={product.id}
                            countdownHours={countdownHours}
                            cycleTotalSeconds={cycleTotalSeconds}
                            compact
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ELEMENTOR-STYLE CLEAN ANIMATED REGULAR PRICE (RED X CROSS-OUT) & OFFER PRICE BANNER (WITH COLOR THEMES & HIGHLIGHT STYLES) */}
              {showTopPriceBanner && (
                <div
                  onClick={scrollToOrderForm}
                  role="button"
                  tabIndex={0}
                  onKeyDown={e => {
                    if (e.key === 'Enter' || e.key === ' ') scrollToOrderForm();
                  }}
                  className={`px-3 py-3.5 sm:px-7 sm:py-5 text-center cursor-pointer select-none transition-colors lp-price-speed-${topPriceAnimationSpeed} ${topPriceThemeClasses.outer}`}
                >
                  <div
                    className={`max-w-2xl mx-auto rounded-2xl px-4 py-4 sm:px-8 sm:py-6 flex flex-col items-center justify-center space-y-2.5 sm:space-y-3.5 transition-all ${topPriceThemeClasses.card}`}
                  >
                    {/* Line 1: পূর্বের মূল্য — 1800 টাকা (English Digits + Elementor-style Animated Red X Cross-Out) */}
                    <div
                      className={`inline-flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 text-lg sm:text-2xl md:text-[29px] font-extrabold tracking-tight leading-snug ${topPriceThemeClasses.regRow}`}
                    >
                      <span>{topRegularPriceLabel}</span>
                      <span
                        className={`relative inline-flex items-baseline gap-1.5 px-3 py-0.5 rounded-xl ${topPriceThemeClasses.regPriceBox}`}
                      >
                        <span className="font-mono font-black text-2xl sm:text-3xl md:text-[36px] tracking-tight tabular-nums">
                          {bannerRegularPrice}
                        </span>
                        <span className="font-extrabold text-lg sm:text-2xl md:text-[27px]">টাকা</span>

                        {/* Animated Red X Cross-Out SVG */}
                        <svg
                          viewBox="0 0 220 68"
                          preserveAspectRatio="none"
                          className="absolute -inset-x-1 -inset-y-0.5 w-[calc(100%+8px)] h-[calc(100%+4px)] pointer-events-none overflow-visible"
                        >
                          <path
                            d="M 6 11 L 214 57"
                            fill="none"
                            stroke={topPriceThemeClasses.crossColor}
                            strokeWidth="5"
                            strokeLinecap="round"
                            className={isTopPriceAnimated ? 'animate-elementor-cross-1' : ''}
                          />
                          <path
                            d="M 214 11 L 6 57"
                            fill="none"
                            stroke={topPriceThemeClasses.crossColor}
                            strokeWidth="5"
                            strokeLinecap="round"
                            className={isTopPriceAnimated ? 'animate-elementor-cross-2' : ''}
                          />
                        </svg>
                      </span>
                    </div>

                    {/* Subtle Gradient Divider */}
                    <div
                      className={`h-px w-4/5 max-w-md bg-gradient-to-r ${topPriceThemeClasses.divider}`}
                    />

                    {/* Line 2 & 3: আজকের অফার মূল্য — মাত্র 990 টাকা (Bigger English Price + Animated Highlight Around Price Only) */}
                    <div className="space-y-1.5 sm:space-y-2">
                      <p
                        className={`text-xl sm:text-3xl md:text-[35px] font-black tracking-tight leading-tight ${topPriceThemeClasses.offerLabel}`}
                      >
                        {topOfferPriceLabel}
                      </p>

                      <div className="inline-flex flex-wrap items-center justify-center gap-2 sm:gap-3 pt-0.5">
                        {topOfferPricePrefix && (
                          <span
                            className={`text-2xl sm:text-4xl md:text-[40px] font-black tracking-tight leading-none ${topPriceThemeClasses.offerPrefix}`}
                          >
                            {topOfferPricePrefix}
                          </span>
                        )}

                        {/* Animated Offer Price (English Digits + Bigger Font + Selectable Highlight Animation) */}
                        <span
                          className={`relative inline-flex items-baseline justify-center px-4 sm:px-6 py-1.5 sm:py-2 mx-0.5 rounded-2xl ${
                            topPriceHighlightStyle === 'burst'
                              ? `${topPriceThemeClasses.offerHighlightBg} ring-2 ring-emerald-500/30`
                              : topPriceThemeClasses.offerHighlightBg
                          } ${isTopPriceAnimated ? 'animate-elementor-price-pop' : ''}`}
                        >
                          <span
                            className={`relative z-10 font-mono font-black text-4xl sm:text-6xl md:text-[64px] tracking-tight tabular-nums leading-none ${topPriceThemeClasses.offerPriceNum}`}
                          >
                            {unitRetailPrice}
                          </span>
                          <span
                            className={`relative z-10 ml-1.5 sm:ml-2 text-2xl sm:text-4xl md:text-[42px] font-black leading-none ${topPriceThemeClasses.offerPriceCurrency}`}
                          >
                            টাকা
                          </span>

                          {topPriceHighlightStyle === 'underline' ? (
                            /* Style 2: Double Hand-Drawn Curved Marker Underline Under Price */
                            <svg
                              viewBox="0 0 320 28"
                              preserveAspectRatio="none"
                              className="absolute left-1 right-1 -bottom-2 w-[calc(100%-8px)] h-4 sm:h-5 pointer-events-none overflow-visible"
                            >
                              <path
                                d="M 6 12 Q 160 2 314 11"
                                fill="none"
                                stroke={topPriceThemeClasses.strokeColor}
                                strokeWidth="6"
                                strokeLinecap="round"
                                className={isTopPriceAnimated ? 'animate-elementor-green-line' : ''}
                              />
                              <path
                                d="M 24 22 Q 165 14 296 21"
                                fill="none"
                                stroke={topPriceThemeClasses.secondaryStrokeColor}
                                strokeWidth="4"
                                strokeLinecap="round"
                                className={isTopPriceAnimated ? 'animate-elementor-green-line' : ''}
                              />
                            </svg>
                          ) : (
                            /* Style 1 & 3: Elementor Hand-Drawn Animated Circle Wrapping the Offer Price */
                            <svg
                              viewBox="0 0 500 150"
                              preserveAspectRatio="none"
                              className="absolute -inset-x-2 -inset-y-1.5 w-[calc(100%+16px)] h-[calc(100%+12px)] pointer-events-none overflow-visible"
                            >
                              <path
                                d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                                fill="none"
                                stroke={topPriceThemeClasses.strokeColor}
                                strokeWidth="8.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className={isTopPriceAnimated ? 'animate-elementor-price-circle' : ''}
                              />
                            </svg>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 sm:gap-6 p-1.5 sm:p-4 items-start">
                {/* Left Column: Swipeable & Slideable Larger Product Image Slider with Smart HD Zoom */}
                <div className="md:col-span-6 space-y-2">
                  {/* Admin Inline Quick Control for Product Image % Discount Badge (Visible only to Admin) */}
                  {isAdminViewing && (
                    <div className="p-2.5 rounded-xl bg-slate-900 text-white border border-slate-700 shadow-xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[11px] font-extrabold text-amber-300 flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          <span>ছবির উপরের "% ছাড়" ব্যাজ ডিজাইন ও ON/OFF:</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            const next = !showImageDiscountBadge;
                            updateProduct(product.id, { landingImageBadgeEnabled: next });
                            updateBusiness({ landingImageBadgeEnabled: next });
                            showToast(
                              next
                                ? 'ছবির উপরে "% ছাড়" ব্যাজ চালু (ON) হয়েছে'
                                : 'ছবির উপরে "% ছাড়" ব্যাজ বন্ধ (OFF) হয়েছে',
                              next ? 'success' : 'info'
                            );
                          }}
                          className={`px-2.5 py-0.5 rounded-md text-[10px] font-extrabold border transition-all cursor-pointer ${
                            showImageDiscountBadge
                              ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60'
                              : 'bg-rose-500/25 text-rose-200 border-rose-400/60'
                          }`}
                        >
                          % ছাড় ব্যাজ: {showImageDiscountBadge ? 'ON ✓' : 'OFF ✕'}
                        </button>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                        {LANDING_IMAGE_BADGE_DESIGN_OPTIONS.map(opt => {
                          const isCurrent = imageBadgeStyle === opt.id && showImageDiscountBadge;
                          return (
                            <button
                              key={opt.id}
                              type="button"
                              onClick={() => {
                                updateProduct(product.id, {
                                  landingImageBadgeEnabled: true,
                                  landingImageBadgeStyle: opt.id
                                });
                                updateBusiness({
                                  landingImageBadgeEnabled: true,
                                  landingImageBadgeStyle: opt.id
                                });
                                showToast(`"${opt.label}" অ্যাক্টিভ করা হয়েছে!`, 'success');
                              }}
                              className={`px-2 py-1.5 rounded-lg text-[11px] font-bold text-left truncate border transition-all cursor-pointer ${
                                isCurrent
                                  ? 'bg-rose-600 text-white border-amber-300 shadow-2xs'
                                  : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
                              }`}
                              title={opt.desc}
                            >
                              {opt.shortLabel}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div
                    onTouchStart={handleImageTouchStart}
                    onTouchMove={handleImageTouchMove}
                    onTouchEnd={handleImageTouchEnd}
                    onMouseDown={handleImageMouseDown}
                    onMouseUp={handleImageMouseUp}
                    onMouseMove={handleImageMouseMoveZoom}
                    onMouseLeave={() => setLpHoverZoom(prev => ({ ...prev, active: false }))}
                    className={`relative aspect-square w-full rounded-xl bg-white border border-slate-200/50 overflow-hidden select-none group ${
                      isGlobalImageZoomEnabled
                        ? 'cursor-zoom-in'
                        : galleryImages.length > 1
                          ? 'cursor-grab active:cursor-grabbing'
                          : 'cursor-default'
                    }`}
                  >
                    {galleryImages.length > 0 ? (
                      <div
                        className="flex w-full h-full transition-transform duration-300 ease-out"
                        style={{
                          transform: `translateX(-${safeLpGalleryIdx * 100}%)`
                        }}
                      >
                        {galleryImages.map((imgUrl, idx) => {
                          const isCurrentZooming =
                            isLpHoverZoomAllowed && lpHoverZoom.active && idx === safeLpGalleryIdx;
                          return (
                            <div
                              key={`${product.id}_slide_${idx}`}
                              className="w-full h-full shrink-0 overflow-hidden flex items-center justify-center bg-white"
                            >
                              <div
                                className="w-full h-full transition-transform duration-200 ease-out"
                                style={
                                  isCurrentZooming
                                    ? {
                                        transform: 'scale(1.85)',
                                        transformOrigin: `${lpHoverZoom.x}% ${lpHoverZoom.y}%`
                                      }
                                    : undefined
                                }
                              >
                                <ProductThumbnail
                                  eager
                                  product={{
                                    ...product,
                                    image: imgUrl
                                  }}
                                  imgClassName="p-0"
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div
                        className="w-full h-full transition-transform duration-200 ease-out"
                        style={
                          isLpHoverZoomAllowed && lpHoverZoom.active
                            ? {
                                transform: 'scale(1.85)',
                                transformOrigin: `${lpHoverZoom.x}% ${lpHoverZoom.y}%`
                              }
                            : undefined
                        }
                      >
                        <ProductThumbnail
                          key={product.id}
                          eager
                          product={{ ...product, image: '' }}
                          imgClassName="p-0"
                        />
                      </div>
                    )}

                    {/* Classic WooCommerce Floating Magnifier Trigger Button */}
                    {isLpLightboxAllowed && (
                      <button
                        type="button"
                        onMouseDown={e => e.stopPropagation()}
                        onMouseUp={e => e.stopPropagation()}
                        onClick={e => {
                          e.stopPropagation();
                          setLpLightboxScale(1);
                          setLpLightboxPan({ x: 50, y: 50 });
                          setLpLightboxOpen(true);
                        }}
                        className="absolute top-2.5 right-2.5 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/95 hover:bg-white text-slate-800 hover:text-emerald-700 border border-slate-200/90 shadow-md flex items-center justify-center z-20 cursor-pointer transition-all hover:scale-105 active:scale-95"
                        title="ছবি বড় করে দেখুন (WooCommerce Fullscreen Lightbox)"
                        aria-label="Open product image in fullscreen lightbox"
                      >
                        <Search className="w-4 h-4 sm:w-[18px] sm:h-[18px] stroke-[2.4]" />
                      </button>
                    )}

                    {/* Slide Counter Badge (Only when multiple gallery images exist) */}
                    {galleryImages.length > 1 && (
                      <span
                        className={`absolute ${
                          isLpLightboxAllowed ? 'top-14 right-2.5' : 'top-2.5 right-2.5'
                        } bg-slate-900/75 text-white text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg backdrop-blur-xs z-10 pointer-events-none`}
                      >
                        {safeLpGalleryIdx + 1} / {galleryImages.length}
                      </span>
                    )}

                    {/* Slide Dots Indicator on Bottom of Image (Only when multiple photos exist) */}
                    {galleryImages.length > 1 && (
                      <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/55 backdrop-blur-xs z-10">
                        {galleryImages.map((_, idx) => (
                          <button
                            key={`dot_${idx}`}
                            type="button"
                            onMouseDown={e => e.stopPropagation()}
                            onMouseUp={e => e.stopPropagation()}
                            onClick={e => {
                              e.stopPropagation();
                              setActiveGalleryIdx(idx);
                            }}
                            className={`h-2 rounded-full transition-all cursor-pointer ${
                              safeLpGalleryIdx === idx
                                ? 'w-5 bg-white'
                                : 'w-2 bg-white/55 hover:bg-white/80'
                            }`}
                            aria-label={`Slide ${idx + 1}`}
                          />
                        ))}
                      </div>
                    )}

                    {/* Top-Left Discount Ribbon (ON/OFF + 6 Mobile-Responsive Designs) */}
                    {showImageDiscountBadge && discountPercent > 0 && (
                      <>
                        {imageBadgeStyle === 'classic_red' && (
                          <span className="absolute top-2.5 left-2.5 bg-[#c30000] text-white text-xs sm:text-sm font-extrabold px-3 py-1 rounded-xl shadow-sm tabular-nums z-10 pointer-events-none">
                            {discountPercent}% ছাড় (সাশ্রয় ৳{unitSavings})
                          </span>
                        )}

                        {imageBadgeStyle === 'crimson_gold' && (
                          <span className="absolute top-2.5 left-2.5 bg-gradient-to-r from-rose-800 via-red-700 to-rose-800 text-white border-2 border-amber-400 text-xs sm:text-sm font-extrabold px-3 py-1 rounded-xl shadow-md tabular-nums z-10 pointer-events-none inline-flex items-center gap-1.5">
                            <span className="text-amber-300 font-black">{discountPercent}% ছাড়</span>
                            <span className="text-white/95 text-[11px] sm:text-xs font-bold">
                              (সাশ্রয় ৳{unitSavings})
                            </span>
                          </span>
                        )}

                        {imageBadgeStyle === 'circle_seal' && (
                          <div className="absolute top-2.5 left-2.5 w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-rose-600 via-red-600 to-rose-800 text-white border-2 border-amber-300 shadow-md flex flex-col items-center justify-center leading-none tabular-nums z-10 pointer-events-none">
                            <span className="text-sm sm:text-base font-black text-amber-200">
                              {discountPercent}%
                            </span>
                            <span className="text-[11px] sm:text-xs font-extrabold tracking-tight mt-0.5">
                              ছাড়
                            </span>
                          </div>
                        )}

                        {imageBadgeStyle === 'royal_dark_gold' && (
                          <span className="absolute top-2.5 left-2.5 bg-slate-950/90 backdrop-blur-xs text-amber-300 border border-amber-400/80 text-xs sm:text-sm font-extrabold px-3 py-1 rounded-xl shadow-md tabular-nums z-10 pointer-events-none inline-flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span>
                              {discountPercent}% ছাড় • সাশ্রয় ৳{unitSavings}
                            </span>
                          </span>
                        )}

                        {imageBadgeStyle === 'emerald_flash' && (
                          <span className="absolute top-2.5 left-2.5 bg-gradient-to-r from-emerald-700 to-teal-600 text-white border border-emerald-300/60 text-xs sm:text-sm font-extrabold px-3.5 py-1 rounded-full shadow-md tabular-nums z-10 pointer-events-none">
                            🔥 {discountPercent}% ছাড় (সাশ্রয় ৳{unitSavings})
                          </span>
                        )}

                        {imageBadgeStyle === 'minimal_percent' && (
                          <span className="absolute top-2.5 left-2.5 bg-[#c30000] text-white text-xs sm:text-sm font-black px-2.5 py-1 rounded-lg shadow-sm tabular-nums z-10 pointer-events-none">
                            -{discountPercent}% ছাড়
                          </span>
                        )}
                      </>
                    )}

                    {/* Smart Image-Overlaid "স্টক শেষ / STOCK OUT" Display (4 Switchable Styles) */}
                    {availableStock <= 0 && (
                      <>
                        {stockOutBadgeStyle === 'classic_corner' && (
                          <div className="absolute top-2.5 right-2.5 z-20 pointer-events-none">
                            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-900/90 text-white text-xs sm:text-sm font-extrabold shadow-md">
                              🚫 স্টক শেষ
                            </span>
                          </div>
                        )}
                        {stockOutBadgeStyle === 'diagonal_ribbon' && (
                          <div className="absolute inset-0 bg-slate-900/25 backdrop-blur-[1.5px] z-20 pointer-events-none overflow-hidden flex items-center justify-center">
                            <div className="w-[150%] -rotate-12 bg-gradient-to-r from-rose-700 via-red-600 to-rose-700 text-white text-center font-black tracking-wider uppercase shadow-xl border-y-2 border-white/80 py-2.5 text-sm sm:text-base">
                              🚫 স্টক শেষ • OUT OF STOCK
                            </div>
                          </div>
                        )}
                        {stockOutBadgeStyle === 'bottom_banner' && (
                          <div className="absolute inset-0 bg-slate-900/20 z-20 pointer-events-none flex flex-col justify-end">
                            <div className="w-full bg-gradient-to-r from-slate-950/95 via-rose-900/95 to-slate-950/95 backdrop-blur-xs text-white text-center font-extrabold border-t border-rose-400/50 shadow-lg py-3 px-4 text-sm sm:text-base flex items-center justify-center gap-2">
                              <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-pulse shrink-0" />
                              <span>🚫 স্টক শেষ (Out of Stock)</span>
                            </div>
                          </div>
                        )}
                        {(stockOutBadgeStyle === 'center_glass' ||
                          (stockOutBadgeStyle !== 'classic_corner' &&
                            stockOutBadgeStyle !== 'diagonal_ribbon' &&
                            stockOutBadgeStyle !== 'bottom_banner')) && (
                          <div className="absolute inset-0 bg-slate-900/35 backdrop-blur-[2px] z-20 pointer-events-none flex items-center justify-center p-3">
                            <div className="bg-slate-950/90 text-white border-2 border-rose-400/80 rounded-2xl shadow-2xl flex flex-col items-center justify-center text-center px-5 py-3 transform -rotate-2">
                              <span className="inline-flex items-center gap-1.5 font-black text-rose-400 tracking-wide uppercase text-xs">
                                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                                STOCK OUT
                              </span>
                              <span className="font-extrabold text-white leading-tight text-base sm:text-lg mt-0.5">
                                🚫 স্টক শেষ
                              </span>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>

                  {/* Thumbnail Strip if multiple photos exist */}
                  {galleryImages.length > 1 && (
                    <div className="flex items-center gap-2 overflow-x-auto pb-1">
                      {galleryImages.map((imgUrl, idx) => (
                        <button
                          key={`${product.id}_thumb_${idx}`}
                          type="button"
                          onClick={() => setActiveGalleryIdx(idx)}
                          className={`w-16 h-16 rounded-xl border-2 overflow-hidden shrink-0 bg-white cursor-pointer transition-all ${
                            safeLpGalleryIdx === idx
                              ? 'border-emerald-600 ring-2 ring-emerald-500/20'
                              : 'border-slate-200 opacity-75 hover:opacity-100'
                          }`}
                        >
                          <ProductThumbnail
                            eager
                            product={{
                              ...product,
                              image: imgUrl
                            }}
                            imgClassName="p-0.5"
                          />
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Authentic WooCommerce PhotoSwipe Fullscreen Dark Lightbox Modal on Landing Page */}
                  {isLpLightboxAllowed && lpLightboxOpen && (
                    <div
                      onClick={() => setLpLightboxOpen(false)}
                      className="fixed inset-0 z-[120] bg-black/95 backdrop-blur-xs flex flex-col justify-between select-none animate-fade-in"
                    >
                      {/* PhotoSwipe Top Toolbar */}
                      <div
                        onClick={e => e.stopPropagation()}
                        className="w-full px-3 sm:px-6 py-3 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between gap-3 text-white z-20"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="font-mono text-xs sm:text-sm font-extrabold text-white/90 bg-white/10 px-2.5 py-1 rounded-lg border border-white/15 shrink-0">
                            {safeLpGalleryIdx + 1} / {Math.max(1, galleryImages.length)}
                          </span>
                          <span className="text-xs sm:text-sm font-bold text-white/90 truncate">
                            {product.nameBn}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              const nextScale =
                                lpLightboxScale <= 1 ? 2 : lpLightboxScale < 2.6 ? 2.8 : 1;
                              setLpLightboxScale(nextScale);
                              if (nextScale === 1) setLpLightboxPan({ x: 50, y: 50 });
                            }}
                            className="h-9 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-colors"
                            title="Zoom In / Out"
                          >
                            <Search className="w-3.5 h-3.5 text-amber-400" />
                            <span className="font-mono">
                              {lpLightboxScale === 1 ? 'Zoom +' : `${lpLightboxScale}x`}
                            </span>
                          </button>

                          {lpLightboxScale > 1 && (
                            <button
                              type="button"
                              onClick={() => {
                                setLpLightboxScale(1);
                                setLpLightboxPan({ x: 50, y: 50 });
                              }}
                              className="h-9 px-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-amber-300 border border-white/15 text-xs font-mono font-bold cursor-pointer transition-colors"
                              title="Reset Zoom (1x)"
                            >
                              1:1
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => setLpLightboxOpen(false)}
                            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-rose-600 text-white border border-white/15 flex items-center justify-center cursor-pointer transition-colors"
                            aria-label="Close lightbox"
                            title="বন্ধ করুন (Close)"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* PhotoSwipe Center Full-Bleed Dark Stage */}
                      <div
                        onClick={e => e.stopPropagation()}
                        onTouchStart={handleImageTouchStart}
                        onTouchMove={handleImageTouchMove}
                        onTouchEnd={handleImageTouchEnd}
                        onMouseMove={e => {
                          if (lpLightboxScale <= 1) return;
                          const rect = e.currentTarget.getBoundingClientRect();
                          if (!rect.width || !rect.height) return;
                          const x = Math.max(
                            0,
                            Math.min(100, ((e.clientX - rect.left) / rect.width) * 100)
                          );
                          const y = Math.max(
                            0,
                            Math.min(100, ((e.clientY - rect.top) / rect.height) * 100)
                          );
                          setLpLightboxPan({ x, y });
                        }}
                        className="relative flex-1 w-full overflow-hidden flex items-center justify-center px-2 sm:px-12"
                      >
                        <div
                          onClick={e => {
                            const rect = e.currentTarget.getBoundingClientRect();
                            if (lpLightboxScale <= 1) {
                              if (rect.width && rect.height) {
                                const x = Math.max(
                                  0,
                                  Math.min(100, ((e.clientX - rect.left) / rect.width) * 100)
                                );
                                const y = Math.max(
                                  0,
                                  Math.min(100, ((e.clientY - rect.top) / rect.height) * 100)
                                );
                                setLpLightboxPan({ x, y });
                              }
                              setLpLightboxScale(2);
                            } else {
                              setLpLightboxScale(1);
                              setLpLightboxPan({ x: 50, y: 50 });
                            }
                          }}
                          className={`relative w-full max-w-[82vw] sm:max-w-[540px] max-h-[70vh] aspect-square rounded-2xl overflow-hidden bg-white shadow-2xl transition-transform duration-200 ease-out ${
                            lpLightboxScale > 1 ? 'cursor-zoom-out' : 'cursor-zoom-in'
                          }`}
                          style={{
                            transform: `scale(${lpLightboxScale})`,
                            transformOrigin: `${lpLightboxPan.x}% ${lpLightboxPan.y}%`
                          }}
                        >
                          <ProductThumbnail
                            eager
                            product={{
                              ...product,
                              image: galleryImages[safeLpGalleryIdx] || ''
                            }}
                            imgClassName="p-0"
                          />
                        </div>

                        {galleryImages.length > 1 && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setLpLightboxScale(1);
                                setLpLightboxPan({ x: 50, y: 50 });
                                handlePrevImage();
                              }}
                              className="fixed left-3 sm:left-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/15 hover:bg-white/30 text-white border border-white/20 flex items-center justify-center shadow-lg cursor-pointer z-20 transition-all"
                              aria-label="Previous image"
                            >
                              <ChevronLeft className="w-5 h-5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setLpLightboxScale(1);
                                setLpLightboxPan({ x: 50, y: 50 });
                                handleNextImage();
                              }}
                              className="fixed right-3 sm:right-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/15 hover:bg-white/30 text-white border border-white/20 flex items-center justify-center shadow-lg cursor-pointer z-20 transition-all"
                              aria-label="Next image"
                            >
                              <ChevronRight className="w-5 h-5" />
                            </button>
                          </>
                        )}
                      </div>

                      {/* PhotoSwipe Bottom Filmstrip & Caption Bar */}
                      <div
                        onClick={e => e.stopPropagation()}
                        className="w-full px-3 sm:px-6 py-3 bg-gradient-to-t from-black/90 via-black/70 to-transparent flex flex-col items-center gap-2.5 z-20"
                      >
                        {galleryImages.length > 1 && (
                          <div className="flex items-center justify-center gap-2 overflow-x-auto max-w-full py-1">
                            {galleryImages.map((imgUrl, idx) => {
                              const isActive = idx === safeLpGalleryIdx;
                              return (
                                <button
                                  key={`lp_lb_thumb_${idx}`}
                                  type="button"
                                  onClick={() => {
                                    setLpLightboxScale(1);
                                    setLpLightboxPan({ x: 50, y: 50 });
                                    setActiveGalleryIdx(idx);
                                  }}
                                  className={`w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden border-2 bg-white shrink-0 transition-all cursor-pointer ${
                                    isActive
                                      ? 'border-amber-400 scale-105 shadow-md'
                                      : 'border-white/20 opacity-60 hover:opacity-100'
                                  }`}
                                >
                                  <ProductThumbnail
                                    eager
                                    product={{
                                      ...product,
                                      image: imgUrl
                                    }}
                                    imgClassName="p-0.5"
                                  />
                                </button>
                              );
                            })}
                          </div>
                        )}
                        <p className="text-[11px] sm:text-xs text-white/75 text-center font-medium">
                          🔍 ছবির ওপর ক্লিক করে জুম ইন / আউট করুন · বর্তমান ভিউ:{' '}
                          <strong className="text-amber-300 font-mono">{lpLightboxScale}x</strong>
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Column: Product Title, Clean Offer Price, Variations, Old Clean Quantity & CTA */}
                <div className="md:col-span-6 space-y-4">
                  {/* Editable Top Trust Badge Only (Stock badge removed as requested) */}
                  {badgeText !== '' && (
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs sm:text-sm font-extrabold">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{badgeText}</span>
                      </div>
                    </div>
                  )}

                  {/* Product Name (Rating next to product name removed as requested) */}
                  <div className="space-y-1">
                    <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-slate-900 leading-snug">
                      {product.nameBn}
                    </h1>
                    {product.nameEn && product.nameEn !== product.nameBn && (
                      <p className="text-sm sm:text-base font-medium text-slate-500">
                        {product.nameEn}
                      </p>
                    )}
                  </div>

                  {/* Small, Non-Intrusive 'People currently viewing this product' Counter (12-48 Randomized, ON/OFF, Isolated Memo Component) */}
                  {showLiveViewers && (
                    <LandingLiveViewerBadge productId={product.id} />
                  )}

                  {/* Simple, Clean, Standard Offer Price Box */}
                  <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200/90 space-y-2">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <div className="flex items-baseline gap-3">
                        <span className="font-mono font-extrabold text-2xl sm:text-3xl text-emerald-800 tabular-nums">
                          ৳{unitRetailPrice}
                        </span>
                        {unitRegularPrice > unitRetailPrice && (
                          <span className="font-mono text-base sm:text-lg text-slate-400 line-through font-bold tabular-nums">
                            ৳{unitRegularPrice}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {unitSavings > 0 && (
                          <span className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-xs font-extrabold tabular-nums">
                            সাশ্রয় ৳{unitSavings}
                          </span>
                        )}
                        {isFreeDelivery && (
                          <span className="px-2.5 py-1 rounded-lg bg-emerald-700 text-white text-xs font-extrabold">
                            ফ্রি ডেলিভারি
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-emerald-200/60 flex items-center gap-1.5 text-xs sm:text-sm font-bold text-emerald-950">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                      <span>অগ্রিম ১ টাকাও লাগবে না — পণ্য হাতে পেয়ে মূল্য পরিশোধ (Cash on Delivery)</span>
                    </div>
                  </div>

                  {/* Animated Evergreen Offer Countdown Timer in Hero Text Area (ON/OFF & Auto-Looping) */}
                  {showCountdown && (countdownPosition === 'hero_info' || !showTopHeading) && (
                    <div
                      onClick={scrollToOrderForm}
                      role="button"
                      tabIndex={0}
                      onKeyDown={e => {
                        if (e.key === 'Enter' || e.key === ' ') scrollToOrderForm();
                      }}
                      className="p-3.5 rounded-xl bg-gradient-to-r from-rose-50 via-amber-50/75 to-rose-50 border border-rose-200/90 animate-countdown-glow cursor-pointer transition-all hover:border-rose-300"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5">
                          <span className="relative flex h-9 w-9 rounded-xl bg-gradient-to-br from-[#dc2626] to-[#991b1b] text-white items-center justify-center shrink-0 shadow-xs">
                            <Flame className="w-5 h-5 text-amber-200 animate-pulse" />
                          </span>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75" />
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600" />
                              </span>
                              <p className="text-xs sm:text-sm font-extrabold text-rose-950 leading-tight">
                                {countdownTitle}
                              </p>
                            </div>
                            <p className="text-[11px] font-bold text-rose-700 mt-0.5">
                              সময় শেষ হওয়ার আগেই ডিসকাউন্ট মূল্যে অর্ডার করুন
                            </p>
                          </div>
                        </div>

                        {/* Live Ticking Hours : Minutes : Seconds Digital Blocks (Isolated Memo Component for 0 Parent Re-renders) */}
                        <LandingEvergreenCountdownDigits
                          productId={product.id}
                          countdownHours={countdownHours}
                          cycleTotalSeconds={cycleTotalSeconds}
                        />
                      </div>
                    </div>
                  )}

                  {/* Variation Selector (6 Mobile-First Responsive Designs + Admin Quick Switcher) */}
                  {/* Admin 1-Click Live Stock & Variation Out-of-Stock Control Bar (Visible only to Admin) */}
                  {isAdminViewing && (
                    <div className="p-3 rounded-xl bg-rose-50/90 border border-rose-200 shadow-2xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[11px] font-extrabold text-rose-950 flex items-center gap-1.5">
                          <span>📦 অ্যাডমিন লাইভ স্টক কন্ট্রোল (১-ক্লিকে ভ্যারিয়েশন বা প্রোডাক্ট স্টক আউট করুন):</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            const nextOut = !product.isOutOfStock;
                            updateProduct(product.id, { isOutOfStock: nextOut });
                            showToast(
                              nextOut
                                ? `"${product.nameBn}" ল্যান্ডিং পেজে স্টক আউট (Out of Stock) করা হয়েছে!`
                                : `"${product.nameBn}" পুনরায় ইন-স্টক (In Stock) করা হয়েছে!`,
                              nextOut ? 'info' : 'success'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                            product.isOutOfStock
                              ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                              : 'bg-white text-emerald-800 border-emerald-300 hover:bg-emerald-50'
                          }`}
                        >
                          {product.isOutOfStock
                            ? '🚫 পুরো প্রোডাক্ট স্টক শেষ (চালু করুন)'
                            : '✓ পুরো প্রোডাক্ট স্টকে আছে (আউট করুন)'}
                        </button>
                      </div>

                      {product.variants && product.variants.length > 0 && (
                        <div className="flex flex-wrap items-center gap-1.5">
                          {product.variants.map((v, vIdx) => {
                            const isVarOut = Boolean(v.outOfStock);
                            return (
                              <button
                                key={v.id}
                                type="button"
                                onClick={() => {
                                  const nextVariants = (product.variants || []).map((item, idx) =>
                                    idx === vIdx ? { ...item, outOfStock: !item.outOfStock } : item
                                  );
                                  updateProduct(product.id, { variants: nextVariants });
                                  showToast(
                                    !isVarOut
                                      ? `"${v.label}" ভ্যারিয়েশনটি ল্যান্ডিং পেজে স্টক আউট করা হয়েছে`
                                      : `"${v.label}" ভ্যারিয়েশনটি পুনরায় স্টকে চালু করা হয়েছে`,
                                    !isVarOut ? 'info' : 'success'
                                  );
                                }}
                                className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-rose-600 text-white border-rose-600'
                                    : 'bg-white text-slate-700 border-slate-300 hover:border-rose-400'
                                }`}
                              >
                                {v.label}: {isVarOut ? '🚫 স্টক শেষ' : '✓ চালু'}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Admin 1-Click Stock Out Image Overlay Style Switcher */}
                      <div className="pt-2 border-t border-rose-200/80 flex flex-wrap items-center justify-between gap-1.5">
                        <span className="text-[11px] font-bold text-rose-900">
                          🖼️ ছবির ওপর "স্টক শেষ" ভিউ স্টাইল:
                        </span>
                        <div className="flex flex-wrap items-center gap-1">
                          {(
                            [
                              { id: 'center_glass', label: '১. ছবির মাঝে স্মার্ট ব্যাজ' },
                              { id: 'diagonal_ribbon', label: '২. কোণাকুণি রিবন' },
                              { id: 'bottom_banner', label: '৩. ছবির নিচে বার' },
                              { id: 'classic_corner', label: '৪. আগের ক্লাসিক ব্যাজ' }
                            ] as { id: StockOutBadgeDesign; label: string }[]
                          ).map(opt => (
                            <button
                              key={opt.id}
                              type="button"
                              onClick={() => {
                                updateBusiness({ stockOutBadgeStyle: opt.id });
                                showToast(`স্টক শেষ ভিউ "${opt.label}" সেট করা হয়েছে!`, 'success');
                              }}
                              className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border transition-all cursor-pointer ${
                                stockOutBadgeStyle === opt.id
                                  ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                                  : 'bg-white text-slate-700 border-slate-300 hover:border-slate-500'
                              }`}
                            >
                              {opt.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {!isMultiShowcaseTemplate && product.variants && product.variants.length > 0 && (
                    <div className="space-y-2.5 pt-1">
                      {/* Admin Inline Quick Design Bar (Visible only to Admin) */}
                      {isAdminViewing && (
                        <div className="p-2.5 rounded-xl bg-slate-900 text-white border border-slate-700 shadow-xs space-y-2">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="text-[11px] font-extrabold text-emerald-300 flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <span>অ্যাডমিন ভ্যারিয়েশন ডিজাইন সুইচার (মোবাইল রেসপনসিভ):</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                const next = !showVariantPrice;
                                updateProduct(product.id, { landingVariantShowPrice: next });
                                updateBusiness({ landingVariantShowPrice: next });
                                showToast(
                                  next
                                    ? 'ভ্যারিয়েশন বাটনে প্রাইস দেখানো চালু (ON) হয়েছে'
                                    : 'ভ্যারিয়েশন বাটনে প্রাইস বন্ধ (OFF) হয়েছে',
                                  next ? 'success' : 'info'
                                );
                              }}
                              className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border transition-all cursor-pointer ${
                                showVariantPrice
                                  ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60'
                                  : 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700'
                              }`}
                            >
                              বাটনে প্রাইস: {showVariantPrice ? 'ON ✓' : 'OFF'}
                            </button>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                            {LANDING_VARIANT_DESIGN_OPTIONS.map(opt => {
                              const isCurrent = variantStyle === opt.id;
                              return (
                                <button
                                  key={opt.id}
                                  type="button"
                                  onClick={() => {
                                    updateProduct(product.id, { landingVariantStyle: opt.id });
                                    updateBusiness({ landingVariantStyle: opt.id });
                                    showToast(`"${opt.label}" অ্যাক্টিভ করা হয়েছে!`, 'success');
                                  }}
                                  className={`px-2 py-1.5 rounded-lg text-[11px] font-bold text-left truncate border transition-all cursor-pointer ${
                                    isCurrent
                                      ? 'bg-emerald-600 text-white border-emerald-400 shadow-2xs'
                                      : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
                                  }`}
                                  title={opt.desc}
                                >
                                  {opt.shortLabel}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Dual Variation Mode: Separate Color Selector Row when product has BOTH Color and Size */}
                      {hasLpDualVariants(product) && (
                        <div className="p-3 rounded-xl bg-rose-50/55 border border-rose-200/80 space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs sm:text-sm font-extrabold text-rose-950">
                              🎨 ১. পছন্দের কালার (Color) নির্বাচন করুন:
                            </span>
                            {activeVariant && (
                              <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-extrabold">
                                ✓ {activeVariant.label}
                              </span>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {getLpColorVariants(product).map(cVar => {
                              const isColorOut = Boolean(cVar.outOfStock);
                              const isColorSelected = !isColorOut && selectedColorId === cVar.id;
                              return (
                                <button
                                  key={cVar.id}
                                  type="button"
                                  onClick={() => handleSelectVariant(cVar)}
                                  className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer border-2 inline-flex items-center gap-1.5 ${
                                    isColorOut
                                      ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-75'
                                      : isColorSelected
                                      ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                                      : 'bg-white text-slate-800 border-rose-200 hover:border-rose-500'
                                  }`}
                                >
                                  {cVar.imageUrl ? (
                                    <img
                                      src={cVar.imageUrl}
                                      alt={cVar.label}
                                      className="w-5 h-5 rounded-md object-cover border border-white/60 shrink-0"
                                    />
                                  ) : (
                                    isColorSelected &&
                                    !isColorOut && (
                                      <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                                    )
                                  )}
                                  <span>{cVar.label}</span>
                                  {isColorOut && (
                                    <span className="text-[10px] font-extrabold text-rose-600 no-underline">
                                      (স্টক শেষ)
                                    </span>
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <label className="block text-sm sm:text-base font-extrabold text-slate-900">
                          {hasLpDualVariants(product)
                            ? '📏 ২. পছন্দের সাইজ / বয়স নির্বাচন করুন:'
                            : variantHeadingText}
                        </label>
                        {showSizeChart && (sizeChartRows.length > 0 || sizeChartImage !== '') && (
                          <button
                            type="button"
                            onClick={() => setShowSizeChartModal(true)}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-extrabold transition-colors cursor-pointer"
                          >
                            <Ruler className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                            <span>সাইজ চার্ট দেখুন</span>
                          </button>
                        )}
                      </div>

                      {/* DESIGN 1: Classic Radio List (Default existing design) */}
                      {variantStyle === 'classic_radio_list' && (
                        <div className="grid grid-cols-1 gap-2">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`w-full p-3 rounded-xl border-2 text-left flex items-center justify-between gap-2.5 transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-slate-100 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-emerald-50/95 border-emerald-600 shadow-2xs'
                                    : 'bg-white hover:bg-slate-50 border-slate-200'
                                }`}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <span
                                    className={`w-5 h-5 rounded-full flex items-center justify-center border-2 shrink-0 ${
                                      isSelected
                                        ? 'border-emerald-600 bg-emerald-600 text-white'
                                        : 'border-slate-300 bg-white'
                                    }`}
                                  >
                                    {isSelected && <span className="w-2 h-2 rounded-full bg-white" />}
                                  </span>
                                  <span
                                    className={`text-sm sm:text-base font-extrabold leading-snug break-words ${
                                      isVarOut
                                        ? 'text-slate-400 line-through'
                                        : isSelected
                                        ? 'text-emerald-950'
                                        : 'text-slate-800'
                                    }`}
                                  >
                                    {variant.label}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  {isVarOut ? (
                                    <span className="px-2.5 py-0.5 rounded-lg bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold shrink-0">
                                      স্টক শেষ
                                    </span>
                                  ) : (
                                    <>
                                      {showVariantPrice && vPrice > 0 && (
                                        <span
                                          className={`text-xs sm:text-sm font-extrabold font-mono ${
                                            isSelected ? 'text-emerald-800' : 'text-slate-600'
                                          }`}
                                        >
                                          {formatCurrency(vPrice)}
                                        </span>
                                      )}
                                      {isSelected && (
                                        <span className="px-2.5 py-0.5 rounded-lg bg-emerald-600 text-white text-[11px] font-bold shrink-0">
                                          নির্বাচিত ✓
                                        </span>
                                      )}
                                    </>
                                  )}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 2: Mobile 2-Column Smart Grid Chips (Super responsive on mobile) */}
                      {variantStyle === 'mobile_grid_chips' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`relative p-2.5 sm:p-3 rounded-xl border-2 text-left flex flex-col justify-between gap-1 min-h-[54px] transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-slate-100 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-emerald-50/95 border-emerald-600 shadow-xs ring-2 ring-emerald-500/20'
                                    : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-emerald-300'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-1.5 w-full">
                                  <span
                                    className={`text-xs sm:text-sm font-extrabold leading-snug break-words pr-1 ${
                                      isVarOut
                                        ? 'text-slate-400 line-through'
                                        : isSelected
                                        ? 'text-emerald-950'
                                        : 'text-slate-800'
                                    }`}
                                  >
                                    {variant.label}
                                  </span>
                                  <span
                                    className={`w-4 h-4 rounded-full flex items-center justify-center border shrink-0 mt-0.5 ${
                                      isSelected
                                        ? 'bg-emerald-600 border-emerald-600 text-white'
                                        : 'border-slate-300 bg-slate-50'
                                    }`}
                                  >
                                    {isSelected && <CheckCircle2 className="w-3 h-3" />}
                                  </span>
                                </div>
                                {isVarOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600">
                                    স্টক শেষ
                                  </span>
                                ) : showVariantPrice && vPrice > 0 ? (
                                  <div className="flex items-center justify-between pt-1 border-t border-emerald-900/10">
                                    <span
                                      className={`text-xs font-extrabold font-mono ${
                                        isSelected ? 'text-emerald-700' : 'text-slate-500'
                                      }`}
                                    >
                                      {formatCurrency(vPrice)}
                                    </span>
                                    {isSelected && (
                                      <span className="text-[10px] font-extrabold text-emerald-700">
                                        সিলেক্টেড
                                      </span>
                                    )}
                                  </div>
                                ) : (
                                  isSelected && (
                                    <span className="text-[10px] font-extrabold text-emerald-700">
                                      ✓ নির্বাচিত
                                    </span>
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 3: Modern Pill Capsules (1-Thumb Fast Tap on Mobile) */}
                      {variantStyle === 'pill_capsules' && (
                        <div className="flex flex-wrap gap-2">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`px-3.5 py-2.5 rounded-full border-2 text-xs sm:text-sm font-extrabold inline-flex items-center gap-2 transition-all cursor-pointer active:scale-95 ${
                                  isVarOut
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-gradient-to-r from-emerald-700 to-emerald-600 text-white border-emerald-700 shadow-sm'
                                    : 'bg-white text-slate-800 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/40'
                                }`}
                              >
                                <span
                                  className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] shrink-0 ${
                                    isSelected
                                      ? 'bg-white text-emerald-700 font-black'
                                      : 'border border-slate-300 bg-slate-50 text-transparent'
                                  }`}
                                >
                                  ✓
                                </span>
                                <span className={`leading-none ${isVarOut ? 'line-through' : ''}`}>
                                  {variant.label}
                                </span>
                                {isVarOut ? (
                                  <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-extrabold">
                                    স্টক শেষ
                                  </span>
                                ) : (
                                  showVariantPrice &&
                                  vPrice > 0 && (
                                    <span
                                      className={`px-2 py-0.5 rounded-full text-[11px] font-mono font-extrabold ${
                                        isSelected
                                          ? 'bg-emerald-900/40 text-amber-200'
                                          : 'bg-slate-100 text-slate-700'
                                      }`}
                                    >
                                      {formatCurrency(vPrice)}
                                    </span>
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 4: Premium Stacked / 2-Col Offer Cards */}
                      {variantStyle === 'stacked_offer_cards' && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            const vRegPrice = Number(
                              variant.regularPrice || product.regularPrice || 0
                            );
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`relative w-full p-3 rounded-2xl border-2 text-left flex items-center justify-between gap-2.5 transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-slate-100 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-gradient-to-r from-emerald-50 via-teal-50/70 to-amber-50/50 border-emerald-600 shadow-xs'
                                    : 'bg-white hover:bg-slate-50 border-slate-200'
                                }`}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div
                                    className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                                      isSelected
                                        ? 'bg-emerald-600 text-white shadow-2xs'
                                        : 'bg-slate-100 text-slate-400 border border-slate-200'
                                    }`}
                                  >
                                    <CheckCircle2 className="w-4 h-4" />
                                  </div>
                                  <div className="min-w-0">
                                    <p
                                      className={`text-sm font-extrabold leading-snug break-words ${
                                        isVarOut
                                          ? 'text-slate-400 line-through'
                                          : isSelected
                                          ? 'text-emerald-950'
                                          : 'text-slate-800'
                                      }`}
                                    >
                                      {variant.label}
                                    </p>
                                    <p className="text-[11px] font-bold text-slate-500">
                                      {isVarOut
                                        ? 'বর্তমানে স্টকে নেই'
                                        : isSelected
                                        ? 'অর্ডারের জন্য সিলেক্ট করা হয়েছে'
                                        : 'সিলেক্ট করতে ট্যাপ করুন'}
                                    </p>
                                  </div>
                                </div>
                                <div className="text-right shrink-0">
                                  {isVarOut ? (
                                    <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-700 text-[11px] font-extrabold">
                                      স্টক শেষ
                                    </span>
                                  ) : showVariantPrice && vPrice > 0 ? (
                                    <div className="flex flex-col items-end">
                                      <span
                                        className={`text-sm font-black font-mono ${
                                          isSelected ? 'text-emerald-700' : 'text-slate-900'
                                        }`}
                                      >
                                        {formatCurrency(vPrice)}
                                      </span>
                                      {vRegPrice > vPrice && (
                                        <span className="text-[10px] text-slate-400 line-through font-mono">
                                          {formatCurrency(vRegPrice)}
                                        </span>
                                      )}
                                    </div>
                                  ) : (
                                    <span
                                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                                        isSelected
                                          ? 'bg-emerald-600 text-white'
                                          : 'bg-slate-100 text-slate-600'
                                      }`}
                                    >
                                      {isSelected ? 'সিলেক্টেড ✓' : 'বেছে নিন'}
                                    </span>
                                  )}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 5: Royal Crimson & Gold Box (High-Converting Bangladeshi Deshi Shop Style) */}
                      {variantStyle === 'royal_crimson_tabs' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`relative p-2.5 sm:p-3 rounded-xl border-2 text-center flex flex-col items-center justify-center gap-1 min-h-[54px] transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-rose-700 text-white border-amber-400 shadow-sm ring-2 ring-rose-500/25'
                                    : 'bg-rose-50/40 hover:bg-rose-50 text-slate-800 border-rose-200'
                                }`}
                              >
                                {isSelected && (
                                  <span className="absolute -top-2 right-2 px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black uppercase tracking-tight shadow-2xs">
                                    ✓ Selected
                                  </span>
                                )}
                                <span
                                  className={`text-xs sm:text-sm font-extrabold leading-snug break-words ${
                                    isVarOut
                                      ? 'text-slate-400 line-through'
                                      : isSelected
                                      ? 'text-white'
                                      : 'text-slate-900'
                                  }`}
                                >
                                  {variant.label}
                                </span>
                                {isVarOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600">
                                    স্টক শেষ
                                  </span>
                                ) : (
                                  showVariantPrice &&
                                  vPrice > 0 && (
                                    <span
                                      className={`text-xs font-extrabold font-mono ${
                                        isSelected ? 'text-amber-300' : 'text-rose-700'
                                      }`}
                                    >
                                      {formatCurrency(vPrice)}
                                    </span>
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 6: Compact Segmented Touch Bar (Ultra Clean Mobile App Look) */}
                      {variantStyle === 'compact_segmented_bar' && (
                        <div className="p-1.5 rounded-2xl bg-slate-100 border border-slate-200/90 grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`px-2.5 py-2 rounded-xl text-center flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-slate-200/60 text-slate-400 opacity-75'
                                    : isSelected
                                    ? 'bg-white text-emerald-900 font-black shadow-xs border border-emerald-500/50'
                                    : 'bg-transparent text-slate-600 font-bold hover:text-slate-900 hover:bg-white/60'
                                }`}
                              >
                                <div className="flex items-center justify-center gap-1 max-w-full">
                                  {isSelected && (
                                    <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
                                  )}
                                  <span
                                    className={`text-xs sm:text-sm leading-tight break-words ${
                                      isVarOut ? 'line-through' : ''
                                    }`}
                                  >
                                    {variant.label}
                                  </span>
                                </div>
                                {isVarOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600">
                                    স্টক শেষ
                                  </span>
                                ) : (
                                  showVariantPrice &&
                                  vPrice > 0 && (
                                    <span
                                      className={`text-[11px] font-mono font-extrabold ${
                                        isSelected ? 'text-emerald-700' : 'text-slate-500'
                                      }`}
                                    >
                                      {formatCurrency(vPrice)}
                                    </span>
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 7: Red-Gold Clean Box (Exact same as Design 5, WITHOUT the "✓ Selected" top text badge) */}
                      {variantStyle === 'royal_crimson_clean' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`relative p-2.5 sm:p-3 rounded-xl border-2 text-center flex flex-col items-center justify-center gap-1 min-h-[54px] transition-all cursor-pointer active:scale-95 ${
                                  isVarOut
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-rose-700 text-white border-amber-400 shadow-sm ring-2 ring-rose-500/25'
                                    : 'bg-rose-50/40 hover:bg-rose-50 text-slate-800 border-rose-200'
                                }`}
                              >
                                <span
                                  className={`text-xs sm:text-sm font-extrabold leading-snug break-words ${
                                    isVarOut
                                      ? 'text-slate-400 line-through'
                                      : isSelected
                                      ? 'text-white'
                                      : 'text-slate-900'
                                  }`}
                                >
                                  {variant.label}
                                </span>
                                {isVarOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600">
                                    স্টক শেষ
                                  </span>
                                ) : (
                                  showVariantPrice &&
                                  vPrice > 0 && (
                                    <span
                                      className={`text-xs font-extrabold font-mono ${
                                        isSelected ? 'text-amber-300' : 'text-rose-700'
                                      }`}
                                    >
                                      {formatCurrency(vPrice)}
                                    </span>
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 8: Special Gift Edition — Royal Dark & Gold VIP Boutique Tile */}
                      {variantStyle === 'royal_luxury_gift' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {product.variants.map(variant => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(variant.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                onClick={() => handleSelectVariant(variant)}
                                className={`relative overflow-hidden p-2.5 sm:p-3 rounded-xl border-2 text-center flex flex-col items-center justify-center gap-1 min-h-[56px] transition-all cursor-pointer active:scale-95 ${
                                  isVarOut
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                    : isSelected
                                    ? 'bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-amber-300 border-amber-400 shadow-sm ring-2 ring-amber-400/30'
                                    : 'bg-gradient-to-b from-white to-amber-50/40 hover:to-amber-50/80 text-slate-800 border-amber-200/90 hover:border-amber-400'
                                }`}
                              >
                                {/* Corner Gold Ribbon Checkmark (Clean icon only, no clutter text) */}
                                {isSelected && (
                                  <span className="absolute top-0 right-0 w-5 h-5 bg-gradient-to-br from-amber-300 to-amber-500 text-slate-950 rounded-bl-lg flex items-center justify-center text-[10px] font-black shadow-2xs">
                                    ✓
                                  </span>
                                )}
                                <span
                                  className={`text-xs sm:text-sm font-extrabold leading-snug break-words px-1 ${
                                    isVarOut
                                      ? 'text-slate-400 line-through'
                                      : isSelected
                                      ? 'text-amber-200'
                                      : 'text-slate-900'
                                  }`}
                                >
                                  {variant.label}
                                </span>
                                {isVarOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600">
                                    স্টক শেষ
                                  </span>
                                ) : (
                                  showVariantPrice &&
                                  vPrice > 0 && (
                                    <span
                                      className={`text-xs font-extrabold font-mono px-2 py-0.5 rounded-md ${
                                        isSelected
                                          ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                                          : 'bg-amber-100/70 text-amber-900'
                                      }`}
                                    >
                                      {formatCurrency(vPrice)}
                                    </span>
                                  )
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* DESIGN 9: LP-2 Red Measurement Grid */}
                      {variantStyle === 'lp2_red_measurement_grid' && (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                          {product.variants.map((variant, vIdx) => {
                            const isVarOut = Boolean(variant.outOfStock);
                            const isSelected = !isVarOut && activeVariant?.id === variant.id;
                            const vPrice = Number(
                              variant.retailPrice || product.discountPrice || product.retailPrice || 0
                            );
                            const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                            return (
                              <button
                                key={variant.id}
                                type="button"
                                disabled={isVarOut}
                                onClick={() => handleSelectVariant(variant)}
                                className={`relative rounded-xl border-2 p-3 text-left transition-all cursor-pointer flex flex-col justify-between ${
                                  showVariantMeasurement ? 'min-h-[72px]' : 'min-h-[54px]'
                                } ${
                                  isVarOut
                                    ? 'border-slate-200 bg-slate-100 opacity-50 cursor-not-allowed'
                                    : isSelected
                                    ? 'border-[#dc2626] bg-rose-50/40 shadow-xs'
                                    : 'border-slate-200 bg-white hover:border-slate-300'
                                }`}
                              >
                                {isSelected && !isVarOut && (
                                  <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#dc2626] text-white flex items-center justify-center shadow-2xs">
                                    <Check className="w-3 h-3 stroke-[3]" />
                                  </span>
                                )}
                                <span
                                  className={`text-sm sm:text-base font-extrabold pr-6 ${
                                    isSelected ? 'text-[#dc2626]' : 'text-slate-900'
                                  }`}
                                >
                                  {variant.label}
                                </span>
                                {(isVarOut || showVariantMeasurement) && (
                                  <span className="text-[11px] sm:text-xs font-medium text-slate-500 mt-1">
                                    {isVarOut ? 'স্টক আউট' : measurementSubtext}
                                  </span>
                                )}
                                {!isVarOut && showVariantPrice && vPrice > 0 && (
                                  <span className="text-xs font-extrabold font-mono text-[#dc2626] mt-0.5">
                                    {formatCurrency(vPrice)}
                                  </span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Quantity Selector + Animated Scarcity Stock Pill */}
                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <span className="text-sm sm:text-base font-bold text-slate-800">
                      পরিমাণ (Quantity):
                    </span>
                    <div className="flex items-center border-2 border-slate-300 rounded-xl overflow-hidden bg-white shadow-2xs">
                      <button
                        type="button"
                        onClick={() => setQuantity(q => Math.max(1, q - 1))}
                        className="w-10 h-10 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-900 cursor-pointer transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-12 text-center font-mono font-extrabold text-sm sm:text-base text-slate-900 tabular-nums">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => setQuantity(q => Math.min(availableStock || 99, q + 1))}
                        className="w-10 h-10 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-900 cursor-pointer transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>

                    {availableStock <= 0 ? (
                      <div className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-extrabold text-rose-700 bg-rose-50 px-3.5 py-2 rounded-xl border border-rose-200">
                        <span>🚫 বর্তমানে স্টকে নেই (স্টক শেষ)</span>
                      </div>
                    ) : (
                      showLandingScarcity && (
                        <div className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-extrabold text-[#c30000] bg-gradient-to-r from-rose-50 via-red-50 to-amber-50 px-3.5 py-2 rounded-xl border border-rose-200/90 animate-scarcity-badge-pulse">
                          <span className="inline-block animate-bounce">🔥</span>
                          <span>অফার মূল্যে আর মাত্র {scarcityLeftCount} টি বাকি আছে!</span>
                        </div>
                      )
                    )}
                  </div>

                  {/* Smart Quantity-Based Free Delivery Banner & 1-Click Quick Quantity Selector ("২ পিস বা ৩ পিস কিনলে ডেলিভারি ফ্রি") */}
                  {availableStock > 0 && isQtyFreeDeliveryEnabled && !currentBusiness.freeDeliveryEnabled && !product.freeDeliveryOnLanding && (
                    <div
                      className={`p-3.5 rounded-2xl border-2 transition-all space-y-2.5 ${
                        isQtyFreeDeliveryUnlocked
                          ? 'bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border-emerald-400 shadow-xs'
                          : 'bg-gradient-to-r from-amber-50/95 via-orange-50/80 to-amber-50/95 border-amber-300 shadow-2xs'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-white shadow-2xs ${
                              isQtyFreeDeliveryUnlocked ? 'bg-emerald-600' : 'bg-amber-500'
                            }`}
                          >
                            <Truck className="w-4 h-4" />
                          </span>
                          <div>
                            {isQtyFreeDeliveryUnlocked ? (
                              <p className="text-xs sm:text-sm font-extrabold text-emerald-950">
                                🎉 অভিনন্দন! আপনি <span className="underline decoration-emerald-500">{quantity} পিস</span> সিলেক্ট করায়{' '}
                                <span className="text-emerald-700">সারা বাংলাদেশে ডেলিভারি সম্পূর্ণ ফ্রি!</span>
                              </p>
                            ) : (
                              <p className="text-xs sm:text-sm font-extrabold text-amber-950">
                                🚚 <span className="text-rose-700 font-black">স্পেশাল অফার:</span> কমপক্ষে{' '}
                                <span className="px-1.5 py-0.5 rounded bg-rose-600 text-white font-mono">
                                  {freeDeliveryMinQty} পিস
                                </span>{' '}
                                অর্ডার করলেই সারা বাংলাদেশে <span className="text-emerald-800 underline">ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!</span>
                              </p>
                            )}
                            <p className="text-[11px] font-bold text-slate-600 mt-0.5">
                              {isQtyFreeDeliveryUnlocked
                                ? `আপনার ডেলিভারি চার্জ ৳${selectedDeliveryZone === 'outside_dhaka' ? outsideDhakaFee : insideDhakaFee} সম্পূর্ণ মওকুফ হয়েছে ✓`
                                : `আর মাত্র ${remainingQtyForFreeDelivery} পিস যোগ করলেই ডেলিভারি চার্জ ৳০ হয়ে যাবে!`}
                            </p>
                          </div>
                        </div>

                        {!isQtyFreeDeliveryUnlocked && (
                          <button
                            type="button"
                            onClick={() => {
                              setQuantity(Math.min(availableStock || 99, freeDeliveryMinQty));
                              showToast(
                                `🎉 ${freeDeliveryMinQty} পিস সিলেক্ট হয়েছে — আপনার ডেলিভারি চার্জ এখন সম্পূর্ণ ফ্রি!`,
                                'success'
                              );
                            }}
                            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold shadow-xs cursor-pointer transition-all shrink-0 active:scale-95"
                          >
                            + {freeDeliveryMinQty} পিস নিন (ফ্রি ডেলিভারি)
                          </button>
                        )}
                      </div>

                      {/* 1-Click Quick Pack Selector Pills (1 pc vs 2 pcs Free Delivery vs 3 pcs Free Delivery) */}
                      <div className="grid grid-cols-3 gap-2 pt-1">
                        {[1, 2, 3].map(packQty => {
                          const isPackFree = packQty >= freeDeliveryMinQty;
                          const isSelectedQty = quantity === packQty;
                          return (
                            <button
                              key={packQty}
                              type="button"
                              onClick={() => {
                                setQuantity(Math.min(availableStock || 99, packQty));
                                if (isPackFree) {
                                  showToast(
                                    `🚚 ${packQty} পিস সিলেক্ট করায় ফ্রি ডেলিভারি চালু হয়েছে!`,
                                    'success'
                                  );
                                }
                              }}
                              className={`p-2 rounded-xl border text-center transition-all cursor-pointer relative ${
                                isSelectedQty
                                  ? isPackFree
                                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs ring-2 ring-emerald-500/25'
                                    : 'bg-slate-900 text-white border-slate-900 shadow-xs'
                                  : isPackFree
                                  ? 'bg-white hover:bg-emerald-50 text-emerald-900 border-emerald-300'
                                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              <div className="text-xs sm:text-sm font-extrabold">
                                {packQty} পিস কিনুন
                              </div>
                              <div
                                className={`text-[10px] font-bold mt-0.5 ${
                                  isSelectedQty
                                    ? isPackFree
                                      ? 'text-amber-200'
                                      : 'text-slate-300'
                                    : isPackFree
                                    ? 'text-emerald-700'
                                    : 'text-slate-500'
                                }`}
                              >
                                {isPackFree ? '🔥 ডেলিভারি ফ্রি!' : 'রেগুলার চার্জ'}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Admin 1-Click Control for Quantity-Based Free Delivery on Landing Page */}
                  {isAdminViewing && (
                    <div className="p-2.5 rounded-xl bg-emerald-950 text-white border border-emerald-700 shadow-2xs flex flex-wrap items-center justify-between gap-2">
                      <span className="text-[11px] font-extrabold text-emerald-200 flex items-center gap-1.5">
                        <Truck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>অ্যাডমিন কন্ট্রোল — কত পিস কিনলে ল্যান্ডিং পেজে ডেলিভারি ফ্রি:</span>
                      </span>
                      <div className="flex flex-wrap items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            updateProduct(product.id, { landingFreeDeliveryByQtyEnabled: false });
                            updateBusiness({ landingFreeDeliveryByQtyEnabled: false });
                            showToast('ল্যান্ডিং পেজে পিস হিসেবে ফ্রি ডেলিভারি অফার বন্ধ (OFF) করা হয়েছে', 'info');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                            !isQtyFreeDeliveryEnabled
                              ? 'bg-rose-600 text-white border-rose-500'
                              : 'bg-emerald-900/70 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                          }`}
                        >
                          OFF (বন্ধ)
                        </button>
                        {[2, 3, 4].map(n => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => {
                              updateProduct(product.id, {
                                landingFreeDeliveryByQtyEnabled: true,
                                landingFreeDeliveryMinQty: n
                              });
                              updateBusiness({
                                landingFreeDeliveryByQtyEnabled: true,
                                landingFreeDeliveryMinQty: n
                              });
                              showToast(
                                `ল্যান্ডিং পেজে "${n} পিস কিনলে ডেলিভারি ফ্রি" অফার চালু করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                              isQtyFreeDeliveryEnabled && freeDeliveryMinQty === n
                                ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-2xs'
                                : 'bg-emerald-900/70 text-emerald-100 border-emerald-700 hover:bg-emerald-800'
                            }`}
                          >
                            {n} পিসে ফ্রি 🚚
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Animated High-Demand & Scarcity Stock Progress Bar Card */}
                  {availableStock > 0 && showLandingScarcity && (
                    <div className="bg-gradient-to-r from-rose-50/90 via-red-50/75 to-amber-50/80 border border-rose-200/90 rounded-xl p-3 sm:p-3.5 shadow-2xs space-y-2">
                      <div className="flex items-center justify-between gap-2 text-xs sm:text-[13px] font-extrabold">
                        <span className="text-rose-800 flex items-center gap-1.5">
                          <Flame className="w-4 h-4 text-[#c30000] fill-[#c30000] animate-pulse shrink-0" />
                          <span>প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে</span>
                        </span>
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/90 border border-rose-200 text-[#c30000] text-[11px] sm:text-xs font-black shadow-2xs shrink-0">
                          <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75" />
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#c30000]" />
                          </span>
                          <span>সীমিত স্টক</span>
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-rose-100/90 rounded-full overflow-hidden p-0.5 border border-rose-200/60">
                        <div
                          className="relative h-full bg-gradient-to-r from-[#c30000] via-orange-500 to-amber-500 rounded-full overflow-hidden transition-all duration-500"
                          style={{ width: `${scarcityProgressPercent}%` }}
                        >
                          <div className="absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-transparent via-white/45 to-transparent animate-scarcity-bar-shimmer" />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Primary Scroll-to-Order CTA Button */}
                  <button
                    type="button"
                    disabled={availableStock <= 0}
                    onClick={scrollToOrderForm}
                    className={`w-full min-h-[54px] py-3.5 px-5 font-extrabold text-base sm:text-lg rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all ${
                      availableStock <= 0
                        ? 'bg-slate-300 text-slate-600 cursor-not-allowed'
                        : 'bg-[#c30000] hover:bg-[#9e0000] text-white cursor-pointer active:scale-[0.99] animate-order-cta-attention'
                    }`}
                  >
                    <ShoppingBag className="w-5 h-5 shrink-0" />
                    <span>
                      {availableStock <= 0
                        ? 'বর্তমানে স্টকে নেই (স্টক শেষ)'
                        : 'অর্ডার করতে এখানে ক্লিক করুন'}
                    </span>
                    {availableStock > 0 && <ArrowDown className="w-5 h-5 shrink-0 animate-bounce" />}
                  </button>

                  {/* Top Direct Call & WhatsApp Action Buttons (Configurable Enable / Disable per Product) */}
                  {(showCallButton || showWhatsappButton) && (
                    <div
                      className={`grid gap-2.5 ${
                        showCallButton && showWhatsappButton ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1'
                      }`}
                    >
                      {showCallButton && (
                        <a
                          href={`tel:${supportPhone.replace(/\s+/g, '')}`}
                          className="min-h-[46px] px-4 py-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 transition-colors"
                        >
                          <PhoneCall className="w-4 h-4 text-blue-600 shrink-0" />
                          <span className="tabular-nums">কল করুন: {supportPhone}</span>
                        </a>
                      )}

                      {showWhatsappButton && (
                        <a
                          href={`https://wa.me/${formattedWaNumber}?text=${prefilledWaOrderText}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="min-h-[46px] px-4 py-2.5 rounded-xl bg-emerald-50 hover:bg-[#25D366] text-emerald-950 hover:text-white border border-[#25D366]/60 hover:border-[#25D366] font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 transition-all group"
                        >
                          <LandingWhatsAppOriginalIcon className="w-4 h-4 text-[#25D366] group-hover:text-white shrink-0 transition-colors" />
                          <span>WhatsApp এ অর্ডার করুন</span>
                        </a>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </section>

            {/* ============================================================================ */}
            {/* LANDING PAGE 2 ONLY: MULTI-DESIGN SHOWCASE CARDS SECTION (Match Reference 1) */}
            {/* ============================================================================ */}
            {isTemplate2 && showcaseEntries.length > 0 && (
              <section
                id="landing-multi-design-showcase-section"
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 sm:p-6 space-y-5"
              >
                {/* Admin Inline Control Bar for "সাইজ পছন্দ করুন" Button ON/OFF & Text Edit (Visible only to Admin) */}
                {isAdminViewing && (
                  <div className="p-3 rounded-xl bg-slate-900 text-white border border-slate-700 shadow-xs space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-[11px] sm:text-xs font-extrabold text-emerald-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>
                          প্রোডাক্ট ছবির নিচের বাটন কন্ট্রোল ({`"${showcaseSelectBtnText} →"`}):
                        </span>
                      </span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            const next = !showcaseMobileTwoCols;
                            updateProduct(product.id, { landingShowcaseMobileTwoCols: next });
                            showToast(
                              next
                                ? 'মোবাইলে ১ লাইনে ২টি করে প্রোডাক্ট (2 কলাম) চালু (ON) করা হয়েছে!'
                                : 'মোবাইলে ১ লাইনে ১টি করে প্রোডাক্ট (1 কলাম) সেট (OFF) করা হয়েছে!',
                              next ? 'success' : 'info'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                            showcaseMobileTwoCols
                              ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60 hover:bg-emerald-500/35'
                              : 'bg-amber-500/25 text-amber-200 border-amber-400/60 hover:bg-amber-500/35'
                          }`}
                          title="মোবাইলে ১ লাইনে ২টি প্রোডাক্ট (ON) নাকি ১টি প্রোডাক্ট (OFF) দেখাবে তা পরিবর্তন করুন"
                        >
                          📱 মোবাইলে ২টি করে প্রোডাক্ট: {showcaseMobileTwoCols ? 'ON (২টি/লাইন) ✓' : 'OFF (১টি/লাইন)'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsEditingShowcaseSelectBtn(prev => !prev)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-extrabold transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>
                            {isEditingShowcaseSelectBtn ? 'এডিট বন্ধ করুন' : 'বাটন টেক্সট এডিট'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const next = !showShowcaseSelectBtn;
                            updateProduct(product.id, { landingShowcaseSelectBtnEnabled: next });
                            showToast(
                              next
                                ? `কার্ডের "${showcaseSelectBtnText}" বাটন চালু (ON) করা হয়েছে`
                                : `কার্ডের "${showcaseSelectBtnText}" বাটন বন্ধ (OFF) করা হয়েছে`,
                              next ? 'success' : 'info'
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all cursor-pointer ${
                            showShowcaseSelectBtn
                              ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60 hover:bg-emerald-500/35'
                              : 'bg-rose-500/25 text-rose-200 border-rose-400/60 hover:bg-rose-500/35'
                          }`}
                        >
                          বাটন: {showShowcaseSelectBtn ? 'ON ✓' : 'OFF'}
                        </button>
                      </div>
                    </div>

                    {isEditingShowcaseSelectBtn && (
                      <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 space-y-2">
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                          <input
                            type="text"
                            value={draftShowcaseSelectBtnText}
                            onChange={e => setDraftShowcaseSelectBtnText(e.target.value)}
                            placeholder="যেমন: সাইজ পছন্দ করুন"
                            className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-600 text-white text-xs font-bold focus:outline-none focus:border-emerald-400"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const cleaned =
                                draftShowcaseSelectBtnText.trim() || 'সাইজ পছন্দ করুন';
                              updateProduct(product.id, {
                                landingShowcaseSelectBtnText: cleaned,
                                landingShowcaseSelectBtnEnabled: true
                              });
                              setIsEditingShowcaseSelectBtn(false);
                              showToast(
                                `বাটনের টেক্সট "${cleaned}" সেভ করা হয়েছে!`,
                                'success'
                              );
                            }}
                            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold cursor-pointer shrink-0"
                          >
                            সেভ করুন ✓
                          </button>
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[10px] text-slate-400 font-bold">কুইক টেক্সট:</span>
                          {[
                            'সাইজ পছন্দ করুন',
                            'পছন্দের সাইজ নিন',
                            'অর্ডার করতে ক্লিক করুন',
                            'ডিজাইন সিলেক্ট করুন'
                          ].map(preset => (
                            <button
                              key={preset}
                              type="button"
                              onClick={() => {
                                setDraftShowcaseSelectBtnText(preset);
                                updateProduct(product.id, {
                                  landingShowcaseSelectBtnText: preset,
                                  landingShowcaseSelectBtnEnabled: true
                                });
                                showToast(`বাটনের টেক্সট "${preset}" সেট করা হয়েছে!`, 'success');
                              }}
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold border cursor-pointer transition-colors ${
                                showcaseSelectBtnText === preset
                                  ? 'bg-emerald-600 text-white border-emerald-400'
                                  : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-700'
                              }`}
                            >
                              {preset}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="text-center space-y-1.5 max-w-2xl mx-auto">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-extrabold">
                    <Sparkles className="w-3.5 h-3.5 text-rose-600" />
                    <span>{showcaseEntries.length}টি এক্সক্লুসিভ কালেকশন</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                    {(product.landingShowcaseSectionTitle || '').trim() ||
                      'পছন্দের ড্রেস ডিজাইনটি বেছে নিন'}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 font-medium">
                    {(product.landingShowcaseSectionSubtitle || '').trim() ||
                      'নিচের যেকোনো কার্ডে "অর্ডার করুন" বাটনে ক্লিক করলে সরাসরি নিচে চেকআউট ফর্মে সিলেক্ট হয়ে যাবে'}
                  </p>
                </div>

                {/* Responsive Grid: 3 columns on desktop (lg:grid-cols-3), 2 on tablet (sm:grid-cols-2), and on mobile either 2 columns (when showcaseMobileTwoCols is ON) or 1 full-width column (when OFF) */}
                <div
                  className={
                    showcaseMobileTwoCols
                      ? 'grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-5'
                      : 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5'
                  }
                >
                  {showcaseEntries.map(entry => {
                    const itemProd = entry.product;
                    const firstInStockVar =
                      itemProd.variants?.find(v => !v.outOfStock) || itemProd.variants?.[0];
                    const cardSalePrice = firstInStockVar
                      ? firstInStockVar.retailPrice
                      : itemProd.retailPrice;
                    const rawCardReg =
                      firstInStockVar?.regularPrice ?? itemProd.regularPrice ?? cardSalePrice;
                    const cardRegularPrice =
                      rawCardReg > cardSalePrice
                        ? rawCardReg
                        : Math.round(cardSalePrice * 1.3);
                    const isCurrentlySelected =
                      selectedShowcaseEntry?.product.id === itemProd.id;
                    const shortDescText =
                      (itemProd.shortDescription || '').trim() ||
                      (itemProd.landingShortDescription || '').trim() ||
                      'উন্নত মানের ফেব্রিক, নিখুঁত ফিনিশিং এবং আরামদায়ক ফিটিং।';

                    const handleSelectCardAndScroll = () => {
                      setSelectedShowcaseProductId(itemProd.id);
                      const targetVar =
                        itemProd.variants?.find(v => !v.outOfStock) || itemProd.variants?.[0];
                      setSelectedVariantId(targetVar?.id || '');
                      triggerLandingAddToCart(targetVar, quantity);
                      triggerLandingInitiateCheckout();
                      const checkoutEl = document.getElementById(
                        'landing-direct-order-section'
                      );
                      if (checkoutEl) {
                        checkoutEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    };

                    return (
                      <div
                        key={itemProd.id}
                        className={`group rounded-2xl bg-white border-2 overflow-hidden flex flex-col justify-between transition-all duration-200 ${
                          isCurrentlySelected
                            ? 'border-[#dc2626] shadow-md ring-2 ring-rose-500/15'
                            : 'border-slate-200/90 hover:border-rose-300 shadow-xs hover:shadow-md'
                        }`}
                      >
                        <div>
                          {/* Product Image Container with Top-Left Red Badge & Bottom-Left Overlay Badge */}
                          <div
                            onClick={handleSelectCardAndScroll}
                            className="relative aspect-[4/4.3] w-full bg-slate-100 overflow-hidden cursor-pointer"
                          >
                            {itemProd.image ? (
                              <img
                                src={itemProd.image}
                                alt={itemProd.nameBn}
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                              />
                            ) : (
                              <ProductThumbnail
                                product={itemProd}
                                className="w-full h-full"
                                imgClassName="object-cover"
                              />
                            )}

                            {/* Top-left red badge (e.g., টপ সেলিং 🔥) */}
                            <div
                              className={
                                showcaseMobileTwoCols
                                  ? 'absolute top-2 left-2 sm:top-3 sm:left-3 z-10'
                                  : 'absolute top-3 left-3 z-10'
                              }
                            >
                              <span
                                className={
                                  showcaseMobileTwoCols
                                    ? 'inline-flex items-center gap-1 px-2 py-0.5 sm:px-3 sm:py-1 rounded-full bg-[#dc2626] text-white text-[10px] sm:text-xs font-extrabold shadow-md'
                                    : 'inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#dc2626] text-white text-xs font-extrabold shadow-md'
                                }
                              >
                                {entry.badgeText}
                              </span>
                            </div>

                            {/* Bottom-left overlay badge (সাইজ পছন্দ করুন →) */}
                            {showShowcaseSelectBtn && (
                              <button
                                type="button"
                                onClick={e => {
                                  e.stopPropagation();
                                  handleSelectCardAndScroll();
                                }}
                                className={
                                  showcaseMobileTwoCols
                                    ? 'absolute bottom-2 left-2 sm:bottom-3 sm:left-3 z-10 inline-flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl bg-slate-950/80 hover:bg-[#dc2626] backdrop-blur-xs text-white text-[10px] sm:text-xs font-extrabold shadow-md transition-colors cursor-pointer'
                                    : 'absolute bottom-3 left-3 z-10 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/80 hover:bg-[#dc2626] backdrop-blur-xs text-white text-xs font-extrabold shadow-md transition-colors cursor-pointer'
                                }
                              >
                                <span>{showcaseSelectBtnText}</span>
                                <span>→</span>
                              </button>
                            )}
                          </div>

                          {/* Card Body */}
                          <div
                            className={
                              showcaseMobileTwoCols
                                ? 'p-2.5 sm:p-4 space-y-1.5 sm:space-y-2'
                                : 'p-4 space-y-2'
                            }
                          >
                            {/* Fabric subtitle on the left, color name on the right */}
                            <div
                              className={
                                showcaseMobileTwoCols
                                  ? 'flex items-center justify-between gap-1 text-[10px] sm:text-xs'
                                  : 'flex items-center justify-between gap-2 text-xs'
                              }
                            >
                              <span className="font-bold text-slate-600 truncate">
                                {entry.fabricSubtitle}
                              </span>
                              <span className="font-extrabold text-[#dc2626] shrink-0">
                                {entry.colorTag}
                              </span>
                            </div>

                            {/* Bold Bangla product title */}
                            <h3
                              onClick={handleSelectCardAndScroll}
                              className={
                                showcaseMobileTwoCols
                                  ? 'text-xs sm:text-lg font-extrabold text-slate-900 leading-snug line-clamp-2 cursor-pointer hover:text-[#dc2626] transition-colors'
                                  : 'text-base sm:text-lg font-extrabold text-slate-900 leading-snug line-clamp-2 cursor-pointer hover:text-[#dc2626] transition-colors'
                              }
                            >
                              {itemProd.nameBn}
                            </h3>

                            {/* Short description */}
                            <p
                              className={
                                showcaseMobileTwoCols
                                  ? 'text-[11px] sm:text-sm text-slate-600 line-clamp-2 leading-relaxed'
                                  : 'text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed'
                              }
                            >
                              {shortDescText}
                            </p>
                          </div>
                        </div>

                        {/* Price & Order CTA Footer */}
                        <div
                          className={
                            showcaseMobileTwoCols
                              ? 'px-2.5 pb-2.5 pt-2 sm:px-4 sm:pb-4 sm:pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-3'
                              : 'px-4 pb-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-3'
                          }
                        >
                          <div
                            className={
                              showcaseMobileTwoCols
                                ? 'flex items-baseline justify-between sm:block gap-1'
                                : ''
                            }
                          >
                            {cardRegularPrice > cardSalePrice && (
                              <span
                                className={
                                  showcaseMobileTwoCols
                                    ? 'text-[10px] sm:text-xs font-bold text-slate-400 line-through tabular-nums sm:block order-2 sm:order-1'
                                    : 'block text-xs font-bold text-slate-400 line-through tabular-nums'
                                }
                              >
                                ৳ {cardRegularPrice.toLocaleString('en-IN')}
                              </span>
                            )}
                            <span
                              className={
                                showcaseMobileTwoCols
                                  ? 'text-sm sm:text-xl font-black text-[#dc2626] tabular-nums order-1 sm:order-2'
                                  : 'text-lg sm:text-xl font-black text-[#dc2626] tabular-nums'
                              }
                            >
                              ৳ {cardSalePrice.toLocaleString('en-IN')}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={handleSelectCardAndScroll}
                            className={
                              showcaseMobileTwoCols
                                ? 'w-full sm:w-auto justify-center px-2.5 py-2 sm:px-4 sm:py-2.5 rounded-xl bg-[#dc2626] hover:bg-[#b91c1c] active:scale-[0.99] text-white font-extrabold text-[11px] sm:text-sm inline-flex items-center gap-1 sm:gap-1.5 shadow-sm transition-all cursor-pointer shrink-0'
                                : 'px-4 py-2.5 rounded-xl bg-[#dc2626] hover:bg-[#b91c1c] active:scale-[0.99] text-white font-extrabold text-xs sm:text-sm inline-flex items-center gap-1.5 shadow-sm transition-all cursor-pointer shrink-0'
                            }
                          >
                            <span>অর্ডার করুন</span>
                            <span>→</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* ============================================================================ */}
            {/* LANDING PAGE 3 ONLY: MULTI-PRODUCT ORDER SHOWCASE SECTION (Select Multiple!) */}
            {/* ============================================================================ */}
            {isTemplate3 && showcaseEntries.length > 0 && (
              <section
                id="landing-multi-product-order-showcase-section"
                className="bg-white rounded-2xl border-2 border-indigo-200/90 shadow-xs p-4 sm:p-6 space-y-5"
              >
                <div className="text-center space-y-2 max-w-2xl mx-auto">
                  <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-800 text-xs font-extrabold">
                    <ShoppingBag className="w-3.5 h-3.5 text-indigo-600" />
                    <span>
                      একসাথে একাধিক প্রোডাক্ট অর্ডার সিস্টেম ({showcaseEntries.length}টি কালেকশন)
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                    {(product.landingShowcaseSectionTitle || '').trim() ||
                      'পছন্দের এক বা একাধিক ড্রেস সিলেক্ট করে একসাথে অর্ডার করুন'}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 font-medium">
                    নিচের যেকোনো প্রোডাক্টে টিক (✓) দিয়ে আপনার পছন্দের কালার/সাইজ ও পরিমাণ বেছে নিন — এক অর্ডারেই সব প্রোডাক্ট ডেলিভারি পাবেন!
                  </p>
                </div>

                {/* Quick Multi-Select Bar */}
                <div className="p-3 rounded-xl bg-indigo-50/70 border border-indigo-200 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-extrabold text-indigo-950">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-mono">
                      নির্বাচিত: {lp3SelectedResolvedItems.length}টি প্রোডাক্ট ({effectiveOrderQuantity} পিস)
                    </span>
                    <span className="font-mono text-emerald-800">
                      মোট: {formatCurrency(subtotal)}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setLp3SelectionMap(prev => {
                          const next = { ...prev };
                          showcaseEntries.forEach(e => {
                            if (next[e.product.id]) {
                              next[e.product.id] = { ...next[e.product.id], selected: true };
                            }
                          });
                          return next;
                        });
                        showToast('সবগুলো প্রোডাক্ট অর্ডারে যুক্ত করা হয়েছে!', 'success');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-white hover:bg-indigo-100 text-indigo-800 border border-indigo-300 text-xs font-extrabold cursor-pointer transition-colors"
                    >
                      ✓ সবগুলো সিলেক্ট করুন
                    </button>
                    <button
                      type="button"
                      onClick={scrollToOrderForm}
                      className="px-3.5 py-1.5 rounded-lg bg-[#dc2626] hover:bg-[#b91c1c] text-white text-xs font-extrabold cursor-pointer transition-colors shadow-2xs"
                    >
                      অর্ডার ফর্মে যান ↓
                    </button>
                  </div>
                </div>

                <div
                  className={
                    showcaseMobileTwoCols
                      ? 'grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-5'
                      : 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5'
                  }
                >
                  {showcaseEntries.map(entry => {
                    const itemProd = entry.product;
                    const cfg = lp3SelectionMap[itemProd.id] || {
                      selected: false,
                      variantId: '',
                      colorId: '',
                      quantity: 1
                    };
                    const isPicked = Boolean(cfg.selected);
                    const isDual = hasLpDualVariants(itemProd);
                    const colorVars = getLpColorVariants(itemProd);
                    const sizeVars = getLpSizeVariants(itemProd);
                    const singleVars = !isDual ? itemProd.variants || [] : [];

                    const resolvedItem = lp3SelectedResolvedItems.find(
                      x => x.product.id === itemProd.id
                    );
                    const firstInStockVar =
                      itemProd.variants?.find(v => !v.outOfStock) || itemProd.variants?.[0];
                    const cardSalePrice = resolvedItem
                      ? resolvedItem.unitRetailPrice
                      : firstInStockVar
                      ? firstInStockVar.retailPrice
                      : itemProd.retailPrice;
                    const rawCardReg = resolvedItem
                      ? resolvedItem.unitRegularPrice
                      : firstInStockVar?.regularPrice ?? itemProd.regularPrice ?? cardSalePrice;
                    const cardRegularPrice =
                      rawCardReg > cardSalePrice
                        ? rawCardReg
                        : Math.round(cardSalePrice * 1.3);

                    return (
                      <div
                        key={itemProd.id}
                        className={`group rounded-2xl bg-white border-2 overflow-hidden flex flex-col justify-between transition-all duration-200 ${
                          isPicked
                            ? 'border-emerald-600 shadow-md ring-2 ring-emerald-500/20 bg-emerald-50/10'
                            : 'border-slate-200/90 hover:border-indigo-300 shadow-xs'
                        }`}
                      >
                        <div>
                          {/* Product Image with Multi-Select Checkbox Badge */}
                          <div
                            onClick={() => toggleLp3ProductSelection(itemProd.id)}
                            className="relative aspect-[4/4.2] w-full bg-slate-100 overflow-hidden cursor-pointer"
                          >
                            {resolvedItem?.activeVariant?.imageUrl || itemProd.image ? (
                              <img
                                src={resolvedItem?.activeVariant?.imageUrl || itemProd.image}
                                alt={itemProd.nameBn}
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                              />
                            ) : (
                              <ProductThumbnail
                                product={itemProd}
                                className="w-full h-full"
                                imgClassName="object-cover"
                              />
                            )}

                            <div className="absolute top-2.5 left-2.5 z-10">
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#dc2626] text-white text-[10px] sm:text-xs font-extrabold shadow-md">
                                {entry.badgeText}
                              </span>
                            </div>

                            <button
                              type="button"
                              onClick={e => {
                                e.stopPropagation();
                                toggleLp3ProductSelection(itemProd.id);
                              }}
                              className={`absolute top-2.5 right-2.5 z-10 px-2.5 py-1 rounded-xl text-[11px] font-extrabold shadow-md flex items-center gap-1 cursor-pointer transition-all ${
                                isPicked
                                  ? 'bg-emerald-600 text-white border border-white'
                                  : 'bg-white/95 text-slate-800 border border-slate-300 hover:border-emerald-500'
                              }`}
                            >
                              {isPicked ? (
                                <>
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                  <span>সিলেক্টেড</span>
                                </>
                              ) : (
                                <span>+ সিলেক্ট করুন</span>
                              )}
                            </button>
                          </div>

                          {/* Card Body: Title + Inline Color/Size & Quantity Controls */}
                          <div className="p-3 sm:p-4 space-y-2.5">
                            <div className="flex items-center justify-between gap-2 text-[11px]">
                              <span className="font-bold text-slate-600 truncate">
                                {entry.fabricSubtitle}
                              </span>
                              <span className="font-extrabold text-[#dc2626] shrink-0">
                                {entry.colorTag}
                              </span>
                            </div>

                            <h3
                              onClick={() => toggleLp3ProductSelection(itemProd.id)}
                              className="text-sm sm:text-base font-extrabold text-slate-900 leading-snug line-clamp-2 cursor-pointer hover:text-emerald-700"
                            >
                              {itemProd.nameBn}
                            </h3>

                            {/* Dual Color Selector on Card */}
                            {isDual && colorVars.length > 0 && (
                              <div className="space-y-1 pt-0.5">
                                <span className="block text-[10px] font-extrabold text-rose-900">
                                  🎨 কালার সিলেক্ট করুন:
                                </span>
                                <div className="flex flex-wrap gap-1">
                                  {colorVars.map(cVar => {
                                    const isOut = Boolean(cVar.outOfStock);
                                    const isSel = !isOut && cfg.colorId === cVar.id;
                                    return (
                                      <button
                                        key={cVar.id}
                                        type="button"
                                        disabled={isOut}
                                        onClick={() =>
                                          updateLp3ProductConfig(itemProd.id, {
                                            selected: true,
                                            colorId: cVar.id
                                          })
                                        }
                                        className={`px-2 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer inline-flex items-center gap-1 ${
                                          isOut
                                            ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-60'
                                            : isSel
                                            ? 'bg-rose-600 text-white border-rose-600'
                                            : 'bg-rose-50/60 text-slate-800 border-rose-200 hover:border-rose-500'
                                        }`}
                                      >
                                        {cVar.imageUrl && (
                                          <img
                                            src={cVar.imageUrl}
                                            alt={cVar.label}
                                            className="w-3.5 h-3.5 rounded-xs object-cover border border-white/60 shrink-0"
                                          />
                                        )}
                                        <span>{cVar.label}</span>
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            )}

                            {/* Size / Single Variation Selector on Card */}
                            {(isDual ? sizeVars : singleVars).length > 0 && (
                              <div className="space-y-1 pt-0.5">
                                <span className="block text-[10px] font-extrabold text-slate-700">
                                  📏 {isDual ? 'সাইজ সিলেক্ট করুন:' : 'ভ্যারিয়েশন / সাইজ:'}
                                </span>
                                <div className="flex flex-wrap gap-1">
                                  {(isDual ? sizeVars : singleVars).map(sVar => {
                                    const isOut = Boolean(sVar.outOfStock);
                                    const isSel = !isOut && cfg.variantId === sVar.id;
                                    return (
                                      <button
                                        key={sVar.id}
                                        type="button"
                                        disabled={isOut}
                                        onClick={() =>
                                          updateLp3ProductConfig(itemProd.id, {
                                            selected: true,
                                            variantId: sVar.id
                                          })
                                        }
                                        className={`px-2 py-1 rounded-lg text-[10px] font-extrabold border transition-all cursor-pointer ${
                                          isOut
                                            ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-60'
                                            : isSel
                                            ? 'bg-emerald-700 text-white border-emerald-700'
                                            : 'bg-slate-50 text-slate-800 border-slate-200 hover:border-emerald-500'
                                        }`}
                                      >
                                        {sVar.label}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            )}

                            {/* Quantity Stepper on Card */}
                            <div className="flex items-center justify-between gap-2 pt-1">
                              <span className="text-[11px] font-bold text-slate-600">পরিমাণ:</span>
                              <div className="inline-flex items-center rounded-lg border border-slate-300 bg-white overflow-hidden">
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateLp3ProductConfig(itemProd.id, {
                                      selected: true,
                                      quantity: Math.max(1, (cfg.quantity || 1) - 1)
                                    })
                                  }
                                  className="w-7 h-7 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold cursor-pointer"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="w-8 text-center font-mono text-xs font-extrabold text-slate-900">
                                  {cfg.quantity || 1}
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateLp3ProductConfig(itemProd.id, {
                                      selected: true,
                                      quantity: Math.min(99, (cfg.quantity || 1) + 1)
                                    })
                                  }
                                  className="w-7 h-7 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Card Footer: Price + Add/Remove & Order Now Buttons */}
                        <div className="px-3 pb-3 pt-2.5 sm:px-4 sm:pb-4 border-t border-slate-100 space-y-2">
                          <div className="flex items-baseline justify-between gap-2">
                            <div>
                              {cardRegularPrice > cardSalePrice && (
                                <span className="text-[11px] font-bold text-slate-400 line-through mr-1.5 tabular-nums">
                                  ৳{cardRegularPrice.toLocaleString('en-IN')}
                                </span>
                              )}
                              <span className="text-base sm:text-lg font-black text-[#dc2626] tabular-nums">
                                ৳{cardSalePrice.toLocaleString('en-IN')}
                              </span>
                            </div>
                            {isPicked && (
                              <span className="text-[11px] font-mono font-extrabold text-emerald-700">
                                মোট: ৳{(cardSalePrice * (cfg.quantity || 1)).toLocaleString('en-IN')}
                              </span>
                            )}
                          </div>

                          <div className="grid grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={() => toggleLp3ProductSelection(itemProd.id)}
                              className={`py-2 px-2 rounded-xl font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 transition-all cursor-pointer border ${
                                isPicked
                                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                  : 'bg-slate-100 hover:bg-emerald-50 text-slate-800 border-slate-300'
                              }`}
                            >
                              {isPicked ? '✓ অর্ডারে যুক্ত' : '+ অর্ডারে নিন'}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                toggleLp3ProductSelection(itemProd.id, true);
                                scrollToOrderForm();
                              }}
                              className="py-2 px-2 rounded-xl bg-[#dc2626] hover:bg-[#b91c1c] text-white font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-2xs transition-all cursor-pointer"
                            >
                              <span>অর্ডার করুন</span>
                              <span>→</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* SECTION 1.2: SEPARATE FULL BODY SIZE CHART SECTION RIGHT ABOVE BANNER 2 & VIDEO (ON/OFF + Inline Admin Editor & Presets) */}
            {(showBodySizeChart || isAdminViewing) && (sizeChartRows.length > 0 || sizeChartImage !== '' || isAdminViewing) && (
              <section
                id="landing-size-chart-section"
                className={`rounded-2xl border shadow-xs p-4 sm:p-6 space-y-4 transition-all ${
                  showBodySizeChart
                    ? 'bg-gradient-to-br from-indigo-50/40 via-white to-violet-50/30 border-indigo-200/80'
                    : 'bg-slate-100/80 border-dashed border-slate-300 opacity-80'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-indigo-100/80">
                  <div className="space-y-1">
                    {!showBodySizeChart && isAdminViewing && (
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-md bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold">
                          কাস্টমারদের জন্য এখন লুকানো (OFF) আছে
                        </span>
                      </div>
                    )}
                    <h2 className="text-base sm:text-xl font-extrabold text-slate-900">
                      {sizeChartTitle}
                    </h2>
                    {sizeChartSubtitle !== '' && (
                      <p className="text-xs sm:text-sm text-slate-600 font-medium">
                        {sizeChartSubtitle}
                      </p>
                    )}
                  </div>

                  {/* Admin Quick Controls right on the Full Body Size Chart */}
                  {isAdminViewing && (
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleLoadBodySizeChartPreset('clothing')}
                        className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-bold cursor-pointer transition-colors"
                      >
                        পোশাক প্রিসেট
                      </button>
                      <button
                        type="button"
                        onClick={() => handleLoadBodySizeChartPreset('shoe')}
                        className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-bold cursor-pointer transition-colors"
                      >
                        জুতা প্রিসেট
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditingBodySizeChart(prev => !prev)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold cursor-pointer transition-colors"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>{isEditingBodySizeChart ? 'এডিট বন্ধ করুন' : 'চার্ট এডিট করুন'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const next = !showBodySizeChart;
                          updateProduct(product.id, { landingBodySizeChartEnabled: next });
                          showToast(
                            next
                              ? 'বডি ফুল সাইজ চার্ট চালু (ON) করা হয়েছে'
                              : 'বডি ফুল সাইজ চার্ট বন্ধ (OFF) করা হয়েছে',
                            'info'
                          );
                        }}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-colors ${
                          showBodySizeChart
                            ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                            : 'bg-rose-600 text-white border-rose-600 hover:bg-rose-700'
                        }`}
                      >
                        {showBodySizeChart ? 'বডি চার্ট: ON' : 'বডি চার্ট: OFF'}
                      </button>
                    </div>
                  )}
                </div>

                {/* Inline Admin Size Chart Editor (Just like Product Page Description Chart) */}
                {isAdminViewing && isEditingBodySizeChart && (
                  <div className="p-4 rounded-xl bg-white border-2 border-indigo-200 shadow-xs space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="text-xs font-extrabold text-indigo-900">
                        ল্যান্ডিং পেজ বডি সাইজ চার্ট কাস্টমাইজ করুন (পপ-আপ ও বডি চার্ট উভয় স্থানেই আপডেট হবে)
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">
                          চার্ট শিরোনাম (Title):
                        </label>
                        <input
                          type="text"
                          value={draftBodyChartTitle}
                          onChange={e => setDraftBodyChartTitle(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">
                          সাব-টাইটেল (Subtitle):
                        </label>
                        <input
                          type="text"
                          value={draftBodyChartSubtitle}
                          onChange={e => setDraftBodyChartSubtitle(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {[0, 1, 2].map(colIdx => (
                        <div key={colIdx}>
                          <label className="block text-[10px] font-bold text-slate-500 mb-1">
                            কলাম হেডার {colIdx + 1}:
                          </label>
                          <input
                            type="text"
                            value={draftBodyChartHeaders[colIdx]}
                            onChange={e => {
                              const next: [string, string, string] = [...draftBodyChartHeaders];
                              next[colIdx] = e.target.value;
                              setDraftBodyChartHeaders(next);
                            }}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50/40 text-xs font-extrabold text-indigo-950"
                          />
                        </div>
                      ))}
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[11px] font-bold text-slate-600">
                        সাইজ সারিগুলো (Rows):
                      </label>
                      {draftBodyChartRows.map((row, idx) => (
                        <div key={row.id || idx} className="grid grid-cols-12 gap-2 items-center">
                          <input
                            type="text"
                            value={row.size}
                            onChange={e =>
                              setDraftBodyChartRows(prev =>
                                prev.map((r, i) => (i === idx ? { ...r, size: e.target.value } : r))
                              )
                            }
                            placeholder="সাইজ (যেমন: M / L / XL)"
                            className="col-span-4 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-900"
                          />
                          <input
                            type="text"
                            value={row.chest}
                            onChange={e =>
                              setDraftBodyChartRows(prev =>
                                prev.map((r, i) => (i === idx ? { ...r, chest: e.target.value } : r))
                              )
                            }
                            placeholder="বডি / চেস্ট"
                            className="col-span-4 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-800"
                          />
                          <input
                            type="text"
                            value={row.length}
                            onChange={e =>
                              setDraftBodyChartRows(prev =>
                                prev.map((r, i) => (i === idx ? { ...r, length: e.target.value } : r))
                              )
                            }
                            placeholder="লম্বা / দৈর্ঘ্য"
                            className="col-span-3 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-800"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setDraftBodyChartRows(prev => prev.filter((_, i) => i !== idx))
                            }
                            className="col-span-1 p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 flex items-center justify-center cursor-pointer"
                            title="সারি মুছুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() =>
                          setDraftBodyChartRows(prev => [
                            ...prev,
                            { id: `sz_${Date.now()}`, size: 'নতুন সাইজ', chest: '৩৮ ইঞ্চি', length: '২৭ ইঞ্চি' }
                          ])
                        }
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>নতুন সাইজ সারি যোগ করুন</span>
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setIsEditingBodySizeChart(false)}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
                        >
                          বাতিল
                        </button>
                        <button
                          type="button"
                          onClick={handleSaveBodySizeChartDraft}
                          className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold cursor-pointer"
                        >
                          সাইজ চার্ট সেভ করুন
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {showBodySizeChart && (
                  <>
                    {sizeChartImage !== '' && (
                      <div className="rounded-xl border border-slate-200 bg-white p-2 overflow-hidden">
                        <LazyImage
                          src={sizeChartImage}
                          alt={sizeChartTitle}
                          wrapperClassName="relative w-full overflow-hidden flex justify-center"
                          skeletonClassName="min-h-[180px]"
                          className="max-h-96 w-auto mx-auto object-contain rounded-lg"
                        />
                      </div>
                    )}

                    {sizeChartRows.length > 0 && (
                      <div className="overflow-x-auto rounded-xl border border-indigo-200/80 bg-white shadow-2xs">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-indigo-50/90 border-b border-indigo-200/80 text-indigo-950 text-xs sm:text-sm font-extrabold">
                              <th className="py-3 px-4">{sizeChartHeaders[0] || 'সাইজ / বয়স'}</th>
                              <th className="py-3 px-4">{sizeChartHeaders[1] || 'বডি / চেস্ট (ইঞ্চি)'}</th>
                              <th className="py-3 px-4">{sizeChartHeaders[2] || 'লম্বা / দৈর্ঘ্য (ইঞ্চি)'}</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 text-xs sm:text-sm">
                            {sizeChartRows.map((row, rIdx) => (
                              <tr
                                key={row.id || rIdx}
                                className={rIdx % 2 === 0 ? 'bg-white' : 'bg-indigo-50/25'}
                              >
                                <td className="py-2.5 px-4 font-extrabold text-indigo-950">
                                  {row.size}
                                </td>
                                <td className="py-2.5 px-4 font-semibold text-slate-700">
                                  {row.chest}
                                </td>
                                <td className="py-2.5 px-4 font-semibold text-slate-700">
                                  {row.length}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </>
                )}
              </section>
            )}

            {/* BANNER 2: PROMOTIONAL BANNER / IMAGE SECTION RIGHT BEFORE VIDEO SECTION (ON/OFF + Direct Upload) */}
            {showPromoBanner2 && (
              promoBanner2Image ? (
                <section className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                  {promoBanner2Title && (
                    <div className="px-4 py-2.5 bg-teal-50/60 border-b border-teal-100 text-center">
                      <p className="text-sm sm:text-base font-extrabold text-teal-950">
                        {promoBanner2Title}
                      </p>
                    </div>
                  )}
                  <div
                    onClick={scrollToOrderForm}
                    role="button"
                    tabIndex={0}
                    onKeyDown={e => {
                      if (e.key === 'Enter' || e.key === ' ') scrollToOrderForm();
                    }}
                    className="relative w-full cursor-pointer group"
                  >
                    <LazyImage
                      src={promoBanner2Image}
                      alt={promoBanner2Title || product.nameBn}
                      wrapperClassName="relative w-full overflow-hidden"
                      skeletonClassName="min-h-[160px] sm:min-h-[240px]"
                      className="w-full h-auto max-h-[460px] object-cover block"
                    />
                    {(isAuthenticated || onBackToAdmin) && (
                      <div
                        onClick={e => e.stopPropagation()}
                        className="absolute top-2.5 right-2.5 flex items-center gap-1.5 bg-slate-900/80 backdrop-blur-xs px-2.5 py-1.5 rounded-xl border border-white/15 text-white text-xs"
                      >
                        <button
                          type="button"
                          onClick={() => promoBanner2FileInputRef.current?.click()}
                          className="font-bold text-teal-300 hover:text-teal-200 inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>ব্যানার ২ পরিবর্তন</span>
                        </button>
                        <span className="text-slate-500">|</span>
                        <button
                          type="button"
                          onClick={() => {
                            updateProduct(product.id, { landingPromoBanner2Enabled: false });
                            showToast('ব্যানার ২ বন্ধ (OFF) করা হয়েছে', 'info');
                          }}
                          className="font-bold text-rose-300 hover:text-rose-200 cursor-pointer"
                        >
                          OFF করুন
                        </button>
                      </div>
                    )}
                  </div>
                </section>
              ) : (isAuthenticated || onBackToAdmin) ? (
                <section className="bg-white rounded-2xl border-2 border-dashed border-teal-300 p-4 sm:p-5 text-center">
                  <div className="max-w-lg mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3 text-left">
                      <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 text-teal-700 flex items-center justify-center shrink-0">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">
                          ব্যানার ২ (ভিডিও সেকশনের উপরে / আগে) — ছবি আপলোড করুন (Admin Only Preview)
                        </h3>
                        <p className="text-[11px] text-slate-500">
                          ব্যানার ২ আপলোড করলে কাস্টমাররা ভিডিও সেকশনের ঠিক উপরে এই ব্যানার ছবিটি দেখতে পাবে (যেকোনো সময় ON/OFF করা যাবে)।
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => promoBanner2FileInputRef.current?.click()}
                        className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>ব্যানার ২ আপলোড করুন</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          updateProduct(product.id, { landingPromoBanner2Enabled: false });
                          showToast('ব্যানার ২ বন্ধ (OFF) করা হয়েছে', 'info');
                        }}
                        className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold cursor-pointer"
                      >
                        OFF
                      </button>
                    </div>
                  </div>
                </section>
              ) : null
            )}

            {/* SECTION 1.5: PRODUCT VIDEO / YOUTUBE / REELS SHOWCASE SECTION (ON/OFF + Supports YouTube, Shorts, FB Reels & MP4) */}
            {showVideoSection && (
              <section className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 sm:p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="space-y-1">
                    {videoSectionSubtitle !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-rose-50 text-rose-800 border border-rose-200 text-xs font-extrabold">
                        <Play className="w-3.5 h-3.5 text-rose-600 fill-rose-600 shrink-0" />
                        <span>{videoSectionSubtitle}</span>
                      </span>
                    )}
                    <h2 className="text-base sm:text-xl font-extrabold text-slate-900">
                      {videoSectionTitle}
                    </h2>
                  </div>
                </div>

                {/* Video Player Container */}
                {videoEmbedInfo.type === 'youtube' || videoEmbedInfo.type === 'facebook' ? (
                  <div
                    className={`w-full mx-auto rounded-2xl overflow-hidden border border-slate-200 bg-slate-950 shadow-xs ${
                      videoEmbedInfo.isReel
                        ? 'max-w-[340px] aspect-[9/16]'
                        : 'aspect-video max-w-3xl'
                    }`}
                  >
                    <iframe
                      src={videoEmbedInfo.embedUrl}
                      title={product.nameBn}
                      className="w-full h-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    />
                  </div>
                ) : videoEmbedInfo.type === 'direct_video' ? (
                  <div className="w-full max-w-3xl mx-auto rounded-2xl overflow-hidden border border-slate-200 bg-slate-950 shadow-xs">
                    <video
                      src={videoEmbedInfo.embedUrl}
                      controls
                      playsInline
                      className="w-full max-h-[520px] object-contain mx-auto"
                    />
                  </div>
                ) : (
                  /* Built-in Interactive Reel / Video Showcase when no external link is pasted yet */
                  <div className="w-full max-w-2xl mx-auto rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 text-white relative shadow-xs">
                    <div className="relative aspect-video sm:aspect-[16/9] w-full flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950">
                      {galleryImages.length > 0 ? (
                        <div
                          key={`reel_slide_${reelSlideIdx}`}
                          className={`w-full h-full flex items-center justify-center transition-transform duration-1000 ${
                            isReelPlaying ? 'scale-105' : 'scale-100'
                          }`}
                        >
                          <ProductThumbnail
                            eager
                            product={{
                              ...product,
                              image: galleryImages[reelSlideIdx % galleryImages.length] || galleryImages[0]
                            }}
                            imgClassName="p-3 sm:p-5"
                          />
                        </div>
                      ) : (
                        <ProductThumbnail eager product={{ ...product, image: '' }} imgClassName="p-6" />
                      )}

                      {/* Top Live Showcase Badge */}
                      <div className="absolute top-3 left-3 flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950/75 backdrop-blur-xs border border-white/15 text-[11px] font-bold">
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                        <span>LIVE PRODUCT REEL</span>
                      </div>

                      {/* Play / Pause Toggle Button */}
                      <button
                        type="button"
                        onClick={() => setIsReelPlaying(p => !p)}
                        className="absolute bottom-3 right-3 px-3.5 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 text-white border border-white/20 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer backdrop-blur-xs"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>{isReelPlaying ? 'পজ করুন' : 'প্লে করুন'}</span>
                      </button>

                      {/* Bottom Product Highlight Overlay */}
                      <div className="absolute bottom-3 left-3 right-28 bg-slate-950/75 backdrop-blur-xs border border-white/10 rounded-xl px-3 py-2 text-left">
                        <p className="text-xs sm:text-sm font-extrabold text-white truncate">
                          {product.nameBn}
                        </p>
                        <p className="text-[11px] text-emerald-300 font-bold">
                          অফার মূল্য: ৳{unitRetailPrice} · ক্যাশ অন ডেলিভারি
                        </p>
                      </div>
                    </div>

                    {/* Admin Quick Video Link Input (Only visible to logged-in Admin) */}
                    {(isAuthenticated || onBackToAdmin) && (
                      <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 text-xs">
                        <span className="text-slate-300 font-bold shrink-0">
                          YouTube / Shorts / FB Reels লিংক:
                        </span>
                        <input
                          type="text"
                          defaultValue={rawVideoUrl}
                          placeholder="এখানে YouTube, Shorts বা Facebook Reels ভিডিও লিংক পেস্ট করুন..."
                          onBlur={e => {
                            const val = e.target.value.trim();
                            if (val !== rawVideoUrl) {
                              updateProduct(product.id, { landingVideoUrl: val });
                              if (val) {
                                showToast('প্রোডাক্ট ভিডিও লিংক সেভ হয়েছে!', 'success');
                              }
                            }
                          }}
                          onKeyDown={e => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              const val = (e.target as HTMLInputElement).value.trim();
                              updateProduct(product.id, { landingVideoUrl: val });
                              showToast('প্রোডাক্ট ভিডিও লিংক সেভ হয়েছে!', 'success');
                            }
                          }}
                          className="flex-1 min-h-[34px] px-3 py-1 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs outline-hidden focus:border-emerald-500"
                        />
                      </div>
                    )}
                  </div>
                )}
              </section>
            )}

            {/* SECTION 2: SIMPLE, CLEAN, STANDARD PRODUCT DETAILS & FABRIC FEATURES (ON/OFF + Editable Texts & Topics) */}
            {showFeaturesSection &&
              (highlightPoints.length > 0 ||
                (showFeaturesBadge && featuresBadgeText !== '') ||
                (showFeaturesHeading && highlightsHeadingText !== '')) && (
                <section className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 sm:p-6 space-y-4">
                  {((showFeaturesBadge && featuresBadgeText !== '') ||
                    (showFeaturesHeading && highlightsHeadingText !== '')) && (
                    <div className="space-y-1.5 pb-3 border-b border-slate-100">
                      {showFeaturesBadge && featuresBadgeText !== '' && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-extrabold">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{featuresBadgeText}</span>
                        </span>
                      )}
                      {showFeaturesHeading && highlightsHeadingText !== '' && (
                        <h2 className="text-base sm:text-xl font-extrabold text-slate-900">
                          {highlightsHeadingText}
                        </h2>
                      )}
                    </div>
                  )}

                  {highlightPoints.length > 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {highlightPoints.map((pt, idx) => (
                        <div
                          key={idx}
                          className="p-3.5 rounded-xl bg-slate-50/90 border border-slate-200/80 flex items-start gap-2.5"
                        >
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <p className="text-sm sm:text-base font-semibold text-slate-800 leading-relaxed">
                            {pt}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </section>
              )}

            {/* SECTION 3: SIMPLE, CLEAN, STANDARD TRUST & GUARANTEE TOPICS (ON/OFF + Editable Heading & Topics) */}
            {showTrustSection && activeTrustItems.length > 0 && (
              <section className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 sm:p-6 space-y-4">
                {((showTrustBadge && trustBadgeText !== '') || trustHeadingText !== '') && (
                  <div className="space-y-1.5 pb-3 border-b border-slate-100">
                    {showTrustBadge && trustBadgeText !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-extrabold">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{trustBadgeText}</span>
                      </span>
                    )}
                    {trustHeadingText !== '' && (
                      <h2 className="text-base sm:text-xl font-extrabold text-slate-900">
                        {trustHeadingText}
                      </h2>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {activeTrustItems.map((item, idx) => (
                    <div
                      key={item.id || idx}
                      className="p-3.5 sm:p-4 rounded-xl bg-slate-50/90 border border-slate-200/80 flex items-start gap-3"
                    >
                      <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div className="space-y-0.5 min-w-0">
                        {item.title && (
                          <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                            {item.title}
                          </h3>
                        )}
                        {item.description && (
                          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                            {item.description}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* SECTION 4: CUSTOMER REVIEWS & SOCIAL PROOF (Slider & Grid Mode + Circular Reviewer Photo Upload on LP-1 & LP-2) */}
            {(reviewsEnabled || isAdminViewing) && (reviewScreenshots.length > 0 || reviewItems.length > 0 || isAdminViewing) && (
              <section
                onMouseEnter={() => setIsReviewSliderPaused(true)}
                onMouseLeave={() => setIsReviewSliderPaused(false)}
                className={`rounded-3xl border shadow-xs p-4 sm:p-7 space-y-5 transition-all ${
                  reviewsEnabled
                    ? 'bg-white border-amber-200/90'
                    : 'bg-slate-100/80 border-dashed border-slate-300 opacity-85'
                }`}
              >
                {/* Hidden File Inputs for Direct Admin Circular Avatar & Screenshot Uploads */}
                {isAdminViewing && (
                  <>
                    <input
                      ref={liveReviewerAvatarInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleReviewerAvatarFileChange}
                      className="hidden"
                    />
                    <input
                      ref={liveNewReviewerAvatarInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleLiveNewReviewerAvatarUpload}
                      className="hidden"
                    />
                    <input
                      ref={liveScreenshotUploadInputRef}
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleLiveScreenshotUpload}
                      className="hidden"
                    />
                  </>
                )}

                <div className="flex flex-wrap items-center gap-2 pb-2 border-b border-slate-100">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-50 text-amber-900 border border-amber-200 text-xs font-extrabold">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span>১০০% ভেরিফাইড কাস্টমার ফিডব্যাক</span>
                  </div>
                  {!reviewsEnabled && isAdminViewing && (
                    <span className="px-2.5 py-0.5 rounded-md bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold">
                      কাস্টমারদের জন্য এখন লুকানো (OFF) আছে
                    </span>
                  )}
                </div>

                {/* Admin Inline Control Bar for Reviews (Slider ON/OFF + Avatar & Review Manager) */}
                {isAdminViewing && (
                  <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200/90 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-xs font-extrabold text-amber-950">
                      <span>✨ অ্যাডমিন রিভিউ কন্ট্রোল:</span>
                      <span className="text-[11px] font-semibold text-amber-800">
                        (যেকোনো কাস্টমারের নামের পাশের গোল বৃত্তে ক্লিক করলেই তার ছবি আপলোড করতে পারবেন)
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          const next = !reviewsSliderEnabled;
                          updateProduct(product.id, { landingReviewsSliderEnabled: next });
                          showToast(
                            next
                              ? '🎠 কাস্টমার রিভিউ স্লাইডার ভিউ চালু (ON) করা হয়েছে!'
                              : '📋 কাস্টমার রিভিউ গ্রিড ভিউ সেট (OFF) করা হয়েছে!',
                            next ? 'success' : 'info'
                          );
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                          reviewsSliderEnabled
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        {reviewsSliderEnabled
                          ? '🎠 স্লাইডার ভিউ: ON (কম জায়গায় অনেক রিভিউ) ✓'
                          : '📋 গ্রিড ভিউ (স্লাইডার চালু করতে ক্লিক করুন)'}
                      </button>

                      <button
                        type="button"
                        onClick={() => setIsEditingLiveReviews(prev => !prev)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold transition-colors cursor-pointer shadow-2xs"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>
                          {isEditingLiveReviews
                            ? 'এডিটর বন্ধ করুন'
                            : '+ নতুন রিভিউ ও ক্রেতার ছবি যোগ/এডিট করুন'}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const next = !reviewsEnabled;
                          updateProduct(product.id, { landingReviewsEnabled: next });
                          showToast(
                            next
                              ? 'কাস্টমার রিভিউ সেকশন চালু (ON) করা হয়েছে'
                              : 'কাস্টমার রিভিউ সেকশন বন্ধ (OFF) করা হয়েছে',
                            'info'
                          );
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-colors cursor-pointer ${
                          reviewsEnabled
                            ? 'bg-white text-emerald-800 border-emerald-300 hover:bg-emerald-50'
                            : 'bg-rose-600 text-white border-rose-600'
                        }`}
                      >
                        {reviewsEnabled ? 'রিভিউ সেকশন: ON' : 'রিভিউ সেকশন: OFF'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Inline Admin Review & Reviewer Circular Photo Manager */}
                {isAdminViewing && isEditingLiveReviews && (
                  <div className="p-4 rounded-2xl bg-slate-50 border-2 border-amber-300 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-200">
                      <div>
                        <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">
                          📝 কাস্টমার রিভিউ ও প্রোফাইল ছবি ম্যানেজার ({reviewItems.length}টি লিখিত রিভিউ)
                        </h3>
                        <p className="text-[11px] text-slate-600">
                          এখানে ক্রেতার নামের প্রথম অক্ষরের গোল জায়গায় ক্রেতার আসল ছবি আপলোড করতে পারবেন এবং যত খুশি রিভিউ যোগ করতে পারবেন।
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => liveScreenshotUploadInputRef.current?.click()}
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>রিভিউ স্ক্রিনশট ছবি আপলোড</span>
                      </button>
                    </div>

                    {/* Add New Review with Circular Avatar Photo */}
                    <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                      <span className="text-xs font-extrabold text-emerald-900 block">
                        + নতুন কাস্টমার রিভিউ যোগ করুন (গোল প্রোফাইল ছবিসহ):
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                        {/* Circular Photo Upload for New Review */}
                        <div className="sm:col-span-3 flex items-center gap-2.5">
                          <div className="relative shrink-0">
                            {liveNewRevAvatar ? (
                              <img
                                src={liveNewRevAvatar}
                                alt="Preview"
                                className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500 shadow-2xs"
                              />
                            ) : (
                              <div className="w-11 h-11 rounded-full bg-emerald-700 text-white font-extrabold text-sm flex items-center justify-center">
                                {(liveNewRevName.trim() || 'ক').slice(0, 1)}
                              </div>
                            )}
                            {liveNewRevAvatar && (
                              <button
                                type="button"
                                onClick={() => setLiveNewRevAvatar('')}
                                className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                title="ছবি মুছুন"
                              >
                                ×
                              </button>
                            )}
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">
                              ক্রেতার ছবি (ঐচ্ছিক)
                            </label>
                            <button
                              type="button"
                              disabled={isUploadingReviewAvatar}
                              onClick={() => liveNewReviewerAvatarInputRef.current?.click()}
                              className="px-2.5 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-extrabold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Upload className="w-3 h-3" />
                              <span>{liveNewRevAvatar ? 'ছবি পরিবর্তন' : '📷 ছবি দিন'}</span>
                            </button>
                          </div>
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            ক্রেতার নাম *
                          </label>
                          <input
                            type="text"
                            value={liveNewRevName}
                            onChange={e => setLiveNewRevName(e.target.value)}
                            placeholder="যেমন: নুসরাত জাহান"
                            className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-900"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            ঠিকানা / পরিচয়
                          </label>
                          <input
                            type="text"
                            value={liveNewRevLocation}
                            onChange={e => setLiveNewRevLocation(e.target.value)}
                            placeholder="ধানমন্ডি, ঢাকা"
                            className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-900"
                          />
                        </div>

                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            রিভিউ কমেন্ট *
                          </label>
                          <input
                            type="text"
                            value={liveNewRevComment}
                            onChange={e => setLiveNewRevComment(e.target.value)}
                            placeholder="প্রোডাক্টের মান খুবই চমৎকার..."
                            className="w-full min-h-[36px] px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-900"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <button
                            type="button"
                            onClick={handleLiveAddReview}
                            className="w-full min-h-[36px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold cursor-pointer"
                          >
                            + রিভিউ যোগ করুন
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Existing Reviews Quick Avatar & Text List */}
                    <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                      {reviewItems.map((rev, idx) => (
                        <div
                          key={rev.id || idx}
                          className="p-2.5 rounded-xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                        >
                          <div className="flex items-center gap-3 min-w-0 flex-1">
                            <div className="relative shrink-0">
                              {rev.avatarUrl ? (
                                <img
                                  src={rev.avatarUrl}
                                  alt={rev.customerName}
                                  className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500"
                                />
                              ) : (
                                <div className="w-10 h-10 rounded-full bg-emerald-700 text-white font-extrabold text-sm flex items-center justify-center">
                                  {(rev.customerName || 'ক').trim().slice(0, 1)}
                                </div>
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="text-xs font-extrabold text-slate-900">
                                  {rev.customerName}
                                </span>
                                {rev.location && (
                                  <span className="text-[11px] font-semibold text-slate-500">
                                    · {rev.location}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-700 truncate">{rev.comment}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => handleTriggerReviewerAvatarUpload(idx)}
                              className="px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-extrabold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Upload className="w-3 h-3" />
                              <span>{rev.avatarUrl ? 'ছবি পরিবর্তন' : '📷 ছবি দিন'}</span>
                            </button>
                            {rev.avatarUrl && (
                              <button
                                type="button"
                                onClick={() => handleRemoveReviewerAvatar(idx)}
                                className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold cursor-pointer"
                                title="ছবি সরিয়ে নামের প্রথম অক্ষর রাখুন"
                              >
                                ছবি মুছুন
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                const nextList = reviewItems.filter((_, i) => i !== idx);
                                updateProduct(product.id, { landingReviewItems: nextList });
                                showToast('রিভিউ মুছে ফেলা হয়েছে', 'info');
                              }}
                              className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer"
                              title="রিভিউ ডিলিট করুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Uploaded Review Screenshots: Slider Mode vs Grid Mode */}
                {reviewScreenshots.length > 0 && (
                  reviewsSliderEnabled && reviewScreenshots.length > 1 ? (
                    <div className="space-y-3">
                      <div
                        className="relative overflow-hidden rounded-2xl select-none cursor-grab active:cursor-grabbing touch-pan-y"
                        onTouchStart={e => {
                          shotTouchEndXRef.current = null;
                          shotTouchStartXRef.current = e.targetTouches[0]?.clientX ?? null;
                          setIsReviewSliderPaused(true);
                        }}
                        onTouchMove={e => {
                          shotTouchEndXRef.current = e.targetTouches[0]?.clientX ?? null;
                        }}
                        onTouchEnd={() => {
                          if (
                            shotTouchStartXRef.current !== null &&
                            shotTouchEndXRef.current !== null
                          ) {
                            const dist = shotTouchStartXRef.current - shotTouchEndXRef.current;
                            if (Math.abs(dist) > 28) {
                              if (dist > 0) {
                                setActiveScreenshotSlide(
                                  prev => (prev + 1) % reviewScreenshots.length
                                );
                              } else {
                                setActiveScreenshotSlide(
                                  prev =>
                                    (prev - 1 + reviewScreenshots.length) %
                                    reviewScreenshots.length
                                );
                              }
                            }
                          }
                          shotTouchStartXRef.current = null;
                          shotTouchEndXRef.current = null;
                          setIsReviewSliderPaused(false);
                        }}
                        onMouseDown={e => {
                          shotMouseStartXRef.current = e.clientX;
                          setIsReviewSliderPaused(true);
                        }}
                        onMouseUp={e => {
                          if (shotMouseStartXRef.current !== null) {
                            const dist = shotMouseStartXRef.current - e.clientX;
                            if (Math.abs(dist) > 30) {
                              if (dist > 0) {
                                setActiveScreenshotSlide(
                                  prev => (prev + 1) % reviewScreenshots.length
                                );
                              } else {
                                setActiveScreenshotSlide(
                                  prev =>
                                    (prev - 1 + reviewScreenshots.length) %
                                    reviewScreenshots.length
                                );
                              }
                            }
                          }
                          shotMouseStartXRef.current = null;
                          setIsReviewSliderPaused(false);
                        }}
                        onMouseLeave={() => {
                          shotMouseStartXRef.current = null;
                          setIsReviewSliderPaused(false);
                        }}
                      >
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                          {Array.from({
                            length: Math.min(3, reviewScreenshots.length)
                          }).map((_, offset) => {
                            const shotIdx =
                              (safeScreenshotSlide + offset) % reviewScreenshots.length;
                            const imgUrl = reviewScreenshots[shotIdx];
                            return (
                              <div
                                key={`shot_${shotIdx}_${offset}`}
                                className={`${
                                  offset === 0
                                    ? 'block'
                                    : offset === 1
                                    ? 'hidden sm:block'
                                    : 'hidden md:block'
                                } relative rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden shadow-2xs transition-all duration-300`}
                              >
                                <LazyImage
                                  src={imgUrl}
                                  alt={`Customer Review ${shotIdx + 1}`}
                                  wrapperClassName="relative w-full overflow-hidden flex justify-center"
                                  skeletonClassName="min-h-[180px]"
                                  className="w-full h-auto max-h-80 object-contain mx-auto"
                                />
                                {isAdminViewing && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const nextShots = reviewScreenshots.filter(
                                        (_, i) => i !== shotIdx
                                      );
                                      updateProduct(product.id, {
                                        landingReviewImages: nextShots
                                      });
                                      showToast('স্ক্রিনশট মুছে ফেলা হয়েছে', 'info');
                                    }}
                                    className="absolute top-2 right-2 w-7 h-7 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs font-bold shadow-md cursor-pointer"
                                    title="স্ক্রিনশট মুছুন"
                                  >
                                    ×
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Screenshot Slider Dots */}
                      <div className="flex items-center justify-center gap-1.5">
                        {reviewScreenshots.map((_, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setActiveScreenshotSlide(idx)}
                            className={`h-2 rounded-full transition-all cursor-pointer ${
                              safeScreenshotSlide === idx
                                ? 'w-6 bg-amber-500'
                                : 'w-2 bg-slate-300 hover:bg-slate-400'
                            }`}
                            aria-label={`Screenshot slide ${idx + 1}`}
                          />
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                      {reviewScreenshots.map((imgUrl, idx) => (
                        <div
                          key={idx}
                          className="relative rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden shadow-2xs"
                        >
                          <LazyImage
                            src={imgUrl}
                            alt={`Customer Review ${idx + 1}`}
                            wrapperClassName="relative w-full overflow-hidden flex justify-center"
                            skeletonClassName="min-h-[180px]"
                            className="w-full h-auto max-h-96 object-contain mx-auto"
                          />
                          {isAdminViewing && (
                            <button
                              type="button"
                              onClick={() => {
                                const nextShots = reviewScreenshots.filter((_, i) => i !== idx);
                                updateProduct(product.id, { landingReviewImages: nextShots });
                                showToast('স্ক্রিনশট মুছে ফেলা হয়েছে', 'info');
                              }}
                              className="absolute top-2 right-2 w-7 h-7 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs font-bold shadow-md cursor-pointer"
                              title="স্ক্রিনশট মুছুন"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )
                )}

                {/* Written Customer Reviews: Compact Smooth Slider Mode vs Grid Mode */}
                {reviewItems.length > 0 && (
                  reviewsSliderEnabled ? (
                    <div className="space-y-3">
                      <div
                        className="relative select-none cursor-grab active:cursor-grabbing touch-pan-y"
                        onTouchStart={e => {
                          revTouchEndXRef.current = null;
                          revTouchStartXRef.current = e.targetTouches[0]?.clientX ?? null;
                          setIsReviewSliderPaused(true);
                        }}
                        onTouchMove={e => {
                          revTouchEndXRef.current = e.targetTouches[0]?.clientX ?? null;
                        }}
                        onTouchEnd={() => {
                          if (
                            revTouchStartXRef.current !== null &&
                            revTouchEndXRef.current !== null
                          ) {
                            const dist = revTouchStartXRef.current - revTouchEndXRef.current;
                            if (Math.abs(dist) > 25) {
                              if (dist > 0) {
                                handleNextReviewSlide();
                              } else {
                                handlePrevReviewSlide();
                              }
                            }
                          }
                          revTouchStartXRef.current = null;
                          revTouchEndXRef.current = null;
                          setIsReviewSliderPaused(false);
                        }}
                        onMouseDown={e => {
                          revMouseStartXRef.current = e.clientX;
                          setIsReviewSliderPaused(true);
                        }}
                        onMouseUp={e => {
                          if (revMouseStartXRef.current !== null) {
                            const dist = revMouseStartXRef.current - e.clientX;
                            if (Math.abs(dist) > 30) {
                              if (dist > 0) {
                                handleNextReviewSlide();
                              } else {
                                handlePrevReviewSlide();
                              }
                            }
                          }
                          revMouseStartXRef.current = null;
                          setIsReviewSliderPaused(false);
                        }}
                        onMouseLeave={() => {
                          revMouseStartXRef.current = null;
                          setIsReviewSliderPaused(false);
                        }}
                      >
                        {/* Responsive 1-Card (Mobile) / 2-Card (Tablet) / 3-Card (Desktop) Single-Row Carousel */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {Array.from({
                            length: Math.min(3, reviewItems.length)
                          }).map((_, offset) => {
                            const revIdx = (safeReviewSlide + offset) % reviewItems.length;
                            const rev = reviewItems[revIdx];
                            return (
                              <div
                                key={`${rev.id || revIdx}_slide_${offset}`}
                                className={`${
                                  offset === 0 ? 'flex' : 'hidden md:flex'
                                } p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-amber-50/35 via-white to-slate-50/80 border border-amber-200/80 flex-col justify-between gap-4 shadow-2xs transition-all duration-300`}
                              >
                                <div className="space-y-2.5">
                                  <div className="flex items-center justify-between gap-2">
                                    <div className="flex items-center gap-0.5 text-amber-400">
                                      {[1, 2, 3, 4, 5].map(s => (
                                        <Star
                                          key={s}
                                          className="w-3.5 h-3.5 fill-amber-400 text-amber-400"
                                        />
                                      ))}
                                    </div>
                                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-extrabold">
                                      ✓ ভেরিফাইড ক্রেতা
                                    </span>
                                  </div>
                                  <p className="text-sm sm:text-base text-slate-800 font-medium leading-relaxed">
                                    &ldquo;{rev.comment}&rdquo;
                                  </p>
                                </div>

                                <div className="pt-3 border-t border-slate-200/70 flex items-center justify-between gap-2.5">
                                  <div className="flex items-center gap-3 min-w-0">
                                    {/* Circular Reviewer Profile Photo OR First-Letter Circle (Clickable by Admin to Upload Photo) */}
                                    <div className="relative shrink-0 group">
                                      {rev.avatarUrl ? (
                                        <img
                                          src={rev.avatarUrl}
                                          alt={rev.customerName}
                                          loading="lazy"
                                          decoding="async"
                                          onClick={() => {
                                            if (isAdminViewing) {
                                              handleTriggerReviewerAvatarUpload(revIdx);
                                            }
                                          }}
                                          className={`w-11 h-11 rounded-full object-cover border-2 border-emerald-500/50 shadow-2xs ${
                                            isAdminViewing ? 'cursor-pointer hover:opacity-90' : ''
                                          }`}
                                          title={
                                            isAdminViewing
                                              ? 'ক্লিক করে এই ক্রেতার গোল ছবি পরিবর্তন করুন'
                                              : rev.customerName
                                          }
                                        />
                                      ) : (
                                        <div
                                          onClick={() => {
                                            if (isAdminViewing) {
                                              handleTriggerReviewerAvatarUpload(revIdx);
                                            }
                                          }}
                                          className={`w-11 h-11 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 text-white font-extrabold text-base flex items-center justify-center shrink-0 shadow-2xs ${
                                            isAdminViewing
                                              ? 'cursor-pointer ring-2 ring-amber-400/70 hover:from-emerald-700 hover:to-teal-800'
                                              : ''
                                          }`}
                                          title={
                                            isAdminViewing
                                              ? 'এখানে ক্লিক করে নামের প্রথম অক্ষরের বদলে ক্রেতার ছবি আপলোড করুন'
                                              : rev.customerName
                                          }
                                        >
                                          {(rev.customerName || 'ক').trim().slice(0, 1)}
                                        </div>
                                      )}

                                      {/* Admin Camera Badge on Circular Avatar */}
                                      {isAdminViewing && (
                                        <button
                                          type="button"
                                          onClick={e => {
                                            e.stopPropagation();
                                            handleTriggerReviewerAvatarUpload(revIdx);
                                          }}
                                          className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 hover:bg-amber-600 text-white border border-white flex items-center justify-center shadow-xs cursor-pointer"
                                          title="এই গোল বৃত্তে ক্রেতার ছবি আপলোড করুন"
                                        >
                                          <Upload className="w-2.5 h-2.5" />
                                        </button>
                                      )}

                                      {isAdminViewing && rev.avatarUrl && (
                                        <button
                                          type="button"
                                          onClick={e => {
                                            e.stopPropagation();
                                            handleRemoveReviewerAvatar(revIdx);
                                          }}
                                          className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-[10px] leading-none flex items-center justify-center shadow-xs cursor-pointer"
                                          title="ছবি সরিয়ে প্রথম অক্ষর দেখান"
                                        >
                                          ×
                                        </button>
                                      )}
                                    </div>

                                    <div className="min-w-0">
                                      <p className="text-sm font-extrabold text-slate-900 truncate">
                                        {rev.customerName}
                                      </p>
                                      {rev.location && (
                                        <p className="text-xs text-slate-500 font-medium truncate">
                                          {rev.location}
                                        </p>
                                      )}
                                    </div>
                                  </div>

                                  {isAdminViewing && (
                                    <button
                                      type="button"
                                      onClick={() => handleTriggerReviewerAvatarUpload(revIdx)}
                                      className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-extrabold shrink-0 cursor-pointer"
                                    >
                                      {rev.avatarUrl ? '📷 ছবি বদলান' : '📷 ছবি দিন'}
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Minimal Pagination Dots Only (No Prev/Next Buttons) */}
                      {reviewItems.length > 1 && (
                        <div className="flex items-center justify-center gap-1.5 pt-0.5">
                          {reviewItems.map((rev, idx) => (
                            <button
                              key={rev.id || idx}
                              type="button"
                              onClick={() => setActiveReviewSlide(idx)}
                              className={`h-2 rounded-full transition-all cursor-pointer ${
                                safeReviewSlide === idx
                                  ? 'w-6 bg-amber-500'
                                  : 'w-2 bg-slate-300 hover:bg-amber-300'
                              }`}
                              aria-label={`Go to review ${idx + 1}`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    /* Classic Grid Mode (when Slider is turned OFF) */
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {reviewItems.map((rev, idx) => (
                        <div
                          key={rev.id || idx}
                          className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-slate-50/90 to-white border border-slate-200/90 flex flex-col justify-between gap-4 shadow-2xs"
                        >
                          <div className="space-y-2.5">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-0.5 text-amber-400">
                                {[1, 2, 3, 4, 5].map(s => (
                                  <Star
                                    key={s}
                                    className="w-3.5 h-3.5 fill-amber-400 text-amber-400"
                                  />
                                ))}
                              </div>
                              <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-extrabold">
                                ✓ ভেরিফাইড ক্রেতা
                              </span>
                            </div>
                            <p className="text-sm sm:text-base text-slate-800 font-medium leading-relaxed">
                              &ldquo;{rev.comment}&rdquo;
                            </p>
                          </div>

                          <div className="pt-3 border-t border-slate-200/70 flex items-center justify-between gap-2.5">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="relative shrink-0">
                                {rev.avatarUrl ? (
                                  <img
                                    src={rev.avatarUrl}
                                    alt={rev.customerName}
                                    loading="lazy"
                                    decoding="async"
                                    onClick={() => {
                                      if (isAdminViewing) {
                                        handleTriggerReviewerAvatarUpload(idx);
                                      }
                                    }}
                                    className={`w-11 h-11 rounded-full object-cover border-2 border-emerald-500/50 shadow-2xs ${
                                      isAdminViewing ? 'cursor-pointer hover:opacity-90' : ''
                                    }`}
                                  />
                                ) : (
                                  <div
                                    onClick={() => {
                                      if (isAdminViewing) {
                                        handleTriggerReviewerAvatarUpload(idx);
                                      }
                                    }}
                                    className={`w-11 h-11 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 text-white font-extrabold text-base flex items-center justify-center shrink-0 ${
                                      isAdminViewing ? 'cursor-pointer ring-2 ring-amber-400/70' : ''
                                    }`}
                                  >
                                    {(rev.customerName || 'ক').trim().slice(0, 1)}
                                  </div>
                                )}

                                {isAdminViewing && (
                                  <button
                                    type="button"
                                    onClick={e => {
                                      e.stopPropagation();
                                      handleTriggerReviewerAvatarUpload(idx);
                                    }}
                                    className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 hover:bg-amber-600 text-white border border-white flex items-center justify-center shadow-xs cursor-pointer"
                                    title="এই গোল বৃত্তে ক্রেতার ছবি আপলোড করুন"
                                  >
                                    <Upload className="w-2.5 h-2.5" />
                                  </button>
                                )}

                                {isAdminViewing && rev.avatarUrl && (
                                  <button
                                    type="button"
                                    onClick={e => {
                                      e.stopPropagation();
                                      handleRemoveReviewerAvatar(idx);
                                    }}
                                    className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-[10px] leading-none flex items-center justify-center shadow-xs cursor-pointer"
                                    title="ছবি সরিয়ে প্রথম অক্ষর দেখান"
                                  >
                                    ×
                                  </button>
                                )}
                              </div>

                              <div className="min-w-0">
                                <p className="text-sm font-extrabold text-slate-900 truncate">
                                  {rev.customerName}
                                </p>
                                {rev.location && (
                                  <p className="text-xs text-slate-500 font-medium truncate">
                                    {rev.location}
                                  </p>
                                )}
                              </div>
                            </div>

                            {isAdminViewing && (
                              <button
                                type="button"
                                onClick={() => handleTriggerReviewerAvatarUpload(idx)}
                                className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-extrabold shrink-0 cursor-pointer"
                              >
                                {rev.avatarUrl ? '📷 ছবি বদলান' : '📷 ছবি দিন'}
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                )}
              </section>
            )}

            {/* SECTION 5: EMBEDDED ONE-PAGE DIRECT ORDER FORM */}
            <section
              id="landing-direct-order-section"
              className="bg-white rounded-3xl border-2 border-emerald-600/80 shadow-md overflow-hidden scroll-mt-16"
            >
              {/* Order Form Header Banner */}
              <div
                className={`${
                  isLandingWinterTheme
                    ? 'bg-gradient-to-r from-[#082f49] via-[#0369a1] to-[#1e3a8a]'
                    : 'bg-gradient-to-r from-[#064E3B] via-[#047857] to-[#065F46]'
                } text-white px-4 sm:px-7 py-4 sm:py-6 text-center`}
              >
                <div className="space-y-1">
                  <h2 className="text-lg sm:text-2xl font-extrabold tracking-tight">
                    অর্ডার করতে নিচের ফর্মটি পূরণ করুন
                  </h2>
                  <p className="text-xs sm:text-sm text-emerald-100 font-medium">
                    অগ্রিম কোনো টাকা দিতে হবে না — পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধ করুন (Cash on Delivery)
                  </p>
                </div>
              </div>

              <form onSubmit={handleConfirmOrder} className="p-4 sm:p-7 space-y-6">
                {/* ============================================================================ */}
                {/* LANDING PAGE 2 ONLY: STEP 1 (PRODUCT SELECT) + STEP 2 (SIZE SELECT) + SUMMARY BAR */}
                {/* ============================================================================ */}
                {isTemplate2 && showcaseEntries.length > 0 && (
                  <div className="space-y-6 pb-2 border-b border-slate-200">
                    {/* STEP 1: ১ পছন্দের ড্রেসটি নির্বাচন করুন */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <span className="w-7 h-7 rounded-full bg-[#dc2626] text-white font-extrabold text-sm flex items-center justify-center shrink-0 shadow-xs">
                            ১
                          </span>
                          <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                            পছন্দের ড্রেসটি নির্বাচন করুন
                          </h3>
                        </div>
                        <span className="px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-extrabold text-slate-700 shrink-0">
                          {showcaseEntries.length}টি ড্রেস
                        </span>
                      </div>

                      {/* Vertical list of selectable full-width product cards (Mobile-First < 640px clean fit) */}
                      <div className="space-y-2.5">
                        {showcaseEntries.map(entry => {
                          const itemProd = entry.product;
                          const isSelected = checkoutTargetProduct.id === itemProd.id;
                          const firstVar =
                            itemProd.variants?.find(v => !v.outOfStock) ||
                            itemProd.variants?.[0];
                          const rowSalePrice = isSelected
                            ? unitRetailPrice
                            : firstVar
                            ? firstVar.retailPrice
                            : itemProd.retailPrice;
                          const rawRowReg = isSelected
                            ? unitRegularPrice
                            : firstVar?.regularPrice ?? itemProd.regularPrice ?? rowSalePrice;
                          const rowRegPrice =
                            rawRowReg > rowSalePrice
                              ? rawRowReg
                              : Math.round(rowSalePrice * 1.3);
                          const oneLineDesc =
                            (itemProd.shortDescription || '').trim() ||
                            (itemProd.landingShortDescription || '').trim() ||
                            `${entry.colorTag} • ১০০% কোয়ালিটি গ্যারান্টি`;

                          return (
                            <div
                              key={itemProd.id}
                              onClick={() => {
                                if (checkoutTargetProduct.id !== itemProd.id) {
                                  setSelectedShowcaseProductId(itemProd.id);
                                  const nextVar =
                                    itemProd.variants?.find(v => !v.outOfStock) ||
                                    itemProd.variants?.[0];
                                  setSelectedVariantId(nextVar?.id || '');
                                  triggerLandingAddToCart(nextVar, quantity);
                                }
                              }}
                              className={`w-full rounded-2xl border-2 p-2.5 sm:p-3.5 transition-all cursor-pointer flex items-center gap-2.5 sm:gap-3.5 ${
                                isSelected
                                  ? 'border-[#dc2626] bg-rose-50/35 shadow-xs'
                                  : 'border-slate-200 bg-white hover:border-slate-300'
                              }`}
                            >
                              {/* Radio Button on the Left */}
                              <div
                                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                                  isSelected
                                    ? 'border-[#dc2626] bg-[#dc2626]'
                                    : 'border-slate-300 bg-white'
                                }`}
                              >
                                {isSelected && (
                                  <span className="w-2 h-2 rounded-full bg-white" />
                                )}
                              </div>

                              {/* Square Thumbnail Image */}
                              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0">
                                {(isSelected && activeVariant?.imageUrl) || itemProd.image ? (
                                  <img
                                    src={(isSelected && activeVariant?.imageUrl) || itemProd.image}
                                    alt={itemProd.nameBn}
                                    loading="lazy"
                                    className="w-full h-full object-cover object-top"
                                  />
                                ) : (
                                  <ProductThumbnail
                                    product={itemProd}
                                    className="w-full h-full"
                                    imgClassName="object-cover"
                                  />
                                )}
                              </div>

                              {/* Middle Info: Red Badge + Fabric Subtitle, Bold Title, 1-line Description */}
                              <div className="min-w-0 flex-1 space-y-0.5">
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-[#dc2626] text-white text-[10px] sm:text-[11px] font-extrabold leading-tight shrink-0">
                                    {entry.badgeText}
                                  </span>
                                  <span className="text-[11px] sm:text-xs font-bold text-slate-500 truncate">
                                    {entry.fabricSubtitle}
                                  </span>
                                </div>
                                <p className="text-xs sm:text-base font-extrabold text-slate-900 truncate">
                                  {itemProd.nameBn}
                                </p>
                                <p className="text-[11px] sm:text-xs text-slate-500 truncate">
                                  {oneLineDesc}
                                </p>
                              </div>

                              {/* Right Column: Regular & Sale Price */}
                              <div className="text-right shrink-0 pl-1">
                                {rowRegPrice > rowSalePrice && (
                                  <span className="block text-[11px] sm:text-xs font-bold text-slate-400 line-through tabular-nums">
                                    ৳{rowRegPrice.toLocaleString('en-IN')}
                                  </span>
                                )}
                                <span className="text-sm sm:text-lg font-black text-[#dc2626] tabular-nums">
                                  ৳{rowSalePrice.toLocaleString('en-IN')}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* STEP 2: ২ আপনার সাইজ নির্বাচন করুন */}
                    <div className="space-y-3">
                      {/* Admin Inline Quick Design Bar inside Step 2 (Visible only to Admin) */}
                      {isAdminViewing && (
                        <div className="p-2.5 rounded-xl bg-slate-900 text-white border border-slate-700 shadow-xs space-y-2">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="text-[11px] font-extrabold text-emerald-300 flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <span>অ্যাডমিন ভ্যারিয়েশন ডিজাইন সুইচার (মোবাইল রেসপনসিভ):</span>
                            </span>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  const next = !showVariantMeasurement;
                                  updateProduct(product.id, { landingVariantShowMeasurement: next });
                                  updateBusiness({ landingVariantShowMeasurement: next });
                                  showToast(
                                    next
                                      ? 'ভ্যারিয়েশন বাটনে সাইজ মাপ (বুক/লম্বা) দেখানো চালু (ON) হয়েছে'
                                      : 'ভ্যারিয়েশন বাটনে সাইজ মাপ (বুক/লম্বা) বন্ধ (OFF) হয়েছে',
                                    next ? 'success' : 'info'
                                  );
                                }}
                                className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border transition-all cursor-pointer ${
                                  showVariantMeasurement
                                    ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60'
                                    : 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700'
                                }`}
                                title="ভ্যারিয়েশন / সাইজ বাটনের ভেতর সাইজ গাইডের মাপ (বুক/লম্বা) দেখানো ON / OFF করুন"
                              >
                                বাটনে মাপ: {showVariantMeasurement ? 'ON ✓' : 'OFF'}
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  const next = !showVariantPrice;
                                  updateProduct(product.id, { landingVariantShowPrice: next });
                                  updateBusiness({ landingVariantShowPrice: next });
                                  showToast(
                                    next
                                      ? 'ভ্যারিয়েশন বাটনে প্রাইস দেখানো চালু (ON) হয়েছে'
                                      : 'ভ্যারিয়েশন বাটনে প্রাইস বন্ধ (OFF) হয়েছে',
                                    next ? 'success' : 'info'
                                  );
                                }}
                                className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border transition-all cursor-pointer ${
                                  showVariantPrice
                                    ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60'
                                    : 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700'
                                }`}
                                title="ভ্যারিয়েশন / সাইজ বাটনের ভেতর প্রাইস দেখানো ON / OFF করুন"
                              >
                                বাটনে প্রাইস: {showVariantPrice ? 'ON ✓' : 'OFF'}
                              </button>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                            {LANDING_VARIANT_DESIGN_OPTIONS.map(opt => {
                              const isCurrent = variantStyle === opt.id;
                              return (
                                <button
                                  key={opt.id}
                                  type="button"
                                  onClick={() => {
                                    updateProduct(product.id, { landingVariantStyle: opt.id });
                                    showToast(`"${opt.label}" অ্যাক্টিভ করা হয়েছে!`, 'success');
                                  }}
                                  className={`px-2 py-1.5 rounded-lg text-[11px] font-bold text-left truncate border transition-all cursor-pointer ${
                                    isCurrent
                                      ? 'bg-emerald-600 text-white border-emerald-400 shadow-2xs'
                                      : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
                                  }`}
                                  title={opt.desc}
                                >
                                  {opt.shortLabel}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <span className="w-7 h-7 rounded-full bg-[#dc2626] text-white font-extrabold text-sm flex items-center justify-center shrink-0 shadow-xs">
                            ২
                          </span>
                          <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                            আপনার সাইজ নির্বাচন করুন
                          </h3>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowSizeChartModal(true)}
                          className="inline-flex items-center gap-1 text-xs sm:text-sm font-extrabold text-[#dc2626] hover:underline cursor-pointer shrink-0"
                        >
                          <Ruler className="w-3.5 h-3.5" />
                          <span>সাইজ পরিমাপ চার্ট</span>
                        </button>
                      </div>

                      {checkoutTargetProduct.variants &&
                      checkoutTargetProduct.variants.length > 0 ? (
                        <>
                          {/* Dual Variation Mode inside Step 2: Color Selector Row */}
                          {hasLpDualVariants(checkoutTargetProduct) && (
                            <div className="p-3 rounded-xl bg-rose-50/55 border border-rose-200/80 space-y-2 mb-2.5">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-xs sm:text-sm font-extrabold text-rose-950">
                                  🎨 পছন্দের কালার (Color) নির্বাচন করুন:
                                </span>
                                {activeVariant && (
                                  <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-extrabold">
                                    ✓ {activeVariant.label}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {getLpColorVariants(checkoutTargetProduct).map(cVar => {
                                  const isColorOut = Boolean(cVar.outOfStock);
                                  const isColorSelected = !isColorOut && selectedColorId === cVar.id;
                                  return (
                                    <button
                                      key={cVar.id}
                                      type="button"
                                      onClick={() => handleSelectVariant(cVar)}
                                      className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer border-2 inline-flex items-center gap-1.5 ${
                                        isColorOut
                                          ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-75'
                                          : isColorSelected
                                          ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                                          : 'bg-white text-slate-800 border-rose-200 hover:border-rose-500'
                                      }`}
                                    >
                                      {cVar.imageUrl ? (
                                        <img
                                          src={cVar.imageUrl}
                                          alt={cVar.label}
                                          className="w-5 h-5 rounded-md object-cover border border-white/60 shrink-0"
                                        />
                                      ) : (
                                        isColorSelected &&
                                        !isColorOut && (
                                          <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                                        )
                                      )}
                                      <span>{cVar.label}</span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* DESIGN 9 (LP-2 Default): Red Measurement Grid (4 cols desktop, 2x2 mobile) */}
                          {variantStyle === 'lp2_red_measurement_grid' && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarSelected = activeVariant?.id === variant.id;
                                const isVarOut = Boolean(variant.outOfStock);
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);

                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    disabled={isVarOut}
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`relative rounded-xl border-2 p-3 text-left transition-all cursor-pointer flex flex-col justify-between ${
                                      showVariantMeasurement ? 'min-h-[72px]' : 'min-h-[54px]'
                                    } ${
                                      isVarOut
                                        ? 'border-slate-200 bg-slate-100 opacity-50 cursor-not-allowed'
                                        : isVarSelected
                                        ? 'border-[#dc2626] bg-rose-50/40 shadow-xs'
                                        : 'border-slate-200 bg-white hover:border-slate-300'
                                    }`}
                                  >
                                    {isVarSelected && !isVarOut && (
                                      <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#dc2626] text-white flex items-center justify-center shadow-2xs">
                                        <Check className="w-3 h-3 stroke-[3]" />
                                      </span>
                                    )}
                                    <span
                                      className={`text-sm sm:text-base font-extrabold pr-6 ${
                                        isVarSelected ? 'text-[#dc2626]' : 'text-slate-900'
                                      }`}
                                    >
                                      {variant.label}
                                    </span>
                                    {(isVarOut || showVariantMeasurement) && (
                                      <span className="text-[11px] sm:text-xs font-medium text-slate-500 mt-1">
                                        {isVarOut ? 'স্টক আউট' : measurementSubtext}
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <span className="text-xs font-extrabold font-mono text-[#dc2626] mt-0.5">
                                        {formatCurrency(vPrice)}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 1: Classic Radio List */}
                          {variantStyle === 'classic_radio_list' && (
                            <div className="grid grid-cols-1 gap-2">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`w-full p-3 rounded-xl border-2 text-left flex items-center justify-between gap-2.5 transition-all cursor-pointer ${
                                      isVarOut
                                        ? 'bg-slate-100 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-emerald-50/95 border-emerald-600 shadow-2xs'
                                        : 'bg-white hover:bg-slate-50 border-slate-200'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <span
                                        className={`w-5 h-5 rounded-full flex items-center justify-center border-2 shrink-0 ${
                                          isSelected
                                            ? 'border-emerald-600 bg-emerald-600 text-white'
                                            : 'border-slate-300 bg-white'
                                        }`}
                                      >
                                        {isSelected && (
                                          <span className="w-2 h-2 rounded-full bg-white" />
                                        )}
                                      </span>
                                      <div className="min-w-0">
                                        <span
                                          className={`block text-sm sm:text-base font-extrabold leading-snug break-words ${
                                            isVarOut
                                              ? 'text-slate-400 line-through'
                                              : isSelected
                                              ? 'text-emerald-950'
                                              : 'text-slate-800'
                                          }`}
                                        >
                                          {variant.label}
                                        </span>
                                        {(isVarOut || showVariantMeasurement) && (
                                          <span className="block text-[11px] font-medium text-slate-500">
                                            {isVarOut ? 'স্টক আউট' : measurementSubtext}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                      {isVarOut ? (
                                        <span className="px-2.5 py-0.5 rounded-lg bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold shrink-0">
                                          স্টক শেষ
                                        </span>
                                      ) : (
                                        <>
                                          {showVariantPrice && vPrice > 0 && (
                                            <span
                                              className={`text-xs sm:text-sm font-extrabold font-mono ${
                                                isSelected ? 'text-emerald-800' : 'text-slate-600'
                                              }`}
                                            >
                                              {formatCurrency(vPrice)}
                                            </span>
                                          )}
                                          {isSelected && (
                                            <span className="px-2.5 py-0.5 rounded-lg bg-emerald-600 text-white text-[11px] font-bold shrink-0">
                                              নির্বাচিত ✓
                                            </span>
                                          )}
                                        </>
                                      )}
                                    </div>
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 2: Mobile 2-Column Smart Grid Chips */}
                          {variantStyle === 'mobile_grid_chips' && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`relative p-2.5 sm:p-3 rounded-xl border-2 text-left flex flex-col justify-between gap-1 ${
                                      showVariantMeasurement ? 'min-h-[66px]' : 'min-h-[48px]'
                                    } transition-all cursor-pointer ${
                                      isVarOut
                                        ? 'bg-slate-100 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-emerald-50/95 border-emerald-600 shadow-xs ring-2 ring-emerald-500/20'
                                        : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-emerald-300'
                                    }`}
                                  >
                                    <div className="flex items-start justify-between gap-1.5 w-full">
                                      <span
                                        className={`text-xs sm:text-sm font-extrabold leading-snug break-words pr-1 ${
                                          isVarOut
                                            ? 'text-slate-400 line-through'
                                            : isSelected
                                            ? 'text-emerald-950'
                                            : 'text-slate-800'
                                        }`}
                                      >
                                        {variant.label}
                                      </span>
                                      <span
                                        className={`w-4 h-4 rounded-full flex items-center justify-center border shrink-0 mt-0.5 ${
                                          isSelected
                                            ? 'bg-emerald-600 border-emerald-600 text-white'
                                            : 'border-slate-300 bg-slate-50'
                                        }`}
                                      >
                                        {isSelected && <CheckCircle2 className="w-3 h-3" />}
                                      </span>
                                    </div>
                                    {(isVarOut || showVariantMeasurement) && (
                                      <span className="text-[11px] font-medium text-slate-500">
                                        {isVarOut ? 'স্টক শেষ' : measurementSubtext}
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <div className="flex items-center justify-between pt-1 border-t border-emerald-900/10">
                                        <span
                                          className={`text-xs font-extrabold font-mono ${
                                            isSelected ? 'text-emerald-700' : 'text-slate-500'
                                          }`}
                                        >
                                          {formatCurrency(vPrice)}
                                        </span>
                                      </div>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 3: Modern Pill Capsules */}
                          {variantStyle === 'pill_capsules' && (
                            <div className="flex flex-wrap gap-2">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`px-3.5 py-2.5 rounded-full border-2 text-xs sm:text-sm font-extrabold inline-flex items-center gap-2 transition-all cursor-pointer active:scale-95 ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-gradient-to-r from-emerald-700 to-emerald-600 text-white border-emerald-700 shadow-sm'
                                        : 'bg-white text-slate-800 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/40'
                                    }`}
                                  >
                                    <span
                                      className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] shrink-0 ${
                                        isSelected
                                          ? 'bg-white text-emerald-700 font-black'
                                          : 'border border-slate-300 bg-slate-50 text-transparent'
                                      }`}
                                    >
                                      ✓
                                    </span>
                                    <span className={`leading-none ${isVarOut ? 'line-through' : ''}`}>
                                      {variant.label}
                                    </span>
                                    {!isVarOut && showVariantMeasurement && (
                                      <span
                                        className={`text-[10px] font-medium ${
                                          isSelected ? 'text-emerald-100' : 'text-slate-500'
                                        }`}
                                      >
                                        ({measurementSubtext})
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <span
                                        className={`px-2 py-0.5 rounded-full text-[11px] font-mono font-extrabold ${
                                          isSelected
                                            ? 'bg-emerald-900/40 text-amber-200'
                                            : 'bg-slate-100 text-slate-700'
                                        }`}
                                      >
                                        {formatCurrency(vPrice)}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 4: Premium Stacked / 2-Col Offer Cards */}
                          {variantStyle === 'stacked_offer_cards' && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const vRegPrice = Number(
                                  variant.regularPrice || checkoutTargetProduct.regularPrice || 0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`relative w-full p-3 rounded-2xl border-2 text-left flex items-center justify-between gap-2.5 transition-all cursor-pointer ${
                                      isVarOut
                                        ? 'bg-slate-100 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-gradient-to-r from-emerald-50 via-teal-50/70 to-amber-50/50 border-emerald-600 shadow-xs'
                                        : 'bg-white hover:bg-slate-50 border-slate-200'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <div
                                        className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                                          isSelected
                                            ? 'bg-emerald-600 text-white shadow-2xs'
                                            : 'bg-slate-100 text-slate-400 border border-slate-200'
                                        }`}
                                      >
                                        <CheckCircle2 className="w-4 h-4" />
                                      </div>
                                      <div className="min-w-0">
                                        <p
                                          className={`text-sm font-extrabold leading-snug break-words ${
                                            isVarOut
                                              ? 'text-slate-400 line-through'
                                              : isSelected
                                              ? 'text-emerald-950'
                                              : 'text-slate-800'
                                          }`}
                                        >
                                          {variant.label}
                                        </p>
                                        {(isVarOut || showVariantMeasurement) && (
                                          <p className="text-[11px] font-bold text-slate-500">
                                            {isVarOut ? 'বর্তমানে স্টকে নেই' : measurementSubtext}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                    <div className="text-right shrink-0">
                                      {isVarOut ? (
                                        <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-700 text-[11px] font-extrabold">
                                          স্টক শেষ
                                        </span>
                                      ) : showVariantPrice && vPrice > 0 ? (
                                        <div className="flex flex-col items-end">
                                          <span
                                            className={`text-sm font-black font-mono ${
                                              isSelected ? 'text-emerald-700' : 'text-slate-900'
                                            }`}
                                          >
                                            {formatCurrency(vPrice)}
                                          </span>
                                          {vRegPrice > vPrice && (
                                            <span className="text-[10px] text-slate-400 line-through font-mono">
                                              {formatCurrency(vRegPrice)}
                                            </span>
                                          )}
                                        </div>
                                      ) : (
                                        <span
                                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                                            isSelected
                                              ? 'bg-emerald-600 text-white'
                                              : 'bg-slate-100 text-slate-600'
                                          }`}
                                        >
                                          {isSelected ? 'সিলেক্টেড ✓' : 'বেছে নিন'}
                                        </span>
                                      )}
                                    </div>
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 5: Royal Crimson & Gold Box */}
                          {variantStyle === 'royal_crimson_tabs' && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`relative p-2.5 sm:p-3 rounded-xl border-2 text-center flex flex-col items-center justify-center gap-1 ${
                                      showVariantMeasurement ? 'min-h-[66px]' : 'min-h-[48px]'
                                    } transition-all cursor-pointer ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-rose-700 text-white border-amber-400 shadow-sm ring-2 ring-rose-500/25'
                                        : 'bg-rose-50/40 hover:bg-rose-50 text-slate-800 border-rose-200'
                                    }`}
                                  >
                                    {isSelected && (
                                      <span className="absolute -top-2 right-2 px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black uppercase tracking-tight shadow-2xs">
                                        ✓ Selected
                                      </span>
                                    )}
                                    <span
                                      className={`text-xs sm:text-sm font-extrabold leading-snug break-words ${
                                        isVarOut
                                          ? 'text-slate-400 line-through'
                                          : isSelected
                                          ? 'text-white'
                                          : 'text-slate-900'
                                      }`}
                                    >
                                      {variant.label}
                                    </span>
                                    {(isVarOut || showVariantMeasurement) && (
                                      <span
                                        className={`text-[10px] font-medium ${
                                          isSelected ? 'text-rose-100' : 'text-slate-500'
                                        }`}
                                      >
                                        {isVarOut ? 'স্টক শেষ' : measurementSubtext}
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <span
                                        className={`text-xs font-extrabold font-mono ${
                                          isSelected ? 'text-amber-300' : 'text-rose-700'
                                        }`}
                                      >
                                        {formatCurrency(vPrice)}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 6: Compact Segmented Touch Bar */}
                          {variantStyle === 'compact_segmented_bar' && (
                            <div className="p-1.5 rounded-2xl bg-slate-100 border border-slate-200/90 grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`px-2.5 py-2 rounded-xl text-center flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                                      isVarOut
                                        ? 'bg-slate-200/60 text-slate-400 opacity-75'
                                        : isSelected
                                        ? 'bg-white text-emerald-900 font-black shadow-xs border border-emerald-500/50'
                                        : 'bg-transparent text-slate-600 font-bold hover:text-slate-900 hover:bg-white/60'
                                    }`}
                                  >
                                    <div className="flex items-center justify-center gap-1 max-w-full">
                                      {isSelected && (
                                        <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
                                      )}
                                      <span
                                        className={`text-xs sm:text-sm leading-tight break-words ${
                                          isVarOut ? 'line-through' : ''
                                        }`}
                                      >
                                        {variant.label}
                                      </span>
                                    </div>
                                    {(isVarOut || showVariantMeasurement) && (
                                      <span className="text-[10px] text-slate-500">
                                        {isVarOut ? 'স্টক শেষ' : measurementSubtext}
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <span
                                        className={`text-[11px] font-mono font-extrabold ${
                                          isSelected ? 'text-emerald-700' : 'text-slate-500'
                                        }`}
                                      >
                                        {formatCurrency(vPrice)}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 7: Red-Gold Clean Box */}
                          {variantStyle === 'royal_crimson_clean' && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`relative p-2.5 sm:p-3 rounded-xl border-2 text-center flex flex-col items-center justify-center gap-1 ${
                                      showVariantMeasurement ? 'min-h-[66px]' : 'min-h-[48px]'
                                    } transition-all cursor-pointer active:scale-95 ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-rose-700 text-white border-amber-400 shadow-sm ring-2 ring-rose-500/25'
                                        : 'bg-rose-50/40 hover:bg-rose-50 text-slate-800 border-rose-200'
                                    }`}
                                  >
                                    <span
                                      className={`text-xs sm:text-sm font-extrabold leading-snug break-words ${
                                        isVarOut
                                          ? 'text-slate-400 line-through'
                                          : isSelected
                                          ? 'text-white'
                                          : 'text-slate-900'
                                      }`}
                                    >
                                      {variant.label}
                                    </span>
                                    {(isVarOut || showVariantMeasurement) && (
                                      <span
                                        className={`text-[10px] font-medium ${
                                          isSelected ? 'text-rose-100' : 'text-slate-500'
                                        }`}
                                      >
                                        {isVarOut ? 'স্টক শেষ' : measurementSubtext}
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <span
                                        className={`text-xs font-extrabold font-mono ${
                                          isSelected ? 'text-amber-300' : 'text-rose-700'
                                        }`}
                                      >
                                        {formatCurrency(vPrice)}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {/* DESIGN 8: Royal Luxury Gift Edition */}
                          {variantStyle === 'royal_luxury_gift' && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                              {checkoutTargetProduct.variants.map((variant, vIdx) => {
                                const isVarOut = Boolean(variant.outOfStock);
                                const isSelected = !isVarOut && activeVariant?.id === variant.id;
                                const vPrice = Number(
                                  variant.retailPrice ||
                                    checkoutTargetProduct.discountPrice ||
                                    checkoutTargetProduct.retailPrice ||
                                    0
                                );
                                const measurementSubtext = getVariantMeasurementText(variant.label, vIdx);
                                return (
                                  <button
                                    key={variant.id}
                                    type="button"
                                    onClick={() => handleSelectVariant(variant)}
                                    className={`relative overflow-hidden p-2.5 sm:p-3 rounded-xl border-2 text-center flex flex-col items-center justify-center gap-1 ${
                                      showVariantMeasurement ? 'min-h-[66px]' : 'min-h-[48px]'
                                    } transition-all cursor-pointer active:scale-95 ${
                                      isVarOut
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                        : isSelected
                                        ? 'bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-amber-300 border-amber-400 shadow-sm ring-2 ring-amber-400/30'
                                        : 'bg-gradient-to-b from-white to-amber-50/40 hover:to-amber-50/80 text-slate-800 border-amber-200/90 hover:border-amber-400'
                                    }`}
                                  >
                                    {isSelected && (
                                      <span className="absolute top-0 right-0 w-5 h-5 bg-gradient-to-br from-amber-300 to-amber-500 text-slate-950 rounded-bl-lg flex items-center justify-center text-[10px] font-black shadow-2xs">
                                        ✓
                                      </span>
                                    )}
                                    <span
                                      className={`text-xs sm:text-sm font-extrabold leading-snug break-words px-1 ${
                                        isVarOut
                                          ? 'text-slate-400 line-through'
                                          : isSelected
                                          ? 'text-amber-200'
                                          : 'text-slate-900'
                                      }`}
                                    >
                                      {variant.label}
                                    </span>
                                    {(isVarOut || showVariantMeasurement) && (
                                      <span
                                        className={`text-[10px] font-medium ${
                                          isSelected ? 'text-amber-100/80' : 'text-slate-500'
                                        }`}
                                      >
                                        {isVarOut ? 'স্টক শেষ' : measurementSubtext}
                                      </span>
                                    )}
                                    {!isVarOut && showVariantPrice && vPrice > 0 && (
                                      <span
                                        className={`text-xs font-extrabold font-mono px-2 py-0.5 rounded-md ${
                                          isSelected
                                            ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                                            : 'bg-amber-100/70 text-amber-900'
                                        }`}
                                      >
                                        {formatCurrency(vPrice)}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </>
                      ) : (
                        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-bold text-slate-700">
                          ফ্রি সাইজ / স্ট্যান্ডার্ড ভ্যারিয়েশন ({checkoutTargetProduct.unit})
                        </div>
                      )}

                      {/* Live Selection Summary & Quantity Bar (flex-col sm:flex-row) */}
                      <div className="rounded-xl bg-emerald-50/70 border border-emerald-200/90 p-3 sm:px-4 sm:py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                          <p className="text-xs sm:text-sm font-extrabold text-slate-900 leading-snug">
                            নির্বাচিত:{' '}
                            <span className="text-emerald-900">
                              {checkoutTargetProduct.nameBn}
                            </span>{' '}
                            {activeVariant && (
                              <span className="text-[#dc2626]">
                                (সাইজ: {activeVariant.label})
                              </span>
                            )}
                          </p>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-2.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-emerald-200/60 shrink-0">
                          <span className="text-xs sm:text-sm font-extrabold text-slate-700">
                            পরিমাণ:
                          </span>
                          <div className="inline-flex items-center rounded-xl bg-white border border-slate-300 p-0.5 shadow-2xs">
                            <button
                              type="button"
                              onClick={() => setQuantity(q => Math.max(1, q - 1))}
                              className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-800 font-extrabold cursor-pointer"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-9 text-center font-mono font-extrabold text-sm sm:text-base text-slate-900 tabular-nums">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                setQuantity(q => Math.min(availableStock || 99, q + 1))
                              }
                              className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-800 font-extrabold cursor-pointer"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ============================================================================ */}
                {/* LANDING PAGE 3 ONLY: MULTI-PRODUCT CHECKBOX + VARIANT + QUANTITY SELECTOR */}
                {/* ============================================================================ */}
                {isTemplate3 && showcaseEntries.length > 0 && (
                  <div className="space-y-4 pb-4 border-b border-slate-200">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded-full bg-indigo-600 text-white font-extrabold text-sm flex items-center justify-center shrink-0 shadow-xs">
                          ১
                        </span>
                        <div>
                          <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                            এক বা একাধিক প্রোডাক্ট, কালার/সাইজ ও পরিমাণ নির্বাচন করুন
                          </h3>
                          <p className="text-xs text-slate-500">
                            আপনি চাইলে ১টি, ২টি বা সবগুলো প্রোডাক্ট টিক (✓) দিয়ে একসাথে অর্ডার করতে পারবেন
                          </p>
                        </div>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-emerald-100 border border-emerald-300 text-xs font-extrabold text-emerald-900 shrink-0">
                        নির্বাচিত: {lp3SelectedResolvedItems.length}টি প্রোডাক্ট ({effectiveOrderQuantity} পিস)
                      </span>
                    </div>

                    <div className="space-y-3">
                      {showcaseEntries.map(entry => {
                        const itemProd = entry.product;
                        const cfg = lp3SelectionMap[itemProd.id] || {
                          selected: false,
                          variantId: '',
                          colorId: '',
                          quantity: 1
                        };
                        const isPicked = Boolean(cfg.selected);
                        const isDual = hasLpDualVariants(itemProd);
                        const colorVars = getLpColorVariants(itemProd);
                        const sizeVars = getLpSizeVariants(itemProd);
                        const singleVars = !isDual ? itemProd.variants || [] : [];

                        const resolvedItem = lp3SelectedResolvedItems.find(
                          x => x.product.id === itemProd.id
                        );
                        const firstVar =
                          itemProd.variants?.find(v => !v.outOfStock) || itemProd.variants?.[0];
                        const rowSalePrice = resolvedItem
                          ? resolvedItem.unitRetailPrice
                          : firstVar
                          ? firstVar.retailPrice
                          : itemProd.retailPrice;
                        const rawRowReg = resolvedItem
                          ? resolvedItem.unitRegularPrice
                          : firstVar?.regularPrice ?? itemProd.regularPrice ?? rowSalePrice;
                        const rowRegPrice =
                          rawRowReg > rowSalePrice ? rawRowReg : Math.round(rowSalePrice * 1.3);

                        return (
                          <div
                            key={itemProd.id}
                            className={`w-full rounded-2xl border-2 p-3 sm:p-4 transition-all space-y-3 ${
                              isPicked
                                ? 'border-emerald-600 bg-emerald-50/35 shadow-xs'
                                : 'border-slate-200 bg-white hover:border-slate-300'
                            }`}
                          >
                            <div
                              onClick={() => toggleLp3ProductSelection(itemProd.id)}
                              className="flex items-center gap-3 cursor-pointer"
                            >
                              {/* Checkbox */}
                              <div
                                className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center shrink-0 transition-colors ${
                                  isPicked
                                    ? 'border-emerald-600 bg-emerald-600 text-white'
                                    : 'border-slate-300 bg-white'
                                }`}
                              >
                                {isPicked && <Check className="w-4 h-4 stroke-[3]" />}
                              </div>

                              {/* Thumbnail */}
                              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0">
                                {resolvedItem?.activeVariant?.imageUrl || itemProd.image ? (
                                  <img
                                    src={resolvedItem?.activeVariant?.imageUrl || itemProd.image}
                                    alt={itemProd.nameBn}
                                    loading="lazy"
                                    className="w-full h-full object-cover object-top"
                                  />
                                ) : (
                                  <ProductThumbnail
                                    product={itemProd}
                                    className="w-full h-full"
                                    imgClassName="object-cover"
                                  />
                                )}
                              </div>

                              {/* Title & Subtitle */}
                              <div className="min-w-0 flex-1 space-y-0.5">
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-[#dc2626] text-white text-[10px] font-extrabold">
                                    {entry.badgeText}
                                  </span>
                                  <span className="text-[11px] font-bold text-slate-500 truncate">
                                    {entry.fabricSubtitle}
                                  </span>
                                </div>
                                <p className="text-xs sm:text-base font-extrabold text-slate-900 truncate">
                                  {itemProd.nameBn}
                                </p>
                                {resolvedItem?.activeVariant && (
                                  <p className="text-[11px] font-extrabold text-emerald-800">
                                    ✓ {resolvedItem.activeVariant.label}
                                  </p>
                                )}
                              </div>

                              {/* Price & Quantity Stepper */}
                              <div
                                onClick={e => e.stopPropagation()}
                                className="flex flex-col items-end gap-1.5 shrink-0"
                              >
                                <div className="text-right">
                                  {rowRegPrice > rowSalePrice && (
                                    <span className="text-[11px] font-bold text-slate-400 line-through mr-1 tabular-nums">
                                      ৳{rowRegPrice.toLocaleString('en-IN')}
                                    </span>
                                  )}
                                  <span className="text-sm sm:text-lg font-black text-[#dc2626] tabular-nums">
                                    ৳{rowSalePrice.toLocaleString('en-IN')}
                                  </span>
                                </div>

                                <div className="inline-flex items-center rounded-lg bg-white border border-slate-300 overflow-hidden">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateLp3ProductConfig(itemProd.id, {
                                        selected: true,
                                        quantity: Math.max(1, (cfg.quantity || 1) - 1)
                                      })
                                    }
                                    className="w-7 h-7 flex items-center justify-center hover:bg-slate-100 text-slate-800 font-bold cursor-pointer"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="w-8 text-center font-mono text-xs font-extrabold text-slate-900">
                                    {cfg.quantity || 1}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateLp3ProductConfig(itemProd.id, {
                                        selected: true,
                                        quantity: Math.min(99, (cfg.quantity || 1) + 1)
                                      })
                                    }
                                    className="w-7 h-7 flex items-center justify-center hover:bg-slate-100 text-slate-800 font-bold cursor-pointer"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Expanded Color & Size Selector inside Checked Row */}
                            {isPicked && (isDual || singleVars.length > 0) && (
                              <div className="pt-2.5 border-t border-emerald-200/70 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                {isDual && colorVars.length > 0 && (
                                  <div className="space-y-1">
                                    <span className="block text-[11px] font-extrabold text-rose-950">
                                      🎨 কালার নির্বাচন করুন:
                                    </span>
                                    <div className="flex flex-wrap gap-1.5">
                                      {colorVars.map(cVar => {
                                        const isOut = Boolean(cVar.outOfStock);
                                        const isSel = !isOut && cfg.colorId === cVar.id;
                                        return (
                                          <button
                                            key={cVar.id}
                                            type="button"
                                            disabled={isOut}
                                            onClick={() =>
                                              updateLp3ProductConfig(itemProd.id, {
                                                selected: true,
                                                colorId: cVar.id
                                              })
                                            }
                                            className={`px-2.5 py-1 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                                              isOut
                                                ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-60'
                                                : isSel
                                                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                                : 'bg-white text-slate-800 border-rose-200 hover:border-rose-500'
                                            }`}
                                          >
                                            {cVar.label}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>
                                )}

                                {(isDual ? sizeVars : singleVars).length > 0 && (
                                  <div className="space-y-1">
                                    <span className="block text-[11px] font-extrabold text-emerald-950">
                                      📏 {isDual ? 'সাইজ / বয়স নির্বাচন করুন:' : 'ভ্যারিয়েশন / সাইজ নির্বাচন করুন:'}
                                    </span>
                                    <div className="flex flex-wrap gap-1.5">
                                      {(isDual ? sizeVars : singleVars).map(sVar => {
                                        const isOut = Boolean(sVar.outOfStock);
                                        const isSel = !isOut && cfg.variantId === sVar.id;
                                        return (
                                          <button
                                            key={sVar.id}
                                            type="button"
                                            disabled={isOut}
                                            onClick={() =>
                                              updateLp3ProductConfig(itemProd.id, {
                                                selected: true,
                                                variantId: sVar.id
                                              })
                                            }
                                            className={`px-2.5 py-1 rounded-lg text-xs font-extrabold border transition-all cursor-pointer ${
                                              isOut
                                                ? 'bg-slate-100 text-slate-400 border-slate-200 line-through opacity-60'
                                                : isSel
                                                ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                                : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500'
                                            }`}
                                          >
                                            {sVar.label}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Left Column: Customer Name, Phone, Address & Delivery Zone */}
                  <div className="lg:col-span-7 space-y-4">
                    <h3 className="text-base sm:text-lg font-extrabold text-slate-900 pb-2.5 border-b border-slate-200 flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-emerald-700 shrink-0" />
                      <span>আপনার ডেলিভারি তথ্য দিন</span>
                    </h3>

                    {/* Full Name */}
                    <div data-checkout-field="name" className="max-md:scroll-mt-24 max-md:scroll-mb-40">
                      <label htmlFor="lp-input-name" className="block text-[14px] sm:text-base font-extrabold text-slate-800 mb-1.5">
                        আপনার নাম (Full Name) <span className="text-rose-600">*</span>
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-slate-400 absolute left-3 sm:left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          id="lp-input-name"
                          type="text"
                          value={customerName}
                          onFocus={triggerLandingInitiateCheckout}
                          onBlur={captureLandingIncompleteLeadNow}
                          onChange={e => {
                            setCustomerName(e.target.value);
                            if (errorField === 'name') setErrorField(null);
                          }}
                          placeholder="আপনার সম্পূর্ণ নাম লিখুন"
                          className={`w-full min-h-[48px] pl-9 sm:pl-10 pr-3 py-2.5 rounded-xl border text-[14px] sm:text-base font-medium placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:font-normal placeholder:text-slate-400 text-slate-900 outline-hidden transition-colors max-md:scroll-mt-24 max-md:scroll-mb-40 ${
                            errorField === 'name'
                              ? 'border-rose-500 bg-rose-50/40 ring-2 ring-rose-500/20'
                              : 'border-slate-300 bg-slate-50/70 focus:border-emerald-600 focus:bg-white'
                          }`}
                        />
                      </div>
                      {errorField === 'name' && (
                        <p className="text-xs font-bold text-rose-600 mt-1">
                          * অনুগ্রহ করে আপনার নাম লিখুন
                        </p>
                      )}
                    </div>

                    {/* Mobile Number */}
                    <div data-checkout-field="phone" className="max-md:scroll-mt-24 max-md:scroll-mb-40">
                      <label htmlFor="lp-input-phone" className="block text-[14px] sm:text-base font-extrabold text-slate-800 mb-1.5">
                        মোবাইল নম্বর (Phone Number) <span className="text-rose-600">*</span>
                      </label>
                      <div className="relative">
                        <PhoneCall className="w-4 h-4 text-slate-400 absolute left-3 sm:left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          id="lp-input-phone"
                          type="tel"
                          inputMode="tel"
                          value={customerPhone}
                          onFocus={triggerLandingInitiateCheckout}
                          onBlur={() => {
                            const norm = normalizeBdPhone(customerPhone);
                            if (isValidBdPhone11(norm) && customerPhone.trim() !== norm) {
                              setCustomerPhone(norm);
                            }
                            captureLandingIncompleteLeadNow();
                          }}
                          onChange={e => {
                            setCustomerPhone(e.target.value);
                            if (errorField === 'phone') setErrorField(null);
                          }}
                          placeholder="017XXXXXXXX (১১ ডিজিটের মোবাইল নম্বর)"
                          className={`w-full min-h-[48px] pl-9 sm:pl-10 pr-2.5 sm:pr-3.5 py-2.5 rounded-xl border text-[14px] sm:text-base font-semibold placeholder:font-sans placeholder:font-normal placeholder:tracking-normal placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:text-slate-400 text-slate-900 outline-hidden transition-colors tabular-nums max-md:scroll-mt-24 max-md:scroll-mb-40 ${
                            errorField === 'phone'
                              ? 'border-rose-500 bg-rose-50/40 ring-2 ring-rose-500/20'
                              : 'border-slate-300 bg-slate-50/70 focus:border-emerald-600 focus:bg-white'
                          }`}
                        />
                      </div>
                      {errorField === 'phone' && (
                        <p className="text-xs font-bold text-rose-600 mt-1">
                          * সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন
                        </p>
                      )}
                    </div>

                    {/* Offer #7: Flash Free Delivery Live Countdown Banner */}
                    {isFlashFreeDeliveryActive && (
                      <div className="p-3.5 rounded-xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white shadow-sm flex items-center justify-between gap-2 animate-pulse">
                        <div className="flex items-center gap-2 font-extrabold text-xs sm:text-sm">
                          <span className="text-base">⚡</span>
                          <span>
                            ফ্ল্যাশ ফ্রি ডেলিভারি অফার চলছে! আগামী{' '}
                            <span className="underline decoration-amber-300 text-amber-200">
                              {flashCountdownLabelBn}
                            </span>{' '}
                            এর মধ্যে অর্ডার করলেই ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!
                          </span>
                        </div>
                        <span className="px-2.5 py-0.5 rounded-full bg-amber-300 text-slate-950 text-[11px] font-black shrink-0">
                          ফ্রি ডেলিভারি ✓
                        </span>
                      </div>
                    )}

                    {/* Offer #1: Minimum Order Amount Free Delivery Animated Progress Bar */}
                    {isMinAmountFreeDeliveryEnabled && !isFlashFreeDeliveryActive && (
                      <div
                        className={`p-3.5 rounded-xl border transition-all ${
                          isMinAmountFreeDeliveryUnlocked
                            ? 'bg-emerald-50/95 border-emerald-300 text-emerald-950'
                            : 'bg-sky-50/90 border-sky-200/90 text-sky-950'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm font-extrabold mb-2">
                          <span className="flex items-center gap-1.5">
                            <Truck
                              className={`w-4 h-4 shrink-0 ${
                                isMinAmountFreeDeliveryUnlocked ? 'text-emerald-600' : 'text-sky-600'
                              }`}
                            />
                            {isMinAmountFreeDeliveryUnlocked ? (
                              <span>
                                🎉 অভিনন্দন! ৳{toBanglaDigitsLpStatic(freeDeliveryMinOrderAmt)}+ টাকার অর্ডারে আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি (৳০)!
                              </span>
                            ) : (
                              <span>
                                আর মাত্র{' '}
                                <strong className="text-rose-600 font-black">
                                  {formatCurrency(remainingAmtForFreeDelivery)}
                                </strong>{' '}
                                টাকার পণ্য যোগ করলেই আপনার ডেলিভারি চার্জ সম্পূর্ণ{' '}
                                <strong className="text-emerald-700">ফ্রি!</strong>
                              </span>
                            )}
                          </span>
                          <div className="flex items-center gap-2">
                            {!isMinAmountFreeDeliveryUnlocked && unitRetailPrice > 0 && (
                              <button
                                type="button"
                                onClick={() => {
                                  const neededQty = Math.ceil(freeDeliveryMinOrderAmt / unitRetailPrice);
                                  setQuantity(Math.min(availableStock || 99, Math.max(quantity + 1, neededQty)));
                                  showToast('🎉 ফ্রি ডেলিভারি টার্গেট পূরণ হয়েছে — ডেলিভারি চার্জ ফ্রি!', 'success');
                                }}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-extrabold cursor-pointer shrink-0"
                              >
                                + ফ্রি ডেলিভারি নিন
                              </button>
                            )}
                            <span className="font-mono text-xs font-black px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-800 shrink-0">
                              {toBanglaDigitsLpStatic(minAmountProgressPct)}%
                            </span>
                          </div>
                        </div>
                        <div className="w-full h-2.5 rounded-full bg-slate-200/80 overflow-hidden p-0.5">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isMinAmountFreeDeliveryUnlocked
                                ? 'bg-gradient-to-r from-emerald-500 to-teal-500'
                                : 'bg-gradient-to-r from-sky-500 via-teal-500 to-emerald-500'
                            }`}
                            style={{ width: `${minAmountProgressPct}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Delivery Area Selector */}
                    {!isFreeDelivery ? (
                      <div>
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                          <label className="block text-[14px] sm:text-base font-extrabold text-slate-800">
                            ডেলিভারি এরিয়া নির্বাচন করুন <span className="text-rose-600">*</span>
                          </label>
                          {isHalfDeliveryOfferEnabled && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-100 border border-rose-200 text-rose-700 text-[11px] font-black animate-pulse">
                              🔥 ডেলিভারি চার্জে {toBanglaDigitsLpStatic(deliveryDiscountPct)}% ছাড় চলছে!
                            </span>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <label
                            className={`flex items-center justify-between p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                              selectedDeliveryZone === 'inside_dhaka'
                                ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950'
                                : 'border-slate-200 bg-slate-50/60 text-slate-700 hover:bg-slate-100/70'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <input
                                type="radio"
                                name="lpDeliveryZone"
                                checked={selectedDeliveryZone === 'inside_dhaka'}
                                onChange={() => setSelectedDeliveryZone('inside_dhaka')}
                                className="w-4 h-4 accent-emerald-600"
                              />
                              <span className="text-[14px] sm:text-base font-extrabold">ঢাকার ভিতরে</span>
                            </div>
                            <span className="font-mono font-extrabold text-sm sm:text-base text-emerald-700 tabular-nums flex items-center gap-1.5">
                              {isHalfDeliveryOfferEnabled && rawInsideDhakaFee > insideDhakaFee && (
                                <span className="text-xs text-slate-400 line-through">
                                  ৳{rawInsideDhakaFee}
                                </span>
                              )}
                              <span className={isHalfDeliveryOfferEnabled ? 'text-rose-600' : ''}>
                                ৳{insideDhakaFee}
                              </span>
                            </span>
                          </label>

                          <label
                            className={`flex items-center justify-between p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                              selectedDeliveryZone === 'outside_dhaka'
                                ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950'
                                : 'border-slate-200 bg-slate-50/60 text-slate-700 hover:bg-slate-100/70'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <input
                                type="radio"
                                name="lpDeliveryZone"
                                checked={selectedDeliveryZone === 'outside_dhaka'}
                                onChange={() => setSelectedDeliveryZone('outside_dhaka')}
                                className="w-4 h-4 accent-emerald-600"
                              />
                              <span className="text-[14px] sm:text-base font-extrabold">ঢাকার বাইরে</span>
                            </div>
                            <span className="font-mono font-extrabold text-sm sm:text-base text-emerald-700 tabular-nums flex items-center gap-1.5">
                              {isHalfDeliveryOfferEnabled && rawOutsideDhakaFee > outsideDhakaFee && (
                                <span className="text-xs text-slate-400 line-through">
                                  ৳{rawOutsideDhakaFee}
                                </span>
                              )}
                              <span className={isHalfDeliveryOfferEnabled ? 'text-rose-600' : ''}>
                                ৳{outsideDhakaFee}
                              </span>
                            </span>
                          </label>
                        </div>

                        {/* ৫. 📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন (Estimated Delivery Date Badge — ON / OFF) */}
                        {(currentBusiness.checkoutEstimatedDeliveryEnabled !== false || isAdminViewing) && (
                          <div
                            className={`mt-2.5 p-2.5 sm:px-3.5 sm:py-2.5 rounded-xl border flex flex-wrap items-center justify-between gap-2 transition-all ${
                              currentBusiness.checkoutEstimatedDeliveryEnabled === false
                                ? 'bg-slate-100/80 border-dashed border-slate-300 text-slate-500'
                                : selectedDeliveryZone === 'inside_dhaka'
                                ? 'bg-emerald-50/90 border-emerald-200/90 text-emerald-950'
                                : 'bg-teal-50/90 border-teal-200/90 text-teal-950'
                            }`}
                          >
                            <div className="flex items-center gap-2 text-xs sm:text-[13px] font-extrabold leading-snug">
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-white border border-emerald-200/80 shadow-2xs shrink-0 text-sm">
                                📦
                              </span>
                              <span>
                                {selectedDeliveryZone === 'inside_dhaka'
                                  ? (currentBusiness.checkoutEstimatedDeliveryInsideText || '').trim() ||
                                    '🚚 আনুমানিক ডেলিভারি: আগামীকাল বা ২৪-৪৮ ঘণ্টার মধ্যে'
                                  : (currentBusiness.checkoutEstimatedDeliveryOutsideText || '').trim() ||
                                    '🚚 আনুমানিক ডেলিভারি: ২-৩ কার্যদিবসের মধ্যে (সুন্দরবন / স্টেডফাস্ট হোম ডেলিভারি)'}
                              </span>
                            </div>

                            {isAdminViewing && (
                              <button
                                type="button"
                                onClick={() => {
                                  const nextEstOn = currentBusiness.checkoutEstimatedDeliveryEnabled === false;
                                  updateBusiness({ checkoutEstimatedDeliveryEnabled: nextEstOn });
                                  showToast(
                                    nextEstOn
                                      ? '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন চালু (ON) করা হয়েছে!'
                                      : '📦 ডেলিভারির আনুমানিক তারিখ প্রদর্শন বন্ধ (OFF) করা হয়েছে!',
                                    nextEstOn ? 'success' : 'info'
                                  );
                                }}
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border cursor-pointer transition-all shrink-0 ${
                                  currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                    : 'bg-slate-700 text-white border-slate-700'
                                }`}
                                title="অ্যাডমিন কন্ট্রোল: ডেলিভারির আনুমানিক তারিখ প্রদর্শন ON / OFF করুন"
                              >
                                {currentBusiness.checkoutEstimatedDeliveryEnabled !== false
                                  ? '📦 ডেলিভারি সময়: ON'
                                  : '📦 ডেলিভারি সময়: OFF (লুকানো)'}
                              </button>
                            )}
                          </div>
                        )}
                        {isQtyFreeDeliveryEnabled && !isQtyFreeDeliveryUnlocked && (
                          <div className="mt-2 p-2.5 rounded-xl bg-amber-50 border border-amber-200/90 flex flex-wrap items-center justify-between gap-2 text-xs font-extrabold text-amber-950">
                            <span>
                              💡 টিপস: কমপক্ষে <strong>{freeDeliveryMinQty} পিস</strong> অর্ডার করলেই এই ডেলিভারি চার্জ সম্পূর্ণ <strong>ফ্রি (৳০)</strong> হয়ে যাবে!
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setQuantity(Math.min(availableStock || 99, freeDeliveryMinQty));
                                showToast(
                                  `🎉 ${freeDeliveryMinQty} পিস সিলেক্ট করা হয়েছে — ডেলিভারি চার্জ ফ্রি!`,
                                  'success'
                                );
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-extrabold cursor-pointer shrink-0"
                            >
                              {freeDeliveryMinQty} পিস নিন (ফ্রি ডেলিভারি)
                            </button>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm font-extrabold flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Truck className="w-5 h-5 text-emerald-700 shrink-0" />
                          <span>
                            {isFlashFreeDeliveryActive
                              ? 'অভিনন্দন! ফ্ল্যাশ ফ্রি ডেলিভারি অফারে আপনার ডেলিভারি চার্জ সম্পূর্ণ ফ্রি!'
                              : isMinAmountFreeDeliveryUnlocked
                              ? `অভিনন্দন! ৳${toBanglaDigitsLpStatic(freeDeliveryMinOrderAmt)}+ টাকার অর্ডারে সারা বাংলাদেশে হোম ডেলিভারি সম্পূর্ণ ফ্রি!`
                              : isQtyFreeDeliveryUnlocked
                              ? `অভিনন্দন! ${quantity} পিস অর্ডারে সারা বাংলাদেশে হোম ডেলিভারি সম্পূর্ণ ফ্রি!`
                              : 'অভিনন্দন! এই পণ্যে সারা বাংলাদেশে হোম ডেলিভারি সম্পূর্ণ ফ্রি!'}
                          </span>
                        </div>
                        {isQtyFreeDeliveryUnlocked && (
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-700 text-white text-xs font-extrabold shrink-0">
                            {freeDeliveryMinQty}+ পিস অফার ✓
                          </span>
                        )}
                      </div>
                    )}

                    {/* Full Delivery Address */}
                    <div data-checkout-field="address" className="max-md:scroll-mt-24 max-md:scroll-mb-40">
                      <label htmlFor="lp-input-address" className="block text-[14px] sm:text-base font-extrabold text-slate-800 mb-1.5">
                        সম্পূর্ণ ডেলিভারি ঠিকানা (Full Address) <span className="text-rose-600">*</span>
                      </label>
                      <textarea
                        id="lp-input-address"
                        rows={3}
                        value={deliveryAddress}
                        onBlur={captureLandingIncompleteLeadNow}
                        onChange={e => {
                          setDeliveryAddress(e.target.value);
                          if (errorField === 'address') setErrorField(null);
                        }}
                        placeholder="বাসা/রোড নম্বর, গ্রাম/এলাকা, থানা ও জেলার নাম লিখুন..."
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-[14px] sm:text-base font-medium placeholder:text-[13.5px] sm:placeholder:text-sm placeholder:font-normal placeholder:text-slate-400 text-slate-900 outline-hidden transition-colors max-md:scroll-mt-24 max-md:scroll-mb-40 ${
                          errorField === 'address'
                            ? 'border-rose-500 bg-rose-50/40 ring-2 ring-rose-500/20'
                            : 'border-slate-300 bg-slate-50/70 focus:border-emerald-600 focus:bg-white'
                        }`}
                      />
                      {errorField === 'address' && (
                        <p className="text-xs font-bold text-rose-600 mt-1">
                          * সম্পূর্ণ ডেলিভারি ঠিকানা লিখুন
                        </p>
                      )}
                    </div>

                    {/* Optional Order Notes */}
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">
                        অর্ডার নোট (ঐচ্ছিক / Optional)
                      </label>
                      <div className="relative">
                        <FileText className="w-4 h-4 text-slate-400 absolute left-3 sm:left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="text"
                          value={orderNotes}
                          onChange={e => setOrderNotes(e.target.value)}
                          placeholder="যেমন: ডেলিভারির আগে কল দিবেন..."
                          className="w-full min-h-[46px] pl-9 sm:pl-10 pr-3 py-2 rounded-xl border border-slate-300 bg-slate-50/70 focus:border-emerald-600 focus:bg-white text-sm sm:text-base placeholder:text-[13px] sm:placeholder:text-sm text-slate-900 outline-hidden"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Live Order Summary & Confirm Button */}
                  <div className="lg:col-span-5 bg-slate-50 rounded-2xl border border-slate-200/90 p-3.5 sm:p-5 space-y-4">
                    <h3 className="text-base sm:text-lg font-extrabold text-slate-900 pb-2.5 border-b border-slate-200 flex items-center gap-2">
                      <PackageCheck className="w-5 h-5 text-emerald-700 shrink-0" />
                      <span>আপনার অর্ডার সামারি</span>
                    </h3>

                    {/* Selected Product Item Card(s) with Inline Quantity Adjuster */}
                    {isTemplate3 && lp3SelectedResolvedItems.length > 0 ? (
                      <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                        {lp3SelectedResolvedItems.map(sel => (
                          <div
                            key={sel.product.id}
                            className="p-3 rounded-xl bg-white border border-slate-200 space-y-2"
                          >
                            <div className="flex items-start justify-between gap-2.5">
                              <div className="flex items-center gap-2.5 min-w-0">
                                <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 overflow-hidden shrink-0">
                                  <ProductThumbnail product={sel.product} imgClassName="p-0.5" />
                                </div>
                                <div className="min-w-0">
                                  <p className="text-xs sm:text-sm font-extrabold text-slate-900 line-clamp-1">
                                    {sel.product.nameBn}
                                  </p>
                                  {sel.activeVariant && (
                                    <span className="inline-block mt-0.5 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold">
                                      {sel.activeVariant.label}
                                    </span>
                                  )}
                                </div>
                              </div>
                              {lp3SelectedResolvedItems.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => toggleLp3ProductSelection(sel.product.id, false)}
                                  className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer shrink-0"
                                  title="অর্ডার থেকে সরান"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              )}
                            </div>

                            <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateLp3ProductConfig(sel.product.id, {
                                      quantity: Math.max(1, sel.quantity - 1)
                                    })
                                  }
                                  className="w-6 h-6 rounded-md bg-slate-100 hover:bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-800 font-bold cursor-pointer"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="w-7 text-center font-mono font-extrabold text-xs text-slate-900 tabular-nums">
                                  {sel.quantity}
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateLp3ProductConfig(sel.product.id, {
                                      quantity: Math.min(99, sel.quantity + 1)
                                    })
                                  }
                                  className="w-6 h-6 rounded-md bg-slate-100 hover:bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-800 font-bold cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>

                              <div className="text-right font-mono tabular-nums">
                                <span className="text-xs text-slate-500 mr-1.5">
                                  ৳{sel.unitRetailPrice} × {sel.quantity} =
                                </span>
                                <span className="font-extrabold text-emerald-800 text-sm">
                                  ৳{sel.lineTotal}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="w-16 h-16 rounded-xl bg-slate-50 border border-slate-200 overflow-hidden shrink-0">
                            <ProductThumbnail product={checkoutTargetProduct} imgClassName="p-1" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm sm:text-base font-extrabold text-slate-900 line-clamp-2">
                              {checkoutTargetProduct.nameBn}
                            </p>
                            {activeVariant && (
                              <span className="inline-block mt-1 px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                                {activeVariant.label}
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setQuantity(q => Math.max(1, q - 1))}
                              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-800 font-bold cursor-pointer"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-8 text-center font-mono font-extrabold text-sm text-slate-900 tabular-nums">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => setQuantity(q => Math.min(availableStock || 99, q + 1))}
                              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-800 font-bold cursor-pointer"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="text-right font-mono tabular-nums">
                            <span className="text-xs text-slate-500 mr-1.5">
                              {unitRegularPrice > unitRetailPrice && (
                                <span className="line-through text-slate-400 mr-1">
                                  ৳{unitRegularPrice}
                                </span>
                              )}
                              ৳{unitRetailPrice} × {quantity} =
                            </span>
                            <span className="font-extrabold text-emerald-800 text-base">
                              ৳{subtotal}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Quick Variant Switcher inside Summary if variants exist (Landing Page 1 Only) */}
                    {!isMultiShowcaseTemplate && product.variants && product.variants.length > 1 && (
                      <div className="space-y-1.5">
                        <span className="text-xs sm:text-sm font-bold text-slate-600 block">
                          সাইজ / ভ্যারিয়েশন পরিবর্তন করুন:
                        </span>
                        <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-1.5">
                          {product.variants.map(v => {
                            const isVarOut = Boolean(v.outOfStock);
                            const isSel = !isVarOut && activeVariant?.id === v.id;
                            const vPrice = Number(v.retailPrice || product.discountPrice || product.retailPrice || 0);
                            return (
                              <button
                                key={v.id}
                                type="button"
                                onClick={() => handleSelectVariant(v)}
                                className={`px-3 py-2 sm:py-1.5 rounded-xl text-xs sm:text-sm font-extrabold border flex items-center justify-between sm:justify-center gap-1.5 transition-all cursor-pointer ${
                                  isVarOut
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 opacity-75'
                                    : isSel
                                    ? variantStyle === 'royal_crimson_tabs' ||
                                      variantStyle === 'royal_crimson_clean'
                                      ? 'bg-rose-700 text-white border-amber-400 shadow-2xs'
                                      : variantStyle === 'royal_luxury_gift'
                                      ? 'bg-slate-900 text-amber-300 border-amber-400 shadow-2xs'
                                      : 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                                    : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-500'
                                }`}
                              >
                                <span className={`truncate ${isVarOut ? 'line-through' : ''}`}>
                                  {v.label.split(' (')[0]}
                                </span>
                                {isVarOut ? (
                                  <span className="text-[10px] font-extrabold text-rose-600 shrink-0">
                                    (স্টক শেষ)
                                  </span>
                                ) : showVariantPrice && vPrice > 0 ? (
                                  <span
                                    className={`text-[11px] font-mono shrink-0 ${
                                      isSel ? 'text-amber-200' : 'text-slate-500'
                                    }`}
                                  >
                                    {formatCurrency(vPrice)}
                                  </span>
                                ) : (
                                  isSel && <span className="text-[11px] shrink-0">✓</span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Bill Breakdown */}
                    <div className="space-y-2 pt-2 border-t border-slate-200 text-sm sm:text-base">
                      <div className="flex justify-between items-center text-slate-600">
                        <span>সাবটোটাল ({quantity} টি):</span>
                        <span className="font-mono font-bold text-slate-900 tabular-nums">
                          {formatCurrency(subtotal)}
                        </span>
                      </div>
                      {spinWheelEnabled && claimedSpinReward && (
                        <div className="p-3 rounded-xl bg-gradient-to-r from-amber-50 via-emerald-50 to-teal-50 border border-emerald-300/85 flex items-start sm:items-center justify-between gap-2.5 text-xs sm:text-sm">
                          <div className="flex items-start gap-2 font-extrabold text-emerald-950 min-w-0 flex-1">
                            <Gift className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                            <span className="leading-snug break-words">
                              স্পিন হুইল অফার ({claimedSpinReward.code}):{' '}
                              <span className="text-emerald-800">{claimedSpinReward.label}</span>
                            </span>
                          </div>
                          <span className="font-mono font-extrabold text-emerald-700 shrink-0 tabular-nums whitespace-nowrap bg-white/85 px-2 py-0.5 rounded-lg border border-emerald-200/80">
                            {claimedSpinReward.type === 'free_delivery'
                              ? 'ফ্রি ডেলিভারি যুক্ত ✓'
                              : `- ${formatCurrency(spinDiscountAmount)}`}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-slate-600">
                        <span>
                          ডেলিভারি চার্জ
                          {isFlashFreeDeliveryActive
                            ? ' (⚡ ফ্ল্যাশ অফার)'
                            : isMinAmountFreeDeliveryUnlocked
                            ? ` (৳${toBanglaDigitsLpStatic(freeDeliveryMinOrderAmt)}+ অফার)`
                            : isProductSpecificFreeDeliveryOnLp
                            ? ' (স্পেশাল ফ্রি ডেলিভারি পণ্য)'
                            : isQtyFreeDeliveryUnlocked
                            ? ` (${freeDeliveryMinQty}+ পিস অফার)`
                            : isHalfDeliveryOfferEnabled && deliveryCharge > 0
                            ? ` (${toBanglaDigitsLpStatic(deliveryDiscountPct)}% ছাড়)`
                            : ''}
                          :
                        </span>
                        <span className="font-mono font-bold text-emerald-700 tabular-nums flex items-center gap-1.5">
                          {deliveryCharge === 0 ? (
                            'ফ্রি ডেলিভারি (৳০)'
                          ) : (
                            <>
                              {isHalfDeliveryOfferEnabled && selectedRawZoneFee > deliveryCharge && (
                                <span className="text-xs text-slate-400 line-through">
                                  {formatCurrency(selectedRawZoneFee)}
                                </span>
                              )}
                              <span className={isHalfDeliveryOfferEnabled ? 'text-rose-600 font-extrabold' : ''}>
                                {formatCurrency(deliveryCharge)}
                              </span>
                            </>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between items-baseline pt-2.5 border-t border-slate-200 text-base sm:text-lg font-extrabold text-slate-900">
                        <span>সর্বমোট বিল (Total):</span>
                        <span className="font-mono text-xl sm:text-2xl text-emerald-800 tabular-nums">
                          {formatCurrency(grandTotal)}
                        </span>
                      </div>
                    </div>

                    {/* COD Assurance Box */}
                    <div className="p-3.5 rounded-xl bg-amber-50/90 border border-amber-200/90 flex items-center gap-2.5 text-xs sm:text-sm text-amber-950 font-bold">
                      <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0" />
                      <span>ক্যাশ অন ডেলিভারি — পণ্য হাতে পেয়ে চেক করে পেমেন্ট করবেন</span>
                    </div>

                    {/* Big Submit Order Button (Observed by IntersectionObserver to auto-hide Sticky Bar) */}
                    <div
                      className={
                        availableStock > 0 &&
                        !isSubmitting &&
                        (floatingBtnAnimation === 'cart_beam' ||
                          floatingBtnAnimation === 'combo_beam')
                          ? `lp-floating-cart-beam-wrapper ${
                              floatingBtnAnimation === 'combo_beam'
                                ? 'lp-floating-combo-pulse'
                                : ''
                            }`
                          : 'w-full'
                      }
                    >
                      <button
                        ref={mainSubmitBtnRef}
                        id="lp-main-submit-btn"
                        type="submit"
                        disabled={isSubmitting || availableStock <= 0}
                        className={`relative z-10 w-full min-h-[52px] sm:min-h-[58px] py-3.5 sm:py-4 px-3 sm:px-5 bg-gradient-to-r from-[#d00000] via-[#b80000] to-[#9e0000] hover:from-[#b80000] hover:to-[#8a0000] disabled:opacity-60 text-white font-extrabold text-[14px] min-[380px]:text-[15px] sm:text-lg rounded-2xl shadow-md flex items-center justify-center gap-1.5 sm:gap-2 whitespace-nowrap transition-all cursor-pointer active:scale-[0.99] ${
                          availableStock > 0 && !isSubmitting
                            ? floatingBtnAnimation === 'jump'
                              ? 'animate-cta-jump'
                              : floatingBtnAnimation === 'login_shine'
                              ? 'lp-btn-red-shine lp-floating-login-glow border border-white/35'
                              : floatingBtnAnimation === 'combo_beam'
                              ? 'lp-btn-red-shine'
                              : floatingBtnAnimation === 'glow_pulse'
                              ? 'animate-order-cta-attention'
                              : ''
                            : ''
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4 min-[380px]:w-5 min-[380px]:h-5 sm:w-6 sm:h-6 shrink-0" />
                        <span className="tabular-nums whitespace-nowrap">
                          {availableStock <= 0
                            ? 'বর্তমানে স্টকে নেই (স্টক শেষ)'
                            : isSubmitting
                            ? 'অর্ডার প্রসেস হচ্ছে...'
                            : `অর্ডার কনফার্ম করুন (${formatCurrency(grandTotal)})`}
                        </span>
                      </button>
                    </div>

                    {/* Direct Help / WhatsApp Order Link */}
                    <div className="pt-1 flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm">
                      {showCallButton && (
                        <a
                          href={`tel:${supportPhone.replace(/\s+/g, '')}`}
                          className="inline-flex items-center gap-1.5 text-blue-700 hover:text-blue-900 font-bold tabular-nums"
                        >
                          <PhoneCall className="w-4 h-4" />
                          <span>কল করুন: {supportPhone}</span>
                        </a>
                      )}
                      {showWhatsappButton && (
                        <a
                          href={`https://wa.me/${formattedWaNumber}?text=${encodeURIComponent(
                            `আসসালামু আলাইকুম, আমি "${product.nameBn}" (${
                              activeVariant ? activeVariant.label : product.unit
                            }) অর্ডার করতে চাই।`
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 text-[#128C7E] hover:text-[#075E54] font-bold"
                        >
                          <LandingWhatsAppOriginalIcon className="w-4 h-4 text-[#25D366] shrink-0" />
                          <span>হোয়াটসঅ্যাপে অর্ডার করুন</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </form>
            </section>
          </>
        )}
      </main>

      {/* Simple Minimal Footer with Configurable Anti-Fake Order Notice & Developer Credit (ON/OFF, Editable) */}
      {(showFooterWarning || (showDeveloperCredit && developerCreditName)) && (
        <footer className="bg-white border-t border-slate-200 py-6 px-4 text-center text-xs sm:text-sm text-slate-600 mt-8 pb-24 sm:pb-8">
          <div className="max-w-5xl mx-auto space-y-4">
            {/* Configurable Anti-Fake Order Notice (ON/OFF & Editable Text from Admin) */}
            {showFooterWarning && footerWarningText && (
              <div className="max-w-xl mx-auto px-4 py-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-center space-y-1">
                {footerWarningText
                  .split(/\n+/)
                  .map(line => line.trim())
                  .filter(Boolean)
                  .map((line, idx) => (
                    <p
                      key={idx}
                      className={
                        idx === 0
                          ? 'text-sm sm:text-base font-extrabold text-rose-700 leading-relaxed'
                          : 'text-xs sm:text-sm font-bold text-slate-700 leading-relaxed'
                      }
                    >
                      {line}
                    </p>
                  ))}
              </div>
            )}

            {showDeveloperCredit && developerCreditName && (
              <div
                className={`${
                  showFooterWarning ? 'pt-3 border-t border-slate-100' : ''
                } flex flex-wrap items-center justify-center sm:justify-between gap-2 text-xs text-slate-500`}
              >
                <span>© {new Date().getFullYear()} {currentBusiness.name} · সর্বস্বত্ব সংরক্ষিত</span>
                <p className="inline-flex items-center gap-1.5 font-medium text-slate-600">
                  <span>Developed by</span>
                  {normalizedDeveloperCreditLink ? (
                    <a
                      href={normalizedDeveloperCreditLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-bold text-emerald-700 hover:text-emerald-800 hover:underline transition-colors"
                    >
                      {developerCreditName}
                    </a>
                  ) : (
                    <span className="font-bold text-slate-800">{developerCreditName}</span>
                  )}
                </p>
              </div>
            )}
          </div>
        </footer>
      )}

      {/* SIZE CHART POPUP MODAL (When user clicks "সাইজ চার্ট দেখুন" next to variations) */}
      {showSizeChart && showSizeChartModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
          <div
            onClick={() => setShowSizeChartModal(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
          />
          <div className="relative w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-xl z-10 overflow-hidden animate-page-rise">
            <div className="px-4 sm:px-5 py-3.5 bg-emerald-50/80 border-b border-emerald-100 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Ruler className="w-4 h-4 text-emerald-700 shrink-0" />
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                  {sizeChartTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSizeChartModal(false)}
                className="p-1 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 max-h-[80vh] overflow-y-auto">
              {sizeChartSubtitle !== '' && (
                <p className="text-xs sm:text-sm text-slate-600 font-medium">
                  {sizeChartSubtitle}
                </p>
              )}

              {sizeChartImage !== '' && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-2 overflow-hidden">
                  <LazyImage
                    src={sizeChartImage}
                    alt={sizeChartTitle}
                    wrapperClassName="relative w-full overflow-hidden flex justify-center"
                    skeletonClassName="min-h-[160px]"
                    className="max-h-80 w-auto mx-auto object-contain rounded-lg"
                  />
                </div>
              )}

              {sizeChartRows.length > 0 && (
                <div className="overflow-x-auto rounded-xl border border-slate-200">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-emerald-50 border-b border-emerald-200 text-emerald-950 text-xs sm:text-sm font-extrabold">
                        <th className="py-2.5 px-3.5">{sizeChartHeaders[0] || 'সাইজ / বয়স'}</th>
                        <th className="py-2.5 px-3.5">{sizeChartHeaders[1] || 'বডি / চেস্ট (ইঞ্চি)'}</th>
                        <th className="py-2.5 px-3.5">{sizeChartHeaders[2] || 'লম্বা / দৈর্ঘ্য (ইঞ্চি)'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-xs sm:text-sm">
                      {sizeChartRows.map((row, rIdx) => (
                        <tr
                          key={row.id || rIdx}
                          className={rIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}
                        >
                          <td className="py-2 px-3.5 font-extrabold text-slate-900">{row.size}</td>
                          <td className="py-2 px-3.5 font-semibold text-slate-700">{row.chest}</td>
                          <td className="py-2 px-3.5 font-semibold text-slate-700">{row.length}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <button
                type="button"
                onClick={() => setShowSizeChartModal(false)}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs sm:text-sm cursor-pointer transition-colors"
              >
                ঠিক আছে, বুঝেছি
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LIVE RECENT ORDER NOTIFICATION POPUP (Social Proof — Can be turned ON/OFF) */}
      {showSocialProof && !isSocialProofDismissed && !confirmedOrder && (
        <div
          className={`fixed bottom-20 sm:bottom-5 left-3 sm:left-5 z-40 max-w-[320px] sm:max-w-[350px] transition-all duration-500 ${
            isSocialProofVisible
              ? 'translate-y-0 opacity-100 pointer-events-auto'
              : 'translate-y-6 opacity-0 pointer-events-none'
          }`}
        >
          <div className="bg-white/98 backdrop-blur-md rounded-2xl border border-emerald-200 shadow-lg p-3 flex items-center gap-3">
            <div
              onClick={scrollToOrderForm}
              className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 overflow-hidden shrink-0 cursor-pointer"
            >
              <ProductThumbnail product={product} imgClassName="p-1" />
            </div>

            <div
              onClick={scrollToOrderForm}
              className="min-w-0 flex-1 cursor-pointer space-y-0.5"
            >
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <p className="text-xs font-extrabold text-slate-900 truncate">
                  {currentSocialProofBuyer.name}{' '}
                  <span className="font-semibold text-slate-500">
                    ({currentSocialProofBuyer.location})
                  </span>
                </p>
              </div>
              <p className="text-[11px] font-bold text-emerald-800 truncate">
                এই প্রোডাক্টটি অর্ডার করেছেন ✓
              </p>
              <p className="text-[10px] font-semibold text-slate-400">
                {currentSocialProofBuyer.timeAgo} · ক্যাশ অন ডেলিভারি
              </p>
            </div>

            <button
              type="button"
              onClick={e => {
                e.stopPropagation();
                setIsSocialProofDismissed(true);
              }}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 shrink-0 cursor-pointer self-start"
              title="নোটিফিকেশন বন্ধ করুন"
              aria-label="Close notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* SMART STICKY FLOATING "অর্ডার কনফার্ম করুন" BUTTON (With Configurable ON/OFF Total Price & Switchable Animation Styles) */}
      {/* Visible when customer is near top of page; automatically hides when the real submit button enters the viewport */}
      {!confirmedOrder && (
        <div
          className={`fixed bottom-3.5 left-3 right-3 z-40 pointer-events-none transition-all duration-300 ${
            isMainSubmitVisible
              ? 'translate-y-16 opacity-0'
              : 'translate-y-0 opacity-100'
          }`}
        >
          <div className="max-w-md mx-auto pointer-events-auto">
            <div
              className={
                floatingBtnAnimation === 'cart_beam' ||
                floatingBtnAnimation === 'combo_beam'
                  ? `lp-floating-cart-beam-wrapper ${
                      floatingBtnAnimation === 'combo_beam'
                        ? 'lp-floating-combo-pulse'
                        : ''
                    }`
                  : 'w-full'
              }
            >
              <button
                type="button"
                onClick={handleConfirmOrder}
                disabled={isMainSubmitVisible || isSubmitting || availableStock <= 0}
                className={`relative z-10 w-full min-h-[50px] sm:min-h-[52px] py-3 sm:py-3.5 px-3.5 sm:px-5 bg-[#c30000] hover:bg-[#9e0000] disabled:opacity-60 text-white font-extrabold text-[14px] min-[380px]:text-[15px] sm:text-lg rounded-2xl flex items-center justify-center gap-1.5 sm:gap-2 whitespace-nowrap transition-all cursor-pointer active:scale-[0.97] ${
                  floatingBtnAnimation === 'jump'
                    ? 'animate-cta-jump border border-white/30 shadow-lg'
                    : floatingBtnAnimation === 'login_shine'
                    ? 'lp-btn-red-shine lp-floating-login-glow border border-white/35'
                    : floatingBtnAnimation === 'cart_beam'
                    ? 'border border-white/15 shadow-md'
                    : floatingBtnAnimation === 'combo_beam'
                    ? 'lp-btn-red-shine border border-white/20'
                    : floatingBtnAnimation === 'glow_pulse'
                    ? 'animate-order-cta-attention border border-white/30 shadow-lg'
                    : 'border border-white/30 shadow-lg'
                }`}
              >
                <CheckCircle2 className="w-4 h-4 min-[380px]:w-5 min-[380px]:h-5 shrink-0" />
                <span className="tabular-nums whitespace-nowrap">
                  {availableStock <= 0
                    ? 'বর্তমানে স্টকে নেই (স্টক শেষ)'
                    : isSubmitting
                    ? 'অর্ডার প্রসেস হচ্ছে...'
                    : showFloatingBtnPrice
                    ? `অর্ডার কনফার্ম করুন (${formatCurrency(grandTotal)})`
                    : 'অর্ডার কনফার্ম করুন'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================================
          SEPARATE LANDING PAGE SPIN THE WHEEL AUTO-POPUP MODAL (Bright Light Theme)
         ========================================================================== */}
      {showSpinModal && (
        <div
          className="fixed inset-0 z-[75] flex items-center justify-center p-3 sm:p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in overflow-y-auto"
          onClick={handleCloseSpinModal}
        >
          <div
            className="relative w-full max-w-md rounded-3xl bg-gradient-to-br from-[#FFFDF9] via-[#FFF7ED] to-[#FDF2F8] text-slate-900 border-2 border-amber-300/90 shadow-[0_25px_70px_-15px_rgba(245,158,11,0.35)] p-5 sm:p-6 overflow-hidden my-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="pointer-events-none absolute -top-24 -left-24 w-56 h-56 rounded-full bg-amber-300/30 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -right-24 w-56 h-56 rounded-full bg-rose-300/30 blur-3xl" />

            <button
              type="button"
              onClick={handleCloseSpinModal}
              className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-white hover:bg-rose-50 text-slate-500 hover:text-rose-600 flex items-center justify-center border border-amber-200 shadow-xs transition-colors cursor-pointer z-20"
              title="কেটে দিন"
            >
              <X className="w-4 h-4" />
            </button>

            {isAdminViewing && (
              <div className="mb-3 flex flex-wrap items-center justify-center gap-1.5 relative z-10">
                <button
                  type="button"
                  onClick={() => {
                    setSpinConfigDraft(spinWheelConfig);
                    setSpinAdminTab('settings');
                    setShowSpinAdminModal(true);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[11px] font-extrabold transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>অ্যাডমিন কন্ট্রোল ও লিডস ({storedSpinLeads.length})</span>
                </button>
                <button
                  type="button"
                  onClick={handleResetLandingSpinLockForAdmin}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold transition-colors cursor-pointer"
                  title="অ্যাডমিন টেস্ট স্পিন লক রিসেট করুন"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>টেস্ট রিসেট</span>
                </button>
              </div>
            )}

            <div className="text-center space-y-1.5 mb-3 relative z-10">
              <div className="flex justify-center pb-0.5">
                <div className="spin-badge-focus-wrapper">
                  <span className="relative z-10 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full spin-badge-focus-inner btn-premium-shine text-white text-xs sm:text-[13px] font-extrabold tracking-wide shadow-sm">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-200 animate-spin shrink-0 relative z-10" />
                    <span className="relative z-10 drop-shadow-xs">{spinWheelConfig.badgeText}</span>
                    <Gift className="w-3.5 h-3.5 text-amber-200 animate-bounce shrink-0 relative z-10" />
                  </span>
                </div>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight leading-snug">
                {spinWheelConfig.titleText}
              </h3>
              <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                {spinWheelConfig.subtitleText}
              </p>
            </div>

            {/* Interactive Festive Animated Spinning Wheel */}
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 mx-auto my-2 flex items-center justify-center">
              {/* Outer Ambient Colorful Glow */}
              <div className="pointer-events-none absolute -inset-2 rounded-full bg-gradient-to-r from-rose-500/25 via-amber-400/30 to-violet-500/25 blur-xl animate-pulse" />

              {/* Top Pointer Arrow with Tick Animation while Spinning */}
              <div
                className={`absolute -top-3.5 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center origin-top ${
                  isSpinning ? 'animate-wheel-pointer-tick' : ''
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-gradient-to-b from-amber-300 to-amber-500 border-2 border-white shadow-md -mb-1.5 z-10" />
                <div className="w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[28px] border-t-[#e11d48] drop-shadow-[0_4px_8px_rgba(225,29,72,0.5)]" />
              </div>

              {/* Outer Golden Casino Rim with 16 Animated Blinking LED Bulbs */}
              <div className="w-full h-full rounded-full p-3 bg-gradient-to-tr from-amber-500 via-yellow-300 to-rose-500 shadow-[0_14px_38px_rgba(225,29,72,0.28)] border-4 border-white relative flex items-center justify-center">
                {Array.from({ length: 16 }).map((_, dIdx) => (
                  <div
                    key={dIdx}
                    className="absolute inset-1 pointer-events-none flex justify-center items-start"
                    style={{ transform: `rotate(${dIdx * 22.5}deg)` }}
                  >
                    <span
                      className={`w-2.5 h-2.5 rounded-full border border-white/80 ${
                        dIdx % 2 === 0
                          ? 'bg-yellow-200 animate-wheel-led-even'
                          : 'bg-rose-500 animate-wheel-led-odd'
                      }`}
                    />
                  </div>
                ))}

                <div
                  className="w-full h-full rounded-full relative overflow-hidden border-4 border-white shadow-inner"
                  style={{
                    transform: `rotate(${wheelRotation}deg)`,
                    transition: isSpinning
                      ? 'transform 4.1s cubic-bezier(0.14, 0.85, 0.18, 1)'
                      : 'none',
                    background: `conic-gradient(${spinWheelSlices
                      .map((s, idx) => {
                        const deg = 360 / Math.max(1, spinWheelSlices.length);
                        return `${s.color} ${idx * deg}deg ${(idx + 1) * deg}deg`;
                      })
                      .join(', ')})`
                  }}
                >
                  {/* Subtle Glossy Overlay on Wheel */}
                  <div
                    className="pointer-events-none absolute inset-0 rounded-full"
                    style={{
                      background:
                        'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.22) 0%, transparent 60%)'
                    }}
                  />

                  {/* Slice Divider Lines */}
                  {spinWheelSlices.map((slice, idx) => {
                    const deg = 360 / Math.max(1, spinWheelSlices.length);
                    return (
                      <div
                        key={`lp_line_${slice.id}_${idx}`}
                        className="absolute top-0 bottom-1/2 left-1/2 w-[2px] -translate-x-1/2 bg-white/75 origin-bottom pointer-events-none"
                        style={{ transform: `rotate(${idx * deg}deg)` }}
                      />
                    );
                  })}

                  {/* Slice Prize Labels */}
                  {spinWheelSlices.map((slice, idx) => {
                    const deg = 360 / Math.max(1, spinWheelSlices.length);
                    const centerAngle = idx * deg + deg / 2;
                    return (
                      <div
                        key={slice.id || idx}
                        className="absolute inset-0 pointer-events-none flex items-start justify-center pt-4 sm:pt-5"
                        style={{ transform: `rotate(${centerAngle}deg)` }}
                      >
                        <span className="px-2.5 py-0.5 rounded-full bg-white/95 text-slate-900 border border-amber-300 font-extrabold text-[10px] sm:text-[11px] tracking-tight shadow-sm max-w-[92px] truncate">
                          {slice.shortLabel}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Center Hub Button */}
                <button
                  type="button"
                  disabled={isSpinning || Boolean(wonSpinSlice)}
                  onClick={handleSpinTheWheel}
                  className="absolute z-20 w-15 h-15 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-white via-amber-50 to-amber-200 text-[#c30000] font-extrabold text-xs border-4 border-amber-400 flex flex-col items-center justify-center cursor-pointer active:scale-95 disabled:opacity-75 disabled:cursor-not-allowed animate-spin-hub-pulse"
                >
                  <Gift className="w-4 h-4 text-[#e11d48] -mb-0.5" />
                  <span className="text-[10px] font-black tracking-wider">
                    {isSpinning ? '...' : wonSpinSlice ? 'DONE' : 'SPIN'}
                  </span>
                </button>
              </div>
            </div>

            {/* Result or Customer Input Form */}
            {wonSpinSlice && !isSpinning ? (
              <div className="mt-4 p-4 rounded-2xl bg-white border-2 border-emerald-300 text-center space-y-3 shadow-sm animate-fade-in relative z-10">
                <div className="space-y-1">
                  <p className="text-xs font-extrabold text-emerald-700 uppercase tracking-wider">
                    🎉 অভিনন্দন! আপনি জিতেছেন:
                  </p>
                  <p className="text-lg sm:text-xl font-black text-slate-900">
                    {wonSpinSlice.label}
                  </p>
                </div>

                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs font-mono font-bold">
                  <span>কুপন কোড: {wonSpinSlice.code}</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(wonSpinSlice.code);
                      showToast('কুপন কোড কপি হয়েছে!', 'info');
                    }}
                    className="p-1 rounded hover:bg-amber-200/60 text-amber-700 cursor-pointer"
                    title="কপি করুন"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>

                {dailySpinLock?.used ? (
                  <div className="space-y-2">
                    <p className="text-[11px] font-bold text-amber-800 bg-amber-100/80 border border-amber-300 rounded-lg px-2.5 py-1.5">
                      ✓ আপনি আপনার অর্ডারে{dailySpinLock.usedOrderNo ? ` (#${dailySpinLock.usedOrderNo})` : ''} এই স্পিন অফারটি ইতিমধ্যে ব্যবহার করেছেন। (স্পিন অফার শুধুমাত্র ১টি অর্ডারেই প্রযোজ্য)
                    </p>
                    <button
                      type="button"
                      onClick={handleCloseSpinModal}
                      className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-xs cursor-pointer transition-colors"
                    >
                      ঠিক আছে, বন্ধ করুন
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <p className="text-[11px] font-semibold text-slate-600">
                      এখনই অর্ডার করুন! চেকআউট বিলে এই ছাড়টি স্বয়ংক্রিয়ভাবে যুক্ত হবে।
                    </p>
                    <div className="spin-reward-beam-wrapper">
                      <button
                        type="button"
                        onClick={handleClaimSpinReward}
                        className="group relative z-10 w-full py-3 px-5 rounded-[13.5px] btn-spin-reward-cta btn-premium-shine text-white font-extrabold text-sm sm:text-base cursor-pointer active:scale-[0.98] transition-all flex items-center justify-center gap-2.5"
                      >
                        <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-200 shrink-0 animate-bounce relative z-10" />
                        <span className="relative z-10 tracking-wide drop-shadow-xs">
                          {spinWheelConfig.claimButtonText}
                        </span>
                        <span className="relative z-10 w-7 h-7 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-sm group-hover:translate-x-1 transition-transform shrink-0">
                          <ArrowRight className="w-4 h-4 stroke-[2.75]" />
                        </span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="mt-3 space-y-2.5 relative z-10">
                <div className="p-3.5 rounded-2xl bg-white/95 border-2 border-amber-200/90 shadow-xs space-y-2.5 text-left">
                  <p className="text-xs font-extrabold text-[#c30000] flex items-center justify-center gap-1.5 text-center">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>স্পিন করতে আপনার নাম ও মোবাইল নাম্বার দিন:</span>
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-extrabold text-slate-700 mb-1">
                        আপনার নাম <span className="text-[#c30000]">*</span>
                      </label>
                      <input
                        type="text"
                        value={spinCustomerName}
                        onChange={e => {
                          setSpinCustomerName(e.target.value);
                          if (spinFormError) setSpinFormError('');
                        }}
                        disabled={isSpinning}
                        placeholder="আপনার নাম লিখুন"
                        className="w-full px-3 py-2 rounded-xl bg-amber-50/40 border border-slate-300 text-slate-900 placeholder:text-slate-400 text-xs font-bold focus:outline-none focus:border-[#c30000] focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-extrabold text-slate-700 mb-1">
                        মোবাইল নাম্বার (১১ ডিজিট) <span className="text-[#c30000]">*</span>
                      </label>
                      <input
                        type="tel"
                        inputMode="numeric"
                        maxLength={14}
                        value={spinCustomerPhone}
                        onChange={e => {
                          setSpinCustomerPhone(e.target.value);
                          if (spinFormError) setSpinFormError('');
                        }}
                        disabled={isSpinning}
                        placeholder="017XXXXXXXX"
                        className="w-full px-3 py-2 rounded-xl bg-amber-50/40 border border-slate-300 text-slate-900 placeholder:text-slate-400 text-xs font-mono font-extrabold focus:outline-none focus:border-[#c30000] focus:bg-white transition-colors"
                      />
                    </div>
                  </div>
                  {spinFormError && (
                    <p className="text-[11px] font-bold text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-2.5 py-1.5">
                      ⚠️ {spinFormError}
                    </p>
                  )}
                </div>

                {/* Colorful Animated "স্পিন করুন" Button Matching User Screenshot */}
                <button
                  type="button"
                  onClick={handleSpinTheWheel}
                  disabled={isSpinning}
                  className="group relative w-full py-3.5 px-6 rounded-2xl animate-spin-colorful-btn text-white font-extrabold text-base sm:text-lg shadow-[0_12px_28px_-6px_rgba(225,29,72,0.55)] hover:shadow-[0_16px_34px_-6px_rgba(225,29,72,0.7)] border border-white/30 cursor-pointer transition-all active:scale-[0.98] disabled:opacity-65 overflow-hidden flex items-center justify-center gap-3"
                >
                  <span className="pointer-events-none absolute inset-y-0 w-24 bg-gradient-to-r from-transparent via-white/35 to-transparent animate-spin-btn-shimmer" />
                  <Sparkles className="w-5 h-5 text-yellow-200 shrink-0 animate-pulse relative z-10" />
                  <span className="relative z-10 tracking-wide drop-shadow-xs">
                    {isSpinning ? 'চাকা ঘুরছে...' : 'স্পিন করুন'}
                  </span>
                  <span className="relative z-10 w-8 h-8 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-md group-hover:translate-x-1 transition-transform shrink-0">
                    <ArrowRight className="w-4 h-4 stroke-[2.75]" />
                  </span>
                </button>

                {/* Security & Verification Note Below Spin Button */}
                <div className="flex items-center justify-center gap-1.5 text-[11px] sm:text-xs font-bold text-slate-600 px-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>আপনার নাম ও ফোন নম্বর পুরস্কার যাচাই করতে ব্যবহার করা হবে।</span>
                </div>

                <button
                  type="button"
                  onClick={handleCloseSpinModal}
                  disabled={isSpinning}
                  className="w-full py-1 text-center text-[11px] font-bold text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                >
                  এখন নয়, ধন্যবাদ — বন্ধ করুন
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================================================
          LANDING PAGE SPIN THE WHEEL ADMIN CONTROL PANEL MODAL (Settings + Leads)
         ========================================================================== */}
      {isAdminViewing && showSpinAdminModal && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in"
          onClick={() => setShowSpinAdminModal(false)}
        >
          <div
            className="relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl bg-white text-slate-900 border border-slate-200 shadow-2xl overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-amber-50 via-white to-rose-50">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 font-bold">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-extrabold text-slate-900">
                    ল্যান্ডিং পেজ স্পিন দ্য হুইল কন্ট্রোল প্যানেল (আলাদা সেটিংস)
                  </h3>
                  <p className="text-xs text-slate-500">
                    শুধুমাত্র ল্যান্ডিং পেজের জন্য স্পিন হুইল ON/OFF, অফার স্লাইস এবং কাস্টমার নাম্বার লিস্ট নিয়ন্ত্রণ করুন
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const next = !productLandingSpinEnabled;
                    updateProduct(product.id, { landingSpinWheelEnabled: next });
                    if (next && currentBusiness.landingSpinWheelEnabled === false) {
                      updateBusiness({ landingSpinWheelEnabled: true });
                    }
                    showToast(
                      next
                        ? 'এই ল্যান্ডিং পেজে স্পিন হুইল চালু (ON) করা হয়েছে'
                        : 'এই ল্যান্ডিং পেজে স্পিন হুইল বন্ধ (OFF) করা হয়েছে',
                      'info'
                    );
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border cursor-pointer transition-colors ${
                    spinWheelEnabled
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-200 text-slate-700 border-slate-300'
                  }`}
                >
                  {spinWheelEnabled ? 'স্পিন হুইল: চালু (ON)' : 'স্পিন হুইল: বন্ধ (OFF)'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowSpinAdminModal(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="px-5 pt-3 border-b border-slate-200 flex items-center justify-between gap-2 bg-slate-50/70">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSpinAdminTab('settings')}
                  className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-extrabold border-b-2 transition-colors cursor-pointer ${
                    spinAdminTab === 'settings'
                      ? 'border-amber-600 text-amber-700 bg-white'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ⚙️ হুইল টেক্সট ও অফার সেটিংস
                </button>
                <button
                  type="button"
                  onClick={() => setSpinAdminTab('leads')}
                  className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-extrabold border-b-2 transition-colors cursor-pointer ${
                    spinAdminTab === 'leads'
                      ? 'border-amber-600 text-amber-700 bg-white'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  📋 ল্যান্ডিং পেজ স্পিন কাস্টমার লিস্ট ({storedSpinLeads.length})
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  setShowSpinAdminModal(false);
                  setShowSpinModal(true);
                }}
                className="mb-1.5 px-3 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-extrabold cursor-pointer"
              >
                👁️ হুইল প্রিভিউ দেখুন
              </button>
            </div>

            {spinAdminTab === 'settings' ? (
              <div className="p-5 overflow-y-auto flex-1 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 bg-amber-50/50 border border-amber-200/80 rounded-2xl p-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      উপরের ব্যাজ টেক্সট (Badge Text):
                    </label>
                    <input
                      type="text"
                      value={spinConfigDraft.badgeText}
                      onChange={e =>
                        setSpinConfigDraft(prev => ({ ...prev, badgeText: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      প্রধান শিরোনাম (Main Title):
                    </label>
                    <input
                      type="text"
                      value={spinConfigDraft.titleText}
                      onChange={e =>
                        setSpinConfigDraft(prev => ({ ...prev, titleText: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      সাব-টাইটেল / বিবরণ (Subtitle Text):
                    </label>
                    <input
                      type="text"
                      value={spinConfigDraft.subtitleText}
                      onChange={e =>
                        setSpinConfigDraft(prev => ({ ...prev, subtitleText: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-semibold text-slate-800"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      পুরস্কার গ্রহণের বাটন টেক্সট (Claim Button Text):
                    </label>
                    <input
                      type="text"
                      value={spinConfigDraft.claimButtonText || ''}
                      onChange={e =>
                        setSpinConfigDraft(prev => ({ ...prev, claimButtonText: e.target.value }))
                      }
                      placeholder="অফারটি গ্রহণ করে অর্ডার করুন"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-extrabold text-rose-700"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      ল্যান্ডিং পেজে ঢোকার কত সেকেন্ড পর অটো আসবে?
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={spinConfigDraft.autoPopupDelaySec}
                      onChange={e =>
                        setSpinConfigDraft(prev => ({
                          ...prev,
                          autoPopupDelaySec: Math.max(1, Number(e.target.value) || 4)
                        }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">
                      একই কাস্টমারকে কত দিনে ১ বার দেখাবে?
                    </label>
                    <select
                      value={spinConfigDraft.cooldownDays}
                      onChange={e =>
                        setSpinConfigDraft(prev => ({
                          ...prev,
                          cooldownDays: Number(e.target.value) || 7
                        }))
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm font-bold text-slate-900"
                    >
                      <option value={1}>১ দিনে ১ বার (Daily Once)</option>
                      <option value={3}>৩ দিনে ১ বার</option>
                      <option value={7}>৭ দিনে ১ বার (Recommended)</option>
                      <option value={15}>১৫ দিনে ১ বার</option>
                      <option value={30}>৩০ দিনে ১ বার</option>
                    </select>
                  </div>
                </div>

                {/* Wheel Slices Editor */}
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-xs sm:text-sm font-extrabold text-slate-800">
                        🎡 ল্যান্ডিং পেজ স্পিন হুইলের স্লাইস / পুরস্কার সমূহ ({(spinConfigDraft.slices || []).length} টি)
                      </h4>
                      <p className="text-[11px] text-slate-600 font-semibold mt-0.5">
                        🔓 আনলক ({(spinConfigDraft.slices || []).filter(s => !s.locked).length}টি): কাস্টমার বারবার পাবে • 🔒 লক ({(spinConfigDraft.slices || []).filter(s => s.locked).length}টি): চাকায় দেখাবে কিন্তু কেউ পাবে না
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setSpinConfigDraft(prev => ({
                          ...prev,
                          slices: [
                            ...(prev.slices || []),
                            {
                              id: `lp_sw_${Date.now()}`,
                              shortLabel: '৳৫০ ছাড়',
                              label: '৳৫০ স্পেশাল ডিসকাউন্ট',
                              type: 'flat',
                              value: 50,
                              code: `LP${(prev.slices || []).length + 1}`,
                              color: '#059669',
                              locked: false
                            }
                          ]
                        }))
                      }
                      className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-extrabold cursor-pointer"
                    >
                      + নতুন অফার যোগ করুন
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {(spinConfigDraft.slices || []).map((slice, idx) => (
                      <div
                        key={slice.id || idx}
                        className={`p-3 rounded-2xl border grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center ${
                          slice.locked
                            ? 'bg-rose-50/50 border-rose-200'
                            : 'bg-slate-50/70 border-slate-200'
                        }`}
                      >
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            চাকার লেখা (Short)
                          </label>
                          <input
                            type="text"
                            value={slice.shortLabel}
                            onChange={e => {
                              const val = e.target.value;
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, shortLabel: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-900"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            পূর্ণ অফার নাম
                          </label>
                          <input
                            type="text"
                            value={slice.label}
                            onChange={e => {
                              const val = e.target.value;
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, label: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            অফারের ধরন
                          </label>
                          <select
                            value={slice.type}
                            onChange={e => {
                              const val = e.target.value as SpinWheelSliceConfig['type'];
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, type: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-800"
                          >
                            <option value="flat">টাকা ছাড় (৳)</option>
                            <option value="percent">শতাংশ ছাড় (%)</option>
                            <option value="free_delivery">ফ্রি ডেলিভারি</option>
                          </select>
                        </div>
                        <div className="sm:col-span-1">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            মান
                          </label>
                          <input
                            type="number"
                            disabled={slice.type === 'free_delivery'}
                            value={slice.type === 'free_delivery' ? 0 : slice.value}
                            onChange={e => {
                              const val = Number(e.target.value) || 0;
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, value: val } : s
                                )
                              }));
                            }}
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white disabled:bg-slate-100 text-xs font-bold text-slate-900"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                            লক / আনলক স্ট্যাটাস
                          </label>
                          <button
                            type="button"
                            onClick={() =>
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, locked: !s.locked } : s
                                )
                              }))
                            }
                            className={`w-full px-2 py-1.5 rounded-lg text-[11px] font-extrabold border flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                              slice.locked
                                ? 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200'
                                : 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200'
                            }`}
                          >
                            <span>{slice.locked ? '🔒 লক (পাবে না)' : '🔓 আনলক (পাবে)'}</span>
                          </button>
                        </div>
                        <div className="sm:col-span-2 flex items-center justify-end gap-1.5 pt-3 sm:pt-4">
                          <input
                            type="text"
                            value={slice.code}
                            onChange={e => {
                              const val = e.target.value.toUpperCase();
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, code: val } : s
                                )
                              }));
                            }}
                            placeholder="CODE"
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono font-bold text-slate-900"
                          />
                          <input
                            type="color"
                            value={slice.color || '#059669'}
                            onChange={e => {
                              const val = e.target.value;
                              setSpinConfigDraft(prev => ({
                                ...prev,
                                slices: (prev.slices || []).map((s, i) =>
                                  i === idx ? { ...s, color: val } : s
                                )
                              }));
                            }}
                            className="w-7 h-7 rounded cursor-pointer border border-slate-300 shrink-0"
                          />
                          {(spinConfigDraft.slices || []).length > 2 && (
                            <button
                              type="button"
                              onClick={() =>
                                setSpinConfigDraft(prev => ({
                                  ...prev,
                                  slices: (prev.slices || []).filter((_, i) => i !== idx)
                                }))
                              }
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setSpinConfigDraft(DEFAULT_LANDING_SPIN_WHEEL_CONFIG)}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                  >
                    ডিফল্ট ৬টি পুরস্কার (৪ আনলক, ২ লক)
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveSpinConfigDraft}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-extrabold shadow-md cursor-pointer"
                  >
                    💾 সেটিংস সংরক্ষণ করুন
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <input
                    type="text"
                    value={spinLeadSearch}
                    onChange={e => setSpinLeadSearch(e.target.value)}
                    placeholder="নাম, মোবাইল নাম্বার বা কুপন দিয়ে খুঁজুন..."
                    className="flex-1 min-w-[200px] px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm focus:outline-none focus:border-amber-500"
                  />
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-extrabold">
                    মোট এন্ট্রি: {filteredSpinLeads.length} জন
                  </span>
                </div>

                <div className="p-4 sm:p-5 overflow-y-auto flex-1">
                  {filteredSpinLeads.length === 0 ? (
                    <div className="text-center py-12 space-y-2">
                      <Gift className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-sm font-bold text-slate-600">
                        এখনো কোনো ল্যান্ডিং পেজ ভিজিটর স্পিন করেননি
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-2xl border border-slate-200">
                      <table className="w-full text-left border-collapse text-xs sm:text-sm">
                        <thead>
                          <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                            <th className="py-3 px-3.5">কাস্টমারের নাম</th>
                            <th className="py-3 px-3.5">মোবাইল নাম্বার</th>
                            <th className="py-3 px-3.5">জেতা অফার / পুরস্কার</th>
                            <th className="py-3 px-3.5">কুপন</th>
                            <th className="py-3 px-3.5">তারিখ ও সময়</th>
                            <th className="py-3 px-3.5 text-right">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 bg-white">
                          {filteredSpinLeads.map(lead => {
                            const dispName = lead.customerName || lead.name || 'কাস্টমার';
                            const dispPhone = lead.customerPhone || lead.phone || '';
                            const dispReward = lead.rewardLabel || lead.prizeLabel || '';
                            const dispCode = lead.couponCode || lead.prizeCode || '';
                            return (
                              <tr key={lead.id} className="hover:bg-slate-50/80 transition-colors">
                                <td className="py-3 px-3.5 font-bold text-slate-900">
                                  {dispName}
                                </td>
                                <td className="py-3 px-3.5">
                                  <div className="inline-flex items-center gap-1.5 font-mono font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                                    <span>{dispPhone}</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        navigator.clipboard?.writeText(dispPhone);
                                        showToast('মোবাইল নাম্বার কপি হয়েছে!', 'info');
                                      }}
                                      className="text-indigo-500 hover:text-indigo-800 cursor-pointer"
                                    >
                                      <Copy className="w-3 h-3" />
                                    </button>
                                  </div>
                                </td>
                                <td className="py-3 px-3.5">
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-extrabold">
                                    🎁 {dispReward}
                                  </span>
                                </td>
                                <td className="py-3 px-3.5 font-mono font-bold text-amber-700">
                                  {dispCode}
                                </td>
                                <td className="py-3 px-3.5 text-xs text-slate-500">
                                  {new Date(lead.createdAt).toLocaleString('bn-BD', {
                                    dateStyle: 'medium',
                                    timeStyle: 'short'
                                  })}
                                </td>
                                <td className="py-3 px-3.5 text-right">
                                  <div className="inline-flex items-center gap-1.5">
                                    <a
                                      href={`tel:${dispPhone}`}
                                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
                                    >
                                      কল
                                    </a>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteSpinLead(lead.id)}
                                      className="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold cursor-pointer"
                                    >
                                      মুছুন
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 🛡️ Clean Daily Order Limit Reached Popup Modal */}
      {orderLimitPopupData && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs animate-page-rise"
          onClick={() => setOrderLimitPopupData(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full p-6 border border-rose-200 shadow-2xl text-center relative overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            {/* Top-Right Cross (X) Button to Close Popup */}
            <button
              type="button"
              onClick={() => setOrderLimitPopupData(null)}
              className="absolute top-3.5 right-3.5 w-9 h-9 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 flex items-center justify-center transition-all cursor-pointer shadow-2xs"
              aria-label="Close"
              title="পপআপ বন্ধ করুন"
            >
              <X className="w-4.5 h-4.5 stroke-[2.5]" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-3.5 shadow-2xs">
              <ShieldCheck className="w-7 h-7" />
            </div>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-[11px] font-extrabold mb-2">
              {orderLimitPopupData.blockType === 'same_product'
                ? `একই পণ্য দিনে সর্বোচ্চ ${
                    currentBusiness.dailySameProductMaxCount ??
                    orderLimitPopupData.sameProductMaxCount
                  } বার অর্ডার করা যাবে`
                : `একই পণ্য ${
                    currentBusiness.dailySameProductMaxCount ??
                    orderLimitPopupData.sameProductMaxCount
                  } বার • মোট সর্বোচ্চ ${orderLimitPopupData.maxCount}টি অর্ডার/দিন`}
            </span>

            <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
              {(currentBusiness.dailyOrderLimitTitle || '').trim() || orderLimitPopupData.title}
            </h3>

            <p className="mt-2.5 text-xs sm:text-sm font-medium text-slate-600 leading-relaxed whitespace-pre-line">
              {(currentBusiness.dailyOrderLimitMessage || '').trim() || orderLimitPopupData.message}
            </p>

            {/* Quick Admin Inline Control if Admin is logged in */}
            {isAdminViewing && (
              <div className="mt-4 pt-3 border-t border-slate-200 text-left">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-extrabold text-indigo-700">
                    ⚙️ অ্যাডমিন কুইক কন্ট্রোল:
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setIsEditingLimitPopupInline(prev => !prev)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[11px] font-bold cursor-pointer"
                    >
                      {isEditingLimitPopupInline ? 'বন্ধ করুন' : '✏️ মেসেজ ও লিমিট এডিট'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateBusiness({ dailyOrderLimitEnabled: false });
                        setOrderLimitPopupData(null);
                        showToast('দৈনিক অর্ডার লিমিট সাময়িকভাবে বন্ধ (OFF) করা হয়েছে!', 'info');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-bold cursor-pointer"
                    >
                      লিমিট OFF করুন
                    </button>
                  </div>
                </div>

                {isEditingLimitPopupInline && (
                  <div className="mt-2.5 space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-slate-700">একই প্রোডাক্ট সর্বোচ্চ:</span>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 5].map(n => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => setInlineLimitSameProdMaxCount(n)}
                            className={`px-2 py-0.5 rounded-md text-[11px] font-extrabold border cursor-pointer ${
                              inlineLimitSameProdMaxCount === n
                                ? 'bg-rose-600 text-white border-rose-600'
                                : 'bg-white text-slate-700 border-slate-300'
                            }`}
                          >
                            {n} বার
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-slate-700">সব মিলিয়ে মোট অর্ডার:</span>
                      <div className="flex items-center gap-1">
                        {[2, 3, 5, 8, 10].map(n => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => setInlineLimitMaxCount(n)}
                            className={`px-2 py-0.5 rounded-md text-[11px] font-extrabold border cursor-pointer ${
                              inlineLimitMaxCount === n
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white text-slate-700 border-slate-300'
                            }`}
                          >
                            {n}টি
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="text"
                      value={inlineLimitTitle}
                      onChange={e => setInlineLimitTitle(e.target.value)}
                      placeholder="পপআপ টাইটেল"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
                    />
                    <textarea
                      rows={2}
                      value={inlineLimitMessage}
                      onChange={e => setInlineLimitMessage(e.target.value)}
                      placeholder="পপআপ মেসেজ"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const nextSameMax = Math.max(1, Number(inlineLimitSameProdMaxCount) || 2);
                        const nextTotalMax = Math.max(1, Number(inlineLimitMaxCount) || 5);
                        updateBusiness({
                          dailyOrderLimitEnabled: true,
                          dailySameProductMaxCount: nextSameMax,
                          dailyOrderMaxCount: nextTotalMax,
                          dailyOrderLimitTitle: inlineLimitTitle.trim() || orderLimitPopupData.title,
                          dailyOrderLimitMessage:
                            inlineLimitMessage.trim() || orderLimitPopupData.message
                        });
                        setOrderLimitPopupData(prev =>
                          prev
                            ? {
                                ...prev,
                                sameProductMaxCount: nextSameMax,
                                maxCount: nextTotalMax,
                                title: inlineLimitTitle.trim() || prev.title,
                                message: inlineLimitMessage.trim() || prev.message
                              }
                            : null
                        );
                        setIsEditingLimitPopupInline(false);
                        showToast('পপআপ মেসেজ ও লিমিট আপডেট হয়েছে!', 'success');
                      }}
                      className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold cursor-pointer"
                    >
                      💾 সেভ করুন
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Helpline Call + Animated WhatsApp Button (Thank You / Login Shine & Beam Effect) */}
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
              <a
                href={`tel:${supportPhone}`}
                className="min-h-[44px] px-4 py-2.5 rounded-[12px] bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-sm transition-colors whitespace-nowrap"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>হেল্পলাইনে কল করুন</span>
              </a>

              <div className="wa-confirm-beam-wrapper">
                <a
                  href={`https://wa.me/${formattedWaNumber}?text=${encodeURIComponent(
                    `আসসালামু আলাইকুম, আমি আপনাদের "${checkoutTargetProduct.nameBn}" প্রোডাক্টটি অর্ডার করতে চাচ্ছি কিন্তু অর্ডার লিমিট দেখাচ্ছে। অনুগ্রহ করে সাহায্য করবেন।`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="relative z-10 w-full min-h-[44px] py-2.5 px-3.5 bg-gradient-to-r from-[#1fa855] via-[#25D366] to-[#128C7E] hover:from-[#1b944a] hover:to-[#0f7a6e] text-white font-extrabold text-xs sm:text-sm rounded-[12px] flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer btn-premium-shine"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-white shrink-0 animate-bounce"
                    fill="currentColor"
                  >
                    <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824zm-3.423-14.416c-6.627 0-12 5.373-12 12 0 2.625.846 5.059 2.284 7.033l-1.494 4.462 4.614-1.469c1.906 1.249 4.184 1.974 6.596 1.974 6.627 0 12-5.373 12-12s-5.373-12-12-12z" />
                  </svg>
                  <span>হোয়াটসঅ্যাপে মেসেজ দিন</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
