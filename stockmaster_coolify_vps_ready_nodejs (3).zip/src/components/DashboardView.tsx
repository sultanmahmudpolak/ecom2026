import React, { useEffect, useMemo, useState } from 'react';
import { useApp, normalizeBdPhone } from '../context/AppContext';
import { ProductThumbnail } from './ProductThumbnail';
import {
  ShoppingBag,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Truck,
  Boxes,
  Users,
  Phone,
  MessageCircle,
  ArrowRight,
  ExternalLink,
  Search,
  PlusCircle,
  TrendingUp,
  MapPin,
  Package,
  Calendar,
  Settings,
  Server,
  Rocket,
  Gift,
  Sun,
  Moon,
  Repeat,
  Database,
  Layers,
  Sparkles,
  X
} from 'lucide-react';
import { OnlineOrderStatus, IncompleteOrderStatus } from '../types';

interface DashboardViewProps {
  onNavigate: (view: string) => void;
  onOpenStorefront?: () => void;
  adminTheme?: 'light' | 'dark';
  onSetAdminTheme?: (theme: 'light' | 'dark') => void;
}

const formatBdt = (amount: number): string =>
  `৳${Math.round(Number(amount || 0)).toLocaleString('en-US')}`;

const formatDateTimeEn = (isoString: string): string => {
  if (!isoString) return '—';
  const date = new Date(isoString);
  if (Number.isNaN(date.getTime())) return isoString;
  return date.toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
};

const toBnDigits = (num: number | string): string =>
  String(num).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[Number(d)]);

const formatRelativeTimeAgoBn = (isoString?: string, nowMs: number = Date.now()): string => {
  if (!isoString) return '—';
  const date = new Date(isoString);
  const timeMs = date.getTime();
  if (Number.isNaN(timeMs)) return '—';

  const diffMs = Math.max(0, nowMs - timeMs);
  const totalSeconds = Math.floor(diffMs / 1000);

  if (totalSeconds < 60) {
    return 'এইমাত্র';
  }

  const totalMinutes = Math.floor(totalSeconds / 60);
  if (totalMinutes < 60) {
    return `${toBnDigits(totalMinutes)} মিনিট আগে`;
  }

  const totalHours = Math.floor(totalMinutes / 60);
  const remMinutes = totalMinutes % 60;
  if (totalHours < 24) {
    return remMinutes > 0
      ? `${toBnDigits(totalHours)} ঘণ্টা ${toBnDigits(remMinutes)} মিনিট আগে`
      : `${toBnDigits(totalHours)} ঘণ্টা আগে`;
  }

  const totalDays = Math.floor(totalHours / 24);
  const remHours = totalHours % 24;
  if (totalDays < 30) {
    return remHours > 0
      ? `${toBnDigits(totalDays)} দিন ${toBnDigits(remHours)} ঘণ্টা আগে`
      : `${toBnDigits(totalDays)} দিন আগে`;
  }

  const totalMonths = Math.floor(totalDays / 30);
  const remDays = totalDays % 30;
  return remDays > 0
    ? `${toBnDigits(totalMonths)} মাস ${toBnDigits(remDays)} দিন আগে`
    : `${toBnDigits(totalMonths)} মাস আগে`;
};

const isTodayIso = (isoString: string): boolean => {
  if (!isoString) return false;
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return false;
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
};

const isWithinDaysIso = (isoString: string, days: number): boolean => {
  if (!isoString) return false;
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return false;
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return d.getTime() >= cutoff;
};

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenStorefront,
  adminTheme = 'light',
  onSetAdminTheme
}) => {
  const {
    currentUser,
    currentBusiness,
    products,
    customers,
    onlineOrders,
    incompleteOrders,
    updateOnlineOrderStatus,
    updateIncompleteOrderStatus,
    convertIncompleteToOrder
  } = useApp();

  const [dateRangeFilter, setDateRangeFilter] = useState<'today' | '7days' | 'month' | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dashboardLeadStatusFilter, setDashboardLeadStatusFilter] = useState<
    'all' | IncompleteOrderStatus
  >('abandoned');
  const [convertingLeadId, setConvertingLeadId] = useState<string | null>(null);
  const [nowTick, setNowTick] = useState<number>(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => {
      setNowTick(Date.now());
    }, 30000);
    return () => window.clearInterval(timer);
  }, []);

  // Mobile-friendly workspace tab so mobile users don't have to scroll miles
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<
    'split' | 'orders' | 'leads' | 'products'
  >(() => {
    if (typeof window !== 'undefined' && window.innerWidth < 1024) {
      return 'orders';
    }
    return 'split';
  });

  const openOrdersViewTab = (tab: 'orders' | 'incomplete') => {
    try {
      sessionStorage.setItem('sm_orders_initial_tab', tab);
    } catch {
      // ignore storage errors
    }
    onNavigate('online_orders');
  };

  // Core e-commerce & order metrics
  const stats = useMemo(() => {
    const now = new Date();
    const validOrders = onlineOrders.filter(o => o.orderStatus !== 'cancelled');

    const todayOrders = onlineOrders.filter(o => isTodayIso(o.createdAt));
    const todayValidOrders = todayOrders.filter(o => o.orderStatus !== 'cancelled');
    const todayRevenue = todayValidOrders.reduce((sum, o) => sum + o.grandTotal, 0);
    const todayPendingCount = todayOrders.filter(o => o.orderStatus === 'pending').length;

    const monthOrders = validOrders.filter(o => {
      const d = new Date(o.createdAt);
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    });
    const monthRevenue = monthOrders.reduce((sum, o) => sum + o.grandTotal, 0);

    const totalRevenue = validOrders.reduce((sum, o) => sum + o.grandTotal, 0);

    const pendingOrders = onlineOrders.filter(o => o.orderStatus === 'pending');
    const confirmedOrders = onlineOrders.filter(o => o.orderStatus === 'confirmed');
    const packagingOrders = onlineOrders.filter(o => o.orderStatus === 'packaging');
    const dispatchedOrders = onlineOrders.filter(o => o.orderStatus === 'dispatched');
    const deliveredOrders = onlineOrders.filter(o => o.orderStatus === 'delivered');
    const cancelledOrders = onlineOrders.filter(o => o.orderStatus === 'cancelled');

    const pendingValue = pendingOrders.reduce((sum, o) => sum + o.grandTotal, 0);
    const confirmedValue = confirmedOrders.reduce((sum, o) => sum + o.grandTotal, 0);
    const packagingValue = packagingOrders.reduce((sum, o) => sum + o.grandTotal, 0);
    const dispatchedValue = dispatchedOrders.reduce((sum, o) => sum + o.grandTotal, 0);
    const deliveredValue = deliveredOrders.reduce((sum, o) => sum + o.grandTotal, 0);

    const activeIncomplete = incompleteOrders.filter(
      inc => inc.status === 'abandoned' || inc.status === 'contacted'
    );
    const todayIncomplete = activeIncomplete.filter(inc =>
      isTodayIso(inc.updatedAt || inc.createdAt)
    );
    const recoverableRevenue = activeIncomplete.reduce(
      (sum, inc) => sum + (inc.grandTotal || 0),
      0
    );

    const abandonedOnlyCount = incompleteOrders.filter(inc => inc.status === 'abandoned').length;
    const contactedCount = incompleteOrders.filter(inc => inc.status === 'contacted').length;
    const convertedCount = incompleteOrders.filter(inc => inc.status === 'converted').length;

    const onlineCustomersCount = customers.filter(
      c => c.customerType === 'online' || c.isOnlineCustomer
    ).length;

    const avgOrderValue =
      validOrders.length > 0 ? Math.round(totalRevenue / validOrders.length) : 0;

    let lowStockCount = 0;
    let outOfStockCount = 0;
    products.forEach(p => {
      const totalStock = Object.values(p.stockByOutlet || {}).reduce(
        (sum, qty) => sum + Number(qty || 0),
        0
      );
      if (totalStock <= 0) outOfStockCount += 1;
      else if (totalStock <= (p.lowStockAlert || 15)) lowStockCount += 1;
    });

    // Area & Source Breakdown (across non-cancelled orders)
    let insideDhakaCount = 0;
    let insideDhakaRevenue = 0;
    let outsideDhakaCount = 0;
    let outsideDhakaRevenue = 0;

    let storefrontOrderCount = 0;
    let storefrontOrderRevenue = 0;
    let landingOrderCount = 0;
    let landingOrderRevenue = 0;
    let recoveredOrderCount = 0;
    let recoveredOrderRevenue = 0;

    const outsideChargeThreshold = Number(currentBusiness.outsideDhakaDeliveryCharge || 110);

    validOrders.forEach(o => {
      const areaStr = `${o.deliveryArea || ''} ${o.deliverySlot || ''}`.toLowerCase();
      const isOutside =
        areaStr.includes('outside') ||
        areaStr.includes('বাইরে') ||
        (!areaStr.includes('inside') &&
          !areaStr.includes('ভিতরে') &&
          !areaStr.includes('ভেতরে') &&
          Number(o.deliveryCharge || 0) >= outsideChargeThreshold);

      if (isOutside) {
        outsideDhakaCount += 1;
        outsideDhakaRevenue += o.grandTotal;
      } else {
        insideDhakaCount += 1;
        insideDhakaRevenue += o.grandTotal;
      }

      if (o.orderSource === 'landing_page' || Boolean(o.landingSlug)) {
        landingOrderCount += 1;
        landingOrderRevenue += o.grandTotal;
      } else if (o.orderSource === 'incomplete_recovery') {
        recoveredOrderCount += 1;
        recoveredOrderRevenue += o.grandTotal;
      } else {
        storefrontOrderCount += 1;
        storefrontOrderRevenue += o.grandTotal;
      }
    });

    const totalValidCount = Math.max(1, validOrders.length);
    const insideDhakaPct = validOrders.length > 0 ? Math.round((insideDhakaCount / totalValidCount) * 100) : 0;
    const outsideDhakaPct = validOrders.length > 0 ? 100 - insideDhakaPct : 0;
    const landingOrderPct = validOrders.length > 0 ? Math.round((landingOrderCount / totalValidCount) * 100) : 0;
    const storefrontOrderPct = validOrders.length > 0 ? Math.round((storefrontOrderCount / totalValidCount) * 100) : 0;
    const recoveredOrderPct = validOrders.length > 0 ? Math.max(0, 100 - landingOrderPct - storefrontOrderPct) : 0;

    return {
      todayOrdersCount: todayOrders.length,
      todayRevenue,
      todayPendingCount,
      monthOrdersCount: monthOrders.length,
      monthRevenue,
      totalOrdersCount: onlineOrders.length,
      totalRevenue,
      avgOrderValue,
      pendingCount: pendingOrders.length,
      pendingValue,
      confirmedCount: confirmedOrders.length,
      confirmedValue,
      packagingCount: packagingOrders.length,
      packagingValue,
      dispatchedCount: dispatchedOrders.length,
      dispatchedValue,
      deliveredCount: deliveredOrders.length,
      deliveredValue,
      cancelledCount: cancelledOrders.length,
      activeIncompleteCount: activeIncomplete.length,
      todayIncompleteCount: todayIncomplete.length,
      recoverableRevenue,
      abandonedOnlyCount,
      contactedCount,
      convertedCount,
      onlineCustomersCount,
      lowStockCount,
      outOfStockCount,
      insideDhakaCount,
      insideDhakaRevenue,
      insideDhakaPct,
      outsideDhakaCount,
      outsideDhakaRevenue,
      outsideDhakaPct,
      storefrontOrderCount,
      storefrontOrderRevenue,
      storefrontOrderPct,
      landingOrderCount,
      landingOrderRevenue,
      landingOrderPct,
      recoveredOrderCount,
      recoveredOrderRevenue,
      recoveredOrderPct
    };
  }, [onlineOrders, incompleteOrders, customers, products, currentBusiness.outsideDhakaDeliveryCharge]);

  // Repeat / duplicate phone detection map
  const phoneOrderHistoryMap = useMemo(() => {
    const map: Record<
      string,
      {
        totalOrders: number;
        todayOrders: number;
        deliveredOrders: number;
        cancelledOrders: number;
        incompleteCount: number;
      }
    > = {};

    onlineOrders.forEach(order => {
      const key = normalizeBdPhone(order.customerPhone || '');
      if (!key) return;
      if (!map[key]) {
        map[key] = {
          totalOrders: 0,
          todayOrders: 0,
          deliveredOrders: 0,
          cancelledOrders: 0,
          incompleteCount: 0
        };
      }
      map[key].totalOrders += 1;
      if (isTodayIso(order.createdAt)) {
        map[key].todayOrders += 1;
      }
      if (order.orderStatus === 'delivered') {
        map[key].deliveredOrders += 1;
      }
      if (order.orderStatus === 'cancelled') {
        map[key].cancelledOrders += 1;
      }
    });

    incompleteOrders.forEach(lead => {
      const key = normalizeBdPhone(lead.customerPhone || '');
      if (!key) return;
      if (!map[key]) {
        map[key] = {
          totalOrders: 0,
          todayOrders: 0,
          deliveredOrders: 0,
          cancelledOrders: 0,
          incompleteCount: 0
        };
      }
      if (lead.status !== 'converted') {
        map[key].incompleteCount += 1;
      }
    });

    return map;
  }, [onlineOrders, incompleteOrders]);

  // Filtered Orders for Dashboard
  const filteredDashboardOrders = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return onlineOrders
      .filter(order => {
        if (dateRangeFilter === 'today' && !isTodayIso(order.createdAt)) return false;
        if (dateRangeFilter === '7days' && !isWithinDaysIso(order.createdAt, 7)) return false;
        if (dateRangeFilter === 'month' && !isWithinDaysIso(order.createdAt, 30)) return false;

        if (!q) return true;
        return (
          order.orderNo.toLowerCase().includes(q) ||
          order.customerName.toLowerCase().includes(q) ||
          order.customerPhone.toLowerCase().includes(q) ||
          order.deliveryAddress.toLowerCase().includes(q) ||
          order.items.some(i => i.productName.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [onlineOrders, dateRangeFilter, searchQuery]);

  // Filtered Incomplete Orders for Dashboard
  const filteredDashboardIncomplete = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return incompleteOrders
      .filter(inc => {
        if (dashboardLeadStatusFilter !== 'all' && inc.status !== dashboardLeadStatusFilter) {
          return false;
        }
        const timestamp = inc.updatedAt || inc.createdAt;
        if (dateRangeFilter === 'today' && !isTodayIso(timestamp)) return false;
        if (dateRangeFilter === '7days' && !isWithinDaysIso(timestamp, 7)) return false;
        if (dateRangeFilter === 'month' && !isWithinDaysIso(timestamp, 30)) return false;

        if (!q) return true;
        return (
          (inc.customerName || '').toLowerCase().includes(q) ||
          (inc.customerPhone || '').toLowerCase().includes(q) ||
          (inc.deliveryAddress || '').toLowerCase().includes(q) ||
          inc.items.some(i => i.productName.toLowerCase().includes(q))
        );
      })
      .sort(
        (a, b) =>
          new Date(b.updatedAt || b.createdAt).getTime() -
          new Date(a.updatedAt || a.createdAt).getTime()
      );
  }, [incompleteOrders, dashboardLeadStatusFilter, dateRangeFilter, searchQuery]);

  // Product Stock & Sales Performance
  const productPerformance = useMemo(() => {
    const qtyMap: Record<string, { qty: number; revenue: number }> = {};
    onlineOrders
      .filter(o => o.orderStatus !== 'cancelled')
      .forEach(o => {
        o.items.forEach(item => {
          if (!qtyMap[item.productId]) {
            qtyMap[item.productId] = { qty: 0, revenue: 0 };
          }
          qtyMap[item.productId].qty += item.quantity;
          qtyMap[item.productId].revenue += item.quantity * item.unitPrice;
        });
      });

    return products
      .map(product => {
        const totalStock = Object.values(product.stockByOutlet || {}).reduce(
          (sum, val) => sum + Number(val || 0),
          0
        );
        return {
          product,
          soldQty: qtyMap[product.id]?.qty || 0,
          revenue: qtyMap[product.id]?.revenue || 0,
          stock: totalStock
        };
      })
      .sort((a, b) => b.soldQty - a.soldQty);
  }, [products, onlineOrders]);

  const totalSpinLeadsCount = useMemo(() => {
    const deletedSet = new Set(currentBusiness.deletedSpinLeadIds || []);
    const ids = new Set<string>();
    (currentBusiness.spinWheelLeads || []).forEach(l => {
      if (l?.id && !deletedSet.has(l.id)) ids.add(l.id);
    });
    (currentBusiness.landingSpinWheelLeads || []).forEach(l => {
      if (l?.id && !deletedSet.has(l.id)) ids.add(l.id);
    });
    return ids.size;
  }, [
    currentBusiness.spinWheelLeads,
    currentBusiness.landingSpinWheelLeads,
    currentBusiness.deletedSpinLeadIds
  ]);

  const handleQuickConvertLead = async (leadId: string) => {
    setConvertingLeadId(leadId);
    try {
      await convertIncompleteToOrder(leadId);
    } finally {
      setConvertingLeadId(null);
    }
  };

  const getOrderStatusSelectStyle = (status: OnlineOrderStatus) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-50 text-amber-900 border-amber-300 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-700';
      case 'confirmed':
        return 'bg-sky-50 text-sky-900 border-sky-300 dark:bg-sky-950/70 dark:text-sky-300 dark:border-sky-700';
      case 'packaging':
        return 'bg-indigo-50 text-indigo-900 border-indigo-300 dark:bg-indigo-950/70 dark:text-indigo-300 dark:border-indigo-700';
      case 'dispatched':
        return 'bg-purple-50 text-purple-900 border-purple-300 dark:bg-purple-950/70 dark:text-purple-300 dark:border-purple-700';
      case 'delivered':
        return 'bg-emerald-50 text-emerald-900 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-700';
      case 'cancelled':
        return 'bg-rose-50 text-rose-900 border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-700';
      default:
        return 'bg-slate-50 text-slate-800 border-slate-300 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700';
    }
  };

  const getIncompleteSelectStyle = (status: IncompleteOrderStatus) => {
    switch (status) {
      case 'abandoned':
        return 'bg-rose-50 text-rose-900 border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-700';
      case 'contacted':
        return 'bg-sky-50 text-sky-900 border-sky-300 dark:bg-sky-950/70 dark:text-sky-300 dark:border-sky-700';
      case 'converted':
        return 'bg-emerald-50 text-emerald-900 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-700';
      case 'ignored':
        return 'bg-slate-100 text-slate-600 border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700';
      default:
        return 'bg-slate-50 text-slate-800 border-slate-300';
    }
  };

  const showOrdersPanel = activeWorkspaceTab === 'split' || activeWorkspaceTab === 'orders';
  const showLeadsPanel = activeWorkspaceTab === 'split' || activeWorkspaceTab === 'leads';
  const showProductsPanel = activeWorkspaceTab === 'split' || activeWorkspaceTab === 'products';

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* 1. Responsive 2x2 Mobile / 4-Col Desktop KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        {/* KPI 1: Today's Orders */}
        <button
          type="button"
          onClick={() => {
            setDateRangeFilter(dateRangeFilter === 'today' ? 'all' : 'today');
            if (window.innerWidth < 1024) setActiveWorkspaceTab('orders');
          }}
          className={`text-left rounded-2xl p-3.5 sm:p-4 bg-white dark:bg-slate-900 border transition-all cursor-pointer shadow-2xs ${
            dateRangeFilter === 'today'
              ? 'border-emerald-500 ring-2 ring-emerald-500/20'
              : 'border-slate-200/90 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs font-bold text-slate-500 dark:text-slate-400">
              Today&apos;s Orders
            </span>
            <span className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <ShoppingBag className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2 flex-wrap">
            <span className="text-xl sm:text-2xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {stats.todayOrdersCount}
            </span>
            <span className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
              {formatBdt(stats.todayRevenue)}
            </span>
          </div>
          <p className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums truncate">
            Pending: <strong className="text-slate-800 dark:text-slate-200">{stats.todayPendingCount}</strong> · Total: <strong className="text-slate-800 dark:text-slate-200">{stats.totalOrdersCount}</strong>
          </p>
        </button>

        {/* KPI 2: Abandoned / Incomplete Leads */}
        <button
          type="button"
          onClick={() => {
            if (window.innerWidth < 1024) {
              setActiveWorkspaceTab('leads');
            } else {
              openOrdersViewTab('incomplete');
            }
          }}
          className="text-left rounded-2xl p-3.5 sm:p-4 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-rose-300 dark:hover:border-rose-700 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs font-bold text-slate-500 dark:text-slate-400">
              Incomplete Orders (Leads)
            </span>
            <span className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2 flex-wrap">
            <span className="text-xl sm:text-2xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {stats.activeIncompleteCount}
            </span>
            <span className="text-xs font-bold font-mono text-rose-600 dark:text-rose-400 tabular-nums">
              {formatBdt(stats.recoverableRevenue)}
            </span>
          </div>
          <p className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums truncate">
            Contacted: <strong className="text-sky-600 dark:text-sky-400">{stats.contactedCount}</strong> · Converted: <strong className="text-emerald-600 dark:text-emerald-400">{stats.convertedCount}</strong>
          </p>
        </button>

        {/* KPI 3: Pending Confirmation Queue */}
        <button
          type="button"
          onClick={() => openOrdersViewTab('orders')}
          className="text-left rounded-2xl p-3.5 sm:p-4 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-700 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs font-bold text-slate-500 dark:text-slate-400">
              Pending Confirmation
            </span>
            <span className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/70 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2 flex-wrap">
            <span className="text-xl sm:text-2xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {stats.pendingCount}
            </span>
            <span className="text-xs font-bold font-mono text-amber-600 dark:text-amber-400 tabular-nums">
              {formatBdt(stats.pendingValue)}
            </span>
          </div>
          <p className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums truncate">
            In Courier: <strong className="text-indigo-600 dark:text-indigo-400">{stats.packagingCount + stats.dispatchedCount}</strong> · Delivered: <strong className="text-emerald-600 dark:text-emerald-400">{stats.deliveredCount}</strong>
          </p>
        </button>

        {/* KPI 4: Total Revenue & Stock Status */}
        <button
          type="button"
          onClick={() => {
            if (window.innerWidth < 1024) {
              setActiveWorkspaceTab('products');
            } else {
              onNavigate('inventory');
            }
          }}
          className="text-left rounded-2xl p-3.5 sm:p-4 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs font-bold text-slate-500 dark:text-slate-400">
              Total Order Sales
            </span>
            <span className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2 flex-wrap">
            <span className="text-lg sm:text-2xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {formatBdt(stats.totalRevenue)}
            </span>
          </div>
          <p className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums truncate">
            This Month: <strong className="text-indigo-600 dark:text-indigo-400">{formatBdt(stats.monthRevenue)}</strong> · Low Stock: <strong className="text-rose-600 dark:text-rose-400">{stats.lowStockCount + stats.outOfStockCount}</strong>
          </p>
        </button>
      </div>

      {/* 2. Compact 6-Stage Order Pipeline Strip */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 p-3.5 sm:p-4 shadow-2xs">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100">
              Order Status Pipeline
            </span>
            <span className="hidden sm:inline text-xs text-slate-400 dark:text-slate-500">
              — Click any stage to view orders
            </span>
          </div>
          <button
            type="button"
            onClick={() => openOrdersViewTab('orders')}
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
          >
            <span>Orders Page</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-2.5">
          {[
            {
              label: 'Pending',
              count: stats.pendingCount,
              value: stats.pendingValue,
              dot: 'bg-amber-500',
              text: 'text-amber-700 dark:text-amber-400',
              onClick: () => openOrdersViewTab('orders')
            },
            {
              label: 'Confirmed',
              count: stats.confirmedCount,
              value: stats.confirmedValue,
              dot: 'bg-sky-500',
              text: 'text-sky-700 dark:text-sky-400',
              onClick: () => openOrdersViewTab('orders')
            },
            {
              label: 'Packaging',
              count: stats.packagingCount,
              value: stats.packagingValue,
              dot: 'bg-indigo-500',
              text: 'text-indigo-700 dark:text-indigo-400',
              onClick: () => openOrdersViewTab('orders')
            },
            {
              label: 'Dispatched',
              count: stats.dispatchedCount,
              value: stats.dispatchedValue,
              dot: 'bg-purple-500',
              text: 'text-purple-700 dark:text-purple-400',
              onClick: () => openOrdersViewTab('orders')
            },
            {
              label: 'Delivered',
              count: stats.deliveredCount,
              value: stats.deliveredValue,
              dot: 'bg-emerald-500',
              text: 'text-emerald-700 dark:text-emerald-400',
              onClick: () => openOrdersViewTab('orders')
            },
            {
              label: 'Incomplete Leads',
              count: stats.activeIncompleteCount,
              value: stats.recoverableRevenue,
              dot: 'bg-rose-500',
              text: 'text-rose-700 dark:text-rose-400',
              onClick: () => openOrdersViewTab('incomplete')
            }
          ].map((stage, idx) => (
            <button
              key={idx}
              type="button"
              onClick={stage.onClick}
              className="text-left p-2.5 sm:p-3 rounded-xl bg-slate-50/80 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full shrink-0 ${stage.dot}`} />
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 truncate">
                  {stage.label}
                </span>
              </div>
              <div className="mt-1 flex items-baseline justify-between gap-1">
                <span className="text-base sm:text-lg font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
                  {stage.count}
                </span>
                <span className={`text-[10px] sm:text-[11px] font-mono font-bold tabular-nums truncate ${stage.text}`}>
                  {formatBdt(stage.value)}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 3. Unified Workspace Switcher, Date Filter & Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 p-3 sm:p-4 space-y-3 shadow-2xs">
        {/* Top Row: Mobile-First Section Tabs + Date Filter */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
          {/* Workspace Section Switcher (Prevents endless scrolling on mobile) */}
          <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800/90 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveWorkspaceTab('orders')}
              className={`min-h-[36px] px-2 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeWorkspaceTab === 'orders'
                  ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Orders</span>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 tabular-nums">
                {stats.pendingCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveWorkspaceTab('leads')}
              className={`min-h-[36px] px-2 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeWorkspaceTab === 'leads'
                  ? 'bg-white dark:bg-slate-900 text-rose-700 dark:text-rose-400 shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Leads</span>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 tabular-nums">
                {stats.activeIncompleteCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveWorkspaceTab('products')}
              className={`min-h-[36px] px-2 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeWorkspaceTab === 'products'
                  ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-400 shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Stock</span>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 tabular-nums">
                {products.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveWorkspaceTab('split')}
              className={`min-h-[36px] px-2 py-1.5 rounded-lg text-[11px] sm:text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeWorkspaceTab === 'split'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Overview</span>
            </button>
          </div>

          {/* Date Range Filter + Search Box */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
              {(
                [
                  { id: 'today', label: `Today (${stats.todayOrdersCount})` },
                  { id: '7days', label: '7 Days' },
                  { id: 'month', label: 'This Month' },
                  { id: 'all', label: `All (${onlineOrders.length})` }
                ] as const
              ).map(tab => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setDateRangeFilter(tab.id)}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    dateRangeFilter === tab.id
                      ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-2xs'
                      : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative flex-1 sm:w-72 lg:w-96">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search customer name, phone, order # or product..."
                className="w-full pl-10 pr-8 py-2 min-h-[38px] text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-emerald-600 focus:bg-white dark:focus:bg-slate-800 rounded-xl text-slate-900 dark:text-slate-100 placeholder:text-slate-400 outline-hidden transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 5. Main Orders & Leads Workbench */}
      {(showOrdersPanel || showLeadsPanel) && (
        <div
          className={`grid grid-cols-1 ${
            activeWorkspaceTab === 'split' ? 'xl:grid-cols-2' : ''
          } gap-4 sm:gap-5 items-start`}
        >
          {/* PANEL A: Recent & Today's Orders */}
          {showOrdersPanel && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden shadow-2xs">
              <div className="px-4 sm:px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <ShoppingBag className="w-4 h-4" />
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                        Recent Orders
                      </h2>
                      <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                        ({filteredDashboardOrders.length})
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      1-Click Call, WhatsApp & Order Status Update
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => openOrdersViewTab('orders')}
                  className="min-h-[34px] px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 inline-flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                >
                  <span>View All</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="p-3.5 sm:p-4 space-y-3">
                {filteredDashboardOrders.slice(0, activeWorkspaceTab === 'orders' ? 12 : 8).map(order => {
                  const cleanPhone = order.customerPhone.replace(/[^0-9]/g, '');
                  const waPhone = cleanPhone.startsWith('88') ? cleanPhone : `88${cleanPhone}`;
                  const placedToday = isTodayIso(order.createdAt);
                  const phoneKey = normalizeBdPhone(order.customerPhone || '');
                  const phoneHist = phoneKey ? phoneOrderHistoryMap[phoneKey] : undefined;
                  const isDuplicateToday = (phoneHist?.todayOrders || 0) >= 2;
                  const isRepeatCustomer = (phoneHist?.totalOrders || 0) >= 2;

                  return (
                    <div
                      key={order.id}
                      className={`rounded-xl border p-3.5 transition-colors ${
                        placedToday
                          ? 'bg-emerald-50/25 dark:bg-emerald-950/15 border-emerald-200/80 dark:border-emerald-800/60'
                          : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/70'
                      }`}
                    >
                      {/* Top Row: Order No, Time, Customer & Grand Total */}
                      <div className="flex items-start justify-between gap-2.5">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5 text-xs">
                            <span className="font-mono font-extrabold text-emerald-700 dark:text-emerald-400 tabular-nums">
                              #{order.orderNo}
                            </span>
                            <span className="text-slate-300 dark:text-slate-600">·</span>
                            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                              {formatDateTimeEn(order.createdAt)}
                            </span>
                            {placedToday && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                                Today
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5 mt-1">
                            <p className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                              {order.customerName}
                            </p>
                            {isDuplicateToday ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 text-[10px] font-bold">
                                <AlertTriangle className="w-3 h-3 shrink-0" />
                                <span>{phoneHist?.todayOrders} Orders Today</span>
                              </span>
                            ) : isRepeatCustomer ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold">
                                <Repeat className="w-3 h-3 shrink-0" />
                                <span>Repeat ({phoneHist?.totalOrders})</span>
                              </span>
                            ) : null}
                            {(phoneHist?.cancelledOrders || 0) >= 2 && (
                              <span className="text-amber-700 dark:text-amber-400 text-[10px] font-bold">
                                · {phoneHist?.cancelledOrders} Cancelled
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <p className="text-sm sm:text-base font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
                            {formatBdt(order.grandTotal)}
                          </p>
                          <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                            {order.paymentMethod.toUpperCase()} ·{' '}
                            {order.deliveryCharge === 0 ? 'Free Delivery' : `Delivery ৳${order.deliveryCharge}`}
                          </p>
                        </div>
                      </div>

                      {/* Address & Products */}
                      <div className="mt-2.5 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 space-y-2">
                        <p className="text-xs text-slate-600 dark:text-slate-300 flex items-start gap-1.5 leading-snug">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                          <span>
                            <strong className="font-bold text-slate-800 dark:text-slate-200">
                              {order.deliveryArea || 'Standard'}:
                            </strong>{' '}
                            {order.deliveryAddress}
                          </span>
                        </p>

                        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200/70 dark:border-slate-700/80 px-2.5 py-1.5 space-y-1">
                          {order.items.map((item, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between gap-2 text-xs"
                            >
                              <span className="text-slate-800 dark:text-slate-200 font-semibold truncate">
                                {item.productName}
                                {item.variantLabel ? ` (${item.variantLabel})` : ''}
                              </span>
                              <span className="font-mono font-bold text-slate-700 dark:text-slate-300 tabular-nums shrink-0">
                                {item.quantity} × ৳{item.unitPrice}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Bottom Thumb-Friendly Action Row */}
                      <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <a
                            href={`tel:${order.customerPhone}`}
                            className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white font-mono text-xs font-bold inline-flex items-center gap-1.5 transition-colors tabular-nums"
                            title="Call Customer"
                          >
                            <Phone className="w-3.5 h-3.5 shrink-0" />
                            <span>{order.customerPhone}</span>
                          </a>

                          <a
                            href={`https://wa.me/${waPhone}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="min-h-[36px] px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1 transition-colors"
                            title="Send WhatsApp Message"
                          >
                            <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                            <span className="hidden sm:inline">WhatsApp</span>
                          </a>
                        </div>

                        <select
                          value={order.orderStatus}
                          onChange={(e) =>
                            updateOnlineOrderStatus(order.id, e.target.value as OnlineOrderStatus)
                          }
                          aria-label={`Order status for ${order.orderNo}`}
                          className={`min-h-[36px] px-2.5 py-1.5 rounded-lg text-xs font-extrabold border outline-hidden cursor-pointer ${getOrderStatusSelectStyle(
                            order.orderStatus
                          )}`}
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="packaging">Packaging</option>
                          <option value="dispatched">Dispatched</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>
                  );
                })}

                {filteredDashboardOrders.length === 0 && (
                  <div className="rounded-xl border border-slate-200/70 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 p-8 text-center space-y-2">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
                      No orders found for this filter.
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {dateRangeFilter === 'today'
                        ? 'No new orders placed today yet. Click "All" to view previous orders.'
                        : 'Clear your search query or change the date filter.'}
                    </p>
                    {dateRangeFilter !== 'all' && (
                      <button
                        type="button"
                        onClick={() => setDateRangeFilter('all')}
                        className="min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 transition-colors cursor-pointer"
                      >
                        Show All Orders ({onlineOrders.length})
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* PANEL B: Incomplete / Abandoned Checkout Leads */}
          {showLeadsPanel && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden shadow-2xs">
              <div className="px-4 sm:px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                      <AlertTriangle className="w-4 h-4" />
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                          Incomplete Orders (Leads)
                        </h2>
                        <span className="text-xs font-mono font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                          ({stats.activeIncompleteCount} Open)
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                        Call customer and convert to a confirmed order in 1 click
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => openOrdersViewTab('incomplete')}
                    className="min-h-[34px] px-3 py-1.5 rounded-xl text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 inline-flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                  >
                    <span>All Leads</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Lead Status Filter Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
                  {[
                    {
                      id: 'abandoned' as const,
                      label: `New Leads (${stats.abandonedOnlyCount})`
                    },
                    {
                      id: 'contacted' as const,
                      label: `Contacted (${stats.contactedCount})`
                    },
                    {
                      id: 'converted' as const,
                      label: `Converted (${stats.convertedCount})`
                    },
                    {
                      id: 'all' as const,
                      label: `All (${incompleteOrders.length})`
                    }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setDashboardLeadStatusFilter(tab.id)}
                      className={`min-h-[32px] px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                        dashboardLeadStatusFilter === tab.id
                          ? 'bg-rose-600 text-white shadow-2xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3.5 sm:p-4 space-y-3">
                {filteredDashboardIncomplete.slice(0, activeWorkspaceTab === 'leads' ? 12 : 8).map(lead => {
                  const cleanPhone = (lead.customerPhone || '').replace(/[^0-9]/g, '');
                  const waPhone = cleanPhone.startsWith('88') ? cleanPhone : `88${cleanPhone}`;
                  const isConverted = lead.status === 'converted';
                  const capturedToday = isTodayIso(lead.updatedAt || lead.createdAt);
                  const phoneKey = normalizeBdPhone(lead.customerPhone || '');
                  const phoneHist = phoneKey ? phoneOrderHistoryMap[phoneKey] : undefined;
                  const existingOrderCount = phoneHist?.totalOrders || 0;
                  const leadItemsSummary = lead.items
                    .map(i => `${i.productName}${i.variantLabel ? ` (${i.variantLabel})` : ''}`)
                    .join(', ');
                  const banglaWaMessage = `আসসালামু আলাইকুম ${
                    lead.customerName || 'ভাইয়া/আপু'
                  }, আপনি আমাদের "${currentBusiness.name}" থেকে (${leadItemsSummary}) অর্ডার করার চেষ্টা করেছিলেন (মোট বিল: ৳${
                    lead.grandTotal
                  })। আপনার অর্ডারটি কি কনফার্ম করে দেবো?`;

                  return (
                    <div
                      key={lead.id}
                      className={`rounded-xl border p-3.5 transition-colors ${
                        isConverted
                          ? 'bg-emerald-50/20 dark:bg-emerald-950/15 border-emerald-200/70 dark:border-emerald-800/60'
                          : 'bg-rose-50/20 dark:bg-rose-950/15 border-rose-200/70 dark:border-rose-800/60'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2.5">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5 text-xs">
                            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                              {formatDateTimeEn(lead.updatedAt || lead.createdAt)}
                            </span>
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-extrabold bg-amber-100 dark:bg-amber-950/80 text-amber-900 dark:text-amber-300 border border-amber-300/80 dark:border-amber-700/70">
                              <Clock className="w-3 h-3 text-amber-700 dark:text-amber-400 shrink-0" />
                              <span>{formatRelativeTimeAgoBn(lead.updatedAt || lead.createdAt, nowTick)}</span>
                            </span>
                            {capturedToday && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
                                Today
                              </span>
                            )}
                            {lead.fbLeadSent && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300">
                                Meta Lead
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5 mt-1">
                            <p className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                              {lead.customerName || 'Guest Customer'}
                            </p>
                            {existingOrderCount > 0 && (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                                <Repeat className="w-3 h-3 shrink-0" />
                                <span>{existingOrderCount} Existing Orders</span>
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <p className="text-sm sm:text-base font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
                            {formatBdt(lead.grandTotal)}
                          </p>
                          <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                            {lead.deliveryCharge === 0 ? 'Free Delivery' : `Delivery ৳${lead.deliveryCharge}`}
                          </p>
                        </div>
                      </div>

                      <div className="mt-2.5 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 space-y-2">
                        <p className="text-xs text-slate-600 dark:text-slate-300 flex items-start gap-1.5 leading-snug">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                          <span>
                            <strong className="font-bold text-slate-800 dark:text-slate-200">
                              {lead.deliveryArea || 'Area'}:
                            </strong>{' '}
                            {lead.deliveryAddress || 'Address not entered'}
                          </span>
                        </p>

                        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200/70 dark:border-slate-700/80 px-2.5 py-1.5 space-y-1">
                          {lead.items.map((item, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between gap-2 text-xs"
                            >
                              <span className="text-slate-800 dark:text-slate-200 font-semibold truncate">
                                {item.productName}
                                {item.variantLabel ? ` (${item.variantLabel})` : ''}
                              </span>
                              <span className="font-mono font-bold text-slate-700 dark:text-slate-300 tabular-nums shrink-0">
                                {item.quantity} × ৳{item.unitPrice}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {lead.customerPhone ? (
                            <>
                              <a
                                href={`tel:${lead.customerPhone}`}
                                onClick={() => {
                                  if (lead.status === 'abandoned') {
                                    updateIncompleteOrderStatus(lead.id, 'contacted');
                                  }
                                }}
                                className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white font-mono text-xs font-bold inline-flex items-center gap-1.5 transition-colors tabular-nums"
                              >
                                <Phone className="w-3.5 h-3.5 shrink-0" />
                                <span>{lead.customerPhone}</span>
                              </a>

                              <a
                                href={`https://wa.me/${waPhone}?text=${encodeURIComponent(
                                  banglaWaMessage
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={() => {
                                  if (lead.status === 'abandoned') {
                                    updateIncompleteOrderStatus(lead.id, 'contacted');
                                  }
                                }}
                                className="min-h-[36px] px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1 transition-colors"
                              >
                                <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                                <span className="hidden sm:inline">WhatsApp</span>
                              </a>
                            </>
                          ) : (
                            <span className="text-xs text-slate-400">No phone entered</span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <select
                            value={lead.status}
                            onChange={(e) =>
                              updateIncompleteOrderStatus(
                                lead.id,
                                e.target.value as IncompleteOrderStatus
                              )
                            }
                            aria-label={`Lead status for ${lead.customerName || 'Guest'}`}
                            className={`min-h-[36px] px-2 py-1.5 rounded-lg text-xs font-extrabold border outline-hidden cursor-pointer ${getIncompleteSelectStyle(
                              lead.status
                            )}`}
                          >
                            <option value="abandoned">Abandoned</option>
                            <option value="contacted">Contacted</option>
                            <option value="converted">Converted</option>
                            <option value="ignored">Ignored</option>
                          </select>

                          {!isConverted ? (
                            <button
                              type="button"
                              disabled={convertingLeadId === lead.id}
                              onClick={() => handleQuickConvertLead(lead.id)}
                              className="min-h-[36px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-extrabold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <PlusCircle className="w-3.5 h-3.5 shrink-0" />
                              <span>{convertingLeadId === lead.id ? 'Converting...' : 'Convert Order'}</span>
                            </button>
                          ) : (
                            <span className="text-xs font-mono font-extrabold text-emerald-700 dark:text-emerald-400 tabular-nums">
                              {lead.convertedOrderNo || 'Converted'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredDashboardIncomplete.length === 0 && (
                  <div className="rounded-xl border border-slate-200/70 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 p-8 text-center space-y-2">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
                      No incomplete orders in this list.
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      When customers type their name or phone number on checkout and leave, their lead will automatically appear here.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 6. Products Stock & Sales Report Section */}
      {showProductsPanel && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden flex flex-col shadow-2xs">
          <div className="px-4 sm:px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                <Boxes className="w-4 h-4" />
              </span>
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  Product Sales & Stock Report ({products.length})
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Click &ldquo;Update Stock&rdquo; on the right to manage product inventory & stock out flags
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('inventory')}
              className="min-h-[34px] px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 inline-flex items-center gap-1 cursor-pointer shrink-0"
            >
              <span>Update Stock</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 px-4 sm:px-5 py-2">
            {productPerformance.slice(0, activeWorkspaceTab === 'products' ? 15 : 6).map(({ product, soldQty, revenue, stock }) => {
              const isOut = stock <= 0 || Boolean(product.isOutOfStock);
              const isLow = !isOut && stock > 0 && stock <= (product.lowStockAlert || 15);
              return (
                <div
                  key={product.id}
                  className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl border border-slate-200/80 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 overflow-hidden shrink-0">
                      <ProductThumbnail product={product} imgClassName="p-0.5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100 truncate">
                        {product.nameBn || product.nameEn}
                      </p>
                      <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                        Price: {formatBdt(product.retailPrice)} · Sold: {soldQty} ({formatBdt(revenue)})
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-2.5 pl-13 sm:pl-0 shrink-0">
                    <span
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono font-extrabold tabular-nums ${
                        isOut
                          ? 'bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
                          : isLow
                          ? 'bg-amber-50 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                          : 'bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                      }`}
                    >
                      {isOut ? 'Stock Out' : isLow ? `Low Stock (${stock})` : `Stock: ${stock}`}
                    </span>

                    <button
                      type="button"
                      onClick={() => onNavigate('inventory')}
                      className="min-h-[32px] px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-200 hover:text-indigo-700 transition-colors cursor-pointer"
                    >
                      + Stock
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. Inside Dhaka vs Outside Dhaka & Order Source Ratio Insights (Bottom Section) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
        {/* Card A: Inside Dhaka vs Outside Dhaka Order Ratio */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 p-3.5 sm:p-4 shadow-2xs space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <MapPin className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">
                  ঢাকার ভেতরে বনাম ঢাকার বাইরে অর্ডার রেশিও
                </h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Inside Dhaka vs Outside Dhaka Delivery Area Breakdown
                </p>
              </div>
            </div>
            <span className="text-[11px] font-mono font-bold text-slate-500 dark:text-slate-400 tabular-nums">
              মোট: {stats.insideDhakaCount + stats.outsideDhakaCount} টি
            </span>
          </div>

          {/* Visual Ratio Progress Bar */}
          <div className="h-2.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden flex">
            <div
              style={{ width: `${stats.insideDhakaPct}%` }}
              className="bg-emerald-500 transition-all duration-300"
              title={`Inside Dhaka: ${stats.insideDhakaPct}%`}
            />
            <div
              style={{ width: `${stats.outsideDhakaPct}%` }}
              className="bg-sky-500 transition-all duration-300"
              title={`Outside Dhaka: ${stats.outsideDhakaPct}%`}
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/50">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[11px] font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <span>ঢাকার ভেতরে (Inside)</span>
                </span>
                <span className="text-[11px] font-mono font-extrabold text-emerald-700 dark:text-emerald-400 tabular-nums">
                  {stats.insideDhakaPct}%
                </span>
              </div>
              <div className="mt-1 flex items-baseline justify-between gap-1 font-mono tabular-nums">
                <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  {stats.insideDhakaCount} টি
                </span>
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                  {formatBdt(stats.insideDhakaRevenue)}
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-sky-50/60 dark:bg-sky-950/30 border border-sky-200/60 dark:border-sky-800/50">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[11px] font-bold text-sky-900 dark:text-sky-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-sky-500 shrink-0" />
                  <span>ঢাকার বাইরে (Outside)</span>
                </span>
                <span className="text-[11px] font-mono font-extrabold text-sky-700 dark:text-sky-400 tabular-nums">
                  {stats.outsideDhakaPct}%
                </span>
              </div>
              <div className="mt-1 flex items-baseline justify-between gap-1 font-mono tabular-nums">
                <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  {stats.outsideDhakaCount} টি
                </span>
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                  {formatBdt(stats.outsideDhakaRevenue)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Card B: Order Source Breakdown (Website vs Landing Page vs Recovered) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 p-3.5 sm:p-4 shadow-2xs space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-violet-50 dark:bg-violet-950/70 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0">
                <Rocket className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">
                  অর্ডার সোর্স রেশিও (ওয়েবসাইট বনাম ল্যান্ডিং পেজ)
                </h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Storefront Website vs Landing Pages vs Recovered Leads
                </p>
              </div>
            </div>
            <span className="text-[11px] font-mono font-bold text-slate-500 dark:text-slate-400 tabular-nums">
              গড় অর্ডার: {formatBdt(stats.avgOrderValue)}
            </span>
          </div>

          {/* Visual Source Progress Bar */}
          <div className="h-2.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden flex">
            <div
              style={{ width: `${stats.storefrontOrderPct}%` }}
              className="bg-indigo-500 transition-all duration-300"
              title={`Storefront: ${stats.storefrontOrderPct}%`}
            />
            <div
              style={{ width: `${stats.landingOrderPct}%` }}
              className="bg-violet-500 transition-all duration-300"
              title={`Landing Page: ${stats.landingOrderPct}%`}
            />
            <div
              style={{ width: `${stats.recoveredOrderPct}%` }}
              className="bg-amber-500 transition-all duration-300"
              title={`Recovered: ${stats.recoveredOrderPct}%`}
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="p-2.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-800/50">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[10px] sm:text-[11px] font-bold text-indigo-900 dark:text-indigo-300 truncate">
                  ওয়েবসাইট
                </span>
                <span className="text-[10px] font-mono font-extrabold text-indigo-700 dark:text-indigo-400 tabular-nums">
                  {stats.storefrontOrderPct}%
                </span>
              </div>
              <p className="mt-1 text-xs sm:text-sm font-mono font-extrabold text-slate-900 dark:text-white tabular-nums">
                {stats.storefrontOrderCount} টি
              </p>
              <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 tabular-nums truncate">
                {formatBdt(stats.storefrontOrderRevenue)}
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-violet-50/60 dark:bg-violet-950/30 border border-violet-200/60 dark:border-violet-800/50">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[10px] sm:text-[11px] font-bold text-violet-900 dark:text-violet-300 truncate">
                  ল্যান্ডিং পেজ
                </span>
                <span className="text-[10px] font-mono font-extrabold text-violet-700 dark:text-violet-400 tabular-nums">
                  {stats.landingOrderPct}%
                </span>
              </div>
              <p className="mt-1 text-xs sm:text-sm font-mono font-extrabold text-slate-900 dark:text-white tabular-nums">
                {stats.landingOrderCount} টি
              </p>
              <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 tabular-nums truncate">
                {formatBdt(stats.landingOrderRevenue)}
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/50">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[10px] sm:text-[11px] font-bold text-amber-900 dark:text-amber-300 truncate">
                  লিড রিকভারি
                </span>
                <span className="text-[10px] font-mono font-extrabold text-amber-700 dark:text-amber-400 tabular-nums">
                  {stats.recoveredOrderPct}%
                </span>
              </div>
              <p className="mt-1 text-xs sm:text-sm font-mono font-extrabold text-slate-900 dark:text-white tabular-nums">
                {stats.recoveredOrderCount} টি
              </p>
              <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 tabular-nums truncate">
                {formatBdt(stats.recoveredOrderRevenue)}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
