import {
  Product,
  LandingReviewItem,
  LandingTrustItem,
  LandingSizeChartRow,
  SpinWheelSliceConfig,
  SpinWheelConfig,
  LandingVariantDesign,
  LandingImageBadgeDesign
} from '../types';

export const LANDING_VARIANT_DESIGN_OPTIONS: {
  id: LandingVariantDesign;
  label: string;
  shortLabel: string;
  desc: string;
}[] = [
  {
    id: 'classic_radio_list',
    label: '১. ক্লাসিক লিস্ট (বর্তমান ডিজাইন)',
    shortLabel: '১. ক্লাসিক লিস্ট',
    desc: 'একটির নিচে একটি ফুল-উইডথ রেডিও লিস্ট (ডিফল্ট)'
  },
  {
    id: 'mobile_grid_chips',
    label: '২. মোবাইল ২-কলাম স্মার্ট গ্রিড (Mobile Grid)',
    shortLabel: '২. মোবাইল গ্রিড',
    desc: 'মোবাইলে পাশাপাশি ২-৩টি বক্স আকারে সাইজ দেখাবে (স্ক্রল কম লাগে)'
  },
  {
    id: 'pill_capsules',
    label: '৩. মডার্ন ক্যাপসুল বাটন (Pill Capsules)',
    shortLabel: '৩. ক্যাপসুল বাটন',
    desc: 'স্মার্টফোনে এক আঙুলে দ্রুত সিলেক্ট করার জন্য রাউন্ড ক্যাপসুল বাটন'
  },
  {
    id: 'stacked_offer_cards',
    label: '৪. প্রিমিয়াম অফার কার্ড (Offer Cards)',
    shortLabel: '৪. অফার কার্ড',
    desc: 'প্রিমিয়াম বর্ডার ও ব্যাজসহ আকর্ষণীয় ভ্যারিয়েশন কার্ড ডিজাইন'
  },
  {
    id: 'royal_crimson_tabs',
    label: '৫. বোল্ড রেড-গোল্ড শপ স্টাইল (Crimson Box)',
    shortLabel: '৫. রেড-গোল্ড বক্স',
    desc: 'বাংলাদেশি হাই-কনভার্টিং শপের মতো গাঢ় লাল ও গোল্ডেন সিলেকশন বক্স'
  },
  {
    id: 'compact_segmented_bar',
    label: '৬. স্লিক কম্প্যাক্ট বাটন বার (Compact Touch)',
    shortLabel: '৬. কম্প্যাক্ট বার',
    desc: 'অ্যাপলের মতো স্লিক সেগমেন্টেড টাচ বার (মোবাইলে অত্যন্ত পরিপাটি)'
  },
  {
    id: 'royal_crimson_clean',
    label: '৭. রেড-গোল্ড ক্লিন বক্স (Selected লেখা ছাড়া)',
    shortLabel: '৭. রেড-গোল্ড ক্লিন',
    desc: '৫ নাম্বারের মতোই আকর্ষণীয় রেড-গোল্ড বক্স, কিন্তু উপরে Selected লেখা ছাড়া'
  },
  {
    id: 'royal_luxury_gift',
    label: '৮. স্পেশাল গিফট: রয়্যাল ডার্ক-গোল্ড ভিআইপি (Gift Edition 🎁)',
    shortLabel: '৮. রয়্যাল গিফট ভিআইপি 🎁',
    desc: 'ব্ল্যাক-এমেরাল্ড ও রয়্যাল গোল্ড কর্নার ব্যাজসহ প্রিমিয়াম বুটিক স্টাইল'
  },
  {
    id: 'lp2_red_measurement_grid',
    label: '৯. রেড মাপ বক্স — বুক ও লম্বা মাপসহ (LP-2 ডিফল্ট)',
    shortLabel: '৯. রেড মাপ বক্স (LP-2)',
    desc: 'উপরে লাল টিক চিহ্ন এবং নিচে বুক ও লম্বা সাইজ মাপসহ রেসপনসিভ কার্ড'
  }
];

export const LANDING_IMAGE_BADGE_DESIGN_OPTIONS: {
  id: LandingImageBadgeDesign;
  label: string;
  shortLabel: string;
  desc: string;
}[] = [
  {
    id: 'classic_red',
    label: '১. ক্লাসিক রেড ব্যাজ (বর্তমান ডিজাইন)',
    shortLabel: '১. ক্লাসিক রেড',
    desc: 'গাঢ় লাল বক্সে "% ছাড় (সাশ্রয় ৳...)" — ডিফল্ট ডিজাইন'
  },
  {
    id: 'crimson_gold',
    label: '২. রেড-গোল্ড ভিআইপি রিবন (Red-Gold VIP)',
    shortLabel: '২. রেড-গোল্ড রিবন',
    desc: 'গাঢ় লাল ও গোল্ডেন বর্ডারের প্রিমিয়াম ডিসকাউন্ট রিবন'
  },
  {
    id: 'circle_seal',
    label: '৩. রাউন্ড সার্কেল স্টিকার (Circle Sticker)',
    shortLabel: '৩. রাউন্ড স্টিকার',
    desc: 'ছবির কোণায় গোল স্টিকার আকারে বড় করে "% ছাড়" দেখাবে'
  },
  {
    id: 'royal_dark_gold',
    label: '৪. রয়্যাল ব্ল্যাক-গোল্ড লাক্সারি (Royal Dark Gold)',
    shortLabel: '৪. ব্ল্যাক-গোল্ড',
    desc: 'কালো ও সোনালি রঙের লাক্সারি বুটিক ডিসকাউন্ট ব্যাজ'
  },
  {
    id: 'emerald_flash',
    label: '৫. এমেরাল্ড ফ্ল্যাশ ক্যাপসুল (Emerald Flash)',
    shortLabel: '৫. এমেরাল্ড ক্যাপসুল',
    desc: 'সবুজ গ্রেডিয়েন্ট রাউন্ড ক্যাপসুল ডিসকাউন্ট ব্যাজ'
  },
  {
    id: 'minimal_percent',
    label: '৬. মিনিমাল শর্ট ব্যাজ — শুধু % ছাড় (Minimal %)',
    shortLabel: '৬. শুধু % ছাড়',
    desc: 'ছোট ও ক্লিন ব্যাজ (শুধু "-২০% ছাড়" লেখা থাকবে, ছবি বেশি দেখা যাবে)'
  }
];

export const DEFAULT_LANDING_TRUST_ITEMS: LandingTrustItem[] = [
  {
    id: 'trust_1',
    title: '১০০% অরিজিনাল পণ্য',
    description: 'ছবির সাথে বাস্তবের শতভাগ মিল এবং প্রিমিয়াম কোয়ালিটির পূর্ণ নিশ্চয়তা।',
    enabled: true
  },
  {
    id: 'trust_2',
    title: 'হাতে পেয়ে মূল্য পরিশোধ',
    description: 'অগ্রিম ১ টাকাও দিতে হবে না। পণ্য হাতে পেয়ে দেখে ডেলিভারি ম্যানকে পেমেন্ট করুন।',
    enabled: true
  },
  {
    id: 'trust_3',
    title: 'সারা দেশে দ্রুত ডেলিভারি',
    description: 'ঢাকা ও ঢাকার বাইরে বাংলাদেশের যেকোনো প্রান্তে দ্রুততম হোম ডেলিভারি সুবিধা।',
    enabled: true
  },
  {
    id: 'trust_4',
    title: 'সহজ রিটার্ন ও এক্সচেঞ্জ',
    description: 'পণ্যে কোনো ত্রুটি থাকলে ডেলিভারি ম্যানের সামনেই চেক করে রিটার্ন করার সুবিধা।',
    enabled: true
  }
];

export const DEFAULT_LANDING_SIZE_CHART_HEADERS: [string, string, string] = [
  'সাইজ / বয়স',
  'বডি / চেস্ট (ইঞ্চি)',
  'লম্বা / দৈর্ঘ্য (ইঞ্চি)'
];

export const DEFAULT_FOOTER_WARNING_TEXT =
  '⚠️ দয়া করে ফেক অর্ডার করবেন না।\nমিথ্যা ও প্রতারণা আল্লাহর কাছে বড় গুনাহ।\nদায়িত্বশীল হয়ে অর্ডার করার অনুরোধ রইলো। 🤍';

export const DEFAULT_LANDING_SIZE_CHART_ROWS: LandingSizeChartRow[] = [
  { id: 'sz_1', size: '১ - ২ বছর (M)', chest: '২২ ইঞ্চি', length: '১৮ ইঞ্চি' },
  { id: 'sz_2', size: '৩ - ৪ বছর (L)', chest: '২৪ ইঞ্চি', length: '২০ ইঞ্চি' },
  { id: 'sz_3', size: '৫ - ৬ বছর (XL)', chest: '২৬ ইঞ্চি', length: '২২ ইঞ্চি' },
  { id: 'sz_4', size: '৭ - ৮ বছর (XXL)', chest: '২৮ ইঞ্চি', length: '২৪ ইঞ্চি' },
  { id: 'sz_5', size: '৯ - ১০ বছর (3XL)', chest: '৩০ ইঞ্চি', length: '২৬ ইঞ্চি' }
];

export const DEFAULT_LANDING_SHOE_SIZE_CHART_HEADERS: [string, string, string] = [
  'ইউরো সাইজ (EU)',
  'ইউকে সাইজ (UK)',
  'পায়ের মাপ (ইঞ্চি / সেমি)'
];

export const DEFAULT_LANDING_SHOE_SIZE_CHART_ROWS: LandingSizeChartRow[] = [
  { id: 'shoe_1', size: 'EU 39 / 40', chest: 'UK 6 - 6.5', length: '৯.৮ ইঞ্চি (25 cm)' },
  { id: 'shoe_2', size: 'EU 41', chest: 'UK 7', length: '১০.২ ইঞ্চি (26 cm)' },
  { id: 'shoe_3', size: 'EU 42', chest: 'UK 8', length: '১০.৪ ইঞ্চি (26.5 cm)' },
  { id: 'shoe_4', size: 'EU 43', chest: 'UK 9', length: '১০.৮ ইঞ্চি (27.5 cm)' },
  { id: 'shoe_5', size: 'EU 44', chest: 'UK 9.5 - 10', length: '১১.০ ইঞ্চি (28 cm)' }
];

export const DEFAULT_SPIN_WHEEL_SLICES: SpinWheelSliceConfig[] = [
  {
    id: 'sw_50',
    label: '৳৫০ ডিসকাউন্ট',
    shortLabel: '৳৫০ ছাড়',
    type: 'flat',
    value: 50,
    color: '#e11d48',
    code: 'SPIN50',
    locked: false
  },
  {
    id: 'sw_free_del',
    label: 'ফ্রি ডেলিভারি',
    shortLabel: 'ফ্রি ডেলিভারি',
    type: 'free_delivery',
    value: 0,
    color: '#059669',
    code: 'FREEDEL',
    locked: false
  },
  {
    id: 'sw_30',
    label: '৳৩০ ডিসকাউন্ট',
    shortLabel: '৳৩০ ছাড়',
    type: 'flat',
    value: 30,
    color: '#d97706',
    code: 'SPIN30',
    locked: false
  },
  {
    id: 'sw_5pct',
    label: '৫% স্পেশাল ছাড়',
    shortLabel: '৫% ছাড়',
    type: 'percent',
    value: 5,
    color: '#7c3aed',
    code: 'SPIN5P',
    locked: true
  },
  {
    id: 'sw_100',
    label: '৳১০০ মেগা ছাড়',
    shortLabel: '৳১০০ ছাড়',
    type: 'flat',
    value: 100,
    color: '#ea580c',
    code: 'MEGA100',
    locked: true
  },
  {
    id: 'sw_20',
    label: '৳২০ ক্যাশব্যাক ছাড়',
    shortLabel: '৳২০ ছাড়',
    type: 'flat',
    value: 20,
    color: '#0284c7',
    code: 'SPIN20',
    locked: false
  }
];

export const DEFAULT_SPIN_WHEEL_CONFIG: Required<SpinWheelConfig> = {
  badgeText: 'স্পেশাল লাকি ডিসকাউন্ট হুইল',
  titleText: 'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
  subtitleText: 'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
  claimButtonText: 'অফারটি গ্রহণ করে অর্ডার করুন',
  autoPopupDelaySec: 4,
  cooldownDays: 7,
  slices: DEFAULT_SPIN_WHEEL_SLICES
};

export const DEFAULT_LANDING_SPIN_WHEEL_SLICES: SpinWheelSliceConfig[] = [
  {
    id: 'lp_sw_1',
    label: '৳৫০ ক্যাশ ডিসকাউন্ট',
    shortLabel: '৳৫০ ছাড়',
    type: 'flat',
    value: 50,
    code: 'LP50',
    color: '#059669',
    locked: false
  },
  {
    id: 'lp_sw_2',
    label: 'ফ্রি হোম ডেলিভারি',
    shortLabel: 'ফ্রি ডেলিভারি',
    type: 'free_delivery',
    value: 0,
    code: 'LPFREE',
    color: '#d97706',
    locked: false
  },
  {
    id: 'lp_sw_3',
    label: '৫% স্পেশাল ছাড়',
    shortLabel: '৫% ছাড়',
    type: 'percent',
    value: 5,
    code: 'LP5PCT',
    color: '#4f46e5',
    locked: false
  },
  {
    id: 'lp_sw_4',
    label: '৳১০০ মেগা ডিসকাউন্ট',
    shortLabel: '৳১০০ ছাড়',
    type: 'flat',
    value: 100,
    code: 'LP100',
    color: '#e11d48',
    locked: true
  },
  {
    id: 'lp_sw_5',
    label: '১০% ভিআইপি ছাড়',
    shortLabel: '১০% ছাড়',
    type: 'percent',
    value: 10,
    code: 'LP10PCT',
    color: '#0d9488',
    locked: true
  },
  {
    id: 'lp_sw_6',
    label: '৳৩০ ইনস্ট্যান্ট ছাড়',
    shortLabel: '৳৩০ ছাড়',
    type: 'flat',
    value: 30,
    code: 'LP30',
    color: '#7c3aed',
    locked: false
  }
];

export const DEFAULT_LANDING_SPIN_WHEEL_CONFIG: SpinWheelConfig = {
  badgeText: 'স্পেশাল লাকি ডিসকাউন্ট হুইল',
  titleText: 'স্পিন করুন এবং নিশ্চিত ডিসকাউন্ট জিতুন!',
  subtitleText: 'চাকা ঘুরিয়ে জিতে নিন সর্বোচ্চ ৳১০০ ছাড় অথবা সম্পূর্ণ ফ্রি ডেলিভারি!',
  claimButtonText: 'অফারটি গ্রহণ করে অর্ডার করুন',
  autoPopupDelaySec: 4,
  cooldownDays: 7,
  slices: DEFAULT_LANDING_SPIN_WHEEL_SLICES
};

export const DEFAULT_SOCIAL_PROOF_BUYERS: Array<{
  name: string;
  location: string;
  timeAgo: string;
}> = [
  { name: 'তানিয়া আক্তার', location: 'উত্তরা সেক্টর-৭, ঢাকা', timeAgo: 'এইমাত্র' },
  { name: 'ফারহানা ইসলাম মিম', location: 'ধানমন্ডি-১৫, ঢাকা', timeAgo: '১ মিনিট আগে' },
  { name: 'মোঃ রাকিবুল হাসান', location: 'আগ্রাবাদ, চট্টগ্রাম', timeAgo: '২ মিনিট আগে' },
  { name: 'সাদিয়া আফরিন', location: 'মিরপুর-১০, ঢাকা', timeAgo: '৩ মিনিট আগে' },
  { name: 'নুসরাত জাহান তন্বী', location: 'জিন্দাবাজার, সিলেট', timeAgo: '৪ মিনিট আগে' },
  { name: 'মাহমুদুল হাসান সোহেল', location: 'কান্দিরপাড়, কুমিল্লা', timeAgo: '৫ মিনিট আগে' },
  { name: 'জান্নাতুল ফেরদৌস ঐশী', location: 'গাজীপুর চৌরাস্তা', timeAgo: '৬ মিনিট আগে' },
  { name: 'শামীমা নাসরিন', location: 'সাহেব বাজার, রাজশাহী', timeAgo: '৭ মিনিট আগে' },
  { name: 'আরিফুল ইসলাম জয়', location: 'চাষাড়া, নারায়ণগঞ্জ', timeAgo: '৮ মিনিট আগে' },
  { name: 'তাসনিম জারিন', location: 'বনানী, ঢাকা', timeAgo: '৯ মিনিট আগে' },
  { name: 'মেহেদী হাসান রনি', location: 'সাতমাথা, বগুড়া', timeAgo: '১০ মিনিট আগে' },
  { name: 'রুবাইয়া সুলতানা', location: 'সোনাডাঙ্গা, খুলনা', timeAgo: '১১ মিনিট আগে' },
  { name: 'ফাহিম আহমেদ', location: 'আম্বরখানা, সিলেট', timeAgo: '১২ মিনিট আগে' },
  { name: 'সুমাইয়া আক্তার বর্ষা', location: 'মোহাম্মদপুর, ঢাকা', timeAgo: '১৩ মিনিট আগে' },
  { name: 'নাজমুল হুদা', location: 'জাহাজ কোম্পানি মোড়, রংপুর', timeAgo: '১৪ মিনিট আগে' },
  { name: 'শারমিন আক্তার নিপা', location: 'নাসিরাবাদ, চট্টগ্রাম', timeAgo: '১৫ মিনিট আগে' },
  { name: 'কাজী তানভীর আহমেদ', location: 'বসুন্ধরা আবাসিক এলাকা, ঢাকা', timeAgo: '১৬ মিনিট আগে' },
  { name: 'আফরোজা খানম', location: 'গাঙ্গিনারপাড়, ময়মনসিংহ', timeAgo: '১৭ মিনিট আগে' },
  { name: 'সাইফুল ইসলাম নয়ন', location: 'মাইজদী, নোয়াখালী', timeAgo: '১৮ মিনিট আগে' },
  { name: 'ইশরাত জাহান ইভা', location: 'বাড্ডা লিংক রোড, ঢাকা', timeAgo: '১৯ মিনিট আগে' },
  { name: 'মোঃ জাহিদুল ইসলাম', location: 'বরিশাল সদর', timeAgo: '২০ মিনিট আগে' },
  { name: 'মালিহা তাবাসসুম', location: 'খিলগাঁও তালতলা, ঢাকা', timeAgo: '২১ মিনিট আগে' },
  { name: 'রাশেদুল করিম', location: 'কক্সবাজার সদর', timeAgo: '২২ মিনিট আগে' },
  { name: 'হাবিবা আক্তার মিম', location: 'সাভার বাসস্ট্যান্ড, ঢাকা', timeAgo: '২৩ মিনিট আগে' },
  { name: 'আব্দুল্লাহ আল মামুন', location: 'যশোর সদর', timeAgo: '২৪ মিনিট আগে' },
  { name: 'নাবিলা ইসলাম', location: 'রামপুরা বনশ্রী, ঢাকা', timeAgo: '২৫ মিনিট আগে' },
  { name: 'তৌহিদুল ইসলাম', location: 'ফেনী সদর', timeAgo: '২৬ মিনিট আগে' },
  { name: 'মরিয়ম আক্তার জুঁই', location: 'টঙ্গী স্টেশন রোড, গাজীপুর', timeAgo: '২৭ মিনিট আগে' },
  { name: 'শাকিল মাহমুদ', location: 'টাঙ্গাইল সদর', timeAgo: '২৮ মিনিট আগে' },
  { name: 'লামিয়া রহমান', location: 'ওয়ারী, ঢাকা', timeAgo: '২৯ মিনিট আগে' },
  { name: 'ইমরান হোসেন', location: 'কুষ্টিয়া সদর', timeAgo: '৩০ মিনিট আগে' },
  { name: 'সাবরিনা সুলতানা', location: 'হালিশহর, চট্টগ্রাম', timeAgo: '৩১ মিনিট আগে' },
  { name: 'আশরাফুল আলম', location: 'দিনাজপুর সদর', timeAgo: '৩২ মিনিট আগে' },
  { name: 'ফাতেমা তুজ জোহরা', location: 'যাত্রাবাড়ী, ঢাকা', timeAgo: '৩৩ মিনিট আগে' },
  { name: 'সোহানুর রহমান', location: 'পাবনা সদর', timeAgo: '৩৪ মিনিট আগে' },
  { name: 'নাজনীন নাহার', location: 'ব্রাহ্মণবাড়িয়া সদর', timeAgo: '৩৫ মিনিট আগে' },
  { name: 'মোঃ তারেক আজিজ', location: 'মাধবদী, নরসিংদী', timeAgo: '৩৬ মিনিট আগে' },
  { name: 'রাবেয়া বসরী', location: 'ফরিদপুর সদর', timeAgo: '৩৭ মিনিট আগে' },
  { name: 'কামরুল হাসান', location: 'শ্রীমঙ্গল, মৌলভীবাজার', timeAgo: '৩৮ মিনিট আগে' },
  { name: 'জেসমিন আক্তার', location: 'চাঁদপুর সদর', timeAgo: '৩৯ মিনিট আগে' },
  { name: 'মাজহারুল ইসলাম', location: 'সিরাজগঞ্জ সদর', timeAgo: '৪০ মিনিট আগে' },
  { name: 'তাহমিনা আক্তার কেয়া', location: 'মিরপুর-১, ঢাকা', timeAgo: '৪১ মিনিট আগে' },
  { name: 'রফিকুল ইসলাম', location: 'ভৈরব, কিশোরগঞ্জ', timeAgo: '৪২ মিনিট আগে' },
  { name: 'সোহানা পারভীন', location: 'হবিগঞ্জ সদর', timeAgo: '৪৩ মিনিট আগে' },
  { name: 'মনিরুজ্জামান মনির', location: 'সৈয়দপুর, নীলফামারী', timeAgo: '৪৪ মিনিট আগে' },
  { name: 'আঁখি মনি', location: 'লক্ষ্মীপুর সদর', timeAgo: '৪৫ মিনিট আগে' },
  { name: 'শরীফুল ইসলাম', location: 'নওগাঁ সদর', timeAgo: '৪৬ মিনিট আগে' },
  { name: 'তাসনুভা আনান', location: 'নিকেতন, গুলশান, ঢাকা', timeAgo: '৪৭ মিনিট আগে' },
  { name: 'মোঃ আল-আমিন', location: 'সাতক্ষীরা সদর', timeAgo: '৪৮ মিনিট আগে' },
  { name: 'সানজিদা ইসলাম', location: 'মানিকগঞ্জ সদর', timeAgo: '৪৯ মিনিট আগে' },
  { name: 'হাসিবুল ইসলাম শান্ত', location: 'ঝিনাইদহ সদর', timeAgo: '৫০ মিনিট আগে' },
  { name: 'নূরজাহান বেগম', location: 'মুন্সীগঞ্জ সদর', timeAgo: '৫২ মিনিট আগে' },
  { name: 'জাকির হোসেন', location: 'পটুয়াখালী সদর', timeAgo: '৫৪ মিনিট আগে' },
  { name: 'হুমাইরা জান্নাত', location: 'নাটোর সদর', timeAgo: '৫৫ মিনিট আগে' },
  { name: 'রেজাউল করিম', location: 'জামালপুর সদর', timeAgo: '৫৭ মিনিট আগে' },
  { name: 'তানজিলা আক্তার', location: 'রাজবাড়ী সদর', timeAgo: '৫৯ মিনিট আগে' }
];

export const slugifyLandingText = (text: string): string =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

export const getProductLandingSlug = (product: Product): string => {
  if (product.landingSlug && product.landingSlug.trim() !== '') {
    return slugifyLandingText(product.landingSlug.trim());
  }
  const base = slugifyLandingText(product.nameEn || product.sku || product.id);
  return base || product.id.toLowerCase();
};

export const buildLandingPagePath = (product: Product): string =>
  `/landing/${getProductLandingSlug(product)}`;

export const findLandingProductFromUrl = (
  productsList: Product[],
  pathname: string,
  search: string
): Product | null => {
  if (!productsList || productsList.length === 0) return null;

  let rawSlug = '';
  const cleanPath = decodeURIComponent(pathname || '').replace(/\/+$/, '');
  if (cleanPath.toLowerCase().startsWith('/landing/')) {
    rawSlug = cleanPath.slice('/landing/'.length).trim();
  } else if (search) {
    const params = new URLSearchParams(search);
    rawSlug = (params.get('landing') || '').trim();
  }

  if (!rawSlug) return null;
  const lowerSlug = rawSlug.toLowerCase();

  return (
    productsList.find(p => {
      const pSlug = getProductLandingSlug(p).toLowerCase();
      return (
        pSlug === lowerSlug ||
        (p.landingSlug && p.landingSlug.toLowerCase() === lowerSlug) ||
        p.id.toLowerCase() === lowerSlug ||
        p.sku.toLowerCase() === lowerSlug
      );
    }) || null
  );
};
