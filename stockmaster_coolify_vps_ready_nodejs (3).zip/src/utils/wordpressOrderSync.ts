import { Business, OnlineOrder, Product, SaleItem } from '../types';

export interface WordPressSyncLogEntry {
  id: string;
  localOrderNo: string;
  customerName: string;
  customerPhone: string;
  grandTotal: number;
  wpOrderId?: number | string;
  wpOrderStatus?: string;
  status: 'success' | 'failed';
  message: string;
  syncedAt: string;
  payloadSnapshot?: OnlineOrder;
}

export interface RemoteWooProduct {
  id: number;
  name: string;
  sku: string;
  price: string;
  regular_price: string;
  status: string;
  permalink?: string;
}

const WP_SYNC_LOGS_KEY = 'stockmaster_wp_sync_logs_v1';

export const getWordPressSyncLogs = (): WordPressSyncLogEntry[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(WP_SYNC_LOGS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const saveWordPressSyncLog = (entry: WordPressSyncLogEntry): WordPressSyncLogEntry[] => {
  const existing = getWordPressSyncLogs().filter(l => l.id !== entry.id);
  const next = [entry, ...existing].slice(0, 50);
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(WP_SYNC_LOGS_KEY, JSON.stringify(next));
    } catch {
      // Ignore storage quota errors
    }
  }
  return next;
};

export const clearWordPressSyncLogs = (): void => {
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.removeItem(WP_SYNC_LOGS_KEY);
    } catch {
      // Ignore
    }
  }
};

export const normalizeWpSiteUrl = (rawUrl?: string): string => {
  if (!rawUrl) return '';
  let clean = rawUrl.trim();
  if (!clean) return '';
  if (!/^https?:\/\//i.test(clean)) {
    clean = `https://${clean}`;
  }
  // Strip trailing slashes or /wp-json/... if user pasted full endpoint
  clean = clean.replace(/\/wp-json.*$/i, '').replace(/\/wp-admin.*$/i, '').replace(/\/+$/, '');
  return clean;
};

/**
 * Extracts clean base product name and variation label from a combined item name like
 * "প্রিমিয়াম এমব্রয়ডারি কটন পাঞ্জাবি (5-6 Years)"
 */
export const parseItemNameAndVariant = (item: SaleItem): { cleanName: string; variantText: string } => {
  const rawName = (item.productName || '').trim();
  if (item.productNameClean && item.variantLabel) {
    return {
      cleanName: item.productNameClean.trim(),
      variantText: item.variantLabel.trim()
    };
  }
  const parenMatch = rawName.match(/^(.*?)\s*\(([^()]+)\)\s*$/);
  if (parenMatch) {
    return {
      cleanName: (item.productNameClean || parenMatch[1]).trim(),
      variantText: (item.variantLabel || parenMatch[2]).trim()
    };
  }
  return {
    cleanName: (item.productNameClean || rawName).trim(),
    variantText: (item.variantLabel || '').trim()
  };
};

/**
 * Generates all plausible search tokens for a size/variation label to match WooCommerce variation attributes.
 * Handles Bengali numerals, English parentheses, slugs, and abbreviated formats (e.g. "5-6 Years", "5-6y", "৫-৬ বছর").
 */
export const getVariationCandidateTokens = (rawLabel: string): string[] => {
  if (!rawLabel) return [];
  const tokens = new Set<string>();
  const clean = rawLabel.trim();
  if (!clean) return [];

  tokens.add(clean.toLowerCase());

  // Extract English in parentheses: "৫-৬ বছর (5-6 Years)" -> "5-6 Years"
  const parenMatch = clean.match(/\(([^()]+)\)/);
  if (parenMatch && parenMatch[1]) {
    const inner = parenMatch[1].trim();
    tokens.add(inner.toLowerCase());
    const outer = clean.replace(/\([^()]*\)/g, '').trim();
    if (outer) tokens.add(outer.toLowerCase());
  }

  // Convert Bengali digits to English digits
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let converted = clean;
  for (let i = 0; i < 10; i++) {
    converted = converted.split(bengaliDigits[i]).join(String(i));
  }
  tokens.add(converted.toLowerCase());

  const currentTokens = Array.from(tokens);
  for (const t of currentTokens) {
    const slug = t
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    if (slug) tokens.add(slug);

    const shortY = t
      .toLowerCase()
      .replace(/years?/g, 'y')
      .replace(/\s+/g, '')
      .replace(/[^a-z0-9]/g, '');
    if (shortY) tokens.add(shortY);
  }

  return Array.from(tokens).filter(Boolean);
};

export const isVariationAttributeMatch = (rv: any, label: string): boolean => {
  if (!rv || !label || !Array.isArray(rv.attributes)) return false;
  const candidateTokens = getVariationCandidateTokens(label);
  return rv.attributes.some((attr: any) => {
    const opt = String(attr?.option || '').trim().toLowerCase();
    const slug = String(attr?.slug || '').trim().toLowerCase();
    const cleanOptSlug = opt.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    return candidateTokens.some(tok => tok === opt || tok === slug || tok === cleanOptSlug);
  });
};

/**
 * Generates a standardized Variation SKU from a Parent SKU + Size/Variation Label (e.g. "FASH-101-XL" or "FASH-101-5-6Y")
 */
export const buildVariantSkuCode = (baseSku: string, label: string, idx = 0): string => {
  const cleanBase = (baseSku || 'ITEM').trim().toUpperCase().replace(/\s+/g, '-');
  const englishParen = label.match(/\(([^()]+)\)/);
  const rawPart = englishParen ? englishParen[1] : label;
  const slug = rawPart
    .trim()
    .toUpperCase()
    .replace(/YEARS?/gi, 'Y')
    .replace(/[^A-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return `${cleanBase}-${slug || `V${idx + 1}`}`;
};

/**
 * Enriches OnlineOrder items with SKU (including Variation SKU for sizes), wpProductId, wpVariationId, and clean product names from the current product catalog
 */
export const enrichOrderWithCatalog = (
  order: OnlineOrder,
  productsCatalog?: Product[]
): OnlineOrder => {
  if (!productsCatalog || productsCatalog.length === 0) {
    return {
      ...order,
      items: order.items.map(it => {
        const { cleanName, variantText } = parseItemNameAndVariant(it);
        const effVarLabel = variantText || it.variantLabel || undefined;
        const effParentSku = it.parentSku || it.sku || undefined;
        const effVarSku =
          it.variantSku ||
          (effVarLabel && it.sku ? it.sku : undefined) ||
          (effVarLabel && effParentSku ? buildVariantSkuCode(effParentSku, effVarLabel) : undefined);
        return {
          ...it,
          productNameClean: cleanName,
          variantLabel: effVarLabel,
          parentSku: effParentSku,
          variantSku: effVarSku,
          sku: effVarSku || it.sku || effParentSku
        };
      })
    };
  }

  const enrichedItems: SaleItem[] = order.items.map(it => {
    const { cleanName, variantText } = parseItemNameAndVariant(it);
    const matchedProd =
      productsCatalog.find(p => p.id === it.productId) ||
      (it.parentSku
        ? productsCatalog.find(p => p.sku.toLowerCase() === it.parentSku!.toLowerCase())
        : undefined) ||
      (it.sku
        ? productsCatalog.find(
            p =>
              p.sku.toLowerCase() === it.sku!.toLowerCase() ||
              p.variants?.some(v => v.sku && v.sku.toLowerCase() === it.sku!.toLowerCase())
          )
        : undefined) ||
      productsCatalog.find(
        p =>
          p.nameBn.trim().toLowerCase() === cleanName.toLowerCase() ||
          p.nameEn.trim().toLowerCase() === cleanName.toLowerCase()
      );

    const matchedVariant = matchedProd?.variants?.find(
      v =>
        (it.variantId && v.id === it.variantId) ||
        (it.variantSku && v.sku && v.sku.trim().toLowerCase() === it.variantSku.trim().toLowerCase()) ||
        (it.sku && v.sku && v.sku.trim().toLowerCase() === it.sku.trim().toLowerCase()) ||
        (variantText && v.label.trim().toLowerCase() === variantText.toLowerCase())
    );

    const resolvedVariantLabel = variantText || it.variantLabel || matchedVariant?.label || undefined;
    const resolvedParentSku = matchedProd?.sku || it.parentSku || (!resolvedVariantLabel ? it.sku : undefined);
    const resolvedVariantSku =
      matchedVariant?.sku ||
      it.variantSku ||
      (resolvedVariantLabel && resolvedParentSku
        ? buildVariantSkuCode(resolvedParentSku, resolvedVariantLabel)
        : resolvedVariantLabel && it.sku && it.sku !== resolvedParentSku
        ? it.sku
        : undefined);

    return {
      ...it,
      productNameClean: matchedProd?.nameBn || cleanName,
      parentSku: resolvedParentSku || undefined,
      variantSku: resolvedVariantSku || undefined,
      sku: resolvedVariantSku || it.sku || resolvedParentSku || undefined,
      wpProductId: it.wpProductId || matchedProd?.wpProductId || undefined,
      wpVariationId: it.wpVariationId || matchedVariant?.wpVariationId || undefined,
      variantId: it.variantId || matchedVariant?.id || undefined,
      variantLabel: resolvedVariantLabel
    };
  });

  return {
    ...order,
    items: enrichedItems
  };
};

/**
 * Builds the WooCommerce REST API v3 Order Payload from our OnlineOrder.
 * Uses `line_items` whenever `wpProductId` is available so WooCommerce assigns real products & variations to the order,
 * and falls back to `fee_lines` only if explicitly requested or if no `wpProductId` could be resolved.
 */
export const buildWooCommerceOrderPayload = (
  business: Business,
  order: OnlineOrder,
  useFeeLinesFallback = false
) => {
  const nameParts = (order.customerName || 'Online Customer').trim().split(/\s+/);
  const firstName = nameParts[0] || 'Customer';
  const lastName = nameParts.slice(1).join(' ') || '';

  const itemSummaryLines = order.items.map((it, idx) => {
    const skuTag = it.variantSku
      ? ` [Var SKU: ${it.variantSku}${it.parentSku ? ` | Parent SKU: ${it.parentSku}` : ''}]`
      : it.sku
      ? ` [SKU: ${it.sku}]`
      : '';
    return `${idx + 1}. ${it.productName}${skuTag} × ${it.quantity} (৳${it.unitPrice} = ৳${it.total})`;
  });

  const isLandingOrder =
    order.orderSource === 'landing_page' ||
    Boolean(order.landingSlug) ||
    Boolean(order.deliverySlot?.includes('Landing Page')) ||
    Boolean(order.notes?.includes('Landing Page'));

  const fullCustomerNote = [
    `Order No: ${order.orderNo} (${order.invoiceNo})${isLandingOrder ? ' [Landing Page Order]' : ''}`,
    `Items:\n${itemSummaryLines.join('\n')}`,
    order.deliverySlot ? `Delivery Slot: ${order.deliverySlot}` : '',
    order.notes ? `Customer Note: ${order.notes}` : ''
  ]
    .filter(Boolean)
    .join('\n\n');

  const billingAndShipping = {
    first_name: firstName,
    last_name: lastName,
    address_1: order.deliveryAddress || 'Bangladesh',
    city: order.deliveryArea || 'Dhaka',
    country: 'BD',
    phone: order.customerPhone
  };

  const shippingLines =
    business.wpSyncIncludeDeliveryFee !== false && order.deliveryCharge > 0
      ? [
          {
            method_id: 'flat_rate',
            method_title: 'Home Delivery Charge',
            total: String(order.deliveryCharge)
          }
        ]
      : [];

  const lineItems: Array<Record<string, any>> = [];
  const feeLines: Array<Record<string, any>> = [];

  for (const it of order.items) {
    const { variantText } = parseItemNameAndVariant(it);
    const wpProdId = Number(it.wpProductId || 0);
    const wpVarId = Number(it.wpVariationId || 0);
    const effectiveItemSku = it.variantSku || it.sku || it.parentSku || '';

    if (!useFeeLinesFallback && wpProdId > 0) {
      const metaData: Array<{ key: string; value: string }> = [];
      if (variantText) {
        metaData.push({ key: 'Size', value: variantText });
        metaData.push({ key: 'size', value: variantText });
        metaData.push({ key: 'pa_size', value: variantText });
        metaData.push({ key: 'attribute_pa_size', value: variantText });
        metaData.push({ key: 'attribute_size', value: variantText });
        metaData.push({ key: 'সাইজ / ভেরিয়েশন', value: variantText });
      }
      if (it.variantSku) {
        metaData.push({ key: 'Variation SKU', value: it.variantSku });
      }
      if (it.parentSku) {
        metaData.push({ key: 'Product SKU', value: it.parentSku });
      }
      if (effectiveItemSku) {
        metaData.push({ key: 'SKU', value: effectiveItemSku });
      }
      lineItems.push({
        product_id: wpProdId,
        ...(wpVarId > 0 ? { variation_id: wpVarId } : {}),
        ...(effectiveItemSku ? { sku: effectiveItemSku } : {}),
        name: it.productName,
        quantity: Number(it.quantity) || 1,
        subtotal: String(it.total),
        total: String(it.total),
        ...(metaData.length > 0 ? { meta_data: metaData } : {})
      });
    } else {
      feeLines.push({
        name: `${it.productName}${effectiveItemSku ? ` [${effectiveItemSku}]` : ''} × ${it.quantity}`,
        total: String(it.total),
        tax_status: 'none'
      });
    }
  }

  return {
    payment_method: 'cod',
    payment_method_title: 'Cash on Delivery (COD)',
    set_paid: false,
    status: business.wpDefaultOrderStatus || 'processing',
    currency: 'BDT',
    customer_note: fullCustomerNote,
    billing: {
      ...billingAndShipping,
      email: `${order.customerPhone.replace(/\D/g, '') || 'customer'}@order.local`
    },
    shipping: billingAndShipping,
    ...(lineItems.length > 0 ? { line_items: lineItems } : {}),
    ...(feeLines.length > 0 ? { fee_lines: feeLines } : {}),
    shipping_lines: shippingLines,
    meta_data: [
      { key: '_external_order_no', value: order.orderNo },
      { key: '_external_invoice_no', value: order.invoiceNo },
      { key: '_external_order_source', value: isLandingOrder ? 'landing_page' : 'storefront' },
      ...(order.landingSlug ? [{ key: '_external_landing_slug', value: order.landingSlug }] : []),
      { key: '_external_source_store', value: business.nameEn || business.name },
      { key: '_external_items_json', value: JSON.stringify(order.items) }
    ]
  };
};

/**
 * Tests connection to the remote WordPress (WooCommerce) website REST API
 */
export const testWordPressConnection = async (params: {
  siteUrl: string;
  consumerKey: string;
  consumerSecret: string;
}): Promise<{ ok: boolean; message: string; storeInfo?: string }> => {
  const siteUrl = normalizeWpSiteUrl(params.siteUrl);
  const ck = params.consumerKey.trim();
  const cs = params.consumerSecret.trim();

  if (!siteUrl || !ck || !cs) {
    return {
      ok: false,
      message: 'অনুগ্রহ করে WordPress Site URL, Consumer Key (ck_...) এবং Consumer Secret (cs_...) পূরণ করুন।'
    };
  }

  // 1. Try server-side proxy first (avoids CORS issues on custom WordPress domains)
  try {
    const proxyRes = await fetch('/api/wp-sync-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'test_connection',
        siteUrl,
        consumerKey: ck,
        consumerSecret: cs
      })
    });

    if (proxyRes.ok) {
      const data = await proxyRes.json();
      if (data && typeof data.ok === 'boolean') {
        return data;
      }
    }
  } catch {
    // Fallback to direct client-side fetch below
  }

  // 2. Direct browser fallback to WooCommerce REST API
  try {
    const endpoint = `${siteUrl}/wp-json/wc/v3/orders?per_page=1&consumer_key=${encodeURIComponent(
      ck
    )}&consumer_secret=${encodeURIComponent(cs)}`;
    const directRes = await fetch(endpoint, {
      method: 'GET',
      headers: { Accept: 'application/json' }
    });

    if (directRes.ok) {
      return {
        ok: true,
        message: `সফলভাবে কানেক্ট হয়েছে! (${siteUrl} - WooCommerce REST API v3 সচল আছে)`
      };
    }

    const errText = await directRes.text();
    return {
      ok: false,
      message: `WordPress সার্ভার রেসপন্স কোড ${directRes.status}: ${errText.slice(0, 140)}`
    };
  } catch (err: any) {
    return {
      ok: false,
      message: `কানেকশন ব্যর্থ হয়েছে: ${err?.message || 'Site URL বা API Key যাচাই করুন'}`
    };
  }
};

/**
 * Fetches existing WooCommerce products from WordPress so the admin can auto-match or map Product IDs
 */
export const fetchWordPressProducts = async (params: {
  siteUrl: string;
  consumerKey: string;
  consumerSecret: string;
}): Promise<{ ok: boolean; products: RemoteWooProduct[]; message: string }> => {
  const siteUrl = normalizeWpSiteUrl(params.siteUrl);
  const ck = params.consumerKey.trim();
  const cs = params.consumerSecret.trim();

  if (!siteUrl || !ck || !cs) {
    return {
      ok: false,
      products: [],
      message: 'প্রথমে WordPress Site URL, Consumer Key এবং Consumer Secret দিন।'
    };
  }

  // 1. Server-side proxy
  try {
    const proxyRes = await fetch('/api/wp-sync-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'fetch_products',
        siteUrl,
        consumerKey: ck,
        consumerSecret: cs
      })
    });
    if (proxyRes.ok) {
      const data = await proxyRes.json();
      if (data && typeof data.ok === 'boolean') {
        return {
          ok: data.ok,
          products: Array.isArray(data.products) ? data.products : [],
          message: data.message || ''
        };
      }
    }
  } catch {
    // Fallback to direct browser call
  }

  // 2. Direct browser call
  try {
    const endpoint = `${siteUrl}/wp-json/wc/v3/products?per_page=100&consumer_key=${encodeURIComponent(
      ck
    )}&consumer_secret=${encodeURIComponent(cs)}`;
    const directRes = await fetch(endpoint, {
      method: 'GET',
      headers: { Accept: 'application/json' }
    });
    const list = await directRes.json().catch(() => []);
    if (directRes.ok && Array.isArray(list)) {
      const mapped: RemoteWooProduct[] = list.map((p: any) => ({
        id: Number(p.id),
        name: String(p.name || ''),
        sku: String(p.sku || ''),
        price: String(p.price || p.regular_price || '0'),
        regular_price: String(p.regular_price || p.price || '0'),
        status: String(p.status || 'publish'),
        permalink: p.permalink ? String(p.permalink) : undefined
      }));
      return {
        ok: true,
        products: mapped,
        message: `WordPress থেকে ${mapped.length} টি প্রোডাক্ট লোড হয়েছে!`
      };
    }
    return {
      ok: false,
      products: [],
      message: list?.message || `WordPress প্রোডাক্ট লোড ব্যর্থ (HTTP ${directRes.status})`
    };
  } catch (err: any) {
    return {
      ok: false,
      products: [],
      message: `নেটওয়ার্ক ত্রুটি: ${err?.message || 'WordPress প্রোডাক্ট লোড করা যায়নি'}`
    };
  }
};

/**
 * Creates or matches a local product (+ its variations & variation SKUs) directly in WordPress WooCommerce
 * and returns its WooCommerce Product ID (`wpProductId`) and `variantMappings` (`wpVariationId`)
 */
export const syncSingleProductToWordPress = async (params: {
  siteUrl: string;
  consumerKey: string;
  consumerSecret: string;
  product: Product;
}): Promise<{
  ok: boolean;
  wpProductId?: number;
  variantMappings?: Array<{ id: string; sku: string; wpVariationId: number }>;
  message: string;
}> => {
  const siteUrl = normalizeWpSiteUrl(params.siteUrl);
  const ck = params.consumerKey.trim();
  const cs = params.consumerSecret.trim();
  const { product } = params;

  if (!siteUrl || !ck || !cs) {
    return {
      ok: false,
      message: 'WordPress Site URL, Consumer Key এবং Consumer Secret প্রয়োজন।'
    };
  }

  const normalizedVariants = Array.isArray(product.variants)
    ? product.variants.map((v, idx) => ({
        ...v,
        sku: (v.sku || '').trim() || buildVariantSkuCode(product.sku, v.label, idx)
      }))
    : [];

  try {
    const proxyRes = await fetch('/api/wp-sync-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'sync_product',
        siteUrl,
        consumerKey: ck,
        consumerSecret: cs,
        product: {
          id: product.id,
          wpProductId: product.wpProductId,
          nameBn: product.nameBn,
          nameEn: product.nameEn,
          sku: product.sku,
          regularPrice: product.regularPrice || product.retailPrice,
          retailPrice: product.retailPrice,
          description: product.description || '',
          variants: normalizedVariants
        }
      })
    });
    if (proxyRes.ok) {
      const data = await proxyRes.json();
      if (data && typeof data.ok === 'boolean') {
        return data;
      }
    }
  } catch {
    // Fallback below
  }

  // Direct browser fallback (supports both Simple and Variable products with Variation SKUs)
  try {
    const queryAuth = `consumer_key=${encodeURIComponent(ck)}&consumer_secret=${encodeURIComponent(cs)}`;
    let resolvedWpProdId = Number(product.wpProductId || 0);

    // 1. Check by SKU first
    if (!resolvedWpProdId && product.sku) {
      const skuRes = await fetch(
        `${siteUrl}/wp-json/wc/v3/products?sku=${encodeURIComponent(product.sku)}&${queryAuth}`
      );
      const skuList = await skuRes.json().catch(() => []);
      if (skuRes.ok && Array.isArray(skuList) && skuList.length > 0 && skuList[0].id) {
        resolvedWpProdId =
          Number(skuList[0].parent_id) > 0
            ? Number(skuList[0].parent_id)
            : Number(skuList[0].id);
      }
    }

    // 2. Create in WooCommerce if not found
    const regPrice = Math.max(product.regularPrice || product.retailPrice, product.retailPrice);
    const hasSale = product.retailPrice < regPrice;
    const hasVariants = normalizedVariants.length > 0;

    if (!resolvedWpProdId) {
      const createRes = await fetch(`${siteUrl}/wp-json/wc/v3/products?${queryAuth}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          name: product.nameBn,
          type: hasVariants ? 'variable' : 'simple',
          status: 'publish',
          sku: product.sku || undefined,
          regular_price: String(regPrice),
          ...(hasSale ? { sale_price: String(product.retailPrice) } : {}),
          description: product.description || '',
          ...(hasVariants
            ? {
                attributes: [
                  {
                    name: 'Size',
                    visible: true,
                    variation: true,
                    options: normalizedVariants.map(v => v.label.trim())
                  }
                ]
              }
            : {})
        })
      });
      const createdJson = await createRes.json().catch(() => null);
      if (createRes.ok && createdJson && createdJson.id) {
        resolvedWpProdId = Number(createdJson.id);
      } else {
        return {
          ok: false,
          message: createdJson?.message || `WordPress প্রোডাক্ট তৈরি ব্যর্থ (HTTP ${createRes.status})`
        };
      }
    }

    // 3. Sync variations & Variation SKUs if product has variants
    const variantMappings: Array<{ id: string; sku: string; wpVariationId: number }> = [];
    if (resolvedWpProdId > 0 && hasVariants) {
      try {
        await fetch(`${siteUrl}/wp-json/wc/v3/products/${resolvedWpProdId}?${queryAuth}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({
            type: 'variable',
            attributes: [
              {
                name: 'Size',
                visible: true,
                variation: true,
                options: normalizedVariants.map(v => v.label.trim())
              }
            ]
          })
        }).catch(() => {});

        const existingVarsRes = await fetch(
          `${siteUrl}/wp-json/wc/v3/products/${resolvedWpProdId}/variations?per_page=100&${queryAuth}`
        );
        const existingVars = await existingVarsRes.json().catch(() => []);
        const validExisting = Array.isArray(existingVars) ? existingVars : [];

        for (const v of normalizedVariants) {
          const match = validExisting.find(
            (rv: any) =>
              (v.sku && String(rv.sku || '').toLowerCase() === v.sku.toLowerCase()) ||
              (Array.isArray(rv.attributes) &&
                rv.attributes.some(
                  (a: any) =>
                    String(a.option || '').trim().toLowerCase() === v.label.trim().toLowerCase()
                ))
          );

          if (match && match.id) {
            variantMappings.push({
              id: v.id,
              sku: v.sku || String(match.sku || ''),
              wpVariationId: Number(match.id)
            });
          } else {
            const vReg = Math.max(v.regularPrice || v.retailPrice, v.retailPrice);
            const vSale = v.retailPrice < vReg ? String(v.retailPrice) : undefined;
            const cVarRes = await fetch(
              `${siteUrl}/wp-json/wc/v3/products/${resolvedWpProdId}/variations?${queryAuth}`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                body: JSON.stringify({
                  regular_price: String(vReg),
                  ...(vSale ? { sale_price: vSale } : {}),
                  ...(v.sku ? { sku: v.sku } : {}),
                  attributes: [{ name: 'Size', option: v.label.trim() }]
                })
              }
            );
            const cVarJson = await cVarRes.json().catch(() => null);
            if (cVarRes.ok && cVarJson && cVarJson.id) {
              variantMappings.push({
                id: v.id,
                sku: v.sku,
                wpVariationId: Number(cVarJson.id)
              });
            }
          }
        }
      } catch {
        // Ignore variation sync errors and return parent product ID
      }
    }

    return {
      ok: true,
      wpProductId: resolvedWpProdId,
      variantMappings,
      message: `"${product.nameBn}" WordPress প্রোডাক্ট #${resolvedWpProdId}${
        variantMappings.length > 0 ? ` (${variantMappings.length} টি ভ্যারিয়েশন SKU সহ)` : ''
      }-এর সাথে লিংক হয়েছে!`
    };
  } catch (err: any) {
    return {
      ok: false,
      message: `ত্রুটি: ${err?.message || 'WordPress সংযোগ ব্যর্থ'}`
    };
  }
};

// Track in-flight order syncs to prevent duplicate WordPress order creation
const inFlightOrderSyncs = new Set<string>();

/**
 * Syncs a placed OnlineOrder (from Storefront, Landing Page, or Incomplete Order Recovery)
 * to the configured WordPress (WooCommerce) website.
 * Automatically resolves or creates real WooCommerce `line_items` products & variations (with Product ID, Variation ID, SKU, Variation SKU).
 */
export const syncOrderToWordPress = async (params: {
  business: Business;
  order: OnlineOrder;
  productsCatalog?: Product[];
  forceSync?: boolean;
}): Promise<{ ok: boolean; wpOrderId?: number | string; message: string }> => {
  const { business, order, productsCatalog, forceSync = false } = params;

  if (!forceSync && !business.wpSyncEnabled) {
    return { ok: false, message: 'WordPress Order Sync বন্ধ রয়েছে' };
  }

  // Idempotency guard: if this orderNo was already synced or is currently syncing (and not forced manually)
  if (!forceSync && order.orderNo) {
    if (inFlightOrderSyncs.has(order.orderNo)) {
      return { ok: true, message: 'অর্ডারটি বর্তমানে WordPress-এ সিঙ্ক হচ্ছে...' };
    }
    const existingSuccess = getWordPressSyncLogs().find(
      l => l.localOrderNo === order.orderNo && l.status === 'success'
    );
    if (existingSuccess) {
      return {
        ok: true,
        wpOrderId: existingSuccess.wpOrderId,
        message: existingSuccess.message
      };
    }
  }

  const siteUrl = normalizeWpSiteUrl(business.wpSiteUrl);
  const ck = (business.wpConsumerKey || '').trim();
  const cs = (business.wpConsumerSecret || '').trim();

  if (!siteUrl || !ck || !cs) {
    return {
      ok: false,
      message: 'WordPress Site URL বা Consumer Key/Secret কনফিগার করা হয়নি'
    };
  }

  if (order.orderNo) {
    inFlightOrderSyncs.add(order.orderNo);
  }

  try {
    const enrichedOrder = enrichOrderWithCatalog(order, productsCatalog);
    const wcOrderPayload = buildWooCommerceOrderPayload(business, enrichedOrder, false);

    // 1. Try server-side proxy (/api/wp-sync-order) first — it automatically matches/creates WooCommerce product_id & variation_id for every line_item!
    try {
      const proxyRes = await fetch('/api/wp-sync-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_order',
          siteUrl,
          consumerKey: ck,
          consumerSecret: cs,
          orderPayload: wcOrderPayload,
          rawOrder: enrichedOrder
        })
      });

      if (proxyRes.ok) {
        const data = await proxyRes.json();
        if (data && data.ok) {
          saveWordPressSyncLog({
            id: `wpsync_${order.orderNo}`,
            localOrderNo: order.orderNo,
            customerName: order.customerName,
            customerPhone: order.customerPhone,
            grandTotal: order.grandTotal,
            wpOrderId: data.wpOrderId,
            wpOrderStatus: data.wpOrderStatus || business.wpDefaultOrderStatus || 'processing',
            status: 'success',
            message: data.message || `WordPress Order #${data.wpOrderId} (প্রোডাক্ট ও ভেরিয়েশনসহ) তৈরি হয়েছে`,
            syncedAt: new Date().toISOString(),
            payloadSnapshot: enrichedOrder
          });
          return {
            ok: true,
            wpOrderId: data.wpOrderId,
            message: data.message || `WordPress Order #${data.wpOrderId} (প্রোডাক্ট ও ভেরিয়েশনসহ) তৈরি হয়েছে`
          };
        }
        if (data && data.ok === false && data.message) {
          saveWordPressSyncLog({
            id: `wpsync_${order.orderNo}`,
            localOrderNo: order.orderNo,
            customerName: order.customerName,
            customerPhone: order.customerPhone,
            grandTotal: order.grandTotal,
            status: 'failed',
            message: data.message,
            syncedAt: new Date().toISOString(),
            payloadSnapshot: enrichedOrder
          });
          return { ok: false, message: data.message };
        }
      }
    } catch {
      // Fallback to direct client-side WooCommerce REST API call
    }

    // 2. Direct Browser Fallback to WooCommerce REST API v3 (with automatic client-side product + variation matching/creation)
    const queryAuth = `consumer_key=${encodeURIComponent(ck)}&consumer_secret=${encodeURIComponent(cs)}`;
    const resolvedItems: SaleItem[] = [];

    for (const item of enrichedOrder.items) {
      let resolvedWpId = Number(item.wpProductId || 0);
      let resolvedWpVarId = Number(item.wpVariationId || 0);
      const { cleanName, variantText } = parseItemNameAndVariant(item);
      const candidateVarSku = (item.variantSku || item.sku || '').trim();
      const candidateParentSku = (item.parentSku || item.sku || '').trim();

      // A. Lookup by Variation SKU first (returns parent_id & variation id if matched in WooCommerce)
      if (candidateVarSku && (!resolvedWpId || (variantText && !resolvedWpVarId))) {
        try {
          const skuRes = await fetch(
            `${siteUrl}/wp-json/wc/v3/products?sku=${encodeURIComponent(candidateVarSku)}&${queryAuth}`
          );
          const skuJson = await skuRes.json().catch(() => []);
          if (skuRes.ok && Array.isArray(skuJson) && skuJson.length > 0 && skuJson[0].id) {
            if (Number(skuJson[0].parent_id) > 0) {
              resolvedWpId = Number(skuJson[0].parent_id);
              resolvedWpVarId = Number(skuJson[0].id);
            } else {
              resolvedWpId = Number(skuJson[0].id);
            }
          }
        } catch {
          // Ignore
        }
      }

      // B. Lookup by Parent Product SKU if parent ID still not resolved
      if (!resolvedWpId && candidateParentSku && candidateParentSku !== candidateVarSku) {
        try {
          const pSkuRes = await fetch(
            `${siteUrl}/wp-json/wc/v3/products?sku=${encodeURIComponent(candidateParentSku)}&${queryAuth}`
          );
          const pSkuJson = await pSkuRes.json().catch(() => []);
          if (pSkuRes.ok && Array.isArray(pSkuJson) && pSkuJson.length > 0 && pSkuJson[0].id) {
            resolvedWpId =
              Number(pSkuJson[0].parent_id) > 0
                ? Number(pSkuJson[0].parent_id)
                : Number(pSkuJson[0].id);
          }
        } catch {
          // Ignore
        }
      }

      // C. Lookup by Product Name
      if (!resolvedWpId && cleanName) {
        try {
          const searchRes = await fetch(
            `${siteUrl}/wp-json/wc/v3/products?search=${encodeURIComponent(cleanName)}&per_page=5&${queryAuth}`
          );
          const searchJson = await searchRes.json().catch(() => []);
          if (searchRes.ok && Array.isArray(searchJson) && searchJson.length > 0 && searchJson[0].id) {
            resolvedWpId =
              Number(searchJson[0].parent_id) > 0
                ? Number(searchJson[0].parent_id)
                : Number(searchJson[0].id);
          }
        } catch {
          // Ignore
        }
      }

      // D. Auto-Create Product in WooCommerce if not found
      if (!resolvedWpId && cleanName) {
        try {
          const createProdRes = await fetch(`${siteUrl}/wp-json/wc/v3/products?${queryAuth}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({
              name: cleanName,
              type: variantText ? 'variable' : 'simple',
              status: 'publish',
              regular_price: String(item.unitPrice),
              ...(candidateParentSku ? { sku: candidateParentSku } : {}),
              ...(variantText
                ? {
                    attributes: [
                      {
                        name: 'Size',
                        visible: true,
                        variation: true,
                        options: [variantText]
                      }
                    ]
                  }
                : {})
            })
          });
          const createdProd = await createProdRes.json().catch(() => null);
          if (createProdRes.ok && createdProd && createdProd.id) {
            resolvedWpId = Number(createdProd.id);
          }
        } catch {
          // Ignore
        }
      }

      // E. Resolve or Auto-Create Variation ID when product has a variation
      if (resolvedWpId > 0 && !resolvedWpVarId && (variantText || candidateVarSku)) {
        try {
          const varListRes = await fetch(
            `${siteUrl}/wp-json/wc/v3/products/${resolvedWpId}/variations?per_page=100&${queryAuth}`
          );
          const varListJson = await varListRes.json().catch(() => []);
          if (varListRes.ok && Array.isArray(varListJson)) {
            const matchedVar = varListJson.find(
              (rv: any) =>
                (candidateVarSku &&
                  String(rv.sku || '').trim().toLowerCase() === candidateVarSku.toLowerCase()) ||
                (variantText && isVariationAttributeMatch(rv, variantText))
            );
            if (matchedVar && matchedVar.id) {
              resolvedWpVarId = Number(matchedVar.id);
            } else if (variantText) {
              const createVarRes = await fetch(
                `${siteUrl}/wp-json/wc/v3/products/${resolvedWpId}/variations?${queryAuth}`,
                {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                  body: JSON.stringify({
                    regular_price: String(item.unitPrice),
                    ...(candidateVarSku ? { sku: candidateVarSku } : {}),
                    attributes: [{ name: 'Size', option: variantText }]
                  })
                }
              );
              const createdVar = await createVarRes.json().catch(() => null);
              if (createVarRes.ok && createdVar && createdVar.id) {
                resolvedWpVarId = Number(createdVar.id);
              }
            }
          }
        } catch {
          // Ignore
        }
      }

      resolvedItems.push({
        ...item,
        wpProductId: resolvedWpId > 0 ? resolvedWpId : undefined,
        wpVariationId: resolvedWpVarId > 0 ? resolvedWpVarId : undefined
      });
    }

    const finalOrder = { ...enrichedOrder, items: resolvedItems };
    const payloadWithLineItems = buildWooCommerceOrderPayload(business, finalOrder, false);
    const endpoint = `${siteUrl}/wp-json/wc/v3/orders?${queryAuth}`;

    let directRes = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      body: JSON.stringify(payloadWithLineItems)
    });

    let json = await directRes.json().catch(() => null);

    // Safety fallback: if line_items failed for any reason, retry with fee_lines so order is never lost
    if (!directRes.ok || !json?.id) {
      const fallbackPayload = buildWooCommerceOrderPayload(business, finalOrder, true);
      directRes = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: JSON.stringify(fallbackPayload)
      });
      json = await directRes.json().catch(() => null);
    }

    if (directRes.ok && json && json.id) {
      const msg = `WordPress-এ অর্ডার #${json.id} (প্রোডাক্ট ও ভেরিয়েশনসহ) সফলভাবে তৈরি হয়েছে`;
      saveWordPressSyncLog({
        id: `wpsync_${order.orderNo}`,
        localOrderNo: order.orderNo,
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        grandTotal: order.grandTotal,
        wpOrderId: json.id,
        wpOrderStatus: json.status || business.wpDefaultOrderStatus || 'processing',
        status: 'success',
        message: msg,
        syncedAt: new Date().toISOString(),
        payloadSnapshot: finalOrder
      });
      return { ok: true, wpOrderId: json.id, message: msg };
    }

    const errMsg =
      json?.message ||
      `WordPress অর্ডার সিঙ্ক ব্যর্থ (HTTP ${directRes.status})`;
    saveWordPressSyncLog({
      id: `wpsync_${order.orderNo}`,
      localOrderNo: order.orderNo,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      grandTotal: order.grandTotal,
      status: 'failed',
      message: errMsg,
      syncedAt: new Date().toISOString(),
      payloadSnapshot: finalOrder
    });
    return { ok: false, message: errMsg };
  } catch (err: any) {
    const errMsg = `নেটওয়ার্ক ত্রুটি: ${err?.message || 'WordPress সাইটে সংযোগ পাওয়া যায়নি'}`;
    saveWordPressSyncLog({
      id: `wpsync_${order.orderNo}`,
      localOrderNo: order.orderNo,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      grandTotal: order.grandTotal,
      status: 'failed',
      message: errMsg,
      syncedAt: new Date().toISOString(),
      payloadSnapshot: enrichOrderWithCatalog(order, productsCatalog)
    });
    return { ok: false, message: errMsg };
  } finally {
    if (order.orderNo) {
      inFlightOrderSyncs.delete(order.orderNo);
    }
  }
};
