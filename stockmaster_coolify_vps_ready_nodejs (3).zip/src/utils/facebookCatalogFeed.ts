import { Business, Product, Brand } from '../types';
import { getEffectiveProductDescription } from '../components/ProductSeoHelmet';

export interface FacebookCatalogFeedItem {
  id: string;
  title: string;
  description: string;
  availability: 'in stock' | 'out of stock';
  condition: 'new';
  price: string;
  sale_price: string;
  link: string;
  image_link: string;
  brand: string;
}

const slugifyProductText = (text: string): string =>
  (text || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

export const buildCatalogProductSlug = (product: Product): string => {
  const base = slugifyProductText(product.nameEn || product.sku || product.id);
  return base ? `${base}--${product.id}` : product.id;
};

export const buildCatalogProductLink = (origin: string, product: Product): string => {
  const cleanOrigin = (origin || '').replace(/\/+$/, '');
  return `${cleanOrigin}/product/${buildCatalogProductSlug(product)}`;
};

export const cleanCatalogDescription = (raw: string): string => {
  if (!raw) return '';
  return raw
    .replace(/<[^>]*>/g, ' ')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
};

export const resolveCatalogImageLink = (
  origin: string,
  product: Product,
  business?: Business
): string => {
  const cleanOrigin = (origin || '').replace(/\/+$/, '');
  const rawImg =
    (product.image && product.image.trim() !== ''
      ? product.image.trim()
      : product.galleryImages?.[0]?.trim()) ||
    business?.logoUrl?.trim() ||
    '';

  if (rawImg.startsWith('http://') || rawImg.startsWith('https://')) {
    return rawImg;
  }

  if (rawImg.startsWith('/') && !rawImg.startsWith('//')) {
    return `${cleanOrigin}${rawImg}`;
  }

  // For base64 data:image/... or fallback images, serve via the dynamic HTTP image endpoint
  // so Meta Commerce Manager always receives a valid https:// image URL.
  return `${cleanOrigin}/api/index.php?route=product-image&id=${encodeURIComponent(product.id)}`;
};

export const getProductTotalAvailableStock = (product: Product): number => {
  if (!product.stockByOutlet || typeof product.stockByOutlet !== 'object') {
    return 10;
  }
  return Object.values(product.stockByOutlet).reduce(
    (sum, qty) => sum + Math.max(0, Number(qty) || 0),
    0
  );
};

export const mapProductsToFacebookCatalogItems = (params: {
  products: Product[];
  business: Business;
  brands?: Brand[];
  origin?: string;
}): FacebookCatalogFeedItem[] => {
  const { products, business, brands = [], origin: customOrigin } = params;
  const origin =
    customOrigin ||
    (typeof window !== 'undefined' ? window.location.origin : 'https://example.com');

  const cleanStoreName =
    (business.name || '').replace('স্টকমাস্টার বিডি - ', '').trim() ||
    business.nameEn ||
    'Online Store';

  return products.map(product => {
    const totalStock = getProductTotalAvailableStock(product);
    const availability: 'in stock' | 'out of stock' =
      totalStock > 0 ? 'in stock' : 'out of stock';

    // Determine effective selling price and regular price
    const primaryVariant =
      product.variants && product.variants.length > 0 ? product.variants[0] : undefined;
    const effectiveSellingPrice = Number(
      primaryVariant ? primaryVariant.retailPrice : product.retailPrice
    ) || 0;

    const rawRegularPrice = Number(
      primaryVariant?.regularPrice ?? product.regularPrice ?? 0
    );
    const rawDiscountPrice = Number(
      primaryVariant?.discountPrice ?? product.discountPrice ?? 0
    );

    const hasDiscount =
      rawRegularPrice > effectiveSellingPrice && rawDiscountPrice !== 0;

    const regularPriceVal = hasDiscount ? rawRegularPrice : effectiveSellingPrice;
    const salePriceVal = hasDiscount ? effectiveSellingPrice : 0;

    const brandObj = brands.find(b => b.id === product.brandId);
    const brandName = (brandObj?.name || cleanStoreName).trim();

    const rawDesc = getEffectiveProductDescription(product);
    const cleanDesc = cleanCatalogDescription(rawDesc) || product.nameBn || product.nameEn;

    return {
      id: String(product.id).trim(),
      title: (product.nameBn || product.nameEn || product.sku).trim(),
      description: cleanDesc,
      availability,
      condition: 'new',
      price: `${regularPriceVal.toFixed(0)} BDT`,
      sale_price: salePriceVal > 0 ? `${salePriceVal.toFixed(0)} BDT` : '',
      link: buildCatalogProductLink(origin, product),
      image_link: resolveCatalogImageLink(origin, product, business),
      brand: brandName
    };
  });
};

const escapeCsvCell = (value: string): string => {
  const normalized = String(value ?? '')
    .replace(/\r\n/g, ' ')
    .replace(/[\r\n]/g, ' ')
    .trim();
  if (
    normalized.includes(',') ||
    normalized.includes('"') ||
    normalized.includes('\n') ||
    normalized.includes('\r')
  ) {
    return `"${normalized.replace(/"/g, '""')}"`;
  }
  return normalized;
};

/**
 * Generates a Meta Commerce Manager compliant CSV string with UTF-8 BOM (\uFEFF)
 * so Bengali text renders accurately in Microsoft Excel and Facebook Catalog uploads.
 */
export const generateFacebookCatalogCsv = (items: FacebookCatalogFeedItem[]): string => {
  const headers: Array<keyof FacebookCatalogFeedItem> = [
    'id',
    'title',
    'description',
    'availability',
    'condition',
    'price',
    'sale_price',
    'link',
    'image_link',
    'brand'
  ];

  const rows: string[] = [headers.join(',')];
  for (const item of items) {
    const row = headers.map(key => escapeCsvCell(item[key] || ''));
    rows.push(row.join(','));
  }

  return '\uFEFF' + rows.join('\r\n');
};

const escapeXmlText = (value: string): string =>
  String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');

/**
 * Generates a Meta Commerce Manager compliant RSS 2.0 XML Product Feed
 * with the Google Base `xmlns:g="http://base.google.com/ns/1.0"` namespace.
 */
export const generateFacebookCatalogXml = (params: {
  items: FacebookCatalogFeedItem[];
  business: Business;
  origin?: string;
}): string => {
  const { items, business, origin: customOrigin } = params;
  const origin =
    customOrigin ||
    (typeof window !== 'undefined' ? window.location.origin : 'https://example.com');
  const cleanStoreName =
    (business.name || '').replace('স্টকমাস্টার বিডি - ', '').trim() ||
    business.nameEn ||
    'Online Store';

  const xmlItems = items
    .map(item => {
      const lines = [
        '    <item>',
        `      <g:id>${escapeXmlText(item.id)}</g:id>`,
        `      <g:title>${escapeXmlText(item.title)}</g:title>`,
        `      <g:description>${escapeXmlText(item.description)}</g:description>`,
        `      <g:availability>${escapeXmlText(item.availability)}</g:availability>`,
        `      <g:condition>${escapeXmlText(item.condition)}</g:condition>`,
        `      <g:price>${escapeXmlText(item.price)}</g:price>`
      ];

      if (item.sale_price && item.sale_price.trim() !== '') {
        lines.push(`      <g:sale_price>${escapeXmlText(item.sale_price)}</g:sale_price>`);
      }

      lines.push(
        `      <g:link>${escapeXmlText(item.link)}</g:link>`,
        `      <g:image_link>${escapeXmlText(item.image_link)}</g:image_link>`,
        `      <g:brand>${escapeXmlText(item.brand)}</g:brand>`,
        '    </item>'
      );

      return lines.join('\n');
    })
    .join('\n');

  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">',
    '  <channel>',
    `    <title>${escapeXmlText(cleanStoreName)} - Facebook Product Catalog Feed</title>`,
    `    <link>${escapeXmlText(origin)}</link>`,
    `    <description>${escapeXmlText(
      `Automatic Meta Commerce Manager Product Feed for ${cleanStoreName}`
    )}</description>`,
    xmlItems,
    '  </channel>',
    '</rss>'
  ].join('\n');
};

export const downloadFacebookCatalogCsv = (
  items: FacebookCatalogFeedItem[],
  filename = 'facebook-catalog-feed.csv'
): void => {
  if (typeof window === 'undefined') return;
  const csvContent = generateFacebookCatalogCsv(items);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
};

export const downloadFacebookCatalogXml = (params: {
  items: FacebookCatalogFeedItem[];
  business: Business;
  origin?: string;
  filename?: string;
}): void => {
  if (typeof window === 'undefined') return;
  const xmlContent = generateFacebookCatalogXml(params);
  const blob = new Blob(['\uFEFF' + xmlContent], {
    type: 'application/xml;charset=utf-8;'
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', params.filename || 'facebook-catalog-feed.xml');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
};
