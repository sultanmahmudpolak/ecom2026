const ADMIN_AUTH_TOKEN_KEY = 'sm_admin_auth_token_v1';
const AUTH_SESSION_STORAGE_KEYS = [
  'stockmaster_bd_auth_session_v2',
  'stockmaster_auth_session_v2',
  'stockmaster_bd_persistent_erp_v2'
];

export function getAdminDownloadAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    Accept: 'application/json'
  };
  if (typeof window === 'undefined') return headers;

  try {
    const token = (window.localStorage.getItem(ADMIN_AUTH_TOKEN_KEY) || '').trim();
    if (token) {
      headers['X-Admin-Token'] = token;
      headers['X-CSRF-Token'] = token;
      headers['Authorization'] = `Bearer ${token}`;
    }
    for (const key of AUTH_SESSION_STORAGE_KEYS) {
      const raw = window.localStorage.getItem(key);
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object' && parsed.currentUserId) {
            headers['X-Admin-User-Id'] = String(parsed.currentUserId);
          }
        } catch {}
      }
    }
  } catch {
    // Ignore storage read errors
  }
  return headers;
}

function isClientAdminAuthenticated(): boolean {
  if (typeof window === 'undefined') return true;
  try {
    for (const key of AUTH_SESSION_STORAGE_KEYS) {
      const raw = window.localStorage.getItem(key);
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          if (parsed && (parsed.isAuthenticated === true || parsed.currentUserId)) {
            return true;
          }
        } catch {}
      }
    }
    const token = window.localStorage.getItem(ADMIN_AUTH_TOKEN_KEY);
    if (token && token.trim().length > 0) {
      return true;
    }
    const path = window.location.pathname.toLowerCase();
    const search = window.location.search.toLowerCase();
    if (path.includes('smart') || search.includes('view=') || search.includes('erp')) {
      return true;
    }
    return false;
  } catch {
    return true;
  }
}

export async function downloadVerifiedZip(
  endpoint:
    | '/api/download-coolify-zip'
    | '/api/download-cpanel-zip'
    | '/api/download-source-zip',
  fallbackFilename: string,
  onStatus?: (msg: string, type: 'info' | 'success' | 'error') => void
): Promise<boolean> {
  try {
    if (!isClientAdminAuthenticated()) {
      onStatus?.(
        'অনুমোদিত নয়! শুধুমাত্র অ্যাডমিন লগইন করার পরেই cPanel কোড ডাউনলোড করা যাবে।',
        'error'
      );
      return false;
    }

    onStatus?.('জিপ (.zip) ফাইল তৈরি ও যাচাই করা হচ্ছে, অনুগ্রহ করে ২ সেকেন্ড অপেক্ষা করুন...', 'info');

    const sep = endpoint.includes('?') ? '&' : '?';
    const res = await fetch(`${endpoint}${sep}format=base64`, {
      method: 'GET',
      headers: getAdminDownloadAuthHeaders(),
      credentials: 'same-origin',
    });

    if (res.status === 401 || res.status === 403) {
      const errJson = await res.json().catch(() => null);
      throw new Error(
        errJson?.error ||
          'অনুমোদিত নয়! শুধুমাত্র অ্যাডমিন লগইন করার পরেই cPanel কোড ডাউনলোড করা যাবে।'
      );
    }

    if (!res.ok) {
      throw new Error(`Server returned status ${res.status}`);
    }

    const payload = await res.json();
    if (!payload?.success || !payload?.base64) {
      throw new Error(payload?.error || 'Invalid ZIP response from server');
    }

    const binaryString = window.atob(payload.base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // Verify standard ZIP magic signature: PK\x03\x04 (0x50, 0x4B, 0x03, 0x04)
    if (
      bytes.length < 22 ||
      bytes[0] !== 0x50 ||
      bytes[1] !== 0x4b ||
      bytes[2] !== 0x03 ||
      bytes[3] !== 0x04
    ) {
      throw new Error('Generated archive failed PK signature verification');
    }

    const blob = new Blob([bytes.buffer], { type: 'application/zip' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = payload.filename || fallbackFilename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 5000);

    onStatus?.(
      `সফলভাবে ডাউনলোড হয়েছে: ${payload.filename || fallbackFilename} (${payload.fileCount || ''} টি ফাইল)`,
      'success'
    );
    return true;
  } catch (err: any) {
    console.error('[ZIP Download Error]', err);
    onStatus?.(
      'জিপ ডাউনলোডে সমস্যা হয়েছে: ' + (err?.message || 'আবার চেষ্টা করুন'),
      'error'
    );
    return false;
  }
}

export async function downloadSqlFile(
  filePath: string,
  downloadName: string,
  onStatus?: (msg: string, type: 'info' | 'success' | 'error') => void
): Promise<void> {
  try {
    if (!isClientAdminAuthenticated()) {
      onStatus?.(
        'অনুমোদিত নয়! শুধুমাত্র অ্যাডমিন লগইন করার পরেই ফাইল ডাউনলোড করা যাবে।',
        'error'
      );
      return;
    }

    const res = await fetch(`/api/project-file?path=${encodeURIComponent(filePath)}`, {
      method: 'GET',
      headers: getAdminDownloadAuthHeaders(),
      credentials: 'same-origin',
    });
    if (res.status === 401 || res.status === 403) {
      onStatus?.(
        'অনুমোদিত নয়! শুধুমাত্র অ্যাডমিন লগইন করার পরেই ফাইল ডাউনলোড করা যাবে।',
        'error'
      );
      return;
    }
    if (!res.ok) throw new Error('File fetch failed');
    const text = await res.text();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = downloadName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    onStatus?.(`সফলভাবে ডাউনলোড হয়েছে: ${downloadName}`, 'success');
  } catch (err: any) {
    onStatus?.('ফাইল ডাউনলোডে সমস্যা হয়েছে।', 'error');
  }
}
