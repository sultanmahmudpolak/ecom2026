import { API_CONFIG } from '../config/api';
import { getAdminDownloadAuthHeaders } from './zipDownloader';

/**
 * Returns the fast 440x440 WebP thumbnail URL for product grids/lists when available,
 * or the full 1080x1080 HD WebP URL when preferHd is true (Product Details, Zoom, Landing Page).
 * Existing legacy images (img_*.webp) do not match hd_*.webp so they never trigger 404s.
 */
export function getProductImageUrl(url?: string, preferHd = false): string {
  if (!url) return '';
  const trimmed = url.trim();
  if (!trimmed || preferHd || trimmed.startsWith('data:')) {
    return trimmed;
  }
  if (/\/uploads\/products\/hd_[a-f0-9]+\.webp(\?.*)?$/i.test(trimmed)) {
    return trimmed.replace(/\.webp(\?.*)?$/i, '_thumb.webp$1');
  }
  return trimmed;
}

/**
 * Uploads a client-compressed image Data URL (plus optional 440x440 thumbnail Data URL)
 * to the server (/api/upload-image) so both HD (1080x1080) and Thumbnail (440x440) versions
 * are stored as physical WebP files in /uploads/products/ or /uploads/logos/.
 * Gracefully falls back to the compressed Data URL if offline.
 */
export async function uploadCompressedDataUrlToServer(
  dataUrl: string,
  folder: 'products' | 'logos' = 'products',
  thumbDataUrl?: string
): Promise<string> {
  if (!dataUrl || !dataUrl.startsWith('data:image/')) {
    return dataUrl;
  }

  const base = (API_CONFIG.BASE_URL || '/api').replace(/\/+$/, '');
  const endpoints = Array.from(
    new Set([
      './api/index.php?route=upload-image',
      `${base}/index.php?route=upload-image`,
      `${base}/upload-image`
    ])
  );

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          ...getAdminDownloadAuthHeaders(),
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        credentials: 'same-origin',
        body: JSON.stringify({
          dataUrl,
          thumbDataUrl: thumbDataUrl && thumbDataUrl.startsWith('data:image/') ? thumbDataUrl : undefined,
          folder
        })
      });

      if (response.ok) {
        const result = await response.json().catch(() => null);
        if (result && result.success && typeof result.url === 'string' && result.url.trim() !== '') {
          return result.url.trim();
        }
      }
    } catch {
      // Try next endpoint or fallback
    }
  }

  return dataUrl;
}

/**
 * Generates TWO high-clarity WebP versions on the client using HTML5 Canvas:
 * 1) 1080x1080px HD WebP (88% quality) for Product Detail view, Zoom & Landing Pages
 * 2) 440x440px Fast Thumbnail WebP (86% quality) for Home Shop Grid & Inventory lists
 * Both are saved to /uploads/products/ (returning /uploads/products/hd_<hash>.webp).
 */
export const processUploadedProductImage = (
  file: File,
  maxDimension = 1080,
  quality = 0.88
): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('অনুগ্রহ করে একটি সঠিক ছবির ফাইল (JPG, PNG, WebP) নির্বাচন করুন।'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('ছবিটি পড়া সম্ভব হয়নি।'));
    reader.onload = () => {
      const rawDataUrl = String(reader.result || '');
      if (!rawDataUrl) {
        reject(new Error('খালি ছবির ফাইল।'));
        return;
      }

      const img = new Image();
      img.onerror = () => reject(new Error('ছবিটি লোড করা সম্ভব হয়নি।'));
      img.onload = () => {
        try {
          const isTransparent = file.type === 'image/png' || file.type === 'image/webp';

          const renderResizedDataUrl = (targetMaxDim: number, targetQuality: number): string => {
            let width = img.width;
            let height = img.height;
            if (width > targetMaxDim || height > targetMaxDim) {
              if (width >= height) {
                height = Math.max(1, Math.round((height * targetMaxDim) / width));
                width = targetMaxDim;
              } else {
                width = Math.max(1, Math.round((width * targetMaxDim) / height));
                height = targetMaxDim;
              }
            }

            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (!ctx) return '';

            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            if (isTransparent) {
              ctx.clearRect(0, 0, width, height);
              ctx.drawImage(img, 0, 0, width, height);
              const out = canvas.toDataURL('image/webp', targetQuality);
              if (!out || out.length < 32 || !out.startsWith('data:image/webp')) {
                return canvas.toDataURL('image/png');
              }
              return out;
            } else {
              ctx.fillStyle = '#FFFFFF';
              ctx.fillRect(0, 0, width, height);
              ctx.drawImage(img, 0, 0, width, height);
              const out = canvas.toDataURL('image/webp', targetQuality);
              if (!out || out.length < 32 || !out.startsWith('data:image/webp')) {
                return canvas.toDataURL('image/jpeg', targetQuality);
              }
              return out;
            }
          };

          // 1) 1080x1080px HD WebP (88% quality) for Product Detail, Zoom & Landing Page
          const hdDataUrl = renderResizedDataUrl(maxDimension, quality);
          // 2) 440x440px Fast Thumbnail WebP (86% quality) for Storefront Grid & Admin List
          const thumbDataUrl = renderResizedDataUrl(440, 0.86);

          uploadCompressedDataUrlToServer(
            hdDataUrl || rawDataUrl,
            'products',
            thumbDataUrl || undefined
          ).then(resolve);
        } catch {
          uploadCompressedDataUrlToServer(rawDataUrl, 'products').then(resolve);
        }
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  });
};

/**
 * Processes an uploaded Storefront Logo image while preserving PNG/WebP transparency
 * and wide horizontal aspect ratio, then saves it as a physical file in /uploads/logos/.
 */
export const processUploadedLogoImage = (
  file: File,
  maxWidth = 720,
  maxHeight = 220
): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('অনুগ্রহ করে একটি সঠিক লোগো ফাইল (PNG, JPG, WebP, SVG) নির্বাচন করুন।'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('লোগো ফাইলটি পড়া সম্ভব হয়নি।'));
    reader.onload = () => {
      const rawDataUrl = String(reader.result || '');
      if (file.type === 'image/svg+xml') {
        resolve(rawDataUrl);
        return;
      }
      const img = new Image();
      img.onerror = () => reject(new Error('লোগো ফাইলটি লোড করা সম্ভব হয়নি।'));
      img.onload = () => {
        try {
          let { width, height } = img;
          const ratio = Math.min(maxWidth / width, maxHeight / height, 1);
          width = Math.max(1, Math.round(width * ratio));
          height = Math.max(1, Math.round(height * ratio));

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            uploadCompressedDataUrlToServer(rawDataUrl, 'logos').then(resolve);
            return;
          }

          ctx.clearRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);

          let outUrl = canvas.toDataURL('image/webp', 0.92);
          if (!outUrl || !outUrl.startsWith('data:image/webp')) {
            outUrl = canvas.toDataURL('image/png');
          }
          uploadCompressedDataUrlToServer(outUrl || rawDataUrl, 'logos').then(resolve);
        } catch {
          uploadCompressedDataUrlToServer(rawDataUrl, 'logos').then(resolve);
        }
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  });
};

/**
 * Default logo fallback is empty string so that when no custom logo is uploaded,
 * the logo area stays clean and empty (no placeholder icon or demo name).
 */
export const DEFAULT_DEMO_STORE_LOGO_DATA_URL = '';

