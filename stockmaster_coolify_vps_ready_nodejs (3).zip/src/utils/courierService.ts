import {
  Business,
  OnlineOrder,
  IncompleteOrder,
  CourierFraudCheckResult,
  CourierSingleProviderStats
} from '../types';

export const normalizeBdPhone11 = (raw?: string): string => {
  if (!raw) return '';
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let str = String(raw);
  bnDigits.forEach((bn, idx) => {
    str = str.split(bn).join(String(idx));
  });
  const digits = str.replace(/\D+/g, '');
  if (digits.startsWith('880') && digits.length === 13) {
    return digits.slice(2);
  }
  if (digits.length === 10 && digits.startsWith('1')) {
    return `0${digits}`;
  }
  return digits;
};

export const computeOwnStoreCustomerRecord = (
  rawPhone: string,
  onlineOrders: OnlineOrder[],
  incompleteOrders: IncompleteOrder[] = []
) => {
  const cleanPhone = normalizeBdPhone11(rawPhone);
  if (!cleanPhone || cleanPhone.length < 10) {
    return {
      phone: cleanPhone,
      totalOrders: 0,
      delivered: 0,
      cancelled: 0,
      pendingOrProcessing: 0,
      abandonedLeads: 0,
      totalSpentDelivered: 0,
      successRatio: 0,
      riskLevel: 'new' as 'safe' | 'moderate' | 'high_risk' | 'new'
    };
  }

  const matchedOrders = onlineOrders.filter(
    o => normalizeBdPhone11(o.customerPhone) === cleanPhone
  );
  const matchedLeads = incompleteOrders.filter(
    inc =>
      normalizeBdPhone11(inc.customerPhone) === cleanPhone &&
      (inc.status === 'abandoned' || inc.status === 'contacted')
  );

  let delivered = 0;
  let cancelled = 0;
  let pendingOrProcessing = 0;
  let totalSpentDelivered = 0;

  matchedOrders.forEach(o => {
    if (o.orderStatus === 'delivered') {
      delivered += 1;
      totalSpentDelivered += Number(o.grandTotal || 0);
    } else if (o.orderStatus === 'cancelled') {
      cancelled += 1;
    } else {
      pendingOrProcessing += 1;
    }
  });

  const finalizedCount = delivered + cancelled;
  const successRatio =
    finalizedCount > 0
      ? Math.round((delivered / finalizedCount) * 100)
      : matchedOrders.length > 0
      ? 100
      : 0;

  let riskLevel: 'safe' | 'moderate' | 'high_risk' | 'new' = 'new';
  if (finalizedCount > 0) {
    if (successRatio >= 75) riskLevel = 'safe';
    else if (successRatio >= 50) riskLevel = 'moderate';
    else riskLevel = 'high_risk';
  } else if (cancelled >= 2) {
    riskLevel = 'high_risk';
  }

  return {
    phone: cleanPhone,
    totalOrders: matchedOrders.length,
    delivered,
    cancelled,
    pendingOrProcessing,
    abandonedLeads: matchedLeads.length,
    totalSpentDelivered,
    successRatio,
    riskLevel
  };
};

const callCourierBackend = async (payload: Record<string, any>): Promise<any> => {
  const endpoints = ['/api/index.php?route=courier', '/api/courier'];
  for (const url of endpoints) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(() => null);
      if (data && typeof data === 'object') {
        return data;
      }
    } catch {
      // Try next endpoint
    }
  }
  return { ok: false, message: 'সার্ভারের সাথে সংযোগ স্থাপন করা যায়নি।' };
};

export const checkSteadfastBalance = async (
  business: Partial<Business>
): Promise<{ ok: boolean; balance?: number; message: string }> => {
  const res = await callCourierBackend({
    action: 'steadfast_balance',
    steadfastApiKey: business.steadfastApiKey,
    steadfastSecretKey: business.steadfastSecretKey
  });
  return {
    ok: Boolean(res?.ok),
    balance: res?.balance !== undefined ? Number(res.balance) : undefined,
    message: String(res?.message || (res?.ok ? 'Steadfast কানেক্টেড!' : 'Steadfast সংযোগ ব্যর্থ'))
  };
};

export const bookSteadfastOrder = async (
  order: OnlineOrder,
  business: Partial<Business>
): Promise<{
  ok: boolean;
  consignmentId?: string;
  trackingCode?: string;
  status?: string;
  message: string;
}> => {
  const cleanPhone = normalizeBdPhone11(order.customerPhone);
  const itemSummary = order.items
    .map(i => `${i.productName} x${i.quantity}`)
    .join(', ');
  const codAmount = order.paymentStatus === 'paid' ? 0 : Math.round(Number(order.grandTotal || 0));

  const res = await callCourierBackend({
    action: 'steadfast_create_order',
    steadfastApiKey: business.steadfastApiKey,
    steadfastSecretKey: business.steadfastSecretKey,
    invoice: order.orderNo || order.invoiceNo || order.id,
    recipient_name: order.customerName || 'Customer',
    recipient_phone: cleanPhone || order.customerPhone,
    recipient_address: `${order.deliveryAddress}${order.deliveryArea ? `, ${order.deliveryArea}` : ''}`,
    cod_amount: codAmount,
    note: order.notes ? `${order.notes} | Items: ${itemSummary}` : `Items: ${itemSummary}`
  });

  return {
    ok: Boolean(res?.ok),
    consignmentId: res?.consignmentId ? String(res.consignmentId) : undefined,
    trackingCode: res?.trackingCode ? String(res.trackingCode) : undefined,
    status: res?.status ? String(res.status) : undefined,
    message: String(res?.message || (res?.ok ? 'Steadfast-এ বুকিং সফল!' : 'Steadfast বুকিং ব্যর্থ'))
  };
};

export const checkSteadfastOrderStatus = async (
  order: OnlineOrder,
  business: Partial<Business>
): Promise<{ ok: boolean; deliveryStatus?: string; message: string }> => {
  const res = await callCourierBackend({
    action: 'steadfast_status',
    steadfastApiKey: business.steadfastApiKey,
    steadfastSecretKey: business.steadfastSecretKey,
    consignmentId: order.courierConsignmentId,
    trackingCode: order.courierTrackingCode,
    invoice: order.orderNo
  });
  return {
    ok: Boolean(res?.ok),
    deliveryStatus: res?.deliveryStatus ? String(res.deliveryStatus) : undefined,
    message: String(res?.message || 'স্ট্যাটাস চেক সম্পন্ন')
  };
};

export const fetchPathaoStores = async (
  business: Partial<Business>
): Promise<{
  ok: boolean;
  stores: Array<{ store_id: string; store_name: string; store_address: string }>;
  message: string;
}> => {
  const res = await callCourierBackend({
    action: 'pathao_stores',
    pathaoSandbox: business.pathaoSandbox,
    pathaoClientId: business.pathaoClientId,
    pathaoClientSecret: business.pathaoClientSecret,
    pathaoUsername: business.pathaoUsername,
    pathaoPassword: business.pathaoPassword
  });
  return {
    ok: Boolean(res?.ok),
    stores: Array.isArray(res?.stores) ? res.stores : [],
    message: String(res?.message || (res?.ok ? 'Pathao কানেক্টেড!' : 'Pathao সংযোগ ব্যর্থ'))
  };
};

export const bookPathaoOrder = async (
  order: OnlineOrder,
  business: Partial<Business>
): Promise<{
  ok: boolean;
  consignmentId?: string;
  trackingCode?: string;
  status?: string;
  message: string;
}> => {
  const cleanPhone = normalizeBdPhone11(order.customerPhone);
  const totalQty = order.items.reduce((sum, i) => sum + Math.max(1, Number(i.quantity || 1)), 0);
  const itemSummary = order.items
    .map(i => `${i.productName} x${i.quantity}`)
    .join(', ');
  const codAmount = order.paymentStatus === 'paid' ? 0 : Math.round(Number(order.grandTotal || 0));

  const res = await callCourierBackend({
    action: 'pathao_create_order',
    pathaoSandbox: business.pathaoSandbox,
    pathaoClientId: business.pathaoClientId,
    pathaoClientSecret: business.pathaoClientSecret,
    pathaoUsername: business.pathaoUsername,
    pathaoPassword: business.pathaoPassword,
    pathaoStoreId: business.pathaoStoreId,
    store_id: business.pathaoStoreId,
    merchant_order_id: order.orderNo || order.invoiceNo || order.id,
    recipient_name: order.customerName || 'Customer',
    recipient_phone: cleanPhone || order.customerPhone,
    recipient_address: `${order.deliveryAddress}${order.deliveryArea ? `, ${order.deliveryArea}` : ''}`,
    item_quantity: totalQty,
    amount_to_collect: codAmount,
    item_description: itemSummary,
    special_instruction: order.notes || ''
  });

  return {
    ok: Boolean(res?.ok),
    consignmentId: res?.consignmentId ? String(res.consignmentId) : undefined,
    trackingCode: res?.trackingCode ? String(res.trackingCode) : undefined,
    status: res?.status ? String(res.status) : undefined,
    message: String(res?.message || (res?.ok ? 'Pathao-তে বুকিং সফল!' : 'Pathao বুকিং ব্যর্থ'))
  };
};

export const checkCustomerFraudAndRatio = async (
  rawPhone: string,
  business: Partial<Business>,
  onlineOrders: OnlineOrder[],
  incompleteOrders: IncompleteOrder[] = []
): Promise<CourierFraudCheckResult> => {
  const cleanPhone = normalizeBdPhone11(rawPhone);
  const ownStore = computeOwnStoreCustomerRecord(cleanPhone, onlineOrders, incompleteOrders);

  const apiRes = await callCourierBackend({
    action: 'fraud_check',
    phone: cleanPhone,
    steadfastApiKey: business.steadfastApiKey,
    steadfastSecretKey: business.steadfastSecretKey,
    steadfastAuthEmail: business.steadfastAuthEmail,
    steadfastAuthPassword: business.steadfastAuthPassword,
    pathaoSandbox: business.pathaoSandbox,
    pathaoClientId: business.pathaoClientId,
    pathaoClientSecret: business.pathaoClientSecret,
    pathaoUsername: business.pathaoUsername,
    pathaoPassword: business.pathaoPassword,
    bdcourierApiKey: business.bdcourierApiKey
  });

  const sf: CourierSingleProviderStats = apiRes?.steadfast || {
    provider: 'Steadfast',
    total: 0,
    delivered: 0,
    cancelled: 0,
    successRatio: 0,
    status: 'not_configured',
    message: 'কনফিগার করা নেই'
  };

  const pt: CourierSingleProviderStats = apiRes?.pathao || {
    provider: 'Pathao',
    total: 0,
    delivered: 0,
    cancelled: 0,
    successRatio: 0,
    status: 'not_configured',
    message: 'কনফিগার করা নেই'
  };

  const ownFinalized = ownStore.delivered + ownStore.cancelled;
  const combinedDelivered = ownStore.delivered + Number(sf.delivered || 0) + Number(pt.delivered || 0);
  const combinedCancelled = ownStore.cancelled + Number(sf.cancelled || 0) + Number(pt.cancelled || 0);
  const combinedTotalParcels = ownFinalized + Number(sf.total || 0) + Number(pt.total || 0);
  const combinedSuccessRatio =
    combinedTotalParcels > 0
      ? Math.round((combinedDelivered / combinedTotalParcels) * 100)
      : ownStore.totalOrders > 0
      ? 100
      : 0;

  let riskLevel: 'safe' | 'moderate' | 'high_risk' | 'new' = 'new';
  let verdictBn = 'নতুন কাস্টমার (পূর্বে কোনো ডেলিভারি বা রিটার্ন রেকর্ড নেই — ফোন কল করে কনফার্ম করুন)';

  if (combinedTotalParcels > 0) {
    if (combinedSuccessRatio >= 80) {
      riskLevel = 'safe';
      verdictBn = `নিরাপদ কাস্টমার (${combinedSuccessRatio}% সফল ডেলিভারি রেশিও — নির্ভয়ে পার্সেল পাঠাতে পারেন)`;
    } else if (combinedSuccessRatio >= 50) {
      riskLevel = 'moderate';
      verdictBn = `মাঝারি ঝুঁকি (${combinedSuccessRatio}% ডেলিভারি রেশিও — ফোনে কথা বলে অর্ডার কনফার্ম করুন)`;
    } else {
      riskLevel = 'high_risk';
      verdictBn = `উচ্চ ঝুঁকিপূর্ণ / ফ্রড সতর্কতা! (${combinedCancelled}টি পার্সেল রিটার্ন করেছে — অগ্রিম ডেলিভারি চার্জ ছাড়া পাঠাবেন না)`;
    }
  } else if (ownStore.totalOrders > 0) {
    verdictBn = `আপনার স্টোরে ${ownStore.totalOrders}টি অর্ডার রয়েছে (প্রসেসিং/পেন্ডিং)`;
  }

  return {
    phone: cleanPhone,
    ownStore: {
      totalOrders: ownStore.totalOrders,
      delivered: ownStore.delivered,
      cancelled: ownStore.cancelled,
      pendingOrProcessing: ownStore.pendingOrProcessing,
      abandonedLeads: ownStore.abandonedLeads,
      totalSpentDelivered: ownStore.totalSpentDelivered,
      successRatio: ownStore.successRatio
    },
    steadfast: sf,
    pathao: pt,
    combinedTotalParcels,
    combinedDelivered,
    combinedCancelled,
    combinedSuccessRatio,
    riskLevel,
    verdictBn,
    checkedAt: new Date().toISOString()
  };
};

export const getSecretWebhookUrl = (token?: string): string => {
  const origin =
    typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : 'https://yourdomain.com';
  const cleanToken = (token || '').trim();
  return cleanToken
    ? `${origin}/api/index.php?route=courier-webhook&token=${encodeURIComponent(cleanToken)}`
    : `${origin}/api/index.php?route=courier-webhook`;
};
