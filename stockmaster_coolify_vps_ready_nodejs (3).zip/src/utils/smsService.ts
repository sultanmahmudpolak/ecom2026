// Dual Smart SMS Gateway Integration: Alpha SMS (https://api.sms.net.bd) & GreenWeb SMS (https://api.bdbulksms.net)
import type { Business } from '../types';

export type SmsProviderType = 'alpha' | 'greenweb';

export interface SmsLogEntry {
  id: string;
  provider?: SmsProviderType;
  requestId: string | number;
  to: string;
  msg: string;
  status: string;
  error: number;
  responseMsg: string;
  createdAt: string;
}

export const DEFAULT_SMS_TEMPLATES = {
  orderPlaced:
    'প্রিয় {name}, {shop_name}-এ আপনার অর্ডার #{order_no} সফলভাবে গৃহীত হয়েছে। সর্বমোট বিল: ৳{total} (ক্যাশ অন ডেলিভারি)। ধন্যবাদ!',
  adminOrderAlert:
    'নতুন অর্ডার #{order_no}! ক্রেতা: {name} ({phone}), বিল: ৳{total}, পণ্য: {items}, ঠিকানা: {address}। - {shop_name}',
  orderStatus:
    'প্রিয় {name}, আপনার অর্ডার #{order_no}-এর বর্তমান স্ট্যাটাস: {status}। মোট বিল: ৳{total}। - {shop_name}',
  otpReset:
    '{shop_name}: আপনার পাসওয়ার্ড রিসেট কোড (OTP) হলো: {otp}। অনুগ্রহ করে কোডটি দিয়ে নতুন পাসওয়ার্ড সেট করুন।',
  signupOtp:
    '{shop_name}: আপনার নতুন একাউন্ট খোলার ভেরিফিকেশন কোড (OTP) হলো: {otp}। কোডটি দিয়ে সাইনআপ সম্পন্ন করুন।'
};

export interface SmsTemplateVariables {
  name?: string;
  order_no?: string;
  invoice_no?: string;
  total?: string | number;
  status?: string;
  otp?: string;
  shop_name?: string;
  phone?: string;
  address?: string;
  items?: string;
}

export const formatSmsMessage = (template: string, vars: SmsTemplateVariables): string => {
  const cleanShop = (vars.shop_name || 'সুপার শপ')
    .replace('স্টকমাস্টার বিডি - ', '')
    .replace('StockMaster BD - ', '');
  return (template || '')
    .replace(/\{name\}/g, vars.name || 'গ্রাহক')
    .replace(/\{order_no\}/g, vars.order_no || '')
    .replace(/\{invoice_no\}/g, vars.invoice_no || '')
    .replace(/\{total\}/g, String(vars.total ?? ''))
    .replace(/\{status\}/g, vars.status || '')
    .replace(/\{otp\}/g, vars.otp || '')
    .replace(/\{shop_name\}/g, cleanShop)
    .replace(/\{phone\}/g, vars.phone || '')
    .replace(/\{address\}/g, vars.address || '')
    .replace(/\{items\}/g, vars.items || '');
};

const convertBanglaDigits = (str: string): string => {
  const bnMap: Record<string, string> = {
    '০': '0',
    '১': '1',
    '২': '2',
    '৩': '3',
    '৪': '4',
    '৫': '5',
    '৬': '6',
    '৭': '7',
    '৮': '8',
    '৯': '9'
  };
  return (str || '').replace(/[০-৯]/g, d => bnMap[d] || d);
};

export const normalizeRecipientForSmsNetBd = (rawTo: string): string => {
  return convertBanglaDigits(rawTo || '')
    .split(',')
    .map(part => {
      const digits = part.replace(/\D/g, '');
      if (!digits) return '';
      if (digits.startsWith('008801') && digits.length >= 15) return digits.slice(2, 15);
      if (digits.startsWith('8801') && digits.length === 13) return digits;
      if (digits.startsWith('01') && digits.length === 11) return `88${digits}`;
      if (digits.startsWith('1') && digits.length === 10) return `880${digits}`;
      return digits;
    })
    .filter(Boolean)
    .join(',');
};

export const normalizeRecipientForGreenWeb = (rawTo: string): string => {
  return convertBanglaDigits(rawTo || '')
    .split(',')
    .map(part => {
      const digits = part.replace(/\D/g, '');
      if (!digits) return '';
      if (digits.startsWith('008801') && digits.length >= 15) return `+88${digits.slice(4, 15)}`;
      if (digits.startsWith('8801') && digits.length === 13) return `+${digits}`;
      if (digits.startsWith('01') && digits.length === 11) return `+88${digits}`;
      if (digits.startsWith('1') && digits.length === 10) return `+880${digits}`;
      return digits;
    })
    .filter(Boolean)
    .join(',');
};

const SMS_LOGS_STORAGE_KEY = 'stockmaster_sms_logs_v1';

export const getSmsLogs = (): SmsLogEntry[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(SMS_LOGS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const saveSmsLog = (entry: SmsLogEntry): void => {
  if (typeof window === 'undefined') return;
  try {
    const prev = getSmsLogs();
    const next = [entry, ...prev].slice(0, 50);
    window.localStorage.setItem(SMS_LOGS_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage errors
  }
};

export const clearSmsLogs = (): void => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(SMS_LOGS_STORAGE_KEY);
  } catch {
    // Ignore
  }
};

export interface SendAlphaSmsOptions {
  provider?: SmsProviderType;
  apiKey?: string;
  greenwebToken?: string;
  to: string;
  msg: string;
  senderId?: string;
  schedule?: string;
  contentId?: string;
  useServerStoredConfig?: boolean;
}

export interface AlphaSmsSendResponse {
  error: number;
  msg: string;
  provider?: SmsProviderType;
  data?: {
    request_id?: number | string;
    [key: string]: unknown;
  };
}

/**
 * Checks if the business has SMS enabled and has a valid API Key / Token (or server-stored config) for the active provider.
 */
export const hasBusinessSmsConfigured = (
  business?: Partial<Business> | null
): boolean => {
  if (!business || business.smsEnabled === false) return false;
  if (business.smsConfigured === true) return true;
  const provider: SmsProviderType = business.smsProvider === 'greenweb' ? 'greenweb' : 'alpha';
  if (provider === 'greenweb') {
    return Boolean((business.greenwebToken || '').trim());
  }
  return Boolean((business.smsApiKey || '').trim());
};

/**
 * Normalizes GreenWeb (api.bdbulksms.net) JSON or plain-text response into AlphaSmsSendResponse format
 */
const parseGreenWebSendResponse = (raw: unknown): AlphaSmsSendResponse => {
  if (Array.isArray(raw) && raw.length > 0) {
    const first = raw[0] as Record<string, unknown>;
    const statusStr = String(first?.status || '').toUpperCase();
    const responseMsg = String(first?.response || first?.status || 'GreenWeb response');
    const isOk =
      statusStr === 'SENT' ||
      statusStr === 'SUCCESS' ||
      responseMsg.toLowerCase().includes('successfully');
    return {
      error: isOk ? 0 : 1,
      msg: responseMsg,
      provider: 'greenweb',
      data: {
        request_id: isOk ? `GW-${Date.now().toString().slice(-6)}` : 0,
        raw
      }
    };
  }
  if (raw && typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    if (typeof obj.error === 'number') {
      return {
        error: obj.error,
        msg: String(obj.msg || (obj.error === 0 ? 'SMS Sent (GreenWeb)' : 'GreenWeb SMS Failed')),
        provider: 'greenweb',
        data: (obj.data as any) || { request_id: `GW-${Date.now().toString().slice(-6)}` }
      };
    }
    const statusStr = String(obj.status || '').toUpperCase();
    const responseMsg = String(obj.response || obj.message || obj.msg || '');
    const isOk =
      statusStr === 'SENT' ||
      statusStr === 'SUCCESS' ||
      responseMsg.toLowerCase().includes('successfully') ||
      responseMsg.toLowerCase().includes('ok:');
    return {
      error: isOk ? 0 : 1,
      msg: responseMsg || (isOk ? 'GreenWeb SMS সফলভাবে পাঠানো হয়েছে' : 'GreenWeb SMS পাঠানো সম্ভব হয়নি'),
      provider: 'greenweb',
      data: {
        request_id: isOk ? `GW-${Date.now().toString().slice(-6)}` : 0
      }
    };
  }
  if (typeof raw === 'string') {
    const text = raw.trim();
    const isOk =
      text.toLowerCase().includes('ok:') ||
      text.toLowerCase().includes('successfully') ||
      text.toLowerCase().includes('"status":"sent"');
    return {
      error: isOk ? 0 : 1,
      msg: text || (isOk ? 'GreenWeb SMS Sent' : 'GreenWeb SMS Failed'),
      provider: 'greenweb',
      data: {
        request_id: isOk ? `GW-${Date.now().toString().slice(-6)}` : 0
      }
    };
  }
  return {
    error: 1,
    msg: 'GreenWeb গেটওয়ে থেকে রেসপন্স পাওয়া যায়নি',
    provider: 'greenweb'
  };
};

/**
 * Unified SMS Sender supporting both Alpha SMS (api.sms.net.bd) and GreenWeb SMS (api.bdbulksms.net).
 */
export const sendAlphaSms = async (options: SendAlphaSmsOptions): Promise<AlphaSmsSendResponse> => {
  const provider: SmsProviderType = options.provider === 'greenweb' ? 'greenweb' : 'alpha';
  const cleanKey = (options.apiKey || '').trim();
  const cleanGwToken = (options.greenwebToken || '').trim();
  const cleanMsg = (options.msg || '').trim();
  const formattedTo =
    provider === 'greenweb'
      ? normalizeRecipientForGreenWeb(options.to)
      : normalizeRecipientForSmsNetBd(options.to);

  if (!formattedTo || !cleanMsg) {
    return { error: 400, msg: 'প্রাপকের মোবাইল নম্বর ও মেসেজ আবশ্যক', provider };
  }

  if (!options.useServerStoredConfig) {
    if (provider === 'greenweb' && !cleanGwToken) {
      return { error: 400, msg: 'GreenWeb SMS Token প্রদান করা হয়নি', provider: 'greenweb' };
    }
    if (provider === 'alpha' && !cleanKey) {
      return { error: 400, msg: 'Alpha SMS API Key প্রদান করা হয়নি', provider: 'alpha' };
    }
  }

  let result: AlphaSmsSendResponse = {
    error: 1,
    msg: 'SMS পাঠানো সম্ভব হয়নি',
    provider
  };

  const payload = {
    provider,
    api_key: cleanKey || undefined,
    token: cleanGwToken || undefined,
    msg: cleanMsg,
    to: formattedTo,
    sender_id: options.senderId?.trim() || undefined,
    schedule: options.schedule?.trim() || undefined,
    content_id: options.contentId?.trim() || undefined
  };

  // 1. Try server-side proxy (/api/sms/send or /api/index.php?route=sms/send)
  let proxySucceeded = false;
  for (const endpoint of ['/api/sms/send', '/api/index.php?route=sms/send']) {
    try {
      const proxyRes = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (proxyRes.ok) {
        const rawJson = await proxyRes.json();
        result =
          provider === 'greenweb' && rawJson?.error === undefined
            ? parseGreenWebSendResponse(rawJson)
            : { ...rawJson, provider };
        proxySucceeded = true;
        break;
      }
    } catch {
      // Try next proxy endpoint
    }
  }

  // 2. Direct browser fallback if server proxy was unreachable
  if (!proxySucceeded) {
    if (provider === 'greenweb' && cleanGwToken) {
      try {
        const params = new URLSearchParams({
          token: cleanGwToken,
          to: formattedTo,
          message: cleanMsg,
          json: '1'
        });
        const directRes = await fetch(`https://api.bdbulksms.net/api.php?${params.toString()}`);
        const rawData = await directRes.json().catch(async () => await directRes.text());
        result = parseGreenWebSendResponse(rawData);
      } catch (err: any) {
        result = {
          error: 500,
          msg: err?.message || 'GreenWeb গেটওয়েতে (api.bdbulksms.net) সংযোগ করা যায়নি',
          provider: 'greenweb'
        };
      }
    } else if (provider === 'alpha' && cleanKey) {
      try {
        const params = new URLSearchParams({
          api_key: cleanKey,
          msg: cleanMsg,
          to: formattedTo
        });
        if (options.senderId?.trim()) params.set('sender_id', options.senderId.trim());
        if (options.schedule?.trim()) params.set('schedule', options.schedule.trim());
        if (options.contentId?.trim()) params.set('content_id', options.contentId.trim());

        const directRes = await fetch(`https://api.sms.net.bd/sendsms?${params.toString()}`);
        const rawJson = await directRes.json();
        result = { ...rawJson, provider: 'alpha' };
      } catch (err: any) {
        result = {
          error: 500,
          msg: err?.message || 'নেটওয়ার্ক ত্রুটির কারণে Alpha SMS গেটওয়েতে সংযোগ করা যায়নি',
          provider: 'alpha'
        };
      }
    }
  }

  saveSmsLog({
    id: `sms_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    provider,
    requestId:
      result?.data?.request_id ??
      (provider === 'greenweb' && result?.error === 0 ? 'GW-SENT' : 0),
    to: formattedTo,
    msg: cleanMsg,
    status: result?.error === 0 ? 'Submitted' : 'Failed',
    error: result?.error ?? 1,
    responseMsg: result?.msg || '',
    createdAt: new Date().toISOString()
  });

  return result;
};

/**
 * High-level helper that sends SMS using the business's currently active gateway (Alpha or GreenWeb).
 */
export const sendBusinessSms = async (
  business: Partial<Business>,
  to: string,
  msg: string,
  schedule?: string
): Promise<AlphaSmsSendResponse> => {
  const provider: SmsProviderType = business.smsProvider === 'greenweb' ? 'greenweb' : 'alpha';
  return sendAlphaSms({
    provider,
    apiKey: business.smsApiKey,
    greenwebToken: business.greenwebToken,
    to,
    msg,
    senderId: business.smsSenderId,
    contentId: business.smsContentId,
    schedule,
    useServerStoredConfig: true
  });
};

export interface AlphaSmsBalanceResponse {
  error: number;
  msg: string;
  provider?: SmsProviderType;
  data?: {
    balance?: string;
    expiry?: string;
    rate?: string;
  };
}

export const checkAlphaSmsBalance = async (
  apiKeyOrToken: string,
  provider: SmsProviderType = 'alpha'
): Promise<AlphaSmsBalanceResponse> => {
  const cleanCredential = (apiKeyOrToken || '').trim();
  if (!cleanCredential) {
    return {
      error: 400,
      msg: provider === 'greenweb' ? 'GreenWeb Token প্রয়োজন' : 'Alpha SMS API Key প্রয়োজন',
      provider
    };
  }

  const query =
    provider === 'greenweb'
      ? `provider=greenweb&token=${encodeURIComponent(cleanCredential)}`
      : `provider=alpha&api_key=${encodeURIComponent(cleanCredential)}`;

  for (const endpoint of [`/api/sms/balance?${query}`, `/api/index.php?route=sms/balance&${query}`]) {
    try {
      const proxyRes = await fetch(endpoint);
      if (proxyRes.ok) {
        const data = await proxyRes.json();
        if (data && typeof data.error === 'number') {
          return { ...data, provider };
        }
      }
    } catch {
      // Fallback
    }
  }

  if (provider === 'greenweb') {
    try {
      const directRes = await fetch(
        `https://api.bdbulksms.net/g_api.php?token=${encodeURIComponent(cleanCredential)}&balance&expiry&json`
      );
      const raw = await directRes.json().catch(async () => await directRes.text());
      if (Array.isArray(raw)) {
        const balNode = raw.find((item: any) => item && item.balance !== undefined);
        const expNode = raw.find((item: any) => item && item.expiry !== undefined);
        if (balNode) {
          return {
            error: 0,
            msg: 'OK',
            provider: 'greenweb',
            data: {
              balance: String(balNode.balance ?? '0'),
              expiry: expNode?.expiry ? String(expNode.expiry) : undefined
            }
          };
        }
      } else if (raw && typeof raw === 'object' && (raw as any).balance !== undefined) {
        return {
          error: 0,
          msg: 'OK',
          provider: 'greenweb',
          data: {
            balance: String((raw as any).balance)
          }
        };
      } else if (typeof raw === 'string' && raw.trim() && !raw.toLowerCase().includes('error')) {
        return {
          error: 0,
          msg: 'OK',
          provider: 'greenweb',
          data: {
            balance: raw.trim()
          }
        };
      }
      return {
        error: 1,
        msg: 'GreenWeb ব্যালেন্স পাওয়া যায়নি (সঠিক Token চেক করুন)',
        provider: 'greenweb'
      };
    } catch (err: any) {
      return {
        error: 500,
        msg: err?.message || 'GreenWeb ব্যালেন্স চেক করতে সমস্যা হয়েছে',
        provider: 'greenweb'
      };
    }
  }

  try {
    const directRes = await fetch(
      `https://api.sms.net.bd/user/balance/?api_key=${encodeURIComponent(cleanCredential)}`
    );
    const json = await directRes.json();
    return { ...json, provider: 'alpha' };
  } catch (err: any) {
    return {
      error: 500,
      msg: err?.message || 'ব্যালেন্স চেক করতে সমস্যা হয়েছে',
      provider: 'alpha'
    };
  }
};

export interface AlphaSmsReportResponse {
  error: number;
  msg: string;
  data?: {
    request_id?: number | string;
    request_status?: string;
    request_charge?: string;
    recipients?: Array<{
      number: string;
      charge: string;
      status: string;
    }>;
  };
}

export const checkAlphaSmsReport = async (
  apiKey: string,
  requestId: string | number
): Promise<AlphaSmsReportResponse> => {
  const cleanKey = (apiKey || '').trim();
  const cleanId = String(requestId || '').trim();
  if (!cleanKey || !cleanId) {
    return { error: 400, msg: 'API Key এবং Request ID প্রয়োজন' };
  }

  try {
    const proxyRes = await fetch(
      `/api/sms/report/${encodeURIComponent(cleanId)}?api_key=${encodeURIComponent(cleanKey)}`
    );
    if (proxyRes.ok) {
      return await proxyRes.json();
    }
  } catch {
    // Fallback
  }

  try {
    const directRes = await fetch(
      `https://api.sms.net.bd/report/request/${encodeURIComponent(cleanId)}/?api_key=${encodeURIComponent(cleanKey)}`
    );
    return await directRes.json();
  } catch (err: any) {
    return { error: 500, msg: err?.message || 'রিপোর্ট লোড করতে সমস্যা হয়েছে' };
  }
};
