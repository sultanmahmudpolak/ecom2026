import { Business, Product, ProductVariant, SaleItem } from '../types';

export type FbStandardEventName =
  | 'PageView'
  | 'ViewContent'
  | 'Search'
  | 'AddToCart'
  | 'InitiateCheckout'
  | 'AddPaymentInfo'
  | 'Lead'
  | 'CompleteRegistration'
  | 'Purchase';

export interface FbCustomerIdentity {
  name?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  externalId?: string;
  fbp?: string;
  fbc?: string;
  clientIp?: string;
  clientUserAgent?: string;
}

export interface FbContentItem {
  id: string;
  sku?: string;
  item_group_id?: string;
  variant?: string;
  quantity: number;
  item_price?: number;
  title?: string;
  category?: string;
}

export interface FbCustomData {
  currency?: string;
  value?: number;
  content_name?: string;
  content_category?: string;
  content_ids?: string[];
  contents?: FbContentItem[];
  content_type?: 'product' | 'product_group';
  item_group_id?: string;
  content_sku?: string;
  variant_label?: string;
  order_source?: string;
  num_items?: number;
  order_id?: string;
  search_string?: string;
  status?: string;
}

/**
 * Build unified Meta Catalog + Pixel + CAPI custom_data for any Product & Variation (Storefront or Landing Page).
 * Automatically includes Variation SKU, Parent SKU, WordPress IDs, and internal ID so Meta Catalog Ads match 100%.
 */
export function buildMetaProductCustomData(params: {
  product: Product;
  activeVariant?: ProductVariant;
  quantity?: number;
  unitPrice?: number;
  totalValue?: number;
  categoryName?: string;
  orderId?: string;
  orderSource?: string;
}): FbCustomData {
  const {
    product,
    activeVariant,
    quantity = 1,
    unitPrice,
    totalValue,
    categoryName = 'Landing Page Product',
    orderId,
    orderSource
  } = params;

  const resolvedUnitPrice =
    typeof unitPrice === 'number'
      ? unitPrice
      : activeVariant
      ? activeVariant.retailPrice
      : product.retailPrice;

  const resolvedTotal =
    typeof totalValue === 'number' ? totalValue : resolvedUnitPrice * quantity;

  const cleanParentSku = (product.sku || '').trim();
  const cleanVariantLabel = (activeVariant?.label || '').trim();
  const resolvedVariantSku = activeVariant
    ? (activeVariant.sku || '').trim() ||
      (cleanParentSku && cleanVariantLabel
        ? `${cleanParentSku}-${cleanVariantLabel
            .toUpperCase()
            .replace(/[^A-Z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')}`
        : '')
    : '';

  const primaryCatalogId =
    resolvedVariantSku ||
    cleanParentSku ||
    (activeVariant?.wpVariationId ? String(activeVariant.wpVariationId) : '') ||
    (product.wpProductId ? String(product.wpProductId) : '') ||
    product.id;

  const itemGroupId =
    cleanParentSku ||
    (product.wpProductId ? String(product.wpProductId) : '') ||
    product.id;

  // Deduplicated array of all relevant IDs (Variation SKU, Parent SKU, WP IDs, Internal ID)
  const contentIds = Array.from(
    new Set(
      [
        primaryCatalogId,
        resolvedVariantSku,
        cleanParentSku,
        activeVariant?.wpVariationId ? String(activeVariant.wpVariationId) : '',
        product.wpProductId ? String(product.wpProductId) : '',
        product.id
      ].filter(Boolean)
    )
  );

  const fullTitle = activeVariant
    ? `${product.nameBn} (${activeVariant.label})`
    : product.nameBn;

  return {
    content_type: 'product',
    content_ids: contentIds,
    content_name: fullTitle,
    content_category: categoryName,
    content_sku: resolvedVariantSku || cleanParentSku || product.id,
    item_group_id: itemGroupId,
    ...(cleanVariantLabel ? { variant_label: cleanVariantLabel } : {}),
    ...(orderSource ? { order_source: orderSource } : {}),
    ...(orderId ? { order_id: orderId } : {}),
    value: resolvedTotal,
    num_items: quantity,
    contents: [
      {
        id: primaryCatalogId,
        sku: resolvedVariantSku || cleanParentSku || product.id,
        item_group_id: itemGroupId,
        ...(cleanVariantLabel ? { variant: cleanVariantLabel } : {}),
        quantity,
        item_price: resolvedUnitPrice,
        title: fullTitle,
        category: categoryName
      }
    ]
  };
}

/**
 * Build Meta custom_data from an array of SaleItems (for multi-item Orders or Incomplete Order conversion)
 */
export function buildMetaOrderItemsCustomData(params: {
  items: SaleItem[];
  orderId?: string;
  totalValue: number;
  orderSource?: string;
}): FbCustomData {
  const { items, orderId, totalValue, orderSource } = params;
  const contentIdsSet = new Set<string>();
  const contents: FbContentItem[] = [];
  let totalQty = 0;

  for (const item of items) {
    const primaryId =
      (item.variantSku || '').trim() ||
      (item.sku || '').trim() ||
      (item.parentSku || '').trim() ||
      (item.wpVariationId ? String(item.wpVariationId) : '') ||
      (item.wpProductId ? String(item.wpProductId) : '') ||
      item.productId;

    const groupId =
      (item.parentSku || '').trim() ||
      (item.wpProductId ? String(item.wpProductId) : '') ||
      item.productId;

    [
      primaryId,
      item.variantSku || '',
      item.sku || '',
      item.parentSku || '',
      item.wpVariationId ? String(item.wpVariationId) : '',
      item.wpProductId ? String(item.wpProductId) : '',
      item.productId
    ]
      .filter(Boolean)
      .forEach(id => contentIdsSet.add(id));

    totalQty += item.quantity || 1;
    contents.push({
      id: primaryId,
      sku: item.variantSku || item.sku || item.parentSku || item.productId,
      item_group_id: groupId,
      ...(item.variantLabel ? { variant: item.variantLabel } : {}),
      quantity: item.quantity || 1,
      item_price: item.unitPrice,
      title: item.productName
    });
  }

  return {
    ...(orderId ? { order_id: orderId } : {}),
    value: totalValue,
    content_type: 'product',
    content_ids: Array.from(contentIdsSet),
    content_name: items.map(i => i.productName).join(', '),
    num_items: totalQty || 1,
    ...(orderSource ? { order_source: orderSource } : {}),
    contents
  };
}

export interface FbEventLogEntry {
  id: string;
  eventId: string;
  eventName: FbStandardEventName | string;
  timestamp: string;
  eventSourceUrl: string;
  browserSent: boolean;
  serverSent: boolean;
  serverStatus: 'sent' | 'queued_retry' | 'skipped' | 'failed';
  serverResponseMsg?: string;
  fbTraceId?: string;
  emqScore: number; // 0 to 10.0
  matchedKeys: string[]; // e.g. ['ph', 'fn', 'ln', 'em', 'ct', 'country', 'external_id', 'fbp', 'fbc', 'ip', 'ua']
  value?: number;
  currency?: string;
  orderId?: string;
  customData?: FbCustomData;
}

const FB_USER_DATA_STORAGE_KEY = 'stockmaster_fb_user_data_v1';
const FB_NORMALIZED_USER_STORAGE_KEY = 'fb_advanced_matching_user';
const FB_EVENT_LOGS_STORAGE_KEY = 'stockmaster_fb_event_logs_v1';
const FB_RETRY_QUEUE_STORAGE_KEY = 'stockmaster_fb_retry_queue_v1';
const FB_EXTERNAL_ID_STORAGE_KEY = 'stockmaster_fb_external_id_v1';
const FB_VISITOR_ID_STORAGE_KEY = 'stockmaster_fb_visitor_id_v1';
const FB_FBP_STORAGE_KEY = 'stockmaster_fb_fbp_v1';
const FB_FBC_STORAGE_KEY = 'stockmaster_fb_fbc_v1';
const FB_FIRED_PURCHASES_STORAGE_KEY = 'stockmaster_fb_fired_purchases_v1';
const FB_FBP_DIRECT_KEY = '_fbp';
const FB_FBC_DIRECT_KEY = '_fbc';
const FB_EXTERNAL_ID_COOKIE = '_sm_external_id';
const FB_IDENTITY_CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days privacy TTL

// In-memory Purchase deduplication guard + Advanced Matching signature cache
const firedPurchaseKeysMemory = new Set<string>();
let lastAdvancedMatchingSignature = '';
let fbqInitDebounceTimer: ReturnType<typeof setTimeout> | null = null;

// Bangladeshi Honorific Prefixes stripped when followed by actual given name(s)
// Kept 100% identical across JavaScript (facebookTracking.ts), PHP (ApiController.php), and Node.js (server.ts)
const BD_HONORIFIC_PREFIXES = new Set<string>([
  'md',
  'mohammad',
  'muhammad',
  'mohammed',
  'mst',
  'most',
  'mr',
  'mrs',
  'ms',
  'dr',
  'alhaj',
  'haji',
  'engr',
  'adv',
  'মোঃ',
  'মো',
  'মোহাম্মদ',
  'মুহাম্মদ',
  'মোসাঃ',
  'মোছাঃ',
  'জনাব',
  'ডঃ',
  'ডাঃ',
  'হাজী',
  'আলহাজ্ব'
]);

export interface NormalizedFbUserData {
  ph: string;            // 8801XXXXXXXXX (13 digits, no +, no spaces/dashes) or '' if unverified
  fn: string;            // lowercase trimmed first name (honorifics stripped)
  ln: string;            // lowercase trimmed last name
  ct: string;            // lowercase verified city/district (e.g. 'dhaka') or '' when unknown
  st: string;            // lowercase verified division/state (e.g. 'dhaka') or '' when unknown
  zp: string;            // verified 4-digit Bangladesh postal code (e.g. '1216') or '' when unknown
  country: 'bd';         // Always 'bd'
  external_id: string;   // Primary external_id (persistent UUID or normalized phone)
  external_ids: string[]; // Complete deduplicated array preserving BOTH persistent UUID and normalized phone
  em?: string;           // Optional lowercase trimmed email
}

declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
    _fbq?: any;
    __smInitializedPixelId?: string;
    dataLayer?: Record<string, any>[];
    __smInitializedGtmId?: string;
  }
}

/**
 * Generate RFC4122 v4 UUID for persistent external_id and deduplicated event_id
 */
export function generateUuidV4(): string {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
  } catch {
    // Fallback below
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function isValidPersistentUuidFormat(val?: string): boolean {
  if (!val) return false;
  const clean = val.trim();
  // Must be RFC4122 UUID v4 or legacy ext_<timestamp> UUID; never a phone number or 'lead_...'
  if (/^(lead_|01\d|8801\d|\+880)/i.test(clean)) return false;
  return (
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(clean) ||
    /^ext_[a-z0-9_-]{12,}$/i.test(clean)
  );
}

/**
 * Generate a unique event_id for Event Deduplication between Browser Pixel ({ eventID: event_id })
 * and Server-Side CAPI (event_id).
 * - For Purchase events with an orderId, uses deterministic `order_${orderId}`
 * - For ViewContent, AddToCart, InitiateCheckout, Lead, etc., generates a unique UUID-backed event_id
 */
export function generateMetaEventId(
  eventName: FbStandardEventName | string = 'Event',
  orderId?: string
): string {
  const cleanOrderId = (orderId || '').trim();
  if (cleanOrderId && eventName === 'Purchase') {
    return cleanOrderId.startsWith('order_') ? cleanOrderId : `order_${cleanOrderId}`;
  }
  if (cleanOrderId) {
    return `${String(eventName).toLowerCase()}_${cleanOrderId}_${generateUuidV4().slice(0, 8)}`;
  }
  return `${String(eventName).toLowerCase()}_${generateUuidV4()}`;
}

/**
 * Check if a Purchase event has already been fired for a given eventId or orderId
 * Prevents duplicate Purchase firing on page refreshes, retries, or status updates.
 */
export function hasPurchaseEventAlreadyFired(eventId?: string, orderId?: string): boolean {
  const keysToCheck: string[] = [];
  if (eventId && eventId.trim()) keysToCheck.push(eventId.trim());
  if (orderId && orderId.trim()) {
    const cleanOrd = orderId.trim();
    keysToCheck.push(cleanOrd.startsWith('order_') ? cleanOrd : `order_${cleanOrd}`);
  }
  if (keysToCheck.length === 0) return false;

  for (const k of keysToCheck) {
    if (firedPurchaseKeysMemory.has(k)) return true;
  }

  if (typeof window !== 'undefined') {
    try {
      const raw = window.localStorage.getItem(FB_FIRED_PURCHASES_STORAGE_KEY);
      if (raw) {
        const list = JSON.parse(raw);
        if (Array.isArray(list)) {
          for (const k of keysToCheck) {
            if (list.includes(k)) {
              firedPurchaseKeysMemory.add(k);
              return true;
            }
          }
        }
      }
    } catch {
      // Ignore storage read error
    }
  }
  return false;
}

export function markPurchaseEventFired(eventId?: string, orderId?: string): void {
  const keysToRecord: string[] = [];
  if (eventId && eventId.trim()) keysToRecord.push(eventId.trim());
  if (orderId && orderId.trim()) {
    const cleanOrd = orderId.trim();
    keysToRecord.push(cleanOrd.startsWith('order_') ? cleanOrd : `order_${cleanOrd}`);
  }
  if (keysToRecord.length === 0) return;

  keysToRecord.forEach(k => firedPurchaseKeysMemory.add(k));

  if (typeof window !== 'undefined') {
    try {
      const raw = window.localStorage.getItem(FB_FIRED_PURCHASES_STORAGE_KEY);
      const existing: string[] = raw ? JSON.parse(raw) : [];
      const merged = Array.from(
        new Set([...(Array.isArray(existing) ? existing : []), ...keysToRecord])
      ).slice(-200);
      window.localStorage.setItem(FB_FIRED_PURCHASES_STORAGE_KEY, JSON.stringify(merged));
    } catch {
      // Ignore storage error
    }
  }
}

/**
 * Pure-JS SHA-256 fallback + Web Crypto SHA-256 (Always returns 64-char lowercase hex)
 * Meta Conversions API requires lowercase hex SHA-256 hashes over UTF-8 bytes.
 */
function sha256PureJs(ascii: string): string {
  function rightRotate(value: number, amount: number) {
    return (value >>> amount) | (value << (32 - amount));
  }

  const mathPow = Math.pow;
  const maxWord = mathPow(2, 32);
  const lengthProperty = 'length';
  let i: number, j: number;
  let result = '';

  const words: number[] = [];
  const asciiBitLength = ascii[lengthProperty] * 8;

  let hash: number[] = [];
  const k: number[] = [];
  let primeCounter = 0;

  const isComposite: Record<number, number> = {};
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isComposite[candidate]) {
      for (i = 0; i < 313; i += candidate) {
        isComposite[i] = candidate;
      }
      hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
      k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
    }
  }

  ascii += '\x80';
  while ((ascii[lengthProperty] % 64) - 56) ascii += '\x00';
  for (i = 0; i < ascii[lengthProperty]; i++) {
    j = ascii.charCodeAt(i);
    if (j >> 8) return '';
    words[i >> 2] |= j << (((3 - i) % 4) * 8);
  }
  words[words[lengthProperty]] = (asciiBitLength / maxWord) | 0;
  words[words[lengthProperty]] = asciiBitLength;

  for (j = 0; j < words[lengthProperty]; ) {
    const w = words.slice(j, (j += 16));
    const oldHash = hash;
    hash = hash.slice(0, 8);

    for (i = 0; i < 64; i++) {
      const w15 = w[i - 15],
        w2 = w[i - 2];

      const a = hash[0],
        e = hash[4];
      const temp1 =
        hash[7] +
        (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) +
        ((e & hash[5]) ^ (~e & hash[6])) +
        k[i] +
        (w[i] =
          i < 16
            ? w[i]
            : (w[i - 16] +
                (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) +
                w[i - 7] +
                (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) |
              0);

      const temp2 =
        (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) +
        ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));

      hash = [(temp1 + temp2) | 0].concat(hash);
      hash[4] = (hash[4] + temp1) | 0;
    }

    for (i = 0; i < 8; i++) {
      hash[i] = (hash[i] + oldHash[i]) | 0;
    }
  }

  for (i = 0; i < 8; i++) {
    for (j = 3; j + 1; j--) {
      const b = (hash[i] >> (j * 8)) & 255;
      result += (b < 16 ? 0 : '') + b.toString(16);
    }
  }
  return result;
}

export function sha256SyncUtf8(raw: string): string {
  const clean = String(raw || '').normalize('NFC').trim().toLowerCase();
  if (!clean) return '';
  if (/^[a-f0-9]{64}$/.test(clean)) return clean;
  try {
    if (typeof TextEncoder !== 'undefined') {
      const bytes = new TextEncoder().encode(clean);
      let binary = '';
      for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      return sha256PureJs(binary);
    }
    const utf8 = unescape(encodeURIComponent(clean));
    return sha256PureJs(utf8);
  } catch {
    return '';
  }
}

export async function sha256MetaHash(raw: string): Promise<string> {
  const clean = String(raw || '').normalize('NFC').trim().toLowerCase();
  if (!clean) return '';
  if (/^[a-f0-9]{64}$/.test(clean)) return clean;
  try {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      const msgBuffer = new TextEncoder().encode(clean);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }
  } catch {
    // Fallback to pure JS SHA-256 over UTF-8 bytes
  }
  return sha256SyncUtf8(clean);
}

function banglaDigitsToAscii(input: string): string {
  const banglaDigits = '০১২৩৪৫৬৭৮৯';
  return String(input || '')
    .split('')
    .map(ch => {
      const idx = banglaDigits.indexOf(ch);
      return idx >= 0 ? String(idx) : ch;
    })
    .join('');
}

/**
 * Strictly normalize and validate Bangladeshi Mobile Numbers to 13-digit E.164 without '+' (8801[3-9]XXXXXXXX).
 * Rejects incomplete or partial numbers (returns '') so partial phone inputs are never cached or sent to Meta.
 */
export function normalizePhoneForMeta(raw?: string): string {
  if (!raw) return '';
  const ascii = banglaDigitsToAscii(String(raw));
  const stripped = ascii.replace(/\D/g, '').replace(/^00+/, '');
  if (!stripped) return '';

  let candidate = '';
  if (stripped.startsWith('8801') && stripped.length === 13) {
    candidate = stripped;
  } else if (stripped.startsWith('01') && stripped.length === 11) {
    candidate = `88${stripped}`;
  } else if (stripped.startsWith('1') && stripped.length === 10) {
    candidate = `880${stripped}`;
  }

  if (/^8801[3-9]\d{8}$/.test(candidate)) {
    return candidate;
  }
  return '';
}

/**
 * Split full name into lowercase trimmed first name (fn) and last name (ln).
 * Strips Bangladeshi honorific prefixes (Md., Mohammad, Mst., মোঃ, মোসাঃ, etc.) when followed by actual name tokens.
 * Kept 100% identical across JavaScript, PHP, and Node.js.
 */
export function splitNameForMeta(fullName?: string): { fn: string; ln: string } {
  if (!fullName) return { fn: '', ln: '' };
  const cleaned = String(fullName)
    .normalize('NFC')
    .trim()
    .toLowerCase()
    .replace(/[0-9.,/#!$%^&*;:{}=\-_`~()'"\\|<>?+[\]]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return { fn: '', ln: '' };

  const parts = cleaned.split(' ').filter(Boolean);
  while (parts.length > 1 && BD_HONORIFIC_PREFIXES.has(parts[0])) {
    parts.shift();
  }

  if (parts.length === 0) return { fn: '', ln: '' };
  if (parts.length === 1) {
    return { fn: parts[0], ln: '' };
  }
  return {
    fn: parts[0].trim(),
    ln: parts.slice(1).join(' ').trim()
  };
}

export function normalizeCityStateTokenForMeta(val?: string): string {
  if (!val) return '';
  return String(val)
    .normalize('NFC')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u0980-\u09ff]/g, '');
}

/**
 * Extract normalized lowercase English city/district (ct), state (st) & zip (zp) from Bangladesh address/zone.
 * - ZERO artificial defaults: returns '' for ct, st, and zp unless verified from actual customer input.
 * - Never uses a full street address as the city value.
 */
export function extractLocationForMeta(
  address?: string,
  cityHint?: string,
  stateHint?: string,
  zipHint?: string
): {
  ct: string;
  st: string;
  zp: string;
  country: 'bd';
} {
  const rawAddress = banglaDigitsToAscii(String(address || ''))
    .normalize('NFC')
    .trim()
    .toLowerCase();
  const rawCityHint = banglaDigitsToAscii(String(cityHint || ''))
    .normalize('NFC')
    .trim()
    .toLowerCase();
  const rawStateHint = banglaDigitsToAscii(String(stateHint || ''))
    .normalize('NFC')
    .trim()
    .toLowerCase();
  const rawZipHint = banglaDigitsToAscii(String(zipHint || ''))
    .normalize('NFC')
    .trim();

  // Only combine address + cityHint if cityHint is not a generic zone flag
  const searchableCityHint =
    rawCityHint === 'outside_dhaka' || rawCityHint.includes('ঢাকার বাইরে')
      ? ''
      : rawCityHint;
  const combined = `${rawAddress} ${searchableCityHint}`.trim();

  let ct = '';
  let st = '';

  const districtMap: Array<{ keywords: string[]; ct: string; st: string }> = [
    { keywords: ['chattogram', 'chittagong', 'চট্টগ্রাম', 'চিটাগাং', 'agrabad', 'আগ্রাবাদ', 'halishahar', 'হালিশহর', 'panchlaish', 'পাঁচলাইশ', 'nasirabad', 'নাসিরাবাদ'], ct: 'chattogram', st: 'chattogram' },
    { keywords: ['sylhet', 'সিলেট', 'zindabazar', 'জিন্দাবাজার', 'amberkhana', 'আম্বরখানা'], ct: 'sylhet', st: 'sylhet' },
    { keywords: ['rajshahi', 'রাজশাহী'], ct: 'rajshahi', st: 'rajshahi' },
    { keywords: ['khulna', 'খুলনা', 'sonadanga', 'সোনাডাঙ্গা', 'khalishpur', 'খালিশপুর'], ct: 'khulna', st: 'khulna' },
    { keywords: ['barishal', 'barisal', 'বরিশাল'], ct: 'barishal', st: 'barishal' },
    { keywords: ['rangpur', 'রংপুর'], ct: 'rangpur', st: 'rangpur' },
    { keywords: ['mymensingh', 'ময়মনসিংহ', 'ময়মনসিংহ'], ct: 'mymensingh', st: 'mymensingh' },
    { keywords: ['gazipur', 'গাজীপুর', 'tongi', 'টঙ্গী', 'joydebpur', 'জয়দেবপুর'], ct: 'gazipur', st: 'dhaka' },
    { keywords: ['narayanganj', 'নারায়ণগঞ্জ', 'নারায়ণগঞ্জ', 'siddhirganj', 'সিদ্ধিরগঞ্জ', 'fatullah', 'ফতুল্লা'], ct: 'narayanganj', st: 'dhaka' },
    { keywords: ['cumilla', 'comilla', 'কুমিল্লা'], ct: 'cumilla', st: 'chattogram' },
    { keywords: ['bogura', 'bogra', 'বগুড়া', 'বগুড়া'], ct: 'bogura', st: 'rajshahi' },
    { keywords: ['noakhali', 'নোয়াখালী', 'নোয়াখালী', 'maijdee', 'মাইজদী'], ct: 'noakhali', st: 'chattogram' },
    { keywords: ['feni', 'ফেনী'], ct: 'feni', st: 'chattogram' },
    { keywords: ['cox', 'কক্সবাজার', 'coxsbazar'], ct: 'coxsbazar', st: 'chattogram' },
    { keywords: ['brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 'ব্রাহ্মণবাড়িয়া'], ct: 'brahmanbaria', st: 'chattogram' },
    { keywords: ['chandpur', 'চাঁদপুর'], ct: 'chandpur', st: 'chattogram' },
    { keywords: ['lakshmipur', 'লক্ষ্মীপুর'], ct: 'lakshmipur', st: 'chattogram' },
    { keywords: ['khagrachhari', 'খাগড়াছড়ি', 'খাগড়াছড়ি'], ct: 'khagrachhari', st: 'chattogram' },
    { keywords: ['rangamati', 'রাঙ্গামাটি'], ct: 'rangamati', st: 'chattogram' },
    { keywords: ['bandarban', 'বান্দরবান'], ct: 'bandarban', st: 'chattogram' },
    { keywords: ['tangail', 'টাঙ্গাইল'], ct: 'tangail', st: 'dhaka' },
    { keywords: ['faridpur', 'ফরিদপুর'], ct: 'faridpur', st: 'dhaka' },
    { keywords: ['kishoreganj', 'কিশোরগঞ্জ', 'bhairab', 'ভৈরব'], ct: 'kishoreganj', st: 'dhaka' },
    { keywords: ['manikganj', 'মানিকগঞ্জ'], ct: 'manikganj', st: 'dhaka' },
    { keywords: ['munshiganj', 'মুন্সীগঞ্জ'], ct: 'munshiganj', st: 'dhaka' },
    { keywords: ['narsingdi', 'নরসিংদী', 'madhabdi', 'মাধবদী'], ct: 'narsingdi', st: 'dhaka' },
    { keywords: ['gopalganj', 'গোপালগঞ্জ'], ct: 'gopalganj', st: 'dhaka' },
    { keywords: ['madaripur', 'মাদারীপুর'], ct: 'madaripur', st: 'dhaka' },
    { keywords: ['rajbari', 'রাজবাড়ী', 'রাজবাড়ী'], ct: 'rajbari', st: 'dhaka' },
    { keywords: ['shariatpur', 'শরীয়তপুর', 'শরীয়তপুর'], ct: 'shariatpur', st: 'dhaka' },
    { keywords: ['jashore', 'jessore', 'যশোর'], ct: 'jashore', st: 'khulna' },
    { keywords: ['kushtia', 'কুষ্টিয়া', 'কুষ্টিয়া'], ct: 'kushtia', st: 'khulna' },
    { keywords: ['satkhira', 'সাতক্ষীরা'], ct: 'satkhira', st: 'khulna' },
    { keywords: ['jhenaidah', 'ঝিনাইদহ'], ct: 'jhenaidah', st: 'khulna' },
    { keywords: ['bagerhat', 'বাগেরহাট'], ct: 'bagerhat', st: 'khulna' },
    { keywords: ['magura', 'মাগুরা'], ct: 'magura', st: 'khulna' },
    { keywords: ['narail', 'নড়াইল', 'নড়াইল'], ct: 'narail', st: 'khulna' },
    { keywords: ['chuadanga', 'চুয়াডাঙ্গা', 'চুয়াডাঙ্গা'], ct: 'chuadanga', st: 'khulna' },
    { keywords: ['meherpur', 'মেহেরপুর'], ct: 'meherpur', st: 'khulna' },
    { keywords: ['pabna', 'পাবনা'], ct: 'pabna', st: 'rajshahi' },
    { keywords: ['sirajganj', 'সিরাজগঞ্জ'], ct: 'sirajganj', st: 'rajshahi' },
    { keywords: ['naogaon', 'নওগাঁ'], ct: 'naogaon', st: 'rajshahi' },
    { keywords: ['natore', 'নাটোর'], ct: 'natore', st: 'rajshahi' },
    { keywords: ['chapainawabganj', 'চাঁপাইনবাবগঞ্জ'], ct: 'chapainawabganj', st: 'rajshahi' },
    { keywords: ['joypurhat', 'জয়পুরহাট', 'জয়পুরহাট'], ct: 'joypurhat', st: 'rajshahi' },
    { keywords: ['dinajpur', 'দিনাজপুর'], ct: 'dinajpur', st: 'rangpur' },
    { keywords: ['nilphamari', 'নীলফামারী', 'saidpur', 'সৈয়দপুর', 'সৈয়দপুর'], ct: 'nilphamari', st: 'rangpur' },
    { keywords: ['kurigram', 'কুড়িগ্রাম', 'কুড়িগ্রাম'], ct: 'kurigram', st: 'rangpur' },
    { keywords: ['gaibandha', 'গাইবান্ধা'], ct: 'gaibandha', st: 'rangpur' },
    { keywords: ['lalmonirhat', 'লালমনিরহাট'], ct: 'lalmonirhat', st: 'rangpur' },
    { keywords: ['thakurgaon', 'ঠাকুরগাঁও'], ct: 'thakurgaon', st: 'rangpur' },
    { keywords: ['panchagarh', 'পঞ্চগড়', 'পঞ্চগড়'], ct: 'panchagarh', st: 'rangpur' },
    { keywords: ['habiganj', 'হবিগঞ্জ'], ct: 'habiganj', st: 'sylhet' },
    { keywords: ['moulvibazar', 'মৌলভীবাজার', 'sreemangal', 'শ্রীমঙ্গল'], ct: 'moulvibazar', st: 'sylhet' },
    { keywords: ['sunamganj', 'সুনামগঞ্জ'], ct: 'sunamganj', st: 'sylhet' },
    { keywords: ['jamalpur', 'জামালপুর'], ct: 'jamalpur', st: 'mymensingh' },
    { keywords: ['netrokona', 'নেত্রকোণা', 'নেত্রকোনা'], ct: 'netrokona', st: 'mymensingh' },
    { keywords: ['sherpur', 'শেরপুর'], ct: 'sherpur', st: 'mymensingh' },
    { keywords: ['patuakhali', 'পটুয়াখালী', 'পটুয়াখালী'], ct: 'patuakhali', st: 'barishal' },
    { keywords: ['bhola', 'ভোলা'], ct: 'bhola', st: 'barishal' },
    { keywords: ['pirojpur', 'পিরোজপুর'], ct: 'pirojpur', st: 'barishal' },
    { keywords: ['barguna', 'বরগুনা'], ct: 'barguna', st: 'barishal' },
    { keywords: ['jhalokati', 'ঝালকাঠি'], ct: 'jhalokati', st: 'barishal' },
    { keywords: ['savar', 'সাভার', 'ashulia', 'আশুলিয়া', 'আশুলিয়া', 'keraniganj', 'কেরানীগঞ্জ', 'dhamrai', 'ধামরাই'], ct: 'dhaka', st: 'dhaka' },
    { keywords: ['dhaka', 'ঢাকা', 'মিরপুর', 'mirpur', 'উত্তরা', 'uttara', 'ধানমন্ডি', 'dhanmondi', 'গুলশান', 'gulshan', 'বনানী', 'banani', 'মোহাম্মদপুর', 'mohammadpur', 'যাত্রাবাড়ী', 'যাত্রাবাড়ী', 'jatrabari', 'মতিঝিল', 'motijheel', 'বাড্ডা', 'badda', 'খিলগাঁও', 'khilgaon', 'রামপুরা', 'rampura', 'তেজগাঁও', 'tejgaon', 'পল্টন', 'paltan', 'শাহবাগ', 'shahbag', 'ফার্মগেট', 'farmgate', 'বসুন্ধরা', 'bashundhara', 'খিলক্ষেত', 'khilkhet', 'ক্যান্টনমেন্ট', 'cantonment', 'শ্যামলী', 'shyamoli', 'কল্যাণপুর', 'kallyanpur', 'আজিমপুর', 'azimpur', 'লালবাগ', 'lalbagh', 'ওয়ারী', 'ওয়ারী', 'wari', 'ডেমরা', 'demra', 'কদমতলী', 'শনির আখড়া', 'শনির আখড়া', 'মুগদা', 'mugda', 'বাসাবো', 'basabo', 'মালিবাগ', 'malibagh', 'মগবাজার', 'mogbazar', 'কাকরাইল', 'kakrail', 'নিউমার্কেট', 'newmarket', 'হাজারীবাগ', 'কামরাঙ্গীরচর'], ct: 'dhaka', st: 'dhaka' }
  ];

  if (combined) {
    for (const entry of districtMap) {
      if (entry.keywords.some(kw => combined.includes(kw))) {
        ct = entry.ct;
        st = entry.st;
        break;
      }
    }
  }

  // If no district keyword matched in address, check if cityHint explicitly specifies Dhaka
  if (!ct && (rawCityHint === 'inside_dhaka' || rawCityHint === 'dhaka' || rawCityHint.includes('ঢাকার ভিতরে'))) {
    ct = 'dhaka';
    st = 'dhaka';
  }

  // Allow explicit valid stateHint if st is still empty
  if (!st && rawStateHint && /^[a-z]+$/.test(rawStateHint)) {
    st = rawStateHint;
  }

  // Only extract a real 4-digit Bangladesh postal code if present in zipHint or address (never default to '1216')
  const zipSource = `${rawZipHint} ${rawAddress}`;
  const zipMatch = zipSource.match(/\b([1-9]\d{3})\b/);
  const zp = zipMatch ? zipMatch[1] : '';

  return { ct, st, zp, country: 'bd' };
}

function getCookie(name: string): string {
  if (typeof document === 'undefined') return '';
  const match = document.cookie.match(new RegExp('(^|;\\s*)' + name + '=([^;]*)'));
  return match ? decodeURIComponent(match[2]) : '';
}

function setCookie(name: string, value: string, days = 90): void {
  if (typeof document === 'undefined') return;
  try {
    const expires = new Date(Date.now() + days * 86400 * 1000).toUTCString();
    document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax`;
  } catch {
    // Ignore cookie errors
  }
}

/**
 * Retrieve or create the single persistent anonymous UUID for this browser/device.
 * Never overwritten by phone numbers, lead IDs, or order IDs.
 */
export function getOrCreatePersistentAnonymousExternalId(): string {
  if (typeof window === 'undefined') return '';
  let persistentUuid = '';
  try {
    const cookieVal = getCookie(FB_EXTERNAL_ID_COOKIE) || getCookie('external_id') || '';
    const storageVal =
      window.localStorage.getItem(FB_EXTERNAL_ID_STORAGE_KEY) ||
      window.localStorage.getItem(FB_VISITOR_ID_STORAGE_KEY) ||
      '';

    if (isValidPersistentUuidFormat(cookieVal)) {
      persistentUuid = cookieVal.trim().toLowerCase();
    } else if (isValidPersistentUuidFormat(storageVal)) {
      persistentUuid = storageVal.trim().toLowerCase();
    } else {
      persistentUuid = generateUuidV4().toLowerCase();
    }

    setCookie(FB_EXTERNAL_ID_COOKIE, persistentUuid, 365);
    setCookie('external_id', persistentUuid, 365);
    window.localStorage.setItem(FB_EXTERNAL_ID_STORAGE_KEY, persistentUuid);
    window.localStorage.setItem(FB_VISITOR_ID_STORAGE_KEY, persistentUuid);
  } catch {
    if (!persistentUuid) persistentUuid = generateUuidV4().toLowerCase();
  }
  return persistentUuid;
}

/**
 * 1. Capture & Persist _fbc, _fbp, and persistent anonymous externalId on Initial Script Load (and SPA route changes):
 * - Checks URL query and hash for `fbclid`—if present, formats as `fb.1.{timestamp}.{fbclid}` and saves in BOTH
 *   cookies (`_fbc`) and `localStorage` (`_fbc` + `stockmaster_fb_fbc_v1`) before any URL cleanup can occur.
 * - Reads `_fbp` cookie (or localStorage fallback) and persists it in both cookies (`_fbp`) and `localStorage` (`_fbp`).
 * - Ensures the persistent anonymous UUID (`_sm_external_id`) is stable and never overwritten.
 */
export function captureAndPersistFbParams(): {
  fbp: string;
  fbc: string;
  externalId: string;
  visitorId: string;
} {
  if (typeof window === 'undefined') {
    return { fbp: '', fbc: '', externalId: '', visitorId: '' };
  }

  const now = Date.now();

  // 1. Capture fbclid from URL immediately -> _fbc = fb.1.${Date.now()}.${fbclid}
  let fbc = getCookie('_fbc') || '';
  try {
    if (!fbc) {
      fbc =
        window.localStorage.getItem(FB_FBC_DIRECT_KEY) ||
        window.localStorage.getItem(FB_FBC_STORAGE_KEY) ||
        '';
    }
    let fbclid: string | null = null;
    if (window.location.search) {
      fbclid = new URLSearchParams(window.location.search).get('fbclid');
    }
    if (!fbclid && window.location.hash.includes('fbclid=')) {
      const hashQuery = window.location.hash.split('?')[1] || '';
      fbclid = new URLSearchParams(hashQuery).get('fbclid');
    }
    if (!fbclid && window.location.href.includes('fbclid=')) {
      const m = window.location.href.match(/[?&]fbclid=([^&#]+)/i);
      if (m && m[1]) {
        fbclid = decodeURIComponent(m[1]);
      }
    }
    if (fbclid && fbclid.trim()) {
      const cleanFbclid = fbclid.trim();
      // Only create a new _fbc timestamp if this fbclid is new or _fbc was empty
      if (!fbc || !fbc.endsWith(`.${cleanFbclid}`)) {
        fbc = `fb.1.${now}.${cleanFbclid}`;
      }
      setCookie('_fbc', fbc, 90);
      window.localStorage.setItem(FB_FBC_DIRECT_KEY, fbc);
      window.localStorage.setItem(FB_FBC_STORAGE_KEY, fbc);
    } else if (fbc) {
      setCookie('_fbc', fbc, 90);
      window.localStorage.setItem(FB_FBC_DIRECT_KEY, fbc);
      window.localStorage.setItem(FB_FBC_STORAGE_KEY, fbc);
    }
  } catch {
    // Ignore URL/storage errors
  }

  // 2. Read & Persist _fbp cookie -> fb.1.${Date.now()}.${10_digit_random}
  let fbp = getCookie('_fbp') || '';
  try {
    if (!fbp) {
      fbp =
        window.localStorage.getItem(FB_FBP_DIRECT_KEY) ||
        window.localStorage.getItem(FB_FBP_STORAGE_KEY) ||
        '';
    }
    if (!fbp) {
      const random10 = Math.floor(1000000000 + Math.random() * 9000000000);
      fbp = `fb.1.${now}.${random10}`;
    }
    setCookie('_fbp', fbp, 90);
    window.localStorage.setItem(FB_FBP_DIRECT_KEY, fbp);
    window.localStorage.setItem(FB_FBP_STORAGE_KEY, fbp);
  } catch {
    // Ignore storage errors
  }

  // 3. Persistent anonymous device UUID (never overwritten with phone numbers)
  const externalId = getOrCreatePersistentAnonymousExternalId();

  return { fbp, fbc, externalId, visitorId: externalId };
}

export const ensureMetaFirstPartyIdentifiers = captureAndPersistFbParams;

// Automatically run on initial script load in browser before any SPA route change can occur
if (typeof window !== 'undefined') {
  captureAndPersistFbParams();
}

/**
 * Normalize customer data into Bangladesh Meta Pixel & CAPI format:
 * - ph: 8801XXXXXXXXX (strictly validated 13 digits; '' if incomplete/invalid)
 * - fn, ln: trimmed, lowercase, BD honorific prefixes stripped
 * - ct, st, zp: verified location only ('' when unknown — zero artificial defaults)
 * - country: 'bd'
 * - external_ids: preserves BOTH persistent anonymous UUID and normalized phone (when available)
 */
export function normalizeCustomerDataForMeta(
  identity: FbCustomerIdentity,
  orderId?: string,
  options?: { ignoreBrowserStorageUuid?: boolean }
): NormalizedFbUserData {
  const persistentUuid = options?.ignoreBrowserStorageUuid
    ? ''
    : getOrCreatePersistentAnonymousExternalId();
  const ph = normalizePhoneForMeta(identity.phone);
  const { fn, ln } = splitNameForMeta(identity.name);
  const loc = extractLocationForMeta(
    identity.address,
    identity.city,
    identity.state,
    identity.zip
  );
  const cleanOrderId = (orderId || '').trim().toLowerCase();
  const rawExplicitExtId = (identity.externalId || '').trim().toLowerCase();
  // Filter out temporary 'lead_...' or partial phone strings from explicit externalId
  const cleanExplicitExtId =
    rawExplicitExtId && !rawExplicitExtId.startsWith('lead_')
      ? normalizePhoneForMeta(rawExplicitExtId) || rawExplicitExtId
      : '';

  // Preserve BOTH the persistent anonymous UUID and the normalized phone number in external_ids
  const externalIdsList = Array.from(
    new Set(
      [persistentUuid, ph, cleanExplicitExtId, cleanOrderId].filter(Boolean)
    )
  );

  // Primary external_id: keep persistentUuid first for stable cross-funnel continuity, or ph if UUID is absent
  const primaryExternalId = persistentUuid || ph || cleanExplicitExtId || cleanOrderId;
  const cleanEmail = (identity.email || '').trim().toLowerCase();
  const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail) ? cleanEmail : '';

  return {
    ph,
    fn,
    ln,
    ct: loc.ct,
    st: loc.st,
    zp: loc.zp,
    country: 'bd',
    external_id: primaryExternalId,
    external_ids: externalIdsList,
    ...(validEmail ? { em: validEmail } : {})
  };
}

function scheduleDebouncedPixelAdvancedMatchingInit(
  pixelId: string,
  identity: FbCustomerIdentity,
  immediate = false
): void {
  if (typeof window === 'undefined' || !pixelId) return;

  const applyInit = () => {
    if (typeof window.fbq !== 'function') return;
    try {
      const advancedMatching = buildBrowserAdvancedMatchingObject(identity);
      const sig = `${pixelId}:${JSON.stringify(advancedMatching)}`;
      if (sig === lastAdvancedMatchingSignature && window.__smInitializedPixelId === pixelId) {
        return;
      }
      lastAdvancedMatchingSignature = sig;
      window.fbq('init', pixelId, advancedMatching);
      window.__smInitializedPixelId = pixelId;
    } catch {
      // Ignore fbq init error
    }
  };

  if (immediate) {
    if (fbqInitDebounceTimer) {
      clearTimeout(fbqInitDebounceTimer);
      fbqInitDebounceTimer = null;
    }
    applyInit();
    return;
  }

  if (fbqInitDebounceTimer) {
    clearTimeout(fbqInitDebounceTimer);
  }
  fbqInitDebounceTimer = setTimeout(() => {
    fbqInitDebounceTimer = null;
    applyInit();
  }, 500);
}

// In-memory active session plaintext identity (NEVER persisted to localStorage or cookies).
// Used exclusively so Browser Pixel fbq('init', pixelId, advancedMatching) receives valid unhashed
// normalized strings during the active session without ever passing pre-hashed 64-char hex strings to fbq('init').
let memorySessionPlaintextIdentity: FbCustomerIdentity = {};

interface StoredHashedFbIdentity {
  phHash?: string;
  fnHash?: string;
  lnHash?: string;
  emHash?: string;
  ctHash?: string;
  stHash?: string;
  zpHash?: string;
  countryHash?: string;
  externalIdHashes?: string[];
  externalId?: string;
  fbp?: string;
  fbc?: string;
  savedAt: number;
}

function isSha256Hex64(val?: string): boolean {
  return typeof val === 'string' && /^[a-f0-9]{64}$/i.test(val.trim());
}

/**
 * Sanitize event_source_url so /smart Admin URLs are never sent as customer event_source_url.
 * Uses the original customer storefront/landing URL when available, or falls back to origin + '/'.
 */
export function sanitizeCustomerEventSourceUrl(preferredUrl?: string): string {
  const isAdminSmartUrl = (u: string): boolean =>
    /\/smart(\/|$|\?|#)/i.test(u) || /[?&]route=smart/i.test(u);

  const candidate = String(preferredUrl || '').trim();
  if (candidate && /^https?:\/\//i.test(candidate) && !isAdminSmartUrl(candidate)) {
    return candidate;
  }

  if (typeof window !== 'undefined' && window.location) {
    const currentHref = String(window.location.href || '').trim();
    if (currentHref && !isAdminSmartUrl(currentHref)) {
      return currentHref;
    }
    const origin = String(window.location.origin || '').replace(/\/+$/, '');
    if (origin) {
      return `${origin}/`;
    }
  }

  return candidate && !isAdminSmartUrl(candidate) ? candidate : '';
}

/**
 * Read hashed customer matching cache from localStorage with strict 30-day TTL enforcement.
 * Automatically migrates and scrubs any legacy plaintext fields if present.
 */
function getStoredHashedFbIdentity(): StoredHashedFbIdentity | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(FB_USER_DATA_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') {
      window.localStorage.removeItem(FB_USER_DATA_STORAGE_KEY);
      window.localStorage.removeItem(FB_NORMALIZED_USER_STORAGE_KEY);
      return null;
    }

    const savedAt = Number(parsed.savedAt || parsed.updatedAt || 0);
    if (!savedAt || Date.now() - savedAt > FB_IDENTITY_CACHE_TTL_MS) {
      window.localStorage.removeItem(FB_USER_DATA_STORAGE_KEY);
      window.localStorage.removeItem(FB_NORMALIZED_USER_STORAGE_KEY);
      return null;
    }

    const persistentUuid = getOrCreatePersistentAnonymousExternalId();

    // If legacy plaintext fields exist from an older version, convert them to SHA-256 hashes once and overwrite immediately
    const hasLegacyPlaintext =
      Boolean(parsed.name) ||
      Boolean(parsed.phone) ||
      Boolean(parsed.email) ||
      Boolean(parsed.address) ||
      Boolean(parsed.city) ||
      Boolean(parsed.state) ||
      Boolean(parsed.zip);

    let phHash = isSha256Hex64(parsed.phHash) ? parsed.phHash.toLowerCase() : '';
    let fnHash = isSha256Hex64(parsed.fnHash) ? parsed.fnHash.toLowerCase() : '';
    let lnHash = isSha256Hex64(parsed.lnHash) ? parsed.lnHash.toLowerCase() : '';
    let emHash = isSha256Hex64(parsed.emHash) ? parsed.emHash.toLowerCase() : '';
    let ctHash = isSha256Hex64(parsed.ctHash) ? parsed.ctHash.toLowerCase() : '';
    let stHash = isSha256Hex64(parsed.stHash) ? parsed.stHash.toLowerCase() : '';
    let zpHash = isSha256Hex64(parsed.zpHash) ? parsed.zpHash.toLowerCase() : '';
    const countryHash = isSha256Hex64(parsed.countryHash)
      ? parsed.countryHash.toLowerCase()
      : sha256SyncUtf8('bd');

    const rawExtHashes: string[] = Array.isArray(parsed.externalIdHashes)
      ? parsed.externalIdHashes.filter((h: any) => isSha256Hex64(h)).map((h: string) => h.toLowerCase())
      : [];

    if (hasLegacyPlaintext) {
      const legacyNorm = normalizeCustomerDataForMeta({
        name: typeof parsed.name === 'string' ? parsed.name : '',
        phone: typeof parsed.phone === 'string' ? parsed.phone : '',
        email: typeof parsed.email === 'string' ? parsed.email : '',
        address: typeof parsed.address === 'string' ? parsed.address : '',
        city: typeof parsed.city === 'string' ? parsed.city : '',
        state: typeof parsed.state === 'string' ? parsed.state : '',
        zip: typeof parsed.zip === 'string' ? parsed.zip : '',
        externalId: persistentUuid
      });
      if (!phHash && legacyNorm.ph) phHash = sha256SyncUtf8(legacyNorm.ph);
      if (!fnHash && legacyNorm.fn) fnHash = sha256SyncUtf8(legacyNorm.fn);
      if (!lnHash && legacyNorm.ln) lnHash = sha256SyncUtf8(legacyNorm.ln);
      if (!emHash && legacyNorm.em) emHash = sha256SyncUtf8(legacyNorm.em);
      if (!ctHash && legacyNorm.ct) ctHash = sha256SyncUtf8(legacyNorm.ct);
      if (!stHash && legacyNorm.st) stHash = sha256SyncUtf8(legacyNorm.st);
      if (!zpHash && legacyNorm.zp) zpHash = sha256SyncUtf8(legacyNorm.zp);
      for (const eid of legacyNorm.external_ids) {
        const h = sha256SyncUtf8(eid);
        if (h && !rawExtHashes.includes(h)) rawExtHashes.push(h);
      }
    }

    const uuidHash = persistentUuid ? sha256SyncUtf8(persistentUuid) : '';
    if (uuidHash && !rawExtHashes.includes(uuidHash)) {
      rawExtHashes.unshift(uuidHash);
    }
    if (phHash && !rawExtHashes.includes(phHash)) {
      rawExtHashes.push(phHash);
    }

    const sanitizedRecord: StoredHashedFbIdentity = {
      ...(phHash ? { phHash } : {}),
      ...(fnHash ? { fnHash } : {}),
      ...(lnHash ? { lnHash } : {}),
      ...(emHash ? { emHash } : {}),
      ...(ctHash ? { ctHash } : {}),
      ...(stHash ? { stHash } : {}),
      ...(zpHash ? { zpHash } : {}),
      countryHash,
      externalIdHashes: Array.from(new Set(rawExtHashes.filter(Boolean))),
      externalId: persistentUuid,
      ...(typeof parsed.fbp === 'string' && parsed.fbp ? { fbp: parsed.fbp } : {}),
      ...(typeof parsed.fbc === 'string' && parsed.fbc ? { fbc: parsed.fbc } : {}),
      savedAt
    };

    if (hasLegacyPlaintext) {
      window.localStorage.setItem(FB_USER_DATA_STORAGE_KEY, JSON.stringify(sanitizedRecord));
    }

    return sanitizedRecord;
  } catch {
    return null;
  }
}

/**
 * 2. Real-time Customer Data Capture, Validation & Privacy-Safe Caching in localStorage + Debounced Pixel Re-Init
 * - Rejects incomplete phone numbers (only caches when phone is a valid 11/13-digit BD mobile number).
 * - Never overwrites the persistent anonymous UUID with phone numbers or temporary lead IDs.
 * - Never stores raw street addresses as `city`.
 * - Never stores plaintext customer PII in `stockmaster_fb_user_data_v1` or `fb_advanced_matching_user`;
 *   persists only normalized SHA-256 identifiers for CAPI with a 30-day TTL, while keeping active-session
 *   plaintext in memory only for live `fbq('init')` calls.
 */
export function saveFbCustomerIdentity(
  partial: FbCustomerIdentity,
  business?: Business
): FbCustomerIdentity {
  if (typeof window === 'undefined') return partial;
  const current = memorySessionPlaintextIdentity;
  const existingHashed = getStoredHashedFbIdentity();
  const { fbp, fbc, externalId: persistentUuid } = captureAndPersistFbParams();

  // Validate phone: only updatephone if the incoming phone is a valid BD number
  const incomingNormPhone =
    partial.phone !== undefined && !isSha256Hex64(partial.phone)
      ? normalizePhoneForMeta(partial.phone)
      : '';
  const currentNormPhone = normalizePhoneForMeta(current.phone);
  const validPhoneToStore = incomingNormPhone || currentNormPhone || '';

  const mergedAddress =
    partial.address !== undefined && !isSha256Hex64(partial.address)
      ? partial.address.trim()
      : current.address || '';
  const rawIncomingCity =
    partial.city !== undefined && !isSha256Hex64(partial.city)
      ? partial.city.trim().toLowerCase()
      : current.city || '';
  const extractedLoc = extractLocationForMeta(
    mergedAddress,
    rawIncomingCity,
    partial.state ?? current.state,
    partial.zip ?? current.zip
  );

  const rawEmail =
    partial.email !== undefined && !isSha256Hex64(partial.email)
      ? partial.email.trim().toLowerCase()
      : current.email || '';
  const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawEmail) ? rawEmail : '';

  const merged: FbCustomerIdentity = {
    name:
      partial.name !== undefined && !isSha256Hex64(partial.name)
        ? partial.name.trim()
        : current.name || '',
    phone: validPhoneToStore,
    email: validEmail,
    address: mergedAddress,
    city: extractedLoc.ct,
    state: extractedLoc.st,
    zip: extractedLoc.zp,
    externalId: persistentUuid,
    fbp: partial.fbp?.trim() || current.fbp || existingHashed?.fbp || fbp,
    fbc: partial.fbc?.trim() || current.fbc || existingHashed?.fbc || fbc
  };

  // Keep plaintext in RAM only for the current browser tab session so fbq('init') never receives SHA-256 hex strings
  memorySessionPlaintextIdentity = merged;

  const normalizedUserData = normalizeCustomerDataForMeta(merged);
  const phHash = normalizedUserData.ph
    ? sha256SyncUtf8(normalizedUserData.ph)
    : existingHashed?.phHash || '';
  const fnHash = normalizedUserData.fn
    ? sha256SyncUtf8(normalizedUserData.fn)
    : existingHashed?.fnHash || '';
  const lnHash = normalizedUserData.ln
    ? sha256SyncUtf8(normalizedUserData.ln)
    : existingHashed?.lnHash || '';
  const emHash = normalizedUserData.em
    ? sha256SyncUtf8(normalizedUserData.em)
    : existingHashed?.emHash || '';
  const ctHash = normalizedUserData.ct
    ? sha256SyncUtf8(normalizedUserData.ct)
    : existingHashed?.ctHash || '';
  const stHash = normalizedUserData.st
    ? sha256SyncUtf8(normalizedUserData.st)
    : existingHashed?.stHash || '';
  const zpHash = normalizedUserData.zp
    ? sha256SyncUtf8(normalizedUserData.zp)
    : existingHashed?.zpHash || '';
  const countryHash = sha256SyncUtf8('bd');

  const computedExtHashes = normalizedUserData.external_ids
    .map(id => sha256SyncUtf8(id))
    .filter(Boolean);
  const mergedExtIdHashes = Array.from(
    new Set([
      ...computedExtHashes,
      ...(existingHashed?.externalIdHashes || []),
      ...(phHash ? [phHash] : [])
    ])
  );

  const hashedCachePayload: StoredHashedFbIdentity = {
    ...(phHash ? { phHash } : {}),
    ...(fnHash ? { fnHash } : {}),
    ...(lnHash ? { lnHash } : {}),
    ...(emHash ? { emHash } : {}),
    ...(ctHash ? { ctHash } : {}),
    ...(stHash ? { stHash } : {}),
    ...(zpHash ? { zpHash } : {}),
    countryHash,
    externalIdHashes: mergedExtIdHashes,
    externalId: persistentUuid,
    ...(merged.fbp ? { fbp: merged.fbp } : {}),
    ...(merged.fbc ? { fbc: merged.fbc } : {}),
    savedAt: Date.now()
  };

  try {
    // Store ONLY SHA-256 hashed identifiers and non-PII technical IDs in localStorage (zero plaintext PII)
    window.localStorage.setItem(FB_USER_DATA_STORAGE_KEY, JSON.stringify(hashedCachePayload));
    window.localStorage.setItem(
      FB_NORMALIZED_USER_STORAGE_KEY,
      JSON.stringify({
        ph: phHash,
        fn: fnHash,
        ln: lnHash,
        ...(emHash ? { em: emHash } : {}),
        ct: ctHash,
        st: stHash,
        zp: zpHash,
        country: countryHash,
        external_id: persistentUuid,
        external_id_hashes: mergedExtIdHashes,
        updatedAt: Date.now()
      })
    );
  } catch {
    // Ignore storage quota errors
  }

  // Debounce Browser Pixel Advanced Matching re-init so typing never spams fbq('init')
  const activePixelId = (business?.fbPixelId || window.__smInitializedPixelId || '').trim();
  if (activePixelId) {
    scheduleDebouncedPixelAdvancedMatchingInit(activePixelId, merged, false);
  }

  return merged;
}

export function getFbCustomerIdentity(): FbCustomerIdentity {
  if (typeof window === 'undefined') return {};
  const { fbp, fbc, externalId: persistentUuid } = captureAndPersistFbParams();
  const storedHashed = getStoredHashedFbIdentity();
  const session = memorySessionPlaintextIdentity;

  return {
    ...(session.name ? { name: session.name } : {}),
    ...(session.phone ? { phone: normalizePhoneForMeta(session.phone) } : {}),
    ...(session.email ? { email: session.email } : {}),
    ...(session.address ? { address: session.address } : {}),
    ...(session.city ? { city: session.city } : {}),
    ...(session.state ? { state: session.state } : {}),
    ...(session.zip ? { zip: session.zip } : {}),
    externalId: persistentUuid,
    fbp: fbp || session.fbp || storedHashed?.fbp,
    fbc: fbc || session.fbc || storedHashed?.fbc
  };
}

/**
 * Build Browser Pixel Advanced Matching dictionary for fbq('init', PIXEL_ID, userData)
 * - Only sends verified unhashed normalized parameters from active session memory / override.
 * - NEVER passes 64-character SHA-256 hex hashes as plaintext values into fbq('init') so fbevents.js never double-hashes.
 */
export function buildBrowserAdvancedMatchingObject(
  identityOverride?: FbCustomerIdentity
): Record<string, string> {
  const session = memorySessionPlaintextIdentity;
  const safeOverride: FbCustomerIdentity = {};
  if (identityOverride) {
    if (identityOverride.name && !isSha256Hex64(identityOverride.name)) safeOverride.name = identityOverride.name;
    if (identityOverride.phone && !isSha256Hex64(identityOverride.phone)) safeOverride.phone = identityOverride.phone;
    if (identityOverride.email && !isSha256Hex64(identityOverride.email)) safeOverride.email = identityOverride.email;
    if (identityOverride.address && !isSha256Hex64(identityOverride.address)) safeOverride.address = identityOverride.address;
    if (identityOverride.city && !isSha256Hex64(identityOverride.city)) safeOverride.city = identityOverride.city;
    if (identityOverride.state && !isSha256Hex64(identityOverride.state)) safeOverride.state = identityOverride.state;
    if (identityOverride.zip && !isSha256Hex64(identityOverride.zip)) safeOverride.zip = identityOverride.zip;
    if (identityOverride.externalId && !isSha256Hex64(identityOverride.externalId)) {
      safeOverride.externalId = identityOverride.externalId;
    }
  }

  const identity: FbCustomerIdentity = {
    ...session,
    ...safeOverride,
    phone:
      normalizePhoneForMeta(safeOverride.phone) ||
      normalizePhoneForMeta(session.phone) ||
      ''
  };
  const normalized = normalizeCustomerDataForMeta(identity);

  const advancedMatching: Record<string, string> = {
    country: normalized.country, // 'bd'
    external_id: normalized.external_id // persistent anonymous UUID (unhashed for fbq('init'))
  };

  if (normalized.ph && !isSha256Hex64(normalized.ph)) advancedMatching.ph = normalized.ph;
  if (normalized.fn && !isSha256Hex64(normalized.fn)) advancedMatching.fn = normalized.fn;
  if (normalized.ln && !isSha256Hex64(normalized.ln)) advancedMatching.ln = normalized.ln;
  if (normalized.em && !isSha256Hex64(normalized.em)) advancedMatching.em = normalized.em;
  if (normalized.ct && !isSha256Hex64(normalized.ct)) advancedMatching.ct = normalized.ct;
  if (normalized.st && !isSha256Hex64(normalized.st)) advancedMatching.st = normalized.st;
  if (normalized.zp && !isSha256Hex64(normalized.zp)) advancedMatching.zp = normalized.zp;

  return advancedMatching;
}

/**
 * Read & write local event telemetry logs for Developer Facebook Dashboard
 */
export function getFbEventLogs(): FbEventLogEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(FB_EVENT_LOGS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function clearFbEventLogs(): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(FB_EVENT_LOGS_STORAGE_KEY);
  } catch {
    // Ignore
  }
}

function recordFbEventLog(entry: FbEventLogEntry): void {
  if (typeof window === 'undefined') return;
  try {
    const existing = getFbEventLogs();
    const updated = [entry, ...existing.filter(e => e.eventId !== entry.eventId)].slice(0, 80);
    window.localStorage.setItem(FB_EVENT_LOGS_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

/**
 * Extract clean GTM Container ID (e.g., GTM-XXXXXXX) even if developer pastes full <script> snippet
 */
export function extractGtmContainerId(raw?: string): string {
  if (!raw) return '';
  const trimmed = String(raw).trim();
  const match = trimmed.match(/GTM-[A-Z0-9]+/i);
  if (match) return match[0].toUpperCase();
  return trimmed.toUpperCase();
}

/**
 * Initialize Google Tag Manager (GTM) Container in <head> and <noscript> in <body>
 */
export function initGoogleTagManager(business?: Business): void {
  if (typeof window === 'undefined' || typeof document === 'undefined' || !business) return;
  if (business.gtmEnabled === false) return;

  const gtmId = extractGtmContainerId(business.gtmContainerId);
  if (!gtmId || !/^GTM-[A-Z0-9]+$/.test(gtmId)) return;

  window.dataLayer = window.dataLayer || [];

  if (window.__smInitializedGtmId === gtmId && document.getElementById('sm-gtm-head-script')) {
    return;
  }

  const rawHost = (business.gtmServerUrl || '').trim().replace(/\/+$/, '');
  const baseHost = /^https:\/\/[a-zA-Z0-9.-]+(?::\d+)?(?:\/[a-zA-Z0-9._/-]*)?$/.test(rawHost)
    ? rawHost
    : 'https://www.googletagmanager.com';

  // Push gtm.start event into dataLayer
  window.dataLayer.push({
    'gtm.start': new Date().getTime(),
    event: 'gtm.js'
  });

  // Inject <script> into <head>
  const existingScript = document.getElementById('sm-gtm-head-script');
  if (existingScript && existingScript.parentNode) {
    existingScript.parentNode.removeChild(existingScript);
  }
  const script = document.createElement('script');
  script.id = 'sm-gtm-head-script';
  script.async = true;
  script.src = `${baseHost}/gtm.js?id=${encodeURIComponent(gtmId)}`;
  const firstScript = document.getElementsByTagName('script')[0];
  if (firstScript && firstScript.parentNode) {
    firstScript.parentNode.insertBefore(script, firstScript);
  } else {
    document.head.appendChild(script);
  }

  // Inject <noscript><iframe> into <body>
  const existingNoScript = document.getElementById('sm-gtm-body-noscript');
  if (existingNoScript && existingNoScript.parentNode) {
    existingNoScript.parentNode.removeChild(existingNoScript);
  }
  if (document.body) {
    const noscript = document.createElement('noscript');
    noscript.id = 'sm-gtm-body-noscript';
    const iframe = document.createElement('iframe');
    iframe.src = `${baseHost}/ns.html?id=${encodeURIComponent(gtmId)}`;
    iframe.height = '0';
    iframe.width = '0';
    iframe.style.display = 'none';
    iframe.style.visibility = 'hidden';
    noscript.appendChild(iframe);
    document.body.insertBefore(noscript, document.body.firstChild);
  }

  window.__smInitializedGtmId = gtmId;
}

/**
 * Push standardized GA4 + Meta CAPI E-Commerce event into window.dataLayer for Google Tag Manager
 */
export function pushGtmDataLayerEvent(params: {
  business?: Business;
  fbEventName: FbStandardEventName;
  eventId: string;
  customData?: FbCustomData;
  rawUserData?: Record<string, any>;
  hashedUserData?: Record<string, any>;
}): void {
  if (typeof window === 'undefined' || !params.business) return;
  const { business, fbEventName, eventId, customData = {}, rawUserData = {}, hashedUserData = {} } = params;

  if (business.gtmEnabled === false || business.gtmDataLayerEnabled === false) return;
  const gtmId = extractGtmContainerId(business.gtmContainerId);
  if (!gtmId) return;

  initGoogleTagManager(business);
  window.dataLayer = window.dataLayer || [];

  const ga4EventMap: Record<FbStandardEventName, string> = {
    PageView: 'page_view',
    ViewContent: 'view_item',
    Search: 'search',
    AddToCart: 'add_to_cart',
    InitiateCheckout: 'begin_checkout',
    AddPaymentInfo: 'add_payment_info',
    Lead: 'generate_lead',
    CompleteRegistration: 'sign_up',
    Purchase: 'purchase'
  };

  const ga4EventName = ga4EventMap[fbEventName] || fbEventName;
  const currency = customData.currency || business.fbCurrency || 'BDT';
  const value = typeof customData.value === 'number' ? customData.value : 0;

  const items = (customData.contents || []).map((item, index) => ({
    item_id: String(item.id),
    item_sku: item.sku || customData.content_sku || String(item.id),
    item_group_id: item.item_group_id || customData.item_group_id || undefined,
    item_variant: item.variant || customData.variant_label || undefined,
    item_name: item.title || customData.content_name || `Product ${item.id}`,
    item_category: item.category || customData.content_category || 'General',
    price: typeof item.item_price === 'number' ? item.item_price : value,
    quantity: item.quantity || 1,
    index
  }));

  // Clear previous ecommerce object per Google GTM best practices
  window.dataLayer.push({ ecommerce: null });

  window.dataLayer.push({
    event: ga4EventName,
    fb_event_name: fbEventName,
    event_id: eventId,
    gtm_container_id: gtmId,
    ecommerce: {
      currency,
      value,
      ...(customData.order_id ? { transaction_id: customData.order_id } : {}),
      ...(customData.search_string ? { search_term: customData.search_string } : {}),
      items
    },
    user_data: {
      phone_number: rawUserData.phone ? `+${rawUserData.phone}` : '',
      email_address: rawUserData.email || '',
      address: {
        first_name: rawUserData.fn || '',
        last_name: rawUserData.ln || '',
        street: rawUserData.address || '',
        ...(rawUserData.city ? { city: rawUserData.city } : {}),
        ...(rawUserData.state ? { region: rawUserData.state } : {}),
        ...(rawUserData.zip ? { postal_code: rawUserData.zip } : {}),
        country: 'BD'
      },
      external_id: rawUserData.external_id || '',
      fbp: rawUserData.fbp || '',
      fbc: rawUserData.fbc || '',
      sha256_user_data: hashedUserData
    }
  });
}

/**
 * Initialize Browser Facebook Pixel with Advanced Matching (fbq('init', PIXEL_ID, userData))
 */
export async function initFacebookPixel(
  business?: Business,
  customerOverride?: FbCustomerIdentity
): Promise<void> {
  if (typeof window === 'undefined' || !business) return;
  initGoogleTagManager(business);
  const pixelId = (business.fbPixelId || '').trim();
  if (!pixelId || business.fbTrackingEnabled === false) return;

  captureAndPersistFbParams();
  if (customerOverride) {
    saveFbCustomerIdentity(customerOverride, business);
  }

  // Inject fbevents.js script once
  if (!window.fbq) {
    (function (f: any, b: Document, e: string, v: string, n?: any, t?: HTMLScriptElement, s?: Element) {
      if (f.fbq) return;
      n = f.fbq = function () {
        n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
      };
      if (!f._fbq) f._fbq = n;
      n.push = n;
      n.loaded = true;
      n.version = '2.0';
      n.queue = [];
      t = b.createElement(e) as HTMLScriptElement;
      t.async = true;
      t.src = v;
      s = b.getElementsByTagName(e)[0];
      if (s && s.parentNode) {
        s.parentNode.insertBefore(t, s);
      } else {
        b.head.appendChild(t);
      }
    })(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
  }

  scheduleDebouncedPixelAdvancedMatchingInit(pixelId, customerOverride || {}, true);
}

/**
 * Build complete SHA-256 hashed user_data object + raw_user_data for Backend CAPI
 * - Preserves BOTH persistent anonymous UUID and normalized phone in external_id array.
 * - Uses cached SHA-256 identifiers from `stockmaster_fb_user_data_v1` when plaintext session fields are absent,
 *   without ever double-hashing already-hashed 64-char hex values.
 * - Only includes ct, st, zp when verified from actual customer data (zero artificial defaults).
 * - Supports isolatedCustomerOnly mode for Admin Incomplete-Order recovery so Admin's browser identity never leaks.
 */
export async function buildMetaHashedUserData(
  customerOverride?: FbCustomerIdentity,
  orderId?: string,
  options?: { isolatedCustomerOnly?: boolean }
): Promise<{
  userData: Record<string, any>;
  rawUserData: Record<string, any>;
  matchedKeys: string[];
  emqScore: number;
}> {
  const isIsolated = Boolean(options?.isolatedCustomerOnly);

  if (!isIsolated && customerOverride) {
    saveFbCustomerIdentity(customerOverride);
  }

  const storedPlainSession = isIsolated ? {} : getFbCustomerIdentity();
  const storedHashedCache = isIsolated ? null : getStoredHashedFbIdentity();
  const browserParams = isIsolated
    ? { fbp: '', fbc: '', externalId: '' }
    : captureAndPersistFbParams();

  const identity: FbCustomerIdentity = isIsolated
    ? { ...(customerOverride || {}) }
    : {
        ...storedPlainSession,
        ...(customerOverride || {}),
        phone:
          normalizePhoneForMeta(customerOverride?.phone) ||
          normalizePhoneForMeta(storedPlainSession.phone) ||
          ''
      };

  const normalized = normalizeCustomerDataForMeta(identity, orderId, {
    ignoreBrowserStorageUuid: isIsolated
  });

  const allExternalIds = Array.from(
    new Set(
      [
        ...normalized.external_ids,
        browserParams.externalId,
        normalized.ph
      ].filter(Boolean)
    )
  );

  const [
    computedPhHash,
    computedFnHash,
    computedLnHash,
    computedEmHash,
    computedCtHash,
    computedStHash,
    computedZpHash,
    countryHash,
    ...extIdHashes
  ] = await Promise.all([
    normalized.ph ? sha256MetaHash(normalized.ph) : Promise.resolve(''),
    normalized.fn ? sha256MetaHash(normalized.fn) : Promise.resolve(''),
    normalized.ln ? sha256MetaHash(normalized.ln) : Promise.resolve(''),
    normalized.em ? sha256MetaHash(normalized.em) : Promise.resolve(''),
    normalized.ct ? sha256MetaHash(normalized.ct) : Promise.resolve(''),
    normalized.st ? sha256MetaHash(normalized.st) : Promise.resolve(''),
    normalized.zp ? sha256MetaHash(normalized.zp) : Promise.resolve(''),
    sha256MetaHash('bd'),
    ...allExternalIds.map(id => sha256MetaHash(id))
  ]);

  // Fall back to cached SHA-256 identifiers (already 64-char hex, never double-hashed) when not in isolated mode
  const phHash = computedPhHash || (!isIsolated && storedHashedCache?.phHash ? storedHashedCache.phHash : '');
  const fnHash = computedFnHash || (!isIsolated && storedHashedCache?.fnHash ? storedHashedCache.fnHash : '');
  const lnHash = computedLnHash || (!isIsolated && storedHashedCache?.lnHash ? storedHashedCache.lnHash : '');
  const emHash = computedEmHash || (!isIsolated && storedHashedCache?.emHash ? storedHashedCache.emHash : '');
  const ctHash = computedCtHash || (!isIsolated && storedHashedCache?.ctHash ? storedHashedCache.ctHash : '');
  const stHash = computedStHash || (!isIsolated && storedHashedCache?.stHash ? storedHashedCache.stHash : '');
  const zpHash = computedZpHash || (!isIsolated && storedHashedCache?.zpHash ? storedHashedCache.zpHash : '');

  const validExtIdHashes = Array.from(
    new Set(
      [
        ...extIdHashes.filter(Boolean),
        ...(!isIsolated && Array.isArray(storedHashedCache?.externalIdHashes)
          ? storedHashedCache!.externalIdHashes.filter(h => isSha256Hex64(h))
          : []),
        ...(phHash ? [phHash] : [])
      ].filter(Boolean)
    )
  );
  const clientUserAgent = isIsolated
    ? (customerOverride?.clientUserAgent || '').trim()
    : (customerOverride?.clientUserAgent || (typeof navigator !== 'undefined' ? navigator.userAgent : '')).trim();
  const clientIp = (customerOverride?.clientIp || '').trim();

  // All hashed PII fields formatted strictly as arrays of hashed strings per Meta CAPI spec
  const userData: Record<string, any> = {
    country: [countryHash]
  };

  const matchedKeys: string[] = ['country'];

  if (validExtIdHashes.length > 0) {
    userData.external_id = validExtIdHashes;
    matchedKeys.push('external_id');
  }
  if (clientUserAgent) {
    userData.client_user_agent = clientUserAgent;
    matchedKeys.push('ua');
  }
  if (clientIp) {
    userData.client_ip_address = clientIp;
    matchedKeys.push('ip');
  } else if (!isIsolated) {
    matchedKeys.push('ip'); // Resolved by server from request headers for direct customer events
  }

  if (phHash) {
    userData.ph = [phHash];
    matchedKeys.push('ph');
  }
  if (fnHash) {
    userData.fn = [fnHash];
    matchedKeys.push('fn');
  }
  if (lnHash) {
    userData.ln = [lnHash];
    matchedKeys.push('ln');
  }
  if (emHash) {
    userData.em = [emHash];
    matchedKeys.push('em');
  }
  if (ctHash) {
    userData.ct = [ctHash];
    matchedKeys.push('ct');
  }
  if (stHash) {
    userData.st = [stHash];
    matchedKeys.push('st');
  }
  if (zpHash) {
    userData.zp = [zpHash];
    matchedKeys.push('zp');
  }

  const effectiveFbp = (
    customerOverride?.fbp ||
    identity.fbp ||
    (!isIsolated && storedHashedCache?.fbp) ||
    browserParams.fbp ||
    ''
  ).trim();
  const effectiveFbc = (
    customerOverride?.fbc ||
    identity.fbc ||
    (!isIsolated && storedHashedCache?.fbc) ||
    browserParams.fbc ||
    ''
  ).trim();

  if (effectiveFbp) {
    userData.fbp = effectiveFbp;
    matchedKeys.push('fbp');
  }
  if (effectiveFbc) {
    userData.fbc = effectiveFbc;
    matchedKeys.push('fbc');
  }

  // Raw user data only populated from active in-memory session or explicit customerOverride (never stored in retry queue)
  const rawUserData: Record<string, any> = {
    name: identity.name || '',
    fn: normalized.fn,
    ln: normalized.ln,
    phone: normalized.ph,
    email: normalized.em || '',
    address: identity.address || '',
    city: normalized.ct,
    state: normalized.st,
    zip: normalized.zp,
    country: 'bd',
    external_id: normalized.external_id,
    external_ids: allExternalIds,
    fbp: effectiveFbp,
    fbc: effectiveFbc,
    ...(clientIp ? { client_ip_address: clientIp } : {}),
    ...(clientUserAgent ? { client_user_agent: clientUserAgent } : {})
  };

  // Calculate realistic diagnostic EMQ estimate based only on actually present parameters
  let score = 4.2; // Base for country + IP/UA/external_id
  if (effectiveFbp) score += 1.0;
  if (effectiveFbc) score += 0.8;
  if (phHash) score += 2.0;
  if (fnHash) score += 0.6;
  if (lnHash) score += 0.3;
  if (ctHash) score += 0.4;
  if (stHash) score += 0.2;
  if (zpHash) score += 0.2;
  if (emHash) score += 0.3;
  const emqScore = Math.min(10, Number(score.toFixed(1)));

  return { userData, rawUserData, matchedKeys, emqScore };
}

/**
 * Send Server-Side CAPI payload through neutral first-party endpoint (/api/order-telemetry or ?route=order-telemetry)
 * with automatic fallback to (/api/fb/capi or ?route=fb/capi).
 */
async function postCapiPayloadToServer(payload: Record<string, any>): Promise<{
  success: boolean;
  events_received?: number;
  fbtrace_id?: string;
  error?: string;
}> {
  const endpoints = [
    '/api/order-telemetry',
    '/api/index.php?route=order-telemetry',
    '/api/fb/capi',
    '/api/index.php?route=fb/capi'
  ];
  let lastError = 'Server CAPI endpoint unreachable';

  for (const url of endpoints) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        keepalive: true,
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(() => null);
      if (res.ok && data && (data.success || data.events_received)) {
        return {
          success: true,
          events_received: data.events_received || data.data?.events_received || 1,
          fbtrace_id: data.fbtrace_id || data.data?.fbtrace_id || ''
        };
      }
      if (data && (data.error || data.msg)) {
        lastError = typeof data.error === 'string' ? data.error : JSON.stringify(data.error || data.msg);
      }
    } catch (err: any) {
      lastError = err?.message || 'Network error';
    }
  }

  return { success: false, error: lastError };
}

/**
 * Queue failed CAPI events in localStorage without any raw customer PII (`raw_user_data` and `access_token` stripped).
 * Preserves `event_id`, `event.user_data` (SHA-256 hashed identifiers + fbp/fbc/UA/IP), and `event.custom_data`.
 */
function enqueueFailedCapiPayload(payload: Record<string, any>): void {
  if (typeof window === 'undefined') return;
  try {
    const raw = window.localStorage.getItem(FB_RETRY_QUEUE_STORAGE_KEY);
    const list: Record<string, any>[] = raw ? JSON.parse(raw) : [];
    const incomingEventId = payload?.event_id || payload?.event?.event_id;
    const deduplicated = incomingEventId
      ? list.filter(item => (item?.event_id || item?.event?.event_id) !== incomingEventId)
      : list;

    // Strip raw_user_data and access_token before persisting to localStorage
    const { raw_user_data: _omittedRawUserData, access_token: _omittedAccessToken, ...safePayload } = payload || {};
    deduplicated.push({ ...safePayload, queuedAt: Date.now() });
    window.localStorage.setItem(FB_RETRY_QUEUE_STORAGE_KEY, JSON.stringify(deduplicated.slice(-30)));
  } catch {
    // Ignore storage errors
  }
}

export async function flushFbRetryQueue(): Promise<number> {
  if (typeof window === 'undefined') return 0;
  try {
    const raw = window.localStorage.getItem(FB_RETRY_QUEUE_STORAGE_KEY);
    if (!raw) return 0;
    const queue: Record<string, any>[] = JSON.parse(raw);
    if (!Array.isArray(queue) || queue.length === 0) return 0;

    window.localStorage.removeItem(FB_RETRY_QUEUE_STORAGE_KEY);
    let flushedCount = 0;
    const remaining: Record<string, any>[] = [];

    for (const item of queue) {
      const { raw_user_data: _omittedRaw, access_token: _omittedToken, ...cleanItem } = item || {};
      const res = await postCapiPayloadToServer(cleanItem);
      if (res.success) {
        flushedCount++;
      } else {
        remaining.push(cleanItem);
      }
    }

    if (remaining.length > 0) {
      window.localStorage.setItem(FB_RETRY_QUEUE_STORAGE_KEY, JSON.stringify(remaining));
    }
    return flushedCount;
  } catch {
    return 0;
  }
}

export function getFbRetryQueueCount(): number {
  if (typeof window === 'undefined') return 0;
  try {
    const raw = window.localStorage.getItem(FB_RETRY_QUEUE_STORAGE_KEY);
    if (!raw) return 0;
    const queue = JSON.parse(raw);
    return Array.isArray(queue) ? queue.length : 0;
  } catch {
    return 0;
  }
}

/**
 * Master Smart Event Dispatcher:
 * Fires BOTH Browser Pixel (fbq) AND Server-Side Conversions API (CAPI) with identical eventId
 * for 100% deduplication.
 * Supports `serverOnly: true` for Admin Incomplete-Order recovery so the Admin's browser pixel/IP/UA is never used.
 */
export async function trackFacebookEvent(params: {
  business?: Business;
  eventName: FbStandardEventName;
  customData?: FbCustomData;
  customer?: FbCustomerIdentity;
  eventIdOverride?: string;
  eventSourceUrlOverride?: string;
  serverOnly?: boolean;
  forceTest?: boolean;
}): Promise<FbEventLogEntry | null> {
  const {
    business,
    eventName,
    customData = {},
    customer,
    eventIdOverride,
    eventSourceUrlOverride,
    serverOnly = false,
    forceTest
  } = params;
  if (typeof window === 'undefined' || !business) return null;

  const pixelId = (business.fbPixelId || '').trim();
  const accessToken = (business.fbAccessToken || '').trim();
  const testEventCode = (business.fbTestEventCode || '').trim();
  const gtmId = extractGtmContainerId(business.gtmContainerId);
  const hasGtmActive = !serverOnly && business.gtmEnabled !== false && Boolean(gtmId);
  const hasFbActive = business.fbTrackingEnabled !== false && Boolean(pixelId);

  if (!forceTest) {
    if (!hasFbActive && !hasGtmActive) return null;
    if (eventName === 'PageView' && business.fbTrackPageView === false) return null;
    if (eventName === 'ViewContent' && business.fbTrackViewContent === false) return null;
    if (eventName === 'Search' && business.fbTrackSearch === false) return null;
    if (eventName === 'AddToCart' && business.fbTrackAddToCart === false) return null;
    if (eventName === 'InitiateCheckout' && business.fbTrackInitiateCheckout === false) return null;
    if (eventName === 'Purchase' && business.fbTrackPurchase === false) return null;
    if ((eventName === 'Lead' || eventName === 'CompleteRegistration') && business.fbTrackLead === false) {
      return null;
    }
  }

  // Generate a single unique event_id per event shared between Browser Pixel ({ eventID }), GTM dataLayer & Server CAPI
  const timestampSec = Math.floor(Date.now() / 1000);
  const eventId =
    eventIdOverride ||
    generateMetaEventId(eventName, customData.order_id);

  // Strict Purchase Deduplication Guard: never allow duplicate Purchase events for the same orderId or eventId
  if (eventName === 'Purchase' && !forceTest) {
    if (hasPurchaseEventAlreadyFired(eventId, customData.order_id)) {
      return null;
    }
    markPurchaseEventFired(eventId, customData.order_id);
  }

  if (!serverOnly) {
    await initFacebookPixel(business, customer);
  }

  // Currency conversion if developer configured USD instead of BDT
  const targetCurrency = business.fbCurrency || 'BDT';
  const exchangeRate = Number(business.fbUsdExchangeRate) > 0 ? Number(business.fbUsdExchangeRate) : 120;
  const rawValue = typeof customData.value === 'number' ? customData.value : undefined;
  const normalizedValue =
    rawValue !== undefined
      ? targetCurrency === 'USD'
        ? Number((rawValue / exchangeRate).toFixed(2))
        : Number(rawValue.toFixed(2))
      : undefined;

  const finalCustomData: FbCustomData = {
    ...customData,
    ...(normalizedValue !== undefined ? { value: normalizedValue, currency: targetCurrency } : {})
  };

  // 1. Fire Browser Pixel with Advanced Matching & { eventID: eventId } for 100% Deduplication (Skipped when serverOnly=true)
  let browserSent = false;
  if (!serverOnly && hasFbActive && pixelId && typeof window.fbq === 'function') {
    try {
      scheduleDebouncedPixelAdvancedMatchingInit(pixelId, customer || {}, true);
      window.fbq('track', eventName, finalCustomData, { eventID: eventId });
      browserSent = true;
    } catch {
      browserSent = false;
    }
  }

  // 2. Build SHA-256 hashed user_data & raw_user_data and fire GTM dataLayer + Server-Side CAPI
  const { userData, rawUserData, matchedKeys, emqScore } = await buildMetaHashedUserData(
    customer,
    customData.order_id,
    { isolatedCustomerOnly: serverOnly }
  );

  if (hasGtmActive) {
    pushGtmDataLayerEvent({
      business,
      fbEventName: eventName,
      eventId,
      customData: finalCustomData,
      rawUserData,
      hashedUserData: userData
    });
  }

  // Ensure /smart Admin URLs are never sent as customer event_source_url
  const eventSourceUrl = sanitizeCustomerEventSourceUrl(eventSourceUrlOverride);
  const clientUserAgent = serverOnly
    ? (customer?.clientUserAgent || '').trim()
    : (customer?.clientUserAgent || (typeof navigator !== 'undefined' ? navigator.userAgent : '')).trim();

  let serverSent = false;
  let serverStatus: FbEventLogEntry['serverStatus'] = 'skipped';
  let serverResponseMsg = '';
  let fbTraceId = '';

  const hasCapiCredential = Boolean(accessToken) || Boolean(business.fbCapiConfigured);
  const shouldSendCapi =
    (business.fbServerSideEnabled !== false && Boolean(pixelId) && hasCapiCredential) ||
    (forceTest && Boolean(pixelId) && hasCapiCredential);

  if (shouldSendCapi) {
    const capiRequestPayload: Record<string, any> = {
      pixel_id: pixelId,
      ...(accessToken ? { access_token: accessToken } : {}),
      ...(testEventCode ? { test_event_code: testEventCode } : {}),
      event_id: eventId,
      _fbp: rawUserData.fbp || '',
      _fbc: rawUserData.fbc || '',
      ...(clientUserAgent ? { client_user_agent: clientUserAgent } : {}),
      ...(serverOnly ? { omit_sender_ip_ua: true } : {}),
      event_source_url: eventSourceUrl,
      raw_user_data: rawUserData,
      event: {
        event_name: eventName,
        event_time: timestampSec,
        event_id: eventId,
        action_source: 'website',
        event_source_url: eventSourceUrl,
        user_data: userData,
        custom_data: finalCustomData
      }
    };

    const capiRes = await postCapiPayloadToServer(capiRequestPayload);
    if (capiRes.success) {
      serverSent = true;
      serverStatus = 'sent';
      fbTraceId = capiRes.fbtrace_id || '';
      serverResponseMsg = `CAPI 200 OK (events_received: ${capiRes.events_received || 1})`;
    } else {
      enqueueFailedCapiPayload(capiRequestPayload);
      serverStatus = 'queued_retry';
      serverResponseMsg = capiRes.error || 'Queued for automatic retry';
    }
  } else if (!hasCapiCredential) {
    serverStatus = 'skipped';
    serverResponseMsg = 'Browser Pixel Only (Add CAPI Access Token for Server-Side)';
  }

  const logEntry: FbEventLogEntry = {
    id: `fblog_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    eventId,
    eventName,
    timestamp: new Date().toISOString(),
    eventSourceUrl,
    browserSent,
    serverSent,
    serverStatus,
    serverResponseMsg,
    fbTraceId,
    emqScore,
    matchedKeys,
    value: finalCustomData.value,
    currency: finalCustomData.currency,
    orderId: finalCustomData.order_id,
    customData: finalCustomData
  };

  recordFbEventLog(logEntry);
  return logEntry;
}



