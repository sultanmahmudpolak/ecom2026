import { BanglaFontStyle } from '../types';

const loadedFontKeys = new Set<string>();

const OPTIONAL_FONT_URLS: Record<string, string> = {
  outfit:
    'https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap'
};

/**
 * Only loads optional English number font (Outfit) if selected.
 * All 14 extra Bangla fonts have been removed; Noto Sans Bengali is the sole default Bangla font.
 */
export function ensureCustomFontLoaded(fontKey?: BanglaFontStyle | string | null): void {
  if (typeof document === 'undefined' || !fontKey) return;
  const key = String(fontKey).trim();
  const href = OPTIONAL_FONT_URLS[key];
  if (!href || loadedFontKeys.has(href)) return;

  loadedFontKeys.add(href);
  if (document.querySelector(`link[href="${href}"]`)) return;

  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = href;
  document.head.appendChild(link);
}
