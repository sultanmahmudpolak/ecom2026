import React, { useState, useEffect, useMemo, useRef, Suspense } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { GlobalSkeletonLoader } from './components/GlobalSkeletonLoader';
import {
  buildLandingPagePath,
  findLandingProductFromUrl
} from './utils/landingConstants';
import {
  captureAndPersistFbParams,
  initFacebookPixel,
  initGoogleTagManager
} from './utils/facebookTracking';
import { upsertFaviconLink } from './components/ProductSeoHelmet';
import { ensureCustomFontLoaded } from './utils/fontLoader';
import { UserRole, Product } from './types';
import {
  ShieldAlert,
  ArrowLeft,
  LayoutDashboard,
  ShoppingBag,
  Boxes,
  Users,
  Menu,
  Database
} from 'lucide-react';

import { EcommerceStorefrontView, findProductFromLocation } from './components/EcommerceStorefrontView';
import { NotFoundView } from './components/NotFoundView';
import { ProductLandingPageView } from './components/ProductLandingPageView';

// Capture fbclid -> _fbc, _fbp, and persistent external_id immediately at module load before any URL history changes
if (typeof window !== 'undefined') {
  try {
    captureAndPersistFbParams();
  } catch {
    // Ignore storage errors
  }
}

// Hybrid Code Splitting: Eagerly load Customer Storefront & Landing Page views for instant 0ms customer experience,
// while lazy-loading heavy Admin Panel / ERP views on-demand with automatic network/cache retry protection.
function lazyAdminModule<T extends React.ComponentType<any>>(
  loader: () => Promise<T>
): React.LazyExoticComponent<T> {
  return React.lazy(() =>
    loader()
      .then((Component) => ({ default: Component }))
      .catch((err) => {
        // Retry once after a short delay in case of transient mobile network blip
        return new Promise<{ default: T }>((resolve, reject) => {
          setTimeout(() => {
            loader()
              .then((Component) => resolve({ default: Component }))
              .catch(reject);
          }, 400);
        });
      })
  );
}

const Header = lazyAdminModule(() => import('./components/Header').then((m) => m.Header));
const Sidebar = lazyAdminModule(() => import('./components/Sidebar').then((m) => m.Sidebar));
const LoginView = lazyAdminModule(() => import('./components/LoginView').then((m) => m.LoginView));
const DashboardView = lazyAdminModule(() => import('./components/DashboardView').then((m) => m.DashboardView));
const OnlineOrdersView = lazyAdminModule(() => import('./components/OnlineOrdersView').then((m) => m.OnlineOrdersView));
const CourierIntegrationView = lazyAdminModule(() => import('./components/CourierIntegrationView').then((m) => m.CourierIntegrationView));
const InventoryView = lazyAdminModule(() => import('./components/InventoryView').then((m) => m.InventoryView));
const LandingPagesView = lazyAdminModule(() => import('./components/LandingPagesView').then((m) => m.LandingPagesView));
const SpinWheelAdminView = lazyAdminModule(() => import('./components/SpinWheelAdminView').then((m) => m.SpinWheelAdminView));
const CustomersView = lazyAdminModule(() => import('./components/CustomersView').then((m) => m.CustomersView));
const DatabaseView = lazyAdminModule(() => import('./components/DatabaseView').then((m) => m.DatabaseView));
const FacebookTrackingView = lazyAdminModule(() => import('./components/FacebookTrackingView').then((m) => m.FacebookTrackingView));
const WordPressSyncView = lazyAdminModule(() => import('./components/WordPressSyncView').then((m) => m.WordPressSyncView));
const SettingsView = lazyAdminModule(() => import('./components/SettingsView').then((m) => m.SettingsView));

export const ROLE_ALLOWED_VIEWS: Record<UserRole, string[]> = {
  developer: [
    'database',
    'facebook',
    'gtm',
    'wordpress',
    'dashboard',
    'online_orders',
    'courier_integration',
    'online_customers',
    'spin_wheel',
    'inventory',
    'landing_pages',
    'customers',
    'settings'
  ],
  super_admin: [
    'dashboard',
    'online_orders',
    'courier_integration',
    'online_customers',
    'spin_wheel',
    'inventory',
    'landing_pages',
    'customers',
    'settings'
  ],
  store_manager: [
    'dashboard',
    'online_orders',
    'courier_integration',
    'online_customers',
    'spin_wheel',
    'inventory',
    'landing_pages',
    'customers'
  ],
  cashier: [
    'dashboard',
    'online_orders',
    'online_customers',
    'spin_wheel',
    'customers'
  ],
  distribution_mgr: [
    'dashboard',
    'online_orders',
    'online_customers',
    'spin_wheel',
    'inventory',
    'landing_pages',
    'customers'
  ],
  sales_rep: [
    'dashboard',
    'customers'
  ]
};

const NAV_ROUTE_MODE_KEY = 'stockmaster_active_route_mode_v1';
const NAV_ERP_VIEW_KEY = 'stockmaster_active_erp_view_v1';
const NAV_LAST_ERP_VIEW_KEY = 'stockmaster_last_erp_view_v1';
const NAV_LANDING_PRODUCT_ID_KEY = 'stockmaster_active_landing_product_id_v1';
const ADMIN_THEME_STORAGE_KEY = 'stockmaster_admin_theme_v1';

// Obfuscated Admin Gate Path ("/smart") so plain-text searches in compiled JS cannot discover the route
const ADMIN_GATE_PATH = String.fromCharCode(47, 115, 109, 97, 114, 116);

const normalizeCleanPath = (rawPathname: string): string => {
  try {
    return decodeURIComponent(rawPathname || '')
      .toLowerCase()
      .replace(/\/+index\.php(?=\/|$)/i, '')
      .replace(/\/+(index\.html|cpanel-app\.html)$/i, '')
      .replace(/\/+$/, '');
  } catch {
    return (rawPathname || '').toLowerCase().replace(/\/+$/, '');
  }
};

const detectInitialAdminTheme = (): 'light' | 'dark' => {
  if (typeof window === 'undefined') return 'light';
  try {
    const saved = window.localStorage.getItem(ADMIN_THEME_STORAGE_KEY);
    if (saved === 'dark' || saved === 'light') return saved;
  } catch {
    // Ignore storage errors
  }
  return 'light';
};

const detectInitialRouteMode = (): 'storefront' | 'erp' | 'landing' | 'not_found' => {
  if (typeof window === 'undefined') return 'storefront';
  const cleanPath = normalizeCleanPath(window.location.pathname);
  const search = (window.location.search || '').toLowerCase();

  // 1. Secret Admin Login & Dashboard Gate (/smart, /index.php/smart, or ?smart)
  if (
    cleanPath === ADMIN_GATE_PATH ||
    cleanPath.endsWith(ADMIN_GATE_PATH) ||
    search === '?smart' ||
    search.startsWith('?smart&') ||
    search.includes('route=smart')
  ) {
    return 'erp';
  }

  // 2. Landing Page Route (/landing/:slug or ?landing=:slug)
  if (
    cleanPath === '/landing' ||
    cleanPath.startsWith('/landing/') ||
    cleanPath.includes('/landing/') ||
    search.includes('landing=')
  ) {
    return 'landing';
  }

  // 3. Valid Storefront Routes (/, /product/..., /checkout, /account, /customer-login)
  if (
    cleanPath === '' ||
    cleanPath === '/' ||
    cleanPath === '/checkout' ||
    cleanPath.endsWith('/checkout') ||
    cleanPath === '/account' ||
    cleanPath.endsWith('/account') ||
    cleanPath === '/customer-login' ||
    cleanPath.endsWith('/customer-login') ||
    cleanPath.startsWith('/product/') ||
    cleanPath.includes('/product/')
  ) {
    try {
      window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'storefront');
      window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
    } catch {
      // Ignore storage errors
    }
    return 'storefront';
  }

  // 4. All other URLs (including /admin, /login, /dashboard, /erp, or invalid links) -> Custom 404 Page
  return 'not_found';
};

const detectInitialErpView = (): string => {
  if (typeof window === 'undefined') return 'dashboard';
  try {
    const params = new URLSearchParams(window.location.search);
    const fromQuery = (params.get('view') || '').trim();
    if (fromQuery) return fromQuery;

    const fromHist = window.history.state?.view;
    if (typeof fromHist === 'string' && fromHist.trim() !== '' && fromHist !== 'home') {
      return fromHist.trim();
    }

    const fromSession = window.sessionStorage.getItem(NAV_ERP_VIEW_KEY);
    if (fromSession && fromSession.trim() !== '') {
      return fromSession.trim();
    }

    const fromLocal = window.localStorage.getItem(NAV_LAST_ERP_VIEW_KEY);
    if (fromLocal && fromLocal.trim() !== '') {
      return fromLocal.trim();
    }
  } catch {
    // Ignore storage errors
  }
  return 'dashboard';
};

const detectInitialLandingProductId = (): string | null => {
  if (typeof window === 'undefined') return null;
  if (detectInitialRouteMode() !== 'landing') return null;
  try {
    const fromHist = window.history.state?.landingProductId;
    if (typeof fromHist === 'string' && fromHist.trim() !== '') {
      return fromHist.trim();
    }
    const fromSession = window.sessionStorage.getItem(NAV_LANDING_PRODUCT_ID_KEY);
    if (fromSession && fromSession.trim() !== '') {
      return fromSession.trim();
    }
  } catch {
    // Ignore storage errors
  }
  return null;
};

const MainLayout: React.FC = () => {
  const {
    isAuthenticated,
    currentUser,
    language,
    setLanguage,
    currentBusiness,
    products,
    onlineOrders,
    incompleteOrders,
    isServerHydrated
  } = useApp();
  const [routeMode, setRouteMode] = useState<'storefront' | 'erp' | 'landing' | 'not_found'>(
    detectInitialRouteMode
  );

  // Automatically keep Admin Panel in English ('en') and Customer Storefront/Landing Page/404 in Bangla ('bn')
  useEffect(() => {
    const targetLang = routeMode === 'erp' ? 'en' : 'bn';
    if (language !== targetLang) {
      setLanguage(targetLang);
    }
  }, [routeMode, language, setLanguage]);

  const [currentView, setCurrentView] = useState<string>(detectInitialErpView);
  const [activeLandingProductId, setActiveLandingProductId] = useState<string | null>(
    detectInitialLandingProductId
  );
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isDesktopSidebarOpen, setIsDesktopSidebarOpen] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    try {
      return window.localStorage.getItem('sm_admin_sidebar_open') !== 'false';
    } catch {
      return true;
    }
  });
  const [isViewTransitioning, setIsViewTransitioning] = useState<boolean>(false);
  const [adminTheme, setAdminTheme] = useState<'light' | 'dark'>(detectInitialAdminTheme);
  const viewTransitionTimerRef = useRef<number | null>(null);

  const toggleDesktopSidebar = () => {
    setIsDesktopSidebarOpen((prev) => {
      const next = !prev;
      try {
        window.localStorage.setItem('sm_admin_sidebar_open', String(next));
      } catch {
        // Ignore storage errors
      }
      return next;
    });
  };

  const safeUserRole: UserRole = (currentUser?.role && ROLE_ALLOWED_VIEWS[currentUser.role])
    ? currentUser.role
    : 'super_admin';
  const allowedViews = ROLE_ALLOWED_VIEWS[safeUserRole] || ['dashboard'];

  useEffect(() => {
    try {
      window.localStorage.setItem(ADMIN_THEME_STORAGE_KEY, adminTheme);
    } catch {
      // Ignore storage errors
    }
    if (typeof document !== 'undefined') {
      const shouldBeDark = routeMode === 'erp' && isAuthenticated && adminTheme === 'dark';
      document.documentElement.classList.toggle('dark', shouldBeDark);
    }
  }, [adminTheme, routeMode, isAuthenticated]);

  useEffect(() => {
    return () => {
      if (viewTransitionTimerRef.current !== null) {
        window.clearTimeout(viewTransitionTimerRef.current);
      }
    };
  }, []);

  // Persist routeMode, currentView, and activeLandingProductId so page reloads stay on the exact same page
  useEffect(() => {
    try {
      if (routeMode !== 'not_found') {
        window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, routeMode);
      }
      if (currentView && currentView !== 'home') {
        window.sessionStorage.setItem(NAV_ERP_VIEW_KEY, currentView);
        window.localStorage.setItem(NAV_LAST_ERP_VIEW_KEY, currentView);
      }
      if (routeMode === 'landing' && activeLandingProductId) {
        window.sessionStorage.setItem(NAV_LANDING_PRODUCT_ID_KEY, activeLandingProductId);
      } else {
        window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
      }
    } catch {
      // Ignore storage errors
    }
  }, [routeMode, currentView, activeLandingProductId]);

  // Resolve active Landing Page product from URL (/landing/:slug or ?landing=:slug) first, then explicit state
  const activeLandingProduct = useMemo<Product | null>(() => {
    if (typeof window !== 'undefined') {
      const fromUrl = findLandingProductFromUrl(
        products,
        window.location.pathname,
        window.location.search
      );
      if (fromUrl) return fromUrl;
    }
    if (activeLandingProductId) {
      const byId = products.find(p => p.id === activeLandingProductId);
      if (byId) return byId;
    }
    if (typeof window !== 'undefined') {
      const cleanPath = normalizeCleanPath(window.location.pathname);
      const hasExplicitLandingSlug =
        cleanPath.startsWith('/landing/') && cleanPath.slice('/landing/'.length).trim().length > 0;
      const params = new URLSearchParams(window.location.search);
      const hasExplicitLandingParam = Boolean((params.get('landing') || '').trim());
      if (hasExplicitLandingSlug || hasExplicitLandingParam) {
        return null;
      }
    }
    return products.find(p => p.isLandingPageProduct) || products[0] || null;
  }, [products, activeLandingProductId, routeMode]);

  // Capture & persist _fbc (from URL fbclid) and _fbp in cookies + localStorage on initial page load & route changes
  useEffect(() => {
    captureAndPersistFbParams();
  }, [routeMode, activeLandingProductId]);

  // Automatically initialize Google Tag Manager (GTM) & Facebook Pixel Advanced Matching on storefront & ERP load
  useEffect(() => {
    if (currentBusiness) {
      initGoogleTagManager(currentBusiness);
      initFacebookPixel(currentBusiness).catch(() => {});
    }
  }, [
    currentBusiness?.gtmContainerId,
    currentBusiness?.gtmEnabled,
    currentBusiness?.gtmServerUrl,
    currentBusiness?.fbPixelId,
    currentBusiness?.fbTrackingEnabled
  ]);

  // Keep browser tab title and favicon synced with Store Name, Favicon & Logo across all modes
  useEffect(() => {
    if (typeof document === 'undefined' || !currentBusiness) return;
    const storeName = currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট';
    const fav =
      currentBusiness.faviconUrl?.trim() ||
      currentBusiness.logoUrl?.trim() ||
      '';
    if (fav) {
      upsertFaviconLink(fav);
    }

    if (routeMode === 'landing' && activeLandingProduct) {
      document.title = `${activeLandingProduct.nameBn} | ${storeName}`;
    } else if (routeMode === 'erp') {
      document.title = `${storeName} | অ্যাডমিন ড্যাশবোর্ড`;
    } else if (routeMode === 'not_found') {
      document.title = `পেজটি পাওয়া যায়নি (404) | ${storeName}`;
    }
  }, [
    routeMode,
    currentBusiness?.name,
    currentBusiness?.faviconUrl,
    currentBusiness?.logoUrl,
    activeLandingProduct
  ]);

  // Load optional custom Bangla/number fonts in the background only if configured
  useEffect(() => {
    ensureCustomFontLoaded(currentBusiness?.banglaFont);
    ensureCustomFontLoaded(currentBusiness?.numberFontStyle);
    if (activeLandingProduct?.landingFontStyle) {
      ensureCustomFontLoaded(activeLandingProduct.landingFontStyle);
    }
  }, [
    currentBusiness?.banglaFont,
    currentBusiness?.numberFontStyle,
    activeLandingProduct?.landingFontStyle
  ]);

  // Sync routeMode & ERP currentView with browser/mobile hardware Back button (popstate)
  useEffect(() => {
    try {
      const currentState = window.history.state;
      if (!currentState || !currentState.routeMode) {
        window.history.replaceState(
          { routeMode, view: currentView, landingProductId: activeLandingProductId },
          '',
          window.location.pathname + window.location.search
        );
      }
    } catch {
      // Ignore history errors in sandboxed iframes
    }

    const handlePopState = (event: PopStateEvent) => {
      setIsMobileMenuOpen(false);
      const urlBasedMode = detectInitialRouteMode();
      const state = event.state;
      if (urlBasedMode === 'not_found') {
        setActiveLandingProductId(null);
        setRouteMode('not_found');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      if (urlBasedMode === 'storefront') {
        setActiveLandingProductId(null);
        setRouteMode('storefront');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      if (state && state.routeMode) {
        setRouteMode(state.routeMode);
        if (state.routeMode === 'erp' && state.view) {
          setCurrentView(state.view);
        }
        if (state.routeMode === 'landing' && state.landingProductId) {
          setActiveLandingProductId(state.landingProductId);
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setRouteMode(urlBasedMode);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const switchToErp = () => {
    try {
      window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'erp');
      window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
      const targetUrl = isAuthenticated
        ? `${ADMIN_GATE_PATH}?view=${encodeURIComponent(currentView)}`
        : ADMIN_GATE_PATH;
      window.history.pushState(
        { routeMode: 'erp', view: currentView },
        '',
        targetUrl
      );
    } catch {
      // Ignore history errors in sandboxed iframes
    }
    setActiveLandingProductId(null);
    setRouteMode('erp');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const switchToStorefront = (targetUrl?: string) => {
    const safeUrl = typeof targetUrl === 'string' && targetUrl.trim() !== '' ? targetUrl.trim() : '/';
    try {
      window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'storefront');
      window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
      window.history.pushState({ routeMode: 'storefront', view: 'home' }, '', safeUrl);
    } catch {
      // Ignore history errors in sandboxed iframes
    }
    setActiveLandingProductId(null);
    setRouteMode('storefront');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openLandingPageForProduct = (product: Product) => {
    const lpPath = buildLandingPagePath(product);
    try {
      window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'landing');
      window.sessionStorage.setItem(NAV_LANDING_PRODUCT_ID_KEY, product.id);
      window.history.pushState(
        { routeMode: 'landing', landingProductId: product.id },
        '',
        lpPath
      );
    } catch {
      // Ignore history errors in sandboxed iframes
    }
    setActiveLandingProductId(product.id);
    setRouteMode('landing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Ensure currentView is valid for the user's role without overwriting their active page on reload
  useEffect(() => {
    if (isAuthenticated) {
      if (!allowedViews.includes(currentView)) {
        const fallbackView =
          safeUserRole === 'developer' && allowedViews.includes('database')
            ? 'database'
            : allowedViews[0] || 'dashboard';
        setCurrentView(fallbackView);
      }
    }
  }, [isAuthenticated, currentUser?.id, safeUserRole]);

  // Background Prefetch: Once an Admin logs into /smart, silently preload other Admin tabs during idle time
  // so switching between Admin views feels 0ms instant while keeping Customer Storefront 100% lightweight.
  useEffect(() => {
    if (routeMode !== 'erp' || !isAuthenticated) return;
    const timer = window.setTimeout(() => {
      import('./components/DashboardView').catch(() => {});
      import('./components/OnlineOrdersView').catch(() => {});
      import('./components/InventoryView').catch(() => {});
      import('./components/LandingPagesView').catch(() => {});
      import('./components/CustomersView').catch(() => {});
      import('./components/SettingsView').catch(() => {});
      import('./components/CourierIntegrationView').catch(() => {});
      import('./components/SpinWheelAdminView').catch(() => {});
      import('./components/FacebookTrackingView').catch(() => {});
      import('./components/WordPressSyncView').catch(() => {});
      import('./components/DatabaseView').catch(() => {});
    }, 900);
    return () => window.clearTimeout(timer);
  }, [routeMode, isAuthenticated]);

  // Keep /smart URL clean and synchronized with authentication state
  useEffect(() => {
    if (typeof window === 'undefined' || routeMode !== 'erp') return;
    try {
      const cleanPath = normalizeCleanPath(window.location.pathname);
      if (!isAuthenticated) {
        if (!cleanPath.endsWith(ADMIN_GATE_PATH) || window.location.search !== '') {
          window.history.replaceState(
            { routeMode: 'erp', view: currentView },
            '',
            ADMIN_GATE_PATH
          );
        }
      } else {
        const targetAdminUrl = `${ADMIN_GATE_PATH}?view=${encodeURIComponent(currentView)}`;
        if (!cleanPath.endsWith(ADMIN_GATE_PATH) || !window.location.search.includes('view=')) {
          window.history.replaceState(
            { routeMode: 'erp', view: currentView },
            '',
            targetAdminUrl
          );
        }
      }
    } catch {
      // Ignore history errors in sandboxed iframes
    }
  }, [routeMode, isAuthenticated, currentView]);

  const pendingMobileOrderCount = useMemo(
    () =>
      onlineOrders.filter(
        o => o.orderStatus === 'pending' || o.orderStatus === 'confirmed'
      ).length,
    [onlineOrders]
  );

  const activeMobileLeadCount = useMemo(
    () =>
      incompleteOrders.filter(
        inc => inc.status === 'abandoned' || inc.status === 'contacted'
      ).length,
    [incompleteOrders]
  );

  // Build dynamic thumb-friendly mobile bottom navigation items based on user role
  const mobileQuickTabs = useMemo(() => {
    const candidates = [
      {
        id: 'dashboard',
        labelBn: 'Dashboard',
        labelEn: 'Dashboard',
        icon: LayoutDashboard,
        badge: 0
      },
      {
        id: 'online_orders',
        labelBn: 'Orders',
        labelEn: 'Orders',
        icon: ShoppingBag,
        badge: pendingMobileOrderCount
      },
      {
        id: 'inventory',
        labelBn: 'Products',
        labelEn: 'Products',
        icon: Boxes,
        badge: 0
      },
      {
        id: 'online_customers',
        labelBn: 'Customers',
        labelEn: 'Customers',
        icon: Users,
        badge: 0
      },
      {
        id: 'database',
        labelBn: 'cPanel',
        labelEn: 'cPanel',
        icon: Database,
        badge: 0
      }
    ];
    return candidates.filter(c => allowedViews.includes(c.id)).slice(0, 4);
  }, [allowedViews, pendingMobileOrderCount]);

  // Custom 404 Page Not Found Route (wrong URLs, /admin, /login, etc.)
  if (routeMode === 'not_found') {
    return <NotFoundView onGoToStorefront={switchToStorefront} />;
  }

  // 0. Dedicated Single-Product Landing Page Route (domain.com/landing/:slug)
  if (routeMode === 'landing') {
    if (!activeLandingProduct) {
      if (products.length > 0 && isServerHydrated) {
        return <NotFoundView onGoToStorefront={switchToStorefront} />;
      }
      return <GlobalSkeletonLoader variant="landing" />;
    }

    return (
      <Suspense fallback={<GlobalSkeletonLoader variant="landing" />}>
        <ProductLandingPageView
          key={activeLandingProduct.id}
          product={activeLandingProduct}
          onBackToAdmin={
            isAuthenticated
              ? () => {
                  setCurrentView('landing_pages');
                  switchToErp();
                }
              : undefined
          }
          onOpenStorefront={switchToStorefront}
        />
      </Suspense>
    );
  }

  // 1. Root Domain (domain.com/) -> Customer E-Commerce Storefront
  if (routeMode === 'storefront') {
    if (typeof window !== 'undefined' && products.length > 0 && isServerHydrated) {
      const cleanPath = normalizeCleanPath(window.location.pathname);
      if (cleanPath.startsWith('/product/') || cleanPath.includes('/product/')) {
        const matchedProd = findProductFromLocation(
          products,
          window.location.pathname,
          window.location.search
        );
        if (!matchedProd) {
          return <NotFoundView onGoToStorefront={switchToStorefront} />;
        }
      }
    }
    return <EcommerceStorefrontView onNavigateToErp={switchToErp} />;
  }

  // 2. ERP Route (domain.com/smart) -> Login Screen if unauthenticated
  if (!isAuthenticated) {
    return (
      <Suspense fallback={<GlobalSkeletonLoader view="dashboard" />}>
        <LoginView onBackToStorefront={switchToStorefront} />
      </Suspense>
    );
  }

  const handleSafeNavigate = (targetView: string) => {
    if (allowedViews.includes(targetView)) {
      const isSwitchingModule = targetView !== currentView;
      try {
        window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'erp');
        window.sessionStorage.setItem(NAV_ERP_VIEW_KEY, targetView);
        window.localStorage.setItem(NAV_LAST_ERP_VIEW_KEY, targetView);
        if (isSwitchingModule) {
          window.history.pushState(
            { routeMode: 'erp', view: targetView },
            '',
            `${ADMIN_GATE_PATH}?view=${encodeURIComponent(targetView)}`
          );
        }
      } catch {
        // Ignore history errors in sandboxed iframes
      }

      if (isSwitchingModule) {
        if (viewTransitionTimerRef.current !== null) {
          window.clearTimeout(viewTransitionTimerRef.current);
        }
        setIsViewTransitioning(true);
        setCurrentView(targetView);
        viewTransitionTimerRef.current = window.setTimeout(() => {
          setIsViewTransitioning(false);
          viewTransitionTimerRef.current = null;
        }, 220);
      } else {
        setCurrentView(targetView);
      }

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const renderView = () => {
    if (!allowedViews.includes(currentView)) {
      return (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900/60 p-6 sm:p-8 max-w-lg mx-auto my-12 text-center space-y-4 shadow-xs">
          <div className="w-12 h-12 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {language === 'bn' ? 'প্রবেশাধিকার সংরক্ষিত (Access Restricted)' : 'Access Restricted'}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            {language === 'bn'
              ? `আপনার বর্তমান অ্যাকাউন্ট (${currentUser.name}) এর এই মডিউলে প্রবেশের অনুমতি নেই। অন্য কোনো রোলে প্রবেশ করতে হলে অনুগ্রহ করে লগআউট করে সেই অ্যাকাউন্টের পাসওয়ার্ড দিয়ে লগইন করুন।`
              : `Your current account (${currentUser.name}) does not have permission to view this module. Please log out and sign in with an authorized account.`}
          </p>
          <button
            onClick={() => handleSafeNavigate('dashboard')}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ড্যাশবোর্ডে ফিরে যান' : 'Back to Dashboard'}</span>
          </button>
        </div>
      );
    }

    if (!isServerHydrated || isViewTransitioning) {
      return <GlobalSkeletonLoader view={currentView} />;
    }

    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            onNavigate={handleSafeNavigate}
            onOpenStorefront={switchToStorefront}
            adminTheme={adminTheme}
            onSetAdminTheme={setAdminTheme}
          />
        );
      case 'online_orders':
        return <OnlineOrdersView onOpenStorefront={switchToStorefront} onNavigate={handleSafeNavigate} />;
      case 'courier_integration':
        return <CourierIntegrationView />;
      case 'inventory':
        return <InventoryView />;
      case 'landing_pages':
        return <LandingPagesView onPreviewLandingProduct={openLandingPageForProduct} />;
      case 'spin_wheel':
        return <SpinWheelAdminView />;
      case 'online_customers':
        return <CustomersView key="online_customers" initialFilter="online" />;
      case 'customers':
        return <CustomersView key="customers" initialFilter="all" />;
      case 'database':
        return <DatabaseView />;
      case 'facebook':
        return <FacebookTrackingView focusGtm={false} />;
      case 'gtm':
        return <FacebookTrackingView focusGtm={true} />;
      case 'wordpress':
        return <WordPressSyncView />;
      case 'settings':
        return <SettingsView />;
      default:
        return (
          <DashboardView
            onNavigate={handleSafeNavigate}
            onOpenStorefront={switchToStorefront}
            adminTheme={adminTheme}
            onSetAdminTheme={setAdminTheme}
          />
        );
    }
  };

  return (
    <div
      className={`${
        adminTheme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-[#f4f7fb] text-slate-900'
      } min-h-screen flex flex-col antialiased transition-colors duration-200`}
    >
      <Suspense fallback={<div className="h-14 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800" />}>
        <Header
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          isDesktopSidebarOpen={isDesktopSidebarOpen}
          onToggleDesktopSidebar={toggleDesktopSidebar}
          onNavigate={handleSafeNavigate}
          onOpenStorefront={switchToStorefront}
          adminTheme={adminTheme}
          onSetAdminTheme={setAdminTheme}
        />
      </Suspense>

      <div className="flex-1 flex">
        <Suspense fallback={null}>
          <Sidebar
            currentView={currentView}
            onSelectView={handleSafeNavigate}
            isOpenMobile={isMobileMenuOpen}
            onCloseMobile={() => setIsMobileMenuOpen(false)}
            isDesktopSidebarOpen={isDesktopSidebarOpen}
            onToggleDesktopSidebar={toggleDesktopSidebar}
            onOpenStorefront={switchToStorefront}
            adminTheme={adminTheme}
            onSetAdminTheme={setAdminTheme}
          />
        </Suspense>

        <main
          className={`flex-1 min-w-0 flex flex-col transition-all duration-200 ${
            isDesktopSidebarOpen ? 'lg:pl-64' : 'lg:pl-0'
          }`}
        >
          <div
            key={currentView}
            className={`flex-1 p-3.5 sm:p-5 lg:p-7 pb-24 lg:pb-8 w-full mx-auto animate-page-rise transition-all duration-200 ${
              isDesktopSidebarOpen ? 'max-w-7xl' : 'max-w-[1600px]'
            }`}
          >
            <Suspense fallback={<GlobalSkeletonLoader view={currentView} />}>
              {renderView()}
            </Suspense>
          </div>
        </main>
      </div>

      {/* Mobile Fixed Bottom Navigation Bar (100% Thumb-Friendly < lg) */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/90 dark:border-slate-800 px-1.5 py-1.5 shadow-[0_-4px_20px_rgba(15,23,42,0.06)] no-print"
        aria-label="Mobile quick navigation"
      >
        <div className="grid grid-cols-5 items-center gap-1 max-w-md mx-auto">
          {mobileQuickTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentView === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleSafeNavigate(tab.id)}
                className={`relative min-h-[48px] flex flex-col items-center justify-center rounded-xl transition-all cursor-pointer ${
                  isActive
                    ? 'text-emerald-700 dark:text-emerald-300 font-extrabold bg-emerald-50/90 dark:bg-emerald-950/60'
                    : 'text-slate-500 dark:text-slate-400 font-semibold hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <div className="relative">
                  <Icon
                    className={`w-4 h-4 ${
                      isActive
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  />
                  {tab.badge > 0 && (
                    <span className="absolute -top-1.5 -right-3 px-1 min-w-[16px] h-4 rounded-full bg-emerald-600 text-white text-[9px] font-mono font-extrabold flex items-center justify-center tabular-nums">
                      {tab.badge > 99 ? '99+' : tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] tracking-tight mt-1 truncate max-w-[68px]">
                  {tab.labelEn}
                </span>
              </button>
            );
          })}

          {/* 5th Tab: Open Full Modules Drawer */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(true)}
            className={`relative min-h-[48px] flex flex-col items-center justify-center rounded-xl transition-all cursor-pointer ${
              isMobileMenuOpen
                ? 'text-emerald-700 dark:text-emerald-300 font-extrabold bg-emerald-50/90 dark:bg-emerald-950/60'
                : 'text-slate-500 dark:text-slate-400 font-semibold hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <div className="relative">
              <Menu className="w-4 h-4" />
              {activeMobileLeadCount > 0 && (
                <span className="absolute -top-1 -right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900" />
              )}
            </div>
            <span className="text-[10px] tracking-tight mt-1">
              Menu
            </span>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
