import React, { useState, useEffect, useMemo, Suspense } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { GlobalSkeletonLoader } from './components/GlobalSkeletonLoader';
import { findLandingProductFromUrl } from './utils/landingConstants';
import {
  captureAndPersistFbParams,
  initFacebookPixel,
  initGoogleTagManager
} from './utils/facebookTracking';
import { upsertFaviconLink } from './components/ProductSeoHelmet';
import { ensureCustomFontLoaded } from './utils/fontLoader';
import { Product } from './types';
import { EcommerceStorefrontView, findProductFromLocation } from './components/EcommerceStorefrontView';
import { NotFoundView } from './components/NotFoundView';
import { ProductLandingPageView } from './components/ProductLandingPageView';

const NAV_ROUTE_MODE_KEY = 'stockmaster_active_route_mode_v1';
const NAV_LANDING_PRODUCT_ID_KEY = 'stockmaster_active_landing_product_id_v1';
const ADMIN_GATE_PATH = String.fromCharCode(47, 115, 109, 97, 114, 116);

const normalizeCleanPath = (rawPathname: string): string => {
  try {
    return decodeURIComponent(rawPathname || '')
      .toLowerCase()
      .replace(/\/+index\.php(?=\/|$)/i, '')
      .replace(/\/+(index\.html|cpanel-app\.html)$/i, '')
      .replace(/\/+$/, '');
  } catch {
    return (rawPathname || '').toLowerCase().replace(/\/+$/, '');
  }
};

const detectInitialStorefrontRouteMode = (): 'storefront' | 'erp' | 'landing' | 'not_found' => {
  if (typeof window === 'undefined') return 'storefront';
  const cleanPath = normalizeCleanPath(window.location.pathname);
  const search = (window.location.search || '').toLowerCase();

  if (
    cleanPath === ADMIN_GATE_PATH ||
    cleanPath.endsWith(ADMIN_GATE_PATH) ||
    search === '?smart' ||
    search.startsWith('?smart&') ||
    search.includes('route=smart')
  ) {
    return 'erp';
  }

  if (
    cleanPath === '/landing' ||
    cleanPath.startsWith('/landing/') ||
    cleanPath.includes('/landing/') ||
    search.includes('landing=')
  ) {
    return 'landing';
  }

  if (
    cleanPath === '' ||
    cleanPath === '/' ||
    cleanPath === '/checkout' ||
    cleanPath.endsWith('/checkout') ||
    cleanPath === '/account' ||
    cleanPath.endsWith('/account') ||
    cleanPath === '/customer-login' ||
    cleanPath.endsWith('/customer-login') ||
    cleanPath.startsWith('/product/') ||
    cleanPath.includes('/product/')
  ) {
    try {
      window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'storefront');
      window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
    } catch {
      // Ignore storage errors
    }
    return 'storefront';
  }

  return 'not_found';
};

const detectInitialLandingProductId = (): string | null => {
  if (typeof window === 'undefined') return null;
  if (detectInitialStorefrontRouteMode() !== 'landing') return null;
  try {
    const fromHist = window.history.state?.landingProductId;
    if (typeof fromHist === 'string' && fromHist.trim() !== '') {
      return fromHist.trim();
    }
    const fromSession = window.sessionStorage.getItem(NAV_LANDING_PRODUCT_ID_KEY);
    if (fromSession && fromSession.trim() !== '') {
      return fromSession.trim();
    }
  } catch {
    // Ignore storage errors
  }
  return null;
};

const StorefrontLayout: React.FC = () => {
  const {
    isAuthenticated,
    language,
    setLanguage,
    currentBusiness,
    products,
    isServerHydrated
  } = useApp();

  const [routeMode, setRouteMode] = useState<'storefront' | 'erp' | 'landing' | 'not_found'>(
    detectInitialStorefrontRouteMode
  );
  const [activeLandingProductId, setActiveLandingProductId] = useState<string | null>(
    detectInitialLandingProductId
  );

  useEffect(() => {
    if (language !== 'bn') {
      setLanguage('bn');
    }
  }, [language, setLanguage]);

  // If the customer bundle ever hits the /smart admin route, redirect so the server loads the full Admin bundle
  useEffect(() => {
    if (routeMode === 'erp' && typeof window !== 'undefined') {
      window.location.href = ADMIN_GATE_PATH + (window.location.search || '');
    }
  }, [routeMode]);

  useEffect(() => {
    try {
      if (routeMode !== 'not_found') {
        window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, routeMode);
      }
      if (routeMode === 'landing' && activeLandingProductId) {
        window.sessionStorage.setItem(NAV_LANDING_PRODUCT_ID_KEY, activeLandingProductId);
      } else {
        window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
      }
    } catch {
      // Ignore storage errors
    }
  }, [routeMode, activeLandingProductId]);

  const activeLandingProduct = useMemo<Product | null>(() => {
    if (typeof window !== 'undefined') {
      const fromUrl = findLandingProductFromUrl(
        products,
        window.location.pathname,
        window.location.search
      );
      if (fromUrl) return fromUrl;
    }
    if (activeLandingProductId) {
      const byId = products.find(p => p.id === activeLandingProductId);
      if (byId) return byId;
    }
    if (typeof window !== 'undefined') {
      const cleanPath = normalizeCleanPath(window.location.pathname);
      const hasExplicitLandingSlug =
        cleanPath.startsWith('/landing/') && cleanPath.slice('/landing/'.length).trim().length > 0;
      const params = new URLSearchParams(window.location.search);
      const hasExplicitLandingParam = Boolean((params.get('landing') || '').trim());
      if (hasExplicitLandingSlug || hasExplicitLandingParam) {
        return null;
      }
    }
    return products.find(p => p.isLandingPageProduct) || products[0] || null;
  }, [products, activeLandingProductId, routeMode]);

  useEffect(() => {
    captureAndPersistFbParams();
  }, [routeMode, activeLandingProductId]);

  useEffect(() => {
    if (currentBusiness) {
      initGoogleTagManager(currentBusiness);
      initFacebookPixel(currentBusiness).catch(() => {});
    }
  }, [
    currentBusiness?.gtmContainerId,
    currentBusiness?.gtmEnabled,
    currentBusiness?.gtmServerUrl,
    currentBusiness?.fbPixelId,
    currentBusiness?.fbTrackingEnabled
  ]);

  useEffect(() => {
    if (typeof document === 'undefined' || !currentBusiness) return;
    const storeName = currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট';
    const fav =
      currentBusiness.faviconUrl?.trim() ||
      currentBusiness.logoUrl?.trim() ||
      '';
    if (fav) {
      upsertFaviconLink(fav);
    }

    if (routeMode === 'landing' && activeLandingProduct) {
      document.title = `${activeLandingProduct.nameBn} | ${storeName}`;
    } else if (routeMode === 'not_found') {
      document.title = `পেজটি পাওয়া যায়নি (404) | ${storeName}`;
    }
  }, [
    routeMode,
    currentBusiness?.name,
    currentBusiness?.faviconUrl,
    currentBusiness?.logoUrl,
    activeLandingProduct
  ]);

  useEffect(() => {
    ensureCustomFontLoaded(currentBusiness?.banglaFont);
    ensureCustomFontLoaded(currentBusiness?.numberFontStyle);
    if (activeLandingProduct?.landingFontStyle) {
      ensureCustomFontLoaded(activeLandingProduct.landingFontStyle);
    }
  }, [
    currentBusiness?.banglaFont,
    currentBusiness?.numberFontStyle,
    activeLandingProduct?.landingFontStyle
  ]);

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      const urlBasedMode = detectInitialStorefrontRouteMode();
      if (urlBasedMode === 'erp') {
        window.location.href = ADMIN_GATE_PATH + (window.location.search || '');
        return;
      }
      if (urlBasedMode === 'storefront') {
        setActiveLandingProductId(null);
        setRouteMode('storefront');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      const state = event.state;
      if (state && state.routeMode === 'landing' && state.landingProductId) {
        setActiveLandingProductId(state.landingProductId);
      }
      setRouteMode(urlBasedMode);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const switchToStorefront = (targetUrl?: string) => {
    const safeUrl = typeof targetUrl === 'string' && targetUrl.trim() !== '' ? targetUrl.trim() : '/';
    try {
      window.sessionStorage.setItem(NAV_ROUTE_MODE_KEY, 'storefront');
      window.sessionStorage.removeItem(NAV_LANDING_PRODUCT_ID_KEY);
      window.history.pushState({ routeMode: 'storefront', view: 'home' }, '', safeUrl);
    } catch {
      // Ignore history errors
    }
    setActiveLandingProductId(null);
    setRouteMode('storefront');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const switchToErp = () => {
    if (typeof window !== 'undefined') {
      window.location.href = ADMIN_GATE_PATH;
    }
  };

  if (routeMode === 'not_found') {
    return <NotFoundView onGoToStorefront={switchToStorefront} />;
  }

  if (routeMode === 'landing') {
    if (!activeLandingProduct) {
      if (products.length > 0 && isServerHydrated) {
        return <NotFoundView onGoToStorefront={switchToStorefront} />;
      }
      return <GlobalSkeletonLoader variant="landing" />;
    }

    return (
      <Suspense fallback={<GlobalSkeletonLoader variant="landing" />}>
        <ProductLandingPageView
          key={activeLandingProduct.id}
          product={activeLandingProduct}
          onBackToAdmin={
            isAuthenticated
              ? () => {
                  window.location.href = `${ADMIN_GATE_PATH}?view=landing_pages`;
                }
              : undefined
          }
          onOpenStorefront={switchToStorefront}
        />
      </Suspense>
    );
  }

  if (typeof window !== 'undefined' && products.length > 0 && isServerHydrated) {
    const cleanPath = normalizeCleanPath(window.location.pathname);
    if (cleanPath.startsWith('/product/') || cleanPath.includes('/product/')) {
      const matchedProd = findProductFromLocation(
        products,
        window.location.pathname,
        window.location.search
      );
      if (!matchedProd) {
        return <NotFoundView onGoToStorefront={switchToStorefront} />;
      }
    }
  }

  return <EcommerceStorefrontView onNavigateToErp={switchToErp} />;
};

export default function StorefrontApp() {
  return (
    <AppProvider>
      <StorefrontLayout />
    </AppProvider>
  );
}
