import React from 'react';
import { createRoot } from 'react-dom/client';
import StorefrontApp from './StorefrontApp.tsx';
import './index.css';

declare global {
  interface Window {
    __STOCKMASTER_BOOTED__?: boolean;
  }
}

if (typeof window !== 'undefined') {
  window.__STOCKMASTER_BOOTED__ = true;

  if (typeof Node === 'function' && Node.prototype) {
    const originalRemoveChild = Node.prototype.removeChild;
    Node.prototype.removeChild = function <T extends Node>(child: T): T {
      if (child.parentNode !== this) {
        return child;
      }
      return originalRemoveChild.apply(this, arguments as unknown as [Node]) as T;
    };

    const originalInsertBefore = Node.prototype.insertBefore;
    Node.prototype.insertBefore = function <T extends Node>(newNode: T, referenceNode: Node | null): T {
      if (referenceNode && referenceNode.parentNode !== this) {
        return this.appendChild(newNode);
      }
      return originalInsertBefore.apply(this, arguments as unknown as [Node, Node | null]) as T;
    };
  }
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class StorefrontErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    const msg = String(error?.message || '').toLowerCase();
    if (msg.includes('removechild') || msg.includes('insertbefore')) {
      this.setState({ hasError: false });
    }
  }

  render() {
    if (this.state.hasError) {
      return <StorefrontApp />;
    }
    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <StorefrontErrorBoundary>
      <StorefrontApp />
    </StorefrontErrorBoundary>
  );
}
