import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  Language, 
  User, 
  UserRole,
  Business, 
  Outlet, 
  Category,
  Brand,
  Product, 
  Customer, 
  Supplier, 
  Sale, 
  SaleReturn,
  Purchase, 
  PurchaseReturn,
  Expense, 
  AccountLedger, 
  SalesRep, 
  StockTransfer, 
  StockAdjustment, 
  StockMovement,
  AuditLogEntry,
  CustomerLedgerEntry,
  DayEndClose, 
  SaleItem,
  PaymentMethod,
  OnlineOrder,
  OnlineOrderStatus,
  IncompleteOrder,
  IncompleteOrderStatus,
  DailyOrderLimitCheckResult
} from '../types';
import { translations } from '../i18n/translations';
import { API_CONFIG, generateIdempotencyKey } from '../config/api';
import {
  sendAlphaSms,
  sendBusinessSms,
  hasBusinessSmsConfigured,
  formatSmsMessage,
  DEFAULT_SMS_TEMPLATES
} from '../utils/smsService';
import { syncOrderToWordPress, buildVariantSkuCode } from '../utils/wordpressOrderSync';
import {
  trackFacebookEvent,
  buildMetaOrderItemsCustomData,
  generateMetaEventId,
  extractLocationForMeta,
  sha256SyncUtf8,
  sanitizeCustomerEventSourceUrl
} from '../utils/facebookTracking';
import { 
  initialBusinesses, 
  initialOutlets, 
  initialCategories,
  initialBrands,
  initialProducts, 
  initialCustomers, 
  initialSuppliers, 
  initialSalesReps, 
  initialAccounts, 
  initialSales, 
  initialPurchases, 
  initialExpenses, 
  initialUsers,
  initialOnlineOrders
} from '../data/initialData';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface HeldCart {
  id: string;
  customerName: string;
  items: SaleItem[];
  heldAt: string;
  note?: string;
}

export interface DeleteConfirmRequest {
  title?: string;
  itemName?: string;
  message?: string;
  confirmLabel?: string;
  onConfirm: () => void | Promise<void>;
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations['bn'];
  businesses: Business[];
  currentBusiness: Business;
  setCurrentBusinessId: (id: string) => void;
  updateBusiness: (updates: Partial<Business>) => void;
  outlets: Outlet[];
  currentOutlet: Outlet;
  setCurrentOutletId: (id: string) => void;
  addOutlet: (data: Omit<Outlet, 'id' | 'businessId'>) => Outlet;
  updateOutlet: (id: string, updates: Partial<Omit<Outlet, 'id' | 'businessId'>>) => void;
  deleteOutlet: (id: string) => void;
  users: User[];
  currentUser: User;
  setCurrentUserId: (id: string) => void;
  isAuthenticated: boolean;
  login: (identifier: string, password: string) => Promise<boolean>;
  quickLogin: (userId: string) => void;
  logout: () => void;
  addUser: (userData: Omit<User, 'id' | 'businessId'>) => void;
  updateUser: (id: string, updates: Partial<Omit<User, 'id' | 'businessId'>>) => void;
  deleteUser: (id: string) => void;
  categories: Category[];
  addCategory: (data: { nameBn: string; nameEn?: string; image?: string; showOnHome?: boolean }) => Category;
  updateCategory: (id: string, updates: Partial<Omit<Category, 'id'>>) => void;
  deleteCategory: (id: string) => void;
  brands: Brand[];
  addBrand: (data: { name: string; origin?: string }) => Brand;
  deleteBrand: (id: string) => void;
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  sales: Sale[];
  addSale: (saleData: Omit<Sale, 'id' | 'invoiceNo' | 'createdAt'>) => Promise<Sale>;
  onlineOrders: OnlineOrder[];
  placeOnlineOrder: (
    orderData: Omit<OnlineOrder, 'id' | 'orderNo' | 'invoiceNo' | 'createdAt' | 'orderStatus'>
  ) => Promise<OnlineOrder>;
  updateOnlineOrderStatus: (
    orderId: string,
    status: OnlineOrderStatus,
    paymentStatus?: 'unpaid' | 'paid'
  ) => Promise<void>;
  updateOnlineOrder: (
    orderId: string,
    updates: Partial<OnlineOrder>
  ) => void;
  checkDailyOrderLimit: (phone: string, productIds?: string[]) => DailyOrderLimitCheckResult;
  verifyDailyOrderLimitServer: (phone: string, productIds?: string[]) => Promise<DailyOrderLimitCheckResult>;
  incompleteOrders: IncompleteOrder[];
  upsertIncompleteOrder: (data: {
    sessionKey: string;
    customerName: string;
    customerPhone: string;
    deliveryArea: string;
    deliveryAddress: string;
    deliverySlot: string;
    items: SaleItem[];
    subtotal: number;
    deliveryCharge: number;
    grandTotal: number;
    fbLeadSent?: boolean;
    fbp?: string;
    fbc?: string;
    externalId?: string;
    clientIp?: string;
    clientUserAgent?: string;
    eventSourceUrl?: string;
    orderSource?: 'landing_page' | 'storefront';
    landingSlug?: string;
    notes?: string;
  }) => void;
  updateIncompleteOrderStatus: (id: string, status: IncompleteOrderStatus) => void;
  deleteIncompleteOrder: (id: string) => void;
  convertIncompleteToOrder: (id: string) => Promise<OnlineOrder | null>;
  saleReturns: SaleReturn[];
  addSaleReturn: (data: {
    saleId: string;
    productId: string;
    returnQty: number;
    refundMethod: 'cash_refund' | 'adjust_customer_due';
    reason: string;
  }) => Promise<void>;
  purchases: Purchase[];
  addPurchase: (purchaseData: Omit<Purchase, 'id' | 'poNumber' | 'receivedDate'>) => Promise<Purchase>;
  purchaseReturns: PurchaseReturn[];
  addPurchaseReturn: (data: {
    purchaseId: string;
    productId: string;
    returnQty: number;
    reason: string;
  }) => Promise<void>;
  customers: Customer[];
  customerLedger: CustomerLedgerEntry[];
  addCustomer: (customerData: Omit<Customer, 'id' | 'createdAt'>) => Promise<void>;
  updateCustomer: (id: string, updates: Partial<Customer>) => Promise<void>;
  registerOrUpdateOnlineCustomer: (data: {
    name: string;
    phone: string;
    address: string;
    password?: string;
  }) => Promise<Customer>;
  collectCustomerDue: (customerId: string, amount: number, method: PaymentMethod, note?: string) => Promise<void>;
  suppliers: Supplier[];
  addSupplier: (supplierData: Omit<Supplier, 'id'>) => Promise<void>;
  paySupplier: (supplierId: string, amount: number, method: PaymentMethod, note?: string) => Promise<void>;
  expenses: Expense[];
  addExpense: (expenseData: Omit<Expense, 'id'>) => Promise<void>;
  accounts: AccountLedger[];
  salesReps: SalesRep[];
  stockTransfers: StockTransfer[];
  addStockTransfer: (transfer: Omit<StockTransfer, 'id' | 'transferNo' | 'date'>) => Promise<void>;
  stockAdjustments: StockAdjustment[];
  addStockAdjustment: (adj: Omit<StockAdjustment, 'id' | 'date'>) => Promise<void>;
  stockMovements: StockMovement[];
  auditLogs: AuditLogEntry[];
  dayEndClosures: DayEndClose[];
  closeDayEnd: (data: Omit<DayEndClose, 'id' | 'date'>) => Promise<DayEndClose>;
  heldCarts: HeldCart[];
  holdCart: (items: SaleItem[], customerName: string) => void;
  restoreHeldCart: (id: string) => SaleItem[];
  removeHeldCart: (id: string) => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  globalSearch: string;
  setGlobalSearch: (q: string) => void;
  dateRange: 'today' | 'this_week' | 'this_month' | 'all';
  setDateRange: (range: 'today' | 'this_week' | 'this_month' | 'all') => void;
  formatCurrency: (amount: number) => string;
  formatDate: (dateStr: string) => string;
  isServerHydrated: boolean;
  confirmDelete: (req: DeleteConfirmRequest) => void;
  clearWebsiteCache: (
    mode: 'soft_clear' | 'hard_reload' | 'reset_storefront_cache'
  ) => Promise<{ cacheVersion?: string; opcacheCleared?: boolean }>;
}

const AppContext = createContext<AppContextType | null>(null);

export const DEFAULT_DAILY_ORDER_LIMIT_TITLE = 'অর্ডার লিমিট অতিক্রম করেছে!';
export const DEFAULT_DAILY_ORDER_LIMIT_MESSAGE =
  'দুঃখিত! আপনার মোবাইল নাম্বার বা ডিভাইস থেকে আজকের সর্বোচ্চ অর্ডারের সীমা পূর্ণ হয়েছে। জরুরি প্রয়োজনে আমাদের হেল্পলাইন নাম্বারে সরাসরি কল করুন।';

const VISITOR_DEVICE_ID_KEY = 'sm_visitor_device_id_v1';
const DAILY_DEVICE_ORDERS_KEY = 'sm_daily_device_orders_v1';

const getOrCreateClientDeviceId = (): string => {
  if (typeof window === 'undefined') return 'srv_dev';
  try {
    let existing = window.localStorage.getItem(VISITOR_DEVICE_ID_KEY);
    if (!existing || existing.trim().length < 6) {
      existing = `dev_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
      window.localStorage.setItem(VISITOR_DEVICE_ID_KEY, existing);
    }
    return existing;
  } catch {
    return ' browser_dev';
  }
};

// Build initial Stock Movements from seed products & transactions
const buildInitialStockMovements = (): StockMovement[] => {
  const list: StockMovement[] = [];
  initialProducts.slice(0, 6).forEach((p, idx) => {
    const qty = p.stockByOutlet['outlet_02'] || 100;
    list.push({
      id: `sm_init_${idx + 1}`,
      businessId: 'biz_01',
      outletId: 'outlet_02',
      outletName: 'তেজগাঁও সেন্ট্রাল ওয়্যারহাউজ (সেন্ট্রাল গুদাম)',
      productId: p.id,
      productName: p.nameBn,
      sku: p.sku,
      movementType: 'OPENING_STOCK',
      referenceNo: `OPN-2026-00${idx + 1}`,
      qtyIn: qty,
      qtyOut: 0,
      balanceAfter: qty,
      unitCost: p.purchasePrice,
      wacAfter: p.avgCost || p.purchasePrice,
      notes: 'প্রারম্ভিক ওপেনিং স্টক এন্ট্রি',
      createdBy: 'আলহাজ্ব মো: কামরুল হাসান',
      createdAt: '2026-10-01T09:00:00+06:00'
    });
  });
  return list;
};

// Build initial Customer Ledger from seed customers & sales so every customer has complete statement history
const buildInitialCustomerLedger = (): CustomerLedgerEntry[] => {
  const entries: CustomerLedgerEntry[] = [];

  initialCustomers.forEach((cust) => {
    const custSales = initialSales
      .filter((s) => s.customerId === cust.id)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));

    const salesNetDue = custSales.reduce((sum, s) => sum + (s.dueAmount || 0), 0);
    const openingDue = Math.max(0, Math.round(((cust.currentDue || 0) - salesNetDue) * 100) / 100);

    let runningBalance = 0;

    if (openingDue > 0) {
      runningBalance = openingDue;
      entries.push({
        id: `cled_opn_${cust.id}`,
        businessId: cust.businessId,
        customerId: cust.id,
        customerName: cust.name,
        entryType: 'OPENING_BALANCE',
        referenceNo: `OPN-${cust.id.toUpperCase()}`,
        description: 'প্রারম্ভিক বকেয়া জের (Opening Due Balance)',
        debit: openingDue,
        credit: 0,
        balanceAfter: runningBalance,
        createdBy: 'আলহাজ্ব মো: কামরুল হাসান',
        createdAt: `${cust.createdAt}T09:00:00+06:00`
      });
    }

    custSales.forEach((s) => {
      const paidPortion = Math.min(s.grandTotal, s.paidAmount);
      runningBalance = Math.round((runningBalance + (s.grandTotal - paidPortion)) * 100) / 100;
      entries.push({
        id: `cled_sale_${s.id}`,
        businessId: s.businessId,
        customerId: cust.id,
        customerName: cust.name,
        entryType: 'SALE_INVOICE',
        referenceNo: s.invoiceNo,
        description: `${s.channel === 'wholesale_distribution' ? 'পাইকারি চালান বিল' : 'পিওএস বিক্রয় বিল'} (${s.notes || 'পণ্য বিক্রয়'})`,
        debit: s.grandTotal,
        credit: paidPortion,
        balanceAfter: runningBalance,
        createdBy: s.cashierName,
        createdAt: s.createdAt
      });
    });
  });

  return entries.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
};

const initialAuditLogs: AuditLogEntry[] = [
  {
    id: 'aud_01',
    businessId: 'biz_01',
    userName: 'আলহাজ্ব মো: কামরুল হাসান',
    userRole: 'super_admin',
    action: 'SYSTEM_BOOT',
    entityType: 'SECURITY',
    entityRef: 'ORG-AMB',
    description: 'Initialized StockMaster BD Weighted Average Costing & Security Session Guard',
    ipAddress: '103.112.204.18',
    createdAt: '2026-10-20T09:00:00+06:00'
  },
  {
    id: 'aud_02',
    businessId: 'biz_01',
    userName: 'কাজী শাহেদ আলম (ম্যানেজার)',
    userRole: 'store_manager',
    action: 'CREATE_PURCHASE_GRN',
    entityType: 'PURCHASE',
    entityRef: 'PO-202610-091',
    description: 'Posted GRN PO-202610-091 (Teer Oil 5L x 100) — Updated WAC to ৳860.00',
    ipAddress: '103.112.204.18',
    createdAt: '2026-10-20T14:30:00+06:00'
  },
  {
    id: 'aud_03',
    businessId: 'biz_01',
    userName: 'মো: আব্দুল্লাহ (ক্যাশিয়ার-১)',
    userRole: 'cashier',
    action: 'CREATE_SALE',
    entityType: 'SALE',
    entityRef: 'AMB-POS-20261022-001',
    description: 'Posted POS Invoice AMB-POS-20261022-001 for ৳1,313.00 (Cash)',
    ipAddress: '103.112.204.18',
    createdAt: '2026-10-22T10:15:00+06:00'
  }
];

const ERP_STATE_STORAGE_KEY = 'stockmaster_bd_persistent_erp_v2';
const AUTH_SESSION_STORAGE_KEY = 'stockmaster_bd_auth_session_v2';
const DB_INSTANCE_STORAGE_KEY = 'stockmaster_bd_db_instance_v1';
const CLIENT_CACHE_VERSION_KEY = 'sm_client_cache_version_v1';

interface PersistedErpState {
  updatedAt: number;
  cacheVersion?: string;
  dbInstanceId?: string;
  _isAdminMutation?: boolean;
  businesses?: Business[];
  outlets?: Outlet[];
  categories?: Category[];
  brands?: Brand[];
  products: Product[];
  sales: Sale[];
  saleReturns: SaleReturn[];
  purchases: Purchase[];
  purchaseReturns: PurchaseReturn[];
  customers: Customer[];
  customerLedger: CustomerLedgerEntry[];
  suppliers: Supplier[];
  expenses: Expense[];
  accounts: AccountLedger[];
  stockTransfers: StockTransfer[];
  stockAdjustments: StockAdjustment[];
  stockMovements: StockMovement[];
  auditLogs: AuditLogEntry[];
  dayEndClosures: DayEndClose[];
  users: User[];
  heldCarts: HeldCart[];
  onlineOrders?: OnlineOrder[];
  incompleteOrders?: IncompleteOrder[];
  deletedIncompleteOrderIds?: string[];
  deletedProductIds?: string[];
}

interface PersistedAuthSession {
  language: Language;
  currentBusinessId: string;
  currentOutletId: string;
  currentUserId: string;
  isAuthenticated: boolean;
}

export const normalizeBdPhone = (raw: string): string => {
  if (!raw) return '';
  const banglaDigits = '০১২৩৪৫৬৭৮৯';
  const ascii = String(raw)
    .split('')
    .map(ch => {
      const idx = banglaDigits.indexOf(ch);
      return idx >= 0 ? String(idx) : ch;
    })
    .join('');
  let digits = ascii.replace(/\D/g, '');
  if (digits.startsWith('00880')) {
    digits = digits.slice(4);
  } else if (digits.startsWith('880')) {
    digits = digits.slice(2);
  } else if (digits.length === 12 && digits.startsWith('881')) {
    digits = `0${digits.slice(2)}`;
  }
  // If user entered 10 digits starting with 1 (e.g. 1712345678), prepend 0 -> 01712345678 (11 digits)
  if (digits.length === 10 && /^1[3-9]\d{8}$/.test(digits)) {
    return `0${digits}`;
  }
  // If user pasted extra trailing digits after a valid 11-digit 01XXXXXXXXX number, keep the 11 digits
  if (digits.length > 11 && /^01[3-9]/.test(digits)) {
    return digits.slice(0, 11);
  }
  return digits;
};

export const isValidBdPhone11 = (raw: string): boolean => {
  const norm = normalizeBdPhone(raw);
  return norm.length === 11 && /^01[3-9]\d{8}$/.test(norm);
};

const INCOMPLETE_STATUS_PRIORITY: Record<IncompleteOrderStatus, number> = {
  abandoned: 1,
  contacted: 2,
  ignored: 3,
  converted: 4
};

const mergeTwoIncompleteOrders = (a: IncompleteOrder, b: IncompleteOrder): IncompleteOrder => {
  const tA = Date.parse(String(a.updatedAt || a.createdAt || '')) || 0;
  const tB = Date.parse(String(b.updatedAt || b.createdAt || '')) || 0;
  const newer = tB >= tA ? b : a;
  const older = tB >= tA ? a : b;

  // Preserve higher status (e.g. 'contacted' or 'converted') if the two records belong to the same lead ID/session
  // or if timestamps are within 15 minutes (prevents visitor clock skew from reverting Admin's 'contacted' status)
  const sameLeadOrRecent =
    a.id === b.id ||
    (a.sessionKey && a.sessionKey === b.sessionKey) ||
    Math.abs(tB - tA) < 15 * 60 * 1000;

  let resolvedStatus = newer.status;
  if (
    sameLeadOrRecent &&
    (INCOMPLETE_STATUS_PRIORITY[older.status] || 0) > (INCOMPLETE_STATUS_PRIORITY[newer.status] || 0)
  ) {
    resolvedStatus = older.status;
  }

  const normPhone = normalizeBdPhone(newer.customerPhone || older.customerPhone);
  const newerName = (newer.customerName || '').trim();
  const olderName = (older.customerName || '').trim();
  const placeholderNames = new Set(['', 'অসম্পূর্ণ অর্ডার ক্রেতা', 'চেকআউট ভিজিটর (Lead)', 'নাম লেখেনি']);
  const resolvedName = !placeholderNames.has(newerName)
    ? newerName
    : !placeholderNames.has(olderName)
    ? olderName
    : newerName || olderName || 'অসম্পূর্ণ অর্ডার ক্রেতা';

  return {
    ...older,
    ...newer,
    customerName: resolvedName,
    customerPhone: normPhone,
    deliveryAddress: (newer.deliveryAddress || '').trim() || (older.deliveryAddress || '').trim(),
    status: resolvedStatus,
    convertedOrderNo: newer.convertedOrderNo || older.convertedOrderNo,
    updatedAt: tB >= tA ? b.updatedAt || b.createdAt : a.updatedAt || a.createdAt
  };
};

const mergeOnlineCustomersWithOrdersAndLocalAccounts = (
  savedCustomers?: Customer[],
  ordersList?: OnlineOrder[]
): Customer[] => {
  const rawBase = Array.isArray(savedCustomers) && savedCustomers.length > 0
    ? [...savedCustomers]
    : [...initialCustomers];

  // Clean out any legacy 10-digit incomplete checkout lead customers and normalize all phones to 11 digits
  const byPhoneOrId = new Map<string, Customer>();
  rawBase.forEach(c => {
    if (!c || typeof c !== 'object') return;
    const norm = normalizeBdPhone(c.phone);
    const isCheckoutLead =
      String(c.id || '').startsWith('cust_lead_') ||
      c.route === 'অনলাইন চেকআউট লিড' ||
      c.address === 'অসম্পূর্ণ চেকআউট';
    if (isCheckoutLead && !isValidBdPhone11(norm)) {
      return;
    }
    const cleanCust: Customer = {
      ...c,
      phone: norm.length === 11 ? norm : c.phone
    };
    const key = norm.length === 11 ? norm : c.id;
    const prev = byPhoneOrId.get(key);
    if (!prev) {
      byPhoneOrId.set(key, cleanCust);
    } else {
      byPhoneOrId.set(key, {
        ...prev,
        ...cleanCust,
        name:
          cleanCust.name && cleanCust.name !== 'চেকআউট ভিজিটর (Lead)'
            ? cleanCust.name
            : prev.name || cleanCust.name,
        address:
          cleanCust.address && cleanCust.address !== 'অসম্পূর্ণ চেকআউট'
            ? cleanCust.address
            : prev.address || cleanCust.address,
        password: cleanCust.password || prev.password
      });
    }
  });

  const base = Array.from(byPhoneOrId.values());

  // Ensure seed online customers from initialCustomers are present
  initialCustomers.forEach(seedCust => {
    const seedNorm = normalizeBdPhone(seedCust.phone);
    if (
      seedNorm.length === 11 &&
      !base.some(c => c.id === seedCust.id || normalizeBdPhone(c.phone) === seedNorm)
    ) {
      base.push({ ...seedCust, phone: seedNorm });
    }
  });

  // Migrate/merge any storefront customer accounts stored in localStorage
  if (typeof window !== 'undefined') {
    try {
      const rawSf = window.localStorage.getItem('stockmaster_storefront_customers_v1');
      if (rawSf) {
        const parsedSf = JSON.parse(rawSf);
        if (Array.isArray(parsedSf)) {
          parsedSf.forEach((acc: { id?: string; name?: string; phone?: string; address?: string; password?: string; createdAt?: string }) => {
            if (!acc || !acc.phone) return;
            const norm = normalizeBdPhone(acc.phone);
            if (!isValidBdPhone11(norm)) return;
            const existingIdx = base.findIndex(c => normalizeBdPhone(c.phone) === norm);
            if (existingIdx >= 0) {
              const existing = base[existingIdx];
              base[existingIdx] = {
                ...existing,
                name: acc.name?.trim() || existing.name,
                phone: norm,
                address: acc.address?.trim() || existing.address,
                customerType: existing.customerType === 'wholesale' ? 'wholesale' : 'online',
                isOnlineCustomer: true,
                password: acc.password || existing.password
              };
            } else {
              base.unshift({
                id: acc.id || `cust_online_${norm}`,
                businessId: 'biz_01',
                name: (acc.name || 'অনলাইন ক্রেতা').trim(),
                phone: norm,
                address: (acc.address || 'হোম ডেলিভারি').trim(),
                route: 'হোম ডেলিভারি (অনলাইন)',
                customerType: 'online',
                isOnlineCustomer: true,
                password: acc.password || '',
                creditLimit: 0,
                currentDue: 0,
                createdAt: (acc.createdAt || new Date().toISOString()).slice(0, 10)
              });
            }
          });
        }
      }
    } catch {
      // Ignore storage read errors
    }
  }

  // Ensure every customer from onlineOrders is also registered as an Online Customer in the database
  const effectiveOrders = Array.isArray(ordersList) ? ordersList : initialOnlineOrders;
  effectiveOrders.forEach(ord => {
    const norm = normalizeBdPhone(ord.customerPhone);
    if (!isValidBdPhone11(norm)) return;
    const existingIdx = base.findIndex(c => normalizeBdPhone(c.phone) === norm);
    if (existingIdx >= 0) {
      base[existingIdx] = {
        ...base[existingIdx],
        phone: norm,
        isOnlineCustomer: true,
        customerType: base[existingIdx].customerType === 'wholesale' ? 'wholesale' : 'online',
        address: base[existingIdx].address || ord.deliveryAddress
      };
    } else {
      base.push({
        id: ord.customerId || `cust_online_${norm}`,
        businessId: ord.businessId || 'biz_01',
        name: ord.customerName || 'অনলাইন ক্রেতা',
        phone: norm,
        address: ord.deliveryAddress || 'হোম ডেলিভারি',
        route: ord.deliveryArea || 'হোম ডেলিভারি (অনলাইন)',
        customerType: 'online',
        isOnlineCustomer: true,
        creditLimit: 0,
        currentDue: 0,
        createdAt: (ord.createdAt || new Date().toISOString()).slice(0, 10)
      });
    }
  });

  return base;
};

const mergeAndRecoverIncompleteOrders = (
  localList?: IncompleteOrder[],
  serverList?: IncompleteOrder[],
  customersList?: Customer[],
  ordersList?: OnlineOrder[],
  productsList?: Product[],
  deletedIds?: string[]
): IncompleteOrder[] => {
  const deletedSet = new Set(Array.isArray(deletedIds) ? deletedIds : []);
  const combined = [
    ...(Array.isArray(serverList) ? serverList : []),
    ...(Array.isArray(localList) ? localList : [])
  ];

  // Step 1: Merge by sessionKey and strictly normalize phone numbers to 11 digits
  const bySession = new Map<string, IncompleteOrder>();
  combined.forEach(item => {
    if (!item || typeof item !== 'object') return;
    const id = String(item.id || '').trim();
    if (!id || deletedSet.has(id)) return;

    const normPhone = normalizeBdPhone(item.customerPhone);
    // Discard any partial/10-digit unnormalized phone numbers so only valid 11-digit BD numbers exist
    if (!isValidBdPhone11(normPhone)) return;

    const normalizedItem: IncompleteOrder = {
      ...item,
      customerPhone: normPhone
    };

    const sKey = String(item.sessionKey || id).trim() || id;
    const prev = bySession.get(sKey);
    if (!prev) {
      bySession.set(sKey, normalizedItem);
    } else {
      bySession.set(sKey, mergeTwoIncompleteOrders(prev, normalizedItem));
    }
  });

  // Step 2: Deduplicate by normalized 11-digit phone number so the same customer phone never creates duplicate rows
  const byPhone = new Map<string, IncompleteOrder>();
  Array.from(bySession.values()).forEach(item => {
    if (deletedSet.has(item.id)) return;
    const normPhone = normalizeBdPhone(item.customerPhone);
    if (!isValidBdPhone11(normPhone)) return;
    const prev = byPhone.get(normPhone);
    if (!prev) {
      byPhone.set(normPhone, item);
    } else {
      byPhone.set(normPhone, mergeTwoIncompleteOrders(prev, item));
    }
  });

  const mergedList = Array.from(byPhone.values()).filter(it => !deletedSet.has(it.id));

  // Step 3: Automatically recover any valid 11-digit checkout leads from `customers` if missing from `incompleteOrders`
  const effectiveCustomers = Array.isArray(customersList) ? customersList : [];
  const effectiveOrders = Array.isArray(ordersList) ? ordersList : [];
  const effectiveProducts =
    Array.isArray(productsList) && productsList.length > 0 ? productsList : initialProducts;
  const defaultProduct =
    effectiveProducts.find(p => p.isLandingPageProduct) || effectiveProducts[0];

  effectiveCustomers.forEach(cust => {
    if (!cust) return;
    const isCheckoutLead =
      String(cust.id || '').startsWith('cust_lead_') ||
      cust.route === 'অনলাইন চেকআউট লিড' ||
      cust.address === 'অসম্পূর্ণ চেকআউট';
    if (!isCheckoutLead) return;

    const normPhone = normalizeBdPhone(cust.phone);
    if (!isValidBdPhone11(normPhone)) return;

    const recId = `inc_rec_${cust.id}`;
    if (deletedSet.has(recId)) return;

    const alreadyInIncomplete = mergedList.some(
      inc => inc.id === recId || normalizeBdPhone(inc.customerPhone) === normPhone
    );
    if (alreadyInIncomplete) return;

    const alreadyOrdered = effectiveOrders.some(
      ord => normalizeBdPhone(ord.customerPhone) === normPhone
    );

    const activeVar = defaultProduct?.variants?.[0];
    const unitPrice = activeVar
      ? activeVar.retailPrice
      : defaultProduct?.retailPrice || 950;
    const costPrice = activeVar
      ? activeVar.purchasePrice
      : defaultProduct?.avgCost ?? defaultProduct?.purchasePrice ?? 600;
    const prodTitle = defaultProduct
      ? activeVar
        ? `${defaultProduct.nameBn} (${activeVar.label})`
        : defaultProduct.nameBn
      : 'অনলাইন চেকআউট পণ্য';

    const fallbackItem: SaleItem = {
      productId: defaultProduct?.id || 'prod_01',
      productName: prodTitle,
      productNameClean: defaultProduct?.nameBn || 'অনলাইন চেকআউট পণ্য',
      sku: activeVar?.sku || defaultProduct?.sku || 'WEB-ITEM',
      variantId: activeVar?.id,
      variantLabel: activeVar?.label,
      unit: activeVar?.label || defaultProduct?.unit || 'পিস',
      quantity: 1,
      unitPrice,
      costPrice,
      discount: 0,
      total: unitPrice
    };

    const deliveryFee = 60;
    const createdAtIso =
      cust.updatedAt ||
      (cust.createdAt ? `${cust.createdAt}T12:00:00.000Z` : new Date().toISOString());

    mergedList.push({
      id: recId,
      sessionKey: `rec_sess_${normPhone}`,
      businessId: cust.businessId || 'biz_01',
      customerName:
        cust.name && cust.name !== 'চেকআউট ভিজিটর (Lead)'
          ? cust.name
          : 'চেকআউট ভিজিটর (Lead)',
      customerPhone: normPhone,
      deliveryArea:
        cust.route && cust.route !== 'অনলাইন চেকআউট লিড'
          ? cust.route
          : 'ঢাকার ভিতরে (Inside Dhaka)',
      deliveryAddress:
        cust.address && cust.address !== 'অসম্পূর্ণ চেকআউট' ? cust.address : '',
      deliverySlot: 'হোম ডেলিভারি (চেকআউট লিড)',
      items: [fallbackItem],
      subtotal: unitPrice,
      deliveryCharge: deliveryFee,
      grandTotal: unitPrice + deliveryFee,
      status: alreadyOrdered ? 'converted' : 'abandoned',
      fbLeadSent: true,
      createdAt: createdAtIso,
      updatedAt: createdAtIso
    });
  });

  return mergedList
    .sort((a, b) =>
      String(b.updatedAt || b.createdAt || '').localeCompare(
        String(a.updatedAt || a.createdAt || '')
      )
    )
    .slice(0, 300);
};

const DEFAULT_USERNAMES_BY_ID: Record<string, string> = {
  user_01: 'admin',
  user_02: 'manager',
  user_03: 'cashier1',
  user_04: 'sr_tarek',
  user_05: 'dist_mgr',
  user_06: 'developer'
};

const normalizeUserObject = (u: User): User => {
  const defMatch = initialUsers.find(
    iu => iu.id === u.id || iu.email.toLowerCase() === (u.email || '').toLowerCase()
  );
  const fallbackUsername =
    defMatch?.username ||
    DEFAULT_USERNAMES_BY_ID[u.id] ||
    (u.email ? u.email.split('@')[0].toLowerCase() : u.id);
  const cleanUser: Record<string, any> = {
    ...u,
    username: (u.username || fallbackUsername).trim()
  };
  delete cleanUser.password;
  delete cleanUser.passwordHash;
  delete cleanUser.password_hash;
  return cleanUser as User;
};

const mergeDefaultUsers = (savedUsers?: User[]): User[] => {
  if (!Array.isArray(savedUsers) || savedUsers.length === 0) {
    return initialUsers.map(normalizeUserObject);
  }
  const merged = savedUsers.map(normalizeUserObject);
  initialUsers.forEach(defUser => {
    if (
      !merged.some(
        u =>
          u.id === defUser.id ||
          u.email.toLowerCase() === defUser.email.toLowerCase() ||
          (u.username && defUser.username && u.username.toLowerCase() === defUser.username.toLowerCase())
      )
    ) {
      merged.push(normalizeUserObject(defUser));
    }
  });
  return merged;
};

const DEFAULT_PRODUCT_VARIANTS: Record<string, Product['variants']> = Object.fromEntries(
  initialProducts.map(p => [p.id, p.variants || []])
);

const LEGACY_SEED_SKUS = new Set([
  'OIL-TEER-5L',
  'OIL-RUP-1L',
  'RICE-MINI-50KG',
  'RICE-NAZIR-25KG',
  'SALT-ACI-1KG',
  'MILK-DANO-1KG',
  'TEA-ISP-400G',
  'SPICE-RADH-TUR-200G',
  'SOAP-CHAKA-130G',
  'TISS-BASH-FACIAL',
  'SNK-PRAN-FROOTO-250',
  'SUGAR-FRESH-1KG',
  'DAL-MASOOR-1KG',
  'ATTA-BASH-2KG',
  'OIL-RADH-MUST-500ML',
  'SPICE-RADH-BEEF-100G',
  'BISC-PRAN-POTATA-100G',
  'BISC-TOAST-PREMIUM-350G',
  'DET-JET-1KG',
  'GHEE-PURE-400G',
  'FASH-PANJABI-01',
  'FASH-PANJABI-02',
  'FASH-POLO-03',
  'FASH-SHIRT-04',
  'FASH-SAREE-05',
  'FASH-3PCS-06',
  'FASH-JEANS-07',
  'FASH-PANT-08',
  'FASH-SHOE-09',
  'FASH-WATCH-10',
  'FASH-BAG-11',
  'FASH-KURTI-12',
  'FASH-TSHIRT-13',
  'FASH-SHOE-14',
  'FASH-PANJABI-15',
  'FASH-WALLET-16',
  'FASH-HOODIE-17',
  'FASH-ABAYA-18',
  'FASH-JOGGER-19',
  'FASH-SUNGLASS-20'
]);

const mergeDefaultCategories = (savedCategories?: Category[]): Category[] => {
  if (!Array.isArray(savedCategories) || savedCategories.length === 0) return initialCategories;
  const hasLegacyCat = savedCategories.some(
    c =>
      c &&
      (c.slug === 'edible-oil' ||
        c.slug === 'grains-staples' ||
        c.slug === 'mens-panjabi' ||
        String(c.nameBn || '').includes('ভোজ্যতেল'))
  );
  if (hasLegacyCat) {
    const customCats = savedCategories.filter(
      c => c && !/^cat_0[1-6]$/.test(String(c.id || ''))
    );
    return [...initialCategories, ...customCats];
  }
  return savedCategories.filter(Boolean);
};

const mergeDefaultBrands = (savedBrands?: Brand[]): Brand[] => {
  if (!Array.isArray(savedBrands) || savedBrands.length === 0) return initialBrands;
  const hasLegacyBrand = savedBrands.some(
    b =>
      b &&
      (String(b.name || '').includes('Teer') ||
        String(b.name || '').includes('Rupchanda') ||
        String(b.name || '').includes('Curren'))
  );
  if (hasLegacyBrand) {
    const customBrands = savedBrands.filter(
      b => b && !/^brand_0[1-8]$/.test(String(b.id || ''))
    );
    return [...initialBrands, ...customBrands];
  }
  return savedBrands.filter(Boolean);
};

const mergeDefaultProducts = (
  savedProducts?: Product[],
  deletedIds?: string[],
  isAuthoritativeServerList = false
): Product[] => {
  const deletedSet = new Set(Array.isArray(deletedIds) ? deletedIds.map(String) : []);

  if (!Array.isArray(savedProducts)) {
    return initialProducts
      .filter(p => !deletedSet.has(p.id))
      .map(p => ({
        ...p,
        avgCost: p.avgCost ?? p.purchasePrice,
        variants: p.variants || DEFAULT_PRODUCT_VARIANTS[p.id] || []
      }));
  }

  if (savedProducts.length === 0) {
    if (isAuthoritativeServerList || deletedSet.size > 0) {
      return [];
    }
    return initialProducts.map(p => ({
      ...p,
      avgCost: p.avgCost ?? p.purchasePrice,
      variants: p.variants || DEFAULT_PRODUCT_VARIANTS[p.id] || []
    }));
  }

  // If the stored list still has the old 20-item seed catalog or grocery seed catalog, replace seed items with our clean 10-item Baby Dress & Fashion catalog while keeping any user-added products
  const hasLegacySeed = savedProducts.some(p => p && LEGACY_SEED_SKUS.has(p.sku));
  if (hasLegacySeed) {
    const customUserProducts = savedProducts.filter(
      p => p && !/^prod_(0[1-9]|1[0-9]|20)$/.test(p.id) && !LEGACY_SEED_SKUS.has(p.sku) && !deletedSet.has(p.id)
    );
    return [
      ...initialProducts
        .filter(ip => !deletedSet.has(ip.id))
        .map(ip => {
          const prev = savedProducts.find(sp => sp.id === ip.id);
          return {
            ...ip,
            image: prev?.image || ip.image,
            avgCost: ip.purchasePrice,
            variants: ip.variants || DEFAULT_PRODUCT_VARIANTS[ip.id] || []
          };
        }),
      ...customUserProducts
    ];
  }

  const normalizedSaved = savedProducts
    .filter(p => p && p.id && !deletedSet.has(String(p.id)))
    .map(p => ({
      ...p,
      avgCost: p.avgCost ?? p.purchasePrice,
      variants:
        Array.isArray(p.variants) && p.variants.length > 0
          ? p.variants
          : DEFAULT_PRODUCT_VARIANTS[p.id] || []
    }));

  // Do not force-inject seed landing products when the list comes authoritatively from the MySQL server
  if (isAuthoritativeServerList) {
    return normalizedSaved;
  }

  const missingSeedLandingProducts = initialProducts.filter(
    p =>
      p.isLandingPageProduct &&
      !deletedSet.has(p.id) &&
      !normalizedSaved.some(sp => sp.id === p.id)
  );
  if (missingSeedLandingProducts.length > 0) {
    return [...normalizedSaved, ...missingSeedLandingProducts];
  }

  return normalizedSaved;
};

const mergeProductReviewItems = (
  localReviews?: Product['landingReviewItems'],
  serverReviews?: Product['landingReviewItems']
): Product['landingReviewItems'] => {
  const a = Array.isArray(localReviews) ? localReviews : [];
  const b = Array.isArray(serverReviews) ? serverReviews : [];
  if (a.length === 0 && b.length === 0) return undefined;
  const map = new Map<string, NonNullable<Product['landingReviewItems']>[number]>();
  for (const r of [...b, ...a]) {
    if (!r || !r.id) continue;
    const prev = map.get(r.id);
    if (!prev) {
      map.set(r.id, r);
    } else {
      map.set(r.id, {
        ...prev,
        ...r,
        status: prev.status === 'approved' || r.status === 'approved' ? 'approved' : r.status || prev.status
      });
    }
  }
  return Array.from(map.values());
};

const mergeProductsSmart = (
  localProducts: Product[],
  serverProducts?: Product[],
  deletedIds?: string[],
  preferServerOnTie = false,
  serverIsAuthoritative = false
): Product[] => {
  const deletedSet = new Set(Array.isArray(deletedIds) ? deletedIds.map(String) : []);
  const cleanLocal = mergeDefaultProducts(localProducts, deletedIds, false).filter(
    p => p && !deletedSet.has(String(p.id))
  );
  if (!Array.isArray(serverProducts)) {
    return cleanLocal;
  }

  const cleanServer = mergeDefaultProducts(serverProducts, deletedIds, true).filter(
    p => p && !deletedSet.has(String(p.id))
  );

  // When MySQL server is authoritative (e.g. initial hydration, new database connected, or server timestamp is newer),
  // ONLY products present in serverProducts are kept — preventing browser localStorage from resurrecting old/deleted products!
  if (serverIsAuthoritative) {
    const localById = new Map<string, Product>();
    for (const lp of cleanLocal) {
      if (lp?.id) localById.set(String(lp.id), lp);
    }
    return cleanServer.map(sp => {
      const existing = localById.get(String(sp.id));
      if (!existing) return sp;
      const mergedReviews = mergeProductReviewItems(existing.landingReviewItems, sp.landingReviewItems);
      return {
        ...existing,
        ...sp,
        ...(mergedReviews ? { landingReviewItems: mergedReviews } : {})
      };
    });
  }

  if (cleanServer.length === 0) {
    return cleanLocal;
  }

  const byId = new Map<string, Product>();
  const orderedIds: string[] = [];

  for (const lp of cleanLocal) {
    if (!lp?.id || deletedSet.has(lp.id)) continue;
    byId.set(lp.id, lp);
    orderedIds.push(lp.id);
  }

  for (const sp of cleanServer) {
    if (!sp?.id || deletedSet.has(sp.id)) continue;
    const existing = byId.get(sp.id);
    if (!existing) {
      byId.set(sp.id, sp);
      orderedIds.push(sp.id);
    } else {
      const tLocal = Date.parse(String(existing.updatedAt || existing.createdAt || '')) || 0;
      const tServer = Date.parse(String(sp.updatedAt || sp.createdAt || '')) || 0;

      let primary: Product;
      let secondary: Product;
      if (tServer > tLocal) {
        primary = sp;
        secondary = existing;
      } else if (tLocal > tServer) {
        primary = existing;
        secondary = sp;
      } else {
        primary = preferServerOnTie ? sp : existing;
        secondary = preferServerOnTie ? existing : sp;
      }

      const mergedReviews = mergeProductReviewItems(existing.landingReviewItems, sp.landingReviewItems);
      byId.set(sp.id, {
        ...secondary,
        ...primary,
        ...(mergedReviews ? { landingReviewItems: mergedReviews } : {})
      });
    }
  }

  return orderedIds.map(id => byId.get(id)!).filter(Boolean);
};

const loadPersistedErpState = (): Partial<PersistedErpState> | null => {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(ERP_STATE_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed;
  } catch {
    return null;
  }
};

const loadPersistedAuthSession = (): Partial<PersistedAuthSession> | null => {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(AUTH_SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed;
  } catch {
    return null;
  }
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initialSavedErp = useRef<Partial<PersistedErpState> | null>(loadPersistedErpState());
  const initialSavedAuth = useRef<Partial<PersistedAuthSession> | null>(loadPersistedAuthSession());
  const lastSavedAtRef = useRef<number>(initialSavedErp.current?.updatedAt || 0);
  const isHydratedFromServerRef = useRef<boolean>(false);
  const [isServerHydrated, setIsServerHydrated] = useState<boolean>(false);

  const [language, setLanguage] = useState<Language>(
    () => initialSavedAuth.current?.language || 'bn'
  );
  const t = translations[language];

  const [businesses, setBusinesses] = useState<Business[]>(() => {
    const savedBiz = initialSavedErp.current?.businesses;
    const base = Array.isArray(savedBiz) && savedBiz.length > 0 ? savedBiz.filter(Boolean) : initialBusinesses;
    return (base.length > 0 ? base : initialBusinesses).map(b => {
      const bName = String(b?.name || '');
      const bNameEn = String(b?.nameEn || '');
      const isLegacyDefaultName =
        b?.id === 'biz_01' &&
        (bName.includes('সুপার শপ') ||
          bNameEn.includes('Super Shop') ||
          bName.includes('আল-মদিনা') ||
          bNameEn.includes('Al-Madina'));
      return {
        ...initialBusinesses[0],
        ...b,
        logoUrl:
          b?.logoUrl === '/uploads/logos/kids_fashion_logo.svg' ||
          b?.logoUrl === '/uploads/logos/smart_look_animated_logo.svg' ||
          b?.logoUrl === '/uploads/logos/smart_look_animated_logo.svg?v=cb2'
            ? '/uploads/logos/smart_look_animated_logo.svg?v=cb3'
            : b?.logoUrl,
        name: isLegacyDefaultName
          ? 'কিডস অ্যান্ড ফ্যাশন মার্ট'
          : bName || initialBusinesses[0].name,
        nameEn: isLegacyDefaultName
          ? 'Kids & Fashion Mart'
          : bNameEn || initialBusinesses[0].nameEn,
        invoicePrefix:
          b.id === 'biz_01' && (b.invoicePrefix === 'AMB' || b.invoicePrefix === 'SMB' || b.invoicePrefix === 'AMF')
            ? 'KFM'
            : b.invoicePrefix,
        ecommerceDeliveryCharge: b.ecommerceDeliveryCharge ?? 60,
        freeDeliveryMinOrder: b.freeDeliveryMinOrder ?? 1500,
        wpSyncEnabled: b.wpSyncEnabled ?? true,
        banglaFont: 'noto_sans',
        storefrontTheme: b.storefrontTheme || 'emerald_default',
        numberFontStyle: b.numberFontStyle || 'jetbrains_mono',
        showProductSkuOnStorefront: b.showProductSkuOnStorefront ?? false,
        cartBorderBeamEnabled: b.cartBorderBeamEnabled ?? true,
        topAnnouncementEnabled: b.topAnnouncementEnabled ?? true,
        topAnnouncementText:
          b.topAnnouncementText !== undefined
            ? b.topAnnouncementText
            : '❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।',
        topAnnouncementSpeed: b.topAnnouncementSpeed || 'normal'
      };
    });
  });
  const [currentBusinessId, setCurrentBusinessId] = useState<string>(
    () => initialSavedAuth.current?.currentBusinessId || initialBusinesses[0].id
  );
  const currentBusiness = businesses.find(b => b.id === currentBusinessId) || businesses[0];

  // Dynamically apply the default Noto Sans Bengali font family, English Number/Price font & Separate Mobile/Computer Font Size Scales
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const numFontChoice = currentBusiness?.numberFontStyle || 'jetbrains_mono';

    const primaryEnglishFont =
      numFontChoice === 'outfit' ? "'Outfit'" : "'Plus Jakarta Sans'";

    const fontStack = `${primaryEnglishFont}, 'Noto Sans Bengali', sans-serif`;

    const monoStack =
      numFontChoice === 'outfit'
        ? "'Outfit', 'Plus Jakarta Sans', sans-serif"
        : numFontChoice === 'plus_jakarta_sans'
        ? "'Plus Jakarta Sans', sans-serif"
        : "'JetBrains Mono', monospace";

    document.documentElement.style.setProperty('--font-sans', fontStack);
    document.documentElement.style.setProperty('--font-mono', monoStack);
    document.documentElement.setAttribute('data-bangla-font', 'noto_sans');

    // Separate Mobile & Computer Font Size Scaling for Storefront & Landing Pages
    const sfMobileScale = Math.max(75, Math.min(140, Number(currentBusiness?.storefrontMobileFontSizeScale) || 100)) / 100;
    const sfDesktopScale = Math.max(75, Math.min(140, Number(currentBusiness?.storefrontDesktopFontSizeScale) || 100)) / 100;
    const lpMobileScale = Math.max(75, Math.min(140, Number(currentBusiness?.landingMobileFontSizeScale) || 100)) / 100;
    const lpDesktopScale = Math.max(75, Math.min(140, Number(currentBusiness?.landingDesktopFontSizeScale) || 100)) / 100;

    const homeTitleMobPx = Math.max(10, Math.min(22, Number(currentBusiness?.homeProductTitleMobilePx) || 13));
    const homeTitleDeskPx = Math.max(11, Math.min(24, Number(currentBusiness?.homeProductTitleDesktopPx) || 14));
    const homeTitleWeight = currentBusiness?.homeProductTitleExtraBold !== false ? '800' : '700';

    document.documentElement.style.setProperty('--sf-mobile-font-scale', String(sfMobileScale));
    document.documentElement.style.setProperty('--sf-desktop-font-scale', String(sfDesktopScale));
    document.documentElement.style.setProperty('--lp-mobile-font-scale', String(lpMobileScale));
    document.documentElement.style.setProperty('--lp-desktop-font-scale', String(lpDesktopScale));
    document.documentElement.style.setProperty('--home-prod-title-mobile-px', `${homeTitleMobPx}px`);
    document.documentElement.style.setProperty('--home-prod-title-desktop-px', `${homeTitleDeskPx}px`);
    document.documentElement.style.setProperty('--home-prod-title-weight', homeTitleWeight);

    // Sync active storefront theme & brand metadata to localStorage + CSS variables so initial boot loader matches 100%
    const isWinter =
      Boolean(currentBusiness?.winterThemeEnabled) ||
      currentBusiness?.storefrontTheme === 'winter_frost';
    const resolvedTheme = isWinter
      ? 'winter_frost'
      : currentBusiness?.storefrontTheme || 'emerald_default';
    document.documentElement.setAttribute('data-boot-theme', resolvedTheme);

    try {
      const bootMeta = {
        theme: resolvedTheme,
        shopName: currentBusiness?.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট',
        logoUrl: currentBusiness?.logoUrl || '',
        phone: currentBusiness?.phone || '',
        topBarEnabled: currentBusiness?.topAnnouncementEnabled !== false,
        topBarText:
          currentBusiness?.topAnnouncementText ??
          'সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে পেমেন্ট করুন'
      };
      window.localStorage.setItem('sm_boot_theme_meta_v1', JSON.stringify(bootMeta));
    } catch {
      // Ignore storage quota errors
    }
  }, [
    currentBusiness?.banglaFont,
    currentBusiness?.numberFontStyle,
    currentBusiness?.storefrontMobileFontSizeScale,
    currentBusiness?.storefrontDesktopFontSizeScale,
    currentBusiness?.landingMobileFontSizeScale,
    currentBusiness?.landingDesktopFontSizeScale,
    currentBusiness?.homeProductTitleMobilePx,
    currentBusiness?.homeProductTitleDesktopPx,
    currentBusiness?.homeProductTitleExtraBold,
    currentBusiness?.storefrontTheme,
    currentBusiness?.winterThemeEnabled,
    currentBusiness?.name,
    currentBusiness?.logoUrl,
    currentBusiness?.phone,
    currentBusiness?.topAnnouncementEnabled,
    currentBusiness?.topAnnouncementText
  ]);

  const [outlets, setOutlets] = useState<Outlet[]>(() => {
    const savedOutlets = initialSavedErp.current?.outlets;
    return Array.isArray(savedOutlets) && savedOutlets.length > 0 ? savedOutlets : initialOutlets;
  });
  const businessOutlets = outlets.filter(o => o.businessId === currentBusiness.id);
  const [currentOutletId, setCurrentOutletId] = useState<string>(
    () => initialSavedAuth.current?.currentOutletId || businessOutlets[0]?.id || 'outlet_01'
  );
  const currentOutlet = businessOutlets.find(o => o.id === currentOutletId) || businessOutlets[0] || outlets[0] || initialOutlets[0];

  const [users, setUsers] = useState<User[]>(() => mergeDefaultUsers(initialSavedErp.current?.users));
  const [currentUserId, setCurrentUserId] = useState<string>(
    () => initialSavedAuth.current?.currentUserId || 'user_01'
  );
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(
    () => Boolean(initialSavedAuth.current?.isAuthenticated)
  );
  const currentUser = users.find(u => u.id === currentUserId) || users[0];

  // Core Business Entities (Persisted in localStorage + Server Disk + MySQL Database)
  const [categories, setCategories] = useState<Category[]>(() =>
    mergeDefaultCategories(initialSavedErp.current?.categories)
  );
  const [brands, setBrands] = useState<Brand[]>(() =>
    mergeDefaultBrands(initialSavedErp.current?.brands)
  );
  const [products, setProducts] = useState<Product[]>(() =>
    mergeDefaultProducts(initialSavedErp.current?.products)
  );
  const [sales, setSales] = useState<Sale[]>(() =>
    Array.isArray(initialSavedErp.current?.sales) ? initialSavedErp.current!.sales : initialSales
  );
  const [onlineOrders, setOnlineOrders] = useState<OnlineOrder[]>(() =>
    Array.isArray(initialSavedErp.current?.onlineOrders)
      ? initialSavedErp.current!.onlineOrders!
      : initialOnlineOrders
  );
  const [deletedIncompleteOrderIds, setDeletedIncompleteOrderIds] = useState<string[]>(() =>
    Array.isArray(initialSavedErp.current?.deletedIncompleteOrderIds)
      ? initialSavedErp.current!.deletedIncompleteOrderIds!
      : []
  );
  const [deletedProductIds, setDeletedProductIds] = useState<string[]>(() =>
    Array.isArray(initialSavedErp.current?.deletedProductIds)
      ? initialSavedErp.current!.deletedProductIds!
      : []
  );
  const [incompleteOrders, setIncompleteOrders] = useState<IncompleteOrder[]>(() =>
    mergeAndRecoverIncompleteOrders(
      initialSavedErp.current?.incompleteOrders,
      [],
      initialSavedErp.current?.customers,
      initialSavedErp.current?.onlineOrders,
      initialSavedErp.current?.products,
      initialSavedErp.current?.deletedIncompleteOrderIds
    )
  );
  const [saleReturns, setSaleReturns] = useState<SaleReturn[]>(() =>
    Array.isArray(initialSavedErp.current?.saleReturns) ? initialSavedErp.current!.saleReturns : []
  );
  const [purchases, setPurchases] = useState<Purchase[]>(() =>
    Array.isArray(initialSavedErp.current?.purchases) ? initialSavedErp.current!.purchases : initialPurchases
  );
  const [purchaseReturns, setPurchaseReturns] = useState<PurchaseReturn[]>(() =>
    Array.isArray(initialSavedErp.current?.purchaseReturns) ? initialSavedErp.current!.purchaseReturns : []
  );
  const [customers, setCustomers] = useState<Customer[]>(() =>
    mergeOnlineCustomersWithOrdersAndLocalAccounts(
      initialSavedErp.current?.customers,
      initialSavedErp.current?.onlineOrders
    )
  );
  const [customerLedger, setCustomerLedger] = useState<CustomerLedgerEntry[]>(() =>
    Array.isArray(initialSavedErp.current?.customerLedger)
      ? initialSavedErp.current!.customerLedger
      : buildInitialCustomerLedger()
  );
  const [suppliers, setSuppliers] = useState<Supplier[]>(() =>
    Array.isArray(initialSavedErp.current?.suppliers) ? initialSavedErp.current!.suppliers : initialSuppliers
  );
  const [expenses, setExpenses] = useState<Expense[]>(() =>
    Array.isArray(initialSavedErp.current?.expenses) ? initialSavedErp.current!.expenses : initialExpenses
  );
  const [accounts, setAccounts] = useState<AccountLedger[]>(() =>
    Array.isArray(initialSavedErp.current?.accounts) ? initialSavedErp.current!.accounts : initialAccounts
  );
  const [salesReps] = useState<SalesRep[]>(initialSalesReps);
  const [stockTransfers, setStockTransfers] = useState<StockTransfer[]>(() =>
    Array.isArray(initialSavedErp.current?.stockTransfers) ? initialSavedErp.current!.stockTransfers : []
  );
  const [stockAdjustments, setStockAdjustments] = useState<StockAdjustment[]>(() =>
    Array.isArray(initialSavedErp.current?.stockAdjustments) ? initialSavedErp.current!.stockAdjustments : []
  );
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() =>
    Array.isArray(initialSavedErp.current?.stockMovements)
      ? initialSavedErp.current!.stockMovements
      : buildInitialStockMovements()
  );
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() =>
    Array.isArray(initialSavedErp.current?.auditLogs) ? initialSavedErp.current!.auditLogs : initialAuditLogs
  );
  const [dayEndClosures, setDayEndClosures] = useState<DayEndClose[]>(() =>
    Array.isArray(initialSavedErp.current?.dayEndClosures) ? initialSavedErp.current!.dayEndClosures : []
  );
  const [heldCarts, setHeldCarts] = useState<HeldCart[]>(() =>
    Array.isArray(initialSavedErp.current?.heldCarts) ? initialSavedErp.current!.heldCarts : []
  );
  const [processedIdempotencyKeys, setProcessedIdempotencyKeys] = useState<Set<string>>(new Set());

  const [toasts, setToasts] = useState<Toast[]>([]);
  const [deleteConfirmModal, setDeleteConfirmModal] = useState<DeleteConfirmRequest | null>(null);
  const [isExecutingDelete, setIsExecutingDelete] = useState<boolean>(false);
  const [globalSearch, setGlobalSearch] = useState<string>('');
  const [dateRange, setDateRange] = useState<'today' | 'this_week' | 'this_month' | 'all'>('today');

  const confirmDelete = (req: DeleteConfirmRequest) => {
    setDeleteConfirmModal(req);
  };

  const getClientAdminTokenHeaders = (): Record<string, string> => {
    if (typeof window === 'undefined') return {};
    try {
      const tok = (window.localStorage.getItem('sm_admin_auth_token_v1') || '').trim();
      if (tok && tok.startsWith('sm_adm_')) {
        return {
          'X-Admin-Token': tok,
          'X-CSRF-Token': tok,
          Authorization: `Bearer ${tok}`
        };
      }
    } catch {
      // Ignore storage errors
    }
    return {};
  };

  // Persist Auth Session state separately so logout only clears session, NEVER business data
  useEffect(() => {
    try {
      const authSnapshot: PersistedAuthSession = {
        language,
        currentBusinessId,
        currentOutletId,
        currentUserId,
        isAuthenticated
      };
      window.localStorage.setItem(AUTH_SESSION_STORAGE_KEY, JSON.stringify(authSnapshot));
      if (!isAuthenticated) {
        window.localStorage.removeItem('sm_admin_auth_token_v1');
      } else {
        const existingTok = (window.localStorage.getItem('sm_admin_auth_token_v1') || '').trim();
        if (!existingTok.startsWith('sm_adm_')) {
          const syncPayload = JSON.stringify({
            userId: currentUserId,
            email: currentUser?.email || '',
            role: currentUser?.role || 'super_admin'
          });
          const sessionEndpoints = [
            './api/index.php?route=auth/session-token',
            '/api/index.php?route=auth/session-token',
            '/api/auth/session-token'
          ];
          (async () => {
            for (const ep of sessionEndpoints) {
              try {
                const r = await fetch(ep, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    'X-Admin-Session-Sync': '1',
                    ...getClientAdminTokenHeaders()
                  },
                  credentials: 'same-origin',
                  body: syncPayload
                });
                const d = await r.json().catch(() => null);
                if (r.ok && d && d.success && d.csrf_token) {
                  try {
                    window.localStorage.setItem('sm_admin_auth_token_v1', String(d.csrf_token));
                  } catch {
                    // Ignore
                  }
                  break;
                } else if (r.status === 401) {
                  // Legacy unverified local session without valid cookie or HMAC token -> require fresh login
                  setIsAuthenticated(false);
                  break;
                }
              } catch {
                // Try next endpoint
              }
            }
          })();
        }
      }
    } catch {
      // Ignore storage quota errors
    }
  }, [language, currentBusinessId, currentOutletId, currentUserId, isAuthenticated, currentUser?.email, currentUser?.role]);

  const preferredEndpointIdxRef = useRef<number>(-1);
  const lastProcessedServerStampRef = useRef<number>(-1);
  const lastProcessedLocalStampRef = useRef<number>(-1);

  const pendingUserPasswordsRef = useRef<Record<string, string>>({});

  // Helper to push state snapshot to cPanel PHP + MySQL API (/api/index.php?route=state & /api/state)
  const pushStateToServer = async (snapshot: PersistedErpState, useKeepAlive = false): Promise<boolean> => {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return false;
    }

    const pendingPasswords = { ...pendingUserPasswordsRef.current };
    const hasPendingPasswords = Object.keys(pendingPasswords).length > 0;
    const payloadToSend: PersistedErpState = hasPendingPasswords
      ? {
          ...snapshot,
          users: Array.isArray(snapshot.users)
            ? snapshot.users.map(u => {
                const cleanU = normalizeUserObject(u);
                const pendingPw = pendingPasswords[u.id];
                return pendingPw ? { ...cleanU, password: pendingPw } : cleanU;
              })
            : snapshot.users
        }
      : snapshot;

    const bodyStr = JSON.stringify(payloadToSend);
    const reqInit: RequestInit = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...getClientAdminTokenHeaders()
      },
      credentials: 'same-origin',
      cache: 'no-store',
      ...(useKeepAlive ? { keepalive: true } : {}),
      body: bodyStr
    };

    const pushEndpoints = [
      `./api/index.php?route=state`,
      `/api/index.php?route=state`,
      `${API_CONFIG.BASE_URL}/state`
    ];

    const pref = preferredEndpointIdxRef.current;
    const orderedIndices =
      pref >= 0 && pref < pushEndpoints.length
        ? [pref, ...[0, 1, 2].filter(i => i !== pref)]
        : [0, 1, 2];

    for (const idx of orderedIndices) {
      const url = pushEndpoints[idx];
      try {
        const res = await fetch(url, reqInit);
        if (res.ok) {
          const json = await res.json().catch(() => null);
          if (json && json.success === true) {
            preferredEndpointIdxRef.current = idx;
            if (hasPendingPasswords) {
              for (const uid of Object.keys(pendingPasswords)) {
                if (pendingUserPasswordsRef.current[uid] === pendingPasswords[uid]) {
                  delete pendingUserPasswordsRef.current[uid];
                }
              }
            }
            if (typeof json.updatedAt === 'number' && json.updatedAt > 0) {
              lastSavedAtRef.current = Math.max(lastSavedAtRef.current, json.updatedAt);
              lastProcessedLocalStampRef.current = lastSavedAtRef.current;
            }
            if (typeof json.dbInstanceId === 'string' && json.dbInstanceId.trim()) {
              currentDbInstanceIdRef.current = json.dbInstanceId.trim();
              try {
                window.localStorage.setItem(DB_INSTANCE_STORAGE_KEY, currentDbInstanceIdRef.current);
              } catch {
                // Ignore
              }
            }
            return true;
          }
        }
      } catch {
        // Try next endpoint
      }
    }

    return false;
  };

  // Helper to fetch authoritative state from cPanel PHP + MySQL API without caching (with 3.5s timeout guard)
  const fetchServerState = async (): Promise<Partial<PersistedErpState> | null> => {
    const cacheBuster = Date.now();
    const adminTokenHeaders = getClientAdminTokenHeaders();
    const hasValidAdminToken = Object.keys(adminTokenHeaders).length > 0;
    const isErpOrAdmin =
      Boolean(liveStateRef.current?.isAuthenticated) && hasValidAdminToken;
    const modeParam = isErpOrAdmin ? '' : '&mode=public';
    const endpoints = [
      `./api/index.php?route=state${modeParam}&_t=${cacheBuster}`,
      `/api/index.php?route=state${modeParam}&_t=${cacheBuster}`,
      `${API_CONFIG.BASE_URL}/state?${modeParam ? 'mode=public&' : ''}_t=${cacheBuster}`
    ];

    const pref = preferredEndpointIdxRef.current;
    const orderedIndices =
      pref >= 0 && pref < endpoints.length
        ? [pref, ...[0, 1, 2].filter(i => i !== pref)]
        : [0, 1, 2];

    for (const idx of orderedIndices) {
      const url = endpoints[idx];
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const timer = controller ? window.setTimeout(() => controller.abort(), 3500) : null;
      try {
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            ...(isErpOrAdmin ? adminTokenHeaders : {})
          },
          credentials: 'same-origin',
          cache: 'no-store',
          ...(controller ? { signal: controller.signal } : {})
        });
        if (timer !== null) window.clearTimeout(timer);
        if (response.ok) {
          const payload = await response.json().catch(() => null);
          if (
            payload &&
            payload.success === true &&
            payload.data &&
            typeof payload.data === 'object' &&
            !Array.isArray(payload.data)
          ) {
            preferredEndpointIdxRef.current = idx;
            return payload.data as Partial<PersistedErpState>;
          }
        }
      } catch {
        if (timer !== null) window.clearTimeout(timer);
        // Try next endpoint
      }
    }
    return null;
  };

  const isInitialMountRef = useRef<boolean>(true);
  const isApplyingServerStateRef = useRef<boolean>(false);
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);

  // Live reference to current React state so background polling and consecutive async calls never read stale closure state
  const liveStateRef = useRef({
    businesses,
    outlets,
    categories,
    brands,
    products,
    sales,
    onlineOrders,
    incompleteOrders,
    deletedIncompleteOrderIds,
    deletedProductIds,
    saleReturns,
    purchases,
    purchaseReturns,
    customers,
    customerLedger,
    suppliers,
    expenses,
    accounts,
    stockTransfers,
    stockAdjustments,
    stockMovements,
    auditLogs,
    dayEndClosures,
    users,
    heldCarts,
    isAuthenticated,
    language
  });
  liveStateRef.current = {
    businesses,
    outlets,
    categories,
    brands,
    products,
    sales,
    onlineOrders,
    incompleteOrders,
    deletedIncompleteOrderIds,
    deletedProductIds,
    saleReturns,
    purchases,
    purchaseReturns,
    customers,
    customerLedger,
    suppliers,
    expenses,
    accounts,
    stockTransfers,
    stockAdjustments,
    stockMovements,
    auditLogs,
    dayEndClosures,
    users,
    heldCarts,
    isAuthenticated,
    language
  };

  const currentDbInstanceIdRef = useRef<string>(
    typeof window !== 'undefined'
      ? window.localStorage.getItem(DB_INSTANCE_STORAGE_KEY) || initialSavedErp.current?.dbInstanceId || ''
      : ''
  );
  const visitorClientIpRef = useRef<string>('');
  const visitorIpHmacRef = useRef<string>('');
  const phoneHmacCacheRef = useRef<Record<string, string>>({});
  const todayOrderLocksRef = useRef<
    Array<{
      id: string;
      phone?: string;
      phoneHash?: string;
      phoneHmac?: string;
      ipHmac?: string;
      ipMatched?: boolean;
      clientDeviceId?: string;
      createdAt: string;
      orderStatus?: string;
      productIds?: string[];
    }>
  >([]);

  const buildSnapshot = (timestamp: number): PersistedErpState => {
    const cur = liveStateRef.current;
    return {
      updatedAt: timestamp,
      ...(currentDbInstanceIdRef.current ? { dbInstanceId: currentDbInstanceIdRef.current } : {}),
      _isAdminMutation: Boolean(cur.isAuthenticated),
      businesses: cur.businesses,
      outlets: cur.outlets,
      categories: cur.categories,
      brands: cur.brands,
      products: cur.products,
      sales: cur.sales,
      onlineOrders: cur.onlineOrders,
      incompleteOrders: cur.incompleteOrders,
      deletedIncompleteOrderIds: cur.deletedIncompleteOrderIds,
      deletedProductIds: cur.deletedProductIds,
      saleReturns: cur.saleReturns,
      purchases: cur.purchases,
      purchaseReturns: cur.purchaseReturns,
      customers: cur.customers,
      customerLedger: cur.customerLedger,
      suppliers: cur.suppliers,
      expenses: cur.expenses,
      accounts: cur.accounts,
      stockTransfers: cur.stockTransfers,
      stockAdjustments: cur.stockAdjustments,
      stockMovements: cur.stockMovements,
      auditLogs: cur.auditLogs,
      dayEndClosures: cur.dayEndClosures,
      users: cur.users.map(normalizeUserObject),
      heldCarts: cur.heldCarts
    };
  };

  const notifySameBrowserTabs = (timestamp: number) => {
    try {
      broadcastChannelRef.current?.postMessage({ type: 'ERP_STATE_UPDATED', updatedAt: timestamp });
    } catch {
      // Ignore BroadcastChannel errors
    }
  };

  const getIncompleteSignature = (list: IncompleteOrder[]): string =>
    list
      .map(
        i =>
          `${i.id}:${i.status}:${normalizeBdPhone(i.customerPhone)}:${i.customerName}:${i.deliveryAddress}:${i.grandTotal}:${i.updatedAt}`
      )
      .join('|');

  const getOnlineOrdersSignature = (list: OnlineOrder[]): string =>
    list
      .map(
        o =>
          `${o.id}:${o.orderNo}:${o.orderStatus}:${o.paymentStatus}:${o.courierProvider || ''}:${o.courierConsignmentId || ''}:${o.courierStatus || ''}:${normalizeBdPhone(o.customerPhone)}:${o.grandTotal}:${o.updatedAt || o.createdAt}`
      )
      .join('|');

  const mergeOnlineOrdersLists = (
    localOrders: OnlineOrder[],
    serverOrders?: OnlineOrder[],
    serverIsAuthoritative = false,
    deletedOrderIds: string[] = []
  ): OnlineOrder[] => {
    if (!Array.isArray(serverOrders)) return localOrders;
    const deletedSet = new Set(deletedOrderIds);

    // Even when serverIsAuthoritative is true, keep any local order placed in the last 2 minutes
    // so an in-flight GET poll can never wipe out a just-placed order.
    const recentCutoffMs = Date.now() - 120000;
    const recentLocalOrders = serverIsAuthoritative
      ? localOrders.filter(o => {
          if (!o || (o.id && deletedSet.has(String(o.id)))) return false;
          const ts = Date.parse(String(o.updatedAt || o.createdAt || '')) || 0;
          return ts >= recentCutoffMs;
        })
      : localOrders.filter(o => !o?.id || !deletedSet.has(String(o.id)));

    if (serverIsAuthoritative && recentLocalOrders.length === 0) {
      return serverOrders
        .filter(o => !o?.id || !deletedSet.has(String(o.id)))
        .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
    }

    const ordMap = new Map<string, OnlineOrder>();
    for (const ord of [...recentLocalOrders, ...serverOrders]) {
      if (!ord || typeof ord !== 'object') continue;
      if (ord.id && deletedSet.has(String(ord.id))) continue;
      const key = String(ord.id || ord.orderNo || '').trim();
      if (!key) continue;
      const normPhone = normalizeBdPhone(ord.customerPhone);
      const cleanOrd: OnlineOrder = {
        ...ord,
        customerPhone: isValidBdPhone11(normPhone) ? normPhone : ord.customerPhone
      };
      const prev = ordMap.get(key);
      if (!prev) {
        ordMap.set(key, cleanOrd);
      } else {
        const tPrev = Date.parse(String(prev.updatedAt || prev.createdAt || '')) || 0;
        const tNext = Date.parse(String(cleanOrd.updatedAt || cleanOrd.createdAt || '')) || 0;
        ordMap.set(key, tNext >= tPrev ? { ...prev, ...cleanOrd } : { ...cleanOrd, ...prev });
      }
    }
    return Array.from(ordMap.values()).sort((a, b) =>
      String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
    );
  };

  const syncStateFromServer = async (isCancelled?: () => boolean) => {
    try {
      const serverState = await fetchServerState();
      if (isCancelled?.() || !serverState) return;

      const cur = liveStateRef.current;
      const serverUpdatedAt = Number(serverState.updatedAt || 0);
      const localUpdatedAt = Number(lastSavedAtRef.current || 0);
      const isFirstHydration = !isHydratedFromServerRef.current;

      if (typeof (serverState as any).visitorIpHmac === 'string' && (serverState as any).visitorIpHmac.trim()) {
        visitorIpHmacRef.current = (serverState as any).visitorIpHmac.trim();
      }
      if (Array.isArray((serverState as any).todayOrderLocks)) {
        todayOrderLocksRef.current = (serverState as any).todayOrderLocks;
      }

      const incomingDbId = typeof serverState.dbInstanceId === 'string' ? serverState.dbInstanceId.trim() : '';
      const storedDbId = currentDbInstanceIdRef.current;
      const dbInstanceChanged = Boolean(incomingDbId && storedDbId && incomingDbId !== storedDbId);
      const isInitialDbBind = Boolean(incomingDbId && !storedDbId && serverUpdatedAt > 0);

      if (incomingDbId) {
        currentDbInstanceIdRef.current = incomingDbId;
        try {
          window.localStorage.setItem(DB_INSTANCE_STORAGE_KEY, incomingDbId);
        } catch {
          // Ignore storage error
        }
      }

      const incomingCacheVersion =
        typeof serverState.cacheVersion === 'string' ? serverState.cacheVersion.trim() : '';
      const storedCacheVersion =
        typeof window !== 'undefined'
          ? window.localStorage.getItem(CLIENT_CACHE_VERSION_KEY) || ''
          : '';
      const cacheVersionChanged = Boolean(
        incomingCacheVersion && incomingCacheVersion !== storedCacheVersion
      );

      if (cacheVersionChanged && typeof window !== 'undefined') {
        try {
          window.localStorage.setItem(CLIENT_CACHE_VERSION_KEY, incomingCacheVersion);
          window.localStorage.removeItem('sm_boot_theme_meta_v1');
        } catch {
          // Ignore storage error
        }
      }

      // Fast-path: If we have already hydrated and neither serverUpdatedAt nor localUpdatedAt has changed since last sync, skip O(N) merges
      if (
        !isFirstHydration &&
        !dbInstanceChanged &&
        !isInitialDbBind &&
        !cacheVersionChanged &&
        serverUpdatedAt > 0 &&
        serverUpdatedAt === lastProcessedServerStampRef.current &&
        localUpdatedAt === lastProcessedLocalStampRef.current
      ) {
        return;
      }

      // When a new MySQL database is connected, or on initial hydration from MySQL, or when cacheVersionChanged, or when serverUpdatedAt >= localUpdatedAt,
      // the MySQL database is 100% authoritative (never merge stale browser localStorage items back into the database!)
      const serverIsAuthoritative =
        dbInstanceChanged ||
        isInitialDbBind ||
        cacheVersionChanged ||
        (isFirstHydration && serverUpdatedAt > 0) ||
        serverUpdatedAt >= localUpdatedAt;

      const mergedDeletedIds = dbInstanceChanged
        ? Array.isArray(serverState.deletedIncompleteOrderIds)
          ? serverState.deletedIncompleteOrderIds
          : []
        : Array.from(
            new Set([
              ...cur.deletedIncompleteOrderIds,
              ...(Array.isArray(serverState.deletedIncompleteOrderIds)
                ? serverState.deletedIncompleteOrderIds
                : [])
            ])
          ).slice(-500);

      const mergedDeletedProductIds = dbInstanceChanged
        ? Array.isArray(serverState.deletedProductIds)
          ? serverState.deletedProductIds
          : []
        : Array.from(
            new Set([
              ...cur.deletedProductIds,
              ...(Array.isArray(serverState.deletedProductIds)
                ? serverState.deletedProductIds
                : [])
            ])
          ).slice(-500);

      const nextProds = mergeProductsSmart(
        dbInstanceChanged ? [] : cur.products,
        serverState.products,
        mergedDeletedProductIds,
        serverUpdatedAt >= localUpdatedAt,
        serverIsAuthoritative
      );

      const getProductsSignature = (list: Product[]): string =>
        list
          .map(
            p =>
              `${p.id}:${p.nameBn}:${p.retailPrice}:${p.wholesalePrice}:${p.purchasePrice}:${p.sku}:${p.stockByOutlet?.outlet_01 ?? 0}:${p.isLandingPageProduct ? 1 : 0}:${p.landingSlug || ''}:${p.updatedAt || ''}:${p.landingReviewItems?.length || 0}`
          )
          .join('|');
      const prodsChanged = getProductsSignature(nextProds) !== getProductsSignature(cur.products);

      const serverDeletedOrdIds = Array.isArray((serverState as any).deletedOnlineOrderIds)
        ? (serverState as any).deletedOnlineOrderIds
        : [];
      const nextOnlineOrders = mergeOnlineOrdersLists(
        dbInstanceChanged ? [] : cur.onlineOrders,
        serverState.onlineOrders,
        serverIsAuthoritative,
        serverDeletedOrdIds
      );

      let nextCustomers = dbInstanceChanged ? [] : cur.customers;
      if (Array.isArray(serverState.customers)) {
        const combinedCusts = [...serverState.customers];
        if (!serverIsAuthoritative) {
          cur.customers.forEach(localCust => {
            const localNorm = normalizeBdPhone(localCust.phone);
            const existingIdx = combinedCusts.findIndex(
              sc =>
                sc.id === localCust.id ||
                (localNorm.length === 11 && normalizeBdPhone(sc.phone) === localNorm)
            );
            if (existingIdx === -1) {
              combinedCusts.unshift(localCust);
            } else if (localCust.password && !combinedCusts[existingIdx].password) {
              combinedCusts[existingIdx] = {
                ...combinedCusts[existingIdx],
                password: localCust.password,
                isOnlineCustomer:
                  localCust.isOnlineCustomer || combinedCusts[existingIdx].isOnlineCustomer,
                customerType:
                  localCust.customerType === 'online'
                    ? 'online'
                    : combinedCusts[existingIdx].customerType
              };
            }
          });
        }
        nextCustomers = mergeOnlineCustomersWithOrdersAndLocalAccounts(
          combinedCusts,
          nextOnlineOrders
        );
      }

      const nextIncompleteOrders = mergeAndRecoverIncompleteOrders(
        serverIsAuthoritative ? [] : cur.incompleteOrders,
        serverState.incompleteOrders,
        nextCustomers,
        nextOnlineOrders,
        nextProds,
        mergedDeletedIds
      );

      const incChanged =
        getIncompleteSignature(nextIncompleteOrders) !==
        getIncompleteSignature(cur.incompleteOrders);
      const ordChanged =
        getOnlineOrdersSignature(nextOnlineOrders) !==
        getOnlineOrdersSignature(cur.onlineOrders);
      const deletedChanged =
        mergedDeletedIds.length !== cur.deletedIncompleteOrderIds.length ||
        mergedDeletedProductIds.length !== cur.deletedProductIds.length;

      // Detect newly arrived orders or abandoned leads to notify logged-in Admin in real time
      if (!isFirstHydration && !dbInstanceChanged && cur.isAuthenticated) {
        const prevOrderIds = new Set(cur.onlineOrders.map(o => o.id));
        const brandNewOrders = nextOnlineOrders.filter(o => !prevOrderIds.has(o.id));
        if (brandNewOrders.length > 0) {
          const latestOrd = brandNewOrders[0];
          showToast(
            cur.language === 'bn'
              ? `নতুন অনলাইন অর্ডার এসেছে: #${latestOrd.orderNo} (${latestOrd.customerName} · ${latestOrd.customerPhone})`
              : `New online order received: #${latestOrd.orderNo} (${latestOrd.customerPhone})`,
            'success'
          );
        } else {
          const prevIncPhones = new Set(
            cur.incompleteOrders.map(i => normalizeBdPhone(i.customerPhone))
          );
          const brandNewLeads = nextIncompleteOrders.filter(
            i =>
              i.status === 'abandoned' &&
              !prevIncPhones.has(normalizeBdPhone(i.customerPhone))
          );
          if (brandNewLeads.length > 0) {
            const latestLead = brandNewLeads[0];
            showToast(
              cur.language === 'bn'
                ? `নতুন অসম্পূর্ণ অর্ডার (Abandoned) এসেছে: ${latestLead.customerPhone}`
                : `New abandoned checkout captured: ${latestLead.customerPhone}`,
              'info'
            );
          }
        }
      }

      let nextBusinesses = Array.isArray(serverState.businesses) && serverState.businesses.length > 0
        ? [...serverState.businesses]
        : [...cur.businesses];
      let spinLeadsChanged = false;
      if (nextBusinesses.length > 0 && cur.businesses.length > 0) {
        const curBiz = cur.businesses[0];
        const srvBiz = (Array.isArray(serverState.businesses) && serverState.businesses[0]) ? serverState.businesses[0] : curBiz;
        const baseBiz = serverIsAuthoritative ? srvBiz : curBiz;

        const mergedDeletedSpinIds = dbInstanceChanged
          ? Array.isArray(srvBiz.deletedSpinLeadIds)
            ? srvBiz.deletedSpinLeadIds
            : []
          : Array.from(
              new Set([
                ...(Array.isArray(curBiz.deletedSpinLeadIds) ? curBiz.deletedSpinLeadIds : []),
                ...(Array.isArray(srvBiz.deletedSpinLeadIds) ? srvBiz.deletedSpinLeadIds : [])
              ])
            ).slice(-500);
        const deletedSpinSet = new Set(mergedDeletedSpinIds);

        const mergeSpinArray = (localArr: any[], serverArr: any[]) => {
          const map = new Map<string, any>();
          const sourceLocal = serverIsAuthoritative ? [] : localArr;
          for (const item of sourceLocal) {
            if (item && item.id && !deletedSpinSet.has(String(item.id))) {
              map.set(String(item.id), item);
            }
          }
          for (const item of serverArr) {
            if (item && item.id && !deletedSpinSet.has(String(item.id))) {
              const prev = map.get(String(item.id));
              if (!prev) {
                map.set(String(item.id), item);
              } else {
                map.set(String(item.id), {
                  ...prev,
                  ...item,
                  usedInOrder: Boolean(prev.usedInOrder || item.usedInOrder),
                  orderInvoiceNo: item.orderInvoiceNo || prev.orderInvoiceNo
                });
              }
            }
          }
          return Array.from(map.values())
            .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
            .slice(0, 500);
        };

        const curWebLeads = Array.isArray(curBiz.spinWheelLeads) ? curBiz.spinWheelLeads : [];
        const srvWebLeads = Array.isArray(srvBiz.spinWheelLeads) ? srvBiz.spinWheelLeads : [];
        const mergedWebLeads = mergeSpinArray(curWebLeads, srvWebLeads);

        const curLpLeads = Array.isArray(curBiz.landingSpinWheelLeads) ? curBiz.landingSpinWheelLeads : [];
        const srvLpLeads = Array.isArray(srvBiz.landingSpinWheelLeads) ? srvBiz.landingSpinWheelLeads : [];
        const mergedLpLeads = mergeSpinArray(curLpLeads, srvLpLeads);

        if (
          mergedWebLeads.length !== curWebLeads.length ||
          mergedLpLeads.length !== curLpLeads.length ||
          mergedDeletedSpinIds.length !== (curBiz.deletedSpinLeadIds?.length || 0)
        ) {
          spinLeadsChanged = true;
        }

        const isLegacySrvName =
          baseBiz.id === 'biz_01' &&
          (String(baseBiz.name || '').includes('সুপার শপ') ||
            String(baseBiz.nameEn || '').includes('Super Shop') ||
            String(baseBiz.name || '').includes('আল-মদিনা') ||
            String(baseBiz.nameEn || '').includes('Al-Madina'));

        const isPublicPayload = Boolean((serverState as any)._isPublicPayload);

        nextBusinesses[0] = {
          ...baseBiz,
          ...(isPublicPayload
            ? {
                smsApiKey: srvBiz.smsApiKey ?? curBiz.smsApiKey,
                greenwebToken: srvBiz.greenwebToken ?? curBiz.greenwebToken,
                steadfastApiKey: srvBiz.steadfastApiKey ?? curBiz.steadfastApiKey,
                steadfastSecretKey: srvBiz.steadfastSecretKey ?? curBiz.steadfastSecretKey,
                pathaoClientSecret: srvBiz.pathaoClientSecret ?? curBiz.pathaoClientSecret,
                pathaoPassword: srvBiz.pathaoPassword ?? curBiz.pathaoPassword,
                wpConsumerKey: srvBiz.wpConsumerKey ?? curBiz.wpConsumerKey,
                wpConsumerSecret: srvBiz.wpConsumerSecret ?? curBiz.wpConsumerSecret
              }
            : {}),
          name: isLegacySrvName ? 'কিডস অ্যান্ড ফ্যাশন মার্ট' : baseBiz.name,
          nameEn: isLegacySrvName ? 'Kids & Fashion Mart' : baseBiz.nameEn,
          invoicePrefix:
            baseBiz.id === 'biz_01' &&
            (baseBiz.invoicePrefix === 'AMB' || baseBiz.invoicePrefix === 'SMB' || baseBiz.invoicePrefix === 'AMF')
              ? 'KFM'
              : baseBiz.invoicePrefix,
          spinWheelLeads: mergedWebLeads,
          landingSpinWheelLeads: mergedLpLeads,
          deletedSpinLeadIds: mergedDeletedSpinIds
        };
      }

      const isPublicPayload = Boolean((serverState as any)._isPublicPayload);

      if (serverIsAuthoritative) {
        isApplyingServerStateRef.current = true;
        lastSavedAtRef.current = serverUpdatedAt > 0 ? serverUpdatedAt : localUpdatedAt;

        if (nextBusinesses.length > 0) {
          setBusinesses(nextBusinesses);
        }
        if (Array.isArray(serverState.outlets) && serverState.outlets.length > 0) {
          setOutlets(serverState.outlets);
        }
        if (Array.isArray(serverState.categories)) {
          setCategories(mergeDefaultCategories(serverState.categories));
        }
        if (Array.isArray(serverState.brands)) {
          setBrands(mergeDefaultBrands(serverState.brands));
        }
        setProducts(nextProds);
        setDeletedProductIds(mergedDeletedProductIds);

        if (!isPublicPayload) {
          if (Array.isArray(serverState.sales)) {
            setSales(serverState.sales);
          } else if (dbInstanceChanged) {
            setSales(initialSales);
          }
          setOnlineOrders(nextOnlineOrders);
          setDeletedIncompleteOrderIds(mergedDeletedIds);
          setCustomers(nextCustomers);
          setIncompleteOrders(nextIncompleteOrders);

          if (Array.isArray(serverState.saleReturns)) setSaleReturns(serverState.saleReturns);
          if (Array.isArray(serverState.purchases)) setPurchases(serverState.purchases);
          if (Array.isArray(serverState.purchaseReturns)) setPurchaseReturns(serverState.purchaseReturns);
          if (Array.isArray(serverState.customerLedger)) setCustomerLedger(serverState.customerLedger);
          if (Array.isArray(serverState.suppliers)) setSuppliers(serverState.suppliers);
          if (Array.isArray(serverState.expenses)) setExpenses(serverState.expenses);
          if (Array.isArray(serverState.accounts)) setAccounts(serverState.accounts);
          if (Array.isArray(serverState.stockTransfers)) setStockTransfers(serverState.stockTransfers);
          if (Array.isArray(serverState.stockAdjustments)) setStockAdjustments(serverState.stockAdjustments);
          if (Array.isArray(serverState.stockMovements)) setStockMovements(serverState.stockMovements);
          if (Array.isArray(serverState.auditLogs)) setAuditLogs(serverState.auditLogs);
          if (Array.isArray(serverState.dayEndClosures)) setDayEndClosures(serverState.dayEndClosures);
          if (Array.isArray(serverState.users)) setUsers(mergeDefaultUsers(serverState.users));
          if (Array.isArray(serverState.heldCarts)) setHeldCarts(serverState.heldCarts);
        }

        const mergedSnapshot = {
          ...(isPublicPayload ? buildSnapshot(serverUpdatedAt > 0 ? serverUpdatedAt : localUpdatedAt) : serverState),
          ...(incomingDbId ? { dbInstanceId: incomingDbId } : {}),
          ...(incomingCacheVersion ? { cacheVersion: incomingCacheVersion } : {}),
          updatedAt: serverUpdatedAt > 0 ? serverUpdatedAt : localUpdatedAt,
          businesses: nextBusinesses,
          products: nextProds,
          onlineOrders: isPublicPayload ? cur.onlineOrders : nextOnlineOrders,
          incompleteOrders: isPublicPayload ? cur.incompleteOrders : nextIncompleteOrders,
          customers: isPublicPayload ? cur.customers : nextCustomers,
          deletedIncompleteOrderIds: isPublicPayload ? cur.deletedIncompleteOrderIds : mergedDeletedIds,
          deletedProductIds: mergedDeletedProductIds
        };

        try {
          window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(mergedSnapshot));
        } catch {
          // Ignore storage quota errors
        }

        // If the MySQL database was just installed (no sales array saved in app_state_store yet), save the clean initial snapshot once
        if (!isPublicPayload && !Array.isArray(serverState.sales) && isFirstHydration) {
          await pushStateToServer({
            ...buildSnapshot(serverUpdatedAt || Date.now()),
            ...(incomingDbId ? { dbInstanceId: incomingDbId } : {}),
            businesses: nextBusinesses,
            categories: Array.isArray(serverState.categories) ? mergeDefaultCategories(serverState.categories) : cur.categories,
            brands: Array.isArray(serverState.brands) ? mergeDefaultBrands(serverState.brands) : cur.brands,
            products: nextProds,
            onlineOrders: nextOnlineOrders,
            incompleteOrders: nextIncompleteOrders,
            customers: nextCustomers,
            deletedIncompleteOrderIds: mergedDeletedIds,
            deletedProductIds: mergedDeletedProductIds,
            _isAdminMutation: true
          });
        }

        setTimeout(() => {
          isApplyingServerStateRef.current = false;
        }, 60);
      } else if (incChanged || ordChanged || deletedChanged || spinLeadsChanged || prodsChanged) {
        // Even if localUpdatedAt > serverUpdatedAt, apply any newly arrived orders, leads, or product updates
        isApplyingServerStateRef.current = true;
        if (prodsChanged) setProducts(nextProds);
        if (!isPublicPayload && ordChanged) setOnlineOrders(nextOnlineOrders);
        if (!isPublicPayload && incChanged) setIncompleteOrders(nextIncompleteOrders);
        if (deletedChanged) {
          if (!isPublicPayload) setDeletedIncompleteOrderIds(mergedDeletedIds);
          setDeletedProductIds(mergedDeletedProductIds);
        }
        if (spinLeadsChanged && nextBusinesses.length > 0) setBusinesses(nextBusinesses);
        if (!isPublicPayload) setCustomers(nextCustomers);
        setTimeout(() => {
          isApplyingServerStateRef.current = false;
        }, 60);
      } else if (localUpdatedAt > serverUpdatedAt && !isFirstHydration && cur.isAuthenticated) {
        const localSaved = loadPersistedErpState();
        if (localSaved) {
          await pushStateToServer({
            ...(localSaved as PersistedErpState),
            ...(incomingDbId ? { dbInstanceId: incomingDbId } : {}),
            _isAdminMutation: true,
            updatedAt: Math.max(Number(localSaved.updatedAt || 0), Date.now()),
            products: nextProds,
            deletedProductIds: mergedDeletedProductIds
          });
        }
      }
      lastProcessedServerStampRef.current = Math.max(serverUpdatedAt, lastSavedAtRef.current || 0);
      lastProcessedLocalStampRef.current = Number(lastSavedAtRef.current || 0);
    } finally {
      if (!isCancelled?.()) {
        isHydratedFromServerRef.current = true;
        setIsServerHydrated(prev => (prev ? prev : true));
      }
    }
  };

  // Hydrate from Server / MySQL Database on initial mount + Live Poll + Cross-Tab BroadcastChannel so Admin sees new Incomplete/Online Orders immediately without reloading
  useEffect(() => {
    let cancelled = false;
    // Guarantee UI hydration within 2s even if cPanel PHP / network is slow on first load
    const safetyHydrationTimer = window.setTimeout(() => {
      if (!cancelled) {
        isHydratedFromServerRef.current = true;
        setIsServerHydrated(prev => (prev ? prev : true));
      }
    }, 2000);

    syncStateFromServer(() => cancelled).finally(() => {
      window.clearTimeout(safetyHydrationTimer);
    });

    let lastVisitorPollAt = Date.now();
    const intervalId = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      const isAdminActive =
        Boolean(liveStateRef.current?.isAuthenticated) ||
        (typeof window !== 'undefined' &&
          (window.location.pathname.toLowerCase().includes('/smart') ||
            window.location.search.toLowerCase().includes('smart') ||
            window.sessionStorage.getItem('stockmaster_active_route_mode_v1') === 'erp'));
      if (isAdminActive) {
        // Real-time 4s polling exclusively for Admin Panel
        syncStateFromServer(() => cancelled);
      } else if (Date.now() - lastVisitorPollAt >= 45000) {
        // Lightweight 45s polling for Storefront / Landing Page visitors (saves 90%+ server CPU & mobile battery)
        lastVisitorPollAt = Date.now();
        syncStateFromServer(() => cancelled);
      }
    }, 4000);

    const handleFocusOrVisible = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        syncStateFromServer(() => cancelled);
      }
    };

    const handleStorageEvent = (e: StorageEvent) => {
      if (e.key === ERP_STATE_STORAGE_KEY && e.newValue) {
        syncStateFromServer(() => cancelled);
      }
    };

    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        const bc = new BroadcastChannel('stockmaster_erp_live_sync');
        broadcastChannelRef.current = bc;
        bc.onmessage = () => {
          syncStateFromServer(() => cancelled);
        };
      } catch {
        // Ignore if BroadcastChannel is blocked
      }
    }

    window.addEventListener('focus', handleFocusOrVisible);
    window.addEventListener('storage', handleStorageEvent);
    document.addEventListener('visibilitychange', handleFocusOrVisible);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
      window.removeEventListener('focus', handleFocusOrVisible);
      window.removeEventListener('storage', handleStorageEvent);
      document.removeEventListener('visibilitychange', handleFocusOrVisible);
      try {
        broadcastChannelRef.current?.close();
      } catch {
        // Ignore
      }
    };
  }, []);

  // Automatically persist all ERP & E-Commerce business data to localStorage & cPanel MySQL/Disk on any mutation (debounced to keep typing/scrolling at 60fps)
  useEffect(() => {
    if (isInitialMountRef.current) {
      isInitialMountRef.current = false;
      return;
    }

    if (isApplyingServerStateRef.current) {
      isApplyingServerStateRef.current = false;
      return;
    }

    // Never push local browser state before initial hydration from MySQL server completes
    if (!isHydratedFromServerRef.current) {
      return;
    }

    const now = Date.now();
    lastSavedAtRef.current = now;
    lastProcessedLocalStampRef.current = now;

    const persistTimer = window.setTimeout(() => {
      const snapshot = buildSnapshot(now);
      try {
        window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snapshot));
      } catch {
        // Ignore quota errors
      }
      notifySameBrowserTabs(now);
      pushStateToServer(snapshot);
    }, 120);

    return () => window.clearTimeout(persistTimer);
  }, [
    businesses,
    outlets,
    categories,
    brands,
    products,
    sales,
    onlineOrders,
    incompleteOrders,
    deletedIncompleteOrderIds,
    deletedProductIds,
    saleReturns,
    purchases,
    purchaseReturns,
    customers,
    customerLedger,
    suppliers,
    expenses,
    accounts,
    stockTransfers,
    stockAdjustments,
    stockMovements,
    dayEndClosures,
    users,
    heldCarts
  ]);

  // Keep boot preloader metadata (sm_boot_theme_meta_v1) in localStorage synced with currentBusiness logo & theme
  useEffect(() => {
    if (typeof window === 'undefined' || !currentBusiness) return;
    try {
      const isWinter =
        Boolean(currentBusiness.winterThemeEnabled) ||
        currentBusiness.storefrontTheme === 'winter_frost';
      const bootMeta = {
        theme: isWinter ? 'winter_frost' : currentBusiness.storefrontTheme || 'emerald_default',
        shopName: currentBusiness.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট',
        logoUrl: currentBusiness.logoUrl || '',
        topBarEnabled: currentBusiness.topAnnouncementEnabled !== false,
        topBarText:
          currentBusiness.topAnnouncementText ||
          'সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে পেমেন্ট করুন',
        preloaderEnabled: currentBusiness.preloaderEnabled !== false,
        preloaderShimmerEnabled: currentBusiness.preloaderShimmerEnabled !== false
      };
      window.localStorage.setItem('sm_boot_theme_meta_v1', JSON.stringify(bootMeta));
    } catch {
      // Ignore storage errors
    }
  }, [
    currentBusiness?.name,
    currentBusiness?.logoUrl,
    currentBusiness?.storefrontTheme,
    currentBusiness?.winterThemeEnabled,
    currentBusiness?.topAnnouncementEnabled,
    currentBusiness?.topAnnouncementText,
    currentBusiness?.preloaderEnabled,
    currentBusiness?.preloaderShimmerEnabled
  ]);

  const updateBusiness = (updates: Partial<Business>) => {
    setBusinesses(prev =>
      prev.map(b => {
        if (b.id !== currentBusiness.id) return b;
        const merged = { ...b, ...updates };
        if (typeof window !== 'undefined') {
          try {
            const isWinter =
              Boolean(merged.winterThemeEnabled) || merged.storefrontTheme === 'winter_frost';
            window.localStorage.setItem(
              'sm_boot_theme_meta_v1',
              JSON.stringify({
                theme: isWinter ? 'winter_frost' : merged.storefrontTheme || 'emerald_default',
                shopName: merged.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট',
                logoUrl: merged.logoUrl || '',
                topBarEnabled: merged.topAnnouncementEnabled !== false,
                topBarText:
                  merged.topAnnouncementText ||
                  'সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে পেমেন্ট করুন',
                preloaderEnabled: merged.preloaderEnabled !== false,
                preloaderShimmerEnabled: merged.preloaderShimmerEnabled !== false
              })
            );
          } catch {
            // Ignore storage errors
          }
        }
        return merged;
      })
    );
    recordAudit(
      'UPDATE_BUSINESS_SETTINGS',
      'SETTINGS',
      currentBusiness.id,
      `Updated store settings (Name/Logo/Delivery Charge/Font)`
    );
  };

  const addOutlet = (data: Omit<Outlet, 'id' | 'businessId'>): Outlet => {
    const newOutlet: Outlet = {
      id: `outlet_${Date.now()}`,
      businessId: currentBusiness.id,
      name: data.name.trim(),
      type: data.type,
      address: data.address.trim(),
      phone: data.phone.trim()
    };
    setOutlets(prev => [...prev, newOutlet]);
    setProducts(prev =>
      prev.map(p => ({
        ...p,
        stockByOutlet: {
          ...p.stockByOutlet,
          [newOutlet.id]: p.stockByOutlet[newOutlet.id] ?? 0
        }
      }))
    );
    recordAudit(
      'CREATE_OUTLET',
      'OUTLET',
      newOutlet.id,
      `Added new branch/warehouse: ${newOutlet.name} (${newOutlet.type})`
    );
    showToast(
      language === 'bn'
        ? `নতুন শাখা/গুদাম "${newOutlet.name}" সফলভাবে যুক্ত করা হয়েছে!`
        : `Branch/Warehouse "${newOutlet.name}" added!`
    );
    return newOutlet;
  };

  const updateOutlet = (id: string, updates: Partial<Omit<Outlet, 'id' | 'businessId'>>) => {
    setOutlets(prev =>
      prev.map(o => {
        if (o.id !== id) return o;
        return {
          ...o,
          ...updates,
          name: updates.name !== undefined ? updates.name.trim() : o.name,
          address: updates.address !== undefined ? updates.address.trim() : o.address,
          phone: updates.phone !== undefined ? updates.phone.trim() : o.phone
        };
      })
    );
    if (updates.name && updates.name.trim()) {
      const updatedName = updates.name.trim();
      setStockMovements(prev =>
        prev.map(sm => (sm.outletId === id ? { ...sm, outletName: updatedName } : sm))
      );
    }
    recordAudit(
      'UPDATE_OUTLET',
      'OUTLET',
      id,
      `Updated branch/warehouse details (${updates.name || id})`
    );
    showToast(
      language === 'bn'
        ? 'শাখা/গুদামের তথ্য সফলভাবে আপডেট করা হয়েছে!'
        : 'Branch/Warehouse updated successfully!'
    );
  };

  const deleteOutlet = (id: string) => {
    const bizOutlets = outlets.filter(o => o.businessId === currentBusiness.id);
    if (bizOutlets.length <= 1) {
      showToast(
        language === 'bn'
          ? 'কমপক্ষে একটি শাখা বা গুদাম থাকা আবশ্যক!'
          : 'At least one branch or warehouse must remain!',
        'error'
      );
      return;
    }
    const target = outlets.find(o => o.id === id);
    setDeleteConfirmModal({
      title: language === 'bn' ? 'শাখা / গুদাম ডিলিট নিশ্চিতকরণ' : 'Confirm Branch Deletion',
      itemName: target?.name || id,
      message:
        language === 'bn'
          ? `আপনি কি নিশ্চিতভাবে "${target?.name || ''}" শাখা বা গুদামটি স্থায়ীভাবে ডিলিট করতে চান?`
          : `Are you sure you want to delete branch "${target?.name || ''}"?`,
      onConfirm: () => {
        setOutlets(prev => prev.filter(o => o.id !== id));
        if (currentOutletId === id) {
          const fallback = bizOutlets.find(o => o.id !== id);
          if (fallback) {
            setCurrentOutletId(fallback.id);
          }
        }
        recordAudit(
          'DELETE_OUTLET',
          'OUTLET',
          id,
          `Deleted branch/warehouse: ${target?.name || id}`
        );
        showToast(
          language === 'bn'
            ? `শাখা/গুদাম "${target?.name || ''}" মুছে ফেলা হয়েছে`
            : 'Branch/Warehouse removed',
          'info'
        );
      }
    });
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 5);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(item => item.id !== id));
    }, 3800);
  };

  const recordAudit = (action: string, entityType: string, entityRef: string, description: string) => {
    const entry: AuditLogEntry = {
      id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      businessId: currentBusiness.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      action,
      entityType,
      entityRef,
      description,
      ipAddress: '103.112.204.18',
      createdAt: new Date().toISOString()
    };
    setAuditLogs(prev => [entry, ...prev]);
  };

  const login = async (identifier: string, password: string): Promise<boolean> => {
    const clean = identifier.trim().toLowerCase();
    const rawPassword = password.trim();
    if (!clean || !rawPassword) {
      showToast(
        language === 'bn'
          ? 'অনুগ্রহ করে ইউজারনেম অথবা ইমেইল এবং পাসওয়ার্ড দিন!'
          : 'Please enter your username or email and password!',
        'error'
      );
      return false;
    }

    // Strictly verify credentials on the Backend Server (never in client JS)
    const loginEndpoints = [
      `./api/index.php?route=auth/login`,
      `/api/index.php?route=auth/login`,
      `${API_CONFIG.BASE_URL}/auth/login`
    ];

    let serverAuthResult: any = null;
    let serverReachable = false;

    for (const url of loginEndpoints) {
      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          },
          credentials: 'same-origin',
          body: JSON.stringify({
            username: clean,
            password: rawPassword
          })
        });
        const json = await res.json().catch(() => null);
        if (json && typeof json === 'object') {
          serverReachable = true;
          serverAuthResult = json;
          break;
        }
      } catch {
        // Try next endpoint
      }
    }

    if (!serverReachable || !serverAuthResult || serverAuthResult.success !== true) {
      showToast(
        language === 'bn'
          ? 'ভুল ইউজারনেম/ইমেইল অথবা পাসওয়ার্ড! অনুগ্রহ করে সঠিক তথ্য প্রদান করুন।'
          : 'Invalid username/email or password!',
        'error'
      );
      return false;
    }

    const srvUser = serverAuthResult.user || {};
    const matchedUser =
      users.find(u => {
        const uname = (u.username || DEFAULT_USERNAMES_BY_ID[u.id] || '').trim().toLowerCase();
        const uemail = (u.email || '').trim().toLowerCase();
        return (
          (srvUser.id && String(u.id) === String(srvUser.id)) ||
          (uname !== '' && uname === clean) ||
          (uemail !== '' && uemail === clean)
        );
      }) ||
      normalizeUserObject({
        id: String(srvUser.id || 'user_01'),
        name: String(srvUser.name || srvUser.full_name || 'Admin'),
        username: String(srvUser.username || clean),
        email: String(srvUser.email || clean),
        phone: String(srvUser.phone || ''),
        role: (srvUser.role as UserRole) || 'super_admin',
        businessId: String(srvUser.businessId || currentBusiness.id),
        outletId: srvUser.outletId ? String(srvUser.outletId) : undefined
      });

    if (serverAuthResult.csrf_token && typeof window !== 'undefined') {
      try {
        window.localStorage.setItem('sm_admin_auth_token_v1', String(serverAuthResult.csrf_token));
      } catch {
        // Ignore storage error
      }
    }

    setCurrentUserId(matchedUser.id);
    if (matchedUser.outletId) {
      setCurrentOutletId(matchedUser.outletId);
    }
    setIsAuthenticated(true);
    liveStateRef.current.isAuthenticated = true;
    lastProcessedServerStampRef.current = -1;

    // Re-sync full ERP state with server on login so any new online orders or sales from other devices are loaded
    await syncStateFromServer();

    const entry: AuditLogEntry = {
      id: `aud_${Date.now()}`,
      businessId: currentBusiness.id,
      userName: matchedUser.name,
      userRole: matchedUser.role,
      action: 'USER_LOGIN',
      entityType: 'AUTH_SESSION',
      entityRef: matchedUser.email,
      description: `User logged in via Encrypted Server Session Auth (Role: ${matchedUser.role})`,
      ipAddress: '103.112.204.18',
      createdAt: new Date().toISOString()
    };
    setAuditLogs(prev => [entry, ...prev]);
    showToast(
      language === 'bn'
        ? `স্বাগতম, ${matchedUser.name}! সফলভাবে লগইন হয়েছে।`
        : `Welcome back, ${matchedUser.name}!`
    );
    return true;
  };

  const quickLogin = (userId: string) => {
    const target = users.find(u => u.id === userId);
    if (!target) return;

    // Strict security guard: Nobody except an already authenticated developer can access the developer account
    if (target.role === 'developer' && currentUser.role !== 'developer') {
      showToast(
        language === 'bn'
          ? 'অনুমোদিত নয়! এই অ্যাকাউন্টে প্রবেশের অনুমতি নেই।'
          : 'Unauthorized access!',
        'error'
      );
      return;
    }

    setCurrentUserId(target.id);
    if (target.outletId) {
      setCurrentOutletId(target.outletId);
    }
    setIsAuthenticated(true);
    syncStateFromServer();

    const entry: AuditLogEntry = {
      id: `aud_${Date.now()}`,
      businessId: currentBusiness.id,
      userName: target.name,
      userRole: target.role,
      action: 'USER_LOGIN',
      entityType: 'AUTH_SESSION',
      entityRef: target.email,
      description: `User logged in via Quick Role Session (Role: ${target.role})`,
      ipAddress: '103.112.204.18',
      createdAt: new Date().toISOString()
    };
    setAuditLogs(prev => [entry, ...prev]);
    showToast(
      language === 'bn'
        ? `${target.name} হিসেবে লগইন সম্পন্ন হয়েছে`
        : `Signed in as ${target.name}`
    );
  };

  const logout = () => {
    // Flush any active business state to localStorage & Server before ending auth session
    if (lastSavedAtRef.current > 0) {
      const currentSnapshot = buildSnapshot(lastSavedAtRef.current);
      try {
        window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(currentSnapshot));
      } catch {
        // Ignore
      }
      pushStateToServer(currentSnapshot, true);
    }

    let oldToken = '';
    try {
      oldToken = window.localStorage.getItem('sm_admin_auth_token_v1') || '';
      window.localStorage.removeItem('sm_admin_auth_token_v1');
    } catch {
      // Ignore
    }

    recordAudit('USER_LOGOUT', 'AUTH_SESSION', currentUser.email, `User ${currentUser.name} logged out and destroyed session`);
    const logoutHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(oldToken ? { 'X-Admin-Token': oldToken } : {})
    };
    fetch(`/api/index.php?route=auth/logout`, {
      method: 'POST',
      headers: logoutHeaders,
      credentials: 'same-origin'
    }).catch(() => {});
    fetch(`/api/auth/logout`, {
      method: 'POST',
      headers: logoutHeaders,
      credentials: 'same-origin'
    }).catch(() => {});
    setIsAuthenticated(false);
    showToast(
      language === 'bn'
        ? 'আপনি সফলভাবে লগআউট করেছেন (সকল ডাটা সুরক্ষিত আছে)'
        : 'You have been logged out safely (all data is saved)',
      'info'
    );
  };

  const addUser = (userData: Omit<User, 'id' | 'businessId'>) => {
    const cleanEmail = userData.email.trim();
    const fallbackUname = cleanEmail.split('@')[0].toLowerCase().replace(/[^a-z0-9_.-]/g, '') || `user_${Date.now()}`;
    const newId = `user_${Date.now()}`;
    const rawNewPassword = userData.password && userData.password.trim() !== '' ? userData.password.trim() : '';
    if (rawNewPassword) {
      pendingUserPasswordsRef.current[newId] = rawNewPassword;
    }
    const newUser: User = normalizeUserObject({
      ...userData,
      id: newId,
      businessId: currentBusiness.id,
      username: (userData.username || fallbackUname).trim(),
      email: cleanEmail
    });
    setUsers(prev => [...prev, newUser]);
    recordAudit('CREATE_USER', 'USER', newUser.email, `Created staff account ${newUser.name} (${newUser.username}) with role ${newUser.role}`);
    showToast(
      language === 'bn'
        ? `নতুন ইউজার "${newUser.name}" সফলভাবে তৈরি হয়েছে`
        : `Staff user "${newUser.name}" created`
    );
  };

  const updateUser = (id: string, updates: Partial<Omit<User, 'id' | 'businessId'>>) => {
    if (updates.password !== undefined && updates.password.trim() !== '') {
      pendingUserPasswordsRef.current[id] = updates.password.trim();
    }
    setUsers(prev =>
      prev.map(u => {
        if (u.id !== id) return u;
        return normalizeUserObject({
          ...u,
          ...updates,
          name: updates.name !== undefined ? updates.name.trim() : u.name,
          username: updates.username !== undefined ? updates.username.trim() : u.username,
          email: updates.email !== undefined ? updates.email.trim() : u.email,
          phone: updates.phone !== undefined ? updates.phone.trim() : u.phone
        });
      })
    );
    recordAudit('UPDATE_USER', 'USER', id, `Updated login credentials / profile for user ${id}`);
    showToast(
      language === 'bn'
        ? 'লগইন ইউজারনেম, ইমেইল ও পাসওয়ার্ড সফলভাবে আপডেট করা হয়েছে!'
        : 'User login details and password updated successfully!'
    );
  };

  const deleteUser = (id: string) => {
    const target = users.find(u => u.id === id);
    if (!target) return;
    if (target.id === currentUser.id) {
      showToast(
        language === 'bn'
          ? 'নিজের বর্তমান লগইনকৃত অ্যাকাউন্ট ডিলিট করা যাবে না!'
          : 'Cannot delete your currently logged-in account!',
        'error'
      );
      return;
    }
    setDeleteConfirmModal({
      title: language === 'bn' ? 'ইউজার অ্যাকাউন্ট ডিলিট নিশ্চিতকরণ' : 'Confirm User Deletion',
      itemName: `${target.name} (${target.email})`,
      message:
        language === 'bn'
          ? `আপনি কি নিশ্চিতভাবে "${target.name}" অ্যাকাউন্টটি ডিলিট করতে চান?`
          : `Are you sure you want to delete user account "${target.name}"?`,
      onConfirm: () => {
        setUsers(prev => prev.filter(u => u.id !== id));
        recordAudit('DELETE_USER', 'USER', target.email, `Deleted user account ${target.name}`);
        showToast(
          language === 'bn'
            ? `"${target.name}" অ্যাকাউন্টটি মুছে ফেলা হয়েছে`
            : `Account "${target.name}" removed`,
          'info'
        );
      }
    });
  };

  const formatCurrency = (amount: number): string => {
    const rounded = Math.round((amount || 0) * 100) / 100;
    const parts = rounded.toFixed(2).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return `৳${parts[0]}${parts[1] === '00' ? '' : '.' + parts[1]}`;
  };

  const formatDate = (dateStr: string): string => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      return `${day}-${month}-${year}`;
    } catch {
      return dateStr;
    }
  };

  const addProduct = async (productData: Omit<Product, 'id'>) => {
    const wac = productData.avgCost ?? productData.purchasePrice;
    const nowIso = new Date().toISOString();
    const newProduct: Product = {
      ...productData,
      avgCost: wac,
      id: `prod_${Date.now()}`,
      createdAt: nowIso,
      updatedAt: nowIso
    };
    setProducts(prev => [newProduct, ...prev]);

    const initialQty = newProduct.stockByOutlet[currentOutlet.id] || 0;
    if (initialQty > 0) {
      setStockMovements(prev => [
        {
          id: `sm_${Date.now()}`,
          businessId: currentBusiness.id,
          outletId: currentOutlet.id,
          outletName: currentOutlet.name,
          productId: newProduct.id,
          productName: newProduct.nameBn,
          sku: newProduct.sku,
          movementType: 'OPENING_STOCK',
          referenceNo: `OPN-${newProduct.sku}`,
          qtyIn: initialQty,
          qtyOut: 0,
          balanceAfter: initialQty,
          unitCost: newProduct.purchasePrice,
          wacAfter: wac,
          notes: 'নতুন পণ্যের প্রারম্ভিক স্টক (Opening Stock)',
          createdBy: currentUser.name,
          createdAt: nowIso
        },
        ...prev
      ]);
    }

    recordAudit('CREATE_PRODUCT', 'PRODUCT', newProduct.sku, `Created product ${newProduct.nameBn} (Opening Stock: ${initialQty}, WAC: ৳${wac})`);
    showToast(language === 'bn' ? 'পণ্য ও প্রারম্ভিক স্টক লেজারে যুক্ত হয়েছে!' : 'Product & opening stock recorded!');

    fetch(`${API_CONFIG.BASE_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProduct)
    }).catch(() => {});
  };

  const addCategory = (data: { nameBn: string; nameEn?: string; image?: string; showOnHome?: boolean }): Category => {
    const cleanBn = data.nameBn.trim();
    const cleanEn = (data.nameEn || data.nameBn).trim();
    const slug = cleanEn.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || `cat-${Date.now()}`;
    const newCat: Category = {
      id: `cat_${Date.now()}`,
      nameBn: cleanBn,
      nameEn: cleanEn,
      slug,
      ...(data.image && data.image.trim() ? { image: data.image.trim() } : {}),
      showOnHome: data.showOnHome !== false
    };
    setCategories(prev => [...prev, newCat]);
    recordAudit('CREATE_CATEGORY', 'CATEGORY', newCat.id, `Created category ${newCat.nameBn}`);
    showToast(language === 'bn' ? `নতুন ক্যাটাগরি "${newCat.nameBn}" যোগ করা হয়েছে!` : `Category "${newCat.nameEn}" added!`);
    return newCat;
  };

  const updateCategory = (id: string, updates: Partial<Omit<Category, 'id'>>) => {
    setCategories(prev =>
      prev.map(cat => {
        if (cat.id !== id) return cat;
        const nextBn = updates.nameBn !== undefined ? updates.nameBn.trim() || cat.nameBn : cat.nameBn;
        const nextEn = updates.nameEn !== undefined ? updates.nameEn.trim() || nextBn : cat.nameEn;
        return {
          ...cat,
          ...updates,
          nameBn: nextBn,
          nameEn: nextEn
        };
      })
    );
  };

  const deleteCategory = (id: string) => {
    const target = categories.find(c => c.id === id);
    if (!target) return;
    setDeleteConfirmModal({
      title: language === 'bn' ? 'ক্যাটাগরি ডিলিট নিশ্চিতকরণ' : 'Confirm Category Deletion',
      itemName: `${target.nameBn}${target.nameEn ? ` (${target.nameEn})` : ''}`,
      message:
        language === 'bn'
          ? `আপনি কি নিশ্চিতভাবে "${target.nameBn}" ক্যাটাগরিটি ডিলিট করতে চান?`
          : `Are you sure you want to delete category "${target.nameEn}"?`,
      onConfirm: () => {
        setCategories(prev => prev.filter(c => c.id !== id));
        recordAudit('DELETE_CATEGORY', 'CATEGORY', id, `Deleted category ${target.nameBn}`);
        showToast(
          language === 'bn'
            ? `ক্যাটাগরি "${target.nameBn}" ডিলিট করা হয়েছে`
            : `Category "${target.nameEn}" deleted`,
          'info'
        );
      }
    });
  };

  const addBrand = (data: { name: string; origin?: string }): Brand => {
    const cleanName = data.name.trim();
    const newBrand: Brand = {
      id: `brand_${Date.now()}`,
      name: cleanName,
      origin: (data.origin || 'বাংলাদেশ').trim()
    };
    setBrands(prev => [...prev, newBrand]);
    recordAudit('CREATE_BRAND', 'BRAND', newBrand.id, `Created brand ${newBrand.name}`);
    showToast(language === 'bn' ? `নতুন ব্র্যান্ড "${newBrand.name}" যোগ করা হয়েছে!` : `Brand "${newBrand.name}" added!`);
    return newBrand;
  };

  const deleteBrand = (id: string) => {
    const target = brands.find(b => b.id === id);
    if (!target) return;
    setDeleteConfirmModal({
      title: language === 'bn' ? 'ব্র্যান্ড ডিলিট নিশ্চিতকরণ' : 'Confirm Brand Deletion',
      itemName: target.name,
      message:
        language === 'bn'
          ? `আপনি কি নিশ্চিতভাবে "${target.name}" ব্র্যান্ডটি ডিলিট করতে চান?`
          : `Are you sure you want to delete brand "${target.name}"?`,
      onConfirm: () => {
        setBrands(prev => prev.filter(b => b.id !== id));
        recordAudit('DELETE_BRAND', 'BRAND', id, `Deleted brand ${target.name}`);
        showToast(
          language === 'bn'
            ? `ব্র্যান্ড "${target.name}" ডিলিট করা হয়েছে`
            : `Brand "${target.name}" deleted`,
          'info'
        );
      }
    });
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    const nowIso = new Date().toISOString();
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...updates, updatedAt: nowIso } : p))
    );
    recordAudit('UPDATE_PRODUCT', 'PRODUCT', id, `Updated product attributes for ${id}`);
    showToast(language === 'bn' ? 'পণ্য আপডেট সম্পন্ন হয়েছে' : 'Product updated successfully');
  };

  const deleteProduct = async (id: string) => {
    const target = products.find(p => p.id === id);
    if (!target) return;
    const isLp = Boolean(target.isLandingPageProduct);
    setDeleteConfirmModal({
      title: isLp
        ? 'ল্যান্ডিং পেজ ডিলিট নিশ্চিতকরণ (Delete Warning)'
        : 'পণ্য ডিলিট নিশ্চিতকরণ (Delete Warning)',
      itemName: `${target.nameBn} (${target.sku})`,
      message: isLp
        ? `আপনি কি নিশ্চিতভাবে "${target.nameBn}" ল্যান্ডিং পেজটি স্থায়ীভাবে ডিলিট করতে চান?`
        : `আপনি কি নিশ্চিতভাবে "${target.nameBn}" পণ্যটি ওয়েবসাইট ও ডাটাবেস থেকে স্থায়ীভাবে ডিলিট করতে চান?`,
      onConfirm: () => {
        setDeletedProductIds(prev => Array.from(new Set([...prev, id])).slice(-500));
        setProducts(prev => prev.filter(p => p.id !== id));
        recordAudit('DELETE_PRODUCT', 'PRODUCT', target.sku, `Deleted product ${target.nameBn}`);
        showToast(
          language === 'bn'
            ? `"${target.nameBn}" পণ্যটি ডিলিট করা হয়েছে`
            : `Product "${target.nameEn}" deleted`,
          'info'
        );
      }
    });
  };

  const addSale = async (saleData: Omit<Sale, 'id' | 'invoiceNo' | 'createdAt'>): Promise<Sale> => {
    const idempotencyKey = saleData.idempotencyKey || generateIdempotencyKey('SALE');
    if (processedIdempotencyKeys.has(idempotencyKey)) {
      throw new Error('Duplicate invoice submission blocked by idempotency guard.');
    }
    setProcessedIdempotencyKeys(prev => new Set(prev).add(idempotencyKey));

    const invoicePrefix = currentBusiness.invoicePrefix || 'SMB';
    const channelCode = saleData.channel === 'retail_pos' ? 'POS' : 'DST';
    const dateCode = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randCode = Math.floor(1000 + Math.random() * 9000);
    const invoiceNo = `${invoicePrefix}-${channelCode}-${dateCode}-${randCode}`;

    // Attach authoritative Weighted Average Cost (WAC) to each sold item
    const itemsWithWac = saleData.items.map(item => {
      const prod = products.find(p => p.id === item.productId);
      const wacCost = prod ? (prod.avgCost ?? prod.purchasePrice) : item.costPrice;
      return { ...item, costPrice: wacCost };
    });

    const newSale: Sale = {
      ...saleData,
      items: itemsWithWac,
      id: `sale_${Date.now()}`,
      invoiceNo,
      idempotencyKey,
      createdAt: new Date().toISOString()
    };

    const newMovements: StockMovement[] = [];
    const targetOutlet = outlets.find(o => o.id === newSale.outletId) || currentOutlet;

    setProducts(prev => prev.map(prod => {
      const lineItem = newSale.items.find(item => item.productId === prod.id);
      if (!lineItem) return prod;
      const currentStock = prod.stockByOutlet[newSale.outletId] || 0;
      const updatedStock = Math.max(0, currentStock - lineItem.quantity);
      const wac = prod.avgCost ?? prod.purchasePrice;

      newMovements.push({
        id: `sm_${Date.now()}_${prod.id}`,
        businessId: currentBusiness.id,
        outletId: newSale.outletId,
        outletName: targetOutlet.name,
        productId: prod.id,
        productName: prod.nameBn,
        sku: prod.sku,
        movementType: newSale.channel === 'wholesale_distribution' ? 'WHOLESALE_CHALLAN' : 'POS_SALE',
        referenceNo: invoiceNo,
        qtyIn: 0,
        qtyOut: lineItem.quantity,
        balanceAfter: updatedStock,
        unitCost: wac,
        wacAfter: wac,
        notes: `${newSale.channel === 'wholesale_distribution' ? 'পাইকারি চালান' : 'পিওএস বিক্রয়'} (${newSale.customerName})`,
        createdBy: currentUser.name,
        createdAt: newSale.createdAt
      });

      return {
        ...prod,
        stockByOutlet: {
          ...prod.stockByOutlet,
          [newSale.outletId]: updatedStock
        }
      };
    }));

    if (newMovements.length > 0) {
      setStockMovements(prev => [...newMovements, ...prev]);
    }

    if (newSale.customerId) {
      const targetCust = customers.find(c => c.id === newSale.customerId);
      const prevDue = targetCust ? (targetCust.currentDue || 0) : 0;
      const paidPortion = Math.min(newSale.grandTotal, newSale.paidAmount);
      const nextDue = Math.round((prevDue + newSale.dueAmount) * 100) / 100;

      if (newSale.dueAmount > 0) {
        setCustomers(prev => prev.map(c => {
          if (c.id === newSale.customerId) {
            return { ...c, currentDue: nextDue };
          }
          return c;
        }));
      }

      const ledgerEntry: CustomerLedgerEntry = {
        id: `cled_${Date.now()}`,
        businessId: currentBusiness.id,
        customerId: newSale.customerId,
        customerName: targetCust?.name || newSale.customerName,
        entryType: 'SALE_INVOICE',
        referenceNo: invoiceNo,
        description: `${newSale.channel === 'wholesale_distribution' ? 'পাইকারি চালান বিক্রয়' : 'খুচরা পিওএস বিক্রয়'}`,
        debit: newSale.grandTotal,
        credit: paidPortion,
        balanceAfter: nextDue,
        createdBy: currentUser.name,
        createdAt: newSale.createdAt
      };
      setCustomerLedger(prev => [ledgerEntry, ...prev]);
    }

    if (newSale.paidAmount > 0) {
      setAccounts(prev => prev.map(acc => {
        if (newSale.paymentSplits.some(ps => ps.method === 'cash') && acc.type === 'cash_drawer') {
          const cashPortion = newSale.paymentSplits.find(ps => ps.method === 'cash')?.amount || 0;
          return { ...acc, currentBalance: acc.currentBalance + cashPortion };
        }
        if (newSale.paymentSplits.some(ps => ps.method === 'bkash') && acc.type === 'bkash_merchant') {
          const bkashPortion = newSale.paymentSplits.find(ps => ps.method === 'bkash')?.amount || 0;
          return { ...acc, currentBalance: acc.currentBalance + bkashPortion };
        }
        return acc;
      }));
    }

    setSales(prev => [newSale, ...prev]);
    recordAudit('CREATE_SALE', 'SALE', invoiceNo, `Posted ${newSale.channel} invoice ${invoiceNo} — Total: ৳${newSale.grandTotal}, Due: ৳${newSale.dueAmount}`);
    showToast(language === 'bn' ? `বিক্রয় সম্পন্ন হয়েছে! ইনভয়েস: ${invoiceNo}` : `Sale posted! Invoice: ${invoiceNo}`);

    fetch(`${API_CONFIG.BASE_URL}/sales`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newSale)
    }).catch(() => {});

    return newSale;
  };

  // Sales Return & Refund / Customer Credit Reversal
  const addSaleReturn = async (data: {
    saleId: string;
    productId: string;
    returnQty: number;
    refundMethod: 'cash_refund' | 'adjust_customer_due';
    reason: string;
  }) => {
    const sale = sales.find(s => s.id === data.saleId);
    if (!sale) return;
    const item = sale.items.find(i => i.productId === data.productId);
    if (!item) return;

    const alreadyReturned = item.returnedQty || 0;
    const maxReturnable = item.quantity - alreadyReturned;
    if (data.returnQty <= 0 || data.returnQty > maxReturnable) {
      showToast(`সর্বোচ্চ ফেরতযোগ্য পরিমাণ: ${maxReturnable}`, 'error');
      return;
    }

    const returnNo = `SRN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const netUnitPrice = item.unitPrice - (item.discount || 0);
    const totalRefundAmount = Math.round(netUnitPrice * data.returnQty * 100) / 100;

    const newReturn: SaleReturn = {
      id: `sret_${Date.now()}`,
      returnNo,
      saleId: sale.id,
      invoiceNo: sale.invoiceNo,
      businessId: currentBusiness.id,
      outletId: sale.outletId,
      customerId: sale.customerId,
      customerName: sale.customerName,
      productId: item.productId,
      productName: item.productName,
      returnQty: data.returnQty,
      unitPrice: netUnitPrice,
      totalRefundAmount,
      refundMethod: data.refundMethod,
      reason: data.reason,
      createdBy: currentUser.name,
      createdAt: new Date().toISOString()
    };

    // 1. Mark returnedQty on original invoice without deleting history
    setSales(prev => prev.map(s => {
      if (s.id !== sale.id) return s;
      const updatedItems = s.items.map(it =>
        it.productId === data.productId
          ? { ...it, returnedQty: (it.returnedQty || 0) + data.returnQty }
          : it
      );
      return { ...s, items: updatedItems, status: 'returned' };
    }));

    // 2. Restore stock to branch & record SALE_RETURN in stock_movements
    const targetOutlet = outlets.find(o => o.id === sale.outletId) || currentOutlet;
    setProducts(prev => prev.map(prod => {
      if (prod.id !== data.productId) return prod;
      const cur = prod.stockByOutlet[sale.outletId] || 0;
      const nextBal = cur + data.returnQty;
      const wac = prod.avgCost ?? prod.purchasePrice;

      setStockMovements(smPrev => [
        {
          id: `sm_${Date.now()}_${prod.id}`,
          businessId: currentBusiness.id,
          outletId: sale.outletId,
          outletName: targetOutlet.name,
          productId: prod.id,
          productName: prod.nameBn,
          sku: prod.sku,
          movementType: 'SALE_RETURN',
          referenceNo: returnNo,
          qtyIn: data.returnQty,
          qtyOut: 0,
          balanceAfter: nextBal,
          unitCost: wac,
          wacAfter: wac,
          notes: `বিক্রয় ফেরত (${sale.invoiceNo}) — কারণ: ${data.reason}`,
          createdBy: currentUser.name,
          createdAt: new Date().toISOString()
        },
        ...smPrev
      ]);

      return {
        ...prod,
        stockByOutlet: {
          ...prod.stockByOutlet,
          [sale.outletId]: nextBal
        }
      };
    }));

    // 3. Adjust Customer Due or Refund Cash
    if (data.refundMethod === 'adjust_customer_due' && sale.customerId) {
      const targetCust = customers.find(c => c.id === sale.customerId);
      const prevDue = targetCust ? (targetCust.currentDue || 0) : 0;
      const nextDue = Math.max(0, Math.round((prevDue - totalRefundAmount) * 100) / 100);

      setCustomers(prev => prev.map(c =>
        c.id === sale.customerId
          ? { ...c, currentDue: nextDue }
          : c
      ));

      const returnLedgerEntry: CustomerLedgerEntry = {
        id: `cled_ret_${Date.now()}`,
        businessId: currentBusiness.id,
        customerId: sale.customerId,
        customerName: targetCust?.name || sale.customerName,
        entryType: 'SALES_RETURN_CREDIT',
        referenceNo: returnNo,
        description: `বিক্রয় ফেরত ক্রেডিট নোট (${sale.invoiceNo} - ${item.productName} x ${data.returnQty})`,
        debit: 0,
        credit: totalRefundAmount,
        balanceAfter: nextDue,
        createdBy: currentUser.name,
        createdAt: new Date().toISOString()
      };
      setCustomerLedger(prev => [returnLedgerEntry, ...prev]);
    } else {
      setAccounts(prev => prev.map(acc =>
        acc.type === 'cash_drawer'
          ? { ...acc, currentBalance: Math.max(0, acc.currentBalance - totalRefundAmount) }
          : acc
      ));
    }

    setSaleReturns(prev => [newReturn, ...prev]);
    recordAudit('CREATE_SALE_RETURN', 'SALE_RETURN', returnNo, `Processed Sales Return ${returnNo} against ${sale.invoiceNo} for ৳${totalRefundAmount}`);
    showToast(language === 'bn' ? `বিক্রয় ফেরত (${returnNo}) সম্পন্ন ও স্টক পুনরুদ্ধার হয়েছে` : `Sales return ${returnNo} processed`);
  };

  // Purchase Receipt (GRN) with Weighted Average Costing (WAC)
  const addPurchase = async (purchaseData: Omit<Purchase, 'id' | 'poNumber' | 'receivedDate'>): Promise<Purchase> => {
    const idempotencyKey = purchaseData.idempotencyKey || generateIdempotencyKey('GRN');
    const poNumber = `GRN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const newPurchase: Purchase = {
      ...purchaseData,
      id: `pur_${Date.now()}`,
      poNumber,
      idempotencyKey,
      receivedDate: new Date().toISOString().slice(0, 10)
    };

    const targetOutlet = outlets.find(o => o.id === newPurchase.outletId) || currentOutlet;
    const newMovements: StockMovement[] = [];

    // Update Stock and Recalculate Weighted Average Cost (WAC)
    setProducts(prev => prev.map(prod => {
      const lineItem = newPurchase.items.find(item => item.productId === prod.id);
      if (!lineItem) return prod;

      const existingTotalOrgStock = Object.values(prod.stockByOutlet).reduce((s, q) => s + (q || 0), 0);
      const oldWac = prod.avgCost ?? prod.purchasePrice;
      const receivedQty = lineItem.quantity;
      const unitCost = lineItem.unitCost || prod.purchasePrice;

      // Weighted Average Cost Formula:
      // New WAC = ((Existing Total Stock * Old WAC) + (Received Qty * New Unit Cost)) / (Existing Total Stock + Received Qty)
      const totalDenom = existingTotalOrgStock + receivedQty;
      const newWac = totalDenom > 0
        ? Math.round((((existingTotalOrgStock * oldWac) + (receivedQty * unitCost)) / totalDenom) * 10000) / 10000
        : unitCost;

      const currentOutletStock = prod.stockByOutlet[newPurchase.outletId] || 0;
      const updatedOutletStock = currentOutletStock + receivedQty;

      newMovements.push({
        id: `sm_${Date.now()}_${prod.id}`,
        businessId: currentBusiness.id,
        outletId: newPurchase.outletId,
        outletName: targetOutlet.name,
        productId: prod.id,
        productName: prod.nameBn,
        sku: prod.sku,
        movementType: 'PURCHASE_RECEIPT',
        referenceNo: poNumber,
        qtyIn: receivedQty,
        qtyOut: 0,
        balanceAfter: updatedOutletStock,
        unitCost,
        wacAfter: newWac,
        notes: `পণ্য ক্রয় GRN (${newPurchase.supplierName}) — গড় ক্রয়মূল্য (WAC): ৳${newWac.toFixed(2)}`,
        createdBy: currentUser.name,
        createdAt: new Date().toISOString()
      });

      return {
        ...prod,
        purchasePrice: unitCost,
        avgCost: newWac,
        stockByOutlet: {
          ...prod.stockByOutlet,
          [newPurchase.outletId]: updatedOutletStock
        }
      };
    }));

    if (newMovements.length > 0) {
      setStockMovements(prev => [...newMovements, ...prev]);
    }

    if (newPurchase.dueAmount > 0) {
      setSuppliers(prev => prev.map(s => {
        if (s.id === newPurchase.supplierId) {
          return { ...s, currentPayable: (s.currentPayable || 0) + newPurchase.dueAmount };
        }
        return s;
      }));
    }

    setPurchases(prev => [newPurchase, ...prev]);
    recordAudit('CREATE_PURCHASE_GRN', 'PURCHASE', poNumber, `Received GRN ${poNumber} Total: ৳${newPurchase.totalAmount} (Recalculated WAC)`);
    showToast(language === 'bn' ? 'ক্রয় ভাউচার সংরক্ষিত, স্টক ও গড় ক্রয়মূল্য (WAC) আপডেট হয়েছে' : 'Purchase recorded & WAC updated');

    fetch(`${API_CONFIG.BASE_URL}/purchases`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPurchase)
    }).catch(() => {});

    return newPurchase;
  };

  // Purchase Return (Debit Note Reversal)
  const addPurchaseReturn = async (data: {
    purchaseId: string;
    productId: string;
    returnQty: number;
    reason: string;
  }) => {
    const pur = purchases.find(p => p.id === data.purchaseId);
    if (!pur) return;
    const item = pur.items.find(i => i.productId === data.productId);
    if (!item) return;

    const alreadyRet = item.returnedQty || 0;
    const maxRet = item.quantity - alreadyRet;
    if (data.returnQty <= 0 || data.returnQty > maxRet) {
      showToast(`সর্বোচ্চ ফেরতযোগ্য পরিমাণ: ${maxRet}`, 'error');
      return;
    }

    const returnNo = `PRN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const totalReturnAmount = Math.round(item.unitCost * data.returnQty * 100) / 100;

    const newPReturn: PurchaseReturn = {
      id: `pret_${Date.now()}`,
      returnNo,
      purchaseId: pur.id,
      poNumber: pur.poNumber,
      businessId: currentBusiness.id,
      outletId: pur.outletId,
      supplierId: pur.supplierId,
      supplierName: pur.supplierName,
      productId: item.productId,
      productName: item.productName,
      returnQty: data.returnQty,
      unitCost: item.unitCost,
      totalReturnAmount,
      reason: data.reason,
      createdBy: currentUser.name,
      createdAt: new Date().toISOString()
    };

    setPurchases(prev => prev.map(p => {
      if (p.id !== pur.id) return p;
      return {
        ...p,
        status: 'returned',
        items: p.items.map(it =>
          it.productId === data.productId
            ? { ...it, returnedQty: (it.returnedQty || 0) + data.returnQty }
            : it
        )
      };
    }));

    const targetOutlet = outlets.find(o => o.id === pur.outletId) || currentOutlet;
    setProducts(prev => prev.map(prod => {
      if (prod.id !== data.productId) return prod;
      const cur = prod.stockByOutlet[pur.outletId] || 0;
      const nextBal = Math.max(0, cur - data.returnQty);
      const wac = prod.avgCost ?? prod.purchasePrice;

      setStockMovements(smPrev => [
        {
          id: `sm_${Date.now()}_${prod.id}`,
          businessId: currentBusiness.id,
          outletId: pur.outletId,
          outletName: targetOutlet.name,
          productId: prod.id,
          productName: prod.nameBn,
          sku: prod.sku,
          movementType: 'PURCHASE_RETURN',
          referenceNo: returnNo,
          qtyIn: 0,
          qtyOut: data.returnQty,
          balanceAfter: nextBal,
          unitCost: item.unitCost,
          wacAfter: wac,
          notes: `ক্রয় ফেরত ডেবিট নোট (${pur.poNumber}) — কারণ: ${data.reason}`,
          createdBy: currentUser.name,
          createdAt: new Date().toISOString()
        },
        ...smPrev
      ]);

      return {
        ...prod,
        stockByOutlet: {
          ...prod.stockByOutlet,
          [pur.outletId]: nextBal
        }
      };
    }));

    // Reduce Supplier Payable
    setSuppliers(prev => prev.map(s =>
      s.id === pur.supplierId
        ? { ...s, currentPayable: Math.max(0, Math.round((s.currentPayable - totalReturnAmount) * 100) / 100) }
        : s
    ));

    setPurchaseReturns(prev => [newPReturn, ...prev]);
    recordAudit('CREATE_PURCHASE_RETURN', 'PURCHASE_RETURN', returnNo, `Processed Purchase Return ${returnNo} against ${pur.poNumber} for ৳${totalReturnAmount}`);
    showToast(language === 'bn' ? `ক্রয় ফেরত (${returnNo}) ও সরবরাহকারী পাওনা সমন্বয় হয়েছে` : `Purchase return ${returnNo} recorded`);
  };

  const addCustomer = async (data: Omit<Customer, 'id' | 'createdAt'>) => {
    const cleanPhone = normalizeBdPhone(data.phone) || data.phone.trim();
    const newCust: Customer = {
      ...data,
      phone: cleanPhone,
      isOnlineCustomer: data.customerType === 'online' || Boolean(data.isOnlineCustomer),
      id: `cust_${Date.now()}`,
      createdAt: new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString()
    };
    const nextCustomers = [newCust, ...customers];
    setCustomers(nextCustomers);

    if (newCust.currentDue > 0) {
      const opnEntry: CustomerLedgerEntry = {
        id: `cled_opn_${Date.now()}`,
        businessId: currentBusiness.id,
        customerId: newCust.id,
        customerName: newCust.name,
        entryType: 'OPENING_BALANCE',
        referenceNo: `OPN-${newCust.id.slice(-4)}`,
        description: 'প্রারম্ভিক বকেয়া জের (Opening Due)',
        debit: newCust.currentDue,
        credit: 0,
        balanceAfter: newCust.currentDue,
        createdBy: currentUser.name,
        createdAt: new Date().toISOString()
      };
      setCustomerLedger(prev => [opnEntry, ...prev]);
    }

    const now = Date.now();
    lastSavedAtRef.current = now;
    const snap = { ...buildSnapshot(now), customers: nextCustomers };
    try {
      window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
    } catch {
      // Ignore quota errors
    }
    pushStateToServer(snap);

    recordAudit('CREATE_CUSTOMER', 'CUSTOMER', newCust.name, `Registered customer ${newCust.name} (Type: ${newCust.customerType}, Phone: ${newCust.phone})`);
    showToast(language === 'bn' ? 'নতুন গ্রাহক ডাটাবেজে সংরক্ষিত হয়েছে' : 'Customer saved to database');
  };

  const updateCustomer = async (id: string, updates: Partial<Customer>) => {
    const normalizedUpdates = {
      ...updates,
      ...(updates.phone ? { phone: normalizeBdPhone(updates.phone) || updates.phone.trim() } : {}),
      updatedAt: new Date().toISOString()
    };
    const nextCustomers = customers.map(c => (c.id === id ? { ...c, ...normalizedUpdates } : c));
    setCustomers(nextCustomers);

    const now = Date.now();
    lastSavedAtRef.current = now;
    const snap = { ...buildSnapshot(now), customers: nextCustomers };
    try {
      window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
    } catch {
      // Ignore quota errors
    }
    await pushStateToServer(snap);

    recordAudit('UPDATE_CUSTOMER', 'CUSTOMER', id, `Updated customer profile/account (${id})`);
  };

  const registerOrUpdateOnlineCustomer = async (data: {
    name: string;
    phone: string;
    address: string;
    password?: string;
  }): Promise<Customer> => {
    const cleanName = data.name.trim();
    const normPhone = normalizeBdPhone(data.phone) || data.phone.trim();
    const cleanAddress = data.address.trim();
    const nowIso = new Date().toISOString();

    const currentCustomers = liveStateRef.current.customers;
    let targetCustomer: Customer | null = null;
    const existing = currentCustomers.find(c => normalizeBdPhone(c.phone) === normPhone);

    let nextCustomers: Customer[];
    if (existing) {
      targetCustomer = {
        ...existing,
        name: cleanName || existing.name,
        phone: normPhone,
        address: cleanAddress || existing.address,
        route: existing.route || 'হোম ডেলিভারি (অনলাইন)',
        customerType: existing.customerType === 'wholesale' ? 'wholesale' : 'online',
        isOnlineCustomer: true,
        password: data.password !== undefined ? data.password : existing.password,
        updatedAt: nowIso
      };
      nextCustomers = currentCustomers.map(c => (c.id === existing.id ? targetCustomer! : c));
    } else {
      targetCustomer = {
        id: `cust_online_${Date.now()}`,
        businessId: currentBusiness.id,
        name: cleanName || 'অনলাইন ক্রেতা',
        phone: normPhone,
        address: cleanAddress || 'হোম ডেলিভারি',
        route: 'হোম ডেলিভারি (অনলাইন)',
        customerType: 'online',
        isOnlineCustomer: true,
        password: data.password || '',
        creditLimit: 0,
        currentDue: 0,
        createdAt: nowIso.slice(0, 10),
        updatedAt: nowIso
      };
      nextCustomers = [targetCustomer, ...currentCustomers];
    }

    liveStateRef.current = {
      ...liveStateRef.current,
      customers: nextCustomers
    };
    setCustomers(nextCustomers);

    // Sync to localStorage & server database immediately so login and admin view work without delay
    const now = Date.now();
    lastSavedAtRef.current = now;
    const snap = { ...buildSnapshot(now), customers: nextCustomers };
    try {
      window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
    } catch {
      // Ignore quota errors
    }
    await pushStateToServer(snap);

    recordAudit(
      existing ? 'UPDATE_ONLINE_CUSTOMER' : 'REGISTER_ONLINE_CUSTOMER',
      'ECOMMERCE_CUSTOMER',
      targetCustomer.phone,
      `Online customer account saved in database: ${targetCustomer.name} (${targetCustomer.phone})`
    );

    return targetCustomer;
  };

  const collectCustomerDue = async (customerId: string, amount: number, method: PaymentMethod, note?: string) => {
    const cust = customers.find(c => c.id === customerId);
    const prevDue = cust ? (cust.currentDue || 0) : 0;
    const nextDue = Math.max(0, Math.round((prevDue - amount) * 100) / 100);

    const dateCode = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randCode = Math.floor(100 + Math.random() * 900);
    const receiptNo = `MR-${dateCode}-${randCode}`;

    const methodLabels: Record<string, string> = {
      cash: 'নগদ ক্যাশ',
      bkash: 'বিকাশ মার্চেন্ট',
      nagad: 'নগদ ওয়ালেট',
      bank: 'ব্যাংক ট্রান্সফার',
      card: 'কার্ড পেমেন্ট'
    };

    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return { ...c, currentDue: nextDue };
      }
      return c;
    }));

    const paymentLedgerEntry: CustomerLedgerEntry = {
      id: `cled_pay_${Date.now()}`,
      businessId: currentBusiness.id,
      customerId,
      customerName: cust?.name || customerId,
      entryType: 'PAYMENT_COLLECTION',
      referenceNo: receiptNo,
      description: `${note || 'বকেয়া আদায় রশিদ'} — মাধ্যম: ${methodLabels[method] || method}`,
      paymentMethod: method,
      debit: 0,
      credit: amount,
      balanceAfter: nextDue,
      createdBy: currentUser.name,
      createdAt: new Date().toISOString()
    };

    setCustomerLedger(prev => [paymentLedgerEntry, ...prev]);

    setAccounts(prev => prev.map(acc => {
      if (method === 'cash' && acc.type === 'cash_drawer') {
        return { ...acc, currentBalance: acc.currentBalance + amount };
      }
      if (method === 'bkash' && acc.type === 'bkash_merchant') {
        return { ...acc, currentBalance: acc.currentBalance + amount };
      }
      if (method === 'nagad' && acc.type === 'nagad_merchant') {
        return { ...acc, currentBalance: acc.currentBalance + amount };
      }
      if (method === 'bank' && acc.type === 'bank_account') {
        return { ...acc, currentBalance: acc.currentBalance + amount };
      }
      return acc;
    }));

    recordAudit('CUSTOMER_PAYMENT', 'CUSTOMER_LEDGER', receiptNo, `Collected customer due ৳${amount} from ${cust?.name || customerId} via ${method} (Remaining Due: ৳${nextDue})`);
    showToast(
      language === 'bn'
        ? `মানি রিসিপ্ট ${receiptNo}: বকেয়া ৳${amount} আদায় ও গ্রাহক খতিয়ানে (Ledger) যুক্ত হয়েছে!`
        : `Receipt ${receiptNo}: Due payment of ৳${amount} recorded in Customer Statement!`
    );
  };

  const addSupplier = async (data: Omit<Supplier, 'id'>) => {
    const newSupp: Supplier = {
      ...data,
      id: `supp_${Date.now()}`
    };
    setSuppliers(prev => [newSupp, ...prev]);
    recordAudit('CREATE_SUPPLIER', 'SUPPLIER', newSupp.companyName, `Registered supplier ${newSupp.companyName}`);
    showToast(language === 'bn' ? 'সরবরাহকারী প্রতিষ্ঠান যুক্ত হয়েছে' : 'Supplier added successfully');
  };

  const paySupplier = async (supplierId: string, amount: number, method: PaymentMethod, note?: string) => {
    const supp = suppliers.find(s => s.id === supplierId);
    setSuppliers(prev => prev.map(s => {
      if (s.id === supplierId) {
        return { ...s, currentPayable: Math.max(0, s.currentPayable - amount) };
      }
      return s;
    }));

    setAccounts(prev => prev.map(acc => {
      if (method === 'cash' && acc.type === 'cash_drawer') {
        return { ...acc, currentBalance: Math.max(0, acc.currentBalance - amount) };
      }
      if (method === 'bank' && acc.type === 'bank_account') {
        return { ...acc, currentBalance: Math.max(0, acc.currentBalance - amount) };
      }
      return acc;
    }));

    recordAudit('SUPPLIER_PAYMENT', 'SUPPLIER_LEDGER', supp?.companyName || supplierId, `Paid supplier ৳${amount} via ${method} (${note || 'Voucher'})`);
    showToast(language === 'bn' ? `সরবরাহকারীকে ৳${amount} পরিশোধ সম্পন্ন হয়েছে` : `Payment of ৳${amount} disbursed to supplier`);
  };

  const addExpense = async (data: Omit<Expense, 'id'>) => {
    const newExp: Expense = {
      ...data,
      id: `exp_${Date.now()}`
    };
    setExpenses(prev => [newExp, ...prev]);

    setAccounts(prev => prev.map(acc => {
      if (data.paymentMethod === 'cash' && acc.type === 'cash_drawer') {
        return { ...acc, currentBalance: Math.max(0, acc.currentBalance - data.amount) };
      }
      return acc;
    }));

    recordAudit('CREATE_EXPENSE', 'EXPENSE', data.category, `Recorded expense ৳${data.amount} paid to ${data.paidTo}`);
    showToast(language === 'bn' ? 'ব্যয় লিপিবদ্ধ করা হয়েছে' : 'Expense recorded successfully');
  };

  const addStockTransfer = async (transferData: Omit<StockTransfer, 'id' | 'transferNo' | 'date'>) => {
    const transferNo = `TR-${Date.now().toString().slice(-6)}`;
    const newTransfer: StockTransfer = {
      ...transferData,
      id: `tr_${Date.now()}`,
      transferNo,
      date: new Date().toISOString().slice(0, 10)
    };

    const fromOutlet = outlets.find(o => o.id === newTransfer.fromOutletId);
    const toOutlet = outlets.find(o => o.id === newTransfer.toOutletId);

    setProducts(prev => prev.map(prod => {
      if (prod.id !== newTransfer.productId) return prod;
      const fromCurrent = prod.stockByOutlet[newTransfer.fromOutletId] || 0;
      const toCurrent = prod.stockByOutlet[newTransfer.toOutletId] || 0;
      const nextFrom = Math.max(0, fromCurrent - newTransfer.quantity);
      const nextTo = toCurrent + newTransfer.quantity;
      const wac = prod.avgCost ?? prod.purchasePrice;

      setStockMovements(smPrev => [
        {
          id: `sm_in_${Date.now()}`,
          businessId: currentBusiness.id,
          outletId: newTransfer.toOutletId,
          outletName: toOutlet?.name || newTransfer.toOutletId,
          productId: prod.id,
          productName: prod.nameBn,
          sku: prod.sku,
          movementType: 'TRANSFER_IN',
          referenceNo: transferNo,
          qtyIn: newTransfer.quantity,
          qtyOut: 0,
          balanceAfter: nextTo,
          unitCost: wac,
          wacAfter: wac,
          notes: `${fromOutlet?.name || ''} হতে আগত চালান`,
          createdBy: currentUser.name,
          createdAt: new Date().toISOString()
        },
        {
          id: `sm_out_${Date.now()}`,
          businessId: currentBusiness.id,
          outletId: newTransfer.fromOutletId,
          outletName: fromOutlet?.name || newTransfer.fromOutletId,
          productId: prod.id,
          productName: prod.nameBn,
          sku: prod.sku,
          movementType: 'TRANSFER_OUT',
          referenceNo: transferNo,
          qtyIn: 0,
          qtyOut: newTransfer.quantity,
          balanceAfter: nextFrom,
          unitCost: wac,
          wacAfter: wac,
          notes: `${toOutlet?.name || ''} এ প্রেরিত চালান`,
          createdBy: currentUser.name,
          createdAt: new Date().toISOString()
        },
        ...smPrev
      ]);

      return {
        ...prod,
        stockByOutlet: {
          ...prod.stockByOutlet,
          [newTransfer.fromOutletId]: nextFrom,
          [newTransfer.toOutletId]: nextTo
        }
      };
    }));

    setStockTransfers(prev => [newTransfer, ...prev]);
    recordAudit('STOCK_TRANSFER', 'TRANSFER', transferNo, `Transferred ${newTransfer.quantity} units of ${newTransfer.productName}`);
    showToast(language === 'bn' ? `স্টক ট্রান্সফার (${newTransfer.quantity} টি) সম্পন্ন হয়েছে!` : `Stock transferred (${newTransfer.quantity} units)`);
  };

  const addStockAdjustment = async (adjData: Omit<StockAdjustment, 'id' | 'date'>) => {
    const adjNo = `ADJ-${Date.now().toString().slice(-6)}`;
    const newAdj: StockAdjustment = {
      ...adjData,
      id: `adj_${Date.now()}`,
      date: new Date().toISOString().slice(0, 10)
    };

    const targetOutlet = outlets.find(o => o.id === newAdj.outletId) || currentOutlet;

    setProducts(prev => prev.map(prod => {
      if (prod.id !== newAdj.productId) return prod;
      const cur = prod.stockByOutlet[newAdj.outletId] || 0;
      const nextBal = Math.max(0, cur + newAdj.quantity);
      const wac = prod.avgCost ?? prod.purchasePrice;

      setStockMovements(smPrev => [
        {
          id: `sm_adj_${Date.now()}`,
          businessId: currentBusiness.id,
          outletId: newAdj.outletId,
          outletName: targetOutlet.name,
          productId: prod.id,
          productName: prod.nameBn,
          sku: prod.sku,
          movementType: 'ADJUSTMENT',
          referenceNo: adjNo,
          qtyIn: newAdj.quantity > 0 ? newAdj.quantity : 0,
          qtyOut: newAdj.quantity < 0 ? Math.abs(newAdj.quantity) : 0,
          balanceAfter: nextBal,
          unitCost: wac,
          wacAfter: wac,
          notes: `স্টক সমন্বয় (${newAdj.type}): ${newAdj.reason}`,
          createdBy: currentUser.name,
          createdAt: new Date().toISOString()
        },
        ...smPrev
      ]);

      return {
        ...prod,
        stockByOutlet: {
          ...prod.stockByOutlet,
          [newAdj.outletId]: nextBal
        }
      };
    }));

    setStockAdjustments(prev => [newAdj, ...prev]);
    recordAudit('STOCK_ADJUSTMENT', 'INVENTORY', adjNo, `Adjusted ${newAdj.productName} by ${newAdj.quantity} (${newAdj.reason})`);
    showToast(language === 'bn' ? 'স্টক সমন্বয় লেজারে রেকর্ড করা হয়েছে' : 'Stock adjustment recorded');
  };

  const closeDayEnd = async (data: Omit<DayEndClose, 'id' | 'date'>): Promise<DayEndClose> => {
    const newClose: DayEndClose = {
      ...data,
      id: `close_${Date.now()}`,
      date: new Date().toISOString().slice(0, 10)
    };
    setDayEndClosures(prev => [newClose, ...prev]);
    recordAudit('DAY_END_CLOSE', 'Z_REPORT', newClose.date, `Closed daily register — Expected: ৳${newClose.expectedClosingCash}, Actual: ৳${newClose.actualPhysicalCash}`);
    showToast(language === 'bn' ? 'আজকের দিন সমাপনী (Z-Report) লক করা হয়েছে' : 'Day-End Z-Report finalized');
    return newClose;
  };

  const holdCart = (items: SaleItem[], customerName: string) => {
    if (items.length === 0) return;
    const newHeld: HeldCart = {
      id: `held_${Date.now()}`,
      customerName: customerName || 'সাধারণ ক্রেতা',
      items,
      heldAt: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
    };
    setHeldCarts(prev => [newHeld, ...prev]);
    showToast(language === 'bn' ? 'কার্ট হোল্ড তালিকায় সংরক্ষণ করা হয়েছে' : 'Cart placed on hold');
  };

  const restoreHeldCart = (id: string): SaleItem[] => {
    const target = heldCarts.find(h => h.id === id);
    if (!target) return [];
    setHeldCarts(prev => prev.filter(h => h.id !== id));
    return target.items;
  };

  const removeHeldCart = (id: string) => {
    setHeldCarts(prev => prev.filter(h => h.id !== id));
  };

  // E-Commerce Online Grocery Order Placement (Synced with ERP Stock, Sales & Ledger)
  const placeOnlineOrder = async (
    orderData: Omit<OnlineOrder, 'id' | 'orderNo' | 'invoiceNo' | 'createdAt' | 'orderStatus'>
  ): Promise<OnlineOrder> => {
    // 1. Strict Online Connectivity Check: Block online storefront orders when Mobile Data / Wi-Fi is off
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      throw new Error('OFFLINE_NO_INTERNET');
    }

    // Build a set of all existing order & invoice numbers to guarantee 100% uniqueness
    const existingCodes = new Set<string>();
    onlineOrders.forEach(o => {
      if (o.orderNo) existingCodes.add(o.orderNo.toUpperCase());
      if (o.invoiceNo) existingCodes.add(o.invoiceNo.toUpperCase());
      const suffix = o.orderNo.replace(/^ORD-/i, '').toUpperCase();
      if (suffix) existingCodes.add(suffix);
    });
    sales.forEach(s => {
      if (s.invoiceNo) existingCodes.add(s.invoiceNo.toUpperCase());
    });

    // Generate a compact, 100% unique 5-character code (e.g., ORD-48291)
    const invoicePrefix = currentBusiness.invoicePrefix || 'SMB';
    let shortCode = '';
    let attempts = 0;
    const alphaChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    while (!shortCode || existingCodes.has(shortCode) || existingCodes.has(`ORD-${shortCode}`)) {
      if (attempts < 50) {
        // Clean 5-digit unique code combining timestamp entropy + random digits (10000 - 99999)
        const timePart = Date.now() % 1000;
        const randPart = Math.floor(10 + Math.random() * 89);
        const mixed = ((randPart * 1000 + timePart + Math.floor(Math.random() * 997)) % 90000) + 10000;
        shortCode = String(mixed);
      } else {
        // Fallback 5-char alphanumeric if 5-digit space is busy
        let code = '';
        for (let i = 0; i < 5; i++) {
          code += alphaChars.charAt(Math.floor(Math.random() * alphaChars.length));
        }
        shortCode = code;
      }
      attempts += 1;
    }

    const orderNo = `ORD-${shortCode}`;
    const invoiceNo = `${invoicePrefix}-${shortCode}`;
    const createdAt = new Date().toISOString();

    // Strict Line Items Sanitization: filter out invalid/ghost items
    const rawItems = Array.isArray(orderData.items) ? orderData.items : [];
    const validRawItems = rawItems.filter(
      item => item && (item.productId || item.productName) && Number(item.quantity) > 0
    );

    // If order is from Landing Page or Direct Buy single purchase, strictly enforce single line item
    const isSingleItemOrder =
      orderData.orderSource === 'landing_page' ||
      Boolean(orderData.landingSlug) ||
      Boolean(orderData.deliverySlot?.includes('Landing Page')) ||
      Boolean(orderData.notes?.includes('Landing Page')) ||
      Boolean(orderData.notes?.includes('Direct Buy'));

    const sanitizedItems = isSingleItemOrder && validRawItems.length > 0
      ? [validRawItems[0]]
      : validRawItems.length > 0
      ? validRawItems
      : rawItems;

    const itemsWithWac = sanitizedItems.map(item => {
      const prod = products.find(p => p.id === item.productId);
      const wacCost = prod ? (prod.avgCost ?? prod.purchasePrice) : item.costPrice;
      const matchedVariant = prod?.variants?.find(
        v =>
          (item.variantId && v.id === item.variantId) ||
          (item.variantLabel &&
            v.label.trim().toLowerCase() === item.variantLabel.trim().toLowerCase()) ||
          (item.unit && v.label.trim().toLowerCase() === item.unit.trim().toLowerCase())
      );
      const parentSku = item.parentSku || prod?.sku || item.sku || '';
      const variantLabel = item.variantLabel || matchedVariant?.label;
      const variantSku =
        item.variantSku ||
        matchedVariant?.sku ||
        (variantLabel ? buildVariantSkuCode(parentSku, variantLabel) : undefined);

      return {
        ...item,
        costPrice: wacCost,
        productNameClean: item.productNameClean || prod?.nameBn || item.productName,
        parentSku,
        variantSku,
        sku: variantSku || parentSku || item.sku,
        wpProductId: item.wpProductId || prod?.wpProductId,
        wpVariationId: item.wpVariationId || matchedVariant?.wpVariationId,
        variantId: item.variantId || matchedVariant?.id,
        variantLabel
      };
    });

    const normOrderPhone = normalizeBdPhone(orderData.customerPhone) || orderData.customerPhone.trim();

    // Upsert Online Customer into Database (customers table/state) so every online order customer is saved
    const existingCust = customers.find(c => normalizeBdPhone(c.phone) === normOrderPhone);
    const upsertedCustomer: Customer = existingCust
      ? {
          ...existingCust,
          name: orderData.customerName.trim() || existingCust.name,
          phone: normOrderPhone,
          address: orderData.deliveryAddress.trim() || existingCust.address,
          route: existingCust.route || orderData.deliveryArea || 'হোম ডেলিভারি (অনলাইন)',
          customerType: existingCust.customerType === 'wholesale' ? 'wholesale' : 'online',
          isOnlineCustomer: true,
          updatedAt: createdAt
        }
      : {
          id: `cust_online_${Date.now()}`,
          businessId: currentBusiness.id,
          name: orderData.customerName.trim() || 'অনলাইন ক্রেতা',
          phone: normOrderPhone,
          address: orderData.deliveryAddress.trim() || 'হোম ডেলিভারি',
          route: orderData.deliveryArea || 'হোম ডেলিভারি (অনলাইন)',
          customerType: 'online',
          isOnlineCustomer: true,
          creditLimit: 0,
          currentDue: 0,
          createdAt: createdAt.slice(0, 10),
          updatedAt: createdAt
        };

    const nextCustomers = existingCust
      ? customers.map(c => (c.id === existingCust.id ? upsertedCustomer : c))
      : [upsertedCustomer, ...customers];

    const clientDeviceId = getOrCreateClientDeviceId();
    const clientIp = orderData.clientIp || visitorClientIpRef.current || undefined;
    const deterministicFbEventId = generateMetaEventId('Purchase', orderNo);

    const newOrder: OnlineOrder = {
      ...orderData,
      orderSource: orderData.orderSource || (isSingleItemOrder ? 'landing_page' : 'storefront'),
      customerId: upsertedCustomer.id,
      customerPhone: normOrderPhone,
      clientDeviceId,
      ...(clientIp ? { clientIp } : {}),
      fbEventId: deterministicFbEventId,
      items: itemsWithWac,
      id: `eord_${Date.now()}`,
      orderNo,
      invoiceNo,
      orderStatus: 'pending',
      createdAt
    };

    const targetOutletId = orderData.outletId || 'outlet_01';
    const targetOutlet = outlets.find(o => o.id === targetOutletId) || currentOutlet;
    const newMovements: StockMovement[] = [];

    const nextProducts = products.map(prod => {
      const lineItem = newOrder.items.find(item => item.productId === prod.id);
      if (!lineItem) return prod;

      const nextStockByOutlet = { ...prod.stockByOutlet };
      let remainingToDeduct = lineItem.quantity;

      // Deduct from primary outlet first, then automatically spill over to warehouse outlets for bulk / ad orders
      const primaryStock = nextStockByOutlet[targetOutletId] ?? 0;
      const deductPrimary = Math.min(primaryStock, remainingToDeduct);
      nextStockByOutlet[targetOutletId] = Math.max(0, primaryStock - deductPrimary);
      remainingToDeduct -= deductPrimary;

      if (remainingToDeduct > 0) {
        for (const outId of Object.keys(nextStockByOutlet)) {
          if (outId === targetOutletId || remainingToDeduct <= 0) continue;
          const avail = nextStockByOutlet[outId] ?? 0;
          if (avail > 0) {
            const take = Math.min(avail, remainingToDeduct);
            nextStockByOutlet[outId] = avail - take;
            remainingToDeduct -= take;
          }
        }
      }

      const updatedStock = nextStockByOutlet[targetOutletId] ?? 0;
      const wac = prod.avgCost ?? prod.purchasePrice;

      newMovements.push({
        id: `sm_web_${Date.now()}_${prod.id}`,
        businessId: currentBusiness.id,
        outletId: targetOutletId,
        outletName: targetOutlet.name,
        productId: prod.id,
        productName: prod.nameBn,
        sku: prod.sku,
        movementType: 'POS_SALE',
        referenceNo: orderNo,
        qtyIn: 0,
        qtyOut: lineItem.quantity,
        balanceAfter: updatedStock,
        unitCost: wac,
        wacAfter: wac,
        notes: `অনলাইন ই-কমার্স অর্ডার (${newOrder.customerName} · ${newOrder.customerPhone})`,
        createdBy: 'অনলাইন স্টোরফ্রন্ট (E-Commerce)',
        createdAt
      });

      return {
        ...prod,
        stockByOutlet: nextStockByOutlet
      };
    });

    const nextStockMovements = newMovements.length > 0 ? [...newMovements, ...stockMovements] : stockMovements;

    // Create linked ERP Sale record so revenue & WAC reports include online orders
    const linkedSale: Sale = {
      id: `sale_web_${Date.now()}`,
      invoiceNo,
      businessId: currentBusiness.id,
      outletId: targetOutletId,
      channel: 'online_ecommerce',
      customerId: upsertedCustomer.id,
      customerName: newOrder.customerName,
      customerPhone: newOrder.customerPhone,
      items: itemsWithWac,
      subtotal: newOrder.subtotal,
      taxAmount: newOrder.deliveryCharge,
      discountAmount: newOrder.discountAmount,
      grandTotal: newOrder.grandTotal,
      paidAmount: newOrder.paymentStatus === 'paid' ? newOrder.grandTotal : 0,
      changeAmount: 0,
      dueAmount: newOrder.paymentStatus === 'paid' ? 0 : newOrder.grandTotal,
      paymentSplits: [
        {
          method: newOrder.paymentMethod === 'cod' ? 'cash' : newOrder.paymentMethod,
          amount: newOrder.grandTotal,
          reference: newOrder.transactionId || orderNo
        }
      ],
      status: 'dispatched',
      createdAt,
      cashierName: 'অনলাইন স্টোর (Web Order)',
      notes: `অনলাইন অর্ডার #${orderNo} | এলাকা: ${newOrder.deliveryArea} | ঠিকানা: ${newOrder.deliveryAddress}`
    };

    const webLedgerEntry: CustomerLedgerEntry = {
      id: `cled_web_${Date.now()}`,
      businessId: currentBusiness.id,
      customerId: upsertedCustomer.id,
      customerName: upsertedCustomer.name,
      entryType: 'SALE_INVOICE',
      referenceNo: orderNo,
      description: `অনলাইন ই-কমার্স অর্ডার (#${orderNo} · ${newOrder.items.length} টি পণ্য)`,
      debit: newOrder.grandTotal,
      credit: newOrder.paymentStatus === 'paid' ? newOrder.grandTotal : 0,
      balanceAfter: upsertedCustomer.currentDue || 0,
      createdBy: 'অনলাইন স্টোর (Web Order)',
      createdAt
    };

    const nextSales = [linkedSale, ...sales];
    const nextOnlineOrders = [newOrder, ...onlineOrders];
    const nextLedger = [webLedgerEntry, ...customerLedger];
    const nextIncompleteOrders: IncompleteOrder[] = incompleteOrders.map(inc => {
      const incPhone = normalizeBdPhone(inc.customerPhone);
      if (
        incPhone &&
        incPhone === normOrderPhone &&
        (inc.status === 'abandoned' || inc.status === 'contacted')
      ) {
        return {
          ...inc,
          status: 'converted',
          convertedOrderNo: orderNo,
          updatedAt: createdAt
        };
      }
      return inc;
    });

    // 2. Verify Server Persistence BEFORE Confirming Online Order:
    // Ensure the order actually reaches the server database (not just offline browser storage)
    const prevLive = liveStateRef.current;
    liveStateRef.current = {
      ...prevLive,
      products: nextProducts,
      stockMovements: nextStockMovements,
      customers: nextCustomers,
      sales: nextSales,
      onlineOrders: nextOnlineOrders,
      incompleteOrders: nextIncompleteOrders,
      customerLedger: nextLedger
    };

    const now = Date.now();
    const snap: PersistedErpState = {
      ...buildSnapshot(now),
      products: nextProducts,
      stockMovements: nextStockMovements,
      customers: nextCustomers,
      sales: nextSales,
      onlineOrders: nextOnlineOrders,
      incompleteOrders: nextIncompleteOrders,
      customerLedger: nextLedger
    };

    const savedOnServer = await pushStateToServer(snap);
    if (!savedOnServer) {
      liveStateRef.current = prevLive;
      throw new Error('OFFLINE_NO_INTERNET');
    }

    lastSavedAtRef.current = Math.max(lastSavedAtRef.current, now);
    setProducts(nextProducts);
    if (newMovements.length > 0) {
      setStockMovements(nextStockMovements);
    }
    setCustomers(nextCustomers);
    setSales(nextSales);
    setOnlineOrders(nextOnlineOrders);
    setIncompleteOrders(nextIncompleteOrders);
    setCustomerLedger(nextLedger);

    try {
      window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
    } catch {
      // Ignore quota errors
    }

    // Record placed order in local device log & todayOrderLocksRef using hashed/HMAC identifiers (no plaintext phone or IP)
    try {
      const orderedProductIds = Array.from(
        new Set(
          (newOrder.items || [])
            .map(it => String(it?.productId || '').trim())
            .filter(Boolean)
        )
      );
      const localPhoneHash = normOrderPhone ? sha256SyncUtf8(normOrderPhone) : '';
      const cachedPhoneHmac = normOrderPhone ? phoneHmacCacheRef.current[normOrderPhone] || '' : '';
      const lockEntry = {
        id: newOrder.id,
        ...(localPhoneHash ? { phoneHash: localPhoneHash } : {}),
        ...(cachedPhoneHmac ? { phoneHmac: cachedPhoneHmac } : {}),
        ...(visitorIpHmacRef.current ? { ipHmac: visitorIpHmacRef.current, ipMatched: true } : {}),
        clientDeviceId,
        createdAt,
        orderStatus: 'pending',
        productIds: orderedProductIds
      };
      todayOrderLocksRef.current = [
        lockEntry,
        ...todayOrderLocksRef.current.filter(l => l.id !== newOrder.id)
      ].slice(0, 300);

      if (typeof window !== 'undefined') {
        const rawLocalLocks = window.localStorage.getItem(DAILY_DEVICE_ORDERS_KEY);
        const parsedLocks = rawLocalLocks ? JSON.parse(rawLocalLocks) : [];
        const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
        const cleanLocks = (Array.isArray(parsedLocks) ? parsedLocks : [])
          .filter((item: any) => item && (Date.parse(String(item.createdAt || '')) || 0) >= cutoff24h)
          .map((item: any) => {
            const { phone: _legacyPhone, clientIp: _legacyIp, ...rest } = item || {};
            const migratedPhoneHash =
              rest.phoneHash || (_legacyPhone ? sha256SyncUtf8(normalizeBdPhone(String(_legacyPhone))) : '');
            return {
              ...rest,
              ...(migratedPhoneHash ? { phoneHash: migratedPhoneHash } : {})
            };
          });
        cleanLocks.unshift(lockEntry);
        window.localStorage.setItem(DAILY_DEVICE_ORDERS_KEY, JSON.stringify(cleanLocks.slice(0, 100)));
      }
    } catch {
      // Ignore storage errors
    }

    if (newOrder.paymentStatus === 'paid') {
      setAccounts(prev => prev.map(acc => {
        if (newOrder.paymentMethod === 'bkash' && acc.type === 'bkash_merchant') {
          return { ...acc, currentBalance: acc.currentBalance + newOrder.grandTotal };
        }
        if (newOrder.paymentMethod === 'nagad' && acc.type === 'nagad_merchant') {
          return { ...acc, currentBalance: acc.currentBalance + newOrder.grandTotal };
        }
        return acc;
      }));
    }

    recordAudit(
      'ONLINE_ORDER_PLACED',
      'ECOMMERCE',
      orderNo,
      `Customer ${newOrder.customerName} (${newOrder.customerPhone}) placed online order ${orderNo} for ৳${newOrder.grandTotal}`
    );

    showToast(
      language === 'bn'
        ? `অর্ডার সফলভাবে সম্পন্ন হয়েছে! অর্ডার নং: ${orderNo}`
        : `Order confirmed! Order #: ${orderNo}`
    );

    // Automatically trigger Customer New Order SMS & Admin New Order Alert SMS via active gateway (Alpha SMS or GreenWeb)
    if (hasBusinessSmsConfigured(currentBusiness)) {
      const itemsSummary = newOrder.items
        .map(it => `${it.productName} x${it.quantity}`)
        .join(', ');

      // 1. Customer Order Confirmation SMS (if enabled, default ON)
      if (currentBusiness.smsOrderConfirmationEnabled !== false) {
        const tpl = currentBusiness.smsOrderPlacedTemplate || DEFAULT_SMS_TEMPLATES.orderPlaced;
        const smsBody = formatSmsMessage(tpl, {
          name: newOrder.customerName,
          order_no: newOrder.orderNo,
          invoice_no: newOrder.invoiceNo,
          total: newOrder.grandTotal,
          status: 'অর্ডার গৃহীত',
          shop_name: currentBusiness.name,
          phone: newOrder.customerPhone,
          address: newOrder.deliveryAddress,
          items: itemsSummary
        });
        sendBusinessSms(currentBusiness, newOrder.customerPhone, smsBody).catch(() => {});
      }

      // 2. Admin New Order Notification SMS (if enabled)
      if (currentBusiness.smsAdminOrderAlertEnabled === true) {
        const adminTargetPhone = (
          currentBusiness.smsAdminOrderAlertPhone ||
          currentBusiness.phone ||
          ''
        ).trim();
        if (adminTargetPhone) {
          const adminTpl =
            currentBusiness.smsAdminOrderAlertTemplate || DEFAULT_SMS_TEMPLATES.adminOrderAlert;
          const adminSmsBody = formatSmsMessage(adminTpl, {
            name: newOrder.customerName,
            order_no: newOrder.orderNo,
            invoice_no: newOrder.invoiceNo,
            total: newOrder.grandTotal,
            status: 'নতুন অর্ডার',
            shop_name: currentBusiness.name,
            phone: newOrder.customerPhone,
            address: newOrder.deliveryAddress,
            items: itemsSummary
          });
          sendBusinessSms(currentBusiness, adminTargetPhone, adminSmsBody).catch(() => {});
        }
      }
    }

    // Automatically push order (Landing Page, Storefront, or Converted Incomplete Order) to WordPress WooCommerce
    syncOrderToWordPress({
      business: currentBusiness,
      order: newOrder,
      productsCatalog: nextProducts
    }).catch(() => {});

    return newOrder;
  };

  const updateOnlineOrderStatus = async (
    orderId: string,
    status: OnlineOrderStatus,
    paymentStatus?: 'unpaid' | 'paid'
  ) => {
    const existing = onlineOrders.find(o => o.id === orderId);
    if (!existing) return;

    const nextPaymentStatus = paymentStatus ?? (status === 'delivered' ? 'paid' : existing.paymentStatus);

    // If order is being cancelled (and wasn't already cancelled), restore stock
    if (status === 'cancelled' && existing.orderStatus !== 'cancelled') {
      const targetOutletId = existing.outletId || 'outlet_01';
      const targetOutlet = outlets.find(o => o.id === targetOutletId) || currentOutlet;
      setProducts(prev => prev.map(prod => {
        const lineItem = existing.items.find(it => it.productId === prod.id);
        if (!lineItem) return prod;
        const cur = prod.stockByOutlet[targetOutletId] ?? 0;
        const nextStock = cur + lineItem.quantity;
        const wac = prod.avgCost ?? prod.purchasePrice;

        setStockMovements(smPrev => [
          {
            id: `sm_web_cancel_${Date.now()}_${prod.id}`,
            businessId: currentBusiness.id,
            outletId: targetOutletId,
            outletName: targetOutlet.name,
            productId: prod.id,
            productName: prod.nameBn,
            sku: prod.sku,
            movementType: 'SALE_RETURN',
            referenceNo: existing.orderNo,
            qtyIn: lineItem.quantity,
            qtyOut: 0,
            balanceAfter: nextStock,
            unitCost: wac,
            wacAfter: wac,
            notes: `অনলাইন অর্ডার বাতিল (#${existing.orderNo}) — স্টক ফেরত`,
            createdBy: currentUser.name,
            createdAt: new Date().toISOString()
          },
          ...smPrev
        ]);

        return {
          ...prod,
          stockByOutlet: {
            ...prod.stockByOutlet,
            [targetOutletId]: nextStock
          }
        };
      }));
    }

    // If payment just transitioned from unpaid to paid, credit the account
    if (existing.paymentStatus === 'unpaid' && nextPaymentStatus === 'paid' && status !== 'cancelled') {
      setAccounts(prev => prev.map(acc => {
        if (existing.paymentMethod === 'cod' && acc.type === 'cash_drawer') {
          return { ...acc, currentBalance: acc.currentBalance + existing.grandTotal };
        }
        if (existing.paymentMethod === 'bkash' && acc.type === 'bkash_merchant') {
          return { ...acc, currentBalance: acc.currentBalance + existing.grandTotal };
        }
        if (existing.paymentMethod === 'nagad' && acc.type === 'nagad_merchant') {
          return { ...acc, currentBalance: acc.currentBalance + existing.grandTotal };
        }
        return acc;
      }));
    }

    setOnlineOrders(prev => prev.map(o =>
      o.id === orderId
        ? {
            ...o,
            orderStatus: status,
            paymentStatus: nextPaymentStatus,
            updatedAt: new Date().toISOString()
          }
        : o
    ));

    // Sync linked ERP Sale status
    setSales(prev => prev.map(s => {
      if (s.invoiceNo !== existing.invoiceNo) return s;
      return {
        ...s,
        paidAmount: nextPaymentStatus === 'paid' ? s.grandTotal : s.paidAmount,
        dueAmount: nextPaymentStatus === 'paid' ? 0 : s.dueAmount,
        status:
          status === 'delivered'
            ? 'delivered'
            : status === 'cancelled'
            ? 'returned'
            : 'dispatched'
      };
    }));

    recordAudit(
      'UPDATE_ONLINE_ORDER',
      'ECOMMERCE',
      existing.orderNo,
      `Updated online order ${existing.orderNo} to status=${status}, payment=${nextPaymentStatus}`
    );

    showToast(
      language === 'bn'
        ? `অর্ডার #${existing.orderNo} এর স্ট্যাটাস আপডেট করা হয়েছে`
        : `Order #${existing.orderNo} updated`
    );

    // Automatically trigger Order Status Update SMS via active gateway (Alpha SMS or GreenWeb) if enabled
    if (
      hasBusinessSmsConfigured(currentBusiness) &&
      currentBusiness.smsOrderStatusUpdateEnabled !== false &&
      existing.orderStatus !== status
    ) {
      const statusBnMap: Record<OnlineOrderStatus, string> = {
        pending: 'অর্ডার গৃহীত (Pending)',
        confirmed: 'অর্ডার কনফার্মড (Confirmed)',
        packaging: 'প্যাকেজিং চলছে (Packaging)',
        dispatched: 'ডেলিভারির পথে (Dispatched)',
        delivered: 'ডেলিভারি সম্পন্ন (Delivered)',
        cancelled: 'বাতিল (Cancelled)'
      };
      const itemsSummary = existing.items
        .map(it => `${it.productName} x${it.quantity}`)
        .join(', ');
      const tpl = currentBusiness.smsOrderStatusTemplate || DEFAULT_SMS_TEMPLATES.orderStatus;
      const smsBody = formatSmsMessage(tpl, {
        name: existing.customerName,
        order_no: existing.orderNo,
        invoice_no: existing.invoiceNo,
        total: existing.grandTotal,
        status: statusBnMap[status] || status,
        shop_name: currentBusiness.name,
        phone: existing.customerPhone,
        address: existing.deliveryAddress,
        items: itemsSummary
      });
      sendBusinessSms(currentBusiness, existing.customerPhone, smsBody).catch(() => {});
    }
  };

  const updateOnlineOrder = (orderId: string, updates: Partial<OnlineOrder>) => {
    const nowIso = new Date().toISOString();
    const targetOrder = onlineOrders.find(o => o.id === orderId);
    const nextOrders = onlineOrders.map(o =>
      o.id === orderId
        ? {
            ...o,
            ...updates,
            updatedAt: nowIso
          }
        : o
    );
    setOnlineOrders(nextOrders);

    let nextSales = sales;
    if (
      targetOrder &&
      (updates.items !== undefined ||
        updates.customerName !== undefined ||
        updates.subtotal !== undefined ||
        updates.discountAmount !== undefined ||
        updates.grandTotal !== undefined)
    ) {
      nextSales = sales.map(s => {
        if (s.invoiceNo !== targetOrder.invoiceNo) return s;
        const nextItems = updates.items !== undefined ? updates.items : s.items;
        const nextCustomerName =
          updates.customerName !== undefined ? updates.customerName : s.customerName;
        const nextCustomerPhone =
          updates.customerPhone !== undefined ? updates.customerPhone : s.customerPhone;
        const nextSub =
          updates.subtotal !== undefined ? updates.subtotal : s.subtotal;
        const nextDiscount =
          updates.discountAmount !== undefined ? updates.discountAmount : s.discountAmount;
        const nextGrand =
          updates.grandTotal !== undefined ? updates.grandTotal : s.grandTotal;
        return {
          ...s,
          customerName: nextCustomerName,
          customerPhone: nextCustomerPhone,
          items: nextItems,
          subtotal: nextSub,
          discountAmount: nextDiscount,
          grandTotal: nextGrand,
          paidAmount: s.paidAmount > 0 ? nextGrand : 0,
          dueAmount: s.paidAmount > 0 ? 0 : nextGrand
        };
      });
      setSales(nextSales);
    }

    if (targetOrder) {
      recordAudit(
        'EDIT_ONLINE_ORDER',
        'ECOMMERCE',
        targetOrder.orderNo,
        `Edited online order #${targetOrder.orderNo} (${updates.customerName || targetOrder.customerName}, Total: ৳${updates.grandTotal ?? targetOrder.grandTotal})`
      );
    }
  };

  const checkDailyOrderLimit = (
    phone: string,
    productIds?: string[]
  ): DailyOrderLimitCheckResult => {
    const isEnabled = currentBusiness.dailyOrderLimitEnabled !== false;
    const sameProductMaxCount = Math.max(
      1,
      Number(currentBusiness.dailySameProductMaxCount ?? 2)
    );
    const rawTotalMax = currentBusiness.dailyOrderMaxCount;
    const maxCount = Math.max(
      1,
      Number(
        currentBusiness.dailySameProductMaxCount === undefined &&
          (rawTotalMax === undefined || rawTotalMax === 2)
          ? 5
          : (rawTotalMax ?? 5)
      )
    );
    const title =
      (currentBusiness.dailyOrderLimitTitle || '').trim() || DEFAULT_DAILY_ORDER_LIMIT_TITLE;
    const message =
      (currentBusiness.dailyOrderLimitMessage || '').trim() || DEFAULT_DAILY_ORDER_LIMIT_MESSAGE;

    if (!isEnabled) {
      return {
        blocked: false,
        count: 0,
        maxCount,
        sameProductCount: 0,
        sameProductMaxCount,
        title,
        message
      };
    }

    const normPhone = normalizeBdPhone(phone);
    const targetProductIds = Array.from(
      new Set((Array.isArray(productIds) ? productIds : []).map(id => String(id || '').trim()).filter(Boolean))
    );
    const nowDate = new Date();
    const startOfTodayMs = new Date(
      nowDate.getFullYear(),
      nowDate.getMonth(),
      nowDate.getDate()
    ).getTime();
    const resetAtMs = Number(currentBusiness.dailyOrderLimitResetAt || 0);
    const effectiveCutoffMs = Math.max(startOfTodayMs, resetAtMs);

    const clientDeviceId = getOrCreateClientDeviceId();
    const visitorIpHmac = (visitorIpHmacRef.current || '').trim();
    const targetPhoneHash = normPhone ? sha256SyncUtf8(normPhone) : '';
    const targetPhoneHmac = normPhone ? (phoneHmacCacheRef.current[normPhone] || '').trim() : '';

    const cancelledIds = new Set<string>();
    const orderProductIdsById = new Map<string, string[]>();
    for (const o of onlineOrders) {
      if (!o) continue;
      const oid = String(o.id || o.orderNo || '').trim();
      if (o.orderStatus === 'cancelled' && oid) {
        cancelledIds.add(oid);
        if (o.id) cancelledIds.add(String(o.id));
        if (o.orderNo) cancelledIds.add(String(o.orderNo));
      } else if (oid && Array.isArray(o.items)) {
        const pids = Array.from(
          new Set(o.items.map(it => String(it?.productId || '').trim()).filter(Boolean))
        );
        orderProductIdsById.set(oid, pids);
      }
    }

    const phoneOrderIds = new Set<string>();
    const deviceOrIpOrderIds = new Set<string>();
    const phoneProductOrdersMap = new Map<string, Set<string>>();
    const deviceProductOrdersMap = new Map<string, Set<string>>();

    const addProductOrderRef = (map: Map<string, Set<string>>, pid: string, orderId: string) => {
      if (!pid || !orderId) return;
      let set = map.get(pid);
      if (!set) {
        set = new Set<string>();
        map.set(pid, set);
      }
      set.add(orderId);
    };

    const inspectRecord = (rec: {
      id?: string;
      phone?: string;
      phoneHash?: string;
      phoneHmac?: string;
      ipHmac?: string;
      ipMatched?: boolean;
      clientDeviceId?: string;
      createdAt?: string;
      orderStatus?: string;
      productIds?: string[];
    }) => {
      if (!rec || rec.orderStatus === 'cancelled') return;
      const rid = String(rec.id || '').trim();
      if (!rid || cancelledIds.has(rid)) return;
      const ts = Date.parse(String(rec.createdAt || '')) || 0;
      if (ts < effectiveCutoffMs) return;

      const recProductIds =
        Array.isArray(rec.productIds) && rec.productIds.length > 0
          ? rec.productIds
          : orderProductIdsById.get(rid) || [];

      const recPhone = normalizeBdPhone(String(rec.phone || ''));
      const recPhoneHash = String(rec.phoneHash || '').trim().toLowerCase();
      const recPhoneHmac = String(rec.phoneHmac || '').trim().toLowerCase();
      const isPhoneMatch =
        Boolean(normPhone && recPhone && recPhone === normPhone) ||
        Boolean(targetPhoneHash && recPhoneHash && recPhoneHash === targetPhoneHash) ||
        Boolean(targetPhoneHmac && recPhoneHmac && recPhoneHmac === targetPhoneHmac);
      if (isPhoneMatch) {
        phoneOrderIds.add(rid);
        for (const pid of recProductIds) {
          addProductOrderRef(phoneProductOrdersMap, String(pid).trim(), rid);
        }
      }

      const recDev = String(rec.clientDeviceId || '').trim();
      const recIpHmac = String(rec.ipHmac || '').trim().toLowerCase();
      const isDeviceOrIpMatch =
        Boolean(clientDeviceId && recDev && recDev === clientDeviceId) ||
        Boolean(rec.ipMatched === true) ||
        Boolean(visitorIpHmac && recIpHmac && recIpHmac === visitorIpHmac.toLowerCase());
      if (isDeviceOrIpMatch) {
        deviceOrIpOrderIds.add(rid);
        for (const pid of recProductIds) {
          addProductOrderRef(deviceProductOrdersMap, String(pid).trim(), rid);
        }
      }
    };

    for (const o of onlineOrders) {
      const oid = String(o.id || o.orderNo || '').trim();
      inspectRecord({
        id: oid,
        phone: o.customerPhone,
        clientDeviceId: o.clientDeviceId,
        createdAt: o.createdAt,
        orderStatus: o.orderStatus,
        productIds: orderProductIdsById.get(oid) || []
      });
    }

    for (const l of todayOrderLocksRef.current) {
      inspectRecord(l);
    }

    if (typeof window !== 'undefined') {
      try {
        const rawLocal = window.localStorage.getItem(DAILY_DEVICE_ORDERS_KEY);
        if (rawLocal) {
          const parsed = JSON.parse(rawLocal);
          if (Array.isArray(parsed)) {
            for (const item of parsed) {
              inspectRecord({
                ...item,
                clientDeviceId: item?.clientDeviceId || clientDeviceId
              });
            }
          }
        }
      } catch {
        // Ignore storage read error
      }
    }

    const phoneCount = phoneOrderIds.size;
    const deviceCount = deviceOrIpOrderIds.size;
    const highestCount = Math.max(phoneCount, deviceCount);

    // Rule 1: Same Product Limit (Default: 2 orders of the exact same product per day)
    let highestSameProductCount = 0;
    if (targetProductIds.length > 0) {
      for (const pid of targetProductIds) {
        const pSameCount = phoneProductOrdersMap.get(pid)?.size || 0;
        const dSameCount = deviceProductOrdersMap.get(pid)?.size || 0;
        const curMaxSame = Math.max(pSameCount, dSameCount);
        if (curMaxSame > highestSameProductCount) {
          highestSameProductCount = curMaxSame;
        }
        if (pSameCount >= sameProductMaxCount) {
          return {
            blocked: true,
            count: Math.max(phoneCount, pSameCount),
            maxCount,
            sameProductCount: pSameCount,
            sameProductMaxCount,
            blockType: 'same_product',
            title,
            message,
            reason: 'phone'
          };
        }
        if (dSameCount >= sameProductMaxCount) {
          return {
            blocked: true,
            count: Math.max(deviceCount, dSameCount),
            maxCount,
            sameProductCount: dSameCount,
            sameProductMaxCount,
            blockType: 'same_product',
            title,
            message,
            reason: 'ip_or_device'
          };
        }
      }
    }

    // Rule 2: Total Daily Limit across all/other products (Default: 5 total orders per day)
    if (phoneCount >= maxCount) {
      return {
        blocked: true,
        count: phoneCount,
        maxCount,
        sameProductCount: highestSameProductCount,
        sameProductMaxCount,
        blockType: 'total_daily',
        title,
        message,
        reason: 'phone'
      };
    }

    if (deviceCount >= maxCount) {
      return {
        blocked: true,
        count: deviceCount,
        maxCount,
        sameProductCount: highestSameProductCount,
        sameProductMaxCount,
        blockType: 'total_daily',
        title,
        message,
        reason: 'ip_or_device'
      };
    }

    return {
      blocked: false,
      count: highestCount,
      maxCount,
      sameProductCount: highestSameProductCount,
      sameProductMaxCount,
      title,
      message
    };
  };

  /**
   * Authoritative server-side daily order-limit validation via /api/order-limit-check (Node.js)
   * or /api/index.php?route=order-limit-check (PHP). Caches the server's HMAC-SHA256 for the phone
   * number and visitor IP so synchronous checkDailyOrderLimit stays in sync.
   */
  const verifyDailyOrderLimitServer = async (
    phone: string,
    productIds?: string[]
  ): Promise<DailyOrderLimitCheckResult> => {
    const normPhone = normalizeBdPhone(phone);
    const clientDeviceId = getOrCreateClientDeviceId();
    const targetProductIds = Array.from(
      new Set((Array.isArray(productIds) ? productIds : []).map(id => String(id || '').trim()).filter(Boolean))
    );

    const endpoints = [
      '/api/order-limit-check',
      '/api/index.php?route=order-limit-check',
      './api/index.php?route=order-limit-check'
    ];

    for (const url of endpoints) {
      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          },
          body: JSON.stringify({
            phone: normPhone,
            clientDeviceId,
            productIds: targetProductIds
          })
        });
        if (res.ok) {
          const data = await res.json().catch(() => null);
          if (data && data.success === true) {
            if (typeof data.phoneHmac === 'string' && data.phoneHmac && normPhone) {
              phoneHmacCacheRef.current[normPhone] = data.phoneHmac.trim().toLowerCase();
            }
            if (typeof data.visitorIpHmac === 'string' && data.visitorIpHmac) {
              visitorIpHmacRef.current = data.visitorIpHmac.trim().toLowerCase();
            }
            const localEval = checkDailyOrderLimit(normPhone, targetProductIds);
            if (data.blocked) {
              return {
                blocked: true,
                count: Number(data.count ?? localEval.count),
                maxCount: Number(data.maxCount ?? localEval.maxCount),
                sameProductCount: Number(data.sameProductCount ?? localEval.sameProductCount),
                sameProductMaxCount: Number(data.sameProductMaxCount ?? localEval.sameProductMaxCount),
                blockType: data.blockType || localEval.blockType || 'same_product',
                title: data.title || localEval.title,
                message: data.message || localEval.message,
                reason: data.reason || localEval.reason || 'phone'
              };
            }
            return localEval;
          }
        }
      } catch {
        // Try next endpoint
      }
    }

    return checkDailyOrderLimit(normPhone, targetProductIds);
  };

  // Upsert Incomplete Order / Abandoned Checkout Lead in real time as customer fills Checkout form
  const upsertIncompleteOrder = (data: {
    sessionKey: string;
    customerName: string;
    customerPhone: string;
    deliveryArea: string;
    deliveryAddress: string;
    deliverySlot: string;
    items: SaleItem[];
    subtotal: number;
    deliveryCharge: number;
    grandTotal: number;
    fbLeadSent?: boolean;
    fbp?: string;
    fbc?: string;
    externalId?: string;
    clientIp?: string;
    clientUserAgent?: string;
    eventSourceUrl?: string;
    orderSource?: 'landing_page' | 'storefront';
    landingSlug?: string;
    notes?: string;
  }) => {
    const normPhone = normalizeBdPhone(data.customerPhone);
    // Strictly require a valid 11-digit BD mobile number (if user entered 10 digits starting with 1, normalizeBdPhone already prepended 0)
    if (!isValidBdPhone11(normPhone)) return;
    if (!data.items || data.items.length === 0) return;

    // Pre-warm server-side phoneHmac for daily order limit matching as soon as customer types their 11-digit phone
    if (!phoneHmacCacheRef.current[normPhone]) {
      verifyDailyOrderLimitServer(
        normPhone,
        data.items.map(it => it.productId).filter(Boolean)
      ).catch(() => {});
    }

    const nowIso = new Date().toISOString();
    const resolvedClientIp = data.clientIp || visitorClientIpRef.current || undefined;
    const resolvedClientUa =
      data.clientUserAgent ||
      (typeof navigator !== 'undefined' ? navigator.userAgent : undefined);

    // 1. Compute nextIncompleteOrders synchronously (matching by sessionKey OR normalized 11-digit phone so no duplicate row is ever created)
    const existingIdx = incompleteOrders.findIndex(item => {
      const itemPhone = normalizeBdPhone(item.customerPhone);
      return item.sessionKey === data.sessionKey || itemPhone === normPhone;
    });

    let nextIncompleteOrders: IncompleteOrder[];
    if (existingIdx !== -1) {
      const existing = incompleteOrders[existingIdx];
      // If customer is updating their own active checkout session, update details; if they had an old converted/ignored lead and started a new session, reopen as 'abandoned'
      const nextStatus: IncompleteOrderStatus =
        existing.sessionKey === data.sessionKey
          ? existing.status
          : existing.status === 'converted' || existing.status === 'ignored'
          ? 'abandoned'
          : existing.status;

      const updated: IncompleteOrder = {
        ...existing,
        sessionKey: data.sessionKey || existing.sessionKey,
        customerName: data.customerName.trim() || existing.customerName || 'অসম্পূর্ণ অর্ডার ক্রেতা',
        customerPhone: normPhone,
        deliveryArea: data.deliveryArea || existing.deliveryArea,
        deliveryAddress: data.deliveryAddress.trim() || existing.deliveryAddress,
        deliverySlot: data.deliverySlot || existing.deliverySlot,
        items: data.items,
        subtotal: data.subtotal,
        deliveryCharge: data.deliveryCharge,
        grandTotal: data.grandTotal,
        status: nextStatus,
        fbLeadSent: existing.fbLeadSent || data.fbLeadSent,
        fbp: data.fbp || existing.fbp,
        fbc: data.fbc || existing.fbc,
        externalId: data.externalId || existing.externalId,
        clientIp: resolvedClientIp || existing.clientIp,
        clientUserAgent: resolvedClientUa || existing.clientUserAgent,
        eventSourceUrl: data.eventSourceUrl || existing.eventSourceUrl,
        orderSource: data.orderSource || existing.orderSource,
        landingSlug: data.landingSlug || existing.landingSlug,
        notes: data.notes ?? existing.notes,
        updatedAt: nowIso
      };
      nextIncompleteOrders = [...incompleteOrders];
      nextIncompleteOrders[existingIdx] = updated;
    } else {
      const created: IncompleteOrder = {
        id: `inc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        sessionKey: data.sessionKey,
        businessId: currentBusiness.id,
        customerName: data.customerName.trim() || 'অসম্পূর্ণ অর্ডার ক্রেতা',
        customerPhone: normPhone,
        deliveryArea: data.deliveryArea || 'ঢাকার ভিতরে (Inside Dhaka)',
        deliveryAddress: data.deliveryAddress.trim() || '',
        deliverySlot: data.deliverySlot || '',
        items: data.items,
        subtotal: data.subtotal,
        deliveryCharge: data.deliveryCharge,
        grandTotal: data.grandTotal,
        status: 'abandoned',
        fbLeadSent: Boolean(data.fbLeadSent),
        fbp: data.fbp,
        fbc: data.fbc,
        externalId: data.externalId,
        clientIp: resolvedClientIp,
        clientUserAgent: resolvedClientUa,
        eventSourceUrl: data.eventSourceUrl,
        orderSource: data.orderSource,
        landingSlug: data.landingSlug,
        notes: data.notes,
        createdAt: nowIso,
        updatedAt: nowIso
      };
      nextIncompleteOrders = [created, ...incompleteOrders].slice(0, 300);
    }

    // 2. Compute nextCustomers synchronously so lead 11-digit phone number & name are stored in Customers too
    const custIdx = customers.findIndex(c => normalizeBdPhone(c.phone) === normPhone);
    let nextCustomers: Customer[];
    if (custIdx !== -1) {
      const cur = customers[custIdx];
      const nextName = data.customerName.trim() || cur.name;
      const nextAddr = data.deliveryAddress.trim() || cur.address;
      nextCustomers = [...customers];
      nextCustomers[custIdx] = {
        ...cur,
        name: nextName,
        phone: normPhone,
        address: nextAddr,
        isOnlineCustomer: true,
        updatedAt: nowIso
      };
    } else {
      const newCust: Customer = {
        id: `cust_lead_${normPhone}`,
        businessId: currentBusiness.id,
        name: data.customerName.trim() || 'চেকআউট ভিজিটর (Lead)',
        phone: normPhone,
        address: data.deliveryAddress.trim() || 'অসম্পূর্ণ চেকআউট',
        route: data.deliveryArea || 'অনলাইন চেকআউট লিড',
        customerType: 'online',
        isOnlineCustomer: true,
        creditLimit: 0,
        currentDue: 0,
        createdAt: nowIso.slice(0, 10),
        updatedAt: nowIso
      };
      nextCustomers = [newCust, ...customers];
    }

    liveStateRef.current = {
      ...liveStateRef.current,
      incompleteOrders: nextIncompleteOrders,
      customers: nextCustomers
    };
    setIncompleteOrders(nextIncompleteOrders);
    setCustomers(nextCustomers);

    // 3. Immediately persist & push to server with keepalive=true
    const now = Date.now();
    lastSavedAtRef.current = now;
    const snap: PersistedErpState = {
      ...buildSnapshot(now),
      incompleteOrders: nextIncompleteOrders,
      customers: nextCustomers
    };
    try {
      window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
    } catch {
      // Ignore storage quota errors
    }
    notifySameBrowserTabs(now);
    pushStateToServer(snap, true);
  };

  const updateIncompleteOrderStatus = (id: string, status: IncompleteOrderStatus) => {
    const nextIncomplete = incompleteOrders.map(inc => {
      if (inc.id !== id) return inc;
      const prevTs = Date.parse(String(inc.updatedAt || inc.createdAt || '')) || 0;
      const safeNextTs = Math.max(Date.now(), prevTs + 2000);
      return {
        ...inc,
        status,
        updatedAt: new Date(safeNextTs).toISOString()
      };
    });
    setIncompleteOrders(nextIncomplete);

    const now = Date.now();
    lastSavedAtRef.current = now;
    const snap: PersistedErpState = {
      ...buildSnapshot(now),
      incompleteOrders: nextIncomplete
    };
    try {
      window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
    } catch {
      // Ignore
    }
    notifySameBrowserTabs(now);
    pushStateToServer(snap, true);

    showToast(
      language === 'bn'
        ? status === 'contacted'
          ? 'স্ট্যাটাস "কথা হয়েছে (Contacted)"-এ সরানো হয়েছে'
          : 'অসম্পূর্ণ অর্ডারের স্ট্যাটাস আপডেট করা হয়েছে'
        : 'Incomplete order status updated',
      'success'
    );
  };

  const deleteIncompleteOrder = (id: string) => {
    const target = incompleteOrders.find(inc => inc.id === id);
    setDeleteConfirmModal({
      title: 'অসম্পূর্ণ অর্ডার ডিলিট নিশ্চিতকরণ (Delete Warning)',
      itemName: target
        ? `${target.customerName || 'ক্রেতা'} · ${target.customerPhone}`
        : id,
      message: `আপনি কি নিশ্চিতভাবে "${target?.customerName || 'ক্রেতা'} (${target?.customerPhone || ''})"-এর এই অসম্পূর্ণ অর্ডারটি স্থায়ীভাবে ডিলিট করতে চান?`,
      onConfirm: () => {
        const targetNormPhone = target ? normalizeBdPhone(target.customerPhone) : '';
        const nextIncomplete = incompleteOrders.filter(inc => inc.id !== id);
        const idsToDelete = [id];
        if (targetNormPhone) {
          idsToDelete.push(`inc_rec_cust_lead_${targetNormPhone}`);
        }
        const nextDeleted = Array.from(
          new Set([...deletedIncompleteOrderIds, ...idsToDelete])
        ).slice(-500);
        setIncompleteOrders(nextIncomplete);
        setDeletedIncompleteOrderIds(nextDeleted);

        const now = Date.now();
        lastSavedAtRef.current = now;
        const snap: PersistedErpState = {
          ...buildSnapshot(now),
          incompleteOrders: nextIncomplete,
          deletedIncompleteOrderIds: nextDeleted
        };
        try {
          window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(snap));
        } catch {
          // Ignore
        }
        notifySameBrowserTabs(now);
        pushStateToServer(snap, true);

        showToast(
          language === 'bn'
            ? 'অসম্পূর্ণ অর্ডারটি মুছে ফেলা হয়েছে'
            : 'Incomplete order deleted',
          'info'
        );
      }
    });
  };

  // 1-Click Admin Recovery: Convert an Incomplete / Abandoned Checkout directly into a real Online Order
  const convertIncompleteToOrder = async (id: string): Promise<OnlineOrder | null> => {
    const target = incompleteOrders.find(inc => inc.id === id);
    if (!target) return null;

    const createdOrder = await placeOnlineOrder({
      businessId: currentBusiness.id,
      outletId: currentOutlet.id || 'outlet_01',
      customerName: target.customerName || 'অনলাইন ক্রেতা',
      customerPhone: target.customerPhone,
      deliveryArea: target.deliveryArea || 'ঢাকার ভিতরে (Inside Dhaka)',
      deliveryAddress: target.deliveryAddress || 'ফোনে কনফার্মকৃত ঠিকানা',
      deliverySlot: target.deliverySlot || 'এক্সপ্রেস ডেলিভারি',
      items: target.items,
      subtotal: target.subtotal,
      deliveryCharge: target.deliveryCharge,
      discountAmount: 0,
      grandTotal: target.grandTotal,
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      orderSource: target.orderSource || 'incomplete_recovery',
      landingSlug: target.landingSlug,
      fbp: target.fbp,
      fbc: target.fbc,
      fbExternalId: target.externalId || target.customerPhone,
      clientIp: target.clientIp,
      clientUserAgent: target.clientUserAgent,
      eventSourceUrl: target.eventSourceUrl,
      notes: target.notes
        ? `${target.notes} (অসম্পূর্ণ অর্ডার থেকে কনফার্মকৃত)`
        : 'অসম্পূর্ণ অর্ডার (Abandoned Checkout) থেকে ফোনে কনফার্মকৃত'
    });

    const isInsideDhakaArea =
      Boolean(target.deliveryArea) &&
      (target.deliveryArea.includes('ঢাকার ভিতরে') ||
        target.deliveryArea.toLowerCase().includes('inside dhaka'));
    const recoveredCity = isInsideDhakaArea
      ? extractLocationForMeta(target.deliveryAddress || '', 'dhaka').ct
      : extractLocationForMeta(target.deliveryAddress || '').ct;

    // Server-Only CAPI Purchase: Do NOT fire Browser Pixel from Admin's browser, and strictly use the customer's original IP, UA, _fbp, _fbc, and externalId
    trackFacebookEvent({
      business: currentBusiness,
      eventName: 'Purchase',
      eventIdOverride: createdOrder.fbEventId || generateMetaEventId('Purchase', createdOrder.orderNo),
      eventSourceUrlOverride: sanitizeCustomerEventSourceUrl(target.eventSourceUrl),
      serverOnly: true,
      customer: {
        name: createdOrder.customerName,
        phone: createdOrder.customerPhone,
        address: createdOrder.deliveryAddress,
        city: recoveredCity || undefined,
        externalId: target.externalId,
        fbp: target.fbp,
        fbc: target.fbc,
        clientIp: target.clientIp,
        clientUserAgent: target.clientUserAgent
      },
      customData: buildMetaOrderItemsCustomData({
        items: createdOrder.items,
        orderId: createdOrder.orderNo,
        totalValue: createdOrder.grandTotal,
        orderSource: target.orderSource || 'incomplete_recovery'
      })
    }).catch(() => {});

    setIncompleteOrders(prev =>
      prev.map(inc =>
        inc.id === id
          ? {
              ...inc,
              status: 'converted',
              convertedOrderNo: createdOrder.orderNo,
              updatedAt: new Date().toISOString()
            }
          : inc
      )
    );

    return createdOrder;
  };

  const clearWebsiteCache = async (
    mode: 'soft_clear' | 'hard_reload' | 'reset_storefront_cache'
  ): Promise<{ cacheVersion?: string; opcacheCleared?: boolean }> => {
    // 1. Clear Browser CacheStorage API (if supported)
    if (typeof window !== 'undefined' && 'caches' in window) {
      try {
        const cacheNames = await window.caches.keys();
        await Promise.all(cacheNames.map(name => window.caches.delete(name)));
      } catch {
        // Ignore CacheStorage error
      }
    }

    // 2. Unregister any stale Service Workers
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      try {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(reg => reg.unregister()));
      } catch {
        // Ignore SW error
      }
    }

    // 3. Clear SessionStorage & temporary localStorage keys while preserving Admin Panel navigation & Auth
    if (typeof window !== 'undefined') {
      try {
        const activeRouteMode = window.sessionStorage.getItem('stockmaster_active_route_mode_v1');
        const activeErpView = window.sessionStorage.getItem('stockmaster_active_erp_view_v1');
        window.sessionStorage.clear();
        if (activeRouteMode) {
          window.sessionStorage.setItem('stockmaster_active_route_mode_v1', activeRouteMode);
        }
        if (activeErpView) {
          window.sessionStorage.setItem('stockmaster_active_erp_view_v1', activeErpView);
        }

        const tempKeysToRemove: string[] = [];
        for (let i = 0; i < window.localStorage.length; i++) {
          const k = window.localStorage.key(i);
          if (
            k &&
            (k === 'sm_boot_theme_meta_v1' ||
              k === 'stockmaster_fb_event_logs_v1' ||
              k === 'stockmaster_fb_retry_queue_v1' ||
              k === 'stockmaster_sms_logs_v1' ||
              k.includes('cart') ||
              k.includes('temp') ||
              k.includes('draft') ||
              k.includes('filter'))
          ) {
            tempKeysToRemove.push(k);
          }
        }
        tempKeysToRemove.forEach(k => window.localStorage.removeItem(k));

        // Immediately rebuild sm_boot_theme_meta_v1 with the latest currentBusiness logo, name, and theme
        const isWinter =
          Boolean(currentBusiness?.winterThemeEnabled) ||
          currentBusiness?.storefrontTheme === 'winter_frost';
        const resolvedTheme = isWinter
          ? 'winter_frost'
          : currentBusiness?.storefrontTheme || 'emerald_default';
        window.localStorage.setItem(
          'sm_boot_theme_meta_v1',
          JSON.stringify({
            theme: resolvedTheme,
            shopName: currentBusiness?.name || 'কিডস অ্যান্ড ফ্যাশন মার্ট',
            logoUrl: currentBusiness?.logoUrl || '',
            phone: currentBusiness?.phone || '',
            topBarEnabled: currentBusiness?.topAnnouncementEnabled !== false,
            topBarText:
              currentBusiness?.topAnnouncementText ??
              'সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে পেমেন্ট করুন'
          })
        );
      } catch {
        // Ignore storage error
      }
    }

    // 4. If mode is reset_storefront_cache, reset products, categories, brands & deletedProductIds in React state, localStorage, AND server
    const nowTs = Date.now();
    if (mode === 'reset_storefront_cache') {
      isApplyingServerStateRef.current = true;
      setDeletedProductIds([]);
      setCategories(initialCategories);
      setBrands(initialBrands);
      setProducts(initialProducts);
      liveStateRef.current.deletedProductIds = [];
      liveStateRef.current.categories = initialCategories;
      liveStateRef.current.brands = initialBrands;
      liveStateRef.current.products = initialProducts;
      lastSavedAtRef.current = nowTs;
      lastProcessedLocalStampRef.current = nowTs;

      const freshSnapshot: PersistedErpState = {
        ...buildSnapshot(nowTs),
        updatedAt: nowTs,
        _isAdminMutation: true,
        categories: initialCategories,
        brands: initialBrands,
        products: initialProducts,
        deletedProductIds: []
      };

      try {
        window.localStorage.setItem(ERP_STATE_STORAGE_KEY, JSON.stringify(freshSnapshot));
      } catch {
        // Ignore quota error
      }
      await pushStateToServer(freshSnapshot);
      setTimeout(() => {
        isApplyingServerStateRef.current = false;
      }, 80);
    }

    // 5. Call Server-Side Cache Flush (/api/index.php?route=clear-cache & /api/clear-cache)
    // Flushes PHP OPcache, LiteSpeed Cache, and bumps global cacheVersion so all visitors' browsers also refresh
    let serverCacheResult: { cacheVersion?: string; opcacheCleared?: boolean } = {};
    const clearEndpoints = [
      './api/index.php?route=clear-cache',
      '/api/index.php?route=clear-cache',
      `${API_CONFIG.BASE_URL}/clear-cache`
    ];
    for (const url of clearEndpoints) {
      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            ...getClientAdminTokenHeaders()
          },
          credentials: 'same-origin',
          cache: 'no-store',
          body: JSON.stringify({
            mode,
            ...(mode === 'reset_storefront_cache'
              ? {
                  products: initialProducts,
                  categories: initialCategories,
                  brands: initialBrands
                }
              : {})
          })
        });
        if (res.ok) {
          const json = await res.json().catch(() => null);
          if (json && json.success) {
            serverCacheResult = {
              cacheVersion: json.cacheVersion,
              opcacheCleared: Boolean(json.opcacheCleared)
            };
            if (json.cacheVersion && typeof window !== 'undefined') {
              try {
                window.localStorage.setItem(CLIENT_CACHE_VERSION_KEY, String(json.cacheVersion));
              } catch {
                // Ignore
              }
            }
            break;
          }
        }
      } catch {
        // Try next endpoint
      }
    }

    // 6. Force fresh server sync or hard reload prep
    lastProcessedServerStampRef.current = -1;
    if (mode === 'hard_reload') {
      // Remove stale local ERP copy so on reload it pulls 100% authoritative state from the server/MySQL DB
      try {
        window.localStorage.removeItem(ERP_STATE_STORAGE_KEY);
      } catch {
        // Ignore
      }
    } else if (mode === 'soft_clear') {
      await syncStateFromServer();
    }

    notifySameBrowserTabs(Date.now());
    return serverCacheResult;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        businesses,
        currentBusiness,
        setCurrentBusinessId,
        updateBusiness,
        outlets,
        currentOutlet,
        setCurrentOutletId,
        addOutlet,
        updateOutlet,
        deleteOutlet,
        users,
        currentUser,
        setCurrentUserId,
        isAuthenticated,
        login,
        quickLogin,
        logout,
        addUser,
        updateUser,
        deleteUser,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        brands,
        addBrand,
        deleteBrand,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        sales,
        addSale,
        onlineOrders,
        placeOnlineOrder,
        updateOnlineOrderStatus,
        updateOnlineOrder,
        checkDailyOrderLimit,
        verifyDailyOrderLimitServer,
        incompleteOrders,
        upsertIncompleteOrder,
        updateIncompleteOrderStatus,
        deleteIncompleteOrder,
        convertIncompleteToOrder,
        saleReturns,
        addSaleReturn,
        purchases,
        addPurchase,
        purchaseReturns,
        addPurchaseReturn,
        customers,
        customerLedger,
        addCustomer,
        updateCustomer,
        registerOrUpdateOnlineCustomer,
        collectCustomerDue,
        suppliers,
        addSupplier,
        paySupplier,
        expenses,
        addExpense,
        accounts,
        salesReps,
        stockTransfers,
        addStockTransfer,
        stockAdjustments,
        addStockAdjustment,
        stockMovements,
        auditLogs,
        dayEndClosures,
        closeDayEnd,
        heldCarts,
        holdCart,
        restoreHeldCart,
        removeHeldCart,
        toasts,
        showToast,
        globalSearch,
        setGlobalSearch,
        dateRange,
        setDateRange,
        formatCurrency,
        formatDate,
        isServerHydrated,
        confirmDelete,
        clearWebsiteCache
      }}
    >
      {children}

      {/* Global Simple Delete Confirmation Modal */}
      {deleteConfirmModal && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-page-rise"
          onClick={() => {
            if (!isExecutingDelete) setDeleteConfirmModal(null);
          }}
        >
          <div
            className="bg-white rounded-2xl max-w-xs sm:max-w-sm w-full p-5 border border-slate-200 shadow-2xl text-center"
            onClick={e => e.stopPropagation()}
          >
            <div className="w-11 h-11 rounded-full bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-3">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-5 h-5"
              >
                <path d="M3 6h18" />
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                <path d="M8 6V4c0-1 1-2 2-2h4c0 1 1 2 2 2v2" />
              </svg>
            </div>

            <h3 className="text-base font-extrabold text-slate-900">
              আপনি কি ডিলিট করতে চান?
            </h3>

            {deleteConfirmModal.itemName && (
              <p className="mt-1.5 text-xs font-semibold text-slate-600 line-clamp-2 px-2">
                {deleteConfirmModal.itemName}
              </p>
            )}

            <div className="grid grid-cols-2 gap-2.5 mt-5">
              <button
                type="button"
                disabled={isExecutingDelete}
                onClick={() => setDeleteConfirmModal(null)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-bold transition-colors cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isExecutingDelete}
                onClick={async () => {
                  try {
                    setIsExecutingDelete(true);
                    await deleteConfirmModal.onConfirm();
                  } finally {
                    setIsExecutingDelete(false);
                    setDeleteConfirmModal(null);
                  }
                }}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-bold shadow-sm transition-colors cursor-pointer"
              >
                {isExecutingDelete ? 'ডিলিট হচ্ছে...' : 'হ্যাঁ, ডিলিট'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Toast Notifications */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`pointer-events-auto px-4 py-3 rounded-lg shadow-lg text-sm font-medium flex items-center justify-between border ${
              toast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-800'
                : toast.type === 'info'
                ? 'bg-slate-900 text-white border-slate-800'
                : 'bg-emerald-950 text-emerald-100 border-emerald-800'
            }`}
          >
            <span>{toast.message}</span>
          </div>
        ))}
      </div>
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
