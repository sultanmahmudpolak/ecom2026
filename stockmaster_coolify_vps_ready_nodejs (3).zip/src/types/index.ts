export type Language = 'bn' | 'en';

export type ProductPageVariantDesign =
  | 'classic_inline'
  | 'stacked_card'
  | 'price_badge'
  | 'minimal_check';

export type LandingVariantDesign =
  | 'classic_radio_list'
  | 'mobile_grid_chips'
  | 'pill_capsules'
  | 'stacked_offer_cards'
  | 'royal_crimson_tabs'
  | 'compact_segmented_bar'
  | 'royal_crimson_clean'
  | 'royal_luxury_gift'
  | 'lp2_red_measurement_grid';

export type LandingImageBadgeDesign =
  | 'classic_red'
  | 'crimson_gold'
  | 'circle_seal'
  | 'royal_dark_gold'
  | 'emerald_flash'
  | 'minimal_percent';

export type StockOutBadgeDesign =
  | 'center_glass'
  | 'diagonal_ribbon'
  | 'bottom_banner'
  | 'classic_corner';

export type BanglaFontStyle =
  | 'noto_sans'
  | 'anek_bangla'
  | 'hind_siliguri'
  | 'baloo_da_2'
  | 'tiro_bangla'
  | 'noto_serif_bengali'
  | 'mina'
  | 'atma'
  | 'galada'
  | 'kalpurush'
  | 'kalpurush_bold'
  | 'solaiman_lipi'
  | 'solaiman_lipi_bold'
  | 'adorsho_lipi'
  | 'nikosh';

export type StorefrontThemeStyle =
  | 'emerald_default'
  | 'winter_frost'
  | 'summer_mango'
  | 'ramadan_noor'
  | 'eid_festive'
  | 'cool_blue'
  | 'royal_crimson'
  | 'ocean_indigo'
  | 'royal_purple'
  | 'sunset_coral'
  | 'rose_magenta'
  | 'coffee_bronze'
  | 'luxury_midnight';

export type OrderCelebrationStyle =
  | 'dual_cannon_badge'
  | 'royal_fireworks'
  | 'luxury_gold_fountain'
  | 'festive_balloons'
  | 'ramadan_noor_lanterns'
  | 'eid_mubarak_royal';

export type UserRole = 
  | 'developer'         // সিস্টেম ডেভেলপার (cPanel + MySQL Setup & Download Only)
  | 'super_admin'       // সুপার অ্যাডমিন (মালিক)
  | 'store_manager'     // স্টোর ম্যানেজার
  | 'cashier'           // পিওএস ক্যাশিয়ার
  | 'distribution_mgr'  // ডিস্ট্রিবিউশন ম্যানেজার
  | 'sales_rep';        // সেলস রিপ্রেজেন্টেটিভ / অডিটর

export interface User {
  id: string;
  name: string;
  username?: string;
  phone: string;
  email: string;
  password?: string;
  role: UserRole;
  businessId: string;
  avatar?: string;
  outletId?: string;
}

export interface Business {
  id: string;
  name: string;
  nameEn: string;
  businessType: 'supershop_and_distribution' | 'retail_only' | 'distribution_only';
  taxId: string; // BIN / TIN
  phone: string;
  address: string;
  currency: string; // ৳
  vatRate: number; // e.g. 5 or 7.5
  invoicePrefix: string;
  planName: string;
  planStatus: 'active' | 'trial' | 'past_due';
  planExpiresAt: string;
  maxOutlets: number;
  maxWarehouses: number;
  logoUrl?: string;
  faviconUrl?: string;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  seoOgImageUrl?: string;
  ecommerceDeliveryCharge?: number;
  insideDhakaDeliveryCharge?: number;
  outsideDhakaDeliveryCharge?: number;
  freeDeliveryEnabled?: boolean;
  freeDeliveryMinOrder?: number;
  freeDeliveryByMinAmountEnabled?: boolean; // Offer #1: Minimum Order Amount Free Delivery + Animated Live Progress Bar (e.g., ৳1,500 or ৳2,000)
  halfDeliveryOfferEnabled?: boolean; // Offer #4: Half Delivery Charge / 50% Delivery Discount Campaign
  deliveryDiscountPercent?: number; // Default 50 (50% Half Delivery Charge)
  productSpecificFreeDeliveryEnabled?: boolean; // Offer #6: Master toggle for Product-Specific Free Delivery (default true)
  flashFreeDeliveryEnabled?: boolean; // Offer #7: Happy Hour / Flash Free Delivery Timer Window
  flashFreeDeliveryEndTime?: number; // Epoch ms when flash free delivery countdown expires
  flashFreeDeliveryDurationMinutes?: number; // Duration in minutes (e.g., 60, 120, 180)
  flashFreeDeliveryScheduleEnabled?: boolean; // Optional daily recurring Happy Hour schedule (e.g., 21:00 to 23:59)
  flashFreeDeliveryStartHour?: string; // Default '21:00'
  flashFreeDeliveryEndHour?: string; // Default '23:59'
  freeDeliveryByQtyEnabled?: boolean; // Smart Quantity-Based Free Delivery (e.g., 2 pcs or 3 pcs = Free Delivery on Storefront)
  freeDeliveryMinQty?: number; // Minimum quantity for Free Delivery (default 2, e.g., 2 or 3 pcs)
  landingFreeDeliveryByQtyEnabled?: boolean; // Global fallback for Quantity-Based Free Delivery on Landing Pages
  landingFreeDeliveryMinQty?: number; // Global fallback minimum quantity on Landing Pages (default 2)
  // Mobile Checkout Delivery Area UX Controls (উপায় ১ ও উপায় ২) & Estimated Delivery Badge
  checkoutSummaryZoneToggleEnabled?: boolean; // উপায় ১: অর্ডার বক্সের ভেতরেই ১-ট্যাপ ডেলিভারি এরিয়া বাটন [✓ ঢাকার ভিতরে] [ঢাকার বাইরে] ON/OFF (Default: true)
  checkoutSummaryZoneHideOnDesktop?: boolean; // উপায় ১-এর বাটন ডেক্সটপ থেকে হাইড ON/OFF (Default: true — শুধু মোবাইলে দেখাবে, ডেক্সটপে হাইড থাকবে)
  checkoutSummaryZoneButtonStyle?: 'emerald_pill' | 'segmented_tab' | 'crimson_bold' | 'radio_compact'; // ৪টি আকর্ষণীয় বাটন ডিজাইন স্টাইল
  checkoutMobileFormFirst?: boolean; // উপায় ২: মোবাইলে আগে ফর্ম (নাম, ফোন, এরিয়া), পরে নিচে অর্ডার বক্স ও বিল ON/OFF (Default: false)
  checkoutEstimatedDeliveryEnabled?: boolean; // 📦 ডেলিভারির আনুমানিক তারিখ/সময় প্রদর্শন (Estimated Delivery Badge) ON/OFF (Default: true)
  checkoutEstimatedDeliveryInsideText?: string; // ঢাকার ভিতরে সিলেক্ট করলে যা দেখাবে
  checkoutEstimatedDeliveryOutsideText?: string; // ঢাকার বাইরে সিলেক্ট করলে যা দেখাবে
  stockOutBadgeStyle?: StockOutBadgeDesign; // Smart Stock Out image overlay style ('center_glass' | 'diagonal_ribbon' | 'bottom_banner' | 'classic_corner')
  storefrontTheme?: StorefrontThemeStyle; // 1-Click Website Color Theme Switcher (Default: 'emerald_default')
  winterThemeEnabled?: boolean; // 1-Click Winter Theme Toggle (Cool Blues, Snowy Whites & Winter Accents)
  winterSnowfallEnabled?: boolean; // Subtle Falling Snow Animation Overlay on Storefront (Default: true)
  winterSnowfallIntensity?: number; // Snowfall Intensity Slider (10 to 100, default 50 — controls particle count & speed)
  winterSnowfallSpeed?: number; // Snow Falling Speed Multiplier % (30 to 200, default 100 — slow to fast)
  winterSnowfallAutoOffSec?: number; // Auto-Off Timer in Seconds (0 = Always On / Never Auto-Off, or e.g. 5, 10, 15, 30, 60 sec)
  // Landing Page Winter Theme & Falling Snow Animation Overlay Controls (Same controls as Storefront)
  landingWinterThemeEnabled?: boolean; // 1-Click Winter Frost Theme (Cool Icy Blues & Snowy Whites) on Landing Pages
  landingSnowfallEnabled?: boolean; // Subtle Falling Snow Animation Overlay on Landing Pages (Default: true)
  landingSnowfallIntensity?: number; // Landing Snowfall Intensity Slider (10 to 100, default 50)
  landingSnowfallSpeed?: number; // Landing Snow Falling Speed Multiplier % (30 to 200, default 100)
  landingSnowfallAutoOffSec?: number; // Landing Auto-Off Timer in Seconds (0 = Always On, or seconds)
  // Order Success Confetti Burst Celebration Animation on Storefront (ON/OFF + 4 Luxury Styles)
  storefrontOrderConfettiEnabled?: boolean; // Default true (ON) — celebratory animation when order is confirmed
  storefrontOrderConfettiStyle?: OrderCelebrationStyle; // Default 'dual_cannon_badge'
  storefrontOrderCelebrationBadgeEnabled?: boolean; // Default true (ON) — center animated golden check celebration badge
  // Order Success Confetti Burst Celebration Animation on Landing Pages (ON/OFF + 4 Luxury Styles)
  landingOrderConfettiEnabled?: boolean; // Default true (ON) — celebratory animation when landing page order is confirmed
  landingOrderConfettiStyle?: OrderCelebrationStyle; // Default 'dual_cannon_badge'
  landingOrderCelebrationBadgeEnabled?: boolean; // Default true (ON) — center animated golden check celebration badge on Landing Page
  // Top Announcement Scrolling Bar (ON/OFF, Editable Text & Scroll Speed)
  topAnnouncementEnabled?: boolean; // Default true (ON)
  topAnnouncementText?: string; // Default: "❄️ শীতের নতুন কালেকশন লাইভ! সারাদেশে ক্যাশ অন ডেলিভারি — প্রোডাক্ট হাতে পেয়ে কোয়ালিটি দেখে পেমেন্ট করুন।"
  topAnnouncementSpeed?: 'slow' | 'normal' | 'fast' | 'static';
  // Storefront Top Utility Bar (Hotline, Login/Signup & Order Track Bar — ON/OFF)
  topUtilityBarEnabled?: boolean; // Default true (ON)
  whatsappOrderPhone?: string;
  callOrderPhone?: string;
  banglaFont?: BanglaFontStyle;
  numberFontStyle?: 'jetbrains_mono' | 'outfit' | 'plus_jakarta_sans';
  // Separate Mobile & Computer Font Size Scaling for Front Website (Storefront) & Landing Pages
  storefrontMobileFontSizeScale?: number; // Default 100 (%)
  storefrontDesktopFontSizeScale?: number; // Default 100 (%)
  landingMobileFontSizeScale?: number; // Default 100 (%)
  landingDesktopFontSizeScale?: number; // Default 100 (%)
  homeProductTitleMobilePx?: number; // Default 13 (px, matching Mobile Footer 'হটলাইন' size)
  homeProductTitleDesktopPx?: number; // Default 14 (px)
  homeProductTitleExtraBold?: boolean; // Default true (800 Extra-Bold weight matching 'হটলাইন' style)
  showFullProductNameOnCards?: boolean; // ON = Show full product name on Home Page & Related Products cards; OFF (default) = 2-line clamp
  showFullProductNameOnCheckout?: boolean; // ON (default true) = Show full product name on Checkout page; OFF (false) = 1-line truncate
  showProductSkuOnStorefront?: boolean;
  cartBorderBeamEnabled?: boolean;
  scarcityStockEnabled?: boolean; // 1-Click Admin Toggle for Marketing Scarcity Stock ("অফার মূল্যে আর মাত্র X টি বাকি আছে!")
  // Dual SMS Gateway (Alpha SMS https://api.sms.net.bd & GreenWeb https://api.bdbulksms.net) & Smart Notification Controls
  smsProvider?: 'alpha' | 'greenweb'; // Active SMS Gateway ('alpha' | 'greenweb')
  smsApiKey?: string; // Alpha SMS API Key
  smsSenderId?: string; // Alpha SMS Optional Sender ID
  smsContentId?: string; // Alpha SMS Optional Content ID
  greenwebToken?: string; // GreenWeb (bdbulksms.net) API Token
  smsConfigured?: boolean; // Public-safe indicator that server has an active SMS key/token configured
  smsEnabled?: boolean; // Master SMS System ON/OFF (default true)
  smsOrderConfirmationEnabled?: boolean; // Customer New Order SMS ON/OFF (default true)
  smsAdminOrderAlertEnabled?: boolean; // Admin New Order Alert SMS ON/OFF (default false)
  smsAdminOrderAlertPhone?: string; // Admin mobile number(s) to receive new order SMS alerts
  smsOrderStatusUpdateEnabled?: boolean; // Customer Order Status Update SMS ON/OFF (default true)
  smsForgotPasswordOtpEnabled?: boolean; // Forgot Password OTP SMS ON/OFF (default true)
  signupOtpRequired?: boolean; // Customer Signup OTP Verification ON/OFF (default false)
  smsOrderPlacedTemplate?: string;
  smsAdminOrderAlertTemplate?: string;
  smsOrderStatusTemplate?: string;
  smsOtpTemplate?: string;
  smsSignupOtpTemplate?: string;
  // Facebook Pixel + Server-Side Conversions API (CAPI) 100% Match Quality Config
  fbPixelId?: string;
  fbAccessToken?: string;
  fbDomainVerification?: string; // Facebook Domain Verification Code (or <meta> tag)
  customHeaderScripts?: string; // Custom <head> Scripts, Tracking Tags, or Meta Tags
  fbCapiConfigured?: boolean; // Public-safe indicator that server has a CAPI Access Token configured
  fbTestEventCode?: string;
  fbTrackingEnabled?: boolean;
  fbServerSideEnabled?: boolean;
  fbCurrency?: 'BDT' | 'USD';
  fbUsdExchangeRate?: number;
  fbTrackPageView?: boolean;
  fbTrackViewContent?: boolean;
  fbTrackSearch?: boolean;
  fbTrackAddToCart?: boolean;
  fbTrackInitiateCheckout?: boolean;
  fbTrackPurchase?: boolean;
  fbTrackLead?: boolean;
  // Google Tag Manager (GTM) & E-Commerce DataLayer Config
  gtmContainerId?: string;
  gtmEnabled?: boolean;
  gtmServerUrl?: string;
  gtmDataLayerEnabled?: boolean;
  // WordPress (WooCommerce REST API v3) Automatic Order Creation Config
  wpSyncEnabled?: boolean;
  wpSiteUrl?: string;
  wpConsumerKey?: string;
  wpConsumerSecret?: string;
  wpDefaultOrderStatus?: 'processing' | 'pending' | 'on-hold' | 'completed';
  wpSyncIncludeDeliveryFee?: boolean;
  // Website & Landing Page Footer Developer Credit Config (ON/OFF, Editable Name & Editable Link)
  developerCreditEnabled?: boolean;
  developerCreditName?: string;
  developerCreditLink?: string;
  // Storefront Spin the Wheel (স্পিন দ্য হুইল) Discount Config (ON/OFF), Custom Texts/Slices & Stored Leads
  spinWheelEnabled?: boolean;
  spinWheelConfig?: SpinWheelConfig;
  spinWheelLeads?: SpinWheelLead[];
  // Separate Landing Page Spin the Wheel (ল্যান্ডিং পেজ স্পিন দ্য হুইল) Discount Config (ON/OFF), Custom Texts/Slices & Stored Leads
  landingSpinWheelEnabled?: boolean;
  landingSpinWheelConfig?: SpinWheelConfig;
  landingSpinWheelLeads?: SpinWheelLead[];
  deletedSpinLeadIds?: string[];
  // Global Product Image Zoom ON/OFF & Style (Storefront & Landing Pages)
  productImageZoomEnabled?: boolean;
  productImageZoomStyle?: 'woocommerce_lightbox' | 'hover_and_lightbox' | 'hover_only';
  // Main Storefront Sticky Floating Button Controls (Product Page & Checkout Page)
  storefrontFloatingBtnEnabled?: boolean; // ON/OFF for Main Store sticky bottom floating button (default true)
  storefrontFloatingBtnHideOnDesktop?: boolean; // When true (default), hides the Product Page sticky bottom floating button on Desktop (lg:hidden) and shows it only on Mobile
  storefrontFloatingBtnPriceEnabled?: boolean; // Show/hide total price inside Main Store floating button (default true)
  storefrontFloatingBtnAnimation?: LandingFloatingBtnAnimation; // Animation style for Main Store floating button (default 'login_shine')
  // Home Page Bottom Floating Bar (1-Tap Checkout Pill Bar & Floating Widgets) ON/OFF (default true = ON)
  homeFloatingBarEnabled?: boolean;
  // Storefront Variant (Size/Age) Selection Warning Popup ON/OFF (When ON, no size is pre-selected and clicking Order/Add-to-Bag without picking a size opens a Size Selection Popup)
  requireVariantSelectionBeforeOrder?: boolean;
  // Show/Hide Product Variations (Size/Age pills) under products on the Home Page & Product Cards (When OFF, variations only show on the Product Page and in the Size Selection Popup)
  showVariantsOnHomePage?: boolean;
  // Show/Hide "+ ব্যাগে যোগ করুন" button on Home Page & Product Cards (default true = ON)
  showAddToBagOnHomePage?: boolean;
  // Show/Hide "শপিং ব্যাগে যোগ করুন" button on the Product Page (default true = ON)
  showAddToBagOnProductPage?: boolean;
  // Separate ON/OFF Control for "মাত্র 5 টি বাকি" badge on Home Page & Product Cards (independent of inner Product Page stock urgency)
  homePageScarcityStockEnabled?: boolean;
  // Product Page Variation Price Show/Hide (ON/OFF) & Multiple Button Design Styles
  productPageVariantShowPrice?: boolean; // Show/hide price inside variation buttons on the Product Page (default true = ON)
  productPageVariantStyle?: ProductPageVariantDesign; // Design style for variation buttons on the Product Page (default 'classic_inline')
  // Landing Page Variation Design Style, Price & Measurement Show/Hide (Global Fallback)
  landingVariantStyle?: LandingVariantDesign;
  landingVariantShowPrice?: boolean;
  landingVariantShowMeasurement?: boolean;
  // Landing Page Product Image % Discount Badge (ON/OFF & Multiple Designs)
  landingImageBadgeEnabled?: boolean;
  landingImageBadgeStyle?: LandingImageBadgeDesign;
  // Storefront Live Recent Order Notification Popup (Social Proof Toast — ON/OFF, Speed/Interval in Seconds & Optional Custom Buyer Entries)
  storefrontSocialProofEnabled?: boolean;
  storefrontSocialProofIntervalSec?: number;
  storefrontSocialProofCustomEntries?: string[];
  // Global Storefront Offer Countdown Timer (Shared across all products, 1-Click Global ON/OFF, Realistic Hours/Minutes/Seconds & Auto-Looping)
  storefrontCountdownEnabled?: boolean;
  storefrontCountdownHours?: number;
  storefrontCountdownMinutes?: number;
  storefrontCountdownSeconds?: number;
  storefrontCountdownTitle?: string;
  storefrontCountdownResetSeed?: number;
  // Storefront Variant Selection Popup Customization Settings
  variantPopupShowOptionPrice?: boolean; // Show/hide price next to each size pill inside popup (default true)
  variantPopupShowSizeChart?: boolean; // Show/hide "সাইজ চার্ট" button inside size selection popup (default true)
  variantPopupOrderButtonText?: string; // Custom confirm button text for direct order (default 'অর্ডার কনফার্ম করুন')
  variantPopupCartButtonText?: string; // Custom confirm button text for add to bag (default 'ব্যাগে যোগ করুন')
  variantPopupShowButtonSize?: boolean; // Show/hide selected size label inside confirm button (default false so button stays 1 line)
  variantPopupShowButtonPrice?: boolean; // Show/hide price inside confirm button (default true)
  variantPopupButtonAnimation?: LandingFloatingBtnAnimation; // Confirm button animation style ('login_shine' | 'cart_beam' | 'combo_beam' | 'glow_pulse' | 'jump' | 'none')
  // Courier Integration (Steadfast & Pathao 1-Click Parcel Send + Direct Fraud & Delivery Ratio Checker)
  steadfastEnabled?: boolean;
  steadfastApiKey?: string;
  steadfastSecretKey?: string;
  steadfastAuthEmail?: string;
  steadfastAuthPassword?: string;
  steadfastWebhookToken?: string;
  pathaoEnabled?: boolean;
  pathaoSandbox?: boolean;
  pathaoClientId?: string;
  pathaoClientSecret?: string;
  pathaoUsername?: string;
  pathaoPassword?: string;
  pathaoStoreId?: string;
  pathaoWebhookToken?: string;
  bdcourierApiKey?: string;
  defaultCourierProvider?: 'steadfast' | 'pathao';
  // Storefront Home Page Sliding Category Bar (Global ON/OFF Toggle, Multiple Designs & Auto Smooth Slider)
  homeCategoryBarEnabled?: boolean;
  homeCategoryBarDesign?: HomeCategoryBarDesign;
  homeCategoryAutoSlide?: boolean;
  // Storefront Home Page Smart Hybrid Infinite Scroll + Load More System (ON/OFF & Products Per Batch: 12, 20, 30, 40)
  homeInfiniteScrollEnabled?: boolean;
  homeProductsPerBatch?: number;
  // Daily Order Limit System (by Mobile Number & IP/Device + Same Product vs Total Daily Limit + Editable Error Popup)
  dailyOrderLimitEnabled?: boolean;
  dailySameProductMaxCount?: number; // Default 2 (same product max 2 times/day)
  dailyOrderMaxCount?: number; // Default 5 (total across all products max 5 times/day)
  dailyOrderLimitTitle?: string;
  dailyOrderLimitMessage?: string;
  dailyOrderLimitResetAt?: number;
  // Preloader / Splash Screen Master ON/OFF Toggle & Shimmer Product Card Skeleton Grid Toggle
  preloaderEnabled?: boolean;
  preloaderShimmerEnabled?: boolean;
  // Smart Invoice & Delivery Slip Customization Settings
  invoiceConfig?: InvoiceCustomizationConfig;
  // Developer / Admin ON/OFF Lock Control for Order Edit System (When false, blocks Store Managers/Staff from editing orders)
  orderEditEnabled?: boolean;
  // Online Orders & Abandoned Orders WhatsApp Message Template Customization (Edit or Keep Blank)
  whatsappOrderMessageBlank?: boolean;
  whatsappOrderTemplate?: string;
  whatsappAbandonedMessageBlank?: boolean;
  whatsappAbandonedTemplate?: string;
}

export type InvoiceAccentTheme =
  | 'cool_blue'
  | 'classic_bw'
  | 'emerald'
  | 'slate'
  | 'royal_crimson'
  | 'midnight_gold';

export type InvoiceLayoutStyle =
  | 'executive_standard'
  | 'modern_banner_header'
  | 'minimal_classic_grid'
  | 'compact_pos_memo'
  | 'luxury_boutique'
  | 'thermal_pos_receipt';

export type DeliverySlipLayoutStyle =
  | 'courier_standard_box'
  | 'bold_cod_split'
  | 'thermal_pos_80mm'
  | 'modern_fashion_tag';

export type InvoicePaperSize = 'a4_standard' | 'a5_half' | 'pos_80mm';

export type SlipPaperSize = 'sticker_4x6' | 'sticker_3x4' | 'thermal_80mm' | 'a5_sheet';

export interface InvoiceCustomizationConfig {
  invoiceStyle?: InvoiceLayoutStyle;
  deliverySlipStyle?: DeliverySlipLayoutStyle;
  invoicePaperSize?: InvoicePaperSize;
  slipPaperSize?: SlipPaperSize;
  accentTheme?: InvoiceAccentTheme;
  showLogo?: boolean;
  logoHeightPx?: number;
  brandNameOverride?: string;
  brandTagline?: string;
  storePhoneOverride?: string;
  storeAddressOverride?: string;
  storeWebsiteText?: string;
  showDomainOnInvoice?: boolean;
  invoiceTitleText?: string;
  deliverySlipTitleText?: string;
  billToLabelText?: string;
  orderInfoLabelText?: string;
  itemColumnLabel?: string;
  qtyColumnLabel?: string;
  priceColumnLabel?: string;
  totalColumnLabel?: string;
  subtotalLabelText?: string;
  deliveryLabelText?: string;
  discountLabelText?: string;
  grandTotalLabelText?: string;
  codNoticeBannerText?: string;
  thankYouText?: string;
  termsAndPolicyText?: string;
  showTermsSection?: boolean;
  showSignatureSection?: boolean;
  customerSignatureLabel?: string;
  authorizedSignatureLabel?: string;
  showCourierBarcode?: boolean;
  showCourierCnBox?: boolean;
  showProductSku?: boolean;
  showProductImage?: boolean;
  showOrderNoteOnInvoice?: boolean;
  showOrderNoteOnSlip?: boolean;
  slipInstructionText?: string;
}

export interface DailyOrderLimitCheckResult {
  blocked: boolean;
  count: number;
  maxCount: number;
  sameProductCount?: number;
  sameProductMaxCount: number;
  blockType?: 'same_product' | 'total_daily';
  title: string;
  message: string;
  reason?: 'phone' | 'ip_or_device';
}

export type HomeCategoryBarDesign =
  | 'large_poster_2col'
  | 'pure_image_card'
  | 'modern_grid_card'
  | 'circle_story'
  | 'compact_pill';

export interface SpinWheelSliceConfig {
  id: string;
  label: string;
  shortLabel: string;
  type: 'flat' | 'percent' | 'free_delivery' | 'none';
  value: number;
  color: string;
  code: string;
  locked?: boolean; // true = teaser/locked slice (shown on wheel to excite visitors, never won); false/undefined = winnable repeatedly
}

export interface SpinWheelConfig {
  badgeText?: string;
  titleText?: string;
  subtitleText?: string;
  claimButtonText?: string;
  autoPopupDelaySec?: number; // Default 4 seconds after landing
  cooldownDays?: number;      // Default 7 days (or 1 / 3 days) so repeat visitors aren't spammed
  slices?: SpinWheelSliceConfig[];
}

export interface SpinWheelLead {
  id: string;
  name: string;
  phone: string;
  prizeId: string;
  prizeLabel: string;
  prizeCode: string;
  dateKey: string; // YYYY-MM-DD (local date)
  // Extended/compatible fields for Landing Page & Unified Admin Dashboard
  customerName?: string;
  customerPhone?: string;
  rewardLabel?: string;
  rewardType?: 'flat' | 'percent' | 'free_delivery' | 'none';
  rewardValue?: number;
  couponCode?: string;
  spinDateKey?: string;
  source?: 'website' | 'landing';
  landingProductId?: string;
  landingProductName?: string;
  createdAt: string;
}

export interface Outlet {
  id: string;
  businessId: string;
  name: string;
  type: 'retail_shop' | 'central_warehouse' | 'distribution_hub';
  address: string;
  phone: string;
}

export interface Category {
  id: string;
  nameBn: string;
  nameEn: string;
  slug: string;
  image?: string;
  showOnHome?: boolean;
}

export interface Brand {
  id: string;
  name: string;
  origin: string;
}

export interface ProductVariant {
  id: string;
  label: string;         // e.g. "৫০০ গ্রাম (500gm)", "১ কেজি (1kg)", "লাল (Red)", "XL"
  type?: 'weight' | 'size' | 'color' | 'pack';
  sku?: string;
  wpVariationId?: number; // Optional WooCommerce Variation ID
  purchasePrice: number;
  regularPrice?: number; // Regular / MRP price before discount
  discountPrice?: number; // Discounted selling price (if set, used as retailPrice)
  retailPrice: number;   // Effective selling price on Storefront & POS
  outOfStock?: boolean;  // Manual Out-of-Stock toggle for this specific variation
  imageUrl?: string;     // Optional variation/color-specific dress photo URL or Base64 WebP
}

export interface LandingReviewItem {
  id: string;
  customerName: string;
  name?: string;
  location?: string;
  rating?: number;
  comment: string;
  avatarUrl?: string; // Optional circular reviewer profile image URL / base64 WebP
  status?: 'approved' | 'pending';
  submittedBy?: 'customer' | 'admin';
  createdAt?: string;
}

export interface LandingTrustItem {
  id: string;
  title: string;
  description: string;
  enabled?: boolean;
}

export interface LandingSizeChartRow {
  id: string;
  size: string;
  chest: string;
  length: string;
  extra?: string;
}

export type LandingPageTemplate = 'template_1' | 'template_2' | 'template_3';

export interface LandingShowcaseProductItem {
  productId: string;
  badgeText?: string;        // e.g., "টপ সেলিং 🔥", "বেস্ট চয়েস ⭐", "লিমিটেড অফার ⏳", "নতুন কালেকশন ✨", "ট্রেন্ডিং 🌸"
  fabricSubtitle?: string;   // e.g., "প্রিমিয়াম চায়না মাইক্রো ভেলভেট"
  colorTag?: string;         // e.g., "রয়্যাল মেরুন"
  shortDescription?: string; // Optional override for 1-line description (falls back to website product description)
}

export interface Product {
  id: string;
  businessId: string;
  sku: string;
  barcode: string;
  wpProductId?: number; // Optional WooCommerce Product ID for 100% direct product assignment in WordPress orders
  nameBn: string;
  nameEn: string;
  categoryId: string;
  brandId: string;
  unit: string;
  packSize: number;
  purchasePrice: number;
  avgCost?: number; // Weighted Average Cost (WAC) in BDT
  regularPrice?: number; // Regular / MRP price set from Dashboard
  discountPrice?: number; // Discounted selling price set from Dashboard
  retailPrice: number; // Effective selling price (discountPrice if > 0, else regularPrice)
  wholesalePrice: number;
  minWholesaleQty: number;
  stockByOutlet: Record<string, number>;
  lowStockAlert: number;
  batchNumber?: string;
  expiryDate?: string;
  vatPercent: number;
  image?: string;
  galleryImages?: string[];
  description?: string;
  shortDescription?: string;
  landingShortDescription?: string;
  isOutOfStock?: boolean; // Manual Out-of-Stock override for the entire product on Storefront & Landing Page
  variants?: ProductVariant[];
  // Dedicated Single-Product / Multi-Product Landing Page Fields
  isLandingPageProduct?: boolean;
  landingTemplate?: LandingPageTemplate; // 'template_1' (Existing Single-Product) | 'template_2' (Landing Page 2 - Multi-Product Showcase) | 'template_3' (Landing Page 3 - Multi-Product Order)
  landingShowcaseSectionTitle?: string;
  landingShowcaseSectionSubtitle?: string;
  landingShowcaseSelectBtnEnabled?: boolean; // Show/hide "সাইজ পছন্দ করুন →" button on LP-2 product showcase cards (default true = ON)
  landingShowcaseSelectBtnText?: string; // Custom text for "সাইজ পছন্দ করুন" button on LP-2 showcase cards
  landingShowcaseMobileTwoCols?: boolean; // ON = 2 products per row on mobile (grid-cols-2); OFF = 1 product per row on mobile (grid-cols-1) on LP-2
  landingShowcaseItems?: LandingShowcaseProductItem[];
  landingSlug?: string;
  freeDelivery?: boolean; // Offer #6: Product-Specific Free Delivery on Storefront & Landing Page (buying this product makes the entire cart/order delivery free)
  freeDeliveryOnLanding?: boolean;
  landingFreeDeliveryByQtyEnabled?: boolean; // Per-Landing Page Quantity-Based Free Delivery ("2 পিস বা 3 পিস কিনলে ডেলিভারি ফ্রি")
  landingFreeDeliveryMinQty?: number; // Minimum quantity for Free Delivery on this Landing Page (e.g. 2 or 3)
  landingBadgeText?: string;
  landingVariantTitle?: string;
  landingVariantStyle?: LandingVariantDesign;
  landingVariantShowPrice?: boolean;
  landingVariantShowMeasurement?: boolean;
  landingImageBadgeEnabled?: boolean;
  landingImageBadgeStyle?: LandingImageBadgeDesign;
  landingHighlightsTitle?: string;
  // Product Details / Fabric & Features Section (ON/OFF + Editable Texts & Topics)
  landingFeaturesEnabled?: boolean;
  landingFeaturesBadgeEnabled?: boolean;
  landingFeaturesBadgeText?: string;
  landingHighlightsTitleEnabled?: boolean;
  // Trust & Guarantee Topics Section (ON/OFF + Editable Heading & Topics)
  landingTrustSectionEnabled?: boolean;
  landingTrustBadgeEnabled?: boolean;
  landingTrustBadgeText?: string;
  landingTrustTitle?: string;
  landingTrustItems?: LandingTrustItem[];
  // Top Animated Heading Before Product Image on Landing Page (ON/OFF + Animation ON/OFF + Style)
  landingTopHeadingEnabled?: boolean;
  landingTopHeadingAnimation?: boolean;
  landingTopHeadingText?: string;
  landingTopHeadingSubtext?: string;
  landingTopHeadingTheme?: 'emerald' | 'crimson' | 'midnight' | 'light';
  landingTopHeadingAnimStyle?: 'shimmer' | 'bounce' | 'glow';
  // Elementor-Style Top Animated Regular & Offer Price Banner at the Start of Landing Page (ON/OFF + Theme + Highlight Style + Speed + Labels)
  landingTopPriceBannerEnabled?: boolean;
  landingTopPriceAnimationEnabled?: boolean;
  landingTopPriceAnimationSpeed?: 'slow' | 'normal' | 'fast' | 'ultra_fast';
  landingTopPriceBannerTheme?: 'emerald' | 'crimson' | 'midnight' | 'amber' | 'light';
  landingTopPriceHighlightStyle?: 'circle' | 'underline' | 'burst';
  landingTopRegularPriceLabel?: string;
  landingTopOfferPriceLabel?: string;
  landingTopOfferPricePrefix?: string;
  // Banner 1: Custom Promotional Banner / Image Upload at the Start of Landing Page (ON/OFF + Uploaded Image + Optional Caption)
  landingPromoBannerEnabled?: boolean;
  landingPromoBannerImage?: string;
  landingPromoBannerPosition?: 'top' | 'after_hero';
  landingPromoBannerTitle?: string;
  // Banner 2: Custom Promotional Banner / Image Upload Right Before Video Section (ON/OFF + Uploaded Image + Optional Caption)
  landingPromoBanner2Enabled?: boolean;
  landingPromoBanner2Image?: string;
  landingPromoBanner2Title?: string;
  // Animated Evergreen Countdown Timer on Landing Page (ON/OFF + Hours Duration + Auto-Restart Loop + Label + Position)
  landingCountdownEnabled?: boolean;
  landingCountdownHours?: number;
  landingCountdownTitle?: string;
  landingCountdownPosition?: 'hero_info' | 'top_heading';
  // Product Video / YouTube / Reels Section on Landing Page (ON/OFF + Video URL + Editable Title)
  landingVideoEnabled?: boolean;
  landingVideoTitle?: string;
  landingVideoSubtitle?: string;
  landingVideoUrl?: string;
  // Size Chart / Measurement Guide on Landing Page (ON/OFF + Editable Table Rows & Headers + Optional Image)
  landingSizeChartEnabled?: boolean;
  landingBodySizeChartEnabled?: boolean;
  landingSizeChartTitle?: string;
  landingSizeChartSubtitle?: string;
  landingSizeChartHeaders?: [string, string, string];
  landingSizeChartRows?: LandingSizeChartRow[];
  landingSizeChartImage?: string;
  // Live Recent Order Social Proof Notification Popup on Landing Page (ON/OFF + Custom Messages)
  landingSocialProofEnabled?: boolean;
  landingSocialProofIntervalSec?: number;
  landingSocialProofCustomEntries?: string[];
  // Live "People currently viewing this product" Counter (12-48 randomized urgency counter, ON/OFF per product)
  landingLiveViewersEnabled?: boolean;
  // Scarcity Stock & High-Demand Urgency Banner on Landing Page ("অফার মূল্যে আর মাত্র 10 টি বাকি আছে!" + "প্রচুর চাহিদা — দ্রুত বিক্রি হচ্ছে" + "সীমিত স্টক")
  landingScarcityEnabled?: boolean;
  landingScarcityCount?: number;
  // Top Header Bar (Logo + Phone Number Bar) on Landing Page (ON/OFF, default ON)
  landingTopHeaderEnabled?: boolean;
  // Top Call & WhatsApp Buttons on Landing Page (Enable/Disable + Optional Custom Phone)
  landingShowCallButton?: boolean;
  landingShowWhatsappButton?: boolean;
  landingCallPhone?: string;
  landingWhatsappPhone?: string;
  // Optional Customer Reviews on Landing Page (Enable/Disable + Slider/Grid Mode + Screenshot Images + Written Reviews with Circular Avatar Photo)
  landingReviewsEnabled?: boolean;
  landingReviewsSliderEnabled?: boolean; // Default true (ON) = Compact smooth slider on LP-1 & LP-2; false (OFF) = Grid layout
  landingReviewsTitle?: string;
  landingReviewImages?: string[];
  landingReviewItems?: LandingReviewItem[];
  // Real Customer Photo & Unboxing Video Gallery ("আমাদের ড্রেস পরা সোনামণিদের বাস্তব ছবি ও আনবক্সিং ভিডিও" — Click-to-Play Video + Lazy WebP Photos)
  realCustomerGalleryEnabled?: boolean;
  realCustomerGalleryTitle?: string;
  realCustomerPhotos?: string[];
  realUnboxingVideoUrl?: string;
  // Optional Footer Anti-Fake Order Notice on Landing Page (ON/OFF + Editable Text)
  landingFooterWarningEnabled?: boolean;
  landingFooterWarningText?: string;
  // Optional Footer Developer Credit on Landing Page (Enable/Disable + Custom Name & Link)
  landingDeveloperCreditEnabled?: boolean;
  landingDeveloperCreditName?: string;
  landingDeveloperCreditLink?: string;
  // Optional Separate Landing Page Spin the Wheel Toggle & Custom Config Override per Product
  landingSpinWheelEnabled?: boolean;
  landingSpinWheelConfig?: SpinWheelConfig;
  // Optional Per-Landing Page Winter Theme & Falling Snow Animation Toggle Overrides
  landingWinterThemeEnabled?: boolean;
  landingSnowfallEnabled?: boolean;
  // Optional Per-Landing Page Order Celebration Overrides (ON/OFF + Style + Badge)
  landingOrderConfettiEnabled?: boolean;
  landingOrderConfettiStyle?: OrderCelebrationStyle;
  landingOrderCelebrationBadgeEnabled?: boolean;
  // Mobile Floating Confirm Button Total Price Display Toggle ("অর্ডার কনফার্ম করুন (৳1,010)" — ON/OFF, default ON)
  landingFloatingBtnPriceEnabled?: boolean;
  // Mobile Floating Confirm Button Animation Style Switcher (Jump, Login Shine, Cart Border Beam, Combo, Glow Pulse, None)
  landingFloatingBtnAnimation?: LandingFloatingBtnAnimation;
  landingFontStyle?: BanglaFontStyle;
  createdAt?: string;
  updatedAt?: string;
}

export type LandingFloatingBtnAnimation =
  | 'jump'
  | 'login_shine'
  | 'cart_beam'
  | 'combo_beam'
  | 'glow_pulse'
  | 'none';

export type StockMovementType =
  | 'OPENING_STOCK'
  | 'PURCHASE_RECEIPT'
  | 'PURCHASE_RETURN'
  | 'POS_SALE'
  | 'WHOLESALE_CHALLAN'
  | 'SALE_RETURN'
  | 'TRANSFER_OUT'
  | 'TRANSFER_IN'
  | 'ADJUSTMENT';

export interface StockMovement {
  id: string;
  businessId: string;
  outletId: string;
  outletName: string;
  productId: string;
  productName: string;
  sku: string;
  movementType: StockMovementType;
  referenceNo: string;
  qtyIn: number;
  qtyOut: number;
  balanceAfter: number;
  unitCost: number;
  wacAfter: number;
  notes: string;
  createdBy: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
  route?: string;
  customerType: 'retail' | 'wholesale' | 'online';
  isOnlineCustomer?: boolean;
  password?: string;
  creditLimit: number;
  currentDue: number;
  salesRepId?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Supplier {
  id: string;
  businessId: string;
  name: string;
  companyName: string;
  phone: string;
  email?: string;
  address: string;
  currentPayable: number;
  bankDetails?: string;
}

export type PaymentMethod = 
  | 'cash' 
  | 'bkash' 
  | 'nagad' 
  | 'rocket' 
  | 'bank' 
  | 'due';

export interface PaymentSplit {
  method: PaymentMethod;
  amount: number;
  reference?: string;
}

export interface SaleItem {
  productId: string;
  productName: string;
  productNameClean?: string;
  image?: string;
  sku?: string;
  parentSku?: string;
  variantSku?: string;
  wpProductId?: number;
  wpVariationId?: number;
  variantId?: string;
  variantLabel?: string;
  unit: string;
  quantity: number;
  returnedQty?: number;
  unitPrice: number;
  costPrice: number; // WAC at moment of sale
  discount: number;
  total: number;
  batchNumber?: string;
}

export type OnlineOrderStatus =
  | 'pending'
  | 'confirmed'
  | 'packaging'
  | 'dispatched'
  | 'delivered'
  | 'cancelled';

export interface OnlineOrder {
  id: string;
  orderNo: string;
  invoiceNo: string;
  businessId: string;
  outletId: string;
  customerId?: string;
  customerName: string;
  customerPhone: string;
  alternativePhone?: string;
  deliveryArea: string;
  deliveryAddress: string;
  deliverySlot: string;
  items: SaleItem[];
  subtotal: number;
  deliveryCharge: number;
  discountAmount: number;
  grandTotal: number;
  paymentMethod: 'cod' | 'bkash' | 'nagad';
  paymentStatus: 'unpaid' | 'paid';
  transactionId?: string;
  orderStatus: OnlineOrderStatus;
  orderSource?: 'landing_page' | 'storefront' | 'incomplete_recovery';
  landingSlug?: string;
  wpOrderId?: number | string;
  // Courier Integration & 1-Click Parcel Booking Tracking Fields
  courierProvider?: 'steadfast' | 'pathao';
  courierConsignmentId?: string;
  courierTrackingCode?: string;
  courierStatus?: string;
  courierBookedAt?: string;
  fraudCheckSummary?: {
    totalParcels: number;
    deliveredParcels: number;
    cancelledParcels: number;
    successRatio: number;
    riskLevel: 'safe' | 'moderate' | 'high_risk' | 'new';
    checkedAt: string;
  };
  // Meta Pixel Advanced Matching & Conversions API (CAPI) Deduplication Metadata
  fbEventId?: string;
  fbp?: string;
  fbc?: string;
  fbExternalId?: string;
  clientUserAgent?: string;
  clientIp?: string;
  clientDeviceId?: string;
  eventSourceUrl?: string;
  notes?: string;
  editHistory?: Array<{
    editedAt: string;
    editedBy: string;
    summary: string;
  }>;
  createdAt: string;
  updatedAt?: string;
}

export interface CourierSingleProviderStats {
  provider: string;
  total: number;
  delivered: number;
  cancelled: number;
  successRatio: number;
  status?: 'live' | 'not_configured' | 'error';
  message?: string;
}

export interface CourierFraudCheckResult {
  phone: string;
  ownStore: {
    totalOrders: number;
    delivered: number;
    cancelled: number;
    pendingOrProcessing: number;
    abandonedLeads: number;
    totalSpentDelivered: number;
    successRatio: number;
  };
  steadfast: CourierSingleProviderStats;
  pathao: CourierSingleProviderStats;
  redx?: CourierSingleProviderStats;
  paperfly?: CourierSingleProviderStats;
  combinedTotalParcels: number;
  combinedDelivered: number;
  combinedCancelled: number;
  combinedSuccessRatio: number;
  riskLevel: 'safe' | 'moderate' | 'high_risk' | 'new';
  verdictBn: string;
  checkedAt: string;
}

export type IncompleteOrderStatus = 'abandoned' | 'contacted' | 'converted' | 'ignored';

export interface IncompleteOrder {
  id: string;
  sessionKey: string;
  businessId: string;
  customerName: string;
  customerPhone: string;
  deliveryArea: string;
  deliveryAddress: string;
  deliverySlot: string;
  items: SaleItem[];
  subtotal: number;
  deliveryCharge: number;
  grandTotal: number;
  status: IncompleteOrderStatus;
  fbLeadSent?: boolean;
  fbp?: string;
  fbc?: string;
  externalId?: string;
  clientIp?: string;
  clientUserAgent?: string;
  eventSourceUrl?: string;
  orderSource?: 'landing_page' | 'storefront';
  landingSlug?: string;
  convertedOrderNo?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Sale {
  id: string;
  invoiceNo: string;
  idempotencyKey?: string;
  businessId: string;
  outletId: string;
  channel: 'retail_pos' | 'wholesale_distribution' | 'online_ecommerce';
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  salesRepId?: string;
  items: SaleItem[];
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  grandTotal: number;
  paidAmount: number;
  changeAmount: number;
  dueAmount: number;
  paymentSplits: PaymentSplit[];
  status: 'completed' | 'hold' | 'dispatched' | 'delivered' | 'returned';
  createdAt: string;
  cashierName: string;
  notes?: string;
}

export interface SaleReturn {
  id: string;
  returnNo: string;
  saleId: string;
  invoiceNo: string;
  businessId: string;
  outletId: string;
  customerId?: string;
  customerName: string;
  productId: string;
  productName: string;
  returnQty: number;
  unitPrice: number;
  totalRefundAmount: number;
  refundMethod: 'cash_refund' | 'adjust_customer_due';
  reason: string;
  createdBy: string;
  createdAt: string;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  quantity: number;
  returnedQty?: number;
  unitCost: number;
  total: number;
  batchNumber?: string;
  expiryDate?: string;
}

export interface Purchase {
  id: string;
  poNumber: string;
  idempotencyKey?: string;
  businessId: string;
  outletId: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseItem[];
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: PaymentMethod;
  paymentRef?: string;
  receivedDate: string;
  status: 'received' | 'pending' | 'cancelled' | 'returned';
  notes?: string;
}

export interface PurchaseReturn {
  id: string;
  returnNo: string;
  purchaseId: string;
  poNumber: string;
  businessId: string;
  outletId: string;
  supplierId: string;
  supplierName: string;
  productId: string;
  productName: string;
  returnQty: number;
  unitCost: number;
  totalReturnAmount: number;
  reason: string;
  createdBy: string;
  createdAt: string;
}

export interface StockTransfer {
  id: string;
  businessId: string;
  transferNo: string;
  fromOutletId: string;
  toOutletId: string;
  productId: string;
  productName: string;
  quantity: number;
  date: string;
  status: 'completed' | 'in_transit' | 'cancelled';
  transferredBy: string;
  note?: string;
}

export interface StockAdjustment {
  id: string;
  businessId: string;
  outletId: string;
  productId: string;
  productName: string;
  type: 'damage' | 'expired' | 'wastage' | 'physical_count_correction';
  quantity: number;
  date: string;
  costImpact: number;
  reason: string;
  createdBy: string;
}

export interface Expense {
  id: string;
  businessId: string;
  outletId: string;
  category: 'rent' | 'salary' | 'electricity' | 'transport' | 'packaging' | 'entertainment' | 'maintenance' | 'other';
  amount: number;
  paymentMethod: PaymentMethod;
  paidTo: string;
  date: string;
  note: string;
  createdBy: string;
}

export interface AccountLedger {
  id: string;
  businessId: string;
  accountName: string;
  type: 'cash_drawer' | 'bkash_merchant' | 'nagad_merchant' | 'bank_account';
  accountNumber?: string;
  currentBalance: number;
}

export interface SalesRep {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  email: string;
  routeTerritory: string;
  monthlyTarget: number;
  commissionRate: number;
  status: 'active' | 'inactive';
}

export interface DayEndClose {
  id: string;
  businessId: string;
  outletId: string;
  date: string;
  openingCash: number;
  cashSales: number;
  digitalSales: number;
  creditSales: number;
  dueCollected: number;
  cashExpenses: number;
  supplierPaidCash: number;
  expectedClosingCash: number;
  actualPhysicalCash: number;
  difference: number;
  closedBy: string;
  notes: string;
}

export interface AuditLogEntry {
  id: string;
  businessId: string;
  userName: string;
  userRole: string;
  action: string;
  entityType: string;
  entityRef: string;
  description: string;
  ipAddress: string;
  createdAt: string;
}

export interface CustomerLedgerEntry {
  id: string;
  businessId: string;
  customerId: string;
  customerName: string;
  entryType: 'OPENING_BALANCE' | 'SALE_INVOICE' | 'PAYMENT_COLLECTION' | 'SALES_RETURN_CREDIT';
  referenceNo: string;
  description: string;
  paymentMethod?: PaymentMethod;
  debit: number;
  credit: number;
  balanceAfter: number;
  createdBy: string;
  createdAt: string;
}

