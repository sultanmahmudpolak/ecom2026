# StockMaster BD — MySQL Database Backup & Restore Guide (cPanel)

Protecting your shop's financial ledger, inventory balances, and customer dues is critical. Follow these simple instructions to back up and restore your database safely on cPanel.

---

## 1. Daily One-Click Backup via cPanel Backup Wizard

1. Log in to **cPanel**.
2. Go to **Files** → click **Backup Wizard**.
3. Click **Back Up** → under **Select Partial Backup**, click **MySQL Databases**.
4. Click on your database name (`myuser_stockmaster`).
5. A compressed `.sql.gz` file will immediately download to your computer.
6. Save this file in a safe folder or Google Drive with today's date (e.g., `stockmaster_backup_22-10-2026.sql.gz`).

---

## 2. Exporting a Clean SQL Backup via phpMyAdmin

1. Open **cPanel → phpMyAdmin**.
2. Select your `stockmaster` database on the left.
3. Click **Export** in the top menu.
4. Select **Custom - display all possible options**:
   - Check **Add DROP TABLE / VIEW / PROCEDURE / FUNCTION / EVENT / TRIGGER statement**.
   - Make sure **Export method** includes both **Structure and data**.
   - Check **Single transaction** (ensures InnoDB tables are exported consistently without locking your POS counter).
5. Click **Export** at the bottom to download your `.sql` file.

---

## 3. Automated Nightly Backup via cPanel Cron Jobs (Recommended)

1. In cPanel, go to **Advanced** → click **Cron Jobs**.
2. Under **Common Settings**, select **Once Per Day (0 0 * * *)**.
3. In the **Command** field, enter:
   ```bash
   mysqldump --single-transaction -u YOUR_DB_USER -p'YOUR_DB_PASS' YOUR_DB_NAME | gzip > /home/YOUR_CPANEL_USER/stockmaster_config/backup_$(date +\%F).sql.gz
   ```
   *(Notice the backup is saved inside `/home/YOUR_CPANEL_USER/stockmaster_config/`, which is OUTSIDE `public_html` so nobody on the internet can download your backups!)*

---

## 4. How to Restore from a Backup

1. Open **cPanel → Backup Wizard** → click **Restore** → select **MySQL Databases**.
2. Choose your `.sql.gz` backup file and click **Upload**.
3. Alternatively, open **phpMyAdmin**, select your database, click **Import**, choose your `.sql` or `.sql.gz` file, and click **Import**.
