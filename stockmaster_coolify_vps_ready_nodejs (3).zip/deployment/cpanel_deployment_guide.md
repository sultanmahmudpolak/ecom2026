# StockMaster BD — Beginner-Friendly cPanel Deployment Guide (PHP 8.2 + MySQL)

This guide is written in simple, step-by-step language so you can deploy **StockMaster BD** on any standard Bangladeshi or international **cPanel Shared Hosting** without needing any programming knowledge, Node.js server, Docker, or SSH terminal.

---

## Step 1: Check PHP Version in cPanel (১. পিএইচপি ভার্সন সেটআপ)

1. Log in to your **cPanel** dashboard.
2. Scroll down to the **Software** section and click **Select PHP Version** (or **MultiPHP Manager**).
3. Select **PHP 8.2** (or **PHP 8.3**) and click **Apply**.
4. Make sure the following standard extensions are checked:
   - `pdo`
   - `pdo_mysql`
   - `mbstring` (for Bangla text support)
   - `json`

---

## Step 2: Create the MySQL Database & User (২. মাইএসকিউএল ডেটাবেজ তৈরি)

1. In cPanel, go to **Databases** → click **MySQL Database Wizard**.
2. **Create a Database**: Enter a name like `stockmaster` and click **Next Step**.
   - *Note down the full database name shown by cPanel (for example: `myuser_stockmaster`).*
3. **Create Database Users**: Enter a username like `smadmin`, click **Password Generator** to create a strong password, copy that password somewhere safe, and click **Create User**.
4. **Add User to Database**: Check the box **ALL PRIVILEGES** and click **Next Step** / **Make Changes**.

---

## Step 3: Import the Database Tables via phpMyAdmin (৩. টেবিল ইমপোর্ট করা)

1. In cPanel, go to **Databases** → click **phpMyAdmin**.
2. On the left sidebar of phpMyAdmin, click your newly created database (`myuser_stockmaster`).
3. Click the **Import** tab at the top.
4. Click **Choose File** and select `database/schema.sql` from this project.
5. Scroll down and click **Import** (or **Go**). You will see green checkmarks creating all 16 tables (`organizations`, `branches`, `users`, `products`, `branch_stocks`, `stock_movements`, `sales`, `purchases`, `audit_logs`, etc.).
6. Optional: Repeat the import with `database/demo_seed.sql` if you want sample Bangladeshi products, branches, and demo accounts loaded immediately.

---

## Step 4: Save Your Database Password Outside `public_html` (৪. নিরাপদ ফোল্ডারে পাসওয়ার্ড রাখা)

To keep your database password 100% safe from hackers, never put it inside `public_html`.

1. Open **cPanel → File Manager**.
2. Stay in your **Home Directory** (`/home/YOUR_CPANEL_USER/` — one level above `public_html`).
3. Click **+ Folder** at the top left and create a folder named:
   `stockmaster_config`
4. Open `stockmaster_config` and create a new file named `env.php`.
5. Right-click `env.php` → click **Edit**, paste the contents of `deployment/environment_configuration_example.txt`, and fill in your `DB_NAME`, `DB_USER`, and `DB_PASS` from Step 2.
6. Save the file, then right-click `env.php` → **Change Permissions** → set it to `0600` (Owner Read & Write only).

---

## Step 5: Upload the PHP Backend & Static Frontend Files (৫. ফাইল আপলোড)

1. In **cPanel → File Manager**, open `public_html/`.
2. Create a folder named `backend` inside `/home/YOUR_CPANEL_USER/` (or inside `public_html/backend` with `.htaccess` protection) and upload the contents of the `backend/` folder.
3. Make sure `backend/api/index.php` and `backend/api/.htaccess` are placed in `public_html/api/`.
4. Upload the compiled static React frontend files (from the `dist/` folder: `index.html` and `assets/`) directly into `public_html/`.

---

## Step 6: Enable Free HTTPS SSL Certificate (৬. এইচটিটিপিএস চালু করা)

1. In cPanel, go to **Security** → **SSL/TLS Status**.
2. Click **Run AutoSSL** so your domain runs on `https://`.
3. Open your domain in your browser and log in!
   - **Default Demo Username:** `admin`
   - **Default Demo Password:** `password` (Change this immediately from the **Users & Roles** menu after first login).
