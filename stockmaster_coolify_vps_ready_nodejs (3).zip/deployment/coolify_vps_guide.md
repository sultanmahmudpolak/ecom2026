# 🚀 Coolify ও VPS ডিপ্লয়মেন্ট গাইড (Pure Node.js + React + SQLite WAL)

এই প্রজেক্টটি এখন **১০০% Coolify এবং যেকোনো Ubuntu/Debian VPS রেডি**। এতে বিল্ট-ইন **High-Speed SQLite (WAL Mode) + Node.js RAM Cache** যুক্ত করা হয়েছে, তাই আলাদা কোনো ডাটাবেস সার্ভার সেটআপ বা কানেক্ট করার ঝামেলা নেই!

---

## পদ্ধতি ১: Coolify দিয়ে ১-ক্লিকে হোস্ট করার নিয়ম (সবচেয়ে সহজ)

১. **নতুন প্রজেক্ট তৈরি করুন:**
   - আপনার **Coolify Dashboard**-এ লগইন করে **Projects -> + Add New Resource**-এ ক্লিক করুন।
   - আপনার GitHub Repository সিলেক্ট করুন (অথবা এই প্রজেক্টের কোড পুশ করা রিপোজিটরি দিন)।
   - **Build Pack** হিসেবে **`Dockerfile`** অথবা **`Docker Compose`** সিলেক্ট করুন (প্রজেক্টের ভেতরে রেডিমেড `Dockerfile` ও `docker-compose.yml` দেওয়া আছে)।

২. **ডোমেইন ও পোর্ট সেটআপ:**
   - **Domains** বক্সে আপনার ডোমেইন নাম লিখুন (যেমন: `https://yourdomain.com`)।
   - **Ports Exposes** বক্সে `3000` দিন (ডিফল্টভাবে `3000` দেওয়া থাকে)।

৩. **Persistent Storage (ডাটাবেস ও ছবি যেন কখনো না মুছে যায়):**
   - Coolify-এর **Storages (Persistent Volumes)** ট্যাবে গিয়ে নিচের ২টি পাথ অ্যাড করুন:
     - **Volume 1 (Database):** Destination Path: `/app/data`
     - **Volume 2 (Uploaded Images):** Destination Path: `/app/uploads`
   - *(নোট: আপনি যদি Build Pack হিসেবে `Docker Compose` সিলেক্ট করেন, তাহলে এই দুটি ভলিউম স্বয়ংক্রিয়ভাবেই সেটআপ হয়ে যাবে!)*

৪. **Deploy বাটনে ক্লিক করুন:**
   - **Deploy** বাটনে ক্লিক করলেই ১-২ মিনিটের মধ্যে আপনার সাইট লাইভ হয়ে যাবে!

---

## পদ্ধতি ২: সাধারণ VPS-এ (Ubuntu + PM2) চালানোর নিয়ম

আপনি যদি Coolify ছাড়া সরাসরি টার্মিনাল দিয়ে VPS-এ চালাতে চান:

```bash
# ১. প্রজেক্ট ফোল্ডারে যান
git clone <your-repo-url> stockmaster-bd
cd stockmaster-bd

# ২. প্যাকেজ ইনস্টল ও ফ্রন্টএন্ড বিল্ড করুন
npm install
npm run build

# ৩. PM2 দিয়ে ২৪ ঘণ্টা চালু রাখুন
npm install -g pm2
pm2 start npm --name "stockmaster-bd" -- start
pm2 save
pm2 startup
```

---

## 🔄 ভবিষ্যতে PostgreSQL বা cPanel-এ ডাটা নেওয়ার নিয়ম

* **১-ক্লিক ব্যাকআপ ডাউনলোড:** অ্যাডমিন প্যানেলে (`/smart`) লগইন করে বাম পাশের **Database & Coolify VPS** মেনু থেকে যেকোনো সময়:
  - **Full JSON Database Backup (`.json`)**
  - **SQLite WAL Binary Database (`.sqlite`)**
  - **cPanel MySQL Complete Export (`.sql` / `.zip`)**
  ডাউনলোড করতে পারবেন।
* **১-ক্লিক রিস্টোর (Restore):** নতুন কোনো VPS, লোকাল সার্ভার বা অন্য কোথাও গিয়ে শুধু ব্যাকআপ `.json` ফাইলটি সিলেক্ট করে **Restore Database** বাটনে ক্লিক করলেই সব প্রোডাক্ট, অর্ডার, কাস্টমার ও সেটিংস সাথে সাথে চলে আসবে!
