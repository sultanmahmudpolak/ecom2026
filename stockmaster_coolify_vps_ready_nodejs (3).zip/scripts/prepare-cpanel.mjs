import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import vm from 'vm';
import { buildSync } from 'esbuild';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');

function copyDirRecursive(srcDir, destDir, ignoreNames = new Set()) {
  if (!fs.existsSync(srcDir)) return;
  fs.mkdirSync(destDir, { recursive: true });
  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const entry of entries) {
    if (ignoreNames.has(entry.name)) continue;
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, destPath, ignoreNames);
    } else if (entry.isFile()) {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function getAppVersionNumber() {
  try {
    const versionFile = path.join(rootDir, 'src', 'config', 'version.ts');
    if (fs.existsSync(versionFile)) {
      const content = fs.readFileSync(versionFile, 'utf-8');
      const match = content.match(/APP_VERSION\s*=\s*['"]([^'"]+)['"]/);
      if (match && match[1]) {
        return match[1].replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || 'v560';
      }
    }
  } catch {
    // ignore
  }
  return 'v560';
}

function sanitizeClassicBundleJs(rawJs) {
  return rawJs
    .replace(/^\/\* StockMaster BD [^*]*\*\/\r?\n/, '')
    .replace(
      /function\s+s\(e\)\{return\s+import\.meta\.resolve\?new\s+URL\(import\.meta\.resolve\(e\)\):new\s+URL\(e,import\.meta\.url\)\}/g,
      'function s(e){return new URL(e,window.location.href)}'
    )
    .replace(/,void 0,import\.meta\.url\)\)/g, ',void 0,window.location.href))')
    .replace(/import\.meta\.resolve/g, 'undefined')
    .replace(/import\.meta\.url/g, '(typeof location!=="undefined"?location.href:"")')
    .replace(/<\/script/gi, '<\\/script')
    .replace(/<script/gi, '\\x3cscript')
    .replace(/<!--/g, '\\x3c!--');
}

function prepareCpanelArtifacts() {
  if (!fs.existsSync(distDir)) {
    console.warn('[prepare-cpanel] dist/ directory not found, skipping.');
    return;
  }

  const distAssetsDir = path.join(distDir, 'assets');
  const rootAssetsDir = path.join(rootDir, 'assets');
  const baseVer = getAppVersionNumber();
  const hashSum = crypto.createHash('sha1');

  if (fs.existsSync(distAssetsDir)) {
    fs.mkdirSync(rootAssetsDir, { recursive: true });

    const assetFiles = fs.readdirSync(distAssetsDir);
    const mainJs = assetFiles.find((f) => f === 'app.bundle.js' || /^index-.*\.js$/.test(f));
    const mainCss = assetFiles.find((f) => f === 'app.bundle.css' || /^index-.*\.css$/.test(f));

    if (mainJs) {
      let rawJs = fs.readFileSync(path.join(distAssetsDir, mainJs), 'utf-8');
      rawJs = sanitizeClassicBundleJs(rawJs);
      hashSum.update(rawJs);
      const wrappedJs = `/* StockMaster BD Production Bundle ${baseVer} */\n(function(){\n${rawJs}\n})();\n`;
      fs.writeFileSync(path.join(distAssetsDir, 'app.bundle.js'), wrappedJs, 'utf-8');
      fs.writeFileSync(path.join(rootAssetsDir, 'app.bundle.js'), wrappedJs, 'utf-8');
    }

    // Build dedicated lightweight Customer Storefront bundle (excludes all 13 Admin Panel views)
    const storefrontEntry = path.join(rootDir, 'src', 'storefront-main.tsx');
    if (fs.existsSync(storefrontEntry)) {
      try {
        const sfBuild = buildSync({
          entryPoints: [storefrontEntry],
          bundle: true,
          minify: true,
          format: 'iife',
          target: ['es2020'],
          write: false,
          define: {
            'process.env.NODE_ENV': '"production"',
            'import.meta.env.VITE_API_BASE_URL': '"/api"',
            'import.meta.env.DEV': 'false',
            'import.meta.env.PROD': 'true',
            'import.meta.env.MODE': '"production"',
            'import.meta.env.SSR': 'false',
            'import.meta.env': '{"VITE_API_BASE_URL":"/api","DEV":false,"PROD":true,"MODE":"production","SSR":false}',
            'import.meta.url': 'window.location.href'
          },
          loader: {
            '.css': 'empty'
          }
        });
        if (sfBuild.outputFiles && sfBuild.outputFiles.length > 0) {
          let sfRawJs = sfBuild.outputFiles[0].text;
          sfRawJs = sanitizeClassicBundleJs(sfRawJs);
          const wrappedSfJs = `/* StockMaster BD Storefront Bundle ${baseVer} */\n(function(){\n${sfRawJs}\n})();\n`;
          fs.writeFileSync(path.join(distAssetsDir, 'storefront.bundle.js'), wrappedSfJs, 'utf-8');
          fs.writeFileSync(path.join(rootAssetsDir, 'storefront.bundle.js'), wrappedSfJs, 'utf-8');
        }
      } catch (sfErr) {
        console.warn('[prepare-cpanel] Warning: storefront.bundle.js build fallback to app.bundle.js:', sfErr);
      }
    }

    if (mainCss) {
      let rawCss = fs.readFileSync(path.join(distAssetsDir, mainCss), 'utf-8');
      rawCss = rawCss.replace(/^\/\* StockMaster BD Production Styles [^*]*\*\/\r?\n/, '');
      rawCss = rawCss.replace(/<\/style/gi, '<\\/style');
      hashSum.update(rawCss);
      const wrappedCss = `/* StockMaster BD Production Styles ${baseVer} */\n${rawCss}\n`;
      fs.writeFileSync(path.join(distAssetsDir, 'app.bundle.css'), wrappedCss, 'utf-8');
      fs.writeFileSync(path.join(rootAssetsDir, 'app.bundle.css'), wrappedCss, 'utf-8');
    }
  }

  const shortHash = hashSum.digest('hex').slice(0, 8);
  const buildVerTag = `${baseVer}_${shortHash}`;

  // 1. Update root index.html so its fallback bundle version is always synced to the latest build
  const rootIndexHtmlPath = path.join(rootDir, 'index.html');
  if (fs.existsSync(rootIndexHtmlPath)) {
    const origRootHtml = fs.readFileSync(rootIndexHtmlPath, 'utf-8');
    const rootHtml = origRootHtml
      .replace(/var\s+cssVer\s*=\s*'[^']+';/, `var cssVer = '${buildVerTag}';`)
      .replace(/var\s+ver\s*=\s*'[^']+';/, `var ver = '${buildVerTag}';`);
    if (rootHtml !== origRootHtml) {
      fs.writeFileSync(rootIndexHtmlPath, rootHtml, 'utf-8');
    }

    // Build clean standalone HTML for dist/index.html and /cpanel-app.html
    const cssLinkTag = `    <link rel="stylesheet" href="./assets/app.bundle.css?v=${buildVerTag}" onerror="this.onerror=null;this.href='/assets/app.bundle.css?v=${buildVerTag}';">\n    <style>`;
    const standaloneHtml = rootHtml
      .replace('    <style>', cssLinkTag)
      .replace(/<script type="module" src="\/src\/main\.tsx"><\/script>\s*/, '');
    fs.writeFileSync(path.join(distDir, 'index.html'), standaloneHtml, 'utf-8');
    fs.writeFileSync(path.join(distDir, 'cpanel-app.html'), standaloneHtml, 'utf-8');
    fs.writeFileSync(path.join(rootDir, 'cpanel-app.html'), standaloneHtml, 'utf-8');
  }

  // 2. Update root index.php, public/index.php, and dist/index.php with the latest buildVerTag
  const rootIndexPhp = path.join(rootDir, 'index.php');
  if (fs.existsSync(rootIndexPhp)) {
    let phpContent = fs.readFileSync(rootIndexPhp, 'utf-8');
    phpContent = phpContent.replace(/\$buildTag\s*=\s*'[^']+';/, `$buildTag = '${buildVerTag}';`);
    fs.writeFileSync(rootIndexPhp, phpContent, 'utf-8');
    fs.writeFileSync(path.join(rootDir, 'public', 'index.php'), phpContent, 'utf-8');
    fs.writeFileSync(path.join(distDir, 'index.php'), phpContent, 'utf-8');
  }

  // Ensure /public/assets/aistudio/* is always preserved in /assets/aistudio/* and /dist/assets/aistudio/*
  const publicAiStudioDir = path.join(rootDir, 'public', 'assets', 'aistudio');
  if (fs.existsSync(publicAiStudioDir)) {
    copyDirRecursive(publicAiStudioDir, path.join(rootAssetsDir, 'aistudio'));
    copyDirRecursive(publicAiStudioDir, path.join(distAssetsDir, 'aistudio'));
  }

  // Sync physical /uploads/* into /dist/uploads/*
  const rootUploadsDir = path.join(rootDir, 'uploads');
  const distUploadsDir = path.join(distDir, 'uploads');
  fs.mkdirSync(path.join(rootUploadsDir, 'products'), { recursive: true });
  fs.mkdirSync(path.join(rootUploadsDir, 'logos'), { recursive: true });
  copyDirRecursive(rootUploadsDir, distUploadsDir);

  // Sync PHP public API (/backend/api/*) into root /api/* AND /dist/api/*
  const backendApiDir = path.join(rootDir, 'backend', 'api');
  const rootApiDir = path.join(rootDir, 'api');
  const distApiDir = path.join(distDir, 'api');
  if (fs.existsSync(backendApiDir)) {
    copyDirRecursive(backendApiDir, rootApiDir);
    copyDirRecursive(backendApiDir, distApiDir);
  }

  // Copy SQL installer file into root /api/ and /dist/api/
  const sqlFile = path.join(rootDir, 'database', 'cpanel_complete_install.sql');
  if (fs.existsSync(sqlFile)) {
    fs.mkdirSync(rootApiDir, { recursive: true });
    fs.mkdirSync(distApiDir, { recursive: true });
    fs.copyFileSync(sqlFile, path.join(rootApiDir, 'cpanel_complete_install.sql'));
    fs.copyFileSync(sqlFile, path.join(distApiDir, 'cpanel_complete_install.sql'));
  }

  // Copy backend/, database/, install.php, .htaccess into dist/
  const backendDir = path.join(rootDir, 'backend');
  const distBackendDir = path.join(distDir, 'backend');
  for (const staleJson of [
    path.join(backendDir, 'config', 'erp_persistent_state.json'),
    path.join(backendDir, 'erp_persistent_state.json'),
    path.join(distBackendDir, 'config', 'erp_persistent_state.json'),
    path.join(distBackendDir, 'erp_persistent_state.json')
  ]) {
    try {
      if (fs.existsSync(staleJson)) fs.unlinkSync(staleJson);
    } catch {
      // ignore
    }
  }
  if (fs.existsSync(backendDir)) {
    copyDirRecursive(backendDir, distBackendDir, new Set(['erp_persistent_state.json', 'env.php', '.htaccess']));
  }

  const databaseDir = path.join(rootDir, 'database');
  const distDatabaseDir = path.join(distDir, 'database');
  if (fs.existsSync(databaseDir)) {
    copyDirRecursive(databaseDir, distDatabaseDir, new Set(['.htaccess']));
  }

  const installerPhp = path.join(rootDir, 'backend', 'api', 'install.php');
  if (fs.existsSync(installerPhp)) {
    fs.copyFileSync(installerPhp, path.join(distDir, 'install.php'));
    fs.copyFileSync(installerPhp, path.join(rootDir, 'install.php'));
  }

  const publicHtaccess = path.join(rootDir, 'public', '.htaccess');
  if (fs.existsSync(publicHtaccess)) {
    fs.copyFileSync(publicHtaccess, path.join(distDir, '.htaccess'));
    fs.copyFileSync(publicHtaccess, path.join(distDir, 'htaccess.txt'));
    fs.copyFileSync(publicHtaccess, path.join(rootDir, '.htaccess'));
    fs.copyFileSync(publicHtaccess, path.join(rootDir, 'htaccess.txt'));
  }

  console.log(`[prepare-cpanel] Root and dist/ cPanel/Hostinger/CyberPanel single-bundle (${buildVerTag}) synchronized successfully.`);
}

prepareCpanelArtifacts();

