-- ============================================================================
-- StockMaster BD - Demo Seed Data for MySQL / MariaDB (phpMyAdmin Import)
-- Run AFTER importing /database/schema.sql
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+06:00';

-- 1. Organization
INSERT INTO `organizations` (`id`, `code`, `name_bn`, `name_en`, `tax_bin`, `phone`, `email`, `address`, `currency_symbol`, `vat_rate`, `invoice_prefix`) VALUES
(1, 'ORG-AMB', 'স্টকমাস্টার বিডি - আল-মদিনা সুপার শপ ও ডিস্ট্রিবিউশন', 'StockMaster BD - Al-Madina Super Shop & Distribution', 'BIN: 002349182-0102', '+8801711234567', 'info@stockmasterbd.com', 'প্লট ৪২, রোড ৭, ধানমন্ডি / তেজগাঁও লিংক রোড, ঢাকা-১২০৫', '৳', 5.00, 'SMB');

-- 2. Branches & Warehouses
INSERT INTO `branches` (`id`, `organization_id`, `code`, `name`, `branch_type`, `phone`, `address`) VALUES
(1, 1, 'BR-DHN-01', 'ধানমন্ডি সুপার শপ ব্রাঞ্চ (মেইন স্টোর)', 'retail_shop', '+8801711234567', 'বাড়ি ১২, রোড ৪/এ, ধানমন্ডি, ঢাকা'),
(2, 1, 'WH-TEJ-01', 'তেজগাঁও সেন্ট্রাল ওয়্যারহাউজ (সেন্ট্রাল গুদাম)', 'central_warehouse', '+8801711998877', 'শিল্প এলাকা, তেজগাঁও, ঢাকা-১২০৮'),
(3, 1, 'DP-MIR-01', 'মিরপুর পাইকারি ডিস্ট্রিবিউশন ডিপো', 'distribution_hub', '+8801711445566', 'সেকশন ১০, গোলচত্বর সংলগ্ন, মিরপুর, ঢাকা');

-- 3. Users (Default Demo Password for all: Admin@1234 -> bcrypt hash)
INSERT INTO `users` (`id`, `organization_id`, `branch_id`, `full_name`, `username`, `email`, `phone`, `password_hash`, `role`) VALUES
(1, 1, 1, 'আলহাজ্ব মো: কামরুল হাসান', 'admin', 'owner@stockmasterbd.com', '+8801711234567', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin'),
(2, 1, 1, 'কাজী শাহেদ আলম (ম্যানেজার)', 'manager', 'manager@stockmasterbd.com', '+8801711334455', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'store_manager'),
(3, 1, 1, 'মো: আব্দুল্লাহ (ক্যাশিয়ার-১)', 'cashier1', 'cashier1@stockmasterbd.com', '+8801819665544', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cashier'),
(4, 1, 3, 'মোঃ তারেকুল ইসলাম (ডিস্ট্রিবিউশন)', 'dist_mgr', 'tarek@stockmasterbd.com', '+8801719882233', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'distribution_mgr'),
(6, 1, 1, 'সিস্টেম ডেভেলপার (Developer)', 'developer', 'developer@stockflowbd.com', '+8801700000000', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'developer');

-- 4. Categories & Brands
INSERT INTO `categories` (`id`, `organization_id`, `name_bn`, `name_en`, `slug`) VALUES
(1, 1, 'ভোজ্যতেল ও ঘি', 'Edible Oil & Ghee', 'edible-oil'),
(2, 1, 'চাল, ডাল ও আটা', 'Rice, Lentils & Flour', 'grains-staples'),
(3, 1, 'পানীয় ও গুঁড়ো দুধ', 'Beverages & Milk Powder', 'beverages-dairy'),
(4, 1, 'মসলা ও রান্নার উপকরণ', 'Spices & Culinary', 'spices'),
(5, 1, 'সাবান, শ্যাম্পু ও ডিটারজেন্ট', 'Soaps & Detergents', 'toiletries');

INSERT INTO `brands` (`id`, `organization_id`, `name`, `origin_country`) VALUES
(1, 1, 'তীর / সিটি গ্রুপ (Teer)', 'Bangladesh'),
(2, 1, 'রূপচাঁদা / বিইওএল (Rupchanda)', 'Bangladesh'),
(3, 1, 'প্রাণ ফুডস (PRAN)', 'Bangladesh'),
(4, 1, 'বসুন্ধরা গ্রুপ (Bashundhara)', 'Bangladesh'),
(5, 1, 'এসিআই পিওর (ACI Pure)', 'Bangladesh'),
(6, 1, 'স্কয়ার কনজিউমার (Radhuni/Chaka)', 'Bangladesh');

-- 5. Products (With Weighted Average Cost)
INSERT INTO `products` (`id`, `organization_id`, `category_id`, `brand_id`, `sku`, `barcode`, `name_bn`, `name_en`, `unit`, `pack_size`, `purchase_price`, `avg_cost`, `retail_price`, `wholesale_price`, `min_wholesale_qty`, `reorder_level`, `vat_percent`, `batch_number`, `expiry_date`) VALUES
(1, 1, 1, 1, 'OIL-TEER-5L', '89411001001', 'তীর ফর্টিফাইড সয়াবিন তেল ৫ লিটার', 'Teer Fortified Soyabean Oil 5L', 'বোতল (Bottle)', 4, 860.00, 860.0000, 940.00, 890.00, 8, 20.00, 5.00, 'TR-2603-A', '2027-09-15'),
(2, 1, 1, 2, 'OIL-RUP-1L', '89411001002', 'রূপচাঁদা সয়াবিন তেল ১ লিটার', 'Rupchanda Soyabean Oil 1L', 'বোতল (Bottle)', 12, 172.00, 172.0000, 190.00, 179.00, 24, 30.00, 5.00, 'RP-2601-B', '2027-08-20'),
(3, 1, 2, 4, 'RICE-MINI-50KG', '89411002001', 'মিনিকেট চাল প্রিমিয়াম ৫০ কেজি বস্তা', 'Miniket Rice Premium 50kg Sack', 'বস্তা (Sack)', 1, 3550.00, 3550.0000, 3850.00, 3680.00, 5, 15.00, 0.00, 'MK-50-2026', '2027-12-01'),
(4, 1, 4, 5, 'SALT-ACI-1KG', '89411004001', 'এসিআই পিওর আয়োডিনযুক্ত লবণ ১ কেজি', 'ACI Pure Iodized Salt 1kg', 'প্যাকেট (Pack)', 25, 36.00, 36.0000, 42.00, 38.00, 50, 40.00, 0.00, 'SLT-2601', '2028-01-01'),
(5, 1, 4, 6, 'SPICE-RADH-TUR-200G', '89411004002', 'রাঁধুনী গুঁড়া হলুদ ২০০ গ্রাম', 'Radhuni Turmeric Powder 200g', 'প্যাক (Pack)', 36, 95.00, 95.0000, 115.00, 102.00, 36, 20.00, 5.00, 'RD-TR-09', '2027-12-15');

-- 6. Branch Stock Balances
INSERT INTO `branch_stocks` (`organization_id`, `branch_id`, `product_id`, `quantity`) VALUES
(1, 1, 1, 34.00), (1, 2, 1, 240.00), (1, 3, 1, 80.00),
(1, 1, 2, 52.00), (1, 2, 2, 480.00), (1, 3, 2, 120.00),
(1, 1, 3, 12.00), (1, 2, 3, 180.00), (1, 3, 3, 65.00),
(1, 1, 4, 85.00), (1, 2, 4, 600.00), (1, 3, 4, 200.00),
(1, 1, 5, 45.00), (1, 2, 5, 280.00), (1, 3, 5, 90.00);

-- 7. Suppliers & Customers
INSERT INTO `suppliers` (`id`, `organization_id`, `company_name`, `contact_person`, `phone`, `email`, `address`, `bank_details`, `opening_payable`, `current_payable`) VALUES
(1, 1, 'সিটি গ্রুপ / তীর এডিবল অয়েলস লি:', 'জনাব সাজ্জাদ হোসেন', '+8801713009911', 'sales@citygroupbd.com', 'সিটি ভবন, মতিঝিল বা/এ, ঢাকা-১০০০', 'BRAC Bank A/C: 1501203498001', 106000.00, 142000.00),
(2, 1, 'বসুন্ধরা ফুড অ্যান্ড বেভারেজ ইন্ডাস্ট্রিজ', 'জনাব মাহমুদুর রহমান', '+8801711884422', 'order@bashundharagroup.com', 'বসুন্ধরা আবাসিক এলাকা, বারিধারা, ঢাকা', 'Islami Bank BD Ltd A/C: 20501890044', 131000.00, 215000.00);

INSERT INTO `customers` (`id`, `organization_id`, `name`, `phone`, `address`, `route_territory`, `customer_type`, `credit_limit`, `opening_due`, `current_due`) VALUES
(1, 1, 'করিম ব্রাদার্স জেনারেল স্টোর', '+8801712001122', 'দোকান নং ১৪, কাওরান বাজার কাঁচামাল মার্কেট, ঢাকা', 'কাওরান বাজার পাইকারি রুট', 'wholesale', 150000.00, 13500.00, 38500.00),
(2, 1, 'ভাই ভাই ডিপার্টমেন্টাল স্টোর', '+8801815334455', 'প্লট ৮, রোড ৩, মিরপুর সেকশন ১০, ঢাকা', 'মিরপুর ডিস্ট্রিবিউশন রুট - ০১', 'wholesale', 100000.00, 47200.00, 47200.00);
