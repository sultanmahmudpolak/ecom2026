-- ============================================================================
-- StockMaster BD - 1-Click Complete MySQL / MariaDB Installer for cPanel
-- File: cpanel_complete_install.sql (Schema + Demo Data + Customer Ledger)
-- How to use in cPanel:
--   1. Open cPanel -> MySQL Database Wizard -> Create Database & User
--   2. Open cPanel -> phpMyAdmin -> Click your Database on the left
--   3. Click "Import" tab at the top -> Choose this file -> Click "Import"
-- Engine: InnoDB | Charset: utf8mb4 (Bangla & English) | Timezone: +06:00
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+06:00';
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

-- ----------------------------------------------------------------------------
-- 1. ORGANIZATIONS (Multi-Business Tenant Isolation)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `organizations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(32) NOT NULL UNIQUE,
    `name_bn` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `tax_bin` VARCHAR(64) DEFAULT NULL,
    `phone` VARCHAR(32) NOT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `address` TEXT NOT NULL,
    `currency_symbol` VARCHAR(10) NOT NULL DEFAULT '৳',
    `vat_rate` DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    `invoice_prefix` VARCHAR(12) NOT NULL DEFAULT 'SMB',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. WAREHOUSES & BRANCHES (Retail Stores, Central Godowns, Distribution Depots)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `branches` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `code` VARCHAR(32) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `branch_type` ENUM('retail_shop', 'central_warehouse', 'distribution_hub') NOT NULL DEFAULT 'retail_shop',
    `phone` VARCHAR(32) DEFAULT NULL,
    `address` TEXT NOT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_branch_code` (`organization_id`, `code`),
    CONSTRAINT `fk_branches_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. USERS, ROLES & PERMISSIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED DEFAULT NULL,
    `full_name` VARCHAR(150) NOT NULL,
    `username` VARCHAR(64) NOT NULL UNIQUE,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `phone` VARCHAR(32) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('developer', 'super_admin', 'store_manager', 'cashier', 'distribution_mgr', 'sales_rep', 'auditor') NOT NULL DEFAULT 'cashier',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_users_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_users_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. CATEGORIES & BRANDS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `app_id` VARCHAR(64) DEFAULT NULL,
    `organization_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `name_bn` VARCHAR(150) NOT NULL,
    `name_en` VARCHAR(150) NOT NULL,
    `slug` VARCHAR(150) NOT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY `uq_cat_app_id` (`app_id`),
    UNIQUE KEY `uq_org_cat_slug` (`organization_id`, `slug`),
    CONSTRAINT `fk_categories_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `brands` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `app_id` VARCHAR(64) DEFAULT NULL,
    `organization_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `name` VARCHAR(150) NOT NULL,
    `origin_country` VARCHAR(100) NOT NULL DEFAULT 'Bangladesh',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY `uq_brand_app_id` (`app_id`),
    CONSTRAINT `fk_brands_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. PRODUCTS (With Weighted Average Costing - WAC & 2-Way phpMyAdmin Sync)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `app_id` VARCHAR(64) DEFAULT NULL,
    `organization_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `category_id` INT UNSIGNED DEFAULT 1,
    `brand_id` INT UNSIGNED DEFAULT 1,
    `sku` VARCHAR(64) NOT NULL,
    `barcode` VARCHAR(64) NOT NULL,
    `name_bn` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'পিস (Pcs)',
    `pack_size` INT UNSIGNED NOT NULL DEFAULT 1,
    `purchase_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `avg_cost` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
    `retail_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `wholesale_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `min_wholesale_qty` INT UNSIGNED NOT NULL DEFAULT 1,
    `reorder_level` DECIMAL(12,2) NOT NULL DEFAULT 10.00,
    `vat_percent` DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    `batch_number` VARCHAR(64) DEFAULT NULL,
    `expiry_date` DATE DEFAULT NULL,
    `is_expiry_tracked` TINYINT(1) NOT NULL DEFAULT 0,
    `image_url` TEXT DEFAULT NULL,
    `is_landing_page` TINYINT(1) NOT NULL DEFAULT 0,
    `landing_slug` VARCHAR(150) DEFAULT NULL,
    `product_json` LONGTEXT DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_prod_app_id` (`app_id`),
    INDEX `idx_prod_sku` (`sku`),
    INDEX `idx_prod_name` (`name_bn`, `name_en`),
    CONSTRAINT `fk_products_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_products_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_products_brand` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. BRANCH STOCK BALANCES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `branch_stocks` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `branch_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `product_id` INT UNSIGNED NOT NULL,
    `quantity` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `stock_qty` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `reserved_qty` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_branch_product` (`branch_id`, `product_id`),
    CONSTRAINT `fk_bstock_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_bstock_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_bstock_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. TRACEABLE STOCK MOVEMENT LEDGER
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_movements` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `movement_type` ENUM(
        'OPENING_STOCK',
        'PURCHASE_RECEIPT',
        'PURCHASE_RETURN',
        'POS_SALE',
        'WHOLESALE_CHALLAN',
        'SALE_RETURN',
        'TRANSFER_OUT',
        'TRANSFER_IN',
        'ADJUSTMENT'
    ) NOT NULL,
    `reference_type` VARCHAR(50) NOT NULL,
    `reference_no` VARCHAR(100) NOT NULL,
    `qty_in` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `qty_out` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `balance_after` DECIMAL(15,2) NOT NULL,
    `unit_cost` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
    `wac_after` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sm_product_date` (`product_id`, `created_at`),
    INDEX `idx_sm_branch_date` (`branch_id`, `created_at`),
    INDEX `idx_sm_ref` (`reference_no`),
    CONSTRAINT `fk_sm_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sm_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sm_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sm_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. SUPPLIERS & SUPPLIER PAYABLE LEDGER
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `suppliers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `company_name` VARCHAR(255) NOT NULL,
    `contact_person` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(32) NOT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `bank_details` VARCHAR(255) DEFAULT NULL,
    `opening_payable` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `current_payable` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_supp_phone` (`phone`),
    CONSTRAINT `fk_suppliers_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `supplier_ledger` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `supplier_id` INT UNSIGNED NOT NULL,
    `entry_type` ENUM('OPENING', 'PURCHASE_BILL', 'PURCHASE_RETURN', 'PAYMENT_VOUCHER') NOT NULL,
    `reference_no` VARCHAR(100) NOT NULL,
    `debit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `credit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `balance_after` DECIMAL(15,2) NOT NULL,
    `payment_method` VARCHAR(32) DEFAULT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sl_supplier` (`supplier_id`, `created_at`),
    CONSTRAINT `fk_sl_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sl_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. CUSTOMERS & CUSTOMER DUE LEDGER (গ্রাহক খতিয়ান বিবরণী)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `app_id` VARCHAR(64) DEFAULT NULL,
    `organization_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `name` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(32) NOT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `route_territory` VARCHAR(150) DEFAULT NULL,
    `customer_type` VARCHAR(32) NOT NULL DEFAULT 'retail',
    `credit_limit` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `opening_due` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `current_due` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_cust_app_id` (`app_id`),
    INDEX `idx_cust_phone` (`phone`),
    CONSTRAINT `fk_customers_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `customer_ledger` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL DEFAULT 1,
    `customer_id` INT UNSIGNED NOT NULL,
    `entry_type` ENUM('OPENING', 'SALE_INVOICE', 'SALE_RETURN', 'PAYMENT_COLLECTION') NOT NULL,
    `reference_no` VARCHAR(100) NOT NULL,
    `debit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `credit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `balance_after` DECIMAL(15,2) NOT NULL,
    `payment_method` VARCHAR(32) DEFAULT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_cl_customer` (`customer_id`, `created_at`),
    CONSTRAINT `fk_cl_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cl_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. PURCHASE ORDERS & GOODS RECEIPTS (GRN) + PURCHASE RETURNS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `purchases` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `supplier_id` INT UNSIGNED NOT NULL,
    `po_number` VARCHAR(64) NOT NULL,
    `idempotency_key` VARCHAR(64) NOT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `paid_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `due_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_method` ENUM('cash', 'bank', 'bkash', 'nagad', 'cheque', 'due') NOT NULL DEFAULT 'bank',
    `payment_ref` VARCHAR(120) DEFAULT NULL,
    `status` ENUM('posted', 'returned_partial', 'returned_full') NOT NULL DEFAULT 'posted',
    `received_date` DATE NOT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_po_number` (`organization_id`, `po_number`),
    UNIQUE KEY `uq_pur_idempotency` (`organization_id`, `idempotency_key`),
    CONSTRAINT `fk_pur_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pur_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pur_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `purchase_items` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `purchase_id` BIGINT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `quantity` DECIMAL(15,2) NOT NULL,
    `returned_qty` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `unit_cost` DECIMAL(15,2) NOT NULL,
    `line_total` DECIMAL(15,2) NOT NULL,
    `batch_number` VARCHAR(64) DEFAULT NULL,
    `expiry_date` DATE DEFAULT NULL,
    CONSTRAINT `fk_pitem_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pitem_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `purchase_returns` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `purchase_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `supplier_id` INT UNSIGNED NOT NULL,
    `return_no` VARCHAR(64) NOT NULL UNIQUE,
    `product_id` INT UNSIGNED NOT NULL,
    `return_qty` DECIMAL(15,2) NOT NULL,
    `unit_cost` DECIMAL(15,2) NOT NULL,
    `total_return_amount` DECIMAL(15,2) NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_preturn_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. POS & WHOLESALE SALES INVOICES + SALES RETURNS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sales` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED DEFAULT NULL,
    `invoice_no` VARCHAR(64) NOT NULL,
    `idempotency_key` VARCHAR(64) NOT NULL,
    `channel` ENUM('retail_pos', 'wholesale_distribution') NOT NULL DEFAULT 'retail_pos',
    `customer_name` VARCHAR(255) NOT NULL DEFAULT 'Walk-in Customer',
    `customer_phone` VARCHAR(32) DEFAULT NULL,
    `delivery_challan_no` VARCHAR(64) DEFAULT NULL,
    `delivery_route` VARCHAR(150) DEFAULT NULL,
    `sales_rep_name` VARCHAR(150) DEFAULT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `tax_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `paid_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `change_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `due_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_method` ENUM('cash', 'bkash', 'nagad', 'rocket', 'bank', 'due', 'split') NOT NULL DEFAULT 'cash',
    `status` ENUM('posted', 'dispatched', 'delivered', 'returned_partial', 'returned_full') NOT NULL DEFAULT 'posted',
    `notes` TEXT DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_invoice_no` (`organization_id`, `invoice_no`),
    UNIQUE KEY `uq_sale_idempotency` (`organization_id`, `idempotency_key`),
    INDEX `idx_sales_created` (`created_at`),
    INDEX `idx_sales_channel` (`channel`),
    CONSTRAINT `fk_sales_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sales_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sales_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sale_items` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `sale_id` BIGINT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `product_name` VARCHAR(255) NOT NULL,
    `unit` VARCHAR(50) NOT NULL,
    `quantity` DECIMAL(15,2) NOT NULL,
    `returned_qty` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `unit_price` DECIMAL(15,2) NOT NULL,
    `wac_cost_at_sale` DECIMAL(15,4) NOT NULL,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `line_total` DECIMAL(15,2) NOT NULL,
    CONSTRAINT `fk_sitem_sale` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sitem_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sales_returns` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `sale_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED DEFAULT NULL,
    `return_no` VARCHAR(64) NOT NULL UNIQUE,
    `product_id` INT UNSIGNED NOT NULL,
    `return_qty` DECIMAL(15,2) NOT NULL,
    `unit_price` DECIMAL(15,2) NOT NULL,
    `total_refund_amount` DECIMAL(15,2) NOT NULL,
    `refund_method` ENUM('cash_refund', 'adjust_customer_due') NOT NULL DEFAULT 'cash_refund',
    `reason` VARCHAR(255) NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_sreturn_sale` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. EXPENSES & FINANCIAL ACCOUNTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expenses` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `voucher_no` VARCHAR(64) NOT NULL UNIQUE,
    `category` ENUM('rent', 'salary', 'electricity', 'transport', 'packaging', 'entertainment', 'maintenance', 'other') NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `payment_method` ENUM('cash', 'bkash', 'nagad', 'bank') NOT NULL DEFAULT 'cash',
    `paid_to` VARCHAR(150) NOT NULL,
    `expense_date` DATE NOT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_exp_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_exp_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. IMMUTABLE SECURITY AUDIT LOGS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED DEFAULT NULL,
    `user_name` VARCHAR(150) NOT NULL,
    `user_role` VARCHAR(50) NOT NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(64) NOT NULL,
    `entity_ref` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL DEFAULT '127.0.0.1',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_org_date` (`organization_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. PERSISTENT ERP STATE STORE & E-COMMERCE ORDERS (REAL-TIME FULL STATE SYNC)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `app_state_store` (
    `id` INT UNSIGNED NOT NULL PRIMARY KEY DEFAULT 1,
    `state_json` LONGTEXT NOT NULL,
    `updated_at` BIGINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `online_orders` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `order_no` VARCHAR(64) NOT NULL,
    `invoice_no` VARCHAR(64) DEFAULT NULL,
    `customer_name` VARCHAR(255) NOT NULL,
    `customer_phone` VARCHAR(32) NOT NULL,
    `delivery_area` VARCHAR(150) DEFAULT NULL,
    `delivery_address` TEXT DEFAULT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `delivery_charge` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_method` VARCHAR(50) NOT NULL DEFAULT 'cod',
    `payment_status` VARCHAR(32) NOT NULL DEFAULT 'unpaid',
    `order_status` VARCHAR(32) NOT NULL DEFAULT 'pending',
    `order_source` VARCHAR(64) DEFAULT 'storefront',
    `courier_provider` VARCHAR(50) DEFAULT NULL,
    `courier_consignment_id` VARCHAR(80) DEFAULT NULL,
    `courier_tracking_code` VARCHAR(80) DEFAULT NULL,
    `courier_status` VARCHAR(60) DEFAULT NULL,
    `items_json` LONGTEXT DEFAULT NULL,
    `order_json` LONGTEXT DEFAULT NULL,
    `created_at` VARCHAR(64) DEFAULT NULL,
    `updated_at` VARCHAR(64) DEFAULT NULL,
    INDEX `idx_oo_phone` (`customer_phone`),
    INDEX `idx_oo_status` (`order_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `incomplete_orders` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `session_key` VARCHAR(120) NOT NULL,
    `customer_name` VARCHAR(255) DEFAULT NULL,
    `customer_phone` VARCHAR(32) NOT NULL,
    `delivery_area` VARCHAR(150) DEFAULT NULL,
    `delivery_address` TEXT DEFAULT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `delivery_charge` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `status` VARCHAR(32) NOT NULL DEFAULT 'abandoned',
    `converted_order_id` VARCHAR(64) DEFAULT NULL,
    `converted_order_no` VARCHAR(64) DEFAULT NULL,
    `order_source` VARCHAR(64) DEFAULT 'storefront',
    `items_json` LONGTEXT DEFAULT NULL,
    `lead_json` LONGTEXT DEFAULT NULL,
    `created_at` VARCHAR(64) DEFAULT NULL,
    `updated_at` VARCHAR(64) DEFAULT NULL,
    INDEX `idx_io_phone` (`customer_phone`),
    INDEX `idx_io_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `spin_wheel_leads` (
    `id` VARCHAR(96) NOT NULL PRIMARY KEY,
    `source` VARCHAR(32) NOT NULL DEFAULT 'website',
    `source_type` VARCHAR(32) NOT NULL DEFAULT 'website',
    `customer_name` VARCHAR(255) NOT NULL,
    `customer_phone` VARCHAR(32) NOT NULL,
    `reward_label` VARCHAR(255) DEFAULT NULL,
    `reward_type` VARCHAR(64) NOT NULL DEFAULT 'flat_discount',
    `reward_value` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `prize_label` VARCHAR(255) DEFAULT NULL,
    `prize_type` VARCHAR(64) NOT NULL DEFAULT 'flat_discount',
    `prize_value` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `coupon_code` VARCHAR(64) DEFAULT NULL,
    `used_in_order` TINYINT(1) NOT NULL DEFAULT 0,
    `order_invoice_no` VARCHAR(64) DEFAULT NULL,
    `landing_product_id` VARCHAR(96) DEFAULT NULL,
    `landing_product_name` VARCHAR(255) DEFAULT NULL,
    `spin_date_key` VARCHAR(32) DEFAULT NULL,
    `lead_json` LONGTEXT DEFAULT NULL,
    `created_at` VARCHAR(64) DEFAULT NULL,
    INDEX `idx_swl_phone` (`customer_phone`),
    INDEX `idx_swl_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================================
-- INITIAL READY-TO-USE SEED DATA FOR STOCKMASTER BD (KIDS & FASHION MART)
-- ============================================================================

-- 1. Organization
INSERT IGNORE INTO `organizations` (`id`, `code`, `name_bn`, `name_en`, `tax_bin`, `phone`, `email`, `address`, `currency_symbol`, `vat_rate`, `invoice_prefix`) VALUES
(1, 'ORG-KFM', 'কিডস অ্যান্ড ফ্যাশন মার্ট', 'Kids & Fashion Mart', 'BIN: 002349182-0102', '+8801711234567', 'info@stockmasterbd.com', 'প্লট ৪২, রোড ৭, ধানমন্ডি / বসুন্ধরা সিটি লেভেল-৩, ঢাকা-১২০৫', '৳', 5.00, 'KFM');

-- 2. Branches & Warehouses
INSERT IGNORE INTO `branches` (`id`, `organization_id`, `code`, `name`, `branch_type`, `phone`, `address`) VALUES
(1, 1, 'BR-DHN-01', 'ধানমন্ডি ফ্ল্যাগশিপ ফ্যাশন শোরুম (মেইন স্টোর)', 'retail_shop', '+8801711234567', 'বাড়ি ১২, রোড ৪/এ, ধানমন্ডি, ঢাকা'),
(2, 1, 'WH-TEJ-01', 'তেজগাঁও সেন্ট্রাল অ্যাপারেল ওয়্যারহাউজ (সেন্ট্রাল গুদাম)', 'central_warehouse', '+8801711998877', 'শিল্প এলাকা, তেজগাঁও, ঢাকা-১২০৮'),
(3, 1, 'DP-MIR-01', 'মিরপুর ফ্যাশন ডিস্ট্রিবিউশন হাব', 'distribution_hub', '+8801711445566', 'সেকশন ১০, গোলচত্বর সংলগ্ন, মিরপুর, ঢাকা');

-- 3. Staff Users (Encrypted Password Hashes)
INSERT IGNORE INTO `users` (`id`, `organization_id`, `branch_id`, `full_name`, `username`, `email`, `phone`, `password_hash`, `role`) VALUES
(1, 1, 1, 'আলহাজ্ব মো: কামরুল হাসান (মালিক)', 'admin', 'owner@stockmasterbd.com', '+8801711234567', 'sha256$sm2026init$ad5a01d11fb52cc2f3b52a28701f794d8712cf945f4544a3b1d5e8761f97e3de', 'super_admin'),
(2, 1, 1, 'কাজী শাহেদ আলম (ম্যানেজার)', 'manager', 'manager@stockmasterbd.com', '+8801711334455', 'sha256$sm2026init$ad5a01d11fb52cc2f3b52a28701f794d8712cf945f4544a3b1d5e8761f97e3de', 'store_manager'),
(3, 1, 1, 'মো: আব্দুল্লাহ (ক্যাশিয়ার-১)', 'cashier1', 'cashier1@stockmasterbd.com', '+8801819665544', 'sha256$sm2026init$ad5a01d11fb52cc2f3b52a28701f794d8712cf945f4544a3b1d5e8761f97e3de', 'cashier'),
(4, 1, 3, 'মোঃ তারেকুল ইসলাম (ডিস্ট্রিবিউশন)', 'dist_mgr', 'tarek@stockmasterbd.com', '+8801719882233', 'sha256$sm2026init$ad5a01d11fb52cc2f3b52a28701f794d8712cf945f4544a3b1d5e8761f97e3de', 'distribution_mgr'),
(5, 1, 3, 'রাকিবুল হাসান (সেলস রিপ্রেজেন্টেটিভ)', 'sr_tarek', 'rakib@stockmasterbd.com', '+8801914556677', 'sha256$sm2026init$ad5a01d11fb52cc2f3b52a28701f794d8712cf945f4544a3b1d5e8761f97e3de', 'sales_rep'),
(6, 1, 1, 'সিস্টেম ডেভেলপার (Developer)', 'developer', 'developer@stockflowbd.com', '+8801700000000', 'sha256$sm2026init$ad5a01d11fb52cc2f3b52a28701f794d8712cf945f4544a3b1d5e8761f97e3de', 'developer');

-- 4. Categories & Brands (Synced with Kids & Fashion Mart Storefront)
INSERT IGNORE INTO `categories` (`id`, `app_id`, `organization_id`, `name_bn`, `name_en`, `slug`) VALUES
(1, 'cat_01', 1, 'বেবি ফ্রক ও পার্টি ড্রেস', 'Baby Frock & Party Dress', 'baby-party-dress'),
(2, 'cat_02', 1, 'বেবি বয়েজ পাঞ্জাবি ও সেট', 'Kids Panjabi & Boys Set', 'kids-boys-wear'),
(3, 'cat_03', 1, 'মেনজ পাঞ্জাবি ও শার্ট', 'Men''s Panjabi & Shirt', 'mens-fashion'),
(4, 'cat_04', 1, 'লেডিস কুর্তি ও থ্রি-পিস', 'Ladies Kurti & Three-Piece', 'womens-fashion');

INSERT IGNORE INTO `brands` (`id`, `app_id`, `organization_id`, `name`, `origin_country`) VALUES
(1, 'brand_01', 1, 'লিটল অ্যাঞ্জেল বেবি ওয়্যার (Little Angel)', 'Bangladesh'),
(2, 'brand_02', 1, 'কিডস ক্লাব ফ্যাশন (Kids Club)', 'Bangladesh'),
(3, 'brand_03', 1, 'আড়ং ক্রাফট স্টাইল (Aarong Style)', 'Bangladesh'),
(4, 'brand_04', 1, 'সেইলর ফ্যাশন (Sailor)', 'Bangladesh');

-- 5. Products (Synced with Kids & Fashion Mart Storefront & Landing Pages)
INSERT IGNORE INTO `products` (`id`, `app_id`, `organization_id`, `category_id`, `brand_id`, `sku`, `barcode`, `name_bn`, `name_en`, `unit`, `pack_size`, `purchase_price`, `avg_cost`, `retail_price`, `wholesale_price`, `min_wholesale_qty`, `reorder_level`, `vat_percent`, `batch_number`, `expiry_date`, `is_landing_page`, `landing_slug`) VALUES
(1, 'prod_01', 1, 1, 1, 'BABY-DRESS-01', '89411001001', 'প্রিমিয়াম বেবি গার্লস পার্টি ফ্রক ও গাউন ড্রেস - পিঙ্ক প্রিন্সেস', 'Premium Baby Girls Party Frock & Gown Dress - Pink Princess', 'পিস (Pcs)', 6, 620.00, 620.0000, 950.00, 760.00, 6, 10.00, 5.00, 'BD-2601', '2029-12-31', 0, NULL),
(2, 'prod_02', 1, 1, 1, 'BABY-DRESS-02', '89411001002', 'বেবি গার্লস সফট কটন ফ্লোরাল ফ্রক ও স্কার্ট সেট', 'Baby Girls Soft Cotton Floral Frock & Skirt Set', 'সেট (Set)', 6, 480.00, 480.0000, 750.00, 590.00, 6, 10.00, 5.00, 'BD-2602', '2029-12-31', 0, NULL),
(3, 'prod_03', 1, 2, 2, 'BABY-BOYS-03', '89411002001', 'বেবি বয়েজ এক্সপোর্ট কোয়ালিটি টি-শার্ট ও ডেনিম শর্টস কম্বো সেট', 'Baby Boys Export T-Shirt & Denim Shorts Combo Set', 'সেট (Set)', 6, 520.00, 520.0000, 820.00, 640.00, 6, 10.00, 5.00, 'BB-2603', '2029-12-01', 0, NULL),
(4, 'prod_04', 1, 2, 2, 'BABY-PANJABI-04', '89411002002', 'কিডস এমব্রয়ডারি কটন ফেস্টিভ পাঞ্জাবি ও পায়জামা সেট', 'Kids Embroidered Cotton Festive Panjabi & Pajama Set', 'সেট (Set)', 6, 680.00, 680.0000, 1050.00, 840.00, 6, 10.00, 5.00, 'BP-2604', '2029-11-20', 0, NULL),
(5, 'prod_05', 1, 1, 1, 'BABY-DRESS-05', '89411004001', 'বেবি গার্লস লেস ওয়ার্ক ফেস্টিভ কুর্তি ও প্লাজো সেট', 'Baby Girls Lace Work Festive Kurti & Palazzo Set', 'সেট (Set)', 6, 720.00, 720.0000, 1120.00, 890.00, 6, 10.00, 5.00, 'BK-2605', '2029-01-01', 0, NULL),
(6, 'prod_06', 1, 2, 2, 'BABY-ROMPER-06', '89411003001', 'কিডস প্রিমিয়াম কটন হুডি ও জগার্স উইন্টার/ক্যাজুয়াল সুট', 'Kids Premium Cotton Hoodie & Joggers Casual Suit', 'সেট (Set)', 6, 650.00, 650.0000, 990.00, 790.00, 6, 10.00, 5.00, 'BH-2606', '2029-10-10', 0, NULL),
(7, 'prod_07', 1, 3, 3, 'FASH-PANJABI-07', '89411003002', 'প্রিমিয়াম এমব্রয়ডারি কটন পাঞ্জাবি - রয়েল মেরুন', 'Premium Embroidered Cotton Panjabi - Royal Maroon', 'পিস (Pcs)', 6, 1080.00, 1080.0000, 1590.00, 1280.00, 6, 10.00, 5.00, 'PJ-2607', '2029-02-14', 0, NULL),
(8, 'prod_08', 1, 3, 4, 'FASH-POLO-08', '89411004002', 'এক্সপোর্ট কোয়ালিটি পিকে পোলো টি-শার্ট - ক্লাসিক ব্ল্যাক', 'Export Quality Pique Polo T-Shirt - Classic Black', 'পিস (Pcs)', 12, 420.00, 420.0000, 690.00, 520.00, 12, 15.00, 5.00, 'PL-2608', '2029-12-15', 0, NULL),
(9, 'prod_09', 1, 4, 3, 'FASH-KURTI-09', '89411005001', 'লেডিস এমব্রয়ডারি ফ্যাশন কুর্তি ও টিউনিক টপস', 'Ladies Embroidered Fashion Kurti & Tunic Top', 'পিস (Pcs)', 6, 780.00, 780.0000, 1250.00, 950.00, 6, 10.00, 5.00, 'KR-2609', '2029-06-30', 0, NULL),
(10, 'prod_10', 1, 3, 4, 'FASH-SHIRT-10', '89411005002', 'মেনজ প্রিমিয়াম অক্সফোর্ড কটন ক্যাজুয়াল চেক শার্ট', 'Mens Premium Oxford Cotton Casual Check Shirt', 'পিস (Pcs)', 10, 750.00, 750.0000, 1150.00, 910.00, 10, 10.00, 5.00, 'SH-2610', '2029-01-01', 0, NULL),
(11, 'prod_lp_makhana', 1, 1, 1, 'LP-MAKHANA-01', '89411009001', 'প্রিমিয়াম রোস্টেড মাখানা (হেলদি ফক্স নাটস - ওজন নিয়ন্ত্রণ ও পুষ্টিকর স্ন্যাকস)', 'Premium Roasted Makhana (Healthy Fox Nuts Superfood)', 'প্যাক (Pack)', 1, 320.00, 320.0000, 450.00, 390.00, 6, 10.00, 0.00, 'MK-2601', '2027-12-31', 1, 'makhana');

-- 6. Branch Stock Balances
INSERT IGNORE INTO `branch_stocks` (`organization_id`, `branch_id`, `product_id`, `quantity`) VALUES
(1, 1, 1, 35.00), (1, 2, 1, 140.00), (1, 3, 1, 50.00),
(1, 1, 2, 42.00), (1, 2, 2, 160.00), (1, 3, 2, 60.00),
(1, 1, 3, 38.00), (1, 2, 3, 150.00), (1, 3, 3, 55.00),
(1, 1, 4, 30.00), (1, 2, 4, 120.00), (1, 3, 4, 40.00),
(1, 1, 5, 28.00), (1, 2, 5, 110.00), (1, 3, 5, 45.00),
(1, 1, 6, 32.00), (1, 2, 6, 95.00), (1, 3, 6, 30.00),
(1, 1, 7, 38.00), (1, 2, 7, 140.00), (1, 3, 7, 50.00),
(1, 1, 8, 45.00), (1, 2, 8, 180.00), (1, 3, 8, 60.00),
(1, 1, 9, 34.00), (1, 2, 9, 120.00), (1, 3, 9, 40.00),
(1, 1, 10, 30.00), (1, 2, 10, 110.00), (1, 3, 10, 45.00),
(1, 1, 11, 85.00), (1, 2, 11, 200.00), (1, 3, 11, 60.00);

-- 7. Suppliers & Customers
INSERT IGNORE INTO `suppliers` (`id`, `organization_id`, `company_name`, `contact_person`, `phone`, `email`, `address`, `bank_details`, `opening_payable`, `current_payable`) VALUES
(1, 1, 'সিটি গ্রুপ / তীর এডিবল অয়েলস লি:', 'জনাব সাজ্জাদ হোসেন', '+8801713009911', 'sales@citygroupbd.com', 'সিটি ভবন, মতিঝিল বা/এ, ঢাকা-১০০০', 'BRAC Bank A/C: 1501203498001', 106000.00, 142000.00),
(2, 1, 'বসুন্ধরা ফুড অ্যান্ড বেভারেজ ইন্ডাস্ট্রিজ', 'জনাব মাহমুদুর রহমান', '+8801711884422', 'order@bashundharagroup.com', 'বসুন্ধরা আবাসিক এলাকা, বারিধারা, ঢাকা', 'Islami Bank BD Ltd A/C: 20501890044', 131000.00, 215000.00);

INSERT IGNORE INTO `customers` (`id`, `app_id`, `organization_id`, `name`, `phone`, `address`, `route_territory`, `customer_type`, `credit_limit`, `opening_due`, `current_due`) VALUES
(1, 'cust_01', 1, 'করিম ব্রাদার্স জেনারেল স্টোর', '01712001122', 'দোকান নং ১৪, কাওরান বাজার কাঁচামাল মার্কেট, ঢাকা', 'কাওরান বাজার পাইকারি রুট', 'wholesale', 150000.00, 13500.00, 38500.00),
(2, 'cust_02', 1, 'ভাই ভাই ডিপার্টমেন্টাল স্টোর', '01815334455', 'প্লট ৮, রোড ৩, মিরপুর সেকশন ১০, ঢাকা', 'মিরপুর ডিস্ট্রিবিউশন রুট - ০১', 'wholesale', 100000.00, 47200.00, 47200.00);

-- 8. Initial Customer Ledger Entries (গ্রাহক খতিয়ান বিবরণী)
INSERT IGNORE INTO `customer_ledger` (`id`, `organization_id`, `customer_id`, `entry_type`, `reference_no`, `debit_amount`, `credit_amount`, `balance_after`, `payment_method`, `notes`, `created_by`) VALUES
(1, 1, 1, 'OPENING', 'OPENING-BAL', 13500.00, 0.00, 13500.00, 'due', 'প্রারম্ভিক বকেয়া (Opening Balance)', 1),
(2, 1, 1, 'SALE_INVOICE', 'KFM-DST-20260322-1041', 25000.00, 0.00, 38500.00, 'due', 'পাইকারি চালান বাকিতে বিক্রয়', 4),
(3, 1, 2, 'OPENING', 'OPENING-BAL', 47200.00, 0.00, 47200.00, 'due', 'প্রারম্ভিক বকেয়া (Opening Balance)', 1);

SET FOREIGN_KEY_CHECKS = 1;
