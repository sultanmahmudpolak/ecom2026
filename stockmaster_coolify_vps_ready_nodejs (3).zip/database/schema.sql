-- ============================================================================
-- StockMaster BD - Enterprise Super Shop & Distribution Management System
-- Complete MySQL / MariaDB Schema for cPanel Shared Hosting (phpMyAdmin Ready)
-- Engine: InnoDB | Charset: utf8mb4 (Supports Bangla & English)
-- Timezone: Asia/Dhaka (+06:00) | Currency: Bangladeshi Taka (BDT / ৳)
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+06:00';
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- 1. ORGANIZATIONS (Multi-Business Tenant Isolation)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `organizations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(32) NOT NULL UNIQUE,
    `name_bn` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `tax_bin` VARCHAR(64) DEFAULT NULL,
    `phone` VARCHAR(32) NOT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `address` TEXT NOT NULL,
    `currency_symbol` VARCHAR(10) NOT NULL DEFAULT '৳',
    `vat_rate` DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    `invoice_prefix` VARCHAR(12) NOT NULL DEFAULT 'SMB',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. WAREHOUSES & BRANCHES (Retail Stores, Central Godowns, Distribution Depots)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `branches` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `code` VARCHAR(32) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `branch_type` ENUM('retail_shop', 'central_warehouse', 'distribution_hub') NOT NULL DEFAULT 'retail_shop',
    `phone` VARCHAR(32) DEFAULT NULL,
    `address` TEXT NOT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_branch_code` (`organization_id`, `code`),
    CONSTRAINT `fk_branches_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. USERS, ROLES & PERMISSIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED DEFAULT NULL,
    `full_name` VARCHAR(150) NOT NULL,
    `username` VARCHAR(64) NOT NULL UNIQUE,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `phone` VARCHAR(32) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL, -- PHP password_hash(PASSWORD_DEFAULT)
    `role` ENUM('developer', 'super_admin', 'store_manager', 'cashier', 'distribution_mgr', 'sales_rep', 'auditor') NOT NULL DEFAULT 'cashier',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_users_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_users_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. CATEGORIES & BRANDS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `name_bn` VARCHAR(150) NOT NULL,
    `name_en` VARCHAR(150) NOT NULL,
    `slug` VARCHAR(150) NOT NULL,
    UNIQUE KEY `uq_org_cat_slug` (`organization_id`, `slug`),
    CONSTRAINT `fk_categories_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `brands` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `origin_country` VARCHAR(100) NOT NULL DEFAULT 'Bangladesh',
    CONSTRAINT `fk_brands_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. PRODUCTS (With Weighted Average Costing - WAC)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `category_id` INT UNSIGNED NOT NULL,
    `brand_id` INT UNSIGNED DEFAULT NULL,
    `sku` VARCHAR(64) NOT NULL,
    `barcode` VARCHAR(64) NOT NULL,
    `name_bn` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'পিস (Pcs)',
    `pack_size` INT UNSIGNED NOT NULL DEFAULT 1,
    `purchase_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `avg_cost` DECIMAL(15,4) NOT NULL DEFAULT 0.0000, -- Weighted Average Cost (WAC)
    `retail_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `wholesale_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `min_wholesale_qty` INT UNSIGNED NOT NULL DEFAULT 1,
    `reorder_level` DECIMAL(12,2) NOT NULL DEFAULT 10.00,
    `vat_percent` DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    `batch_number` VARCHAR(64) DEFAULT NULL,
    `expiry_date` DATE DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_sku` (`organization_id`, `sku`),
    UNIQUE KEY `uq_org_barcode` (`organization_id`, `barcode`),
    INDEX `idx_prod_name` (`name_bn`, `name_en`),
    CONSTRAINT `fk_products_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_products_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_products_brand` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. BRANCH STOCK BALANCES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `branch_stocks` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `quantity` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_branch_product` (`branch_id`, `product_id`),
    CONSTRAINT `fk_bstock_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_bstock_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_bstock_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. TRACEABLE STOCK MOVEMENT LEDGER (Immutable Inventory History)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_movements` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `movement_type` ENUM(
        'OPENING_STOCK',
        'PURCHASE_RECEIPT',
        'PURCHASE_RETURN',
        'POS_SALE',
        'WHOLESALE_CHALLAN',
        'SALE_RETURN',
        'TRANSFER_OUT',
        'TRANSFER_IN',
        'ADJUSTMENT'
    ) NOT NULL,
    `reference_type` VARCHAR(50) NOT NULL,
    `reference_no` VARCHAR(100) NOT NULL,
    `qty_in` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `qty_out` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `balance_after` DECIMAL(15,2) NOT NULL,
    `unit_cost` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
    `wac_after` DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sm_product_date` (`product_id`, `created_at`),
    INDEX `idx_sm_branch_date` (`branch_id`, `created_at`),
    INDEX `idx_sm_ref` (`reference_no`),
    CONSTRAINT `fk_sm_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sm_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sm_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sm_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. SUPPLIERS & SUPPLIER PAYABLE LEDGER
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `suppliers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `company_name` VARCHAR(255) NOT NULL,
    `contact_person` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(32) NOT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `bank_details` VARCHAR(255) DEFAULT NULL,
    `opening_payable` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `current_payable` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_supp_phone` (`phone`),
    CONSTRAINT `fk_suppliers_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `supplier_ledger` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `supplier_id` INT UNSIGNED NOT NULL,
    `entry_type` ENUM('OPENING', 'PURCHASE_BILL', 'PURCHASE_RETURN', 'PAYMENT_VOUCHER') NOT NULL,
    `reference_no` VARCHAR(100) NOT NULL,
    `debit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,  -- Reduces payable (Payment / Return)
    `credit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00, -- Increases payable (Purchase Bill)
    `balance_after` DECIMAL(15,2) NOT NULL,
    `payment_method` VARCHAR(32) DEFAULT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sl_supplier` (`supplier_id`, `created_at`),
    CONSTRAINT `fk_sl_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sl_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. CUSTOMERS & CUSTOMER DUE LEDGER
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(32) NOT NULL,
    `email` VARCHAR(120) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `route_territory` VARCHAR(150) DEFAULT NULL,
    `customer_type` ENUM('retail', 'wholesale') NOT NULL DEFAULT 'retail',
    `credit_limit` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `opening_due` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `current_due` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_cust_phone` (`phone`),
    CONSTRAINT `fk_customers_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `customer_ledger` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED NOT NULL,
    `entry_type` ENUM('OPENING', 'SALE_INVOICE', 'SALE_RETURN', 'PAYMENT_COLLECTION') NOT NULL,
    `reference_no` VARCHAR(100) NOT NULL,
    `debit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,  -- Increases customer due (Credit Sale)
    `credit_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00, -- Reduces customer due (Payment / Return)
    `balance_after` DECIMAL(15,2) NOT NULL,
    `payment_method` VARCHAR(32) DEFAULT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_cl_customer` (`customer_id`, `created_at`),
    CONSTRAINT `fk_cl_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_cl_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. PURCHASE ORDERS & GOODS RECEIPTS (GRN) + PURCHASE RETURNS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `purchases` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `supplier_id` INT UNSIGNED NOT NULL,
    `po_number` VARCHAR(64) NOT NULL,
    `idempotency_key` VARCHAR(64) NOT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `paid_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `due_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_method` ENUM('cash', 'bank', 'bkash', 'nagad', 'cheque', 'due') NOT NULL DEFAULT 'bank',
    `payment_ref` VARCHAR(120) DEFAULT NULL,
    `status` ENUM('posted', 'returned_partial', 'returned_full') NOT NULL DEFAULT 'posted',
    `received_date` DATE NOT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_po_number` (`organization_id`, `po_number`),
    UNIQUE KEY `uq_pur_idempotency` (`organization_id`, `idempotency_key`),
    CONSTRAINT `fk_pur_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pur_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pur_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `purchase_items` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `purchase_id` BIGINT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `quantity` DECIMAL(15,2) NOT NULL,
    `returned_qty` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `unit_cost` DECIMAL(15,2) NOT NULL,
    `line_total` DECIMAL(15,2) NOT NULL,
    `batch_number` VARCHAR(64) DEFAULT NULL,
    `expiry_date` DATE DEFAULT NULL,
    CONSTRAINT `fk_pitem_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pitem_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `purchase_returns` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `purchase_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `supplier_id` INT UNSIGNED NOT NULL,
    `return_no` VARCHAR(64) NOT NULL UNIQUE,
    `product_id` INT UNSIGNED NOT NULL,
    `return_qty` DECIMAL(15,2) NOT NULL,
    `unit_cost` DECIMAL(15,2) NOT NULL,
    `total_return_amount` DECIMAL(15,2) NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_preturn_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. POS & WHOLESALE SALES INVOICES + SALES RETURNS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sales` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED DEFAULT NULL,
    `invoice_no` VARCHAR(64) NOT NULL,
    `idempotency_key` VARCHAR(64) NOT NULL, -- Prevents duplicate form/button submission
    `channel` ENUM('retail_pos', 'wholesale_distribution') NOT NULL DEFAULT 'retail_pos',
    `customer_name` VARCHAR(255) NOT NULL DEFAULT 'Walk-in Customer',
    `customer_phone` VARCHAR(32) DEFAULT NULL,
    `delivery_challan_no` VARCHAR(64) DEFAULT NULL,
    `delivery_route` VARCHAR(150) DEFAULT NULL,
    `sales_rep_name` VARCHAR(150) DEFAULT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `tax_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `paid_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `change_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `due_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_method` ENUM('cash', 'bkash', 'nagad', 'rocket', 'bank', 'due', 'split') NOT NULL DEFAULT 'cash',
    `status` ENUM('posted', 'dispatched', 'delivered', 'returned_partial', 'returned_full') NOT NULL DEFAULT 'posted',
    `notes` TEXT DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_org_invoice_no` (`organization_id`, `invoice_no`),
    UNIQUE KEY `uq_sale_idempotency` (`organization_id`, `idempotency_key`),
    INDEX `idx_sales_created` (`created_at`),
    INDEX `idx_sales_channel` (`channel`),
    CONSTRAINT `fk_sales_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sales_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sales_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sale_items` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `sale_id` BIGINT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `product_name` VARCHAR(255) NOT NULL,
    `unit` VARCHAR(50) NOT NULL,
    `quantity` DECIMAL(15,2) NOT NULL,
    `returned_qty` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `unit_price` DECIMAL(15,2) NOT NULL,
    `wac_cost_at_sale` DECIMAL(15,4) NOT NULL, -- Captures exact Weighted Average Cost at moment of sale
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `line_total` DECIMAL(15,2) NOT NULL,
    CONSTRAINT `fk_sitem_sale` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_sitem_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sales_returns` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `sale_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED DEFAULT NULL,
    `return_no` VARCHAR(64) NOT NULL UNIQUE,
    `product_id` INT UNSIGNED NOT NULL,
    `return_qty` DECIMAL(15,2) NOT NULL,
    `unit_price` DECIMAL(15,2) NOT NULL,
    `total_refund_amount` DECIMAL(15,2) NOT NULL,
    `refund_method` ENUM('cash_refund', 'adjust_customer_due') NOT NULL DEFAULT 'cash_refund',
    `reason` VARCHAR(255) NOT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_sreturn_sale` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. EXPENSES & FINANCIAL ACCOUNTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expenses` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `branch_id` INT UNSIGNED NOT NULL,
    `voucher_no` VARCHAR(64) NOT NULL UNIQUE,
    `category` ENUM('rent', 'salary', 'electricity', 'transport', 'packaging', 'entertainment', 'maintenance', 'other') NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `payment_method` ENUM('cash', 'bkash', 'nagad', 'bank') NOT NULL DEFAULT 'cash',
    `paid_to` VARCHAR(150) NOT NULL,
    `expense_date` DATE NOT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_exp_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_exp_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. IMMUTABLE SECURITY AUDIT LOGS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `organization_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED DEFAULT NULL,
    `user_name` VARCHAR(150) NOT NULL,
    `user_role` VARCHAR(50) NOT NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(64) NOT NULL,
    `entity_ref` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL DEFAULT '127.0.0.1',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_org_date` (`organization_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. PERSISTENT ERP STATE STORE, E-COMMERCE ORDERS & SPIN WHEEL LEADS (cPanel Full Sync)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `app_state_store` (
    `id` INT UNSIGNED NOT NULL PRIMARY KEY DEFAULT 1,
    `state_json` LONGTEXT NOT NULL,
    `updated_at` BIGINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `online_orders` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `order_no` VARCHAR(64) NOT NULL,
    `invoice_no` VARCHAR(64) DEFAULT NULL,
    `customer_name` VARCHAR(255) NOT NULL,
    `customer_phone` VARCHAR(32) NOT NULL,
    `delivery_area` VARCHAR(150) DEFAULT NULL,
    `delivery_address` TEXT DEFAULT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `delivery_charge` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_method` VARCHAR(32) NOT NULL DEFAULT 'cod',
    `payment_status` VARCHAR(32) NOT NULL DEFAULT 'unpaid',
    `order_status` VARCHAR(32) NOT NULL DEFAULT 'pending',
    `order_source` VARCHAR(64) DEFAULT 'storefront',
    `items_json` LONGTEXT DEFAULT NULL,
    `created_at` VARCHAR(64) DEFAULT NULL,
    `updated_at` VARCHAR(64) DEFAULT NULL,
    INDEX `idx_oo_phone` (`customer_phone`),
    INDEX `idx_oo_status` (`order_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `incomplete_orders` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `session_key` VARCHAR(120) NOT NULL,
    `customer_name` VARCHAR(255) DEFAULT NULL,
    `customer_phone` VARCHAR(32) NOT NULL,
    `delivery_area` VARCHAR(150) DEFAULT NULL,
    `delivery_address` TEXT DEFAULT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `delivery_charge` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `status` VARCHAR(32) NOT NULL DEFAULT 'abandoned',
    `converted_order_id` VARCHAR(64) DEFAULT NULL,
    `converted_order_no` VARCHAR(64) DEFAULT NULL,
    `order_source` VARCHAR(64) DEFAULT 'storefront',
    `items_json` LONGTEXT DEFAULT NULL,
    `created_at` VARCHAR(64) DEFAULT NULL,
    `updated_at` VARCHAR(64) DEFAULT NULL,
    INDEX `idx_io_phone` (`customer_phone`),
    INDEX `idx_io_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `spin_wheel_leads` (
    `id` VARCHAR(96) NOT NULL PRIMARY KEY,
    `source` VARCHAR(32) NOT NULL DEFAULT 'website',
    `customer_name` VARCHAR(255) NOT NULL,
    `customer_phone` VARCHAR(32) NOT NULL,
    `reward_label` VARCHAR(255) NOT NULL,
    `reward_type` VARCHAR(64) NOT NULL DEFAULT 'flat_discount',
    `reward_value` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `coupon_code` VARCHAR(64) DEFAULT NULL,
    `used_in_order` TINYINT(1) NOT NULL DEFAULT 0,
    `order_invoice_no` VARCHAR(64) DEFAULT NULL,
    `landing_product_id` VARCHAR(96) DEFAULT NULL,
    `landing_product_name` VARCHAR(255) DEFAULT NULL,
    `spin_date_key` VARCHAR(32) DEFAULT NULL,
    `created_at` VARCHAR(64) DEFAULT NULL,
    INDEX `idx_swl_phone` (`customer_phone`),
    INDEX `idx_swl_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
